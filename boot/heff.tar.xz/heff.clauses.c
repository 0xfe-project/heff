// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eclauses_2eappendC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eappendC_entry, 2, 0};

V g_heff_2eclauses_2eappendC(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eclauses_2eappendC(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2eappendC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eappendC(a[0], a[1]);
}
Clo g_heff_2eclauses_2econcatMapC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_entry, 2, 0};

V g_heff_2eclauses_2econcatMapC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eclauses_2econcatMapC(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2econcatMapC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eclauses_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecatMaybesC_entry, 1, 0};

V g_heff_2eclauses_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eclauses_2ecatMaybesC(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ecatMaybesC(a[0]);
}
Clo g_heff_2eclauses_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_entry, 2, 0};

V g_heff_2eclauses_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_at(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_x1_247 = (g_heff_2eclauses_2etraverseC(v_f_240, v_xs_243));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_x_246);
        return heff_tag_at(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){v_e_248});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_249})});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC(a[0], a[1]);
}
Clo g_heff_2eclauses_2eforC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eforC_entry, 2, 0};

V g_heff_2eclauses_2eforC(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_x1_244 = heff_tr(heff_apply(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_at(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      heff_take_n(v_x1_244, 0ULL, 1);
      V t_0 = v_xs_243;
      V t_1 = v_f_241;
      v_x1_240 = t_0;
      v_f_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2eforC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eforC(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2enthC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2enthC_entry, 2, 0};

V g_heff_2eclauses_2enthC(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2enthC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2enthC(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2ezipC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ezipC_entry, 2, 0};

V g_heff_2eclauses_2ezipC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eclauses_2ezipC(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2ezipC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ezipC(a[0], a[1]);
}
Clo g_heff_2eclauses_2eanyC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eanyC_entry, 2, 0};

V g_heff_2eclauses_2eanyC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2eanyC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eanyC(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eclauses_2eallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eallC_entry, 2, 0};

V g_heff_2eclauses_2eallC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2eallC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eallC(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2enubStr_lam0(V self, V *args);
Clo g_heff_2eclauses_2enubStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2enubStr_entry, 1, 0};

V g_heff_2eclauses_2enubStr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2eclauses_2enubStr_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eclauses_2enubStr(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2enubStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2enubStr(a[0]);
}
V g_heff_2eclauses_2enubStr_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2eclauses_2eupToGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eupToGo_entry, 2, 0};

V g_heff_2eclauses_2eupToGo(V v_i_240, V v_n_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_241), heff_dup(v_i_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_i_240), (g_heff_2eclauses_2eupToGo(heff_intAdd(v_i_240, MK_INT(1LL)), v_n_241))});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eclauses_2eupToGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eupToGo(a[0], a[1]);
}
Clo g_heff_2eclauses_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edropAt_entry, 2, 0};

V g_heff_2eclauses_2edropAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eclauses_2edropAt(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2edropAt(a[0], a[1]);
}
Clo g_heff_2eclauses_2etakeC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etakeC_entry, 2, 0};

V g_heff_2eclauses_2etakeC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eclauses_2etakeC(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2etakeC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etakeC(a[0], a[1]);
}
Clo g_heff_2eclauses_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edropC_entry, 2, 0};

V g_heff_2eclauses_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2edropC(a[0], a[1]);
}
Clo g_heff_2eclauses_2etraverseC_24s272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_24s272_entry, 1, 0};

V g_heff_2eclauses_2etraverseC_24s272(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eclauses_2etraverseC_24s272(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2etraverseC_24s272_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC_24s272(a[0]);
}
Clo g_heff_2eclauses_2etraverseC_24s273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_24s273_entry, 1, 0};

V g_heff_2eclauses_2etraverseC_24s273(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_p_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_x1_245 = (g_heff_2eclauses_2epat(v_p_244));
      switch (heff_tag_of(v_x1_245)) {
      case TAG_Left: {
        V v_e_246 = heff_field(v_x1_245, 0);
        V v_ru_24x1_245_24Left = heff_take_reuse_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_243);
        v_x1_248 = heff_tag_at(v_ru_24x1_245_24Left, TAG_Left, 1, (V[]){v_e_246});
        break;
      }
      case TAG_Right: {
        V v_x_247 = heff_field(v_x1_245, 0);
        V v_ru_24x1_245_24Right = heff_take_reuse_n(v_x1_245, 1ULL, 1);
        v_x1_248 = heff_tag_at(v_ru_24x1_245_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_x_247})});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      heff_drop(v_xs_242);
      return heff_tag_at(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      V v_x1_2411 = (g_heff_2eclauses_2etraverseC_24s273(v_xs_242));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Left: {
        V v_e_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        heff_drop(v_x_2410);
        return heff_tag_at(v_ru_24x1_248_24Right, TAG_Left, 1, (V[]){v_e_2412});
      }
      case TAG_Right: {
        V v_x_2413 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_x_2413})});
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2etraverseC_24s273_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC_24s273(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[86]; } g_heff_2eclauses_2epat_str0 = {{0x80000000u, K_STR, 0}, 86, 86, {97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 118, 97, 114, 105, 97, 98, 108, 101, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 111, 114, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 111, 102, 32, 112, 97, 116, 116, 101, 114, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[86]; } g_heff_2eclauses_2epat_str1 = {{0x80000000u, K_STR, 0}, 86, 86, {97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 118, 97, 114, 105, 97, 98, 108, 101, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 111, 114, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 111, 102, 32, 112, 97, 116, 116, 101, 114, 110, 115}};
Clo g_heff_2eclauses_2epat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epat_entry, 1, 0};

V g_heff_2eclauses_2epat(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_dup(heff_field(v_p_240, 0));
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24PatVar = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_p_240);
    return heff_tag_at(v_ru_24t_243_24PatVar, TAG_Right, 1, (V[]){heff_tag(TAG_PVar, 1, (V[]){v_x_244})});
  }
  case TAG_PatTag: {
    V v_t_245 = heff_field(v_t_243, 0);
    V v_tsp_246 = heff_field(v_t_243, 1);
    V v_ps_247 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24PatTag = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_p_240);
    V v_x1_248 = (g_heff_2eclauses_2etraverseC_24s272(v_ps_247));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      heff_drop(v_t_245);
      heff_drop(v_tsp_246);
      heff_drop_cell(v_ru_24t_243_24PatTag, 3);
      return heff_tag_at(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24t_243_24PatTag, TAG_PTag, 3, (V[]){v_t_245, v_x_2410, v_tsp_246})});
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_PatOp: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_span_2416;
    switch (heff_tag_of(v_p_240)) {
    case TAG_At: {
      V v_s_2415 = heff_field(v_p_240, 1);
      heff_take_n(v_p_240, 2ULL, 2);
      v_span_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_p_240);
    }
    return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2416, ((V)&g_heff_2eclauses_2epat_str0)})});
  }
  case TAG_PatInt: {
    V v_ru_24t_243_24PatInt = heff_take_reuse_n(v_t_243, 0ULL, 1);
    return heff_tag_at(v_ru_24t_243_24PatInt, TAG_Right, 1, (V[]){heff_tag(TAG_PLit, 1, (V[]){v_p_240})});
  }
  case TAG_PatFloat: {
    V v_ru_24t_243_24PatFloat = heff_take_reuse_n(v_t_243, 0ULL, 1);
    return heff_tag_at(v_ru_24t_243_24PatFloat, TAG_Right, 1, (V[]){heff_tag(TAG_PLit, 1, (V[]){v_p_240})});
  }
  case TAG_PatString: {
    V v_ru_24t_243_24PatString = heff_take_reuse_n(v_t_243, 0ULL, 1);
    return heff_tag_at(v_ru_24t_243_24PatString, TAG_Right, 1, (V[]){heff_tag(TAG_PLit, 1, (V[]){v_p_240})});
  }
  case TAG_PatRecord: {
    V v_fs_2420 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24PatRecord = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_x1_2421 = (g_heff_2eclauses_2etraverseC_24s273(v_fs_2420));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Left: {
      V v_e_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      heff_drop(v_p_240);
      return heff_tag_at(v_ru_24t_243_24PatRecord, TAG_Left, 1, (V[]){v_e_2422});
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_tag_at(v_ru_24t_243_24PatRecord, TAG_Right, 1, (V[]){heff_tag(TAG_PRec, 2, (V[]){v_x_2423, v_t_2426})});
    }
    default: return heff_nomatch(v_x1_2421);
    }
  }
  case TAG_PatWord: {
    V v_ru_24t_243_24PatWord = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_span_2430;
    switch (heff_tag_of(v_p_240)) {
    case TAG_At: {
      V v_s_2429 = heff_field(v_p_240, 1);
      heff_take_n(v_p_240, 2ULL, 2);
      v_span_2430 = v_s_2429;
      break;
    }
    default: heff_nomatch(v_p_240);
    }
    return heff_tag_at(v_ru_24t_243_24PatWord, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2430, ((V)&g_heff_2eclauses_2epat_str1)})});
  }
  case TAG_PatAs: {
    V v_x_2431 = heff_field(v_t_243, 0);
    V v_q_2433 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    heff_drop(v_p_240);
    V v_x1_2434 = (g_heff_2eclauses_2epat(v_q_2433));
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Left: {
      V v_e_2435 = heff_field(v_x1_2434, 0);
      V v_ru_24x1_2434_24Left = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
      heff_drop(v_x_2431);
      return heff_tag_at(v_ru_24x1_2434_24Left, TAG_Left, 1, (V[]){v_e_2435});
    }
    case TAG_Right: {
      V v_x_2436 = heff_field(v_x1_2434, 0);
      V v_ru_24x1_2434_24Right = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_2434_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_PAs, 2, (V[]){v_x_2431, v_x_2436})});
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2epat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epat(a[0]);
}
Clo g_heff_2eclauses_2esameLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2esameLit_entry, 2, 0};

V g_heff_2eclauses_2esameLit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      return NTAG(TAG_False);
    }
    case TAG_PatOp: {
      return NTAG(TAG_False);
    }
    case TAG_PatInt: {
      V v_x_2411 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2412 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          V v_y_2421 = heff_field(v_x21_2412, 0);
          return heff_intEq(heff_dup(v_x_2411), heff_dup(v_y_2421));
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatFloat: {
      V v_x_2429 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2430 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2430)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          V v_y_2440 = heff_field(v_x21_2430, 0);
          return heff_floatEq(heff_dup(v_x_2429), heff_dup(v_y_2440));
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2430);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatString: {
      V v_x_2447 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2448 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2448)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          V v_y_2459 = heff_field(v_x21_2448, 0);
          return heff_strEq(heff_dup(v_x_2447), heff_dup(v_y_2459));
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2448);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRecord: {
      return NTAG(TAG_False);
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2esameLit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2esameLit(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eclauses_2elitExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitExpr_entry, 1, 0};

V g_heff_2eclauses_2elitExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatTag: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatOp: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatInt: {
      V v_x_2410 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatInt = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2411 = heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IInt, 1, (V[]){v_x_2410}), heff_dup(v_sp_242)});
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x11_241_24PatInt, TAG_CInf, 1, (V[]){v_t_2411}), v_sp_242});
    }
    case TAG_PatFloat: {
      V v_x_2412 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatFloat = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2413 = heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IFloat, 1, (V[]){v_x_2412}), heff_dup(v_sp_242)});
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x11_241_24PatFloat, TAG_CInf, 1, (V[]){v_t_2413}), v_sp_242});
    }
    case TAG_PatString: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatString = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag(TAG_IString, 1, (V[]){v_x_2414}), heff_dup(v_sp_242)});
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x11_241_24PatString, TAG_CInf, 1, (V[]){v_t_2415}), v_sp_242});
    }
    case TAG_PatRecord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatAs: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2elitExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2elitExpr(a[0]);
}
Clo g_heff_2eclauses_2etraverseC_24s274_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_24s274_entry, 1, 0};

V g_heff_2eclauses_2etraverseC_24s274(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eclauses_2etraverseC_24s274(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2etraverseC_24s274_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC_24s274(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s275_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s275(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eclauses_2epatVars(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eclauses_2econcatMapC_24s275(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s275_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s275(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s276_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s276_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s276(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_y_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eclauses_2epatVars(v_t_245));
    V v_t_247 = (g_heff_2eclauses_2econcatMapC_24s276(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s276_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s276(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2epatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epatVars_entry, 1, 0};

V g_heff_2eclauses_2epatVars(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
  }
  case TAG_PTag: {
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_ps_243; V r_ = (g_heff_2eclauses_2econcatMapC_24s275(a_0)); heff_drop(v_ps_243); r_; });
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PRec: {
    V v_fps_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fps_246; V r_ = (g_heff_2eclauses_2econcatMapC_24s276(a_0)); heff_drop(v_fps_246); r_; });
  }
  case TAG_PAs: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_p_249 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_248, (g_heff_2eclauses_2epatVars(v_p_249))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2epatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epatVars(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s277_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eclauses_2epatIdents(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eclauses_2econcatMapC_24s277(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s277_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s277(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s278_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s278_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s278(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_q_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eclauses_2epatIdents(v_q_244))});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eclauses_2econcatMapC_24s278(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s278_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2econcatMapC_24s278(a[0]);
}
Clo g_heff_2eclauses_2epatIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epatIdents_entry, 1, 0};

V g_heff_2eclauses_2epatIdents(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
  }
  case TAG_PatTag: {
    V v_ps_247 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    return ({ V a_0 = v_ps_247; V r_ = (g_heff_2eclauses_2econcatMapC_24s277(a_0)); heff_drop(v_ps_247); r_; });
  }
  case TAG_PatOp: {
    V v_x_248 = heff_field(v_t_243, 0);
    V v_ps_2410 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_248, ({ V a_0 = v_ps_2410; V r_ = (g_heff_2eclauses_2econcatMapC_24s277(a_0)); heff_drop(v_ps_2410); r_; })});
  }
  case TAG_PatInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatString: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatRecord: {
    V v_fs_2414 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2econcatMapC_24s278(v_fs_2414);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatAs: {
    V v_x_2416 = heff_field(v_t_243, 0);
    V v_q_2418 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2416, (g_heff_2eclauses_2epatIdents(v_q_2418))});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2epatIdents_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epatIdents(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s279_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s279_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eclauses_2epatIdents(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eclauses_2econcatMapC_24s279(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s279_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s279(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eclauses_2eidentsInfF_lam0(V self, V *args);
Clo g_heff_2eclauses_2eidentsInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsInfF_entry, 2, 0};

V g_heff_2eclauses_2eidentsInfF(V v_r_240, V v_n_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_IVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_r_240);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
  }
  case TAG_IInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_IFloat: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_IString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_IApp: {
    V v_h_249 = heff_field(v_t_244, 0);
    V v_args_2410 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_h_249}));
    V v_t_2420 = ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsInfF_lam0, 1, 1, (V[]){v_r_240}); V a_1 = v_args_2410; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_args_2410); r_; });
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2411, v_t_2420);
  }
  case TAG_IAnn: {
    V v_c_2421 = heff_field(v_t_244, 0);
    V v_t_2422 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_chk), 1, (V[]){v_c_2421}));
    V v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2422}));
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2423, v_t_2424);
  }
  case TAG_ISpec: {
    V v_a_2425 = heff_field(v_t_244, 0);
    V v_v_2428 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 9ULL, 4);
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_a_2425}));
    V v_t_2430 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_v_2428}));
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2429, v_t_2430);
  }
  case TAG_IAnnLam: {
    V v_x_2431 = heff_field(v_t_244, 0);
    V v_t_2433 = heff_field(v_t_244, 2);
    V v_b_2434 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2433}));
    V v_t_2436 = heff_tr(heff_apply(heff_get(v_r_240, LBL_inf), 1, (V[]){v_b_2434}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2431, (g_heff_2eclauses_2eappendC(v_t_2435, v_t_2436))});
  }
  case TAG_IInvalid: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_INominal: {
    V v_i_2439 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_2439});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2eidentsInfF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eidentsInfF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2eidentsInfF_lam0(V self, V *args) {
  V v_x2_2412 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_At: {
    V v_x21_2413 = heff_field(v_x2_2412, 0);
    V v_ru_24x2_2412_24At = heff_take_reuse_n(v_x2_2412, 1ULL, 2);
    switch (heff_tag_of(v_x21_2413)) {
    case TAG_ArgExplicit: {
      V v_c_2415 = heff_field(v_x21_2413, 0);
      heff_take_n(v_x21_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2412_24At, 2);
      V f_ = heff_get(v_r_240, LBL_chk);
      args[0] = v_c_2415;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_2413, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop_cell(v_ru_24x2_2412_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ArgNamed: {
      V v_x_2417 = heff_field(v_x21_2413, 0);
      V v_c_2418 = heff_field(v_x21_2413, 1);
      heff_take_n(v_x21_2413, 3ULL, 2);
      V v_t_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2418}));
      return heff_tag_at(v_ru_24x2_2412_24At, TAG_Cons, 2, (V[]){v_x_2417, v_t_2419});
    }
    default: return heff_nomatch(v_x21_2413);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2eclauses_2eidentsChkF_lam0(V self, V *args);
V g_heff_2eclauses_2eidentsChkF_lam1(V self, V *args);
Clo g_heff_2eclauses_2eidentsChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsChkF_entry, 2, 0};

V g_heff_2eclauses_2eidentsChkF(V v_r_240, V v_n_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_CInf: {
    V v_i_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_246});
  }
  case TAG_CLam: {
    V v_x_247 = heff_field(v_t_244, 0);
    V v_b_249 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_249}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_247, v_t_2410});
  }
  case TAG_CImplicitLam: {
    V v_x_2411 = heff_field(v_t_244, 0);
    V v_b_2413 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2413}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_t_2414});
  }
  case TAG_CAnnLam: {
    V v_x_2415 = heff_field(v_t_244, 0);
    V v_t_2417 = heff_field(v_t_244, 2);
    V v_b_2418 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2417}));
    V v_t_2420 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2418}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2415, (g_heff_2eclauses_2eappendC(v_t_2419, v_t_2420))});
  }
  case TAG_CTag: {
    V v_args_2423 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 4ULL, 3);
    return ({ V a_0 = heff_get(v_r_240, LBL_chk); V a_1 = v_args_2423; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_args_2423); r_; });
  }
  case TAG_CStruct: {
    V v_fs_2424 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsChkF_lam0, 1, 1, (V[]){v_r_240}); V a_1 = v_fs_2424; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_fs_2424); r_; });
  }
  case TAG_CMatch: {
    V v_s_2434 = heff_field(v_t_244, 0);
    V v_alts_2435 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_s_2434}));
    V v_t_2444 = ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsChkF_lam1, 1, 1, (V[]){v_r_240}); V a_1 = v_alts_2435; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_alts_2435); r_; });
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2436, v_t_2444);
  }
  case TAG_CLetIn: {
    V v_rhs_2445 = heff_field(v_t_244, 0);
    V v_a_2446 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_rhs_2445}));
    V v_t_2454;
    switch (heff_tag_of(v_a_2446)) {
    case TAG_At: {
      V v_x21_2448 = heff_field(v_a_2446, 0);
      heff_take_n(v_a_2446, 1ULL, 2);
      switch (heff_tag_of(v_x21_2448)) {
      case TAG_MkAlt: {
        V v_p_2450 = heff_field(v_x21_2448, 0);
        V v_b_2451 = heff_field(v_x21_2448, 1);
        heff_take_n(v_x21_2448, 3ULL, 2);
        V v_t_2452 = (g_heff_2eclauses_2epatIdents(v_p_2450));
        V v_t_2453 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2451}));
        v_t_2454 = (g_heff_2eclauses_2eappendC(v_t_2452, v_t_2453));
        break;
      }
      default: heff_nomatch(v_x21_2448);
      }
      break;
    }
    default: heff_nomatch(v_a_2446);
    }
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2447, v_t_2454);
  }
  case TAG_CLocal: {
    V v_body_2455 = heff_field(v_t_244, 0);
    V v_ds_2456 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_chk), 1, (V[]){v_body_2455}));
    V v_t_2458 = ({ V a_0 = heff_get(v_r_240, LBL_decl); V a_1 = v_ds_2456; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_ds_2456); r_; });
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2457, v_t_2458);
  }
  case TAG_CAbandon: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_CNominal: {
    V v_c_2459 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2459});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2eidentsChkF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eidentsChkF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2eidentsChkF_lam0(V self, V *args) {
  V v_f_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_At: {
    V v_x_2426 = heff_field(v_f_2425, 0);
    heff_take_n(v_f_2425, 1ULL, 2);
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_SetField: {
    V v_x_2429 = heff_field(v_t_2428, 0);
    V v_e_2431 = heff_field(v_t_2428, 2);
    heff_take_n(v_t_2428, 5ULL, 3);
    V v_t_2432 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_e_2431}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2429, v_t_2432});
  }
  case TAG_BadFieldSet: {
    V v_e_2433 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    V f_ = heff_get(v_r_240, LBL_chk);
    args[0] = v_e_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2eclauses_2eidentsChkF_lam1(V self, V *args) {
  V v_a_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2437)) {
  case TAG_At: {
    V v_x21_2438 = heff_field(v_a_2437, 0);
    heff_take_n(v_a_2437, 1ULL, 2);
    switch (heff_tag_of(v_x21_2438)) {
    case TAG_MkAlt: {
      V v_p_2440 = heff_field(v_x21_2438, 0);
      V v_b_2441 = heff_field(v_x21_2438, 1);
      heff_take_n(v_x21_2438, 3ULL, 2);
      V v_t_2442 = (g_heff_2eclauses_2epatIdents(v_p_2440));
      V v_t_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2441}));
      return (g_heff_2eclauses_2eappendC(v_t_2442, v_t_2443));
    }
    default: return heff_nomatch(v_x21_2438);
    }
  }
  default: return heff_nomatch(v_a_2437);
  }
}
V g_heff_2eclauses_2eidentsTypF_lam0(V self, V *args);
V g_heff_2eclauses_2eidentsTypF_lam1(V self, V *args);
Clo g_heff_2eclauses_2eidentsTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsTypF_entry, 2, 0};

V g_heff_2eclauses_2eidentsTypF(V v_r_240, V v_n_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_TPi: {
    V v_b_245 = heff_field(v_t_244, 0);
    V v_cod_246 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24TPi = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_b_245)) {
    case TAG_PiNamed: {
      V v_x_247 = heff_field(v_b_245, 0);
      V v_t_249 = heff_field(v_b_245, 2);
      heff_take_n(v_b_245, 5ULL, 3);
      V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_249}));
      v_t_2422 = heff_tag_at(v_ru_24t_244_24TPi, TAG_Cons, 2, (V[]){v_x_247, v_t_2410});
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2411 = heff_field(v_b_245, 0);
      V v_t_2414 = heff_field(v_b_245, 3);
      heff_take_n(v_b_245, 9ULL, 4);
      V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2414}));
      v_t_2422 = heff_tag_at(v_ru_24t_244_24TPi, TAG_Cons, 2, (V[]){v_x_2411, v_t_2415});
      break;
    }
    case TAG_PiInstance: {
      V v_x_2416 = heff_field(v_b_245, 0);
      V v_t_2419 = heff_field(v_b_245, 3);
      heff_take_n(v_b_245, 9ULL, 4);
      V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2419}));
      v_t_2422 = heff_tag_at(v_ru_24t_244_24TPi, TAG_Cons, 2, (V[]){v_x_2416, v_t_2420});
      break;
    }
    case TAG_PiAnon: {
      V v_d_2421 = heff_field(v_b_245, 0);
      heff_take_n(v_b_245, 1ULL, 1);
      heff_drop_cell(v_ru_24t_244_24TPi, 2);
      v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_d_2421}));
      break;
    }
    default: heff_nomatch(v_b_245);
    }
    V v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_cod_246}));
    HEFF_LAST return g_heff_2eclauses_2eappendC(v_t_2422, v_t_2423);
  }
  case TAG_TSig: {
    V v_fs_2424 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsTypF_lam0, 1, 1, (V[]){v_r_240}); V a_1 = v_fs_2424; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_fs_2424); r_; });
  }
  case TAG_TSum: {
    V v_vs_2437 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsTypF_lam1, 1, 1, (V[]){v_r_240}); V a_1 = v_vs_2437; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_vs_2437); r_; });
  }
  case TAG_TType: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TInt: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TFloat: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TString: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TArray: {
    V v_a_2446 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_typ), 1, (V[]){v_a_2446});
  }
  case TAG_TInf: {
    V v_i_2447 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_2447});
  }
  case TAG_TChk: {
    V v_c_2448 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2448});
  }
  case TAG_TNominal: {
    V v_t_2449 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2449});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2eidentsTypF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eidentsTypF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2eidentsTypF_lam0(V self, V *args) {
  V v_f_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_At: {
    V v_x_2426 = heff_field(v_f_2425, 0);
    heff_take_n(v_f_2425, 1ULL, 2);
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_DeclareField: {
    V v_x_2429 = heff_field(v_t_2428, 0);
    V v_t_2431 = heff_field(v_t_2428, 2);
    V v_d_2432 = heff_field(v_t_2428, 3);
    heff_take_n(v_t_2428, 13ULL, 4);
    V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2431}));
    V v_t_2435;
    switch (heff_tag_of(v_d_2432)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      v_t_2435 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2434 = heff_field(v_d_2432, 0);
      heff_take_n(v_d_2432, 1ULL, 1);
      v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_x_2434}));
      break;
    }
    default: heff_nomatch(v_d_2432);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2429, (g_heff_2eclauses_2eappendC(v_t_2433, v_t_2435))});
  }
  case TAG_BadFieldDecl: {
    V v_e_2436 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    V f_ = heff_get(v_r_240, LBL_typ);
    args[0] = v_e_2436;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2eclauses_2eidentsTypF_lam1(V self, V *args) {
  V v_v_2438 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441;
  switch (heff_tag_of(v_v_2438)) {
  case TAG_At: {
    V v_x_2439 = heff_field(v_v_2438, 0);
    heff_take_n(v_v_2438, 1ULL, 2);
    v_t_2441 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_v_2438);
  }
  switch (heff_tag_of(v_t_2441)) {
  case TAG_TagVariant: {
    V v_args_2444 = heff_field(v_t_2441, 2);
    heff_take_n(v_t_2441, 4ULL, 3);
    return ({ V a_0 = heff_get(v_r_240, LBL_typ); V a_1 = v_args_2444; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_args_2444); r_; });
  }
  case TAG_BadVariant: {
    V v_e_2445 = heff_field(v_t_2441, 0);
    heff_take_n(v_t_2441, 1ULL, 1);
    V f_ = heff_get(v_r_240, LBL_typ);
    args[0] = v_e_2445;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2441);
  }
}
V g_heff_2eclauses_2eidentsDeclF_lam0(V self, V *args);
V g_heff_2eclauses_2eidentsDeclF_lam1(V self, V *args);
V g_heff_2eclauses_2eidentsDeclF_lam2(V self, V *args);
Clo g_heff_2eclauses_2eidentsDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsDeclF_entry, 2, 0};

V g_heff_2eclauses_2eidentsDeclF(V v_r_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_ty_247}));
    V v_t_2419 = ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsDeclF_lam0, 1, 1, (V[]){v_r_240}); V a_1 = v_eqs_248; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_eqs_248); r_; });
    return heff_tag(TAG_Cons, 2, (V[]){v_f_245, (g_heff_2eclauses_2eappendC(v_t_249, v_t_2419))});
  }
  case TAG_DeclDefine: {
    V v_x_2420 = heff_field(v_t_244, 0);
    V v_ps_2422 = heff_field(v_t_244, 2);
    V v_u_2423 = heff_field(v_t_244, 3);
    V v_body_2424 = heff_field(v_t_244, 4);
    heff_take_n(v_t_244, 29ULL, 5);
    V v_t_2436 = ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsDeclF_lam1, 1, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_ps_2422; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_ps_2422); r_; });
    V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_u_2423}));
    V v_t_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_body_2424}));
    V v_t_2439 = (g_heff_2eclauses_2eappendC(v_t_2437, v_t_2438));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2420, (g_heff_2eclauses_2eappendC(v_t_2436, v_t_2439))});
  }
  case TAG_DeclTheory: {
    V v_x_2440 = heff_field(v_t_244, 0);
    V v_ps_2442 = heff_field(v_t_244, 2);
    V v_body_2443 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2455 = ({ V a_0 = heff_clo(g_heff_2eclauses_2eidentsDeclF_lam2, 1, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_ps_2442; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_ps_2442); r_; });
    V v_t_2456 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_body_2443}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2440, (g_heff_2eclauses_2eappendC(v_t_2455, v_t_2456))});
  }
  case TAG_DeclPrimitive: {
    V v_x_2457 = heff_field(v_t_244, 0);
    V v_t_2459 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2459}));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2457, v_t_2460});
  }
  case TAG_DeclTest: {
    V v_x_2461 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24DeclTest = heff_take_reuse_n(v_t_244, 1ULL, 2);
    heff_drop(v_r_240);
    return heff_tag_at(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){v_x_2461, NTAG(TAG_Nil)});
  }
  case TAG_DeclWatch: {
    V v_e_2463 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tail(heff_get(v_r_240, LBL_chk), 1, (V[]){v_e_2463});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2eidentsDeclF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eidentsDeclF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2eidentsDeclF_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_m_2410, 0);
    V v_ru_24m_2410_24At = heff_take_reuse_n(v_m_2410, 1ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkEquation: {
      V v_f_2413 = heff_field(v_x21_2411, 0);
      V v_ps_2415 = heff_field(v_x21_2411, 2);
      V v_rhs_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 13ULL, 4);
      V v_t_2417 = ({ V a_0 = v_ps_2415; V r_ = (g_heff_2eclauses_2econcatMapC_24s279(a_0)); heff_drop(v_ps_2415); r_; });
      V v_t_2418 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_rhs_2416}));
      return heff_tag_at(v_ru_24m_2410_24At, TAG_Cons, 2, (V[]){v_f_2413, (g_heff_2eclauses_2eappendC(v_t_2417, v_t_2418))});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eclauses_2eidentsDeclF_lam1(V self, V *args) {
  V v_m_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2425)) {
  case TAG_At: {
    V v_x21_2426 = heff_field(v_m_2425, 0);
    V v_ru_24m_2425_24At = heff_take_reuse_n(v_m_2425, 1ULL, 2);
    switch (heff_tag_of(v_x21_2426)) {
    case TAG_ExplicitParam: {
      V v_x_2428 = heff_field(v_x21_2426, 0);
      V v_t_2430 = heff_field(v_x21_2426, 2);
      heff_take_n(v_x21_2426, 5ULL, 3);
      V v_t_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2430}));
      return heff_tag_at(v_ru_24m_2425_24At, TAG_Cons, 2, (V[]){v_x_2428, v_t_2431});
    }
    case TAG_ImplicitParam: {
      V v_x_2432 = heff_field(v_x21_2426, 0);
      V v_t_2434 = heff_field(v_x21_2426, 2);
      heff_take_n(v_x21_2426, 5ULL, 3);
      V v_t_2435 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2434}));
      return heff_tag_at(v_ru_24m_2425_24At, TAG_Cons, 2, (V[]){v_x_2432, v_t_2435});
    }
    default: return heff_nomatch(v_x21_2426);
    }
  }
  default: return heff_nomatch(v_m_2425);
  }
}
V g_heff_2eclauses_2eidentsDeclF_lam2(V self, V *args) {
  V v_m_2444 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2444)) {
  case TAG_At: {
    V v_x21_2445 = heff_field(v_m_2444, 0);
    V v_ru_24m_2444_24At = heff_take_reuse_n(v_m_2444, 1ULL, 2);
    switch (heff_tag_of(v_x21_2445)) {
    case TAG_ExplicitParam: {
      V v_x_2447 = heff_field(v_x21_2445, 0);
      V v_t_2449 = heff_field(v_x21_2445, 2);
      heff_take_n(v_x21_2445, 5ULL, 3);
      V v_t_2450 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2449}));
      return heff_tag_at(v_ru_24m_2444_24At, TAG_Cons, 2, (V[]){v_x_2447, v_t_2450});
    }
    case TAG_ImplicitParam: {
      V v_x_2451 = heff_field(v_x21_2445, 0);
      V v_t_2453 = heff_field(v_x21_2445, 2);
      heff_take_n(v_x21_2445, 5ULL, 3);
      V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2453}));
      return heff_tag_at(v_ru_24m_2444_24At, TAG_Cons, 2, (V[]){v_x_2451, v_t_2454});
    }
    default: return heff_nomatch(v_x21_2445);
    }
  }
  default: return heff_nomatch(v_m_2444);
  }
}
V g_heff_2eclauses_2eidents_lam0(V self, V *args); static Clo g_heff_2eclauses_2eidents_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidents_lam0, 1, 0};
V g_heff_2eclauses_2eidents_lam1(V self, V *args); static Clo g_heff_2eclauses_2eidents_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidents_lam1, 1, 0};
V g_heff_2eclauses_2eidents_lam2(V self, V *args); static Clo g_heff_2eclauses_2eidents_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidents_lam2, 1, 0};
V g_heff_2eclauses_2eidents_lam3(V self, V *args); static Clo g_heff_2eclauses_2eidents_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidents_lam3, 1, 0};

static V g_heff_2eclauses_2eidents_val;
static int g_heff_2eclauses_2eidents_st;
static V g_heff_2eclauses_2eidents_init(void) {
  return heff_rec(4, shape_138_43_353_54, (V[]){((V)&g_heff_2eclauses_2eidents_lam0_clo), ((V)&g_heff_2eclauses_2eidents_lam1_clo), ((V)&g_heff_2eclauses_2eidents_lam2_clo), ((V)&g_heff_2eclauses_2eidents_lam3_clo)});
}
V g_heff_2eclauses_2eidents_get(void) {
  if (g_heff_2eclauses_2eidents_st == 2) return g_heff_2eclauses_2eidents_val;
  if (g_heff_2eclauses_2eidents_st == 1) heff_fail("defined by itself");
  g_heff_2eclauses_2eidents_st = 1;
  g_heff_2eclauses_2eidents_val = heff_tr(g_heff_2eclauses_2eidents_init());
  g_heff_2eclauses_2eidents_st = 2;
  return g_heff_2eclauses_2eidents_val;
}
V g_heff_2eclauses_2eidents_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eclauses_2eidents_get()); V a_1 = v_n_240; V r_ = (g_heff_2eclauses_2eidentsInfF(a_0, a_1)); heff_drop(v_n_240); r_; });
}
V g_heff_2eclauses_2eidents_lam1(V self, V *args) {
  V v_n_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eclauses_2eidents_get()); V a_1 = v_n_241; V r_ = (g_heff_2eclauses_2eidentsChkF(a_0, a_1)); heff_drop(v_n_241); r_; });
}
V g_heff_2eclauses_2eidents_lam2(V self, V *args) {
  V v_n_242 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eclauses_2eidents_get()); V a_1 = v_n_242; V r_ = (g_heff_2eclauses_2eidentsTypF(a_0, a_1)); heff_drop(v_n_242); r_; });
}
V g_heff_2eclauses_2eidents_lam3(V self, V *args) {
  V v_d_243 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eclauses_2eidents_get()); V a_1 = v_d_243; V r_ = (g_heff_2eclauses_2eidentsDeclF(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2eclauses_2econcatMapC_24s281_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s281_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s281(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_SetField: {
      V v_x_246 = heff_field(v_t_245, 0);
      V v_e_248 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 5ULL, 3);
      v_t_2410 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, (g_heff_2eclauses_2eidentsChkF_24s280(v_e_248))});
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_249 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2410 = (g_heff_2eclauses_2eidentsChkF_24s280(v_e_249));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411 = (g_heff_2eclauses_2econcatMapC_24s281(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s281_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2econcatMapC_24s281(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s282_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s282_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s282(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x21_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x21_243, 0);
        V v_b_246 = heff_field(v_x21_243, 1);
        V v_t_247 = (g_heff_2eclauses_2epatIdents(heff_dup(v_p_245)));
        V v_t_248 = (g_heff_2eclauses_2eidentsChkF_24s280(heff_dup(v_b_246)));
        v_t_249 = (g_heff_2eclauses_2eappendC(v_t_247, v_t_248));
        break;
      }
      default: heff_nomatch(v_x21_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410 = (g_heff_2eclauses_2econcatMapC_24s282(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s282_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s282(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s284_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s284_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s284(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x21_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_ArgExplicit: {
        V v_c_245 = heff_field(v_x21_243, 0);
        heff_take_n(v_x21_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_249 = (g_heff_2eclauses_2eidentsChkF_24s280(v_c_245));
        break;
      }
      case TAG_ArgProject: {
        heff_take_n(v_x21_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ArgNamed: {
        V v_x_247 = heff_field(v_x21_243, 0);
        V v_c_248 = heff_field(v_x21_243, 1);
        heff_take_n(v_x21_243, 3ULL, 2);
        v_t_249 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, (g_heff_2eclauses_2eidentsChkF_24s280(v_c_248))});
        break;
      }
      default: heff_nomatch(v_x21_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410 = (g_heff_2eclauses_2econcatMapC_24s284(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s284_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2econcatMapC_24s284(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s286_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s286_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s286(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2414;
    switch (heff_tag_of(v_t_245)) {
    case TAG_DeclareField: {
      V v_x_246 = heff_field(v_t_245, 0);
      V v_t_248 = heff_field(v_t_245, 2);
      V v_d_249 = heff_field(v_t_245, 3);
      heff_take_n(v_t_245, 13ULL, 4);
      V v_t_2410 = (g_heff_2eclauses_2eidentsTypF_24s285(v_t_248));
      V v_t_2412;
      switch (heff_tag_of(v_d_249)) {
      case TAG_Nothing: {
        v_t_2412 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_d_249, 0);
        heff_take_n(v_d_249, 1ULL, 1);
        v_t_2412 = (g_heff_2eclauses_2eidentsChkF_24s280(v_x_2411));
        break;
      }
      default: heff_nomatch(v_d_249);
      }
      v_t_2414 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, (g_heff_2eclauses_2eappendC(v_t_2410, v_t_2412))});
      break;
    }
    case TAG_BadFieldDecl: {
      V v_e_2413 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2414 = (g_heff_2eclauses_2eidentsTypF_24s285(v_e_2413));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2415 = (g_heff_2eclauses_2econcatMapC_24s286(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s286_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2econcatMapC_24s286(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s287_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s287_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s287(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_TagVariant: {
      V v_args_248 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 4ULL, 3);
      v_t_2410 = ({ V a_0 = heff_get(heff_dup(g_heff_2eclauses_2eidents_get()), LBL_typ); V a_1 = v_args_248; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_args_248); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_249 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      v_t_2410 = (g_heff_2eclauses_2eidentsTypF_24s285(v_e_249));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411 = (g_heff_2eclauses_2econcatMapC_24s287(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s287_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s287(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2eidentsTypF_24s285_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsTypF_24s285_entry, 1, 0};

V g_heff_2eclauses_2eidentsTypF_24s285(V v_n_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_TPi: {
    V v_b_244 = heff_field(v_t_243, 0);
    V v_cod_245 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24TPi = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_b_244)) {
    case TAG_PiNamed: {
      V v_x_246 = heff_field(v_b_244, 0);
      V v_t_248 = heff_field(v_b_244, 2);
      heff_take_n(v_b_244, 5ULL, 3);
      v_t_2418 = heff_tag_at(v_ru_24t_243_24TPi, TAG_Cons, 2, (V[]){v_x_246, (g_heff_2eclauses_2eidentsTypF_24s285(v_t_248))});
      break;
    }
    case TAG_PiImplicit: {
      V v_x_249 = heff_field(v_b_244, 0);
      V v_t_2412 = heff_field(v_b_244, 3);
      heff_take_n(v_b_244, 9ULL, 4);
      v_t_2418 = heff_tag_at(v_ru_24t_243_24TPi, TAG_Cons, 2, (V[]){v_x_249, (g_heff_2eclauses_2eidentsTypF_24s285(v_t_2412))});
      break;
    }
    case TAG_PiInstance: {
      V v_x_2413 = heff_field(v_b_244, 0);
      V v_t_2416 = heff_field(v_b_244, 3);
      heff_take_n(v_b_244, 9ULL, 4);
      v_t_2418 = heff_tag_at(v_ru_24t_243_24TPi, TAG_Cons, 2, (V[]){v_x_2413, (g_heff_2eclauses_2eidentsTypF_24s285(v_t_2416))});
      break;
    }
    case TAG_PiAnon: {
      V v_d_2417 = heff_field(v_b_244, 0);
      heff_take_n(v_b_244, 1ULL, 1);
      heff_drop_cell(v_ru_24t_243_24TPi, 2);
      v_t_2418 = (g_heff_2eclauses_2eidentsTypF_24s285(v_d_2417));
      break;
    }
    default: heff_nomatch(v_b_244);
    }
    V v_t_2419 = (g_heff_2eclauses_2eidentsTypF_24s285(v_cod_245));
    return (g_heff_2eclauses_2eappendC(v_t_2418, v_t_2419));
  }
  case TAG_TSig: {
    V v_fs_2420 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2econcatMapC_24s286(v_fs_2420);
  }
  case TAG_TSum: {
    V v_vs_2421 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return ({ V a_0 = v_vs_2421; V r_ = (g_heff_2eclauses_2econcatMapC_24s287(a_0)); heff_drop(v_vs_2421); r_; });
  }
  case TAG_TType: {
    return NTAG(TAG_Nil);
  }
  case TAG_TInt: {
    return NTAG(TAG_Nil);
  }
  case TAG_TFloat: {
    return NTAG(TAG_Nil);
  }
  case TAG_TString: {
    return NTAG(TAG_Nil);
  }
  case TAG_TArray: {
    V v_a_2422 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V t_0 = v_a_2422;
    v_n_240 = t_0;
    goto top;
  }
  case TAG_TInf: {
    V v_i_2423 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2eidentsInfF_24s283(v_i_2423);
  }
  case TAG_TChk: {
    V v_c_2424 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2eidentsChkF_24s280(v_c_2424);
  }
  case TAG_TNominal: {
    V v_t_2425 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V t_0 = v_t_2425;
    v_n_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2eidentsTypF_24s285_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eidentsTypF_24s285(a[0]);
}
Clo g_heff_2eclauses_2eidentsInfF_24s283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsInfF_24s283_entry, 1, 0};

V g_heff_2eclauses_2eidentsInfF_24s283(V v_n_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_IVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
  }
  case TAG_IInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_IFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_IString: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_IApp: {
    V v_h_248 = heff_field(v_t_243, 0);
    V v_args_249 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_t_2410 = (g_heff_2eclauses_2eidentsInfF_24s283(v_h_248));
    V v_t_2411 = (g_heff_2eclauses_2econcatMapC_24s284(v_args_249));
    return (g_heff_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  case TAG_IAnn: {
    V v_c_2412 = heff_field(v_t_243, 0);
    V v_t_2413 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_t_2414 = (g_heff_2eclauses_2eidentsChkF_24s280(v_c_2412));
    V v_t_2415 = (g_heff_2eclauses_2eidentsTypF_24s285(v_t_2413));
    return (g_heff_2eclauses_2eappendC(v_t_2414, v_t_2415));
  }
  case TAG_ISpec: {
    V v_a_2416 = heff_field(v_t_243, 0);
    V v_v_2419 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 9ULL, 4);
    V v_t_2420 = (g_heff_2eclauses_2eidentsInfF_24s283(v_a_2416));
    V v_t_2421 = (g_heff_2eclauses_2eidentsChkF_24s280(v_v_2419));
    return (g_heff_2eclauses_2eappendC(v_t_2420, v_t_2421));
  }
  case TAG_IAnnLam: {
    V v_x_2422 = heff_field(v_t_243, 0);
    V v_t_2424 = heff_field(v_t_243, 2);
    V v_b_2425 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    V v_t_2426 = (g_heff_2eclauses_2eidentsTypF_24s285(v_t_2424));
    V v_t_2427 = (g_heff_2eclauses_2eidentsInfF_24s283(v_b_2425));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2422, (g_heff_2eclauses_2eappendC(v_t_2426, v_t_2427))});
  }
  case TAG_IInvalid: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_INominal: {
    V v_i_2430 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V t_0 = v_i_2430;
    v_n_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2eidentsInfF_24s283_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eidentsInfF_24s283(a[0]);
}
Clo g_heff_2eclauses_2eidentsChkF_24s280_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eidentsChkF_24s280_entry, 1, 0};

V g_heff_2eclauses_2eidentsChkF_24s280(V v_n_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_CInf: {
    V v_i_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2eidentsInfF_24s283(v_i_244);
  }
  case TAG_CType: {
    V v_t_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2eidentsTypF_24s285(v_t_245);
  }
  case TAG_CLam: {
    V v_x_246 = heff_field(v_t_243, 0);
    V v_b_248 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_246, (g_heff_2eclauses_2eidentsChkF_24s280(v_b_248))});
  }
  case TAG_CImplicitLam: {
    V v_x_249 = heff_field(v_t_243, 0);
    V v_b_2411 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_249, (g_heff_2eclauses_2eidentsChkF_24s280(v_b_2411))});
  }
  case TAG_CAnnLam: {
    V v_x_2412 = heff_field(v_t_243, 0);
    V v_t_2414 = heff_field(v_t_243, 2);
    V v_b_2415 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    V v_t_2416 = (g_heff_2eclauses_2eidentsTypF_24s285(v_t_2414));
    V v_t_2417 = (g_heff_2eclauses_2eidentsChkF_24s280(v_b_2415));
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2412, (g_heff_2eclauses_2eappendC(v_t_2416, v_t_2417))});
  }
  case TAG_CTag: {
    V v_args_2420 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    return ({ V a_0 = heff_get(heff_dup(g_heff_2eclauses_2eidents_get()), LBL_chk); V a_1 = v_args_2420; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_args_2420); r_; });
  }
  case TAG_CStruct: {
    V v_fs_2421 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HEFF_LAST return g_heff_2eclauses_2econcatMapC_24s281(v_fs_2421);
  }
  case TAG_CMatch: {
    V v_s_2422 = heff_field(v_t_243, 0);
    V v_alts_2423 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_t_2424 = (g_heff_2eclauses_2eidentsInfF_24s283(v_s_2422));
    V v_t_2425 = ({ V a_0 = v_alts_2423; V r_ = (g_heff_2eclauses_2econcatMapC_24s282(a_0)); heff_drop(v_alts_2423); r_; });
    return (g_heff_2eclauses_2eappendC(v_t_2424, v_t_2425));
  }
  case TAG_CLetIn: {
    V v_rhs_2426 = heff_field(v_t_243, 0);
    V v_a_2427 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_t_2428 = (g_heff_2eclauses_2eidentsInfF_24s283(v_rhs_2426));
    V v_t_2435;
    switch (heff_tag_of(v_a_2427)) {
    case TAG_At: {
      V v_x21_2429 = heff_field(v_a_2427, 0);
      heff_take_n(v_a_2427, 1ULL, 2);
      switch (heff_tag_of(v_x21_2429)) {
      case TAG_MkAlt: {
        V v_p_2431 = heff_field(v_x21_2429, 0);
        V v_b_2432 = heff_field(v_x21_2429, 1);
        heff_take_n(v_x21_2429, 3ULL, 2);
        V v_t_2433 = (g_heff_2eclauses_2epatIdents(v_p_2431));
        V v_t_2434 = (g_heff_2eclauses_2eidentsChkF_24s280(v_b_2432));
        v_t_2435 = (g_heff_2eclauses_2eappendC(v_t_2433, v_t_2434));
        break;
      }
      default: heff_nomatch(v_x21_2429);
      }
      break;
    }
    default: heff_nomatch(v_a_2427);
    }
    return (g_heff_2eclauses_2eappendC(v_t_2428, v_t_2435));
  }
  case TAG_CLocal: {
    V v_body_2436 = heff_field(v_t_243, 0);
    V v_ds_2437 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_t_2438 = (g_heff_2eclauses_2eidentsChkF_24s280(v_body_2436));
    V v_t_2439 = ({ V a_0 = heff_get(heff_dup(g_heff_2eclauses_2eidents_get()), LBL_decl); V a_1 = v_ds_2437; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_ds_2437); r_; });
    return (g_heff_2eclauses_2eappendC(v_t_2438, v_t_2439));
  }
  case TAG_CAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_CNominal: {
    V v_c_2440 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V t_0 = v_c_2440;
    v_n_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2eidentsChkF_24s280_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eidentsChkF_24s280(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2efresh_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
Clo g_heff_2eclauses_2efresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2efresh_entry, 2, 0};

V g_heff_2eclauses_2efresh(V v_used_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
  V v_t_243 = (g_prelude_2eany(v_t_242, v_used_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V t_0 = v_used_240;
    V t_1 = heff_strAppend(v_x_241, ((V)&g_heff_2eclauses_2efresh_str0));
    v_used_240 = t_0;
    v_x_241 = t_1;
    goto top;
  }
  case TAG_False: {
    return v_x_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2efresh_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2efresh(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s288_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s288(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eclauses_2epatBinds(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eclauses_2econcatMapC_24s288(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s288_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s288(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s289_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s289_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s289(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_q_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2eclauses_2epatBinds(heff_dup(v_q_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eclauses_2econcatMapC_24s289(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s289_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s289(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2epatBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epatBinds_entry, 1, 0};

V g_heff_2eclauses_2epatBinds(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
  }
  case TAG_PatTag: {
    V v_ps_247 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    return ({ V a_0 = v_ps_247; V r_ = (g_heff_2eclauses_2econcatMapC_24s288(a_0)); heff_drop(v_ps_247); r_; });
  }
  case TAG_PatOp: {
    V v_ps_2410 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    return ({ V a_0 = v_ps_2410; V r_ = (g_heff_2eclauses_2econcatMapC_24s288(a_0)); heff_drop(v_ps_2410); r_; });
  }
  case TAG_PatInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatString: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatRecord: {
    V v_fs_2414 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2eclauses_2econcatMapC_24s289(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_PatWord: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PatAs: {
    V v_x_2416 = heff_field(v_t_243, 0);
    V v_q_2418 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    return heff_tag(TAG_Cons, 2, (V[]){v_x_2416, (g_heff_2eclauses_2epatBinds(v_q_2418))});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2epatBinds_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epatBinds(a[0]);
}
Clo g_heff_2eclauses_2erenameSeq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameSeq_entry, 3, 0};

V g_heff_2eclauses_2erenameSeq(V v_f_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = heff_tr(heff_apply(heff_dup(v_b_241), 1, (V[]){v_m_243}));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_f_240);
      heff_drop(v_b_241);
      v_t_247 = v_rest_244;
      break;
    }
    case TAG_False: {
      v_t_247 = (g_heff_2eclauses_2erenameSeq(v_f_240, v_b_241, v_rest_244));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eclauses_2erenameSeq_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameSeq(a[0], a[1], a[2]);
}
Clo g_heff_2eclauses_2erenameAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameAlt_entry, 2, 0};

V g_heff_2eclauses_2erenameAlt(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_xs_246 = (g_heff_2eclauses_2epatBinds(heff_dup(v_p_244)));
      V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_r_240), LBL_x)}));
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_244, v_b_245}), v_sp_243});
      }
      case TAG_False: {
        V v_t_249 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_245}));
        return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_244, v_t_249}), v_sp_243});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2erenameAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameAlt(a[0], a[1]);
}
Clo g_heff_2eclauses_2erenameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameField_entry, 2, 0};

V g_heff_2eclauses_2erenameField(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_ysp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_246}));
      V v_t_2411;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop(v_r_240);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_c_249 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_249}));
        v_t_2411 = heff_tag_at(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_DeclareField, 4, (V[]){v_y_244, v_ysp_245, v_t_248, v_t_2411}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_e_2412}));
      return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_BadFieldDecl, 1, (V[]){v_t_2413}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2erenameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameField(a[0], a[1]);
}
V g_heff_2eclauses_2erenameEquation_lam0(V self, V *args);
Clo g_heff_2eclauses_2erenameEquation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameEquation_entry, 2, 0};

V g_heff_2eclauses_2erenameEquation(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_2411 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2erenameEquation_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_ps_246));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_r_240);
        return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_rhs_247}), v_sp_243});
      }
      case TAG_False: {
        V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_rhs_247}));
        return heff_tag_at(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2412}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2erenameEquation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameEquation(a[0], a[1]);
}
V g_heff_2eclauses_2erenameEquation_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2eclauses_2epatBinds(v_p_248));
  V v_t_2410 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_r_240, LBL_x)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
V g_heff_2eclauses_2erenameDecl_lam0(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam1(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam2(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam3(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam4(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam5(V self, V *args);
V g_heff_2eclauses_2erenameDecl_lam6(V self, V *args);
Clo g_heff_2eclauses_2erenameDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameDecl_entry, 2, 0};

V g_heff_2eclauses_2erenameDecl(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_d_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_d_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_it1_242, 0);
      V v_fsp_245 = heff_field(v_it1_242, 1);
      V v_ty_246 = heff_field(v_it1_242, 2);
      V v_eqs_247 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24DeclEquations = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      heff_drop_tag(v_d_241, 2);
      V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_ty_246}));
      V v_t_249 = heff_strEq(heff_get(heff_dup(v_r_240), LBL_x), heff_dup(v_f_244));
      V v_t_2411;
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_r_240);
        v_t_2411 = v_eqs_247;
        break;
      }
      case TAG_False: {
        V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eclauses_2erenameEquation_clo), 1, (V[]){v_r_240}));
        v_t_2411 = (g_prelude_2emap(v_t_2410, v_eqs_247));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_244, v_fsp_245, v_t_248, v_t_2411}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_y_2412 = heff_field(v_it1_242, 0);
      V v_ysp_2413 = heff_field(v_it1_242, 1);
      V v_ps_2414 = heff_field(v_it1_242, 2);
      V v_u_2415 = heff_field(v_it1_242, 3);
      V v_body_2416 = heff_field(v_it1_242, 4);
      V v_ru_24it1_242_24DeclDefine = heff_take_reuse_n(v_it1_242, 31ULL, 5);
      V v_t_2417 = heff_strEq(heff_get(heff_dup(v_r_240), LBL_x), heff_dup(v_y_2412));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        heff_drop(v_y_2412);
        heff_drop(v_ysp_2413);
        heff_drop(v_ps_2414);
        heff_drop(v_u_2415);
        heff_drop(v_body_2416);
        heff_drop_cell(v_ru_24it1_242_24DeclDefine, 5);
        return v_d_241;
      }
      case TAG_False: {
        heff_drop_tag(v_d_241, 2);
        V v_x_2418 = heff_get(heff_dup(v_r_240), LBL_x);
        V v_t_2439 = (g_heff_2eclauses_2erenameSeq(heff_clo(g_heff_2eclauses_2erenameDecl_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo(g_heff_2eclauses_2erenameDecl_lam1, 1, 1, (V[]){v_x_2418}), heff_dup(v_ps_2414)));
        V v_x_2440 = heff_get(heff_dup(v_r_240), LBL_x);
        V v_t_2450 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2erenameDecl_lam2, 1, 1, (V[]){v_x_2440}), v_ps_2414));
        V v_t_2451;
        switch (heff_tag_of(v_t_2450)) {
        case TAG_True: {
          v_t_2451 = v_u_2415;
          break;
        }
        case TAG_False: {
          v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_u_2415}));
          break;
        }
        default: heff_nomatch(v_t_2450);
        }
        V v_x_2452 = heff_get(heff_dup(v_r_240), LBL_x);
        V v_t_2462 = ({ V a_0 = heff_clo(g_heff_2eclauses_2erenameDecl_lam3, 1, 1, (V[]){v_x_2452}); V a_1 = v_ps_2414; V r_ = (g_heff_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2414); r_; });
        V v_t_2463;
        switch (heff_tag_of(v_t_2462)) {
        case TAG_True: {
          heff_drop(v_r_240);
          v_t_2463 = v_body_2416;
          break;
        }
        case TAG_False: {
          v_t_2463 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_body_2416}));
          break;
        }
        default: heff_nomatch(v_t_2462);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_y_2412, v_ysp_2413, v_t_2439, v_t_2451, v_t_2463}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    case TAG_DeclTheory: {
      V v_y_2464 = heff_field(v_it1_242, 0);
      V v_ysp_2465 = heff_field(v_it1_242, 1);
      V v_ps_2466 = heff_field(v_it1_242, 2);
      V v_body_2467 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24DeclTheory = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      V v_t_2468 = heff_strEq(heff_get(heff_dup(v_r_240), LBL_x), heff_dup(v_y_2464));
      switch (heff_tag_of(v_t_2468)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        heff_drop(v_y_2464);
        heff_drop(v_ysp_2465);
        heff_drop(v_ps_2466);
        heff_drop(v_body_2467);
        heff_drop_cell(v_ru_24it1_242_24DeclTheory, 4);
        return v_d_241;
      }
      case TAG_False: {
        heff_drop_tag(v_d_241, 2);
        V v_x_2469 = heff_get(heff_dup(v_r_240), LBL_x);
        V v_t_2490 = (g_heff_2eclauses_2erenameSeq(heff_clo(g_heff_2eclauses_2erenameDecl_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo(g_heff_2eclauses_2erenameDecl_lam5, 1, 1, (V[]){v_x_2469}), heff_dup(v_ps_2466)));
        V v_x_2491 = heff_get(heff_dup(v_r_240), LBL_x);
        V v_t_24101 = ({ V a_0 = heff_clo(g_heff_2eclauses_2erenameDecl_lam6, 1, 1, (V[]){v_x_2491}); V a_1 = v_ps_2466; V r_ = (g_heff_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2466); r_; });
        V v_t_24102;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_True: {
          heff_drop(v_r_240);
          v_t_24102 = v_body_2467;
          break;
        }
        case TAG_False: {
          v_t_24102 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_body_2467}));
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_y_2464, v_ysp_2465, v_t_2490, v_t_24102}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2468);
      }
    }
    case TAG_DeclPrimitive: {
      V v_y_24103 = heff_field(v_it1_242, 0);
      V v_ysp_24104 = heff_field(v_it1_242, 1);
      V v_t_24105 = heff_field(v_it1_242, 2);
      V v_ru_24it1_242_24DeclPrimitive = heff_take_reuse_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_d_241, 2);
      V v_t_24106 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_24105}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_y_24103, v_ysp_24104, v_t_24106}), v_sp_243});
    }
    case TAG_DeclTest: {
      heff_take_n(v_it1_242, 0ULL, 2);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_d_241;
    }
    case TAG_DeclWatch: {
      V v_e_24109 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24DeclWatch = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_d_241, 2);
      V v_t_24110 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_e_24109}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_24110}), v_sp_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eclauses_2erenameDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameDecl(a[0], a[1]);
}
V g_heff_2eclauses_2erenameDecl_lam0(V self, V *args) {
  V v_x2_2419 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_At: {
    V v_x21_2420 = heff_field(v_x2_2419, 0);
    V v_sp_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24At = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    switch (heff_tag_of(v_x21_2420)) {
    case TAG_ExplicitParam: {
      V v_y_2422 = heff_field(v_x21_2420, 0);
      V v_ysp_2423 = heff_field(v_x21_2420, 1);
      V v_t_2424 = heff_field(v_x21_2420, 2);
      heff_take_n(v_x21_2420, 7ULL, 3);
      V v_t_2425 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2424}));
      return heff_tag_at(v_ru_24x2_2419_24At, TAG_At, 2, (V[]){heff_tag(TAG_ExplicitParam, 3, (V[]){v_y_2422, v_ysp_2423, v_t_2425}), v_sp_2421});
    }
    case TAG_ImplicitParam: {
      V v_y_2426 = heff_field(v_x21_2420, 0);
      V v_ysp_2427 = heff_field(v_x21_2420, 1);
      V v_t_2428 = heff_field(v_x21_2420, 2);
      heff_take_n(v_x21_2420, 7ULL, 3);
      V v_t_2429 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2428}));
      return heff_tag_at(v_ru_24x2_2419_24At, TAG_At, 2, (V[]){heff_tag(TAG_ImplicitParam, 3, (V[]){v_y_2426, v_ysp_2427, v_t_2429}), v_sp_2421});
    }
    default: return heff_nomatch(v_x21_2420);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2eclauses_2erenameDecl_lam1(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_x2_2430, 0);
    heff_take_n(v_x2_2430, 1ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_ExplicitParam: {
      V v_y_2433 = heff_field(v_x21_2431, 0);
      heff_take_n(v_x21_2431, 1ULL, 3);
      return heff_strEq(v_x_2418, v_y_2433);
    }
    case TAG_ImplicitParam: {
      V v_y_2436 = heff_field(v_x21_2431, 0);
      heff_take_n(v_x21_2431, 1ULL, 3);
      return heff_strEq(v_x_2418, v_y_2436);
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eclauses_2erenameDecl_lam2(V self, V *args) {
  V v_x2_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_At: {
    V v_x21_2442 = heff_field(v_x2_2441, 0);
    heff_take_n(v_x2_2441, 1ULL, 2);
    switch (heff_tag_of(v_x21_2442)) {
    case TAG_ExplicitParam: {
      V v_y_2444 = heff_field(v_x21_2442, 0);
      heff_take_n(v_x21_2442, 1ULL, 3);
      return heff_strEq(v_x_2440, v_y_2444);
    }
    case TAG_ImplicitParam: {
      V v_y_2447 = heff_field(v_x21_2442, 0);
      heff_take_n(v_x21_2442, 1ULL, 3);
      return heff_strEq(v_x_2440, v_y_2447);
    }
    default: return heff_nomatch(v_x21_2442);
    }
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2eclauses_2erenameDecl_lam3(V self, V *args) {
  V v_x2_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_At: {
    V v_x21_2454 = heff_field(v_x2_2453, 0);
    heff_take_n(v_x2_2453, 1ULL, 2);
    switch (heff_tag_of(v_x21_2454)) {
    case TAG_ExplicitParam: {
      V v_y_2456 = heff_field(v_x21_2454, 0);
      heff_take_n(v_x21_2454, 1ULL, 3);
      return heff_strEq(v_x_2452, v_y_2456);
    }
    case TAG_ImplicitParam: {
      V v_y_2459 = heff_field(v_x21_2454, 0);
      heff_take_n(v_x21_2454, 1ULL, 3);
      return heff_strEq(v_x_2452, v_y_2459);
    }
    default: return heff_nomatch(v_x21_2454);
    }
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2eclauses_2erenameDecl_lam4(V self, V *args) {
  V v_x2_2470 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_At: {
    V v_x21_2471 = heff_field(v_x2_2470, 0);
    V v_sp_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24At = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    switch (heff_tag_of(v_x21_2471)) {
    case TAG_ExplicitParam: {
      V v_y_2473 = heff_field(v_x21_2471, 0);
      V v_ysp_2474 = heff_field(v_x21_2471, 1);
      V v_t_2475 = heff_field(v_x21_2471, 2);
      heff_take_n(v_x21_2471, 7ULL, 3);
      V v_t_2476 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2475}));
      return heff_tag_at(v_ru_24x2_2470_24At, TAG_At, 2, (V[]){heff_tag(TAG_ExplicitParam, 3, (V[]){v_y_2473, v_ysp_2474, v_t_2476}), v_sp_2472});
    }
    case TAG_ImplicitParam: {
      V v_y_2477 = heff_field(v_x21_2471, 0);
      V v_ysp_2478 = heff_field(v_x21_2471, 1);
      V v_t_2479 = heff_field(v_x21_2471, 2);
      heff_take_n(v_x21_2471, 7ULL, 3);
      V v_t_2480 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2479}));
      return heff_tag_at(v_ru_24x2_2470_24At, TAG_At, 2, (V[]){heff_tag(TAG_ImplicitParam, 3, (V[]){v_y_2477, v_ysp_2478, v_t_2480}), v_sp_2472});
    }
    default: return heff_nomatch(v_x21_2471);
    }
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2eclauses_2erenameDecl_lam5(V self, V *args) {
  V v_x2_2481 = args[0];
  V v_x_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_At: {
    V v_x21_2482 = heff_field(v_x2_2481, 0);
    heff_take_n(v_x2_2481, 1ULL, 2);
    switch (heff_tag_of(v_x21_2482)) {
    case TAG_ExplicitParam: {
      V v_y_2484 = heff_field(v_x21_2482, 0);
      heff_take_n(v_x21_2482, 1ULL, 3);
      return heff_strEq(v_x_2469, v_y_2484);
    }
    case TAG_ImplicitParam: {
      V v_y_2487 = heff_field(v_x21_2482, 0);
      heff_take_n(v_x21_2482, 1ULL, 3);
      return heff_strEq(v_x_2469, v_y_2487);
    }
    default: return heff_nomatch(v_x21_2482);
    }
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2eclauses_2erenameDecl_lam6(V self, V *args) {
  V v_x2_2492 = args[0];
  V v_x_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_At: {
    V v_x21_2493 = heff_field(v_x2_2492, 0);
    heff_take_n(v_x2_2492, 1ULL, 2);
    switch (heff_tag_of(v_x21_2493)) {
    case TAG_ExplicitParam: {
      V v_y_2495 = heff_field(v_x21_2493, 0);
      heff_take_n(v_x21_2493, 1ULL, 3);
      return heff_strEq(v_x_2491, v_y_2495);
    }
    case TAG_ImplicitParam: {
      V v_y_2498 = heff_field(v_x21_2493, 0);
      heff_take_n(v_x21_2493, 1ULL, 3);
      return heff_strEq(v_x_2491, v_y_2498);
    }
    default: return heff_nomatch(v_x21_2493);
    }
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
Clo g_heff_2eclauses_2erenamePi_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenamePi_entry, 2, 0};

V g_heff_2eclauses_2erenamePi(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ysp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_244}));
    return heff_tag_at(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_y_242, v_ysp_243, v_t_245});
  }
  case TAG_PiImplicit: {
    V v_y_246 = heff_field(v_x2_241, 0);
    V v_ysp_247 = heff_field(v_x2_241, 1);
    V v_bsp_248 = heff_field(v_x2_241, 2);
    V v_t_249 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_249}));
    return heff_tag_at(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 4, (V[]){v_y_246, v_ysp_247, v_bsp_248, v_t_2410});
  }
  case TAG_PiInstance: {
    V v_y_2411 = heff_field(v_x2_241, 0);
    V v_ysp_2412 = heff_field(v_x2_241, 1);
    V v_bsp_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2414}));
    return heff_tag_at(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_y_2411, v_ysp_2412, v_bsp_2413, v_t_2415});
  }
  case TAG_PiAnon: {
    V v_d_2416 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_d_2416}));
    return heff_tag_at(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2erenamePi_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenamePi(a[0], a[1]);
}
V g_heff_2eclauses_2erenameInfF_lam0(V self, V *args);
Clo g_heff_2eclauses_2erenameInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameInfF_entry, 2, 0};

V g_heff_2eclauses_2erenameInfF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_IVar: {
      V v_y_244 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24IVar = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      V v_t_245 = heff_strEq(v_y_244, heff_get(heff_dup(v_r_240), LBL_x));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop_tag(v_n_241, 2);
        V v_t_246 = heff_tag_at(v_ru_24it1_242_24IVar, TAG_IVar, 1, (V[]){heff_get(v_r_240, LBL_v)});
        return heff_tag(TAG_At, 2, (V[]){v_t_246, v_sp_243});
      }
      case TAG_False: {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24it1_242_24IVar, 1);
        return v_n_241;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_IInt: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IFloat: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IString: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_it1_242, 0);
      V v_args_2411 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24IApp = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_h_2410}));
      V v_t_2422 = heff_tag_at(v_ru_24it1_242_24IApp, TAG_IApp, 2, (V[]){v_t_2412, (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erenameInfF_lam0, 1, 1, (V[]){v_r_240}), v_args_2411))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2422, v_sp_243});
    }
    case TAG_IAnn: {
      V v_c_2423 = heff_field(v_it1_242, 0);
      V v_t_2424 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24IAnn = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_chk), 1, (V[]){v_c_2423}));
      V v_t_2426 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2424}));
      return heff_tag_at(v_ru_24it1_242_24IAnn, TAG_At, 2, (V[]){heff_tag(TAG_IAnn, 2, (V[]){v_t_2425, v_t_2426}), v_sp_243});
    }
    case TAG_ISpec: {
      V v_a_2427 = heff_field(v_it1_242, 0);
      V v_f_2428 = heff_field(v_it1_242, 1);
      V v_fsp_2429 = heff_field(v_it1_242, 2);
      V v_val_2430 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24ISpec = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_a_2427}));
      V v_t_2432 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_val_2430}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24ISpec, TAG_ISpec, 4, (V[]){v_t_2431, v_f_2428, v_fsp_2429, v_t_2432}), v_sp_243});
    }
    case TAG_IAnnLam: {
      V v_y_2433 = heff_field(v_it1_242, 0);
      V v_ysp_2434 = heff_field(v_it1_242, 1);
      V v_t_2435 = heff_field(v_it1_242, 2);
      V v_b_2436 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24IAnnLam = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2435}));
      V v_t_2438 = heff_strEq(heff_dup(v_y_2433), heff_get(heff_dup(v_r_240), LBL_x));
      V v_t_2439;
      switch (heff_tag_of(v_t_2438)) {
      case TAG_True: {
        heff_drop(v_r_240);
        v_t_2439 = v_b_2436;
        break;
      }
      case TAG_False: {
        v_t_2439 = heff_tr(heff_apply(heff_get(v_r_240, LBL_inf), 1, (V[]){v_b_2436}));
        break;
      }
      default: heff_nomatch(v_t_2438);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_y_2433, v_ysp_2434, v_t_2437, v_t_2439}), v_sp_243});
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_242, 0ULL, 2);
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_INominal: {
      V v_i_2442 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24INominal = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2443 = heff_tr(heff_apply(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_2442}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24INominal, TAG_INominal, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eclauses_2erenameInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameInfF(a[0], a[1]);
}
V g_heff_2eclauses_2erenameInfF_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2413)) {
  case TAG_At: {
    V v_a1_2414 = heff_dup(heff_field(v_a_2413, 0));
    V v_sp_2415 = heff_dup(heff_field(v_a_2413, 1));
    switch (heff_tag_of(v_a1_2414)) {
    case TAG_ArgExplicit: {
      V v_c_2416 = heff_field(v_a1_2414, 0);
      V v_ru_24a1_2414_24ArgExplicit = heff_take_reuse_n(v_a1_2414, 1ULL, 1);
      heff_drop_tag(v_a_2413, 2);
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2416}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24a1_2414_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2417}), v_sp_2415});
    }
    case TAG_ArgProject: {
      heff_take_n(v_a1_2414, 0ULL, 1);
      heff_drop(v_r_240);
      heff_drop(v_sp_2415);
      return v_a_2413;
    }
    case TAG_ArgNamed: {
      V v_y_2419 = heff_field(v_a1_2414, 0);
      V v_c_2420 = heff_field(v_a1_2414, 1);
      V v_ru_24a1_2414_24ArgNamed = heff_take_reuse_n(v_a1_2414, 3ULL, 2);
      heff_drop_tag(v_a_2413, 2);
      V v_t_2421 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2420}));
      return heff_tag_at(v_ru_24a1_2414_24ArgNamed, TAG_At, 2, (V[]){heff_tag(TAG_ArgNamed, 2, (V[]){v_y_2419, v_t_2421}), v_sp_2415});
    }
    default: return heff_nomatch(v_a1_2414);
    }
  }
  default: return heff_nomatch(v_a_2413);
  }
}
V g_heff_2eclauses_2erenameChkF_lam0(V self, V *args);
V g_heff_2eclauses_2erenameChkF_lam1(V self, V *args);
V g_heff_2eclauses_2erenameChkF_lam2(V self, V *args);
Clo g_heff_2eclauses_2erenameChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameChkF_entry, 2, 0};

V g_heff_2eclauses_2erenameChkF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24CInf = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_244}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_243});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24CType = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_246}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CType, TAG_CType, 1, (V[]){v_t_247}), v_sp_243});
    }
    case TAG_CLam: {
      V v_y_248 = heff_field(v_it1_242, 0);
      V v_ysp_249 = heff_field(v_it1_242, 1);
      V v_b_2410 = heff_field(v_it1_242, 2);
      V v_ru_24it1_242_24CLam = heff_take_reuse_n(v_it1_242, 7ULL, 3);
      V v_t_2411 = heff_strEq(heff_dup(v_y_248), heff_get(heff_dup(v_r_240), LBL_x));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        heff_drop(v_y_248);
        heff_drop(v_ysp_249);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24it1_242_24CLam, 3);
        return v_n_241;
      }
      case TAG_False: {
        heff_drop_tag(v_n_241, 2);
        V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2410}));
        return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CLam, TAG_CLam, 3, (V[]){v_y_248, v_ysp_249, v_t_2412}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_CImplicitLam: {
      V v_y_2413 = heff_field(v_it1_242, 0);
      V v_ysp_2414 = heff_field(v_it1_242, 1);
      V v_b_2415 = heff_field(v_it1_242, 2);
      V v_ru_24it1_242_24CImplicitLam = heff_take_reuse_n(v_it1_242, 7ULL, 3);
      V v_t_2416 = heff_strEq(heff_dup(v_y_2413), heff_get(heff_dup(v_r_240), LBL_x));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_b_2415);
        heff_drop_cell(v_ru_24it1_242_24CImplicitLam, 3);
        return v_n_241;
      }
      case TAG_False: {
        heff_drop_tag(v_n_241, 2);
        V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2415}));
        return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_y_2413, v_ysp_2414, v_t_2417}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_CAnnLam: {
      V v_y_2418 = heff_field(v_it1_242, 0);
      V v_ysp_2419 = heff_field(v_it1_242, 1);
      V v_t_2420 = heff_field(v_it1_242, 2);
      V v_b_2421 = heff_field(v_it1_242, 3);
      V v_ru_24it1_242_24CAnnLam = heff_take_reuse_n(v_it1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_typ), 1, (V[]){v_t_2420}));
      V v_t_2423 = heff_strEq(heff_dup(v_y_2418), heff_get(heff_dup(v_r_240), LBL_x));
      V v_t_2424;
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        heff_drop(v_r_240);
        v_t_2424 = v_b_2421;
        break;
      }
      case TAG_False: {
        v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_b_2421}));
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_y_2418, v_ysp_2419, v_t_2422, v_t_2424}), v_sp_243});
    }
    case TAG_CTag: {
      V v_t_2425 = heff_field(v_it1_242, 0);
      V v_tsp_2426 = heff_field(v_it1_242, 1);
      V v_args_2427 = heff_field(v_it1_242, 2);
      V v_ru_24it1_242_24CTag = heff_take_reuse_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_n_241, 2);
      V v_t_2428 = heff_tag_at(v_ru_24it1_242_24CTag, TAG_CTag, 3, (V[]){v_t_2425, v_tsp_2426, (g_prelude_2emap(heff_get(v_r_240, LBL_chk), v_args_2427))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2428, v_sp_243});
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24CStruct = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2439 = heff_tag_at(v_ru_24it1_242_24CStruct, TAG_CStruct, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2eclauses_2erenameChkF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2429))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2439, v_sp_243});
    }
    case TAG_CMatch: {
      V v_s_2440 = heff_field(v_it1_242, 0);
      V v_alts_2441 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24CMatch = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_s_2440}));
      V v_t_2443 = heff_tr(heff_apply(((V)&g_heff_2eclauses_2erenameAlt_clo), 1, (V[]){v_r_240}));
      V v_t_2444 = heff_tag_at(v_ru_24it1_242_24CMatch, TAG_CMatch, 2, (V[]){v_t_2442, (g_prelude_2emap(v_t_2443, v_alts_2441))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2444, v_sp_243});
    }
    case TAG_CLetIn: {
      V v_rhs_2445 = heff_field(v_it1_242, 0);
      V v_a_2446 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24CLetIn = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_inf), 1, (V[]){v_rhs_2445}));
      V v_t_2448 = heff_tag_at(v_ru_24it1_242_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2447, (g_heff_2eclauses_2erenameAlt(v_r_240, v_a_2446))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2448, v_sp_243});
    }
    case TAG_CLocal: {
      V v_body_2449 = heff_field(v_it1_242, 0);
      V v_ds_2450 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24CLocal = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_x_2451 = heff_get(heff_dup(v_r_240), LBL_x);
      V v_t_2475 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2erenameChkF_lam1, 1, 1, (V[]){v_x_2451}), v_ds_2450));
      V v_t_2476;
      switch (heff_tag_of(v_t_2475)) {
      case TAG_True: {
        v_t_2476 = v_body_2449;
        break;
      }
      case TAG_False: {
        v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_chk), 1, (V[]){v_body_2449}));
        break;
      }
      default: heff_nomatch(v_t_2475);
      }
      V v_t_2477 = heff_tr(heff_apply(((V)&g_heff_2eclauses_2erenameDecl_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_x_2478 = heff_get(v_r_240, LBL_x);
      V v_t_24102 = heff_tag_at(v_ru_24it1_242_24CLocal, TAG_CLocal, 2, (V[]){v_t_2476, (g_heff_2eclauses_2erenameSeq(v_t_2477, heff_clo(g_heff_2eclauses_2erenameChkF_lam2, 1, 1, (V[]){v_x_2478}), v_ds_2450))});
      return heff_tag(TAG_At, 2, (V[]){v_t_24102, v_sp_243});
    }
    case TAG_CAbandon: {
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_CNominal: {
      V v_c_24103 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24CNominal = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_24104 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_24103}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24CNominal, TAG_CNominal, 1, (V[]){v_t_24104}), v_sp_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eclauses_2erenameChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameChkF(a[0], a[1]);
}
V g_heff_2eclauses_2erenameChkF_lam0(V self, V *args) {
  V v_f_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_2430)) {
  case TAG_At: {
    V v_it1_2431 = heff_field(v_f_2430, 0);
    V v_fsp_2432 = heff_field(v_f_2430, 1);
    V v_ru_24f_2430_24At = heff_take_reuse_n(v_f_2430, 3ULL, 2);
    switch (heff_tag_of(v_it1_2431)) {
    case TAG_SetField: {
      V v_y_2433 = heff_field(v_it1_2431, 0);
      V v_ysp_2434 = heff_field(v_it1_2431, 1);
      V v_e_2435 = heff_field(v_it1_2431, 2);
      heff_take_n(v_it1_2431, 7ULL, 3);
      V v_t_2436 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_e_2435}));
      return heff_tag_at(v_ru_24f_2430_24At, TAG_At, 2, (V[]){heff_tag(TAG_SetField, 3, (V[]){v_y_2433, v_ysp_2434, v_t_2436}), v_fsp_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2437 = heff_field(v_it1_2431, 0);
      heff_take_n(v_it1_2431, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_e_2437}));
      return heff_tag_at(v_ru_24f_2430_24At, TAG_At, 2, (V[]){heff_tag(TAG_BadFieldSet, 1, (V[]){v_t_2438}), v_fsp_2432});
    }
    default: return heff_nomatch(v_it1_2431);
    }
  }
  default: return heff_nomatch(v_f_2430);
  }
}
V g_heff_2eclauses_2erenameChkF_lam1(V self, V *args) {
  V v_d_2452 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455;
  switch (heff_tag_of(v_d_2452)) {
  case TAG_At: {
    V v_x_2453 = heff_field(v_d_2452, 0);
    heff_take_n(v_d_2452, 1ULL, 2);
    v_t_2455 = v_x_2453;
    break;
  }
  default: heff_nomatch(v_d_2452);
  }
  switch (heff_tag_of(v_t_2455)) {
  case TAG_DeclEquations: {
    V v_f_2456 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 4);
    return heff_strEq(v_x_2451, v_f_2456);
  }
  case TAG_DeclDefine: {
    V v_x_2460 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 5);
    return heff_strEq(v_x_2451, v_x_2460);
  }
  case TAG_DeclTheory: {
    V v_x_2465 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 4);
    return heff_strEq(v_x_2451, v_x_2465);
  }
  case TAG_DeclPrimitive: {
    V v_x_2469 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 3);
    return heff_strEq(v_x_2451, v_x_2469);
  }
  case TAG_DeclTest: {
    V v_x_2472 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 2);
    return heff_strEq(v_x_2451, v_x_2472);
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_2455, 0ULL, 1);
    heff_drop(v_x_2451);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2455);
  }
}
V g_heff_2eclauses_2erenameChkF_lam2(V self, V *args) {
  V v_d_2479 = args[0];
  V v_x_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2482;
  switch (heff_tag_of(v_d_2479)) {
  case TAG_At: {
    V v_x_2480 = heff_field(v_d_2479, 0);
    heff_take_n(v_d_2479, 1ULL, 2);
    v_t_2482 = v_x_2480;
    break;
  }
  default: heff_nomatch(v_d_2479);
  }
  switch (heff_tag_of(v_t_2482)) {
  case TAG_DeclEquations: {
    V v_f_2483 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 4);
    return heff_strEq(v_x_2478, v_f_2483);
  }
  case TAG_DeclDefine: {
    V v_x_2487 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 5);
    return heff_strEq(v_x_2478, v_x_2487);
  }
  case TAG_DeclTheory: {
    V v_x_2492 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 4);
    return heff_strEq(v_x_2478, v_x_2492);
  }
  case TAG_DeclPrimitive: {
    V v_x_2496 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 3);
    return heff_strEq(v_x_2478, v_x_2496);
  }
  case TAG_DeclTest: {
    V v_x_2499 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 2);
    return heff_strEq(v_x_2478, v_x_2499);
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_2482, 0ULL, 1);
    heff_drop(v_x_2478);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2482);
  }
}
V g_heff_2eclauses_2erenameTypF_lam0(V self, V *args);
V g_heff_2eclauses_2erenameTypF_lam1(V self, V *args);
Clo g_heff_2eclauses_2erenameTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenameTypF_entry, 2, 0};

V g_heff_2eclauses_2erenameTypF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_it1_242, 0);
      V v_cod_245 = heff_field(v_it1_242, 1);
      V v_ru_24it1_242_24TPi = heff_take_reuse_n(v_it1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_246 = (g_heff_2eclauses_2erenamePi(heff_dup(v_r_240), heff_dup(v_b_244)));
      V v_x_247 = heff_get(heff_dup(v_r_240), LBL_x);
      V v_t_2423;
      switch (heff_tag_of(v_b_244)) {
      case TAG_PiNamed: {
        V v_y_248 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 3);
        V v_t_2411 = heff_strEq(v_x_247, v_y_248);
        switch (heff_tag_of(v_t_2411)) {
        case TAG_True: {
          heff_drop(v_r_240);
          v_t_2423 = v_cod_245;
          break;
        }
        case TAG_False: {
          v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_cod_245}));
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        break;
      }
      case TAG_PiImplicit: {
        V v_y_2412 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 4);
        V v_t_2416 = heff_strEq(v_x_247, v_y_2412);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_r_240);
          v_t_2423 = v_cod_245;
          break;
        }
        case TAG_False: {
          v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_cod_245}));
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
        break;
      }
      case TAG_PiInstance: {
        V v_y_2417 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 4);
        V v_t_2421 = heff_strEq(v_x_247, v_y_2417);
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_r_240);
          v_t_2423 = v_cod_245;
          break;
        }
        case TAG_False: {
          v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_cod_245}));
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_244, 0ULL, 1);
        heff_drop(v_x_247);
        v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_cod_245}));
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      return heff_tag_at(v_ru_24it1_242_24TPi, TAG_At, 2, (V[]){heff_tag(TAG_TPi, 2, (V[]){v_t_246, v_t_2423}), v_sp_243});
    }
    case TAG_TSig: {
      V v_fs_2424 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TSig = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2425 = heff_tr(heff_apply(((V)&g_heff_2eclauses_2erenameField_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2434 = heff_tag_at(v_ru_24it1_242_24TSig, TAG_TSig, 1, (V[]){(g_heff_2eclauses_2erenameSeq(v_t_2425, heff_clo(g_heff_2eclauses_2erenameTypF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2424))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2434, v_sp_243});
    }
    case TAG_TSum: {
      V v_vs_2435 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TSum = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2445 = heff_tag_at(v_ru_24it1_242_24TSum, TAG_TSum, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2eclauses_2erenameTypF_lam1, 1, 1, (V[]){v_r_240}), v_vs_2435))});
      return heff_tag(TAG_At, 2, (V[]){v_t_2445, v_sp_243});
    }
    case TAG_TType: {
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInt: {
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TFloat: {
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TString: {
      heff_drop(v_r_240);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TArray: {
      V v_a_2446 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TArray = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_a_2446}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24TArray, TAG_TArray, 1, (V[]){v_t_2447}), v_sp_243});
    }
    case TAG_TInf: {
      V v_i_2448 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TInf = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2449 = heff_tr(heff_apply(heff_get(v_r_240, LBL_inf), 1, (V[]){v_i_2448}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24TInf, TAG_TInf, 1, (V[]){v_t_2449}), v_sp_243});
    }
    case TAG_TChk: {
      V v_c_2450 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TChk = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2451 = heff_tr(heff_apply(heff_get(v_r_240, LBL_chk), 1, (V[]){v_c_2450}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24TChk, TAG_TChk, 1, (V[]){v_t_2451}), v_sp_243});
    }
    case TAG_TNominal: {
      V v_t_2452 = heff_field(v_it1_242, 0);
      V v_ru_24it1_242_24TNominal = heff_take_reuse_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2453 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_t_2452}));
      return heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24it1_242_24TNominal, TAG_TNominal, 1, (V[]){v_t_2453}), v_sp_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eclauses_2erenameTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenameTypF(a[0], a[1]);
}
V g_heff_2eclauses_2erenameTypF_lam0(V self, V *args) {
  V v_x2_2426 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_At: {
    V v_x21_2427 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_DeclareField: {
      V v_y_2429 = heff_field(v_x21_2427, 0);
      heff_take_n(v_x21_2427, 1ULL, 4);
      return heff_strEq(heff_get(v_r_240, LBL_x), v_y_2429);
    }
    case TAG_BadFieldDecl: {
      heff_take_n(v_x21_2427, 0ULL, 1);
      heff_drop(v_r_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2eclauses_2erenameTypF_lam1(V self, V *args) {
  V v_m_2436 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2436)) {
  case TAG_At: {
    V v_it1_2437 = heff_field(v_m_2436, 0);
    V v_vsp_2438 = heff_field(v_m_2436, 1);
    V v_ru_24m_2436_24At = heff_take_reuse_n(v_m_2436, 3ULL, 2);
    switch (heff_tag_of(v_it1_2437)) {
    case TAG_TagVariant: {
      V v_t_2439 = heff_field(v_it1_2437, 0);
      V v_tsp_2440 = heff_field(v_it1_2437, 1);
      V v_args_2441 = heff_field(v_it1_2437, 2);
      V v_ru_24it1_2437_24TagVariant = heff_take_reuse_n(v_it1_2437, 7ULL, 3);
      V v_t_2442 = heff_tag_at(v_ru_24it1_2437_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_2439, v_tsp_2440, (g_prelude_2emap(heff_get(v_r_240, LBL_typ), v_args_2441))});
      return heff_tag_at(v_ru_24m_2436_24At, TAG_At, 2, (V[]){v_t_2442, v_vsp_2438});
    }
    case TAG_BadVariant: {
      V v_e_2443 = heff_field(v_it1_2437, 0);
      heff_take_n(v_it1_2437, 1ULL, 1);
      V v_t_2444 = heff_tr(heff_apply(heff_get(v_r_240, LBL_typ), 1, (V[]){v_e_2443}));
      return heff_tag_at(v_ru_24m_2436_24At, TAG_At, 2, (V[]){heff_tag(TAG_BadVariant, 1, (V[]){v_t_2444}), v_vsp_2438});
    }
    default: return heff_nomatch(v_it1_2437);
    }
  }
  default: return heff_nomatch(v_m_2436);
  }
}
V g_heff_2eclauses_2erenamer_lam0(V self, V *args);
V g_heff_2eclauses_2erenamer_lam1(V self, V *args);
V g_heff_2eclauses_2erenamer_lam2(V self, V *args);
Clo g_heff_2eclauses_2erenamer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erenamer_entry, 2, 0};

V g_heff_2eclauses_2erenamer(V v_x_240, V v_v_241) {
top: ;
  return heff_rec(5, shape_377_365_138_43_353, (V[]){heff_dup(v_x_240), heff_dup(v_v_241), heff_clo(g_heff_2eclauses_2erenamer_lam0, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo(g_heff_2eclauses_2erenamer_lam1, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo(g_heff_2eclauses_2erenamer_lam2, 1, 2, (V[]){v_x_240, v_v_241})});
}
V g_heff_2eclauses_2erenamer_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erenamer(a[0], a[1]);
}
V g_heff_2eclauses_2erenamer_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_heff_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eclauses_2erenameInfF(v_t_243, v_n_242));
}
V g_heff_2eclauses_2erenamer_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_heff_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eclauses_2erenameChkF(v_t_245, v_n_244));
}
V g_heff_2eclauses_2erenamer_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eclauses_2erenameTypF(v_t_247, v_n_246));
}
Clo g_heff_2eclauses_2efindTagLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2efindTagLit_entry, 2, 0};

V g_heff_2eclauses_2efindTagLit(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_2413;
    switch (heff_tag_of(v_p_242)) {
    case TAG_PVar: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PTag: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_PLit: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PRec: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PAs: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_tag(TAG_Just, 1, (V[]){v_i_241});
    }
    case TAG_False: {
      switch (heff_tag_of(v_p_242)) {
      case TAG_PVar: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PTag: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PLit: {
        return heff_tag(TAG_Just, 1, (V[]){v_i_241});
      }
      case TAG_PRec: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PAs: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      default: return heff_nomatch(v_p_242);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2efindTagLit_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2efindTagLit(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eclauses_2enubTagRows_lam0(V self, V *args);
Clo g_heff_2eclauses_2enubTagRows_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2enubTagRows_entry, 1, 0};

V g_heff_2eclauses_2enubTagRows(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2eclauses_2enubTagRows_lam0, 1, 1, (V[]){heff_dup(v_t_241)}), v_rest_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_241, (g_heff_2eclauses_2enubTagRows(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2enubTagRows_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2enubTagRows(a[0]);
}
V g_heff_2eclauses_2enubTagRows_lam0(V self, V *args) {
  V v_u_243 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(heff_get(v_t_241, LBL_tag), heff_get(v_u_243, LBL_tag));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2earmSubName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2earmSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2earmSubName_entry, 5, 0};

V g_heff_2eclauses_2earmSubName(V v_used_240, V v_bound_241, V v_v_242, V v_i_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
    V v_t_246 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
    return ({ V a_0 = v_t_245; V a_1 = heff_strAppend(v_v_242, v_t_246); V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x5_244, 0);
    V v_t_248 = heff_strEq(heff_dup(v_x_247), ((V)&g_heff_2eclauses_2earmSubName_str0));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
      V v_t_2410 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
      return ({ V a_0 = v_t_249; V a_1 = heff_strAppend(v_v_242, v_t_2410); V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_False: {
      V v_t_2411 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_247)}));
      V v_x1_2412 = (g_prelude_2eany(v_t_2411, v_bound_241));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_True: {
        V v_t_2413 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
        V v_t_2414 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
        return ({ V a_0 = v_t_2413; V a_1 = heff_strAppend(v_v_242, v_t_2414); V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_2413); r_; });
      }
      case TAG_False: {
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_v_242);
        heff_drop(v_i_243);
        return heff_dup(v_x_247);
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eclauses_2earmSubName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2earmSubName(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
Clo g_heff_2eclauses_2earmSub_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2earmSub_entry, 5, 0};

V g_heff_2eclauses_2earmSub(V v_used_240, V v_bound_241, V v_t_242, V v_v_243, V v_i_244) {
top: ;
  V v_t_245 = ({ V b_0 = heff_get(v_t_242, LBL_pats); V a_1 = heff_dup(v_i_244); V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
    V v_t_247 = heff_intShow(heff_intAdd(v_i_244, MK_INT(1LL)));
    return ({ V a_0 = v_t_246; V a_1 = heff_strAppend(v_v_243, v_t_247); V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_246); r_; });
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_p_248)) {
    case TAG_PVar: {
      V v_x_249 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 1);
      v_t_2418 = heff_tag_at(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_x_249});
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_p_248, 0ULL, 3);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_p_248, 0ULL, 1);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_p_248, 0ULL, 2);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PAs: {
      V v_x_2416 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 2);
      v_t_2418 = heff_tag_at(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_x_2416});
      break;
    }
    default: heff_nomatch(v_p_248);
    }
    return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_v_243; V a_3 = v_i_244; V a_4 = v_t_2418; V r_ = (g_heff_2eclauses_2earmSubName(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2418); r_; });
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eclauses_2earmSub_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2earmSub(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eclauses_2ebadArity_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ebadArity_entry, 3, 0};

V g_heff_2eclauses_2ebadArity(V v_c_240, V v_t_241, V v_row_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_get(v_row_242, LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_p_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    switch (heff_tag_of(v_p_244)) {
    case TAG_PVar: {
      heff_take_n(v_p_244, 0ULL, 1);
      heff_drop(v_t_241);
      return NTAG(TAG_False);
    }
    case TAG_PTag: {
      V v_t_27_246 = heff_field(v_p_244, 0);
      V v_ps_247 = heff_field(v_p_244, 1);
      heff_take_n(v_p_244, 3ULL, 3);
      V v_t_249 = heff_strEq(v_t_27_246, heff_get(heff_dup(v_t_241), LBL_tag));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        V v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ps_247; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_ps_247); r_; });
        V v_x1_2411 = heff_intEq(v_t_2410, heff_get(v_t_241, LBL_arity));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_2411);
        }
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_ps_247);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_PLit: {
      heff_take_n(v_p_244, 0ULL, 1);
      heff_drop(v_t_241);
      return NTAG(TAG_False);
    }
    case TAG_PRec: {
      heff_take_n(v_p_244, 0ULL, 2);
      heff_drop(v_t_241);
      return NTAG(TAG_False);
    }
    case TAG_PAs: {
      heff_take_n(v_p_244, 0ULL, 2);
      heff_drop(v_t_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_p_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eclauses_2ebadArity_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ebadArity(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2earmSpecializeV_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2earmSpecializeV_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2earmSpecializeV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2earmSpecializeV_entry, 5, 0};

V g_heff_2eclauses_2earmSpecializeV(V v_c_240, V v_t_241, V v_ys_242, V v_v_243, V v_r_244) {
top: ;
  V v_t_245 = ({ V b_0 = heff_get(heff_dup(v_r_244), LBL_pats); V a_1 = heff_dup(v_c_240); V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_247 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2earmSpecializeV_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_PVar: {
    V v_x_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24PVar = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_t_241);
    V v_ys_249 = (g_prelude_2emap_24s290(v_ys_242));
    V v_xs_2410 = heff_get(heff_dup(v_r_244), LBL_pats);
    V v_t_2411 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2410)));
    V v_t_2412 = (g_heff_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2410));
    V v_t_2413 = (g_heff_2eclauses_2eappendC(v_ys_249, v_t_2412));
    V v_pats_2414 = (g_heff_2eclauses_2eappendC(v_t_2411, v_t_2413));
    V v_e_2415 = heff_get(v_r_244, LBL_rhs);
    V v_t_2416 = heff_strEq(heff_dup(v_x_248), ((V)&g_heff_2eclauses_2earmSpecializeV_str1));
    V v_rhs_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_v_243);
      heff_drop(v_x_248);
      v_rhs_2419 = v_e_2415;
      break;
    }
    case TAG_False: {
      V v_t_2417 = heff_strEq(heff_dup(v_x_248), heff_dup(v_v_243));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        heff_drop(v_v_243);
        heff_drop(v_x_248);
        v_rhs_2419 = v_e_2415;
        break;
      }
      case TAG_False: {
        V v_t_2418 = (g_heff_2eclauses_2erenamer(v_x_248, v_v_243));
        v_rhs_2419 = heff_tr(heff_apply(heff_get(v_t_2418, LBL_chk), 1, (V[]){v_e_2415}));
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_at(v_ru_24t_247_24PVar, TAG_Just, 1, (V[]){heff_rec(2, shape_241_279, (V[]){v_pats_2414, v_rhs_2419})});
  }
  case TAG_PTag: {
    V v_t_27_2420 = heff_field(v_t_247, 0);
    V v_ps_2421 = heff_field(v_t_247, 1);
    heff_take_n(v_t_247, 3ULL, 3);
    heff_drop(v_ys_242);
    heff_drop(v_v_243);
    V v_t_2423 = heff_strEq(v_t_27_2420, heff_get(v_t_241, LBL_tag));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      V v_xs_2424 = heff_get(heff_dup(v_r_244), LBL_pats);
      V v_t_2425 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2424)));
      V v_t_2426 = (g_heff_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2424));
      V v_t_2427 = (g_heff_2eclauses_2eappendC(v_ps_2421, v_t_2426));
      V v_pats_2428 = (g_heff_2eclauses_2eappendC(v_t_2425, v_t_2427));
      V v_t_2429 = heff_rec(2, shape_241_279, (V[]){v_pats_2428, heff_get(v_r_244, LBL_rhs)});
      return heff_tag(TAG_Just, 1, (V[]){v_t_2429});
    }
    case TAG_False: {
      heff_drop(v_c_240);
      heff_drop(v_r_244);
      heff_drop(v_ps_2421);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_PLit: {
    V v_ru_24t_247_24PLit = heff_take_reuse_n(v_t_247, 0ULL, 1);
    heff_drop(v_t_241);
    heff_drop(v_v_243);
    V v_ys_2431 = (g_prelude_2emap_24s290(v_ys_242));
    V v_xs_2432 = heff_get(heff_dup(v_r_244), LBL_pats);
    V v_t_2433 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2432)));
    V v_t_2434 = (g_heff_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2432));
    V v_t_2435 = (g_heff_2eclauses_2eappendC(v_ys_2431, v_t_2434));
    V v_pats_2436 = (g_heff_2eclauses_2eappendC(v_t_2433, v_t_2435));
    V v_t_2437 = heff_rec(2, shape_241_279, (V[]){v_pats_2436, heff_get(v_r_244, LBL_rhs)});
    return heff_tag_at(v_ru_24t_247_24PLit, TAG_Just, 1, (V[]){v_t_2437});
  }
  case TAG_PRec: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_t_241);
    heff_drop(v_ys_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_PAs: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_t_241);
    heff_drop(v_ys_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eclauses_2earmSpecializeV_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2earmSpecializeV(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2elitYesOne_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2elitYesOne_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2elitYesOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitYesOne_entry, 5, 0};

V g_heff_2eclauses_2elitYesOne(V v_c_240, V v_l_241, V v_v_242, V v_r_243, V v_acc_244) {
top: ;
  V v_t_245 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = heff_dup(v_c_240); V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_247 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2elitYesOne_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_PVar: {
    V v_x_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_pats_249 = (g_heff_2eclauses_2edropAt(v_c_240, heff_get(heff_dup(v_r_243), LBL_pats)));
    V v_e_2410 = heff_get(v_r_243, LBL_rhs);
    V v_t_2411 = heff_strEq(heff_dup(v_x_248), ((V)&g_heff_2eclauses_2elitYesOne_str1));
    V v_rhs_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_v_242);
      heff_drop(v_x_248);
      v_rhs_2414 = v_e_2410;
      break;
    }
    case TAG_False: {
      V v_t_2412 = heff_strEq(heff_dup(v_x_248), heff_dup(v_v_242));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_v_242);
        heff_drop(v_x_248);
        v_rhs_2414 = v_e_2410;
        break;
      }
      case TAG_False: {
        V v_t_2413 = (g_heff_2eclauses_2erenamer(v_x_248, v_v_242));
        v_rhs_2414 = heff_tr(heff_apply(heff_get(v_t_2413, LBL_chk), 1, (V[]){v_e_2410}));
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    return heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_241_279, (V[]){v_pats_249, v_rhs_2414}), v_acc_244});
  }
  case TAG_PTag: {
    heff_take_n(v_t_247, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop(v_r_243);
    return v_acc_244;
  }
  case TAG_PLit: {
    V v_l_27_2418 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_v_242);
    V v_t_2419 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2418; V r_ = (g_heff_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      V v_pats_2420 = (g_heff_2eclauses_2edropAt(v_c_240, heff_get(heff_dup(v_r_243), LBL_pats)));
      V v_t_2421 = heff_rec(2, shape_241_279, (V[]){v_pats_2420, heff_get(v_r_243, LBL_rhs)});
      return heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_acc_244});
    }
    case TAG_False: {
      heff_drop(v_c_240);
      heff_drop(v_r_243);
      return v_acc_244;
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_PRec: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop(v_r_243);
    return v_acc_244;
  }
  case TAG_PAs: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop(v_r_243);
    return v_acc_244;
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eclauses_2elitYesOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elitYesOne(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
Clo g_heff_2eclauses_2elitYes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitYes_entry, 4, 0};

V g_heff_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eclauses_2elitYes(heff_dup(v_c_240), v_l_241, heff_dup(v_v_242), v_rest_245));
    return (g_heff_2eclauses_2elitYesOne(v_c_240, v_l_241, v_v_242, heff_dup(v_r_244), v_t_246));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eclauses_2elitYes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elitYes(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[3]); return r;
}
Clo g_heff_2eclauses_2elitNoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitNoOne_entry, 4, 0};

V g_heff_2eclauses_2elitNoOne(V v_c_240, V v_l_241, V v_r_242, V v_acc_243) {
top: ;
  V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_r_242), LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PLit: {
      V v_l_27_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_t_2411 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2410; V r_ = (g_heff_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_r_242);
        return v_acc_243;
      }
      case TAG_False: {
        return heff_tag(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_PRec: {
      V v_ru_24p_245_24PRec = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at(v_ru_24p_245_24PRec, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PAs: {
      V v_ru_24p_245_24PAs = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at(v_ru_24p_245_24PAs, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2elitNoOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elitNoOne(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
Clo g_heff_2eclauses_2elitNo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitNo_entry, 3, 0};

V g_heff_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eclauses_2elitNo(heff_dup(v_c_240), v_l_241, v_rest_244));
    return (g_heff_2eclauses_2elitNoOne(v_c_240, v_l_241, heff_dup(v_r_243), v_t_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eclauses_2elitNo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elitNo(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2elitChecks_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2eclauses_2elitChecks_str1 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 108, 105, 116, 101, 114, 97, 108, 32, 97, 110, 100, 32, 97, 32, 116, 97, 103, 32, 109, 97, 116, 99, 104, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2elitChecks_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[88]; } g_heff_2eclauses_2elitChecks_str3 = {{0x80000000u, K_STR, 0}, 88, 88, {108, 105, 116, 101, 114, 97, 108, 115, 32, 97, 114, 101, 32, 109, 97, 116, 99, 104, 101, 100, 32, 104, 101, 114, 101, 58, 32, 111, 110, 101, 32, 111, 102, 32, 116, 104, 101, 109, 32, 109, 117, 115, 116, 32, 109, 97, 116, 99, 104, 32, 101, 118, 101, 114, 121, 32, 111, 116, 104, 101, 114, 32, 118, 97, 108, 117, 101, 32, 40, 97, 32, 118, 97, 114, 105, 97, 98, 108, 101, 44, 32, 111, 114, 32, 96, 95, 96, 41}};
V g_heff_2eclauses_2elitChecks_lam0(V self, V *args);
V g_heff_2eclauses_2elitChecks_lam1(V self, V *args);
Clo g_heff_2eclauses_2elitChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elitChecks_entry, 5, 0};

V g_heff_2eclauses_2elitChecks(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244) {
top: ;
  V v_t_2418 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2elitChecks_lam0, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
  V v_x1_2422;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    V v_span_2421;
    switch (heff_tag_of(v_l_244)) {
    case TAG_At: {
      V v_s_2420 = heff_field(v_l_244, 1);
      v_span_2421 = heff_dup(v_s_2420);
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    v_x1_2422 = heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2421, ((V)&g_heff_2eclauses_2elitChecks_str1)})});
    break;
  }
  case TAG_False: {
    v_x1_2422 = heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Left: {
    V v_e_2423 = heff_field(v_x1_2422, 0);
    V v_ru_24x1_2422_24Left = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
    heff_drop(v_c_243);
    return heff_tag_at(v_ru_24x1_2422_24Left, TAG_Left, 1, (V[]){v_e_2423});
  }
  case TAG_Right: {
    V v_ru_24x1_2422_24Right = heff_take_reuse_n(v_x1_2422, 0ULL, 1);
    V v_t_2438 = (g_heff_2eclauses_2eallC(heff_clo(g_heff_2eclauses_2elitChecks_lam1, 1, 1, (V[]){v_c_243}), v_rows_242));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      V v_span_2441;
      switch (heff_tag_of(v_l_244)) {
      case TAG_At: {
        V v_s_2440 = heff_field(v_l_244, 1);
        v_span_2441 = heff_dup(v_s_2440);
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      return heff_tag_at(v_ru_24x1_2422_24Right, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2441, ((V)&g_heff_2eclauses_2elitChecks_str3)})});
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x1_2422_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eclauses_2elitChecks_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elitChecks(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[4]); return r;
}
V g_heff_2eclauses_2elitChecks_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get(v_row_245, LBL_pats); V a_1 = v_c_243; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_x1_248 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2elitChecks_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_x1_248 = v_p_247;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_PVar: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_248, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eclauses_2elitChecks_lam1(V self, V *args) {
  V v_row_2425 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = ({ V b_0 = heff_get(v_row_2425, LBL_pats); V a_1 = v_c_243; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2428;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    v_x1_2428 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2elitChecks_str2)});
    break;
  }
  case TAG_Just: {
    V v_p_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_x1_2428 = v_p_2427;
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2428, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2eclauses_2enoLitHere_str0 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 108, 105, 116, 101, 114, 97, 108, 32, 97, 110, 100, 32, 97, 32, 116, 97, 103, 32, 109, 97, 116, 99, 104, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
V g_heff_2eclauses_2enoLitHere_lam0(V self, V *args);
Clo g_heff_2eclauses_2enoLitHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2enoLitHere_entry, 3, 0};

V g_heff_2eclauses_2enoLitHere(V v_sp_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eclauses_2eforC(v_rows_242, heff_clo(g_heff_2eclauses_2enoLitHere_lam0, 1, 1, (V[]){v_c_241})));
}
V g_heff_2eclauses_2enoLitHere_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2enoLitHere(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2eclauses_2enoLitHere_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V b_0 = heff_get(v_row_243, LBL_pats); V a_1 = v_c_241; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PLit: {
      V v_l_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_span_2413;
      switch (heff_tag_of(v_l_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_l_2410, 1);
        heff_take_n(v_l_2410, 2ULL, 2);
        v_span_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_l_2410);
      }
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2413, ((V)&g_heff_2eclauses_2enoLitHere_str0)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2eclauses_2elookupField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2elookupField_entry, 2, 0};

V g_heff_2eclauses_2elookupField(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_p_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_f_240), heff_dup(v_g_244));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_f_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_245)});
      }
      case TAG_False: {
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eclauses_2elookupField_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2elookupField(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2enoRecMix_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eclauses_2enoRecMix_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 97, 110, 100, 32, 97, 32, 116, 97, 103, 32, 109, 97, 116, 99, 104, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eclauses_2enoRecMix_str2 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 114, 101, 99, 111, 114, 100, 32, 97, 110, 100, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 32, 109, 97, 116, 99, 104, 32, 116, 104, 101, 32, 115, 97, 109, 101, 32, 97, 114, 103, 117, 109, 101, 110, 116}};
V g_heff_2eclauses_2enoRecMix_lam0(V self, V *args);
V g_heff_2eclauses_2enoRecMix_lam1(V self, V *args);
Clo g_heff_2eclauses_2enoRecMix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2enoRecMix_entry, 2, 0};

V g_heff_2eclauses_2enoRecMix(V v_rows_240, V v_c_241) {
top: ;
  V v_t_2415 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2enoRecMix_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    HEFF_LAST return g_heff_2eclauses_2eforC(v_rows_240, heff_clo(g_heff_2eclauses_2enoRecMix_lam1, 1, 1, (V[]){v_c_241}));
  }
  case TAG_False: {
    heff_drop(v_c_241);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eclauses_2enoRecMix_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2enoRecMix(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eclauses_2enoRecMix_lam0(V self, V *args) {
  V v_row_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get(v_row_242, LBL_pats); V a_1 = v_c_241; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_x1_245 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2enoRecMix_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_x1_245 = v_p_244;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_x1_245)) {
  case TAG_PVar: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_245, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eclauses_2enoRecMix_lam1(V self, V *args) {
  V v_row_2416 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = ({ V b_0 = heff_get(v_row_2416, LBL_pats); V a_1 = v_c_241; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_2418 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    switch (heff_tag_of(v_p_2418)) {
    case TAG_PVar: {
      heff_take_n(v_p_2418, 0ULL, 1);
      return heff_tag_at(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      V v_sp_2422 = heff_field(v_p_2418, 2);
      heff_take_n(v_p_2418, 4ULL, 3);
      return heff_tag_at(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_sp_2422, ((V)&g_heff_2eclauses_2enoRecMix_str1)})});
    }
    case TAG_PLit: {
      V v_l_2423 = heff_field(v_p_2418, 0);
      heff_take_n(v_p_2418, 1ULL, 1);
      V v_span_2426;
      switch (heff_tag_of(v_l_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_l_2423, 1);
        heff_take_n(v_l_2423, 2ULL, 2);
        v_span_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_l_2423);
      }
      return heff_tag_at(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2426, ((V)&g_heff_2eclauses_2enoRecMix_str2)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_2418);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecFieldVar_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2erecFieldVar_lam0(V self, V *args);
Clo g_heff_2eclauses_2erecFieldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erecFieldVar_entry, 3, 0};

V g_heff_2eclauses_2erecFieldVar(V v_c_240, V v_rows_241, V v_f_242) {
top: ;
  V v_t_2417 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erecFieldVar_lam0, 1, 2, (V[]){v_c_240, v_f_242}), v_rows_241));
  V v_t_2418 = (g_heff_2eclauses_2ecatMaybesC(v_t_2417));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 2);
    switch (heff_tag_of(v_p_2419)) {
    case TAG_PVar: {
      V v_x_2421 = heff_field(v_p_2419, 0);
      V v_ru_24p_2419_24PVar = heff_take_reuse_n(v_p_2419, 1ULL, 1);
      return heff_tag_at(v_ru_24p_2419_24PVar, TAG_Just, 1, (V[]){v_x_2421});
    }
    case TAG_PTag: {
      heff_take_n(v_p_2419, 0ULL, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_2419, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_2419, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2428 = heff_field(v_p_2419, 0);
      heff_take_n(v_p_2419, 1ULL, 2);
      return heff_tag(TAG_Just, 1, (V[]){v_x_2428});
    }
    default: return heff_nomatch(v_p_2419);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eclauses_2erecFieldVar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erecFieldVar(a[0], a[1], a[2]);
}
V g_heff_2eclauses_2erecFieldVar_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = ({ V b_0 = heff_get(v_row_243, LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_x1_246 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecFieldVar_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_x1_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_PVar: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_246, 0ULL, 3);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2412 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 2);
    v_t_2416 = v_fps_2412;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_246, 0ULL, 2);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2416; V r_ = (g_heff_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_t_2416); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSubName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2erecSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erecSubName_entry, 4, 0};

V g_heff_2eclauses_2erecSubName(V v_used_240, V v_bound_241, V v_x3_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
    return ({ V a_0 = v_t_244; V a_1 = v_f_243; V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_t_246 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2eclauses_2erecSubName_str0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
      return ({ V a_0 = v_t_247; V a_1 = v_f_243; V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_247); r_; });
    }
    case TAG_False: {
      V v_t_248 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_245)}));
      V v_x1_249 = (g_prelude_2eany(v_t_248, v_bound_241));
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        V v_t_2410 = (g_heff_2eclauses_2eappendC(v_used_240, v_bound_241));
        return ({ V a_0 = v_t_2410; V a_1 = v_f_243; V r_ = (g_heff_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_2410); r_; });
      }
      case TAG_False: {
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_f_243);
        return heff_dup(v_x_245);
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eclauses_2erecSubName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2erecSubName(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSubs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2erecSubs_lam0(V self, V *args);
V g_heff_2eclauses_2erecSubs_lam1(V self, V *args);
Clo g_heff_2eclauses_2erecSubs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erecSubs_entry, 4, 0};

V g_heff_2eclauses_2erecSubs(V v_used_240, V v_bound_241, V v_c_242, V v_rows_243) {
top: ;
  V v_t_2418 = (g_heff_2eclauses_2econcatMapC(heff_clo(g_heff_2eclauses_2erecSubs_lam0, 1, 1, (V[]){heff_dup(v_c_242)}), v_rows_243));
  V v_t_2419 = (g_heff_2eclauses_2enubStr(v_t_2418));
  return (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erecSubs_lam1, 1, 4, (V[]){v_c_242, v_rows_243, v_used_240, v_bound_241}), v_t_2419));
}
V g_heff_2eclauses_2erecSubs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erecSubs(a[0], a[1], a[2], a[3]);
}
V g_heff_2eclauses_2erecSubs_lam0(V self, V *args) {
  V v_row_244 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V b_0 = heff_get(v_row_244, LBL_pats); V a_1 = v_c_242; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_x1_247 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSubs_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_x1_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2417;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_PVar: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_247, 0ULL, 3);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2413 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2417 = v_fps_2413;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  return (g_prelude_2emap_24s5(v_t_2417));
}
V g_heff_2eclauses_2erecSubs_lam1(V self, V *args) {
  V v_f_2420 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_rows_243 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = (g_heff_2eclauses_2erecFieldVar(v_c_242, v_rows_243, heff_dup(v_f_2420)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2421; V a_3 = v_f_2420; V r_ = (g_heff_2eclauses_2erecSubName(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecSpecialize_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2erecSpecialize_lam0(V self, V *args);
Clo g_heff_2eclauses_2erecSpecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erecSpecialize_entry, 4, 0};

V g_heff_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243) {
top: ;
  V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = heff_dup(v_c_240); V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_PVar: {
    V v_ru_24t_246_24PVar = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_248 = (g_prelude_2emap_24s290(v_fs_241));
    V v_xs_249 = heff_get(heff_dup(v_r_243), LBL_pats);
    V v_t_2410 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_249)));
    V v_t_2411 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_249));
    V v_t_2412 = (g_heff_2eclauses_2eappendC(v_ys_248, v_t_2411));
    V v_pats_2413 = (g_heff_2eclauses_2eappendC(v_t_2410, v_t_2412));
    V v_t_2414 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
    V v_x2_2416;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      v_x2_2416 = heff_tag_at(v_ru_24t_246_24PVar, TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str1)});
      break;
    }
    case TAG_Just: {
      V v_p_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PVar, 1);
      v_x2_2416 = v_p_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_e_2417 = heff_get(v_r_243, LBL_rhs);
    V v_rhs_2430;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_PVar: {
      V v_x_2418 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      V v_t_2419 = heff_strEq(heff_dup(v_x_2418), ((V)&g_heff_2eclauses_2erecSpecialize_str2));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_True: {
        heff_drop(v_v_242);
        heff_drop(v_x_2418);
        v_rhs_2430 = v_e_2417;
        break;
      }
      case TAG_False: {
        V v_t_2420 = heff_strEq(heff_dup(v_x_2418), heff_dup(v_v_242));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_v_242);
          heff_drop(v_x_2418);
          v_rhs_2430 = v_e_2417;
          break;
        }
        case TAG_False: {
          V v_t_2421 = (g_heff_2eclauses_2erenamer(v_x_2418, v_v_242));
          v_rhs_2430 = heff_tr(heff_apply(heff_get(v_t_2421, LBL_chk), 1, (V[]){v_e_2417}));
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
        break;
      }
      default: heff_nomatch(v_t_2419);
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2416, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2416, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return heff_rec(2, shape_241_279, (V[]){v_pats_2413, v_rhs_2430});
  }
  case TAG_PTag: {
    heff_take_n(v_t_246, 0ULL, 3);
    V v_ys_2434 = (g_prelude_2emap_24s290(v_fs_241));
    V v_xs_2435 = heff_get(heff_dup(v_r_243), LBL_pats);
    V v_t_2436 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2435)));
    V v_t_2437 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2435));
    V v_t_2438 = (g_heff_2eclauses_2eappendC(v_ys_2434, v_t_2437));
    V v_pats_2439 = (g_heff_2eclauses_2eappendC(v_t_2436, v_t_2438));
    V v_t_2440 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
    V v_x2_2442;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      v_x2_2442 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str3)});
      break;
    }
    case TAG_Just: {
      V v_p_2441 = heff_field(v_t_2440, 0);
      heff_take_n(v_t_2440, 1ULL, 1);
      v_x2_2442 = v_p_2441;
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V v_e_2443 = heff_get(v_r_243, LBL_rhs);
    V v_rhs_2456;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_PVar: {
      V v_x_2444 = heff_field(v_x2_2442, 0);
      heff_take_n(v_x2_2442, 1ULL, 1);
      V v_t_2445 = heff_strEq(heff_dup(v_x_2444), ((V)&g_heff_2eclauses_2erecSpecialize_str4));
      switch (heff_tag_of(v_t_2445)) {
      case TAG_True: {
        heff_drop(v_v_242);
        heff_drop(v_x_2444);
        v_rhs_2456 = v_e_2443;
        break;
      }
      case TAG_False: {
        V v_t_2446 = heff_strEq(heff_dup(v_x_2444), heff_dup(v_v_242));
        switch (heff_tag_of(v_t_2446)) {
        case TAG_True: {
          heff_drop(v_v_242);
          heff_drop(v_x_2444);
          v_rhs_2456 = v_e_2443;
          break;
        }
        case TAG_False: {
          V v_t_2447 = (g_heff_2eclauses_2erenamer(v_x_2444, v_v_242));
          v_rhs_2456 = heff_tr(heff_apply(heff_get(v_t_2447, LBL_chk), 1, (V[]){v_e_2443}));
          break;
        }
        default: heff_nomatch(v_t_2446);
        }
        break;
      }
      default: heff_nomatch(v_t_2445);
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2442, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2442, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    return heff_rec(2, shape_241_279, (V[]){v_pats_2439, v_rhs_2456});
  }
  case TAG_PLit: {
    V v_ru_24t_246_24PLit = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_2458 = (g_prelude_2emap_24s290(v_fs_241));
    V v_xs_2459 = heff_get(heff_dup(v_r_243), LBL_pats);
    V v_t_2460 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2459)));
    V v_t_2461 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2459));
    V v_t_2462 = (g_heff_2eclauses_2eappendC(v_ys_2458, v_t_2461));
    V v_pats_2463 = (g_heff_2eclauses_2eappendC(v_t_2460, v_t_2462));
    V v_t_2464 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
    V v_x2_2466;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      v_x2_2466 = heff_tag_at(v_ru_24t_246_24PLit, TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str5)});
      break;
    }
    case TAG_Just: {
      V v_p_2465 = heff_field(v_t_2464, 0);
      heff_take_n(v_t_2464, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PLit, 1);
      v_x2_2466 = v_p_2465;
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    V v_e_2467 = heff_get(v_r_243, LBL_rhs);
    V v_rhs_2480;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_PVar: {
      V v_x_2468 = heff_field(v_x2_2466, 0);
      heff_take_n(v_x2_2466, 1ULL, 1);
      V v_t_2469 = heff_strEq(heff_dup(v_x_2468), ((V)&g_heff_2eclauses_2erecSpecialize_str6));
      switch (heff_tag_of(v_t_2469)) {
      case TAG_True: {
        heff_drop(v_v_242);
        heff_drop(v_x_2468);
        v_rhs_2480 = v_e_2467;
        break;
      }
      case TAG_False: {
        V v_t_2470 = heff_strEq(heff_dup(v_x_2468), heff_dup(v_v_242));
        switch (heff_tag_of(v_t_2470)) {
        case TAG_True: {
          heff_drop(v_v_242);
          heff_drop(v_x_2468);
          v_rhs_2480 = v_e_2467;
          break;
        }
        case TAG_False: {
          V v_t_2471 = (g_heff_2eclauses_2erenamer(v_x_2468, v_v_242));
          v_rhs_2480 = heff_tr(heff_apply(heff_get(v_t_2471, LBL_chk), 1, (V[]){v_e_2467}));
          break;
        }
        default: heff_nomatch(v_t_2470);
        }
        break;
      }
      default: heff_nomatch(v_t_2469);
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2466, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2466, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    return heff_rec(2, shape_241_279, (V[]){v_pats_2463, v_rhs_2480});
  }
  case TAG_PRec: {
    V v_fps_2481 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    heff_drop(v_v_242);
    V v_ys_2486 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erecSpecialize_lam0, 1, 1, (V[]){v_fps_2481}), v_fs_241));
    V v_xs_2487 = heff_get(heff_dup(v_r_243), LBL_pats);
    V v_t_2488 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2487)));
    V v_t_2489 = (g_heff_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2487));
    V v_t_2490 = (g_heff_2eclauses_2eappendC(v_ys_2486, v_t_2489));
    V v_pats_2491 = (g_heff_2eclauses_2eappendC(v_t_2488, v_t_2490));
    return heff_rec(2, shape_241_279, (V[]){v_pats_2491, heff_get(v_r_243, LBL_rhs)});
  }
  case TAG_PAs: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_ys_2494 = (g_prelude_2emap_24s290(v_fs_241));
    V v_xs_2495 = heff_get(heff_dup(v_r_243), LBL_pats);
    V v_t_2496 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2495)));
    V v_t_2497 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2495));
    V v_t_2498 = (g_heff_2eclauses_2eappendC(v_ys_2494, v_t_2497));
    V v_pats_2499 = (g_heff_2eclauses_2eappendC(v_t_2496, v_t_2498));
    V v_t_24100 = ({ V b_0 = heff_get(heff_dup(v_r_243), LBL_pats); V a_1 = v_c_240; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
    V v_x2_24102;
    switch (heff_tag_of(v_t_24100)) {
    case TAG_Nothing: {
      v_x2_24102 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str8)});
      break;
    }
    case TAG_Just: {
      V v_p_24101 = heff_field(v_t_24100, 0);
      heff_take_n(v_t_24100, 1ULL, 1);
      v_x2_24102 = v_p_24101;
      break;
    }
    default: heff_nomatch(v_t_24100);
    }
    V v_e_24103 = heff_get(v_r_243, LBL_rhs);
    V v_rhs_24116;
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_PVar: {
      V v_x_24104 = heff_field(v_x2_24102, 0);
      heff_take_n(v_x2_24102, 1ULL, 1);
      V v_t_24105 = heff_strEq(heff_dup(v_x_24104), ((V)&g_heff_2eclauses_2erecSpecialize_str9));
      switch (heff_tag_of(v_t_24105)) {
      case TAG_True: {
        heff_drop(v_v_242);
        heff_drop(v_x_24104);
        v_rhs_24116 = v_e_24103;
        break;
      }
      case TAG_False: {
        V v_t_24106 = heff_strEq(heff_dup(v_x_24104), heff_dup(v_v_242));
        switch (heff_tag_of(v_t_24106)) {
        case TAG_True: {
          heff_drop(v_v_242);
          heff_drop(v_x_24104);
          v_rhs_24116 = v_e_24103;
          break;
        }
        case TAG_False: {
          V v_t_24107 = (g_heff_2eclauses_2erenamer(v_x_24104, v_v_242));
          v_rhs_24116 = heff_tr(heff_apply(heff_get(v_t_24107, LBL_chk), 1, (V[]){v_e_24103}));
          break;
        }
        default: heff_nomatch(v_t_24106);
        }
        break;
      }
      default: heff_nomatch(v_t_24105);
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_24102, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_24102, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    default: heff_nomatch(v_x2_24102);
    }
    return heff_rec(2, shape_241_279, (V[]){v_pats_2499, v_rhs_24116});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eclauses_2erecSpecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erecSpecialize(a[0], a[1], a[2], a[3]);
}
V g_heff_2eclauses_2erecSpecialize_lam0(V self, V *args) {
  V v_f_2483 = args[0];
  V v_fps_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2484 = ({ V a_0 = v_f_2483; V a_1 = v_fps_2481; V r_ = (g_heff_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_fps_2481); r_; });
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_Nothing: {
    return heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecSpecialize_str7)});
  }
  case TAG_Just: {
    V v_p_2485 = heff_field(v_x1_2484, 0);
    heff_take_n(v_x1_2484, 1ULL, 1);
    return v_p_2485;
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2eletFields_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eclauses_2eletFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eletFields_entry, 4, 0};

V g_heff_2eclauses_2eletFields(V v_sp_240, V v_v_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_v_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x31_244, 0);
      V v_y_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_248 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){heff_dup(v_v_241)}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at(v_ru_24x31_244_24MkPair, TAG_At, 2, (V[]){heff_tag(TAG_ArgProject, 1, (V[]){heff_dup(v_f_246)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      V v_t_2411 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgProject, 1, (V[]){((V)&g_heff_2eclauses_2eletFields_str0)}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgProject, 1, (V[]){v_f_246}), heff_dup(v_sp_240)});
      V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_x1_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_heff_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2413, 2); r_; });
      V v_b_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 2ULL, 2);
        v_b_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2418 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_sp_240), LBL_start), heff_get(v_b_2417, LBL_end)});
      V v_t_2419 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_IApp, 2, (V[]){v_t_248, v_t_2410}), v_t_2418});
      V v_e_2420 = (g_heff_2eclauses_2eletFields(heff_dup(v_sp_240), v_v_241, v_rest_245, v_body_243));
      V v_t_2421 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){v_y_247}), heff_dup(v_sp_240)});
      V v_b_2424;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_e_2420, 1));
        v_b_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      V v_t_2425 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_sp_240), LBL_start), heff_get(v_b_2424, LBL_end)});
      V v_t_2426 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_t_2421, v_e_2420}), v_t_2425});
      return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CLetIn, 2, (V[]){v_t_2419, v_t_2426}), v_sp_240});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eclauses_2eletFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2eletFields(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2epeelAs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2epeelAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epeelAs_entry, 3, 0};

V g_heff_2eclauses_2epeelAs(V v_v_240, V v_p_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_PVar: {
    heff_drop(v_v_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PTag: {
    heff_drop(v_v_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PLit: {
    heff_drop(v_v_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PRec: {
    heff_drop(v_v_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PAs: {
    V v_x_2410 = heff_field(v_p_241, 0);
    V v_p2_2411 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    V v_t_2412 = heff_strEq(heff_dup(v_x_2410), ((V)&g_heff_2eclauses_2epeelAs_str0));
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_x_2410);
      v_t_2415 = v_e_242;
      break;
    }
    case TAG_False: {
      V v_t_2413 = heff_strEq(heff_dup(v_x_2410), heff_dup(v_v_240));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_x_2410);
        v_t_2415 = v_e_242;
        break;
      }
      case TAG_False: {
        V v_t_2414 = (g_heff_2eclauses_2erenamer(v_x_2410, heff_dup(v_v_240)));
        v_t_2415 = heff_tr(heff_apply(heff_get(v_t_2414, LBL_chk), 1, (V[]){v_e_242}));
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V t_0 = v_v_240;
    V t_1 = v_p2_2411;
    V t_2 = v_t_2415;
    v_v_240 = t_0;
    v_p_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eclauses_2epeelAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epeelAs(a[0], a[1], a[2]);
}
Clo g_heff_2eclauses_2epeelCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2epeelCols_entry, 3, 0};

V g_heff_2eclauses_2epeelCols(V v_x1_240, V v_ps_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_rec(2, shape_241_279, (V[]){v_ps_241, v_e_242});
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_ps_241)) {
    case TAG_Nil: {
      heff_drop(v_v_243);
      heff_drop(v_vs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_rec(2, shape_241_279, (V[]){v_ps_241, v_e_242});
    }
    case TAG_Cons: {
      V v_p_245 = heff_field(v_ps_241, 0);
      V v_ps2_246 = heff_field(v_ps_241, 1);
      heff_take_n(v_ps_241, 3ULL, 2);
      V v_t_247 = (g_heff_2eclauses_2epeelAs(v_v_243, v_p_245, v_e_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_p_27_248 = heff_field(v_t_247, 0);
        V v_e_27_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_r_2410 = (g_heff_2eclauses_2epeelCols(v_vs_244, v_ps2_246, v_e_27_249));
        V v_t_2411 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_27_248, heff_get(heff_dup(v_r_2410), LBL_pats)});
        return heff_rec(2, shape_241_279, (V[]){v_t_2411, heff_get(v_r_2410, LBL_rhs)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ps_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eclauses_2epeelCols_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2epeelCols(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecolPick_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecolPick_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecolPick_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecolPick_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eclauses_2ecolPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecolPick_entry, 3, 0};

V g_heff_2eclauses_2ecolPick(V v_used_240, V v_i_241, V v_xs_242) {
top: ;
  switch (heff_tag_of(v_xs_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
    return (g_heff_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eclauses_2ecolPick_str0), v_t_243)));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_242, 0);
    V v_xs2_245 = heff_field(v_xs_242, 1);
    switch (heff_tag_of(v_xs2_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_strEq(heff_dup(v_x_244), ((V)&g_heff_2eclauses_2ecolPick_str1));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        V v_t_247 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
        return (g_heff_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eclauses_2ecolPick_str2), v_t_247)));
      }
      case TAG_False: {
        heff_drop(v_i_241);
        return heff_dup(v_x_244);
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_Cons: {
      V v_t_2410 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
      return (g_heff_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eclauses_2ecolPick_str3), v_t_2410)));
    }
    default: return heff_nomatch(v_xs2_245);
    }
  }
  default: return heff_nomatch(v_xs_242);
  }
}
V g_heff_2eclauses_2ecolPick_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2ecolPick(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2eclauses_2ecolName_lam0(V self, V *args);
Clo g_heff_2eclauses_2ecolName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecolName_entry, 4, 0};

V g_heff_2eclauses_2ecolName(V v_used_240, V v_params_241, V v_rows_242, V v_i_243) {
top: ;
  V v_t_244 = (g_heff_2eclauses_2enthC(v_params_241, heff_dup(v_i_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_2417 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2ecolName_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), v_rows_242));
    V v_t_2418 = (g_heff_2eclauses_2ecatMaybesC(v_t_2417));
    V v_t_2419 = (g_heff_2eclauses_2enubStr(v_t_2418));
    return ({ V a_0 = v_used_240; V a_1 = v_i_243; V a_2 = v_t_2419; V r_ = (g_heff_2eclauses_2ecolPick(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  }
  case TAG_Just: {
    V v_p_2420 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    return v_p_2420;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eclauses_2ecolName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2ecolName(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2ecolName_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get(v_r_245, LBL_pats); V a_1 = v_i_243; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    switch (heff_tag_of(v_p_247)) {
    case TAG_PVar: {
      V v_x_248 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 1);
      return heff_tag_at(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_248});
    }
    case TAG_PTag: {
      heff_take_n(v_p_247, 0ULL, 3);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_247, 0ULL, 1);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_247, 0ULL, 2);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2415 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 2);
      return heff_tag_at(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_2415});
    }
    default: return heff_nomatch(v_p_247);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2eclauses_2efoldr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2efoldr2_entry, 3, 0};

V g_heff_2eclauses_2efoldr2(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2eclauses_2efoldr2(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eclauses_2efoldr2_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2efoldr2(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[44]; } g_heff_2eclauses_2earmOf_24s294_str0 = {{0x80000000u, K_STR, 0}, 44, 44, {32, 105, 115, 32, 117, 115, 101, 100, 32, 119, 105, 116, 104, 32, 100, 105, 102, 102, 101, 114, 101, 110, 116, 32, 110, 117, 109, 98, 101, 114, 115, 32, 111, 102, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115}};
V g_heff_2eclauses_2earmOf_24s294_lam0(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam1(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam2(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam4(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam3(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam5(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam6(V self, V *args);
V g_heff_2eclauses_2earmOf_24s294_lam7(V self, V *args);
Clo g_heff_2eclauses_2earmOf_24s294_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2earmOf_24s294_entry, 8, 0};

V g_heff_2eclauses_2earmOf_24s294(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_v_246, V v_t_247) {
top: ;
  V v_t_249 = (g_heff_2eclauses_2eanyC(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam0, 1, 2, (V[]){heff_dup(v_c_245), heff_dup(v_t_247)}), v_rows_244));
  V v_x1_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    V v_t_2410 = heff_strAppend(heff_get(heff_dup(v_t_247), LBL_tag), ((V)&g_heff_2eclauses_2earmOf_24s294_str0));
    V v_t_2411 = heff_rec(2, shape_314_193, (V[]){heff_get(heff_dup(v_t_247), LBL_span), v_t_2410});
    v_x1_2412 = heff_tag(TAG_Left, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_False: {
    v_x1_2412 = heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Left: {
    V v_e_2413 = heff_field(v_x1_2412, 0);
    V v_ru_24x1_2412_24Left = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop(v_v_246);
    heff_drop(v_t_247);
    return heff_tag_at(v_ru_24x1_2412_24Left, TAG_Left, 1, (V[]){v_e_2413});
  }
  case TAG_Right: {
    V v_ru_24x1_2412_24Right = heff_take_reuse_n(v_x1_2412, 0ULL, 1);
    V v_t_2415 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_get(heff_dup(v_t_247), LBL_arity)));
    V v_t_2417 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam1, 1, 4, (V[]){heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_t_247), heff_dup(v_v_246)}), v_t_2415));
    V v_bound_2418 = (g_heff_2eclauses_2eappendC(v_t_2417, heff_dup(v_bound_241)));
    V v_t_2419 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_get(heff_dup(v_t_247), LBL_arity)));
    V v_ys_2421 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam2, 1, 4, (V[]){heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_t_247), heff_dup(v_v_246)}), v_t_2419));
    V v_t_2422 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2423 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_245), MK_INT(1LL)), v_vars_243));
    V v_t_2424 = (g_heff_2eclauses_2eappendC(v_ys_2421, v_t_2423));
    V v_vars_2425 = (g_heff_2eclauses_2eappendC(v_t_2422, v_t_2424));
    V v_t_2430 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam3, 1, 5, (V[]){heff_dup(v_t_247), heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_v_246), v_c_245}), v_rows_244));
    V v_rows_2431 = (g_heff_2eclauses_2ecatMaybesC(v_t_2430));
    V v_t_2433 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam5, 1, 1, (V[]){heff_dup(v_vars_2425)}), v_rows_2431));
    V v_x1_2434 = (g_heff_2eclauses_2ecompilePeeled_24s292(heff_dup(v_used_240), v_bound_2418, heff_dup(v_sp_242), v_vars_2425, v_t_2433));
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Left: {
      V v_e_2435 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_v_246);
      heff_drop(v_t_247);
      return heff_tag_at(v_ru_24x1_2412_24Right, TAG_Left, 1, (V[]){v_e_2435});
    }
    case TAG_Right: {
      V v_x_2436 = heff_field(v_x1_2434, 0);
      V v_ru_24x1_2434_24Right = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
      V v_t_2437 = heff_get(heff_dup(v_t_247), LBL_tag);
      V v_tsp_2438 = heff_get(heff_dup(v_t_247), LBL_span);
      V v_t_2439 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_get(heff_dup(v_t_247), LBL_arity)));
      V v_t_2441 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam6, 1, 4, (V[]){v_used_240, v_bound_241, v_t_247, v_v_246}), v_t_2439));
      V v_ps_2443 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam7, 1, 1, (V[]){v_sp_242}), v_t_2441));
      V v_t_2444 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2412_24Right, TAG_PatVar, 1, (V[]){heff_dup(v_t_2437)}), heff_dup(v_tsp_2438)});
      V v_x1_2445 = (g_heff_2epresyntax_2elastOr(v_t_2444, v_ps_2443));
      V v_b_2448;
      switch (heff_tag_of(v_x1_2445)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_x1_2445, 1);
        heff_take_n(v_x1_2445, 2ULL, 2);
        v_b_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_x1_2445);
      }
      V v_t_2449 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_tsp_2438), LBL_start), heff_get(v_b_2448, LBL_end)});
      V v_p_2450 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatTag, 3, (V[]){v_t_2437, v_tsp_2438, v_ps_2443}), v_t_2449});
      V v_a_2453;
      switch (heff_tag_of(v_p_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_p_2450, 1));
        v_a_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_p_2450);
      }
      V v_b_2456;
      switch (heff_tag_of(v_x_2436)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_x_2436, 1));
        v_b_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_x_2436);
      }
      V v_t_2457 = heff_rec(2, shape_320_83, (V[]){heff_get(v_a_2453, LBL_start), heff_get(v_b_2456, LBL_end)});
      V v_t_2458 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_2450, v_x_2436}), v_t_2457});
      return heff_tag_at(v_ru_24x1_2434_24Right, TAG_Right, 1, (V[]){v_t_2458});
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eclauses_2earmOf_24s294_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2earmOf_24s294(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eclauses_2earmOf_24s294_lam0(V self, V *args) {
  V v_row_248 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eclauses_2ebadArity(v_c_245, v_t_247, v_row_248));
}
V g_heff_2eclauses_2earmOf_24s294_lam1(V self, V *args) {
  V v_i_2416 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eclauses_2earmSub(v_used_240, v_bound_241, v_t_247, v_v_246, v_i_2416));
}
V g_heff_2eclauses_2earmOf_24s294_lam2(V self, V *args) {
  V v_i_2420 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eclauses_2earmSub(v_used_240, v_bound_241, v_t_247, v_v_246, v_i_2420));
}
V g_heff_2eclauses_2earmOf_24s294_lam4(V self, V *args) {
  V v_i_2428 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eclauses_2earmSub(v_used_240, v_bound_241, v_t_247, v_v_246, v_i_2428));
}
V g_heff_2eclauses_2earmOf_24s294_lam3(V self, V *args) {
  V v_row_2426 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_used_240 = heff_env(self)[1];
  V v_bound_241 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  V v_c_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2427 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_get(heff_dup(v_t_247), LBL_arity)));
  V v_t_2429 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2earmOf_24s294_lam4, 1, 4, (V[]){v_used_240, v_bound_241, heff_dup(v_t_247), heff_dup(v_v_246)}), v_t_2427));
  return (g_heff_2eclauses_2earmSpecializeV(v_c_245, v_t_247, v_t_2429, v_v_246, v_row_2426));
}
V g_heff_2eclauses_2earmOf_24s294_lam5(V self, V *args) {
  V v_row_2432 = args[0];
  V v_vars_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_2425, heff_get(heff_dup(v_row_2432), LBL_pats), heff_get(v_row_2432, LBL_rhs)));
}
V g_heff_2eclauses_2earmOf_24s294_lam6(V self, V *args) {
  V v_i_2440 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_t_247 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eclauses_2earmSub(v_used_240, v_bound_241, v_t_247, v_v_246, v_i_2440));
}
V g_heff_2eclauses_2earmOf_24s294_lam7(V self, V *args) {
  V v_y_2442 = args[0];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){v_y_2442}), v_sp_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2edefaultOf_24s296_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2edefaultOf_24s296_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2edefaultOf_24s296_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2edefaultOf_24s296_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2edefaultOf_24s296_lam0(V self, V *args);
V g_heff_2eclauses_2edefaultOf_24s296_lam1(V self, V *args);
Clo g_heff_2eclauses_2edefaultOf_24s296_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edefaultOf_24s296_entry, 7, 0};

V g_heff_2eclauses_2edefaultOf_24s296(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246) {
top: ;
  switch (heff_tag_of(v_rest_246)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_vars_249 = (g_heff_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_rows_2432 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edefaultOf_24s296_lam0, 1, 2, (V[]){v_c_245, v_vars_243}), v_rest_246));
    V v_t_2434 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edefaultOf_24s296_lam1, 1, 1, (V[]){heff_dup(v_vars_249)}), v_rows_2432));
    V v_x1_2435 = (g_heff_2eclauses_2ecompilePeeled_24s292(v_used_240, v_bound_241, heff_dup(v_sp_242), v_vars_249, v_t_2434));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Left: {
      V v_e_2436 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Left = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at(v_ru_24x1_2435_24Left, TAG_Left, 1, (V[]){v_e_2436});
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Right = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      V v_t_2438 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2435_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eclauses_2edefaultOf_24s296_str3)}), heff_dup(v_sp_242)});
      V v_b_2441;
      switch (heff_tag_of(v_x_2437)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_x_2437, 1));
        v_b_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_x_2437);
      }
      V v_t_2442 = heff_rec(2, shape_320_83, (V[]){heff_get(v_sp_242, LBL_start), heff_get(v_b_2441, LBL_end)});
      V v_t_2443 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_t_2438, v_x_2437}), v_t_2442});
      V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2444});
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  default: return heff_nomatch(v_rest_246);
  }
}
V g_heff_2eclauses_2edefaultOf_24s296_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2edefaultOf_24s296(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eclauses_2edefaultOf_24s296_lam0(V self, V *args) {
  V v_row_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_vars_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_pats_2411 = (g_heff_2eclauses_2edropAt(heff_dup(v_c_245), heff_get(heff_dup(v_row_2410), LBL_pats)));
  V v_t_2412 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_v_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    v_v_2414 = ((V)&g_heff_2eclauses_2edefaultOf_24s296_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    v_v_2414 = v_v_2413;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2415 = ({ V b_0 = heff_get(heff_dup(v_row_2410), LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x2_2417 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2edefaultOf_24s296_str1)});
    break;
  }
  case TAG_Just: {
    V v_p_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_x2_2417 = v_p_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_e_2418 = heff_get(v_row_2410, LBL_rhs);
  V v_rhs_2431;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_PVar: {
    V v_x_2419 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    V v_t_2420 = heff_strEq(heff_dup(v_x_2419), ((V)&g_heff_2eclauses_2edefaultOf_24s296_str2));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_v_2414);
      heff_drop(v_x_2419);
      v_rhs_2431 = v_e_2418;
      break;
    }
    case TAG_False: {
      V v_t_2421 = heff_strEq(heff_dup(v_x_2419), heff_dup(v_v_2414));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        heff_drop(v_v_2414);
        heff_drop(v_x_2419);
        v_rhs_2431 = v_e_2418;
        break;
      }
      case TAG_False: {
        V v_t_2422 = (g_heff_2eclauses_2erenamer(v_x_2419, v_v_2414));
        v_rhs_2431 = heff_tr(heff_apply(heff_get(v_t_2422, LBL_chk), 1, (V[]){v_e_2418}));
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x2_2417, 0ULL, 3);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x2_2417, 0ULL, 1);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  return heff_rec(2, shape_241_279, (V[]){v_pats_2411, v_rhs_2431});
}
V g_heff_2eclauses_2edefaultOf_24s296_lam1(V self, V *args) {
  V v_row_2433 = args[0];
  V v_vars_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_249, heff_get(heff_dup(v_row_2433), LBL_pats), heff_get(v_row_2433, LBL_rhs)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2edefaultArm_24s295_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2edefaultArm_24s295_lam0(V self, V *args);
Clo g_heff_2eclauses_2edefaultArm_24s295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edefaultArm_24s295_entry, 6, 0};

V g_heff_2eclauses_2edefaultArm_24s295(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_t_2420 = (g_prelude_2efilter(heff_clo(g_heff_2eclauses_2edefaultArm_24s295_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_t_2420; V r_ = (g_heff_2eclauses_2edefaultOf_24s296(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
}
V g_heff_2eclauses_2edefaultArm_24s295_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2edefaultArm_24s295(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eclauses_2edefaultArm_24s295_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V b_0 = heff_get(v_row_246, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_x1_249 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2edefaultArm_24s295_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_x1_249 = v_p_248;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_x1_2419;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    v_x1_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2eliteralOf_24s297_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eclauses_2eliteralOf_24s297_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2eliteralOf_24s297_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eclauses_2eliteralOf_24s297_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eclauses_2eliteralOf_24s297_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eclauses_2eliteralOf_24s297_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
V g_heff_2eclauses_2eliteralOf_24s297_lam0(V self, V *args);
V g_heff_2eclauses_2eliteralOf_24s297_lam1(V self, V *args);
Clo g_heff_2eclauses_2eliteralOf_24s297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2eliteralOf_24s297_entry, 7, 0};

V g_heff_2eclauses_2eliteralOf_24s297(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246) {
top: ;
  V v_x1_247 = (g_heff_2eclauses_2elitChecks(v_sp_242, v_vars_243, v_rows_244, heff_dup(v_c_245), v_l_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    heff_drop(v_l_246);
    return heff_tag_at(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 0ULL, 1);
    V v_vars_2410 = (g_heff_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2411 = (g_heff_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_t_2413;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      v_t_2413 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str0);
      break;
    }
    case TAG_Just: {
      V v_v_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      v_t_2413 = v_v_2412;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_rows_2414 = (g_heff_2eclauses_2elitYes(heff_dup(v_c_245), v_l_246, v_t_2413, v_rows_244));
    V v_t_2416 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2eliteralOf_24s297_lam0, 1, 1, (V[]){heff_dup(v_vars_2410)}), v_rows_2414));
    V v_x1_2417 = (g_heff_2eclauses_2ecompilePeeled_24s292(heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), v_vars_2410, v_t_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_l_246);
      return heff_tag_at(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2418});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Right = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      V v_rows_2420 = (g_heff_2eclauses_2elitNo(heff_dup(v_c_245), v_l_246, v_rows_244));
      V v_t_2422 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2eliteralOf_24s297_lam1, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2420));
      V v_x1_2423 = (g_heff_2eclauses_2ecompilePeeled_24s292(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_t_2422));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x1_2423, 0);
        heff_take_n(v_x1_2423, 1ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_c_245);
        heff_drop(v_l_246);
        heff_drop(v_x_2419);
        heff_drop_cell(v_ru_24x1_2417_24Right, 1);
        return heff_tag_at(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2424});
      }
      case TAG_Right: {
        V v_x_2425 = heff_field(v_x1_2423, 0);
        V v_ru_24x1_2423_24Right = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_x11_2426 = heff_dup(heff_field(v_l_246, 0));
          switch (heff_tag_of(v_x11_2426)) {
          case TAG_PatVar: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str1);
            break;
          }
          case TAG_PatTag: {
            heff_take_n(v_x11_2426, 0ULL, 3);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str2);
            break;
          }
          case TAG_PatOp: {
            heff_take_n(v_x11_2426, 0ULL, 3);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str3);
            break;
          }
          case TAG_PatInt: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str4);
            break;
          }
          case TAG_PatFloat: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str5);
            break;
          }
          case TAG_PatString: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str6);
            break;
          }
          case TAG_PatRecord: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str7);
            break;
          }
          case TAG_PatWord: {
            heff_take_n(v_x11_2426, 0ULL, 1);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str8);
            break;
          }
          case TAG_PatAs: {
            heff_take_n(v_x11_2426, 0ULL, 3);
            v_t_2443 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str9);
            break;
          }
          default: heff_nomatch(v_x11_2426);
          }
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2446;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_l_246, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2447 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_247_24Right, TAG_IVar, 1, (V[]){v_t_2443}), v_t_2446});
        V v_t_2448 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
        V v_t_2450;
        switch (heff_tag_of(v_t_2448)) {
        case TAG_Nothing: {
          v_t_2450 = ((V)&g_heff_2eclauses_2eliteralOf_24s297_str10);
          break;
        }
        case TAG_Just: {
          V v_v_2449 = heff_field(v_t_2448, 0);
          heff_take_n(v_t_2448, 1ULL, 1);
          v_t_2450 = v_v_2449;
          break;
        }
        default: heff_nomatch(v_t_2448);
        }
        V v_i_2451 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2417_24Right, TAG_IVar, 1, (V[]){v_t_2450}), heff_dup(v_sp_242)});
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        V v_t_2455 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2423_24Right, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        V v_t_2456 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_ArgExplicit, 1, (V[]){v_t_2455}), v_sp_242});
        V v_t_2457 = heff_tag(TAG_ArgExplicit, 1, (V[]){(g_heff_2eclauses_2elitExpr(heff_dup(v_l_246)))});
        V v_t_2460;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2459 = heff_dup(heff_field(v_l_246, 1));
          v_t_2460 = v_s_2459;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2461 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2457, v_t_2460}), NTAG(TAG_Nil)});
        V v_t_2462 = (g_heff_2epresyntax_2einfApp(v_t_2447, heff_tag(TAG_Cons, 2, (V[]){v_t_2456, v_t_2461})));
        V v_tsp_2465;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2464 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2465 = v_s_2464;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2466 = heff_tag(TAG_PatTag, 3, (V[]){((V)&g_heff_2eclauses_2eliteralOf_24s297_str11), heff_dup(v_tsp_2465), NTAG(TAG_Nil)});
        V v_t_2467 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){((V)&g_heff_2eclauses_2eliteralOf_24s297_str12)}), heff_dup(v_tsp_2465)});
        V v_x1_2468 = ({ V a_0 = v_t_2467; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2471;
        switch (heff_tag_of(v_x1_2468)) {
        case TAG_At: {
          V v_s_2470 = heff_field(v_x1_2468, 1);
          heff_take_n(v_x1_2468, 2ULL, 2);
          v_b_2471 = v_s_2470;
          break;
        }
        default: heff_nomatch(v_x1_2468);
        }
        V v_t_2472 = heff_rec(2, shape_320_83, (V[]){heff_get(v_tsp_2465, LBL_start), heff_get(v_b_2471, LBL_end)});
        V v_p_2473 = heff_tag(TAG_At, 2, (V[]){v_t_2466, v_t_2472});
        V v_a_2476;
        switch (heff_tag_of(v_p_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_dup(heff_field(v_p_2473, 1));
          v_a_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_p_2473);
        }
        V v_b_2479;
        switch (heff_tag_of(v_x_2419)) {
        case TAG_At: {
          V v_s_2478 = heff_dup(heff_field(v_x_2419, 1));
          v_b_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        V v_t_2480 = heff_rec(2, shape_320_83, (V[]){heff_get(v_a_2476, LBL_start), heff_get(v_b_2479, LBL_end)});
        V v_t_2481 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_2473, v_x_2419}), v_t_2480});
        V v_tsp_2484;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2485 = heff_tag(TAG_PatTag, 3, (V[]){((V)&g_heff_2eclauses_2eliteralOf_24s297_str13), heff_dup(v_tsp_2484), NTAG(TAG_Nil)});
        V v_t_2486 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_PatVar, 1, (V[]){((V)&g_heff_2eclauses_2eliteralOf_24s297_str14)}), heff_dup(v_tsp_2484)});
        V v_x1_2487 = ({ V a_0 = v_t_2486; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2490;
        switch (heff_tag_of(v_x1_2487)) {
        case TAG_At: {
          V v_s_2489 = heff_field(v_x1_2487, 1);
          heff_take_n(v_x1_2487, 2ULL, 2);
          v_b_2490 = v_s_2489;
          break;
        }
        default: heff_nomatch(v_x1_2487);
        }
        V v_t_2491 = heff_rec(2, shape_320_83, (V[]){heff_get(v_tsp_2484, LBL_start), heff_get(v_b_2490, LBL_end)});
        V v_p_2492 = heff_tag(TAG_At, 2, (V[]){v_t_2485, v_t_2491});
        V v_a_2495;
        switch (heff_tag_of(v_p_2492)) {
        case TAG_At: {
          V v_s_2494 = heff_dup(heff_field(v_p_2492, 1));
          v_a_2495 = v_s_2494;
          break;
        }
        default: heff_nomatch(v_p_2492);
        }
        V v_b_2498;
        switch (heff_tag_of(v_x_2425)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_x_2425, 1));
          v_b_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_x_2425);
        }
        V v_t_2499 = heff_rec(2, shape_320_83, (V[]){heff_get(v_a_2495, LBL_start), heff_get(v_b_2498, LBL_end)});
        V v_t_24100 = heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_MkAlt, 2, (V[]){v_p_2492, v_x_2425}), v_t_2499});
        V v_t_24101 = heff_tag(TAG_Cons, 2, (V[]){v_t_24100, NTAG(TAG_Nil)});
        V v_t_24102 = heff_tag(TAG_CMatch, 2, (V[]){v_t_2462, heff_tag(TAG_Cons, 2, (V[]){v_t_2481, v_t_24101})});
        V v_t_24105;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_24104 = heff_field(v_l_246, 1);
          heff_take_n(v_l_246, 2ULL, 2);
          v_t_24105 = v_s_24104;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24102, v_t_24105})});
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eclauses_2eliteralOf_24s297_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2eliteralOf_24s297(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eclauses_2eliteralOf_24s297_lam0(V self, V *args) {
  V v_row_2415 = args[0];
  V v_vars_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_2410, heff_get(heff_dup(v_row_2415), LBL_pats), heff_get(v_row_2415, LBL_rhs)));
}
V g_heff_2eclauses_2eliteralOf_24s297_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_243, heff_get(heff_dup(v_row_2421), LBL_pats), heff_get(v_row_2421, LBL_rhs)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecordOf_24s298_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecordOf_24s298_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecordOf_24s298_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2erecordOf_24s298_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2erecordOf_24s298_lam1(V self, V *args);
V g_heff_2eclauses_2erecordOf_24s298_lam0(V self, V *args);
V g_heff_2eclauses_2erecordOf_24s298_lam2(V self, V *args);
V g_heff_2eclauses_2erecordOf_24s298_lam3(V self, V *args);
Clo g_heff_2eclauses_2erecordOf_24s298_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2erecordOf_24s298_entry, 6, 0};

V g_heff_2eclauses_2erecordOf_24s298(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_x1_246 = (g_heff_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Left: {
    V v_e_247 = heff_field(v_x1_246, 0);
    V v_ru_24x1_246_24Left = heff_take_reuse_n(v_x1_246, 1ULL, 1);
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    return heff_tag_at(v_ru_24x1_246_24Left, TAG_Left, 1, (V[]){v_e_247});
  }
  case TAG_Right: {
    V v_ru_24x1_246_24Right = heff_take_reuse_n(v_x1_246, 0ULL, 1);
    V v_t_249 = (g_heff_2eclauses_2erecSubs(heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_c_245), heff_dup(v_rows_244)));
    V v_bound_2410 = (g_heff_2eclauses_2eappendC(v_t_249, heff_dup(v_bound_241)));
    V v_ys_2411 = (g_heff_2eclauses_2erecSubs(heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_c_245), heff_dup(v_rows_244)));
    V v_t_2412 = (g_heff_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2413 = (g_heff_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_245), MK_INT(1LL)), heff_dup(v_vars_243)));
    V v_t_2414 = (g_heff_2eclauses_2eappendC(v_ys_2411, v_t_2413));
    V v_vars_2415 = (g_heff_2eclauses_2eappendC(v_t_2412, v_t_2414));
    V v_rows_2436 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erecordOf_24s298_lam0, 1, 3, (V[]){heff_dup(v_c_245), heff_dup(v_rows_244), heff_dup(v_vars_243)}), heff_dup(v_rows_244)));
    V v_t_2438 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2erecordOf_24s298_lam2, 1, 1, (V[]){heff_dup(v_vars_2415)}), v_rows_2436));
    V v_x1_2439 = (g_heff_2eclauses_2ecompilePeeled_24s292(heff_dup(v_used_240), v_bound_2410, heff_dup(v_sp_242), v_vars_2415, v_t_2438));
    switch (heff_tag_of(v_x1_2439)) {
    case TAG_Left: {
      V v_e_2440 = heff_field(v_x1_2439, 0);
      heff_take_n(v_x1_2439, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      return heff_tag_at(v_ru_24x1_246_24Right, TAG_Left, 1, (V[]){v_e_2440});
    }
    case TAG_Right: {
      V v_x_2441 = heff_field(v_x1_2439, 0);
      heff_take_n(v_x1_2439, 1ULL, 1);
      V v_t_2442 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
      V v_t_2444;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_Nothing: {
        v_t_2444 = ((V)&g_heff_2eclauses_2erecordOf_24s298_str2);
        break;
      }
      case TAG_Just: {
        V v_v_2443 = heff_field(v_t_2442, 0);
        heff_take_n(v_t_2442, 1ULL, 1);
        v_t_2444 = v_v_2443;
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      V v_t_2459 = (g_heff_2eclauses_2econcatMapC(heff_clo(g_heff_2eclauses_2erecordOf_24s298_lam3, 1, 1, (V[]){heff_dup(v_c_245)}), v_rows_244));
      V v_t_2460 = (g_heff_2eclauses_2enubStr(v_t_2459));
      V v_t_2461 = (g_heff_2eclauses_2erecSubs(v_used_240, v_bound_241, v_c_245, v_rows_244));
      V v_t_2462 = (g_heff_2eclauses_2ezipC(v_t_2460, v_t_2461));
      return heff_tag_at(v_ru_24x1_246_24Right, TAG_Right, 1, (V[]){(g_heff_2eclauses_2eletFields(v_sp_242, v_t_2444, v_t_2462, v_x_2441))});
    }
    default: return heff_nomatch(v_x1_2439);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eclauses_2erecordOf_24s298_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2erecordOf_24s298(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eclauses_2erecordOf_24s298_lam1(V self, V *args) {
  V v_row_2417 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = ({ V b_0 = heff_get(v_row_2417, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2420;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    v_x1_2420 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecordOf_24s298_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 1);
    v_x1_2420 = v_p_2419;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2430;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_t_2430 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2420, 0ULL, 3);
    v_t_2430 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2420, 0ULL, 1);
    v_t_2430 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2426 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 2);
    v_t_2430 = v_fps_2426;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2420, 0ULL, 2);
    v_t_2430 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  return (g_prelude_2emap_24s5(v_t_2430));
}
V g_heff_2eclauses_2erecordOf_24s298_lam0(V self, V *args) {
  V v_row_2416 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_rows_244 = heff_env(self)[1];
  V v_vars_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = ({ V a_0 = heff_clo(g_heff_2eclauses_2erecordOf_24s298_lam1, 1, 1, (V[]){heff_dup(v_c_245)}); V a_1 = v_rows_244; V r_ = (g_heff_2eclauses_2econcatMapC(a_0, a_1)); heff_drop(v_rows_244); r_; });
  V v_t_2432 = (g_heff_2eclauses_2enubStr(v_t_2431));
  V v_t_2433 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_Nothing: {
    v_t_2435 = ((V)&g_heff_2eclauses_2erecordOf_24s298_str1);
    break;
  }
  case TAG_Just: {
    V v_v_2434 = heff_field(v_t_2433, 0);
    heff_take_n(v_t_2433, 1ULL, 1);
    v_t_2435 = v_v_2434;
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  return (g_heff_2eclauses_2erecSpecialize(v_c_245, v_t_2432, v_t_2435, v_row_2416));
}
V g_heff_2eclauses_2erecordOf_24s298_lam2(V self, V *args) {
  V v_row_2437 = args[0];
  V v_vars_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_2415, heff_get(heff_dup(v_row_2437), LBL_pats), heff_get(v_row_2437, LBL_rhs)));
}
V g_heff_2eclauses_2erecordOf_24s298_lam3(V self, V *args) {
  V v_row_2445 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = ({ V b_0 = heff_get(v_row_2445, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2448;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_Nothing: {
    v_x1_2448 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2erecordOf_24s298_str3)});
    break;
  }
  case TAG_Just: {
    V v_p_2447 = heff_field(v_t_2446, 0);
    heff_take_n(v_t_2446, 1ULL, 1);
    v_x1_2448 = v_p_2447;
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2458;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2448, 0ULL, 3);
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2454 = heff_field(v_x1_2448, 0);
    heff_take_n(v_x1_2448, 1ULL, 2);
    v_t_2458 = v_fps_2454;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2448, 0ULL, 2);
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  return (g_prelude_2emap_24s5(v_t_2458));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompileAt_24s293_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
V g_heff_2eclauses_2ecompileAt_24s293_lam0(V self, V *args);
V g_heff_2eclauses_2ecompileAt_24s293_lam1(V self, V *args);
V g_heff_2eclauses_2ecompileAt_24s293_lam2(V self, V *args);
V g_heff_2eclauses_2ecompileAt_24s293_lam3(V self, V *args);
V g_heff_2eclauses_2ecompileAt_24s293_lam4(V self, V *args);
V g_heff_2eclauses_2ecompileAt_24s293_lam5(V self, V *args);
Clo g_heff_2eclauses_2ecompileAt_24s293_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecompileAt_24s293_entry, 7, 0};

V g_heff_2eclauses_2ecompileAt_24s293(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_p_246)) {
  case TAG_PVar: {
    V v_ru_24p_246_24PVar = heff_take_reuse_n(v_p_246, 0ULL, 1);
    V v_x1_248 = (g_heff_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      return heff_tag_at(v_ru_24p_246_24PVar, TAG_Left, 1, (V[]){v_e_249});
    }
    case TAG_Right: {
      V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 0ULL, 1);
      V v_x1_2411 = (g_heff_2eclauses_2enoLitHere(v_sp_242, heff_dup(v_c_245), v_rows_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Left: {
        V v_e_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        heff_drop_cell(v_ru_24x1_248_24Right, 1);
        return heff_tag_at(v_ru_24p_246_24PVar, TAG_Left, 1, (V[]){v_e_2412});
      }
      case TAG_Right: {
        heff_take_n(v_x1_2411, 0ULL, 1);
        V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
        V v_t_2429 = (g_heff_2eclauses_2ecatMaybesC(v_t_2428));
        V v_t_2430 = (g_heff_2eclauses_2enubTagRows(v_t_2429));
        V v_x1_2435 = (g_heff_2eclauses_2etraverseC(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam1, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), heff_dup(v_rows_244)}), v_t_2430));
        switch (heff_tag_of(v_x1_2435)) {
        case TAG_Left: {
          V v_e_2436 = heff_field(v_x1_2435, 0);
          heff_take_n(v_x1_2435, 1ULL, 1);
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop_cell(v_ru_24x1_248_24Right, 1);
          return heff_tag_at(v_ru_24p_246_24PVar, TAG_Left, 1, (V[]){v_e_2436});
        }
        case TAG_Right: {
          V v_x_2437 = heff_field(v_x1_2435, 0);
          heff_take_n(v_x1_2435, 1ULL, 1);
          V v_x1_2438 = (g_heff_2eclauses_2edefaultArm_24s295(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_rows_244, heff_dup(v_c_245)));
          switch (heff_tag_of(v_x1_2438)) {
          case TAG_Left: {
            V v_e_2439 = heff_field(v_x1_2438, 0);
            heff_take_n(v_x1_2438, 1ULL, 1);
            heff_drop(v_sp_242);
            heff_drop(v_vars_243);
            heff_drop(v_c_245);
            heff_drop_cell(v_ru_24x1_248_24Right, 1);
            heff_drop(v_x_2437);
            return heff_tag_at(v_ru_24p_246_24PVar, TAG_Left, 1, (V[]){v_e_2439});
          }
          case TAG_Right: {
            V v_x_2440 = heff_field(v_x1_2438, 0);
            heff_take_n(v_x1_2438, 1ULL, 1);
            V v_t_2441 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
            V v_t_2443;
            switch (heff_tag_of(v_t_2441)) {
            case TAG_Nothing: {
              v_t_2443 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str2);
              break;
            }
            case TAG_Just: {
              V v_v_2442 = heff_field(v_t_2441, 0);
              heff_take_n(v_t_2441, 1ULL, 1);
              v_t_2443 = v_v_2442;
              break;
            }
            default: heff_nomatch(v_t_2441);
            }
            V v_t_2444 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24p_246_24PVar, TAG_IVar, 1, (V[]){v_t_2443}), heff_dup(v_sp_242)});
            V v_t_2445 = heff_tag(TAG_CMatch, 2, (V[]){v_t_2444, (g_heff_2eclauses_2eappendC(v_x_2437, v_x_2440))});
            return heff_tag_at(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2445, v_sp_242})});
          }
          default: return heff_nomatch(v_x1_2438);
          }
        }
        default: return heff_nomatch(v_x1_2435);
        }
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_246, 0ULL, 3);
    V v_x1_2449 = (g_heff_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_Left: {
      V v_e_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24Left = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      return heff_tag_at(v_ru_24x1_2449_24Left, TAG_Left, 1, (V[]){v_e_2450});
    }
    case TAG_Right: {
      V v_ru_24x1_2449_24Right = heff_take_reuse_n(v_x1_2449, 0ULL, 1);
      V v_x1_2452 = (g_heff_2eclauses_2enoLitHere(v_sp_242, heff_dup(v_c_245), v_rows_244));
      switch (heff_tag_of(v_x1_2452)) {
      case TAG_Left: {
        V v_e_2453 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        return heff_tag_at(v_ru_24x1_2449_24Right, TAG_Left, 1, (V[]){v_e_2453});
      }
      case TAG_Right: {
        V v_ru_24x1_2452_24Right = heff_take_reuse_n(v_x1_2452, 0ULL, 1);
        V v_t_2469 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam2, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
        V v_t_2470 = (g_heff_2eclauses_2ecatMaybesC(v_t_2469));
        V v_t_2471 = (g_heff_2eclauses_2enubTagRows(v_t_2470));
        V v_x1_2476 = (g_heff_2eclauses_2etraverseC(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam3, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), heff_dup(v_rows_244)}), v_t_2471));
        switch (heff_tag_of(v_x1_2476)) {
        case TAG_Left: {
          V v_e_2477 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop_cell(v_ru_24x1_2452_24Right, 1);
          return heff_tag_at(v_ru_24x1_2449_24Right, TAG_Left, 1, (V[]){v_e_2477});
        }
        case TAG_Right: {
          V v_x_2478 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_x1_2479 = (g_heff_2eclauses_2edefaultArm_24s295(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_rows_244, heff_dup(v_c_245)));
          switch (heff_tag_of(v_x1_2479)) {
          case TAG_Left: {
            V v_e_2480 = heff_field(v_x1_2479, 0);
            heff_take_n(v_x1_2479, 1ULL, 1);
            heff_drop(v_sp_242);
            heff_drop(v_vars_243);
            heff_drop(v_c_245);
            heff_drop_cell(v_ru_24x1_2452_24Right, 1);
            heff_drop(v_x_2478);
            return heff_tag_at(v_ru_24x1_2449_24Right, TAG_Left, 1, (V[]){v_e_2480});
          }
          case TAG_Right: {
            V v_x_2481 = heff_field(v_x1_2479, 0);
            heff_take_n(v_x1_2479, 1ULL, 1);
            V v_t_2482 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
            V v_t_2484;
            switch (heff_tag_of(v_t_2482)) {
            case TAG_Nothing: {
              v_t_2484 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str5);
              break;
            }
            case TAG_Just: {
              V v_v_2483 = heff_field(v_t_2482, 0);
              heff_take_n(v_t_2482, 1ULL, 1);
              v_t_2484 = v_v_2483;
              break;
            }
            default: heff_nomatch(v_t_2482);
            }
            V v_t_2485 = heff_tag(TAG_At, 2, (V[]){heff_tag_at(v_ru_24x1_2449_24Right, TAG_IVar, 1, (V[]){v_t_2484}), heff_dup(v_sp_242)});
            V v_t_2486 = heff_tag(TAG_CMatch, 2, (V[]){v_t_2485, (g_heff_2eclauses_2eappendC(v_x_2478, v_x_2481))});
            return heff_tag_at(v_ru_24x1_2452_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_2486, v_sp_242})});
          }
          default: return heff_nomatch(v_x1_2479);
          }
        }
        default: return heff_nomatch(v_x1_2476);
        }
      }
      default: return heff_nomatch(v_x1_2452);
      }
    }
    default: return heff_nomatch(v_x1_2449);
    }
  }
  case TAG_PLit: {
    V v_l_2487 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24PLit = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_x1_2488 = (g_heff_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_2488)) {
    case TAG_Left: {
      V v_e_2489 = heff_field(v_x1_2488, 0);
      heff_take_n(v_x1_2488, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_l_2487);
      return heff_tag_at(v_ru_24p_246_24PLit, TAG_Left, 1, (V[]){v_e_2489});
    }
    case TAG_Right: {
      heff_take_n(v_x1_2488, 0ULL, 1);
      heff_drop_cell(v_ru_24p_246_24PLit, 1);
      return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_l_2487; V r_ = (g_heff_2eclauses_2eliteralOf_24s297(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
    }
    default: return heff_nomatch(v_x1_2488);
    }
  }
  case TAG_PRec: {
    heff_take_n(v_p_246, 0ULL, 2);
    return (g_heff_2eclauses_2erecordOf_24s298(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245));
  }
  case TAG_PAs: {
    V v_ru_24p_246_24PAs = heff_take_reuse_n(v_p_246, 0ULL, 2);
    V v_x1_2495 = (g_heff_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_2495)) {
    case TAG_Left: {
      V v_e_2496 = heff_field(v_x1_2495, 0);
      V v_ru_24x1_2495_24Left = heff_take_reuse_n(v_x1_2495, 1ULL, 1);
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop_cell(v_ru_24p_246_24PAs, 2);
      return heff_tag_at(v_ru_24x1_2495_24Left, TAG_Left, 1, (V[]){v_e_2496});
    }
    case TAG_Right: {
      V v_ru_24x1_2495_24Right = heff_take_reuse_n(v_x1_2495, 0ULL, 1);
      V v_x1_2498 = (g_heff_2eclauses_2enoLitHere(v_sp_242, heff_dup(v_c_245), v_rows_244));
      switch (heff_tag_of(v_x1_2498)) {
      case TAG_Left: {
        V v_e_2499 = heff_field(v_x1_2498, 0);
        heff_take_n(v_x1_2498, 1ULL, 1);
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        heff_drop_cell(v_ru_24p_246_24PAs, 2);
        return heff_tag_at(v_ru_24x1_2495_24Right, TAG_Left, 1, (V[]){v_e_2499});
      }
      case TAG_Right: {
        heff_take_n(v_x1_2498, 0ULL, 1);
        V v_t_24115 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam4, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
        V v_t_24116 = (g_heff_2eclauses_2ecatMaybesC(v_t_24115));
        V v_t_24117 = (g_heff_2eclauses_2enubTagRows(v_t_24116));
        V v_x1_24122 = (g_heff_2eclauses_2etraverseC(heff_clo(g_heff_2eclauses_2ecompileAt_24s293_lam5, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), heff_dup(v_rows_244)}), v_t_24117));
        switch (heff_tag_of(v_x1_24122)) {
        case TAG_Left: {
          V v_e_24123 = heff_field(v_x1_24122, 0);
          heff_take_n(v_x1_24122, 1ULL, 1);
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop_cell(v_ru_24p_246_24PAs, 2);
          return heff_tag_at(v_ru_24x1_2495_24Right, TAG_Left, 1, (V[]){v_e_24123});
        }
        case TAG_Right: {
          V v_x_24124 = heff_field(v_x1_24122, 0);
          heff_take_n(v_x1_24122, 1ULL, 1);
          V v_x1_24125 = (g_heff_2eclauses_2edefaultArm_24s295(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_rows_244, heff_dup(v_c_245)));
          switch (heff_tag_of(v_x1_24125)) {
          case TAG_Left: {
            V v_e_24126 = heff_field(v_x1_24125, 0);
            heff_take_n(v_x1_24125, 1ULL, 1);
            heff_drop(v_sp_242);
            heff_drop(v_vars_243);
            heff_drop(v_c_245);
            heff_drop_cell(v_ru_24p_246_24PAs, 2);
            heff_drop(v_x_24124);
            return heff_tag_at(v_ru_24x1_2495_24Right, TAG_Left, 1, (V[]){v_e_24126});
          }
          case TAG_Right: {
            V v_x_24127 = heff_field(v_x1_24125, 0);
            heff_take_n(v_x1_24125, 1ULL, 1);
            V v_t_24128 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
            V v_t_24130;
            switch (heff_tag_of(v_t_24128)) {
            case TAG_Nothing: {
              v_t_24130 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str8);
              break;
            }
            case TAG_Just: {
              V v_v_24129 = heff_field(v_t_24128, 0);
              heff_take_n(v_t_24128, 1ULL, 1);
              v_t_24130 = v_v_24129;
              break;
            }
            default: heff_nomatch(v_t_24128);
            }
            V v_t_24131 = heff_tag_at(v_ru_24p_246_24PAs, TAG_At, 2, (V[]){heff_tag(TAG_IVar, 1, (V[]){v_t_24130}), heff_dup(v_sp_242)});
            V v_t_24132 = heff_tag(TAG_CMatch, 2, (V[]){v_t_24131, (g_heff_2eclauses_2eappendC(v_x_24124, v_x_24127))});
            return heff_tag_at(v_ru_24x1_2495_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_24132, v_sp_242})});
          }
          default: return heff_nomatch(v_x1_24125);
          }
        }
        default: return heff_nomatch(v_x1_24122);
        }
      }
      default: return heff_nomatch(v_x1_2498);
      }
    }
    default: return heff_nomatch(v_x1_2495);
    }
  }
  default: return heff_nomatch(v_p_246);
  }
}
V g_heff_2eclauses_2ecompileAt_24s293_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ecompileAt_24s293(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eclauses_2ecompileAt_24s293_lam0(V self, V *args) {
  V v_row_2414 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V b_0 = heff_get(v_row_2414, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x1_2417 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2ecompileAt_24s293_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_x1_2417 = v_p_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PTag: {
    V v_t_2419 = heff_field(v_x1_2417, 0);
    V v_ps_2420 = heff_field(v_x1_2417, 1);
    V v_s_2421 = heff_field(v_x1_2417, 2);
    heff_take_n(v_x1_2417, 7ULL, 3);
    V v_t_2422 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ps_2420));
    return heff_tag(TAG_Just, 1, (V[]){heff_rec(4, shape_330_14_241_314, (V[]){v_t_2419, v_t_2422, v_ps_2420, v_s_2421})});
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2417, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2417, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2eclauses_2ecompileAt_24s293_lam1(V self, V *args) {
  V v_t_2431 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  V v_sp_242 = heff_env(self)[4];
  V v_rows_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = (g_heff_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
  V v_t_2434;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_Nothing: {
    v_t_2434 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str1);
    break;
  }
  case TAG_Just: {
    V v_v_2433 = heff_field(v_t_2432, 0);
    heff_take_n(v_t_2432, 1ULL, 1);
    v_t_2434 = v_v_2433;
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  return (g_heff_2eclauses_2earmOf_24s294(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2434, v_t_2431));
}
V g_heff_2eclauses_2ecompileAt_24s293_lam2(V self, V *args) {
  V v_row_2455 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = ({ V b_0 = heff_get(v_row_2455, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2458;
  switch (heff_tag_of(v_t_2456)) {
  case TAG_Nothing: {
    v_x1_2458 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2ecompileAt_24s293_str3)});
    break;
  }
  case TAG_Just: {
    V v_p_2457 = heff_field(v_t_2456, 0);
    heff_take_n(v_t_2456, 1ULL, 1);
    v_x1_2458 = v_p_2457;
    break;
  }
  default: heff_nomatch(v_t_2456);
  }
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PTag: {
    V v_t_2460 = heff_field(v_x1_2458, 0);
    V v_ps_2461 = heff_field(v_x1_2458, 1);
    V v_s_2462 = heff_field(v_x1_2458, 2);
    heff_take_n(v_x1_2458, 7ULL, 3);
    V v_t_2463 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ps_2461));
    return heff_tag(TAG_Just, 1, (V[]){heff_rec(4, shape_330_14_241_314, (V[]){v_t_2460, v_t_2463, v_ps_2461, v_s_2462})});
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2458, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2458, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2eclauses_2ecompileAt_24s293_lam3(V self, V *args) {
  V v_t_2472 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  V v_sp_242 = heff_env(self)[4];
  V v_rows_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2473 = (g_heff_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
  V v_t_2475;
  switch (heff_tag_of(v_t_2473)) {
  case TAG_Nothing: {
    v_t_2475 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str4);
    break;
  }
  case TAG_Just: {
    V v_v_2474 = heff_field(v_t_2473, 0);
    heff_take_n(v_t_2473, 1ULL, 1);
    v_t_2475 = v_v_2474;
    break;
  }
  default: heff_nomatch(v_t_2473);
  }
  return (g_heff_2eclauses_2earmOf_24s294(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2475, v_t_2472));
}
V g_heff_2eclauses_2ecompileAt_24s293_lam4(V self, V *args) {
  V v_row_24101 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = ({ V b_0 = heff_get(v_row_24101, LBL_pats); V a_1 = v_c_245; V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_24104;
  switch (heff_tag_of(v_t_24102)) {
  case TAG_Nothing: {
    v_x1_24104 = heff_tag(TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2ecompileAt_24s293_str6)});
    break;
  }
  case TAG_Just: {
    V v_p_24103 = heff_field(v_t_24102, 0);
    heff_take_n(v_t_24102, 1ULL, 1);
    v_x1_24104 = v_p_24103;
    break;
  }
  default: heff_nomatch(v_t_24102);
  }
  switch (heff_tag_of(v_x1_24104)) {
  case TAG_PVar: {
    heff_take_n(v_x1_24104, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PTag: {
    V v_t_24106 = heff_field(v_x1_24104, 0);
    V v_ps_24107 = heff_field(v_x1_24104, 1);
    V v_s_24108 = heff_field(v_x1_24104, 2);
    heff_take_n(v_x1_24104, 7ULL, 3);
    V v_t_24109 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ps_24107));
    return heff_tag(TAG_Just, 1, (V[]){heff_rec(4, shape_330_14_241_314, (V[]){v_t_24106, v_t_24109, v_ps_24107, v_s_24108})});
  }
  case TAG_PLit: {
    heff_take_n(v_x1_24104, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_24104, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_24104, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_24104);
  }
}
V g_heff_2eclauses_2ecompileAt_24s293_lam5(V self, V *args) {
  V v_t_24118 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  V v_sp_242 = heff_env(self)[4];
  V v_rows_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24119 = (g_heff_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
  V v_t_24121;
  switch (heff_tag_of(v_t_24119)) {
  case TAG_Nothing: {
    v_t_24121 = ((V)&g_heff_2eclauses_2ecompileAt_24s293_str7);
    break;
  }
  case TAG_Just: {
    V v_v_24120 = heff_field(v_t_24119, 0);
    heff_take_n(v_t_24119, 1ULL, 1);
    v_t_24121 = v_v_24120;
    break;
  }
  default: heff_nomatch(v_t_24119);
  }
  return (g_heff_2eclauses_2earmOf_24s294(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_24121, v_t_24118));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eclauses_2ecompilePeeled_24s292_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eclauses_2ecompilePeeled_24s292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecompilePeeled_24s292_entry, 5, 0};

V g_heff_2eclauses_2ecompilePeeled_24s292(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244) {
top: ;
  switch (heff_tag_of(v_rows_244)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_vars_243);
    V v_t_245 = heff_tag(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    return heff_tag(TAG_Right, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_row_246 = heff_dup(heff_field(v_rows_244, 0));
    V v_t_248 = ({ V b_0 = heff_get(heff_dup(v_row_246), LBL_pats); V a_1 = MK_INT(0LL); V r_ = (g_heff_2eclauses_2efindTagLit(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop_tag(v_rows_244, 2);
      V v_t_249 = (g_heff_2eclauses_2ezipC(v_vars_243, heff_get(heff_dup(v_row_246), LBL_pats)));
      return heff_tag(TAG_Right, 1, (V[]){({ V a_0 = heff_get(v_row_246, LBL_rhs); V a_1 = v_t_249; V r_ = (g_prelude_2efoldl_24s291(a_0, a_1)); heff_drop(v_t_249); r_; })});
    }
    case TAG_Just: {
      V v_c_2410 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2411 = ({ V b_0 = heff_get(v_row_246, LBL_pats); V a_1 = heff_dup(v_c_2410); V r_ = (g_heff_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_at(v_ru_24t_248_24Just, TAG_PVar, 1, (V[]){((V)&g_heff_2eclauses_2ecompilePeeled_24s292_str0)});
        break;
      }
      case TAG_Just: {
        V v_p_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        v_t_2413 = v_p_2412;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      return (g_heff_2eclauses_2ecompileAt_24s293(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_2410, v_t_2413));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_rows_244);
  }
}
V g_heff_2eclauses_2ecompilePeeled_24s292_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ecompilePeeled_24s292(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eclauses_2edesugarBody_lam0(V self, V *args);
V g_heff_2eclauses_2edesugarBody_lam1(V self, V *args);
V g_heff_2eclauses_2edesugarBody_lam2(V self, V *args);
V g_heff_2eclauses_2edesugarBody_lam3(V self, V *args);
V g_heff_2eclauses_2edesugarBody_lam4(V self, V *args);
Clo g_heff_2eclauses_2edesugarBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edesugarBody_entry, 6, 0};

V g_heff_2eclauses_2edesugarBody(V v_f_240, V v_params_241, V v_sp_242, V v_rows_243, V v_arity_244, V v_used_245) {
top: ;
  V v_t_246 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(v_arity_244)));
  V v_bound_248 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edesugarBody_lam0, 1, 3, (V[]){heff_dup(v_used_245), heff_dup(v_params_241), heff_dup(v_rows_243)}), v_t_246));
  V v_t_249 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(v_arity_244)));
  V v_vars_2411 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edesugarBody_lam1, 1, 3, (V[]){heff_dup(v_used_245), heff_dup(v_params_241), heff_dup(v_rows_243)}), v_t_249));
  V v_t_2413 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edesugarBody_lam2, 1, 1, (V[]){heff_dup(v_vars_2411)}), heff_dup(v_rows_243)));
  V v_x1_2414 = (g_heff_2eclauses_2ecompilePeeled_24s292(heff_dup(v_used_245), v_bound_248, heff_dup(v_sp_242), v_vars_2411, v_t_2413));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Left: {
    V v_e_2415 = heff_field(v_x1_2414, 0);
    V v_ru_24x1_2414_24Left = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
    heff_drop(v_sp_242);
    heff_drop(v_rows_243);
    heff_drop(v_arity_244);
    heff_drop(v_used_245);
    return heff_tag_at(v_ru_24x1_2414_24Left, TAG_Left, 1, (V[]){v_e_2415});
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x1_2414, 0);
    V v_ru_24x1_2414_24Right = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
    V v_t_2417 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_params_241));
    V v_t_2418 = (g_heff_2eclauses_2eupToGo(MK_INT(0LL), v_arity_244));
    V v_t_2420 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2edesugarBody_lam3, 1, 3, (V[]){v_used_245, heff_dup(v_params_241), v_rows_243}), v_t_2418));
    V v_t_2421 = (g_heff_2eclauses_2edropC(v_t_2417, v_t_2420));
    return heff_tag_at(v_ru_24x1_2414_24Right, TAG_Right, 1, (V[]){({ V a_0 = heff_clo(g_heff_2eclauses_2edesugarBody_lam4, 2, 1, (V[]){v_sp_242}); V a_1 = v_x_2416; V a_2 = v_t_2421; V r_ = heff_tr(g_heff_2eclauses_2efoldr2(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; })});
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
V g_heff_2eclauses_2edesugarBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2edesugarBody(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eclauses_2edesugarBody_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_used_245 = heff_env(self)[0];
  V v_params_241 = heff_env(self)[1];
  V v_rows_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_used_245; V a_1 = v_params_241; V a_2 = v_rows_243; V a_3 = v_i_247; V r_ = (g_heff_2eclauses_2ecolName(a_0, a_1, a_2, a_3)); heff_drop(v_used_245); heff_drop(v_params_241); r_; });
}
V g_heff_2eclauses_2edesugarBody_lam1(V self, V *args) {
  V v_i_2410 = args[0];
  V v_used_245 = heff_env(self)[0];
  V v_params_241 = heff_env(self)[1];
  V v_rows_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_used_245; V a_1 = v_params_241; V a_2 = v_rows_243; V a_3 = v_i_2410; V r_ = (g_heff_2eclauses_2ecolName(a_0, a_1, a_2, a_3)); heff_drop(v_used_245); heff_drop(v_params_241); r_; });
}
V g_heff_2eclauses_2edesugarBody_lam2(V self, V *args) {
  V v_row_2412 = args[0];
  V v_vars_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eclauses_2epeelCols(v_vars_2411, heff_get(heff_dup(v_row_2412), LBL_pats), heff_get(v_row_2412, LBL_rhs)));
}
V g_heff_2eclauses_2edesugarBody_lam3(V self, V *args) {
  V v_i_2419 = args[0];
  V v_used_245 = heff_env(self)[0];
  V v_params_241 = heff_env(self)[1];
  V v_rows_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_used_245; V a_1 = v_params_241; V a_2 = v_rows_243; V a_3 = v_i_2419; V r_ = (g_heff_2eclauses_2ecolName(a_0, a_1, a_2, a_3)); heff_drop(v_used_245); heff_drop(v_params_241); r_; });
}
V g_heff_2eclauses_2edesugarBody_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_b_2423 = args[1];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2426;
  switch (heff_tag_of(v_b_2423)) {
  case TAG_At: {
    V v_s_2425 = heff_dup(heff_field(v_b_2423, 1));
    v_b_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_b_2423);
  }
  V v_t_2427 = heff_rec(2, shape_320_83, (V[]){heff_get(heff_dup(v_sp_242), LBL_start), heff_get(v_b_2426, LBL_end)});
  return heff_tag(TAG_At, 2, (V[]){heff_tag(TAG_CLam, 3, (V[]){v_x_2422, v_sp_242, v_b_2423}), v_t_2427});
}
Clo g_heff_2eclauses_2etraverseC_24s299_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_24s299_entry, 1, 0};

V g_heff_2eclauses_2etraverseC_24s299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_ps_247 = heff_field(v_x11_243, 2);
        V v_rhs_248 = heff_field(v_x11_243, 3);
        heff_take_n(v_x11_243, 12ULL, 4);
        V v_x1_249 = (g_heff_2eclauses_2etraverseC_24s274(v_ps_247));
        switch (heff_tag_of(v_x1_249)) {
        case TAG_Left: {
          V v_e_2410 = heff_field(v_x1_249, 0);
          V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
          heff_drop(v_rhs_248);
          v_x1_2412 = heff_tag_at(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
          break;
        }
        case TAG_Right: {
          V v_x_2411 = heff_field(v_x1_249, 0);
          V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
          v_x1_2412 = heff_tag_at(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){heff_rec(2, shape_241_279, (V[]){v_x_2411, v_rhs_248})});
          break;
        }
        default: heff_nomatch(v_x1_249);
        }
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Left = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at(v_ru_24x1_2412_24Left, TAG_Left, 1, (V[]){v_e_2413});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Right = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      V v_x1_2415 = (g_heff_2eclauses_2etraverseC_24s299(v_xs_242));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Left: {
        V v_e_2416 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_2414);
        return heff_tag_at(v_ru_24x1_2412_24Right, TAG_Left, 1, (V[]){v_e_2416});
      }
      case TAG_Right: {
        V v_x_2417 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2412_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, v_x_2417})});
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2etraverseC_24s299_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC_24s299(a[0]);
}
Clo g_heff_2eclauses_2econcatMapC_24s300_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s300_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s300(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eclauses_2epatVars(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eclauses_2econcatMapC_24s300(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s300_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s300(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eclauses_2econcatMapC_24s301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2econcatMapC_24s301_entry, 1, 0};

V g_heff_2eclauses_2econcatMapC_24s301(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = ({ V b_0 = heff_get(heff_dup(v_x_241), LBL_pats); V r_ = (g_heff_2eclauses_2econcatMapC_24s300(b_0)); heff_drop(b_0); r_; });
    V v_t_244 = (g_heff_2eclauses_2eidentsChkF_24s280(heff_get(heff_dup(v_x_241), LBL_rhs)));
    V v_t_245 = (g_heff_2eclauses_2eappendC(v_t_243, v_t_244));
    V v_t_246 = (g_heff_2eclauses_2econcatMapC_24s301(v_xs_242));
    return (g_heff_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2econcatMapC_24s301_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eclauses_2econcatMapC_24s301(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[43]; } g_heff_2eclauses_2edesugar_str0 = {{0x80000000u, K_STR, 0}, 43, 43, {97, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32, 98, 121, 32, 101, 113, 117, 97, 116, 105, 111, 110, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 113, 117, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eclauses_2edesugar_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {101, 118, 101, 114, 121, 32, 101, 113, 117, 97, 116, 105, 111, 110, 32, 111, 102, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eclauses_2edesugar_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {96, 32, 104, 97, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eclauses_2edesugar_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 112, 97, 116, 116, 101, 114, 110, 40, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eclauses_2edesugar_str4 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 104, 101, 32, 101, 113, 117, 97, 116, 105, 111, 110, 115, 32, 111, 102, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2eclauses_2edesugar_str5 = {{0x80000000u, K_STR, 0}, 37, 37, {96, 32, 109, 97, 116, 99, 104, 32, 102, 101, 119, 101, 114, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 116, 104, 97, 110, 32, 105, 116, 32, 110, 97, 109, 101, 115}};
V g_heff_2eclauses_2edesugar_lam0(V self, V *args);
Clo g_heff_2eclauses_2edesugar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2edesugar_entry, 4, 0};

V g_heff_2eclauses_2edesugar(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eclauses_2etraverseC_24s299(v_eqNs_242));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Left: {
    V v_e_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_params_241);
    heff_drop(v_sp_243);
    return heff_tag_at(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
  }
  case TAG_Right: {
    V v_x_246 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_249;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_x1_249 = heff_tag_at(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){heff_dup(v_sp_243), ((V)&g_heff_2eclauses_2edesugar_str0)})});
      break;
    }
    case TAG_Cons: {
      V v_r_247 = heff_dup(heff_field(v_x_246, 0));
      v_x1_249 = heff_tag_at(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_r_247, LBL_pats); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; })});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x1_249, 0);
      V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_params_241);
      heff_drop(v_sp_243);
      heff_drop(v_x_246);
      return heff_tag_at(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x1_249, 0);
      V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
      V v_x1_2420 = (g_heff_2eclauses_2eforC(v_x_246, heff_clo(g_heff_2eclauses_2edesugar_lam0, 1, 2, (V[]){heff_dup(v_x_2411), heff_dup(v_f_240)})));
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_Left: {
        V v_e_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_params_241);
        heff_drop(v_sp_243);
        heff_drop(v_x_246);
        heff_drop(v_x_2411);
        return heff_tag_at(v_ru_24x1_249_24Right, TAG_Left, 1, (V[]){v_e_2421});
      }
      case TAG_Right: {
        V v_ru_24x1_2420_24Right = heff_take_reuse_n(v_x1_2420, 0ULL, 1);
        V v_t_2423 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_params_241));
        V v_t_2424 = heff_intLt(heff_dup(v_x_2411), v_t_2423);
        V v_e_2426;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_True: {
          V v_t_2425 = heff_strAppend(((V)&g_heff_2eclauses_2edesugar_str4), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2eclauses_2edesugar_str5)));
          v_e_2426 = heff_tag_at(v_ru_24x1_249_24Right, TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){heff_dup(v_sp_243), v_t_2425})});
          break;
        }
        case TAG_False: {
          v_e_2426 = heff_tag_at(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_x1_2427 = v_e_2426;
        switch (heff_tag_of(v_x1_2427)) {
        case TAG_Left: {
          V v_e_2428 = heff_field(v_x1_2427, 0);
          heff_take_n(v_x1_2427, 1ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_params_241);
          heff_drop(v_sp_243);
          heff_drop(v_x_246);
          heff_drop(v_x_2411);
          return heff_tag_at(v_ru_24x1_2420_24Right, TAG_Left, 1, (V[]){v_e_2428});
        }
        case TAG_Right: {
          heff_take_n(v_x1_2427, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2420_24Right, 1);
          V v_t_2430 = (g_heff_2eclauses_2econcatMapC_24s301(v_x_246));
          V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_240), NTAG(TAG_Nil)});
          V v_t_2432 = (g_heff_2eclauses_2eappendC(heff_dup(v_params_241), v_t_2431));
          V v_t_2433 = (g_heff_2eclauses_2eappendC(v_t_2430, v_t_2432));
          return ({ V a_0 = v_f_240; V a_1 = v_params_241; V a_2 = v_sp_243; V a_3 = v_x_246; V a_4 = v_x_2411; V a_5 = v_t_2433; V r_ = (g_heff_2eclauses_2edesugarBody(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_f_240); heff_drop(v_params_241); r_; });
        }
        default: return heff_nomatch(v_x1_2427);
        }
      }
      default: return heff_nomatch(v_x1_2420);
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2eclauses_2edesugar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2edesugar(a[0], a[1], a[2], a[3]);
}
V g_heff_2eclauses_2edesugar_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(heff_dup(v_r_2412), LBL_pats); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2414 = heff_intEq(v_t_2413, heff_dup(v_x_2411));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_True: {
    heff_drop(v_r_2412);
    heff_drop(v_x_2411);
    heff_drop(v_f_240);
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_False: {
    V v_t_2415 = heff_get(v_r_2412, LBL_rhs);
    V v_span_2418;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_At: {
      V v_s_2417 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 2ULL, 2);
      v_span_2418 = v_s_2417;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eclauses_2edesugar_str1), heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2eclauses_2edesugar_str2), heff_strAppend(heff_intShow(v_x_2411), ((V)&g_heff_2eclauses_2edesugar_str3)))));
    return heff_tag(TAG_Left, 1, (V[]){heff_rec(2, shape_314_193, (V[]){v_span_2418, v_t_2419})});
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
V g_heff_2eclauses_2ecaseTreeOf_lam0(V self, V *args);
Clo g_heff_2eclauses_2ecaseTreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2ecaseTreeOf_entry, 4, 0};

V g_heff_2eclauses_2ecaseTreeOf(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2emap(heff_clo(g_heff_2eclauses_2ecaseTreeOf_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  V v_x1_249 = (g_heff_2eclauses_2ecompilePeeled_24s292(heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}), v_t_244, v_sp_240, v_t_245, v_t_248));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    heff_drop(v_x_243);
    return heff_tag_at(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x_2411 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){heff_rec(2, shape_290_348, (V[]){v_x_243, v_x_2411})});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eclauses_2ecaseTreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2ecaseTreeOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eclauses_2ecaseTreeOf_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eclauses_2epeelCols(v_t_247, heff_get(heff_dup(v_row_246), LBL_pats), heff_get(v_row_246, LBL_rhs)));
}
Clo g_heff_2eclauses_2etraverseC_24s302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eclauses_2etraverseC_24s302_entry, 1, 0};

V g_heff_2eclauses_2etraverseC_24s302(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_rhs_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 2);
        V v_x1_247 = (g_heff_2eclauses_2epat(v_p_245));
        switch (heff_tag_of(v_x1_247)) {
        case TAG_Left: {
          V v_e_248 = heff_field(v_x1_247, 0);
          V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_rhs_246);
          v_x1_2411 = heff_tag_at(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
          break;
        }
        case TAG_Right: {
          V v_x_249 = heff_field(v_x1_247, 0);
          V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 1ULL, 1);
          V v_t_2410 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_249, NTAG(TAG_Nil)});
          v_x1_2411 = heff_tag_at(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){heff_rec(2, shape_241_279, (V[]){v_t_2410, v_rhs_246})});
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Left = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      heff_drop(v_xs_242);
      return heff_tag_at(v_ru_24x1_2411_24Left, TAG_Left, 1, (V[]){v_e_2412});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Right = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      V v_x1_2414 = (g_heff_2eclauses_2etraverseC_24s302(v_xs_242));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        heff_drop(v_x_2413);
        return heff_tag_at(v_ru_24x1_2411_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x_2416 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2411_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_x_2416})});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eclauses_2etraverseC_24s302_entry(V self, V *a) {
  (void)self;
  return g_heff_2eclauses_2etraverseC_24s302(a[0]);
}