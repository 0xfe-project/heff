// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {13}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2eprint_2eescChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eescChar_entry, 1, 0};

V g_heff_2eprint_2eescChar(V v_c_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eprint_2eescChar_str1);
  }
  case TAG_False: {
    V v_t_242 = heff_strEq(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str2));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eprint_2eescChar_str3);
    }
    case TAG_False: {
      V v_t_243 = heff_strEq(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str4));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eprint_2eescChar_str5);
      }
      case TAG_False: {
        V v_t_244 = heff_strEq(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str6));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eprint_2eescChar_str7);
        }
        case TAG_False: {
          V v_t_245 = heff_strEq(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str8));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eprint_2eescChar_str9);
          }
          case TAG_False: {
            return v_c_240;
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eprint_2eescChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2eescChar(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescFrom_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eprint_2eescFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eescFrom_entry, 2, 0};

V g_heff_2eprint_2eescFrom(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2eprint_2eescChar(v_t_243));
    return heff_strAppend(v_t_244, (g_heff_2eprint_2eescFrom(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)))));
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eprint_2eescFrom_str0);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eprint_2eescFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2eescFrom(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2ecommaSep_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2ecommaSep_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_heff_2eprint_2ecommaSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2ecommaSep_entry, 1, 0};

V g_heff_2eprint_2ecommaSep(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eprint_2ecommaSep_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eprint_2ecommaSep_str1), (g_heff_2eprint_2ecommaSep(v_x12_242))));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eprint_2ecommaSep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2ecommaSep(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2edictOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2edictOf_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eprint_2edictOf_lam0(V self, V *args);
Clo g_heff_2eprint_2edictOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2edictOf_entry, 2, 0};

V g_heff_2eprint_2edictOf(V v_f_240, V v_d_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_241), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_241, LBL_values));
  V v_t_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_xs_2411 = (g_prelude_2emap(heff_clo(g_heff_2eprint_2edictOf_lam0, 1, 1, (V[]){v_f_240}), v_t_244));
  V v_t_2412 = ({ V a_0 = v_xs_2411; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2411); r_; });
  V v_t_2413 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_str5), heff_strAppend(v_t_2412, ((V)&g_heff_2eprint_2edictOf_str6)));
  return heff_strAppend(((V)&g_heff_2eprint_2edictOf_str7), heff_strAppend(v_t_2413, ((V)&g_heff_2eprint_2edictOf_str8)));
}
V g_heff_2eprint_2edictOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2edictOf(a[0], a[1]);
}
V g_heff_2eprint_2edictOf_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_v_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_t_248 = (g_heff_2eprint_2eescFrom(v_k_246, MK_INT(0LL)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_str0), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2edictOf_str1)));
    V v_t_2410 = heff_tr(heff_apply(v_f_240, 1, (V[]){v_v_247}));
    return heff_strAppend(((V)&g_heff_2eprint_2edictOf_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eprint_2edictOf_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2eprint_2edictOf_str4)))));
  }
  default: return heff_nomatch(v_p_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eabsOf_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 77, 107, 65, 98, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eabsOf_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 65, 98, 115, 67, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eabsOf_entry, 2, 0};

V g_heff_2eprint_2eabsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkAbs: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_242), MK_INT(0LL)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eabsOf_str1)));
    V v_t_246 = heff_tr(heff_apply(v_f_240, 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str3), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2eabsOf_str4)))));
  }
  case TAG_AbsConst: {
    V v_b_247 = heff_field(v_x2_241, 0);
    V v_t_248 = heff_tr(heff_apply(v_f_240, 1, (V[]){heff_dup(v_b_247)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2eabsOf_str6)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eabsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eabsOf(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2earmOf_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2earmOf_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2earmOf_entry, 2, 0};

V g_heff_2eprint_2earmOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_xs_244 = (g_prelude_2emap_24s416(heff_arrayToList(heff_dup(v_xs_242))));
    V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2earmOf_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2earmOf_str3)));
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eprint_2earmOf_str4), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eprint_2earmOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2earmOf_str6)))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2earmOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2earmOf(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 76, 111, 99, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 71, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str13 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 76, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 110, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 111, 106, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str27 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str29 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 84, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 77, 97, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_str37 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 83, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 83, 73, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {83, 79, 112, 97, 113, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 65, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str45 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 82, 101, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str47 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 70, 105, 120, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_str52 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 73, 109, 112, 108, 105, 99, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str57 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 105, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str59 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str63 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTermF_str65 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 83, 77, 101, 116, 97, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str69 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_str71 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 76, 105, 116, 73, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_str73 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str77 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 76, 105, 116, 83, 116, 114, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTermF_entry, 2, 0};

V g_heff_2eprint_2eshowTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_243 = heff_intLt(heff_dup(v_i_242), MK_INT(0LL));
    V v_t_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_242)));
      v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTermF_str1)));
      break;
    }
    case TAG_False: {
      v_t_245 = heff_intShow(heff_dup(v_i_242));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2eshowTermF_str3)));
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_247 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_246), MK_INT(0LL)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2eshowTermF_str5)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str6), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2eshowTermF_str7)));
  }
  case TAG_SCode: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_249)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str8), heff_strAppend(v_t_2410, ((V)&g_heff_2eprint_2eshowTermF_str9)));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_f_2411)}));
    V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_a_2412)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str10), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str11), heff_strAppend(v_t_2414, ((V)&g_heff_2eprint_2eshowTermF_str12)))));
  }
  case TAG_SLam: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_a_2415)}));
    V v_t_2418 = (g_heff_2eprint_2eabsOf(heff_get(v_r_240, LBL_el), v_b_2416));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str13), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str14), heff_strAppend(v_t_2418, ((V)&g_heff_2eprint_2eshowTermF_str15)))));
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_x2_241, 0);
    V v_t_2420 = (g_heff_2eprint_2edictOf(heff_get(v_r_240, LBL_el), heff_dup(v_d_2419)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str16), heff_strAppend(v_t_2420, ((V)&g_heff_2eprint_2eshowTermF_str17)));
  }
  case TAG_SProj: {
    V v_t_2421 = heff_field(v_x2_241, 0);
    V v_x_2422 = heff_field(v_x2_241, 1);
    V v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2421)}));
    V v_t_2424 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2422), MK_INT(0LL)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str18), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTermF_str19)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str20), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str21), heff_strAppend(v_t_2425, ((V)&g_heff_2eprint_2eshowTermF_str22)))));
  }
  case TAG_STag: {
    V v_x_2426 = heff_field(v_x2_241, 0);
    V v_ts_2427 = heff_field(v_x2_241, 1);
    V v_t_2428 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2426), MK_INT(0LL)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str23), heff_strAppend(v_t_2428, ((V)&g_heff_2eprint_2eshowTermF_str24)));
    V v_xs_2430 = (g_prelude_2emap(heff_get(v_r_240, LBL_el), heff_arrayToList(heff_dup(v_ts_2427))));
    V v_t_2431 = ({ V a_0 = v_xs_2430; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2430); r_; });
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str25), heff_strAppend(v_t_2431, ((V)&g_heff_2eprint_2eshowTermF_str26)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str27), heff_strAppend(v_t_2432, ((V)&g_heff_2eprint_2eshowTermF_str28)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str29), heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str30), heff_strAppend(v_t_2433, ((V)&g_heff_2eprint_2eshowTermF_str31)))));
  }
  case TAG_SMatch: {
    V v_t_2434 = heff_field(v_x2_241, 0);
    V v_arms_2435 = heff_field(v_x2_241, 1);
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_t_2434)}));
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2eprint_2earmOf_clo), 1, (V[]){v_r_240}));
    V v_t_2438 = (g_heff_2eprint_2edictOf(v_t_2437, heff_dup(v_arms_2435)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str32), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str33), heff_strAppend(v_t_2438, ((V)&g_heff_2eprint_2eshowTermF_str34)))));
  }
  case TAG_SSpecialize: {
    V v_t_2439 = heff_field(v_x2_241, 0);
    V v_x_2440 = heff_field(v_x2_241, 1);
    V v_t_27_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_t_2439)}));
    V v_t_2443 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2440), MK_INT(0LL)));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str35), heff_strAppend(v_t_2443, ((V)&g_heff_2eprint_2eshowTermF_str36)));
    V v_t_2445 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_27_2441)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str37), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str38), heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str39), heff_strAppend(v_t_2445, ((V)&g_heff_2eprint_2eshowTermF_str40)))))));
  }
  case TAG_SIs: {
    V v_t_2446 = heff_field(v_x2_241, 0);
    V v_t_2447 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2446)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str41), heff_strAppend(v_t_2447, ((V)&g_heff_2eprint_2eshowTermF_str42)));
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTermF_str43);
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTermF_str44);
  }
  case TAG_SRec: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_t_2449 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2448)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str45), heff_strAppend(v_t_2449, ((V)&g_heff_2eprint_2eshowTermF_str46)));
  }
  case TAG_SFix: {
    V v_a_2450 = heff_field(v_x2_241, 0);
    V v_b_2451 = heff_field(v_x2_241, 1);
    V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_a_2450)}));
    V v_t_2453 = (g_heff_2eprint_2eabsOf(heff_get(v_r_240, LBL_el), v_b_2451));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str47), heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str48), heff_strAppend(v_t_2453, ((V)&g_heff_2eprint_2eshowTermF_str49)))));
  }
  case TAG_SImplicit: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_t_2455 = heff_field(v_x2_241, 1);
    V v_t_2456 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2454), MK_INT(0LL)));
    V v_t_2457 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str50), heff_strAppend(v_t_2456, ((V)&g_heff_2eprint_2eshowTermF_str51)));
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2455)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str52), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str53), heff_strAppend(v_t_2458, ((V)&g_heff_2eprint_2eshowTermF_str54)))));
  }
  case TAG_SPrim: {
    V v_x_2459 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2460 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2459), MK_INT(0LL)));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str55), heff_strAppend(v_t_2460, ((V)&g_heff_2eprint_2eshowTermF_str56)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str57), heff_strAppend(v_t_2461, ((V)&g_heff_2eprint_2eshowTermF_str58)));
  }
  case TAG_SMetaApp: {
    V v_m_2462 = heff_field(v_x2_241, 0);
    V v_idxs_2463 = heff_field(v_x2_241, 1);
    V v_a_2464 = heff_field(v_x2_241, 2);
    V v_t_2465 = heff_intLt(heff_dup(v_m_2462), MK_INT(0LL));
    V v_t_2467;
    switch (heff_tag_of(v_t_2465)) {
    case TAG_True: {
      V v_t_2466 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2462)));
      v_t_2467 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str59), heff_strAppend(v_t_2466, ((V)&g_heff_2eprint_2eshowTermF_str60)));
      break;
    }
    case TAG_False: {
      v_t_2467 = heff_intShow(heff_dup(v_m_2462));
      break;
    }
    default: heff_nomatch(v_t_2465);
    }
    V v_xs_2468 = (g_prelude_2emap_24s417(heff_arrayToList(heff_dup(v_idxs_2463))));
    V v_t_2469 = ({ V a_0 = v_xs_2468; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2468); r_; });
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str61), heff_strAppend(v_t_2469, ((V)&g_heff_2eprint_2eshowTermF_str62)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str63), heff_strAppend(v_t_2470, ((V)&g_heff_2eprint_2eshowTermF_str64)));
    V v_t_2472 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_2464)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str65), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str66), heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str67), heff_strAppend(v_t_2472, ((V)&g_heff_2eprint_2eshowTermF_str68)))))));
  }
  case TAG_SLitInt: {
    V v_n_2473 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2474 = heff_intLt(heff_dup(v_n_2473), MK_INT(0LL));
    V v_t_2476;
    switch (heff_tag_of(v_t_2474)) {
    case TAG_True: {
      V v_t_2475 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2473)));
      v_t_2476 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str69), heff_strAppend(v_t_2475, ((V)&g_heff_2eprint_2eshowTermF_str70)));
      break;
    }
    case TAG_False: {
      v_t_2476 = heff_intShow(heff_dup(v_n_2473));
      break;
    }
    default: heff_nomatch(v_t_2474);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str71), heff_strAppend(v_t_2476, ((V)&g_heff_2eprint_2eshowTermF_str72)));
  }
  case TAG_SLitFloat: {
    V v_x_2477 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str73), heff_strAppend(heff_floatShow(heff_dup(v_x_2477)), ((V)&g_heff_2eprint_2eshowTermF_str74)));
  }
  case TAG_SLitString: {
    V v_s_2478 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2479 = (g_heff_2eprint_2eescFrom(heff_dup(v_s_2478), MK_INT(0LL)));
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str75), heff_strAppend(v_t_2479, ((V)&g_heff_2eprint_2eshowTermF_str76)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str77), heff_strAppend(v_t_2480, ((V)&g_heff_2eprint_2eshowTermF_str78)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eshowTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTermF(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 109, 97, 108, 108, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {76, 97, 114, 103, 101, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 83, 85, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 68, 101, 99, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {69, 120, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 109, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_str12 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 70, 117, 110, 99, 116, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str17 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_str20 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 82, 101, 99, 111, 114, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_str26 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str28 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 83, 117, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_str30 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 73, 115, 84, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 80, 114, 105, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTypeF_str33 = {{0x80000000u, K_STR, 0}, 10, 10, {83, 80, 114, 105, 109, 70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_str34 = {{0x80000000u, K_STR, 0}, 11, 11, {83, 80, 114, 105, 109, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_str35 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 80, 114, 105, 109, 65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eprint_2eshowTypeF_lam0(V self, V *args);
Clo g_heff_2eprint_2eshowTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTypeF_entry, 2, 0};

V g_heff_2eprint_2eshowTypeF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    V v_u_242 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_243;
    switch (heff_tag_of(v_u_242)) {
    case TAG_SmallU: {
      v_t_243 = ((V)&g_heff_2eprint_2eshowTypeF_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_243 = ((V)&g_heff_2eprint_2eshowTypeF_str1);
      break;
    }
    default: heff_nomatch(v_u_242);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str2), heff_strAppend(v_t_243, ((V)&g_heff_2eprint_2eshowTypeF_str3)));
  }
  case TAG_SDecode: {
    V v_t_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_244)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str4), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2eshowTypeF_str5)));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x2_241, 0);
    V v_dom_247 = heff_field(v_x2_241, 1);
    V v_cod_248 = heff_field(v_x2_241, 2);
    V v_implicit_249 = heff_field(v_x2_241, 3);
    V v_t_2410;
    switch (heff_tag_of(v_level_246)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_str6);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_str8);
      break;
    }
    default: heff_nomatch(v_level_246);
    }
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_dom_247)}));
    V v_t_2412 = (g_heff_2eprint_2eabsOf(heff_get(v_r_240, LBL_ty), v_cod_248));
    V v_t_2413;
    switch (heff_tag_of(v_implicit_249)) {
    case TAG_Expl: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_str11);
      break;
    }
    default: heff_nomatch(v_implicit_249);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str12), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str13), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str14), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str15), heff_strAppend(v_t_2413, ((V)&g_heff_2eprint_2eshowTypeF_str16)))))))));
  }
  case TAG_SRecord: {
    V v_level_2414 = heff_field(v_x2_241, 0);
    V v_fieldTypes_2415 = heff_field(v_x2_241, 1);
    V v_defaults_2416 = heff_field(v_x2_241, 2);
    V v_t_2417;
    switch (heff_tag_of(v_level_2414)) {
    case TAG_Small: {
      v_t_2417 = ((V)&g_heff_2eprint_2eshowTypeF_str17);
      break;
    }
    case TAG_Large: {
      v_t_2417 = ((V)&g_heff_2eprint_2eshowTypeF_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2417 = ((V)&g_heff_2eprint_2eshowTypeF_str19);
      break;
    }
    default: heff_nomatch(v_level_2414);
    }
    V v_t_2418 = (g_heff_2eprint_2edictOf(heff_get(heff_dup(v_r_240), LBL_ty), heff_dup(v_fieldTypes_2415)));
    V v_t_2419 = (g_heff_2eprint_2edictOf(heff_get(v_r_240, LBL_el), heff_dup(v_defaults_2416)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str20), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str21), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str22), heff_strAppend(v_t_2419, ((V)&g_heff_2eprint_2eshowTypeF_str23)))))));
  }
  case TAG_SSum: {
    V v_st_2420 = heff_field(v_x2_241, 0);
    V v_t_2425 = (g_heff_2eprint_2edictOf(heff_clo(g_heff_2eprint_2eshowTypeF_lam0, 1, 1, (V[]){v_r_240}), heff_dup(v_st_2420)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str28), heff_strAppend(v_t_2425, ((V)&g_heff_2eprint_2eshowTypeF_str29)));
  }
  case TAG_SIsTy: {
    V v_t_2426 = heff_field(v_x2_241, 0);
    V v_t_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_t_2426)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str30), heff_strAppend(v_t_2427, ((V)&g_heff_2eprint_2eshowTypeF_str31)));
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str32);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str33);
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str34);
  }
  case TAG_SPrimArray: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    V v_t_2429 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_2428)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str35), heff_strAppend(v_t_2429, ((V)&g_heff_2eprint_2eshowTypeF_str36)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eshowTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTypeF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eprint_2eshowTypeF_lam0(V self, V *args) {
  V v_xs_2421 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2422 = (g_prelude_2emap(heff_get(v_r_240, LBL_ty), heff_arrayToList(v_xs_2421)));
  V v_t_2423 = ({ V a_0 = v_xs_2422; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2422); r_; });
  V v_t_2424 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str24), heff_strAppend(v_t_2423, ((V)&g_heff_2eprint_2eshowTypeF_str25)));
  return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str26), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTypeF_str27)));
}
V g_heff_2eprint_2epr_lam0(V self, V *args); static Clo g_heff_2eprint_2epr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2epr_lam0, 1, 0};
V g_heff_2eprint_2epr_lam1(V self, V *args); static Clo g_heff_2eprint_2epr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2epr_lam1, 1, 0};

static V g_heff_2eprint_2epr_val;
static int g_heff_2eprint_2epr_st;
static V g_heff_2eprint_2epr_init(void) {
  return heff_rec(2, shape_80_351, (V[]){((V)&g_heff_2eprint_2epr_lam0_clo), ((V)&g_heff_2eprint_2epr_lam1_clo)});
}
V g_heff_2eprint_2epr_get(void) {
  if (g_heff_2eprint_2epr_st == 2) return g_heff_2eprint_2epr_val;
  if (g_heff_2eprint_2epr_st == 1) heff_fail("defined by itself");
  g_heff_2eprint_2epr_st = 1;
  g_heff_2eprint_2epr_val = heff_tr(g_heff_2eprint_2epr_init());
  g_heff_2eprint_2epr_st = 2;
  return g_heff_2eprint_2epr_val;
}
V g_heff_2eprint_2epr_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eprint_2epr_get()); V a_1 = v_t_240; V r_ = (g_heff_2eprint_2eshowTermF(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eprint_2epr_lam1(V self, V *args) {
  V v_t_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eprint_2epr_get()); V a_1 = v_t_241; V r_ = (g_heff_2eprint_2eshowTypeF(a_0, a_1)); heff_drop(v_t_241); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s419_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s419_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2earmOf_24s419_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s419_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2earmOf_24s419_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s419_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s419_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2earmOf_24s419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2earmOf_24s419_entry, 1, 0};

V g_heff_2eprint_2earmOf_24s419(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_MkPair: {
    V v_xs_241 = heff_field(v_x2_240, 0);
    V v_b_242 = heff_field(v_x2_240, 1);
    V v_xs_243 = (g_prelude_2emap_24s416(heff_arrayToList(heff_dup(v_xs_241))));
    V v_t_244 = ({ V a_0 = v_xs_243; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s419_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2earmOf_24s419_str1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s419_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2earmOf_24s419_str3)));
    V v_t_247 = (g_heff_2eprint_2eshowTermF_24s418(v_b_242));
    return heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s419_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s419_str5), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2earmOf_24s419_str6)))));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2earmOf_24s419_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2earmOf_24s419(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s420_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s420_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2edictOf_24s420_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s420_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2edictOf_24s420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2edictOf_24s420_entry, 1, 0};

V g_heff_2eprint_2edictOf_24s420(V v_d_240) {
top: ;
  V v_t_241 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_242 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_t_243 = (g_heff_2edict_2ezipKV(v_t_241, v_t_242));
  V v_xs_244 = (g_prelude_2emap_24s421(v_t_243));
  V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
  V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_24s420_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2edictOf_24s420_str1)));
  return heff_strAppend(((V)&g_heff_2eprint_2edictOf_24s420_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2edictOf_24s420_str3)));
}
V g_heff_2eprint_2edictOf_24s420_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2edictOf_24s420(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s423_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s423_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2edictOf_24s423_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_24s423_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2edictOf_24s423_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2edictOf_24s423_entry, 1, 0};

V g_heff_2eprint_2edictOf_24s423(V v_d_240) {
top: ;
  V v_t_241 = heff_arrayToList(heff_get(heff_dup(v_d_240), LBL_keys));
  V v_t_242 = heff_arrayToList(heff_get(v_d_240, LBL_values));
  V v_t_243 = (g_heff_2edict_2ezipKV(v_t_241, v_t_242));
  V v_xs_244 = (g_prelude_2emap_24s424(v_t_243));
  V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
  V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_24s423_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2edictOf_24s423_str1)));
  return heff_strAppend(((V)&g_heff_2eprint_2edictOf_24s423_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2edictOf_24s423_str3)));
}
V g_heff_2eprint_2edictOf_24s423_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2edictOf_24s423(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s422_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 109, 97, 108, 108, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s422_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {76, 97, 114, 103, 101, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 83, 85, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_24s422_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 68, 101, 99, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s422_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s422_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {69, 120, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 109, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_24s422_str12 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 70, 117, 110, 99, 116, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s422_str17 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s422_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s422_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_24s422_str20 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 82, 101, 99, 111, 114, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s422_str24 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 83, 117, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_24s422_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 73, 115, 84, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s422_str28 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 80, 114, 105, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTypeF_24s422_str29 = {{0x80000000u, K_STR, 0}, 10, 10, {83, 80, 114, 105, 109, 70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_24s422_str30 = {{0x80000000u, K_STR, 0}, 11, 11, {83, 80, 114, 105, 109, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s422_str31 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 80, 114, 105, 109, 65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s422_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTypeF_24s422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTypeF_24s422_entry, 1, 0};

V g_heff_2eprint_2eshowTypeF_24s422(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_u_241 = heff_field(v_x2_240, 0);
    V v_t_242;
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      v_t_242 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_242 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str1);
      break;
    }
    default: heff_nomatch(v_u_241);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str2), heff_strAppend(v_t_242, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str3)));
  }
  case TAG_SDecode: {
    V v_t_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2eprint_2eshowTermF_24s418(v_t_243));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str4), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str5)));
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_t_249;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_249 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str6);
      break;
    }
    case TAG_Large: {
      v_t_249 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str7);
      break;
    }
    case TAG_TopL: {
      v_t_249 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str8);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2410 = (g_heff_2eprint_2eshowTypeF_24s422(v_dom_246));
    V v_t_2411 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), v_cod_247));
    V v_t_2412;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2412 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2412 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2412 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str11);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str12), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str14), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str15), heff_strAppend(v_t_2412, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str16)))))))));
  }
  case TAG_SRecord: {
    V v_level_2413 = heff_field(v_x2_240, 0);
    V v_fieldTypes_2414 = heff_field(v_x2_240, 1);
    V v_defaults_2415 = heff_field(v_x2_240, 2);
    V v_t_2416;
    switch (heff_tag_of(v_level_2413)) {
    case TAG_Small: {
      v_t_2416 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str17);
      break;
    }
    case TAG_Large: {
      v_t_2416 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2416 = ((V)&g_heff_2eprint_2eshowTypeF_24s422_str19);
      break;
    }
    default: heff_nomatch(v_level_2413);
    }
    V v_t_2417 = (g_heff_2eprint_2edictOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), heff_dup(v_fieldTypes_2414)));
    V v_t_2418 = (g_heff_2eprint_2edictOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), heff_dup(v_defaults_2415)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str20), heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str21), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str22), heff_strAppend(v_t_2418, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str23)))))));
  }
  case TAG_SSum: {
    V v_st_2419 = heff_field(v_x2_240, 0);
    V v_t_2420 = (g_heff_2eprint_2edictOf_24s423(heff_dup(v_st_2419)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str24), heff_strAppend(v_t_2420, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str25)));
  }
  case TAG_SIsTy: {
    V v_t_2421 = heff_field(v_x2_240, 0);
    V v_t_2422 = (g_heff_2eprint_2eshowTypeF_24s422(v_t_2421));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str26), heff_strAppend(v_t_2422, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str27)));
  }
  case TAG_SPrimInt: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s422_str28);
  }
  case TAG_SPrimFloat: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s422_str29);
  }
  case TAG_SPrimString: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s422_str30);
  }
  case TAG_SPrimArray: {
    V v_a_2423 = heff_field(v_x2_240, 0);
    V v_t_2424 = (g_heff_2eprint_2eshowTypeF_24s422(v_a_2423));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s422_str31), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTypeF_24s422_str32)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2eshowTypeF_24s422_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTypeF_24s422(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s418_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s418_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 76, 111, 99, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_24s418_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 71, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s418_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s418_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s418_str13 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 76, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s418_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 110, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s418_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 111, 106, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s418_str27 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s418_str29 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 84, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s418_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 77, 97, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_24s418_str37 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 83, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s418_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 83, 73, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s418_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {83, 79, 112, 97, 113, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s418_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 65, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s418_str45 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 82, 101, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s418_str47 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 70, 105, 120, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_24s418_str52 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 73, 109, 112, 108, 105, 99, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s418_str57 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 105, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s418_str59 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s418_str63 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTermF_24s418_str65 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 83, 77, 101, 116, 97, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s418_str69 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_24s418_str71 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 76, 105, 116, 73, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_24s418_str73 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s418_str77 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 76, 105, 116, 83, 116, 114, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s418_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTermF_24s418_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTermF_24s418_entry, 1, 0};

V g_heff_2eprint_2eshowTermF_24s418(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_241 = heff_field(v_x2_240, 0);
    V v_t_242 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
    V v_t_244;
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_241)));
      v_t_244 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str0), heff_strAppend(v_t_243, ((V)&g_heff_2eprint_2eshowTermF_24s418_str1)));
      break;
    }
    case TAG_False: {
      v_t_244 = heff_intShow(heff_dup(v_i_241));
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTermF_24s418_str3)));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_t_246 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_245), MK_INT(0LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str4), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2eshowTermF_24s418_str5)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str6), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2eshowTermF_24s418_str7)));
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_t_249 = (g_heff_2eprint_2eshowTypeF_24s422(v_a_248));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str8), heff_strAppend(v_t_249, ((V)&g_heff_2eprint_2eshowTermF_24s418_str9)));
  }
  case TAG_SApp: {
    V v_f_2410 = heff_field(v_x2_240, 0);
    V v_a_2411 = heff_field(v_x2_240, 1);
    V v_t_2412 = (g_heff_2eprint_2eshowTermF_24s418(v_f_2410));
    V v_t_2413 = (g_heff_2eprint_2eshowTermF_24s418(v_a_2411));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str10), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str11), heff_strAppend(v_t_2413, ((V)&g_heff_2eprint_2eshowTermF_24s418_str12)))));
  }
  case TAG_SLam: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_heff_2eprint_2eshowTypeF_24s422(v_a_2414));
    V v_t_2417 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), v_b_2415));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str13), heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str14), heff_strAppend(v_t_2417, ((V)&g_heff_2eprint_2eshowTermF_24s418_str15)))));
  }
  case TAG_SCons: {
    V v_d_2418 = heff_field(v_x2_240, 0);
    V v_t_2419 = (g_heff_2eprint_2edictOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), heff_dup(v_d_2418)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str16), heff_strAppend(v_t_2419, ((V)&g_heff_2eprint_2eshowTermF_24s418_str17)));
  }
  case TAG_SProj: {
    V v_t_2420 = heff_field(v_x2_240, 0);
    V v_x_2421 = heff_field(v_x2_240, 1);
    V v_t_2422 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2420));
    V v_t_2423 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2421), MK_INT(0LL)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str18), heff_strAppend(v_t_2423, ((V)&g_heff_2eprint_2eshowTermF_24s418_str19)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str20), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str21), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTermF_24s418_str22)))));
  }
  case TAG_STag: {
    V v_x_2425 = heff_field(v_x2_240, 0);
    V v_ts_2426 = heff_field(v_x2_240, 1);
    V v_t_2427 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2425), MK_INT(0LL)));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str23), heff_strAppend(v_t_2427, ((V)&g_heff_2eprint_2eshowTermF_24s418_str24)));
    V v_xs_2429 = (g_prelude_2emap(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), heff_arrayToList(heff_dup(v_ts_2426))));
    V v_t_2430 = ({ V a_0 = v_xs_2429; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2429); r_; });
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str25), heff_strAppend(v_t_2430, ((V)&g_heff_2eprint_2eshowTermF_24s418_str26)));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str27), heff_strAppend(v_t_2431, ((V)&g_heff_2eprint_2eshowTermF_24s418_str28)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str29), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str30), heff_strAppend(v_t_2432, ((V)&g_heff_2eprint_2eshowTermF_24s418_str31)))));
  }
  case TAG_SMatch: {
    V v_t_2433 = heff_field(v_x2_240, 0);
    V v_arms_2434 = heff_field(v_x2_240, 1);
    V v_t_2435 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2433));
    V v_t_2436 = (g_heff_2eprint_2edictOf_24s420(heff_dup(v_arms_2434)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str32), heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str33), heff_strAppend(v_t_2436, ((V)&g_heff_2eprint_2eshowTermF_24s418_str34)))));
  }
  case TAG_SSpecialize: {
    V v_t_2437 = heff_field(v_x2_240, 0);
    V v_x_2438 = heff_field(v_x2_240, 1);
    V v_t_27_2439 = heff_field(v_x2_240, 2);
    V v_t_2440 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2437));
    V v_t_2441 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2438), MK_INT(0LL)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str35), heff_strAppend(v_t_2441, ((V)&g_heff_2eprint_2eshowTermF_24s418_str36)));
    V v_t_2443 = (g_heff_2eprint_2eshowTermF_24s418(v_t_27_2439));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str37), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str38), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str39), heff_strAppend(v_t_2443, ((V)&g_heff_2eprint_2eshowTermF_24s418_str40)))))));
  }
  case TAG_SIs: {
    V v_t_2444 = heff_field(v_x2_240, 0);
    V v_t_2445 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2444));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str41), heff_strAppend(v_t_2445, ((V)&g_heff_2eprint_2eshowTermF_24s418_str42)));
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2eprint_2eshowTermF_24s418_str43);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2eprint_2eshowTermF_24s418_str44);
  }
  case TAG_SRec: {
    V v_t_2446 = heff_field(v_x2_240, 0);
    V v_t_2447 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2446));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str45), heff_strAppend(v_t_2447, ((V)&g_heff_2eprint_2eshowTermF_24s418_str46)));
  }
  case TAG_SFix: {
    V v_a_2448 = heff_field(v_x2_240, 0);
    V v_b_2449 = heff_field(v_x2_240, 1);
    V v_t_2450 = (g_heff_2eprint_2eshowTypeF_24s422(v_a_2448));
    V v_t_2451 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), v_b_2449));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str47), heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str48), heff_strAppend(v_t_2451, ((V)&g_heff_2eprint_2eshowTermF_24s418_str49)))));
  }
  case TAG_SImplicit: {
    V v_x_2452 = heff_field(v_x2_240, 0);
    V v_t_2453 = heff_field(v_x2_240, 1);
    V v_t_2454 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2452), MK_INT(0LL)));
    V v_t_2455 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str50), heff_strAppend(v_t_2454, ((V)&g_heff_2eprint_2eshowTermF_24s418_str51)));
    V v_t_2456 = (g_heff_2eprint_2eshowTermF_24s418(v_t_2453));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str52), heff_strAppend(v_t_2455, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str53), heff_strAppend(v_t_2456, ((V)&g_heff_2eprint_2eshowTermF_24s418_str54)))));
  }
  case TAG_SPrim: {
    V v_x_2457 = heff_field(v_x2_240, 0);
    V v_t_2458 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2457), MK_INT(0LL)));
    V v_t_2459 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str55), heff_strAppend(v_t_2458, ((V)&g_heff_2eprint_2eshowTermF_24s418_str56)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str57), heff_strAppend(v_t_2459, ((V)&g_heff_2eprint_2eshowTermF_24s418_str58)));
  }
  case TAG_SMetaApp: {
    V v_m_2460 = heff_field(v_x2_240, 0);
    V v_idxs_2461 = heff_field(v_x2_240, 1);
    V v_a_2462 = heff_field(v_x2_240, 2);
    V v_t_2463 = heff_intLt(heff_dup(v_m_2460), MK_INT(0LL));
    V v_t_2465;
    switch (heff_tag_of(v_t_2463)) {
    case TAG_True: {
      V v_t_2464 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2460)));
      v_t_2465 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str59), heff_strAppend(v_t_2464, ((V)&g_heff_2eprint_2eshowTermF_24s418_str60)));
      break;
    }
    case TAG_False: {
      v_t_2465 = heff_intShow(heff_dup(v_m_2460));
      break;
    }
    default: heff_nomatch(v_t_2463);
    }
    V v_xs_2466 = (g_prelude_2emap_24s417(heff_arrayToList(heff_dup(v_idxs_2461))));
    V v_t_2467 = ({ V a_0 = v_xs_2466; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2466); r_; });
    V v_t_2468 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str61), heff_strAppend(v_t_2467, ((V)&g_heff_2eprint_2eshowTermF_24s418_str62)));
    V v_t_2469 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str63), heff_strAppend(v_t_2468, ((V)&g_heff_2eprint_2eshowTermF_24s418_str64)));
    V v_t_2470 = (g_heff_2eprint_2eshowTypeF_24s422(v_a_2462));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str65), heff_strAppend(v_t_2465, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str66), heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str67), heff_strAppend(v_t_2470, ((V)&g_heff_2eprint_2eshowTermF_24s418_str68)))))));
  }
  case TAG_SLitInt: {
    V v_n_2471 = heff_field(v_x2_240, 0);
    V v_t_2472 = heff_intLt(heff_dup(v_n_2471), MK_INT(0LL));
    V v_t_2474;
    switch (heff_tag_of(v_t_2472)) {
    case TAG_True: {
      V v_t_2473 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2471)));
      v_t_2474 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str69), heff_strAppend(v_t_2473, ((V)&g_heff_2eprint_2eshowTermF_24s418_str70)));
      break;
    }
    case TAG_False: {
      v_t_2474 = heff_intShow(heff_dup(v_n_2471));
      break;
    }
    default: heff_nomatch(v_t_2472);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str71), heff_strAppend(v_t_2474, ((V)&g_heff_2eprint_2eshowTermF_24s418_str72)));
  }
  case TAG_SLitFloat: {
    V v_x_2475 = heff_field(v_x2_240, 0);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str73), heff_strAppend(heff_floatShow(heff_dup(v_x_2475)), ((V)&g_heff_2eprint_2eshowTermF_24s418_str74)));
  }
  case TAG_SLitString: {
    V v_s_2476 = heff_field(v_x2_240, 0);
    V v_t_2477 = (g_heff_2eprint_2eescFrom(heff_dup(v_s_2476), MK_INT(0LL)));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str75), heff_strAppend(v_t_2477, ((V)&g_heff_2eprint_2eshowTermF_24s418_str76)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s418_str77), heff_strAppend(v_t_2478, ((V)&g_heff_2eprint_2eshowTermF_24s418_str78)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2eshowTermF_24s418_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTermF_24s418(a[0]); heff_drop(a[0]); return r;
}