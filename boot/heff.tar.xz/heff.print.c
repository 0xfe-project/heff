// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2eprint_2eabsOf(V, V);
V g_heff_2eprint_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2eabsOf_clo;
V g_heff_2eprint_2earmOf(V, V);
V g_heff_2eprint_2earmOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_clo;
V g_heff_2eprint_2earmOf_24s139775371x1736504365(V);
V g_heff_2eprint_2earmOf_24s139775371x1736504365_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_24s139775371x1736504365_clo;
V g_heff_2eprint_2ecommaSep(V);
V g_heff_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eprint_2ecommaSep_clo;
V g_heff_2eprint_2edictOf(V, V);
V g_heff_2eprint_2edictOf_entry(V self, V *a);
extern Clo g_heff_2eprint_2edictOf_clo;
V g_heff_2eprint_2eescChar(V);
V g_heff_2eprint_2eescChar_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescChar_clo;
V g_heff_2eprint_2eescFrom(V, V);
V g_heff_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescFrom_clo;
V g_heff_2eprint_2epr_get(void);
V g_heff_2eprint_2eshowTermF(V, V);
V g_heff_2eprint_2eshowTermF_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_clo;
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(V);
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_clo;
V g_heff_2eprint_2eshowTypeF(V, V);
V g_heff_2eprint_2eshowTypeF_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_clo;
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(V);
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1107296543x493652800(V, V, V, V, V, V, V);
V g_list_2emap_24s1107296543x493652800_entry(V self, V *a);
extern Clo g_list_2emap_24s1107296543x493652800_clo;
V g_list_2emap_24s1300207191x1224487257(V);
V g_list_2emap_24s1300207191x1224487257_entry(V self, V *a);
extern Clo g_list_2emap_24s1300207191x1224487257_clo;
V g_list_2emap_24s1486836708x2052186263(V, V, V, V, V, V, V);
V g_list_2emap_24s1486836708x2052186263_entry(V self, V *a);
extern Clo g_list_2emap_24s1486836708x2052186263_clo;
V g_list_2emap_24s1516017384x1249556640(V);
V g_list_2emap_24s1516017384x1249556640_entry(V self, V *a);
extern Clo g_list_2emap_24s1516017384x1249556640_clo;
V g_list_2emap_24s1999471019x1288081638(V, V, V, V, V, V, V);
V g_list_2emap_24s1999471019x1288081638_entry(V self, V *a);
extern Clo g_list_2emap_24s1999471019x1288081638_clo;
V g_list_2emap_24s638199897x1254231767(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s638199897x1254231767_entry(V self, V *a);
extern Clo g_list_2emap_24s638199897x1254231767_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {13}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescChar_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eescChar_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2eprint_2eescChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eescChar_entry, 1, 0};

V g_heff_2eprint_2eescChar(V v_c_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str0))) {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eprint_2eescChar_str1);
  } else {
    if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str2))) {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eprint_2eescChar_str3);
    } else {
      if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str4))) {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eprint_2eescChar_str5);
      } else {
        if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str6))) {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eprint_2eescChar_str7);
        } else {
          if (heff_strEq_c(heff_dup(v_c_240), ((V)&g_heff_2eprint_2eescChar_str8))) {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eprint_2eescChar_str9);
          } else {
            return v_c_240;
          }
        }
      }
    }
  }
}
V g_heff_2eprint_2eescChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2eescChar(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eescFrom_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eprint_2eescFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eescFrom_entry, 2, 0};

V g_heff_2eprint_2eescFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength(heff_dup(v_s_240)))) {
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2eprint_2eescChar(v_t_243));
    return heff_strAppend(v_t_244, (g_heff_2eprint_2eescFrom(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)))));
  } else {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eprint_2eescFrom_str0);
  }
}
V g_heff_2eprint_2eescFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2eescFrom(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2ecommaSep_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2ecommaSep_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_heff_2eprint_2ecommaSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2ecommaSep_entry, 1, 0};

V g_heff_2eprint_2ecommaSep(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eprint_2ecommaSep_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eprint_2ecommaSep_str1), (g_heff_2eprint_2ecommaSep(v_x12_242))));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eprint_2ecommaSep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2ecommaSep(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2edictOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2edictOf_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2edictOf_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eprint_2edictOf_lam0(V self, V *args);
Clo g_heff_2eprint_2edictOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2edictOf_entry, 2, 0};

V g_heff_2eprint_2edictOf(V v_f_240, V v_d_241) {
top: ;
  V v_t_242 = heff_arrayToList(heff_get(heff_dup(v_d_241), LBL_keys));
  V v_t_243 = heff_arrayToList(heff_get(v_d_241, LBL_values));
  V v_t_244 = (g_heff_2edict_2ezipKV(v_t_242, v_t_243));
  V v_xs_2411 = (g_list_2emap(heff_clo(g_heff_2eprint_2edictOf_lam0, 1, 1, (V[]){v_f_240}), v_t_244));
  V v_t_2412 = ({ V a_0 = v_xs_2411; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2411); r_; });
  V v_t_2413 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_str5), heff_strAppend(v_t_2412, ((V)&g_heff_2eprint_2edictOf_str6)));
  return heff_strAppend(((V)&g_heff_2eprint_2edictOf_str7), heff_strAppend(v_t_2413, ((V)&g_heff_2eprint_2edictOf_str8)));
}
V g_heff_2eprint_2edictOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprint_2edictOf(a[0], a[1]);
}
V g_heff_2eprint_2edictOf_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_v_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_t_248 = (g_heff_2eprint_2eescFrom(v_k_246, MK_INT(0LL)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2eprint_2edictOf_str0), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2edictOf_str1)));
    V v_t_2410 = heff_tr(heff_apply(v_f_240, 1, (V[]){v_v_247}));
    return heff_strAppend(((V)&g_heff_2eprint_2edictOf_str2), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eprint_2edictOf_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2eprint_2edictOf_str4)))));
  }
  default: return heff_nomatch(v_p_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eabsOf_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 77, 107, 65, 98, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eabsOf_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 65, 98, 115, 67, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eabsOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eabsOf_entry, 2, 0};

V g_heff_2eprint_2eabsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkAbs: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_242), MK_INT(0LL)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eabsOf_str1)));
    V v_t_246 = heff_tr(heff_apply(v_f_240, 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str2), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str3), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2eabsOf_str4)))));
  }
  case TAG_AbsConst: {
    V v_b_247 = heff_field(v_x2_241, 0);
    V v_t_248 = heff_tr(heff_apply(v_f_240, 1, (V[]){heff_dup(v_b_247)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eabsOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2eabsOf_str6)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eabsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eabsOf(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2earmOf_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2earmOf_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2earmOf_entry, 2, 0};

V g_heff_2eprint_2earmOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x2_241, 0);
    V v_b_243 = heff_field(v_x2_241, 1);
    V v_xs_244 = (g_list_2emap_24s1516017384x1249556640(heff_arrayToList(heff_dup(v_xs_242))));
    V v_t_245 = ({ V a_0 = v_xs_244; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_str0), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2earmOf_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_str2), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2earmOf_str3)));
    V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_b_243)}));
    return heff_strAppend(((V)&g_heff_2eprint_2earmOf_str4), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eprint_2earmOf_str5), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2earmOf_str6)))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2earmOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2earmOf(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 76, 111, 99, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 71, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str13 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 76, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 110, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str20 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 111, 106, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str27 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str29 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 84, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 77, 97, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_str37 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 83, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 83, 73, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str43 = {{0x80000000u, K_STR, 0}, 7, 7, {83, 79, 112, 97, 113, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 65, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str45 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 82, 101, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_str47 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 70, 105, 120, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_str52 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 73, 109, 112, 108, 105, 99, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_str57 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 105, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str59 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str63 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTermF_str65 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 83, 77, 101, 116, 97, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str69 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_str71 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 76, 105, 116, 73, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_str73 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_str77 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 76, 105, 116, 83, 116, 114, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTermF_str79 = {{0x80000000u, K_STR, 0}, 2, 2, {73, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str81 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str82 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTermF_str83 = {{0x80000000u, K_STR, 0}, 2, 2, {85, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str84 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str85 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str86 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_str87 = {{0x80000000u, K_STR, 0}, 3, 3, {70, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_str88 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str89 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_str90 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 105, 120, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str91 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str92 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_str93 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 51, 50, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTermF_entry, 2, 0};

V g_heff_2eprint_2eshowTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_i_242), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_242)));
      v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTermF_str1)));
    } else {
      v_t_245 = heff_intShow(heff_dup(v_i_242));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2eshowTermF_str3)));
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_247 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_246), MK_INT(0LL)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str4), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2eshowTermF_str5)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str6), heff_strAppend(v_t_248, ((V)&g_heff_2eprint_2eshowTermF_str7)));
  }
  case TAG_SCode: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_249)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str8), heff_strAppend(v_t_2410, ((V)&g_heff_2eprint_2eshowTermF_str9)));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_f_2411)}));
    V v_t_2414 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_a_2412)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str10), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str11), heff_strAppend(v_t_2414, ((V)&g_heff_2eprint_2eshowTermF_str12)))));
  }
  case TAG_SLam: {
    V v_a_2415 = heff_field(v_x2_241, 0);
    V v_b_2416 = heff_field(v_x2_241, 1);
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_a_2415)}));
    V v_t_2418 = (g_heff_2eprint_2eabsOf(heff_get(v_r_240, LBL_el), v_b_2416));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str13), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str14), heff_strAppend(v_t_2418, ((V)&g_heff_2eprint_2eshowTermF_str15)))));
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_x2_241, 0);
    V v_t_2420 = (g_heff_2eprint_2edictOf(heff_get(v_r_240, LBL_el), heff_dup(v_d_2419)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str16), heff_strAppend(v_t_2420, ((V)&g_heff_2eprint_2eshowTermF_str17)));
  }
  case TAG_SProj: {
    V v_t_2421 = heff_field(v_x2_241, 0);
    V v_x_2422 = heff_field(v_x2_241, 1);
    V v_t_2423 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2421)}));
    V v_t_2424 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2422), MK_INT(0LL)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str18), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTermF_str19)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str20), heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str21), heff_strAppend(v_t_2425, ((V)&g_heff_2eprint_2eshowTermF_str22)))));
  }
  case TAG_STag: {
    V v_x_2426 = heff_field(v_x2_241, 0);
    V v_ts_2427 = heff_field(v_x2_241, 1);
    V v_t_2428 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2426), MK_INT(0LL)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str23), heff_strAppend(v_t_2428, ((V)&g_heff_2eprint_2eshowTermF_str24)));
    V v_xs_2430 = (g_list_2emap(heff_get(v_r_240, LBL_el), heff_arrayToList(heff_dup(v_ts_2427))));
    V v_t_2431 = ({ V a_0 = v_xs_2430; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2430); r_; });
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str25), heff_strAppend(v_t_2431, ((V)&g_heff_2eprint_2eshowTermF_str26)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str27), heff_strAppend(v_t_2432, ((V)&g_heff_2eprint_2eshowTermF_str28)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str29), heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str30), heff_strAppend(v_t_2433, ((V)&g_heff_2eprint_2eshowTermF_str31)))));
  }
  case TAG_SMatch: {
    V v_t_2434 = heff_field(v_x2_241, 0);
    V v_arms_2435 = heff_field(v_x2_241, 1);
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_t_2434)}));
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2eprint_2earmOf_clo), 1, (V[]){v_r_240}));
    V v_t_2438 = (g_heff_2eprint_2edictOf(v_t_2437, heff_dup(v_arms_2435)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str32), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str33), heff_strAppend(v_t_2438, ((V)&g_heff_2eprint_2eshowTermF_str34)))));
  }
  case TAG_SSpecialize: {
    V v_t_2439 = heff_field(v_x2_241, 0);
    V v_x_2440 = heff_field(v_x2_241, 1);
    V v_t_27_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 1, (V[]){heff_dup(v_t_2439)}));
    V v_t_2443 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2440), MK_INT(0LL)));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str35), heff_strAppend(v_t_2443, ((V)&g_heff_2eprint_2eshowTermF_str36)));
    V v_t_2445 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_27_2441)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str37), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str38), heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str39), heff_strAppend(v_t_2445, ((V)&g_heff_2eprint_2eshowTermF_str40)))))));
  }
  case TAG_SIs: {
    V v_t_2446 = heff_field(v_x2_241, 0);
    V v_t_2447 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2446)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str41), heff_strAppend(v_t_2447, ((V)&g_heff_2eprint_2eshowTermF_str42)));
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTermF_str43);
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTermF_str44);
  }
  case TAG_SRec: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_t_2449 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2448)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str45), heff_strAppend(v_t_2449, ((V)&g_heff_2eprint_2eshowTermF_str46)));
  }
  case TAG_SFix: {
    V v_a_2450 = heff_field(v_x2_241, 0);
    V v_b_2451 = heff_field(v_x2_241, 1);
    V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_a_2450)}));
    V v_t_2453 = (g_heff_2eprint_2eabsOf(heff_get(v_r_240, LBL_el), v_b_2451));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str47), heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str48), heff_strAppend(v_t_2453, ((V)&g_heff_2eprint_2eshowTermF_str49)))));
  }
  case TAG_SImplicit: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_t_2455 = heff_field(v_x2_241, 1);
    V v_t_2456 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2454), MK_INT(0LL)));
    V v_t_2457 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str50), heff_strAppend(v_t_2456, ((V)&g_heff_2eprint_2eshowTermF_str51)));
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_2455)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str52), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str53), heff_strAppend(v_t_2458, ((V)&g_heff_2eprint_2eshowTermF_str54)))));
  }
  case TAG_SPrim: {
    V v_x_2459 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2460 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2459), MK_INT(0LL)));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str55), heff_strAppend(v_t_2460, ((V)&g_heff_2eprint_2eshowTermF_str56)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str57), heff_strAppend(v_t_2461, ((V)&g_heff_2eprint_2eshowTermF_str58)));
  }
  case TAG_SMetaApp: {
    V v_m_2462 = heff_field(v_x2_241, 0);
    V v_idxs_2463 = heff_field(v_x2_241, 1);
    V v_a_2464 = heff_field(v_x2_241, 2);
    V v_t_2467;
    if (heff_intLt_c(heff_dup(v_m_2462), MK_INT(0LL))) {
      V v_t_2466 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2462)));
      v_t_2467 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str59), heff_strAppend(v_t_2466, ((V)&g_heff_2eprint_2eshowTermF_str60)));
    } else {
      v_t_2467 = heff_intShow(heff_dup(v_m_2462));
    }
    V v_xs_2468 = (g_list_2emap_24s1300207191x1224487257(heff_arrayToList(heff_dup(v_idxs_2463))));
    V v_t_2469 = ({ V a_0 = v_xs_2468; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2468); r_; });
    V v_t_2470 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str61), heff_strAppend(v_t_2469, ((V)&g_heff_2eprint_2eshowTermF_str62)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str63), heff_strAppend(v_t_2470, ((V)&g_heff_2eprint_2eshowTermF_str64)));
    V v_t_2472 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_2464)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str65), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str66), heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str67), heff_strAppend(v_t_2472, ((V)&g_heff_2eprint_2eshowTermF_str68)))))));
  }
  case TAG_SLitInt: {
    V v_n_2473 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2476;
    if (heff_intLt_c(heff_dup(v_n_2473), MK_INT(0LL))) {
      V v_t_2475 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2473)));
      v_t_2476 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str69), heff_strAppend(v_t_2475, ((V)&g_heff_2eprint_2eshowTermF_str70)));
    } else {
      v_t_2476 = heff_intShow(heff_dup(v_n_2473));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str71), heff_strAppend(v_t_2476, ((V)&g_heff_2eprint_2eshowTermF_str72)));
  }
  case TAG_SLitFloat: {
    V v_x_2477 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str73), heff_strAppend(heff_floatShow(heff_dup(v_x_2477)), ((V)&g_heff_2eprint_2eshowTermF_str74)));
  }
  case TAG_SLitString: {
    V v_s_2478 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2479 = (g_heff_2eprint_2eescFrom(heff_dup(v_s_2478), MK_INT(0LL)));
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str75), heff_strAppend(v_t_2479, ((V)&g_heff_2eprint_2eshowTermF_str76)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str77), heff_strAppend(v_t_2480, ((V)&g_heff_2eprint_2eshowTermF_str78)));
  }
  case TAG_SLitFixed: {
    V v_w_2481 = heff_field(v_x2_241, 0);
    V v_n_2482 = heff_field(v_x2_241, 1);
    heff_drop(v_r_240);
    V v_t_2483;
    switch (heff_tag_of(v_w_2481)) {
    case TAG_I8: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str79);
      break;
    }
    case TAG_I16: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str80);
      break;
    }
    case TAG_I32: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str81);
      break;
    }
    case TAG_I64: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str82);
      break;
    }
    case TAG_U8: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str83);
      break;
    }
    case TAG_U16: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str84);
      break;
    }
    case TAG_U32: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str85);
      break;
    }
    case TAG_U64: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str86);
      break;
    }
    case TAG_F32: {
      v_t_2483 = ((V)&g_heff_2eprint_2eshowTermF_str87);
      break;
    }
    default: heff_nomatch(v_w_2481);
    }
    V v_t_2486;
    if (heff_intLt_c(heff_dup(v_n_2482), MK_INT(0LL))) {
      V v_t_2485 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2482)));
      v_t_2486 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str88), heff_strAppend(v_t_2485, ((V)&g_heff_2eprint_2eshowTermF_str89)));
    } else {
      v_t_2486 = heff_intShow(heff_dup(v_n_2482));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str90), heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str91), heff_strAppend(v_t_2486, ((V)&g_heff_2eprint_2eshowTermF_str92)))));
  }
  case TAG_SLitFloat32: {
    V v_x_2487 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_str93), heff_strAppend(heff_floatShow(heff_dup(v_x_2487)), ((V)&g_heff_2eprint_2eshowTermF_str94)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eshowTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTermF(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 109, 97, 108, 108, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {76, 97, 114, 103, 101, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 83, 85, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 68, 101, 99, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {69, 120, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 109, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 78, 111, 116, 104, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 40, 74, 117, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_str15 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 70, 117, 110, 99, 116, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_str23 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 82, 101, 99, 111, 114, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_str29 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_str31 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 83, 117, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_str33 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 73, 115, 84, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_str35 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 80, 114, 105, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTypeF_str36 = {{0x80000000u, K_STR, 0}, 10, 10, {83, 80, 114, 105, 109, 70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_str37 = {{0x80000000u, K_STR, 0}, 11, 11, {83, 80, 114, 105, 109, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_str38 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 80, 114, 105, 109, 65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTypeF_str40 = {{0x80000000u, K_STR, 0}, 2, 2, {73, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str41 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str43 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTypeF_str44 = {{0x80000000u, K_STR, 0}, 2, 2, {85, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str45 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str46 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str47 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_str48 = {{0x80000000u, K_STR, 0}, 3, 3, {70, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_str49 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 70, 105, 120, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2eprint_2eshowTypeF_lam0(V self, V *args);
Clo g_heff_2eprint_2eshowTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTypeF_entry, 2, 0};

V g_heff_2eprint_2eshowTypeF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    V v_u_242 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_243;
    switch (heff_tag_of(v_u_242)) {
    case TAG_SmallU: {
      v_t_243 = ((V)&g_heff_2eprint_2eshowTypeF_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_243 = ((V)&g_heff_2eprint_2eshowTypeF_str1);
      break;
    }
    default: heff_nomatch(v_u_242);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str2), heff_strAppend(v_t_243, ((V)&g_heff_2eprint_2eshowTypeF_str3)));
  }
  case TAG_SDecode: {
    V v_t_244 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_t_244)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str4), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2eshowTypeF_str5)));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x2_241, 0);
    V v_dom_247 = heff_field(v_x2_241, 1);
    V v_cod_248 = heff_field(v_x2_241, 2);
    V v_implicit_249 = heff_field(v_x2_241, 3);
    V v_dflt_2410 = heff_field(v_x2_241, 4);
    V v_t_2411;
    switch (heff_tag_of(v_level_246)) {
    case TAG_Small: {
      v_t_2411 = ((V)&g_heff_2eprint_2eshowTypeF_str6);
      break;
    }
    case TAG_Large: {
      v_t_2411 = ((V)&g_heff_2eprint_2eshowTypeF_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2411 = ((V)&g_heff_2eprint_2eshowTypeF_str8);
      break;
    }
    default: heff_nomatch(v_level_246);
    }
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 1, (V[]){heff_dup(v_dom_247)}));
    V v_t_2413 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(v_r_240), LBL_ty), v_cod_248));
    V v_t_2414;
    switch (heff_tag_of(v_implicit_249)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2eprint_2eshowTypeF_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2eprint_2eshowTypeF_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2eprint_2eshowTypeF_str11);
      break;
    }
    default: heff_nomatch(v_implicit_249);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      v_t_2417 = ((V)&g_heff_2eprint_2eshowTypeF_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2410, 0);
      V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 1, (V[]){heff_dup(v_d_2415)}));
      v_t_2417 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str13), heff_strAppend(v_t_2416, ((V)&g_heff_2eprint_2eshowTypeF_str14)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str15), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str16), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str17), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str18), heff_strAppend(v_t_2414, heff_strAppend(v_t_2417, ((V)&g_heff_2eprint_2eshowTypeF_str19))))))))));
  }
  case TAG_SRecord: {
    V v_level_2418 = heff_field(v_x2_241, 0);
    V v_fieldTypes_2419 = heff_field(v_x2_241, 1);
    V v_defaults_2420 = heff_field(v_x2_241, 2);
    V v_t_2421;
    switch (heff_tag_of(v_level_2418)) {
    case TAG_Small: {
      v_t_2421 = ((V)&g_heff_2eprint_2eshowTypeF_str20);
      break;
    }
    case TAG_Large: {
      v_t_2421 = ((V)&g_heff_2eprint_2eshowTypeF_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2421 = ((V)&g_heff_2eprint_2eshowTypeF_str22);
      break;
    }
    default: heff_nomatch(v_level_2418);
    }
    V v_t_2422 = (g_heff_2eprint_2edictOf(heff_get(heff_dup(v_r_240), LBL_ty), heff_dup(v_fieldTypes_2419)));
    V v_t_2423 = (g_heff_2eprint_2edictOf(heff_get(v_r_240, LBL_el), heff_dup(v_defaults_2420)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str23), heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str24), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str25), heff_strAppend(v_t_2423, ((V)&g_heff_2eprint_2eshowTypeF_str26)))))));
  }
  case TAG_SSum: {
    V v_st_2424 = heff_field(v_x2_241, 0);
    V v_t_2429 = (g_heff_2eprint_2edictOf(heff_clo(g_heff_2eprint_2eshowTypeF_lam0, 1, 1, (V[]){v_r_240}), heff_dup(v_st_2424)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str31), heff_strAppend(v_t_2429, ((V)&g_heff_2eprint_2eshowTypeF_str32)));
  }
  case TAG_SIsTy: {
    V v_t_2430 = heff_field(v_x2_241, 0);
    V v_t_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_t_2430)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str33), heff_strAppend(v_t_2431, ((V)&g_heff_2eprint_2eshowTypeF_str34)));
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str35);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str36);
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    return ((V)&g_heff_2eprint_2eshowTypeF_str37);
  }
  case TAG_SPrimArray: {
    V v_a_2432 = heff_field(v_x2_241, 0);
    V v_t_2433 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 1, (V[]){heff_dup(v_a_2432)}));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str38), heff_strAppend(v_t_2433, ((V)&g_heff_2eprint_2eshowTypeF_str39)));
  }
  case TAG_SFixed: {
    V v_w_2434 = heff_field(v_x2_241, 0);
    heff_drop(v_r_240);
    V v_t_2435;
    switch (heff_tag_of(v_w_2434)) {
    case TAG_I8: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str40);
      break;
    }
    case TAG_I16: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str41);
      break;
    }
    case TAG_I32: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str42);
      break;
    }
    case TAG_I64: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str43);
      break;
    }
    case TAG_U8: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str44);
      break;
    }
    case TAG_U16: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str45);
      break;
    }
    case TAG_U32: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str46);
      break;
    }
    case TAG_U64: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str47);
      break;
    }
    case TAG_F32: {
      v_t_2435 = ((V)&g_heff_2eprint_2eshowTypeF_str48);
      break;
    }
    default: heff_nomatch(v_w_2434);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str49), heff_strAppend(v_t_2435, ((V)&g_heff_2eprint_2eshowTypeF_str50)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprint_2eshowTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTypeF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eprint_2eshowTypeF_lam0(V self, V *args) {
  V v_xs_2425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2426 = (g_list_2emap(heff_get(v_r_240, LBL_ty), heff_arrayToList(v_xs_2425)));
  V v_t_2427 = ({ V a_0 = v_xs_2426; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2426); r_; });
  V v_t_2428 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str27), heff_strAppend(v_t_2427, ((V)&g_heff_2eprint_2eshowTypeF_str28)));
  return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_str29), heff_strAppend(v_t_2428, ((V)&g_heff_2eprint_2eshowTypeF_str30)));
}
V g_heff_2eprint_2epr_lam0(V self, V *args); static Clo g_heff_2eprint_2epr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2epr_lam0, 1, 0};
V g_heff_2eprint_2epr_lam1(V self, V *args); static Clo g_heff_2eprint_2epr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2epr_lam1, 1, 0};

static V g_heff_2eprint_2epr_val;
static int g_heff_2eprint_2epr_st;
static V g_heff_2eprint_2epr_init(void) {
  return heff_rec(2, shape_el__ty, (V[]){((V)&g_heff_2eprint_2epr_lam0_clo), ((V)&g_heff_2eprint_2epr_lam1_clo)});
}
V g_heff_2eprint_2epr_get(void) {
  if (g_heff_2eprint_2epr_st == 2) return g_heff_2eprint_2epr_val;
  if (g_heff_2eprint_2epr_st == 1) heff_fail("defined by itself");
  g_heff_2eprint_2epr_st = 1;
  g_heff_2eprint_2epr_val = heff_tr(g_heff_2eprint_2epr_init());
  g_heff_2eprint_2epr_st = 2;
  return g_heff_2eprint_2epr_val;
}
V g_heff_2eprint_2epr_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eprint_2epr_get()); V a_1 = v_t_240; V r_ = (g_heff_2eprint_2eshowTermF(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eprint_2epr_lam1(V self, V *args) {
  V v_t_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2eprint_2epr_get()); V a_1 = v_t_241; V r_ = (g_heff_2eprint_2eshowTypeF(a_0, a_1)); heff_drop(v_t_241); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 109, 97, 108, 108, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {76, 97, 114, 103, 101, 85}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 83, 85, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 68, 101, 99, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {69, 120, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 109, 112, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 78, 111, 116, 104, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 40, 74, 117, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str15 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 70, 117, 110, 99, 116, 105, 111, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {83, 109, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {76, 97, 114, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 111, 112, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str23 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str30 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str39 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str41 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 82, 101, 99, 111, 114, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str45 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str49 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str56 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str58 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 83, 117, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str60 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 73, 115, 84, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str62 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 80, 114, 105, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str63 = {{0x80000000u, K_STR, 0}, 10, 10, {83, 80, 114, 105, 109, 70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str64 = {{0x80000000u, K_STR, 0}, 11, 11, {83, 80, 114, 105, 109, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str65 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 80, 114, 105, 109, 65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str67 = {{0x80000000u, K_STR, 0}, 2, 2, {73, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str68 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str69 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str70 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str71 = {{0x80000000u, K_STR, 0}, 2, 2, {85, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str72 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str73 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str74 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str75 = {{0x80000000u, K_STR, 0}, 3, 3, {70, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str76 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 70, 105, 120, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str77 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_entry, 1, 0};

V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_u_241 = heff_field(v_x2_240, 0);
    V v_t_242;
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      v_t_242 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str0);
      break;
    }
    case TAG_LargeU: {
      v_t_242 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str1);
      break;
    }
    default: heff_nomatch(v_u_241);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str2), heff_strAppend(v_t_242, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str3)));
  }
  case TAG_SDecode: {
    V v_t_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_243));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str4), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str5)));
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str6);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str7);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str8);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_dom_246));
    V v_t_2412 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), v_cod_247));
    V v_t_2413;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str9);
      break;
    }
    case TAG_Impl: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str10);
      break;
    }
    case TAG_Inst: {
      v_t_2413 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str11);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2416;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2416 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str12);
      break;
    }
    case TAG_Just: {
      V v_d_2414 = heff_field(v_dflt_249, 0);
      V v_t_2415 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_d_2414));
      v_t_2416 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str13), heff_strAppend(v_t_2415, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str14)));
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str15), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str16), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str17), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str18), heff_strAppend(v_t_2413, heff_strAppend(v_t_2416, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str19))))))))));
  }
  case TAG_SRecord: {
    V v_level_2417 = heff_field(v_x2_240, 0);
    V v_fieldTypes_2418 = heff_field(v_x2_240, 1);
    V v_defaults_2419 = heff_field(v_x2_240, 2);
    V v_t_2420;
    switch (heff_tag_of(v_level_2417)) {
    case TAG_Small: {
      v_t_2420 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str20);
      break;
    }
    case TAG_Large: {
      v_t_2420 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str21);
      break;
    }
    case TAG_TopL: {
      v_t_2420 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str22);
      break;
    }
    default: heff_nomatch(v_level_2417);
    }
    V v_t_2421 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2418), LBL_keys));
    V v_t_2422 = heff_arrayToList(heff_get(heff_dup(v_fieldTypes_2418), LBL_values));
    V v_t_2423 = (g_heff_2edict_2ezipKV(v_t_2421, v_t_2422));
    V v_xs_2424 = (g_list_2emap_24s1999471019x1288081638(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str23), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str24), MK_INT(0LL), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str25), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str26), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str27), v_t_2423));
    V v_t_2425 = ({ V a_0 = v_xs_2424; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2424); r_; });
    V v_t_2426 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str28), heff_strAppend(v_t_2425, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str29)));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str30), heff_strAppend(v_t_2426, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str31)));
    V v_t_2428 = heff_arrayToList(heff_get(heff_dup(v_defaults_2419), LBL_keys));
    V v_t_2429 = heff_arrayToList(heff_get(heff_dup(v_defaults_2419), LBL_values));
    V v_t_2430 = (g_heff_2edict_2ezipKV(v_t_2428, v_t_2429));
    V v_xs_2431 = (g_list_2emap_24s1486836708x2052186263(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str32), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str33), MK_INT(0LL), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str34), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str35), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str36), v_t_2430));
    V v_t_2432 = ({ V a_0 = v_xs_2431; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2431); r_; });
    V v_t_2433 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str37), heff_strAppend(v_t_2432, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str38)));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str39), heff_strAppend(v_t_2433, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str40)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str41), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str42), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str43), heff_strAppend(v_t_2434, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str44)))))));
  }
  case TAG_SSum: {
    V v_st_2435 = heff_field(v_x2_240, 0);
    V v_t_2436 = heff_arrayToList(heff_get(heff_dup(v_st_2435), LBL_keys));
    V v_t_2437 = heff_arrayToList(heff_get(heff_dup(v_st_2435), LBL_values));
    V v_t_2438 = (g_heff_2edict_2ezipKV(v_t_2436, v_t_2437));
    V v_xs_2439 = (g_list_2emap_24s638199897x1254231767(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str45), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str46), MK_INT(0LL), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str47), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str48), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str49), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str50), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str51), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str52), ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str53), v_t_2438));
    V v_t_2440 = ({ V a_0 = v_xs_2439; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2439); r_; });
    V v_t_2441 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str54), heff_strAppend(v_t_2440, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str55)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str56), heff_strAppend(v_t_2441, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str57)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str58), heff_strAppend(v_t_2442, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str59)));
  }
  case TAG_SIsTy: {
    V v_t_2443 = heff_field(v_x2_240, 0);
    V v_t_2444 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_t_2443));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str60), heff_strAppend(v_t_2444, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str61)));
  }
  case TAG_SPrimInt: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str62);
  }
  case TAG_SPrimFloat: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str63);
  }
  case TAG_SPrimString: {
    return ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str64);
  }
  case TAG_SPrimArray: {
    V v_a_2445 = heff_field(v_x2_240, 0);
    V v_t_2446 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_a_2445));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str65), heff_strAppend(v_t_2446, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str66)));
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_x2_240, 0);
    V v_t_2448;
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str67);
      break;
    }
    case TAG_I16: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str68);
      break;
    }
    case TAG_I32: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str69);
      break;
    }
    case TAG_I64: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str70);
      break;
    }
    case TAG_U8: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str71);
      break;
    }
    case TAG_U16: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str72);
      break;
    }
    case TAG_U32: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str73);
      break;
    }
    case TAG_U64: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str74);
      break;
    }
    case TAG_F32: {
      v_t_2448 = ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str75);
      break;
    }
    default: heff_nomatch(v_w_2447);
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str76), heff_strAppend(v_t_2448, ((V)&g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_str77)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2earmOf_24s139775371x1736504365_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2earmOf_24s139775371x1736504365_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2earmOf_24s139775371x1736504365_entry, 1, 0};

V g_heff_2eprint_2earmOf_24s139775371x1736504365(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_MkPair: {
    V v_xs_241 = heff_field(v_x2_240, 0);
    V v_b_242 = heff_field(v_x2_240, 1);
    V v_xs_243 = (g_list_2emap_24s1516017384x1249556640(heff_arrayToList(heff_dup(v_xs_241))));
    V v_t_244 = ({ V a_0 = v_xs_243; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str0), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str3)));
    V v_t_247 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_b_242));
    return heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str5), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2earmOf_24s139775371x1736504365_str6)))));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2earmOf_24s139775371x1736504365_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2earmOf_24s139775371x1736504365(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 76, 111, 99, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 71, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str13 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 76, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str16 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str23 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str25 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 67, 111, 110, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str29 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 111, 106, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str36 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str38 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 84, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str41 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 77, 107, 80, 97, 105, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str48 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 68, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str50 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 83, 77, 97, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str55 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 83, 112, 101, 99, 105, 97, 108, 105, 122, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str59 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 83, 73, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str61 = {{0x80000000u, K_STR, 0}, 7, 7, {83, 79, 112, 97, 113, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str62 = {{0x80000000u, K_STR, 0}, 8, 8, {83, 65, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str63 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 82, 101, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str65 = {{0x80000000u, K_STR, 0}, 6, 6, {40, 83, 70, 105, 120, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str70 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 73, 109, 112, 108, 105, 99, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str73 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str75 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 83, 80, 114, 105, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str77 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str79 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str81 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 65, 46, 102, 114, 111, 109, 76, 105, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str83 = {{0x80000000u, K_STR, 0}, 10, 10, {40, 83, 77, 101, 116, 97, 65, 112, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str87 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str89 = {{0x80000000u, K_STR, 0}, 9, 9, {40, 83, 76, 105, 116, 73, 110, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str91 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str92 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str93 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str95 = {{0x80000000u, K_STR, 0}, 12, 12, {40, 83, 76, 105, 116, 83, 116, 114, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str96 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str97 = {{0x80000000u, K_STR, 0}, 2, 2, {73, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str98 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str99 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str100 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str101 = {{0x80000000u, K_STR, 0}, 2, 2, {85, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str102 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str103 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str104 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str105 = {{0x80000000u, K_STR, 0}, 3, 3, {70, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str106 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str107 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str108 = {{0x80000000u, K_STR, 0}, 11, 11, {40, 83, 76, 105, 116, 70, 105, 120, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str109 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str110 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str111 = {{0x80000000u, K_STR, 0}, 13, 13, {40, 83, 76, 105, 116, 70, 108, 111, 97, 116, 51, 50, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str112 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_entry, 1, 0};

V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_241 = heff_field(v_x2_240, 0);
    V v_t_244;
    if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
      V v_t_243 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_i_241)));
      v_t_244 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str0), heff_strAppend(v_t_243, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str1)));
    } else {
      v_t_244 = heff_intShow(heff_dup(v_i_241));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str2), heff_strAppend(v_t_244, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str3)));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_t_246 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_245), MK_INT(0LL)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str4), heff_strAppend(v_t_246, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str5)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str6), heff_strAppend(v_t_247, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str7)));
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_t_249 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_a_248));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str8), heff_strAppend(v_t_249, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str9)));
  }
  case TAG_SApp: {
    V v_f_2410 = heff_field(v_x2_240, 0);
    V v_a_2411 = heff_field(v_x2_240, 1);
    V v_t_2412 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_f_2410));
    V v_t_2413 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_a_2411));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str10), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str11), heff_strAppend(v_t_2413, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str12)))));
  }
  case TAG_SLam: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_a_2414));
    V v_t_2417 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), v_b_2415));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str13), heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str14), heff_strAppend(v_t_2417, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str15)))));
  }
  case TAG_SCons: {
    V v_d_2418 = heff_field(v_x2_240, 0);
    V v_t_2419 = heff_arrayToList(heff_get(heff_dup(v_d_2418), LBL_keys));
    V v_t_2420 = heff_arrayToList(heff_get(heff_dup(v_d_2418), LBL_values));
    V v_t_2421 = (g_heff_2edict_2ezipKV(v_t_2419, v_t_2420));
    V v_xs_2422 = (g_list_2emap_24s1486836708x2052186263(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str16), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str17), MK_INT(0LL), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str18), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str19), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str20), v_t_2421));
    V v_t_2423 = ({ V a_0 = v_xs_2422; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2422); r_; });
    V v_t_2424 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str21), heff_strAppend(v_t_2423, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str22)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str23), heff_strAppend(v_t_2424, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str24)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str25), heff_strAppend(v_t_2425, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str26)));
  }
  case TAG_SProj: {
    V v_t_2426 = heff_field(v_x2_240, 0);
    V v_x_2427 = heff_field(v_x2_240, 1);
    V v_t_2428 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2426));
    V v_t_2429 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2427), MK_INT(0LL)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str27), heff_strAppend(v_t_2429, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str28)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str29), heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str30), heff_strAppend(v_t_2430, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str31)))));
  }
  case TAG_STag: {
    V v_x_2431 = heff_field(v_x2_240, 0);
    V v_ts_2432 = heff_field(v_x2_240, 1);
    V v_t_2433 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2431), MK_INT(0LL)));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str32), heff_strAppend(v_t_2433, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str33)));
    V v_xs_2435 = (g_list_2emap(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), heff_arrayToList(heff_dup(v_ts_2432))));
    V v_t_2436 = ({ V a_0 = v_xs_2435; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2435); r_; });
    V v_t_2437 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str34), heff_strAppend(v_t_2436, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str35)));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str36), heff_strAppend(v_t_2437, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str37)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str38), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str39), heff_strAppend(v_t_2438, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str40)))));
  }
  case TAG_SMatch: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_arms_2440 = heff_field(v_x2_240, 1);
    V v_t_2441 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2439));
    V v_t_2442 = heff_arrayToList(heff_get(heff_dup(v_arms_2440), LBL_keys));
    V v_t_2443 = heff_arrayToList(heff_get(heff_dup(v_arms_2440), LBL_values));
    V v_t_2444 = (g_heff_2edict_2ezipKV(v_t_2442, v_t_2443));
    V v_xs_2445 = (g_list_2emap_24s1107296543x493652800(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str41), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str42), MK_INT(0LL), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str43), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str44), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str45), v_t_2444));
    V v_t_2446 = ({ V a_0 = v_xs_2445; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2445); r_; });
    V v_t_2447 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str46), heff_strAppend(v_t_2446, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str47)));
    V v_t_2448 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str48), heff_strAppend(v_t_2447, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str49)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str50), heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str51), heff_strAppend(v_t_2448, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str52)))));
  }
  case TAG_SSpecialize: {
    V v_t_2449 = heff_field(v_x2_240, 0);
    V v_x_2450 = heff_field(v_x2_240, 1);
    V v_t_27_2451 = heff_field(v_x2_240, 2);
    V v_t_2452 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2449));
    V v_t_2453 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2450), MK_INT(0LL)));
    V v_t_2454 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str53), heff_strAppend(v_t_2453, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str54)));
    V v_t_2455 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_27_2451));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str55), heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str56), heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str57), heff_strAppend(v_t_2455, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str58)))))));
  }
  case TAG_SIs: {
    V v_t_2456 = heff_field(v_x2_240, 0);
    V v_t_2457 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2456));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str59), heff_strAppend(v_t_2457, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str60)));
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str61);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str62);
  }
  case TAG_SRec: {
    V v_t_2458 = heff_field(v_x2_240, 0);
    V v_t_2459 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2458));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str63), heff_strAppend(v_t_2459, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str64)));
  }
  case TAG_SFix: {
    V v_a_2460 = heff_field(v_x2_240, 0);
    V v_b_2461 = heff_field(v_x2_240, 1);
    V v_t_2462 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_a_2460));
    V v_t_2463 = (g_heff_2eprint_2eabsOf(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_el), v_b_2461));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str65), heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str66), heff_strAppend(v_t_2463, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str67)))));
  }
  case TAG_SImplicit: {
    V v_x_2464 = heff_field(v_x2_240, 0);
    V v_t_2465 = heff_field(v_x2_240, 1);
    V v_t_2466 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2464), MK_INT(0LL)));
    V v_t_2467 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str68), heff_strAppend(v_t_2466, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str69)));
    V v_t_2468 = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(v_t_2465));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str70), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str71), heff_strAppend(v_t_2468, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str72)))));
  }
  case TAG_SPrim: {
    V v_x_2469 = heff_field(v_x2_240, 0);
    V v_t_2470 = (g_heff_2eprint_2eescFrom(heff_dup(v_x_2469), MK_INT(0LL)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str73), heff_strAppend(v_t_2470, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str74)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str75), heff_strAppend(v_t_2471, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str76)));
  }
  case TAG_SMetaApp: {
    V v_m_2472 = heff_field(v_x2_240, 0);
    V v_idxs_2473 = heff_field(v_x2_240, 1);
    V v_a_2474 = heff_field(v_x2_240, 2);
    V v_t_2477;
    if (heff_intLt_c(heff_dup(v_m_2472), MK_INT(0LL))) {
      V v_t_2476 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_m_2472)));
      v_t_2477 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str77), heff_strAppend(v_t_2476, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str78)));
    } else {
      v_t_2477 = heff_intShow(heff_dup(v_m_2472));
    }
    V v_xs_2478 = (g_list_2emap_24s1300207191x1224487257(heff_arrayToList(heff_dup(v_idxs_2473))));
    V v_t_2479 = ({ V a_0 = v_xs_2478; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_xs_2478); r_; });
    V v_t_2480 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str79), heff_strAppend(v_t_2479, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str80)));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str81), heff_strAppend(v_t_2480, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str82)));
    V v_t_2482 = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(v_a_2474));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str83), heff_strAppend(v_t_2477, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str84), heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str85), heff_strAppend(v_t_2482, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str86)))))));
  }
  case TAG_SLitInt: {
    V v_n_2483 = heff_field(v_x2_240, 0);
    V v_t_2486;
    if (heff_intLt_c(heff_dup(v_n_2483), MK_INT(0LL))) {
      V v_t_2485 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2483)));
      v_t_2486 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str87), heff_strAppend(v_t_2485, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str88)));
    } else {
      v_t_2486 = heff_intShow(heff_dup(v_n_2483));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str89), heff_strAppend(v_t_2486, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str90)));
  }
  case TAG_SLitFloat: {
    V v_x_2487 = heff_field(v_x2_240, 0);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str91), heff_strAppend(heff_floatShow(heff_dup(v_x_2487)), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str92)));
  }
  case TAG_SLitString: {
    V v_s_2488 = heff_field(v_x2_240, 0);
    V v_t_2489 = (g_heff_2eprint_2eescFrom(heff_dup(v_s_2488), MK_INT(0LL)));
    V v_t_2490 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str93), heff_strAppend(v_t_2489, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str94)));
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str95), heff_strAppend(v_t_2490, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str96)));
  }
  case TAG_SLitFixed: {
    V v_w_2491 = heff_field(v_x2_240, 0);
    V v_n_2492 = heff_field(v_x2_240, 1);
    V v_t_2493;
    switch (heff_tag_of(v_w_2491)) {
    case TAG_I8: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str97);
      break;
    }
    case TAG_I16: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str98);
      break;
    }
    case TAG_I32: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str99);
      break;
    }
    case TAG_I64: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str100);
      break;
    }
    case TAG_U8: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str101);
      break;
    }
    case TAG_U16: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str102);
      break;
    }
    case TAG_U32: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str103);
      break;
    }
    case TAG_U64: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str104);
      break;
    }
    case TAG_F32: {
      v_t_2493 = ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str105);
      break;
    }
    default: heff_nomatch(v_w_2491);
    }
    V v_t_2496;
    if (heff_intLt_c(heff_dup(v_n_2492), MK_INT(0LL))) {
      V v_t_2495 = heff_intShow(heff_intSub(MK_INT(0LL), heff_dup(v_n_2492)));
      v_t_2496 = heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str106), heff_strAppend(v_t_2495, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str107)));
    } else {
      v_t_2496 = heff_intShow(heff_dup(v_n_2492));
    }
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str108), heff_strAppend(v_t_2493, heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str109), heff_strAppend(v_t_2496, ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str110)))));
  }
  case TAG_SLitFloat32: {
    V v_x_2497 = heff_field(v_x2_240, 0);
    return heff_strAppend(((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str111), heff_strAppend(heff_floatShow(heff_dup(v_x_2497)), ((V)&g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_str112)));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(a[0]); heff_drop(a[0]); return r;
}