// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_col 308218
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s375411411x525089187(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s375411411x525089187_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s375411411x525089187_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543(V);
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1345968422x916930247(V, V, V);
V g_list_2eany_24s1345968422x916930247_entry(V self, V *a);
extern Clo g_list_2eany_24s1345968422x916930247_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s41451459x2069155315_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s851015108x1468688003(V, V);
V g_list_2efoldl_24s851015108x1468688003_entry(V self, V *a);
extern Clo g_list_2efoldl_24s851015108x1468688003_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1511525408x973271992(V, V);
V g_list_2ekeepIf_24s1511525408x973271992_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1511525408x973271992_clo;
V g_list_2ekeepIf_24s1796013173x2143580739(V, V);
V g_list_2ekeepIf_24s1796013173x2143580739_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1796013173x2143580739_clo;
V g_list_2ekeepIf_24s188390362x2017344139(V, V, V);
V g_list_2ekeepIf_24s188390362x2017344139_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s188390362x2017344139_clo;
V g_list_2ekeepIf_24s684755021x1118425975(V, V);
V g_list_2ekeepIf_24s684755021x1118425975_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s684755021x1118425975_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 1, ":");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_245 = NTAG(TAG_Nothing);
  } else {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
  }
  V v_t_246 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_dup(heff_rfield(v_p_242, 0)), MK_INT(0LL), MK_INT(0LL), v_t_245));
  V v_t_247 = heff_intAdd(heff_get_n(v_t_246, 0, 3), MK_INT(1LL));
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), v_src_241, MK_INT(0LL), 5);
  V v_t_2410;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_2410 = NTAG(TAG_Nothing);
  } else {
    v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  V v_t_2411 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_take_field(v_p_242, 0), MK_INT(0LL), MK_INT(0LL), v_t_2410));
  V v_t_2412 = heff_intAdd(heff_get_n(v_t_2411, 2, 3), MK_INT(1LL));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), heff_get_n(v_p_242, 1, 2));
  V v_t_2414 = heff_strAppend(heff_intShow(v_t_2412), v_t_2413);
  V v_t_2415 = heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3), v_t_2414));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4), v_t_2415));
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eproblemMsg(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_s_243 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedDir_str0), v_v_242));
  V v_x2_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_p_249;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_p_249 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Posix: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    v_p_249 = ({ V a_0 = v_t_248; V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_st_2410 = heff_take_field(v_ps_240, 5);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, heff_get_n(v_ps_240, 3, 6)));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, v_p_249));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  return ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_k_244, 1)), heff_dup(v_from_243)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_ps_240);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_t_246);
      return heff_dup(v_k_244);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_ps_240;
      V t_1 = v_rest_245;
      V t_2 = v_project_242;
      V t_3 = v_from_243;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      v_project_242 = t_2;
      v_from_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2ekeepIf_24s1796013173x2143580739(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_pkgs_241);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_pkgs_241; V a_1 = v_p_249; HeffT2 r_ = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(a_0, a_1)); heff_drop(v_p_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2414 = v_field_2412;
          V v_base_2415 = heff_take_field(v_q_2414, 2);
          V v_m_2416 = heff_strAppend(heff_take_field(v_q_2414, 3), heff_dup(v_rest_244));
          V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0); V a_1 = v_m_2416; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2416, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2416); r_; });
          V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
          V v_parts_2422;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2419 = heff_field(v_t_2418, 0);
            V v_before_2420 = heff_field(v_t_2418, 1);
            heff_take_n(v_t_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2419, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), v_before_2420});
            v_parts_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2421));
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2429 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2415), v_parts_2422));
          V v_t_2430 = heff_strAppend(heff_get_n(v_q_2414, 4, 7), v_rest_244);
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2429, v_base_2415, v_parts_2422, v_t_2430}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2423 = args[0];
  V v_p_2424 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2425 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2425, v_d_2423));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_2425, v_p_2424));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  return ({ V a_0 = v_st_2425; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); heff_drop(v_t_2428); r_; });
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 8, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_named_243, V v_path_244, V v_src_245, V v_implicit_246, V v_renames_247) {
top: ;
  HeffT2 v_t_248 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_244)));
  V v_t_2417;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_rel_2412 = v_field_2410;
      V v_st_2413 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2414 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ebuild_2eload_2epushDone_str0)));
      V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, v_rel_2412));
      V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
      v_t_2417 = ({ V a_0 = v_st_2413; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); heff_drop(v_t_2416); r_; });
    } else {
      heff_drop(v_field_2410);
      v_t_2417 = heff_dup(v_path_244);
    }
  }
  HeffT2 v_t_2418 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_244)));
  V v_t_2423;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    v_t_2423 = heff_bool(((v_tag_2419 == ((int64_t)0ULL)) && ({ V v_x_2422 = heff_dup(v_field_2420); int c_ = 1; heff_drop(v_x_2422); c_; })));
    heff_drop(v_field_2420);
  }
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_named_243, v_path_244, v_t_2417, v_src_245, v_renames_247, v_implicit_246, v_t_2423}), NTAG(TAG_Nil)});
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2424));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2425; V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 55, ", and the imports of it, so that the name is one file's");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 9, ": module ");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s2087317732x355496638(heff_dup(v_found_241)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  HeffT2 v_t_2414 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), heff_dup(v_found_241)));
  V v_t_2421;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2418 = v_field_2416;
      v_t_2421 = heff_get_n(v_f_2418, 0, 5);
    } else {
      heff_drop(v_field_2416);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2);
        break;
      }
      case TAG_Cons: {
        V v_f_2419 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2421 = heff_get_n(v_f_2419, 0, 5);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
  }
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str3), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4)));
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str5), heff_strAppend(v_t_247, v_t_2422));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str6), heff_strAppend(v_m_243, v_t_2423));
  return heff_strAppend(v_from_242, v_t_2424);
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_248, 0, 5)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2413 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2413); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str2, 3, "src");
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_d_242)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_248); r_; });
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0, 2, 4, (V[]){v_c_249, v_d_242, v_h_240, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_start_241 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    if (heff_strEq_c_lent(v_d_242, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str1), 2)) {
      heff_drop(v_d_242);
      V v_st_2414 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(v_st_2414, heff_dup(heff_rfield(v_h_240, 2))));
      V v_t_2425;
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        V v_d_2419 = v_field_2416;
        V v_a_2420 = v_field_2417;
        V v_xs_2421 = v_field_2418;
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
        V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
        v_t_2425 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2419, v_a_2420, v_t_2424});
      }
      V v_t_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_start_241, v_t_2426));
      V f_ = v_t_2427;
      heff_room[0] = v_hd_2410;
      heff_room[1] = v_k_2411;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_st_2428 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2429 = (g_std_2epath_2eparse_24cpr(v_st_2428, heff_dup(v_d_242)));
      V v_t_2439;
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_field_2432 = v_t_2429.f[2];
        V v_d_2433 = v_field_2430;
        V v_a_2434 = v_field_2431;
        V v_xs_2435 = v_field_2432;
        V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2435));
        V v_xs_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2436; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2436); r_; });
        V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
        v_t_2439 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2433, v_a_2434, v_t_2438});
      }
      V v_t_2440 = ({ V a_0 = v_st_2428; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2439); r_; });
      if (heff_strEq_c_lent(v_t_2440, v_d_242, 1)) {
        heff_drop(v_d_242);
        heff_drop(v_hd_2410);
        V v_t_2442 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
        V f_ = v_k_2411;
        args[0] = v_t_2442;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        V v_st_2443 = heff_dup(heff_rfield(v_h_240, 3));
        HeffT3 v_t_2444 = (g_std_2epath_2eparse_24cpr(v_st_2443, v_d_242));
        V v_t_2454;
        {
          V v_field_2445 = v_t_2444.f[0];
          V v_field_2446 = v_t_2444.f[1];
          V v_field_2447 = v_t_2444.f[2];
          V v_d_2448 = v_field_2445;
          V v_a_2449 = v_field_2446;
          V v_xs_2450 = v_field_2447;
          V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2450));
          V v_xs_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2451); r_; });
          V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
          v_t_2454 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2448, v_a_2449, v_t_2453});
        }
        V v_t_2455 = ({ V a_0 = v_st_2443; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2443); heff_drop(v_t_2454); r_; });
        V v_t_2456 = (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_start_241, v_t_2455));
        V f_ = v_t_2456;
        heff_room[0] = v_hd_2410;
        heff_room[1] = v_k_2411;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_Just: {
    heff_drop(v_start_241);
    heff_drop(v_hd_2410);
    V v_st_2458 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_2459 = (g_std_2epath_2eparse(v_st_2458, heff_dup(v_d_242)));
    V v_t_2460 = (g_std_2epath_2eparse(v_st_2458, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str2)));
    V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
    V v_t_2462 = ({ V a_0 = v_st_2458; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2458); heff_drop(v_t_2461); r_; });
    V v_t_2471;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nothing: {
      v_t_2471 = heff_dup(heff_rfield(v_h_240, 0));
      break;
    }
    case TAG_Just: {
      V v_hf_2463 = heff_field(v_x_2412, 0);
      V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
      HeffT2 v_t_2464 = ({ V a_0 = v_hf_2463; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_hf_2463); r_; });
      V v_t_2470;
      {
        V v_field_2466 = v_t_2464.f[1];
        int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
        if ((v_tag_2465 == ((int64_t)0ULL))) {
          V v_p_2468 = v_field_2466;
          v_t_2470 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_p_2468});
        } else {
          heff_drop_cell(v_ru_24x_2412_24Just, 1);
          V v_x_2469 = v_field_2466;
          v_t_2470 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2469));
        }
      }
      v_t_2471 = ({ V a_0 = heff_dup(v_h_240); V a_1 = heff_dup(v_d_242); V a_2 = v_t_2470; V r_ = (g_heff_2ebuild_2eload_2elibRead(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_x_2472 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2462, v_t_2471, heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
    V f_ = v_k_2411;
    args[0] = v_x_2472;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_h_240 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1, 1, 5, (V[]){v_d_242, v_h_240, v_start_241, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str2, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str6, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str7, 16, " is the package ");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_dir_241)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_248); r_; });
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0, 2, 4, (V[]){v_c_249, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2451;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop(v_path_242);
    V v_st_2413 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2414 = (g_std_2epath_2eparse(v_st_2413, v_dir_241));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str1)));
    V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
    V v_t_2417 = ({ V a_0 = v_st_2413; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); heff_drop(v_t_2416); r_; });
    v_x_2451 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str2))});
    break;
  }
  case TAG_Just: {
    V v_t_2418 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    HeffT2 v_t_2419 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2418));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_path_242);
        V v_p_2423 = v_field_2421;
        V v_st_2424 = heff_get_n(v_ps_240, 5, 6);
        V v_t_2425 = (g_std_2epath_2eparse(v_st_2424, v_dir_241));
        V v_t_2426 = (g_std_2epath_2eparse(v_st_2424, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str3)));
        V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
        V v_t_2428 = ({ V a_0 = v_st_2424; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2427); r_; });
        V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_t_2418; V a_2 = v_p_2423; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
        v_x_2451 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2429});
      } else {
        V v_x_2430 = v_field_2421;
        HeffT2 v_t_2431 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2430));
        {
          V v_field_2433 = v_t_2431.f[1];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          if ((v_tag_2432 == ((int64_t)0ULL))) {
            heff_drop(v_path_242);
            V v_p_2435 = v_field_2433;
            V v_st_2436 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, v_dir_241));
            V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str4)));
            V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
            V v_t_2440 = ({ V a_0 = v_st_2436; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2439); r_; });
            V v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_t_2418; V a_2 = v_p_2435; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
            v_x_2451 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2441});
          } else {
            heff_drop(v_t_2418);
            V v_pk_2442 = v_field_2433;
            if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2442, 0)), heff_dup(v_path_242))) {
              heff_drop_rec(v_ps_240, 6);
              heff_drop(v_dir_241);
              heff_drop(v_path_242);
              v_x_2451 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Right, 1, (V[]){v_pk_2442});
            } else {
              V v_st_2444 = heff_get_n(v_ps_240, 5, 6);
              V v_t_2445 = (g_std_2epath_2eparse(v_st_2444, v_dir_241));
              V v_t_2446 = (g_std_2epath_2eparse(v_st_2444, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str5)));
              V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
              V v_t_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
              V v_t_2449 = heff_strAppend(heff_get_n(v_pk_2442, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str6), v_path_242));
              V v_t_2450 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str7), v_t_2449));
              v_x_2451 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2450});
            }
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_2411;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str3, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str6, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str9, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str10, 1, " ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2ekeepIf_24s684755021x1118425975(v_path_244, heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2ekeepIf_24s1511525408x973271992(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_s_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str0));
    V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2414; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2415); r_; });
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0, 2, 6, (V[]){v_c_2416, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2447 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2448 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2449 = (g_std_2epath_2eparse(v_st_2448, heff_dup(heff_rfield(v_ps_240, 0))));
    V v_t_2450 = (g_std_2epath_2eparse(v_st_2448, v_d_2447));
    V v_t_2451 = (g_std_2epath_2ejoin(v_t_2449, v_t_2450));
    V v_t_2452 = ({ V a_0 = v_st_2448; V a_1 = v_t_2451; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2448); heff_drop(v_t_2451); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2452, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2417);
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str1), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str2)));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str3), heff_strAppend(v_path_244, v_t_2420));
    V v_t_2422 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_by_243, v_t_2421)});
    V f_ = v_k_2418;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2423 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Just = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2424 = (g_list_2ekeepIf_24s188390362x2017344139(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2417);
      heff_drop(v_h_2423);
      heff_drop_cell(v_ru_24x_2419_24Just, 1);
      V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str5)));
      V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str6), heff_strAppend(v_path_244, v_t_2425));
      V f_ = v_k_2418;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2426});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_s_2427 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 2);
      V v_want_2429 = heff_get_n(v_s_2427, 2, 3);
      V v_t_2430 = (g_prelude_2eskipSpaces(v_h_2423, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_h_2423, 0)) - ((int64_t)1ULL));
      V v_t_2432 = (g_prelude_2eskipSpaces(v_h_2423, heff_box_word(v_t_2431), MK_INT(-1LL)));
      V v_t_2433 = heff_strSlice(heff_dup(v_h_2423), v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2433, v_want_2429, 1)) {
        heff_drop(v_h_2423);
        heff_drop_cell(v_ru_24x_2419_24Just, 1);
        heff_drop(v_want_2429);
        V v_t_2435 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2436 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2435, v_path_244));
        V f_ = v_t_2436;
        heff_room[0] = v_hd_2417;
        heff_room[1] = v_k_2418;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2417);
        V v_t_2437 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2438 = (g_prelude_2eskipSpaces(v_h_2423, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_h_2423, 0)) - ((int64_t)1ULL));
        V v_t_2440 = (g_prelude_2eskipSpaces(v_h_2423, heff_box_word(v_t_2439), MK_INT(-1LL)));
        V v_t_2441 = heff_strSlice(v_h_2423, v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
        V v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str7), v_want_2429));
        V v_t_2443 = heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str8), v_t_2442));
        V v_t_2444 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str9), v_t_2443));
        V v_t_2445 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str10), v_t_2444));
        V v_x_2446 = heff_tag_at_n(v_ru_24x_2419_24Just, TAG_Left, 1, (V[]){v_t_2445});
        V f_ = v_k_2418;
        args[0] = v_x_2446;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2418, v_sums_242, v_ps_240, v_hd_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str7, 24, " cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str10, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str11, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry, 2, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V v_ps_240, V v_src_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_src_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_242));
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0, 2, 3, (V[]){v_c_243, v_src_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2437;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str5), heff_strAppend(v_x_2414, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str6)));
    v_x_2437 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2424)});
    break;
  }
  case TAG_Just: {
    V v_ru_24x_2423_24Just = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_st_2426 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2427 = (g_std_2epath_2eparse(v_st_2426, v_src_241));
    V v_t_2428 = (g_std_2epath_2eparse(v_st_2426, heff_dup(v_x_2414)));
    V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
    V v_dir_2430 = ({ V a_0 = v_st_2426; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2429); r_; });
    HeffT2 v_t_2431 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2414));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        heff_drop(v_x_2414);
        V v_why_2435 = v_field_2433;
        V v_t_2436 = heff_strAppend(v_dir_2430, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str7), v_why_2435));
        v_x_2437 = heff_tag_at_n(v_ru_24x_2423_24Just, TAG_Left, 1, (V[]){v_t_2436});
      } else {
        heff_drop(v_dir_2430);
        heff_drop(v_field_2433);
        v_x_2437 = heff_tag_at_n(v_ru_24x_2423_24Just, TAG_Right, 1, (V[]){v_x_2414});
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_245;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_244);
    V v_t_247 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str0))});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_248 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_244);
      V v_t_2411;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_it1_248, 0);
        V v_xs_2410 = heff_field(v_it1_248, 1);
        heff_take_n(v_it1_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_it1_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str4)));
      V v_x_2413 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2412)});
      V f_ = v_k_245;
      args[0] = v_x_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_dup(heff_field(v_it1_248, 0));
      V v_it12_2415 = heff_dup(heff_field(v_it1_248, 1));
      switch (heff_tag_of(v_it12_2415)) {
      case TAG_Nil: {
        heff_drop_tag(v_it1_248, 2);
        heff_drop_cell(v_ru_24x_246_24Just, 1);
        V v_st_2416 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2417 = (g_std_2epath_2eparse(v_st_2416, heff_dup(v_src_241)));
        V v_t_2418 = (g_std_2epath_2eparse(v_st_2416, heff_dup(v_x_2414)));
        V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
        V v_s_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
        V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_c_2422 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_2421));
        V f_ = v_c_2422;
        heff_room[0] = v_hd_244;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2, 1, 4, (V[]){v_x_2414, v_src_241, v_ps_240, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2415, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_244);
        heff_drop(v_x_2414);
        V v_t_2442;
        switch (heff_tag_of(v_it1_248)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_it1_248, 0);
          V v_xs_2441 = heff_field(v_it1_248, 1);
          heff_take_n(v_it1_248, 3ULL, 2);
          v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str9); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_it1_248);
        }
        V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str10), heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str11)));
        V v_x_2444 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2443)});
        V f_ = v_k_245;
        args[0] = v_x_2444;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2415);
      }
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1, 1, 4, (V[]){v_src_241, v_k_245, v_ps_240, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_t_244 = (g_list_2ekeepIf_24s684755021x1118425975(heff_rfield(v_x_242, 0), heff_take_field(v_root_241, 2)));
  V v_x_2414;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_x_2414 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
    break;
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_t_247 = (g_list_2ekeepIf_24s1511525408x973271992(v_r_245, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_x_2414 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
      break;
    }
    case TAG_Cons: {
      V v_p_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 2);
      V v_st_2410 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, heff_dup(heff_rfield(v_ps_240, 0))));
      V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, heff_get_n(v_p_248, 1, 2)));
      V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
      v_x_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0, 2, 4, (V[]){v_ps_240, v_x_2414, v_pk_243, v_x_242});
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2433;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_why_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2414);
    heff_drop_rec(v_pk_243, 4);
    heff_drop_rec(v_x_242, 3);
    v_x_2433 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_Left, 1, (V[]){v_why_2424});
    break;
  }
  case TAG_Right: {
    V v_name_2425 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    V v_st_2426 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2427 = (g_std_2epath_2eparse(v_st_2426, heff_dup(v_x_2414)));
    V v_t_2428 = (g_std_2epath_2eparse(v_st_2426, ((V)&g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str1)));
    V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
    V v_t_2430 = ({ V a_0 = v_st_2426; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2429); r_; });
    V v_t_2431 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_pk_243, 2)));
    V v_t_2432 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_get_n(v_x_242, 0, 3), v_x_2414, v_t_2430, heff_dup(v_name_2425), v_name_2425, heff_get_n(v_pk_243, 1, 4), v_t_2431});
    v_x_2433 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Right, 1, (V[]){v_t_2432});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_2417, heff_dup(v_x_2414)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2417, ((V)&g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_str0)));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
  V v_t_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
  V v_c_2422 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(heff_dup(v_ps_240), v_t_2421));
  V f_ = v_c_2422;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_lam1, 1, 5, (V[]){v_ps_240, v_x_2414, v_pk_243, v_x_242, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x31_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(heff_dup(v_ps_240), heff_dup(v_root_241), v_x31_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    V f_ = v_t_2418;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    V f_ = v_t_2422;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0, 2, 3, (V[]){v_c_242, v_root_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_seen_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2418; V a_1 = v_seen_2416; V r_ = (g_list_2efoldl_24s851015108x1468688003(a_0, a_1)); heff_drop(v_seen_2416); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_x_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2425 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2427 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2430;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2433;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_x_2421, 1);
    heff_take_n(v_x_2421, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2433));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2434));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2435});
  V f_ = v_k_244;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_seen_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2417 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_2416)));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3, 1, 1, (V[]){v_seen_2416}), v_t_2417));
  V v_c_2420 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2420;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4, 1, 3, (V[]){v_x_245, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str0))) {
    v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str1);
  } else {
    v_t_2410 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2411 = (g_list_2emap_24s675147852x248982264(v_t_2410, heff_dup(heff_rfield(v_root_241, 2))));
  V v_c_2412 = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248, heff_rfield(v_root_241, 0), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1, 1, 4, (V[]){v_root_241, v_ps_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str9, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str10, 30, "packages require one another: ");
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry, 2, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1, 2, 3, (V[]){v_c_248, v_ps_240, heff_dup(v_root_247)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Nothing: {
    v_t_2428 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_x_2429 = (g_list_2emap_24s1462590149x1582455373(v_t_2428));
  V v_t_2430 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_247, 2))));
  V v_t_2431 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str5), heff_dup(heff_rfield(v_root_247, 1)), v_t_2430});
  V v_t_2432 = (g_prelude_2e_2b_2b(v_x_2423, v_x_2429));
  V v_t_2433 = (g_prelude_2e_2b_2b(v_x_2417, v_t_2432));
  V v_t_2436;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2436 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2437 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2433, v_t_2436));
  V v_t_2440;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2441 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_247, 2)));
  V v_t_2442 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str7), heff_take_field(v_root_247, 1), v_t_2441});
  V v_t_2445;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 2);
    v_t_2445 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
  V v_t_2447 = (g_heff_2ebuild_2eload_2ecycleAmong(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2445}), NTAG(TAG_Nil), v_t_2446));
  V v_t_2452;
  switch (heff_tag_of(v_t_2447)) {
  case TAG_Nothing: {
    v_t_2452 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2448 = heff_field(v_t_2447, 0);
    heff_take_n(v_t_2447, 1ULL, 1);
    V v_t_2451;
    switch (heff_tag_of(v_c_2448)) {
    case TAG_Nil: {
      v_t_2451 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2449 = heff_field(v_c_2448, 0);
      V v_xs_2450 = heff_field(v_c_2448, 1);
      heff_take_n(v_c_2448, 3ULL, 2);
      v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str9); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
      break;
    }
    default: heff_nomatch(v_c_2448);
    }
    v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str10), v_t_2451), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2447);
  }
  V v_t_2453 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2452));
  V v_x_2454 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2437}), v_t_2453});
  V f_ = v_k_2410;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_x_2423 = (g_list_2emap_24s1462590149x1582455373(v_t_2422));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_ps_240, 2)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2425 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_2424));
  V f_ = v_c_2425;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2423, v_x_2417, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_x_2417 = (g_list_2emap_24s1462590149x1582455373(v_t_2416));
  V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_ps_240, 0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2419 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2417, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_ps_240, 1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2413 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_pl_243, 0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_245); r_; });
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam1, 2, 3, (V[]){v_c_246, v_rest_244, v_pl_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543(a[0]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2423;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_243, 4);
    v_x_2423 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_dup(heff_rfield(v_pl_243, 2));
    V v_p_2416;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_p_2416 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      V v_xs_2415 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      v_p_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice(heff_dup(v_p_2416), heff_box_word(v_t_2417), heff_strLength_lent(v_p_2416, 0));
    V v_t_2421;
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_str2))) {
      int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
      v_t_2421 = heff_strSlice(v_p_2416, MK_INT(0LL), heff_box_word(v_t_2420));
    } else {
      v_t_2421 = v_p_2416;
    }
    V v_t_2422 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_s_2412, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4), v_t_2421});
    v_x_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543(v_rest_244));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam3, 1, 3, (V[]){v_x_249, v_pl_243, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543_lam2, 1, 4, (V[]){v_rest_244, v_hd_247, v_pl_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0, 2, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry, 3, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V v_ps_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    return ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_d_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_248 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_247));
    return heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_x_245), v_ps_240, v_d_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2413; V a_1 = v_x_245; V r_ = (g_heff_2ebuild_2eload_2esameButCase(a_0, a_1)); heff_drop(v_n_2413); heff_drop(v_x_245); r_; });
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_hd_249);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2412));
    HeffT2 v_t_2415 = (g_heff_2ebuild_2eload_2ecasesIn_24cpr(heff_dup(v_ps_240), heff_dup(v_d_241), heff_dup(v_x_245), v_t_2414));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_x_245);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_rest_246);
        heff_drop(v_hd_249);
        V v_why_2419 = v_field_2417;
        V f_ = v_k_2410;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2419});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_field_2417);
        V v_st_2420 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2421 = (g_std_2epath_2eparse(v_st_2420, v_d_241));
        V v_t_2422 = (g_std_2epath_2eparse(v_st_2420, v_x_245));
        V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
        V v_t_2424 = ({ V a_0 = v_st_2420; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2423); r_; });
        V v_t_2425 = ({ V a_0 = v_ps_240; V a_1 = v_t_2424; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
        V f_ = v_t_2425;
        heff_room[0] = v_hd_249;
        heff_room[1] = v_k_2410;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2, 1, 6, (V[]){v_k_2410, v_x_245, v_ps_240, v_d_241, v_rest_246, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(V v_lit_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s437267306x573350543(v_t_2412));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam1, 2, 10, (V[]){v_c_2413, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam4(V self, V *args) {
  V v_x_2471 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_from_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_dup(heff_field(v_x_2471, 0));
    v_t_2474 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2477;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_y_2476 = heff_field(v_x_2471, 1);
    heff_take_n(v_x_2471, 2ULL, 2);
    v_t_2477 = v_y_2476;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2478 = (g_heff_2ebuild_2eload_2epushDone(v_t_2474, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2429, 3)), heff_take_field(v_f_2429, 4), heff_take_field(v_f_2429, 0), heff_take_field(v_f_2429, 1), heff_dup(v_lit_240), v_t_2477));
  V v_m_2479 = heff_get_n(v_f_2429, 3, 5);
  V v_t_2481;
  if (heff_strEq_c_lent(v_w_2410, v_m_2479, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2479);
    v_t_2481 = v_rs_247;
  } else {
    v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2479}), v_rs_247});
  }
  V v_t_2482 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2478, v_t_2481));
  V f_ = v_t_2482;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam3(V self, V *args) {
  V v_x_2458 = args[0];
  V v_f_2429 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  V v_pkgs_242 = heff_env(self)[7];
  V v_hd_2414 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2415 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2429, 3)), heff_dup(v_stack_243)});
  V v_t_2460 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(heff_rfield(v_f_2429, 1))));
  V v_imps_2461 = heff_get_n(v_t_2460, 0, 4);
  V v_t_2462 = (g_list_2emap_24s1817208647x1282894070(v_imps_2461));
  V v_t_2463 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2462));
  V v_t_2469;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_t_2469 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2464 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    V v_t_2465 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str9), v_why_2464));
    V v_t_2466 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str10), v_t_2465));
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
    V v_t_2468 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2467));
    v_t_2469 = ({ V rv_2 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_c_2470 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(heff_dup(v_lit_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2459, heff_dup(heff_rfield(v_f_2429, 0)), v_t_2463, v_t_2469, NTAG(TAG_Nil)));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam4, 1, 11, (V[]){v_ps_241, v_f_2429, v_lit_240, v_w_2410, v_rs_247, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s435407392x1528135477(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str2), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str3)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str4), heff_strAppend(v_w_2410, v_t_2422));
    V v_e_2424 = heff_strAppend(heff_dup(v_from_244), v_t_2423);
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2428 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2427, v_rs_247));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2429 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2430 = heff_dup(heff_field(v_x_2416, 1));
    V v_t_2431 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
    V v_t_2432 = (g_list_2eany(v_t_2431, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2430);
      heff_drop(v_t_2432);
      V v_m_2433 = heff_get_n(v_f_2429, 3, 5);
      V v_t_2435;
      if (heff_strEq_c_lent(v_w_2410, v_m_2433, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2433);
        v_t_2435 = v_rs_247;
      } else {
        v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2433}), v_rs_247});
      }
      V v_t_2436 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2435));
      V f_ = v_t_2436;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2432);
      V v_t_2437 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
      V v_t_2438 = (g_list_2eany(v_t_2437, v_stack_243));
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2430);
        heff_drop(v_t_2438);
        V v_m_2439 = heff_dup(heff_rfield(v_f_2429, 3));
        V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2439), NTAG(TAG_Nil)});
        V v_x2_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
        V v_t_2445;
        switch (heff_tag_of(v_x2_2442)) {
        case TAG_Nil: {
          v_t_2445 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2443 = heff_field(v_x2_2442, 0);
          V v_xs_2444 = heff_field(v_x2_2442, 1);
          heff_take_n(v_x2_2442, 3ULL, 2);
          v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str6); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2442);
        }
        V v_t_2446 = heff_strAppend(v_m_2439, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str7), v_t_2445));
        V v_e_2447 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_str8), v_t_2446));
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2447, NTAG(TAG_Nil)});
        V v_t_2449 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2448));
        V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2451 = heff_get_n(v_f_2429, 3, 5);
        V v_t_2453;
        if (heff_strEq_c_lent(v_w_2410, v_m_2451, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2451);
          v_t_2453 = v_rs_247;
        } else {
          v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2451}), v_rs_247});
        }
        V v_t_2454 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2450, v_t_2453));
        V f_ = v_t_2454;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2438);
        switch (heff_tag_of(v_others_2430)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2416, 2);
          V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_f_2429, 2)), 1, 4);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2429, 2)), 2, 4);
          V v_c_2457 = ({ V a_0 = heff_dup(v_ps_241); V a_1 = v_t_2455; V a_2 = v_t_2456; V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, a_2)); heff_drop(v_t_2456); r_; });
          V f_ = v_c_2457;
          heff_room[0] = heff_dup(v_hd_2414);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam3, 1, 12, (V[]){v_f_2429, v_stack_243, v_lit_240, v_st_246, v_w_2410, v_from_244, v_ps_241, v_pkgs_242, v_hd_2414, v_rs_247, v_rest_2411, v_k_2415});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2430_24Cons = heff_take_reuse_n(v_others_2430, 0ULL, 2);
          V v_e_2485 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2416, heff_dup(v_from_244), heff_dup(v_w_2410)));
          V v_t_2486 = heff_tag_at_n(v_ru_24others_2430_24Cons, TAG_Cons, 2, (V[]){v_e_2485, NTAG(TAG_Nil)});
          V v_t_2487 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2486));
          V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2429, 3)), heff_take_field(v_st_246, 1)});
          V v_t_2489 = ({ V rv_1 = v_t_2488; V rv_2 = v_t_2487; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2490 = heff_get_n(v_f_2429, 3, 5);
          V v_t_2492;
          if (heff_strEq_c_lent(v_w_2410, v_m_2490, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2490);
            v_t_2492 = v_rs_247;
          } else {
            v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2490}), v_rs_247});
          }
          V v_t_2493 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2489, v_t_2492));
          V f_ = v_t_2493;
          heff_room[0] = v_hd_2414;
          heff_room[1] = v_k_2415;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2430);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s1338026343x609171059(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam1, 2, 7, (V[]){v_c_2411, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_before_243, v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2420 = (g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411(v_ps_240, v_pkgs_241, v_from_242, v_t_2416, v_ms_249, v_t_2419));
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411_lam2, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam0, 2, 3, (V[]){v_c_242, v_h_240, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam6(V self, V *args) {
  V v_m_2444 = args[0];
  V v_made_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = ({ V a_0 = v_m_2444; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2444); r_; });
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_s_2449 = v_field_2447;
      return heff_get_n(v_s_2449, 6, 8);
    } else {
      heff_drop(v_field_2447);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2427 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2454;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_dup(heff_field(v_x_2451, 0));
    v_t_2454 = v_x_2452;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2455 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2456 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2457 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2458 = ({ V a_0 = v_m_2457; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2457); r_; });
  V v_t_2463;
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    if ((v_tag_2459 == ((int64_t)0ULL))) {
      V v_s_2462 = v_field_2460;
      v_t_2463 = heff_get_n(v_s_2462, 6, 8);
    } else {
      heff_drop(v_field_2460);
      v_t_2463 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2466;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_y_2465 = heff_field(v_x_2451, 1);
    heff_take_n(v_x_2451, 2ULL, 2);
    v_t_2466 = v_y_2465;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2467 = (g_heff_2ebuild_2eload_2epushDone(v_t_2454, heff_dup(v_x_245), v_t_2455, v_t_2456, v_file_241, v_src_2421, v_t_2463, v_t_2466));
  V v_x_2468 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2467; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_made_2427 = heff_get_n(v_x_2426, 0, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_m_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2434 = ({ V a_0 = v_m_2433; V a_1 = heff_dup(v_made_2427); HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2433); r_; });
  V v_t_2439;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_s_2438 = v_field_2436;
      v_t_2439 = heff_get_n(v_s_2438, 6, 8);
    } else {
      heff_drop(v_field_2436);
      v_t_2439 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2440 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2439, heff_dup(v_src_2421)));
  V v_imps_2441 = heff_get_n(v_t_2440, 0, 4);
  V v_t_2442 = (g_list_2emap_24s1817208647x1282894070(v_imps_2441));
  V v_t_2443 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2442));
  V v_c_2450 = (g_heff_2ebuild_2eload_2eloadMany_24s375411411x525089187(heff_dup(v_x_245), v_t_2430, v_t_2432, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam6, 1, 1, (V[]){heff_dup(v_made_2427)}), v_t_2443, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2450;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam7, 1, 7, (V[]){v_x_245, v_file_241, v_made_2427, v_src_2421, v_x_247, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s2006804781x2037627411(heff_dup(v_x_245), v_t_2424, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2425;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam5, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_src_2421, v_hd_243, v_x_247, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_file_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2414); r_; });
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam4, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = ({ V a_0 = heff_dup(v_x_245); V a_1 = v_t_2411; V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(v_h_240, heff_dup(v_x_245)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_lam1, 1, 4, (V[]){v_h_240, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_n_247, 1)), heff_dup(v_root_241))) {
      heff_drop_rec(v_n_247, 3);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    } else {
      V v_t_2410 = (g_list_2eany_24s1345968422x916930247(heff_rfield(v_n_247, 1), heff_rfield(v_n_247, 2), v_seen_243));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_n_247, 3);
        heff_drop(v_t_2410);
        V t_0 = v_rd_240;
        V t_1 = v_root_241;
        V t_2 = v_rest_248;
        V t_3 = v_seen_243;
        V t_4 = v_errs_244;
        v_rd_240 = t_0;
        v_root_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        v_errs_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2410);
        V v_c_2411 = heff_tr(heff_call(heff_dup(v_rd_240), 3, (V[]){heff_dup(heff_rfield(v_n_247, 0)), heff_dup(heff_rfield(v_n_247, 1)), heff_dup(heff_rfield(v_n_247, 2))}));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1, 2, 7, (V[]){v_c_2411, v_n_247, v_seen_243, v_errs_244, v_rd_240, heff_dup(v_root_241), v_rest_248});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_seen_243 = heff_env(self)[1];
  V v_errs_244 = heff_env(self)[2];
  V v_rd_240 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), NTAG(TAG_Nothing)});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2419));
    V v_t_2421 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_t_2418; V a_4 = v_t_2420; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2421;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2422 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_str0), heff_dup(heff_rfield(v_n_247, 2)));
    V v_t_2424 = heff_strAppend(heff_dup(heff_rfield(v_n_247, 1)), v_t_2423);
    V v_t_2425 = (g_list_2emap_24s675147852x248982264(v_t_2424, heff_dup(heff_rfield(v_pk_2422, 2))));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2425));
    V v_t_2427 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), heff_tag_n(TAG_Just, 1, (V[]){v_pk_2422})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2428));
    V v_t_2430 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_t_2426; V a_3 = v_t_2429; V a_4 = v_errs_244; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_lam2, 1, 8, (V[]){v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V v_lit_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(heff_dup(v_read_241), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1, 2, 11, (V[]){v_c_2414, v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_pkgs_243 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_from_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2478;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2477 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2478 = v_y_2477;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2479 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_242), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 4), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), heff_dup(v_lit_240), v_t_2478));
  V v_m_2480 = heff_get_n(v_f_2430, 3, 5);
  V v_t_2482;
  if (heff_strEq_c_lent(v_w_2411, v_m_2480, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2480);
    v_t_2482 = v_rs_248;
  } else {
    v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2480}), v_rs_248});
  }
  V v_t_2483 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2479, v_t_2482));
  V f_ = v_t_2483;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_245 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_ps_242 = heff_env(self)[7];
  V v_pkgs_243 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_244)});
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str9), v_why_2465));
    V v_t_2467 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str10), v_t_2466));
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(heff_dup(v_lit_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), v_t_2460, heff_dup(heff_rfield(v_f_2430, 0)), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam4, 1, 12, (V[]){v_ps_242, v_f_2430, v_lit_240, v_w_2411, v_rs_248, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_245), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 5);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_244));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 5);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          V v_c_2458 = ({ V a_0 = heff_dup(v_ps_242); V a_1 = v_t_2456; V a_2 = v_t_2457; V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, a_2)); heff_drop(v_t_2457); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2415);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam3, 1, 13, (V[]){v_f_2430, v_stack_244, v_lit_240, v_st_247, v_w_2411, v_from_245, v_read_241, v_ps_242, v_pkgs_243, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          V v_e_2486 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2417, heff_dup(v_from_245), heff_dup(v_w_2411)));
          V v_t_2487 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2486, NTAG(TAG_Nil)});
          V v_t_2488 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2487));
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2490 = ({ V rv_1 = v_t_2489; V rv_2 = v_t_2488; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2491 = heff_get_n(v_f_2430, 3, 5);
          V v_t_2493;
          if (heff_strEq_c_lent(v_w_2411, v_m_2491, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2491);
            v_t_2493 = v_rs_248;
          } else {
            v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2491}), v_rs_248});
          }
          V v_t_2494 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2490, v_t_2493));
          V f_ = v_t_2494;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_lam2, 1, 12, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4(V self, V *args) {
  V v_x_2473 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_from_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2476;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_dup(heff_field(v_x_2473, 0));
    v_t_2476 = v_x_2474;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2477 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2480;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_y_2479 = heff_field(v_x_2473, 1);
    heff_take_n(v_x_2473, 2ULL, 2);
    v_t_2480 = v_y_2479;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2481 = (g_heff_2ebuild_2eload_2epushDone(v_t_2476, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 4), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), v_t_2477, v_t_2480));
  V v_m_2482 = heff_get_n(v_f_2430, 3, 5);
  V v_t_2484;
  if (heff_strEq_c_lent(v_w_2411, v_m_2482, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2482);
    v_t_2484 = v_rs_248;
  } else {
    v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2482}), v_rs_248});
  }
  V v_t_2485 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2481, v_t_2484));
  V f_ = v_t_2485;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_imp_245 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_243)});
  V v_t_2461 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2462 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2461, heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2463 = heff_get_n(v_t_2462, 0, 4);
  V v_t_2464 = (g_list_2emap_24s1817208647x1282894070(v_imps_2463));
  V v_t_2465 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2464));
  V v_t_2471;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2471 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2466 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2467 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str9), v_why_2466));
    V v_t_2468 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str10), v_t_2467));
    V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
    V v_t_2470 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2469));
    v_t_2471 = ({ V rv_2 = v_t_2470; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2472 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2460, heff_dup(heff_rfield(v_f_2430, 0)), heff_dup(v_imp_245), v_t_2465, v_t_2471, NTAG(TAG_Nil)));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam4, 1, 12, (V[]){v_imp_245, v_f_2430, v_ps_241, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_244), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 5);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_243));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 5);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          V v_c_2458 = ({ V a_0 = heff_dup(v_ps_241); V a_1 = v_t_2456; V a_2 = v_t_2457; V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, a_2)); heff_drop(v_t_2457); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2415);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam3, 1, 13, (V[]){v_f_2430, v_stack_243, v_imp_245, v_st_247, v_w_2411, v_from_244, v_read_240, v_ps_241, v_pkgs_242, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          V v_e_2488 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2417, heff_dup(v_from_244), heff_dup(v_w_2411)));
          V v_t_2489 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2488, NTAG(TAG_Nil)});
          V v_t_2490 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2489));
          V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2492 = ({ V rv_1 = v_t_2491; V rv_2 = v_t_2490; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2493 = heff_get_n(v_f_2430, 3, 5);
          V v_t_2495;
          if (heff_strEq_c_lent(v_w_2411, v_m_2493, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2493);
            v_t_2495 = v_rs_248;
          } else {
            v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2493}), v_rs_248});
          }
          V v_t_2496 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2492, v_t_2495));
          V f_ = v_t_2496;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}