// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s973071017x1608150717(V);
V g_co_2eop_24s973071017x1608150717_entry(V self, V *a);
extern Clo g_co_2eop_24s973071017x1608150717_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394(V, V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
HeffT4 g_heff_2esyntax_2eimport_2eimportsOf_24cpr(V, V);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 2, ": ");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_at_243 = heff_take_field(v_p_242, 0);
  V v_msg_244 = heff_get_n(v_p_242, 1, 2);
  V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_246;
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_j_245);
    v_t_246 = NTAG(TAG_Nothing);
  } else {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_j_245});
  }
  HeffT3 v_t_247 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_241, heff_dup(v_at_243), MK_INT(0LL), MK_INT(0LL), v_t_246));
  {
    V v_field_248 = v_t_247.f[0];
    heff_drop(v_t_247.f[1]);
    heff_drop(v_t_247.f[2]);
    V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), v_src_241, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = NTAG(TAG_Nothing);
    } else {
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2411});
    }
    HeffT3 v_t_2413 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_241, v_at_243, MK_INT(0LL), MK_INT(0LL), v_t_2412));
    {
      V v_field_2416 = v_t_2413.f[2];
      heff_drop(v_t_2413.f[0]);
      heff_drop(v_t_2413.f[1]);
      V v_t_2417 = heff_intShow(heff_intAdd(v_field_248, MK_INT(1LL)));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_path_240, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2)), v_t_2417);
      V v_t_2419 = heff_intShow(heff_intAdd(v_field_2416, MK_INT(1LL)));
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3)), v_t_2419);
      return heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4)), v_msg_244);
    }
  }
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eproblemMsg(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_mod_243 = heff_take_field(v_ps_240, 3);
  V v_style_244 = heff_get_n(v_ps_240, 5, 6);
  V v_d_245 = v_mod_243;
  V v_s_246 = heff_strAppend(heff_strAppend(v_path_241, ((V)&g_heff_2ebuild_2eload_2ecachedDir_str0)), v_v_242);
  V v_x2_247 = ({ V a_0 = v_s_246; V b_1 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_246); heff_drop(b_1); r_; });
  V v_p_2412;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_p_2412 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_dup(v_style_244);
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Posix: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    v_p_2412 = ({ V a_0 = v_t_2411; V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_st_2413 = v_style_244;
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2413), v_d_245));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2413), v_p_2412));
  V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
  return ({ V a_0 = v_st_2413; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); heff_drop(v_t_2416); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_rest_243);
      return heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_242, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_246 = ({ V rv_4 = v_t_244; V rr_ = heff_rec_reuse_nf(v_k_242, 111ULL, 7, shape_path__dir__src__own__top__heff__scope, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_taken_240}), v_rest_243, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_247 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_nf(v_k_243, 111ULL, 7, shape_path__dir__src__own__top__heff__scope, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_u_249;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_k_244, 1)), heff_dup(v_from_243)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_ps_240);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_t_246);
      return heff_dup(v_k_244);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_ps_240;
      V t_1 = v_rest_245;
      V t_2 = v_project_242;
      V t_3 = v_from_243;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      v_project_242 = t_2;
      v_from_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2ekeepIf_24s1220809684x843195562(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_pkgs_241; V a_1 = v_p_249; HeffT2 r_ = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(a_0, a_1)); heff_drop(v_p_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2413 = v_field_2412;
          V v_src_2414 = heff_take_field(v_q_2413, 2);
          V v_own_2415 = heff_take_field(v_q_2413, 3);
          V v_top_2416 = heff_get_n(v_q_2413, 4, 7);
          V v_base_2417 = v_src_2414;
          V v_m_2418 = heff_strAppend(v_own_2415, heff_dup(v_rest_244));
          V v_xs_2419 = ({ V a_0 = v_m_2418; V b_1 = ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2418, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_2418); heff_drop(b_1); r_; });
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
          V v_parts_2424;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2424 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2421 = heff_field(v_t_2420, 0);
            V v_before_2422 = heff_field(v_t_2420, 1);
            heff_take_n(v_t_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2421, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), NTAG(TAG_Nil)});
            v_parts_2424 = (g_list_2efoldl_24s1370882877x364361272(v_t_2423, v_before_2422));
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2431 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2417), v_parts_2424));
          V v_t_2432 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2431, v_base_2417, v_parts_2424, heff_strAppend(v_top_2416, v_rest_244)});
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2425 = args[0];
  V v_p_2426 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2427 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_d_2425));
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_p_2426));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  return ({ V a_0 = v_st_2427; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2430); r_; });
}
HEFF_REC_LIT(g_heff_2ebuild_2eload_2eemptySt_lit0, 3, shape_done__doneMods__errors, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return ((V)&g_heff_2ebuild_2eload_2eemptySt_lit0);
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 8, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_named_243, V v_path_244, V v_src_245, V v_implicit_246, V v_renames_247) {
top: ;
  HeffT2 v_t_248 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_244)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2416;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_rel_2411 = v_field_2410;
      V v_st_2412 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2eload_2epushDone_str0)));
      V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_rel_2411));
      V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
      v_t_2416 = ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
    } else {
      heff_drop(v_field_2410);
      v_t_2416 = heff_dup(v_path_244);
    }
    HeffT2 v_t_2417 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_244)));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      V v_t_2421 = heff_bool(((v_tag_2418 == ((int64_t)0ULL)) && ({ V v_x_2420 = heff_dup(v_field_2419); int c_ = 1; heff_drop(v_x_2420); c_; })));
      heff_drop(v_field_2419);
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_named_243, v_path_244, v_t_2416, v_src_245, v_renames_247, v_implicit_246, v_t_2421}), NTAG(TAG_Nil)});
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2422));
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
      return ({ V rv_0 = v_t_2423; V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 9, ": module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 55, ", and the imports of it, so that the name is one file's");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s2087317732x355496638(heff_dup(v_found_241)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  HeffT2 v_t_2413 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), v_found_241));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    V v_t_2419;
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2416 = v_field_2415;
      v_t_2419 = heff_get_n(v_f_2416, 0, 5);
    } else {
      heff_drop(v_field_2415);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2);
        break;
      }
      case TAG_Cons: {
        V v_f_2417 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2419 = heff_get_n(v_f_2417, 0, 5);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_from_242, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str3)), v_m_243);
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4)), v_t_247);
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str5)), v_t_2419);
    return heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str6));
  }
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_248, 0, 5)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2412); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam0, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_d_242)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam1, 2, 4, (V[]){v_a_2411, v_d_242, v_h_240, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_start_241 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(v_d_242, v_h_240, v_start_241, v_hd_2412, v_k_2413, heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(v_d_242, v_h_240, v_start_241, v_hd_2412, v_k_2413, heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422})));
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(v_d_242, v_h_240, v_start_241, v_hd_2412, v_k_2413, heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2423})));
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_h_240 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_lam2, 1, 5, (V[]){v_d_242, v_h_240, v_start_241, v_hd_2412, v_k_2413})));
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_242), heff_dup(v_file_241)));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_d_247 = v_field_244;
    V v_a_248 = v_field_245;
    V v_xs_249 = v_field_246;
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_xs_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2410; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
    V v_t_2413 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_247, v_a_248, v_t_2412});
    V v_t_2414 = ({ V a_0 = v_st_242; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop_tag(v_t_2413, 3); r_; });
    V v_st_2415 = heff_dup(heff_rfield(v_h_240, 3));
    HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2415), v_file_241));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_field_2419 = v_t_2416.f[2];
      V v_d_2420 = v_field_2417;
      V v_a_2421 = v_field_2418;
      V v_xs_2422 = v_field_2419;
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
      V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
      V v_t_2426 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2420, v_a_2421, v_t_2425});
      V v_t_2427 = ({ V a_0 = v_st_2415; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop_tag(v_t_2426, 3); r_; });
      return (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(v_h_240, v_t_2414, v_t_2427));
    }
  }
}
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_root_242)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam1, 2, 3, (V[]){v_a_2411, v_root_242, v_style_241});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_style_241 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_root_242);
    heff_drop(v_style_241);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    V f_ = v_k_2413;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      heff_take_n(v_y_2422, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_root_242);
      heff_drop(v_style_241);
      V v_t_2424 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
      V f_ = v_k_2413;
      args[0] = v_t_2424;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_y_2422, 0);
      V v_ru_24y_2422_24Right = heff_take_reuse_n(v_y_2422, 1ULL, 1);
      V v_t_2426 = ({ V a_0 = v_x_2425; V b_1 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str2), v_x_2425, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      HeffT2 v_t_2427 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2426));
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        V v_x_2439;
        heff_clo_take(self, 3);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x_2419_24Right, 1);
          V v_p_2430 = v_field_2429;
          V v_d_2431 = v_root_242;
          V v_st_2432 = v_style_241;
          V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2432), v_d_2431));
          V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_2432), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_str3)));
          V v_t_2435 = (g_std_2epath_2ejoin(v_t_2433, v_t_2434));
          V v_t_2436 = ({ V a_0 = v_st_2432; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2432); heff_drop(v_t_2435); r_; });
          V v_t_2437 = ({ V a_0 = v_t_2436; V a_1 = v_x_2425; V a_2 = v_p_2430; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_x_2425); r_; });
          v_x_2439 = heff_tag_at_n(v_ru_24y_2422_24Right, TAG_Left, 1, (V[]){v_t_2437});
        } else {
          heff_drop(v_root_242);
          heff_drop(v_style_241);
          heff_drop(v_x_2425);
          heff_drop_cell(v_ru_24y_2422_24Right, 1);
          V v_sums_2438 = v_field_2429;
          v_x_2439 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_sums_2438});
        }
        V f_ = v_k_2413;
        args[0] = v_x_2439;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_style_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, v_hd_2412, heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_lam2, 1, 3, (V[]){v_k_2413, v_root_242, v_style_241})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_dir_241)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam1, 2, 4, (V[]){v_a_2411, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 4);
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(v_ps_240, v_dir_241, v_path_242, v_k_2413, heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(v_ps_240, v_dir_241, v_path_242, v_k_2413, heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422})));
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(v_ps_240, v_dir_241, v_path_242, v_k_2413, heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2423})));
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, v_hd_2412, heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_lam2, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_entry, 7, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(V v_lit_240, V v_lit_241, V v_lit_242, V v_root_243, V v_x3_244, V v_seen_245, V v_errs_246) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam0, 2, 2, (V[]){v_seen_245, v_errs_246});
  }
  case TAG_Cons: {
    V v_n_249 = heff_field(v_x3_244, 0);
    V v_rest_2410 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    V v_path_2411 = heff_take_field(v_n_249, 1);
    V v_version_2412 = heff_take_field(v_n_249, 2);
    V v_by_2413 = heff_get_n(v_n_249, 0, 3);
    if (heff_strEq_c_lent(v_path_2411, v_root_243, 0)) {
      heff_drop(v_path_2411);
      heff_drop(v_version_2412);
      heff_drop(v_by_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_root_243;
      V t_4 = v_rest_2410;
      V t_5 = v_seen_245;
      V t_6 = v_errs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_root_243 = t_3;
      v_x3_244 = t_4;
      v_seen_245 = t_5;
      v_errs_246 = t_6;
      goto top;
    } else {
      V v_t_2414 = (g_list_2eany_24s241416889x826324235(v_path_2411, v_version_2412, v_seen_245));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_path_2411);
        heff_drop(v_version_2412);
        heff_drop(v_by_2413);
        heff_drop(v_t_2414);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_root_243;
        V t_4 = v_rest_2410;
        V t_5 = v_seen_245;
        V t_6 = v_errs_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_root_243 = t_3;
        v_x3_244 = t_4;
        v_seen_245 = t_5;
        v_errs_246 = t_6;
        goto top;
      } else {
        heff_drop(v_t_2414);
        V v_c_2415 = (g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_by_2413, heff_dup(v_path_2411), heff_dup(v_version_2412)));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam1, 2, 10, (V[]){v_c_2415, v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_root_243), v_rest_2410});
      }
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_seen_245 = heff_env(self)[0];
  V v_errs_246 = heff_env(self)[1];
  heff_drop(v_hd_247);
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_245, v_errs_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_path_2411 = heff_env(self)[0];
  V v_version_2412 = heff_env(self)[1];
  V v_seen_245 = heff_env(self)[2];
  V v_errs_246 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_root_243 = heff_env(self)[7];
  V v_rest_2410 = heff_env(self)[8];
  V v_hd_2416 = heff_env(self)[9];
  V v_k_2417 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_clo_take(self, 11);
    V v_t_2420 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2421));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(v_errs_246, v_t_2423));
    V v_t_2425 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_rest_2410; V a_5 = v_t_2422; V a_6 = v_t_2424; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2426 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2427 = heff_strAppend(heff_strAppend(heff_dup(v_path_2411), ((V)&g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_str0)), heff_dup(v_version_2412));
    V v_t_2428 = (g_list_2emap_24s675147852x248982264(v_t_2427, heff_dup(heff_rfield(v_pk_2426, 2))));
    heff_clo_take(self, 11);
    V v_t_2429 = (g_prelude_2e_2b_2b(v_rest_2410, v_t_2428));
    V v_t_2430 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2426})});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    V v_t_2432 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2431));
    V v_t_2433 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_t_2429; V a_5 = v_t_2432; V a_6 = v_errs_246; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_path_2411 = heff_env(self)[1];
  V v_version_2412 = heff_env(self)[2];
  V v_seen_245 = heff_env(self)[3];
  V v_errs_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_root_243 = heff_env(self)[8];
  V v_rest_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951_lam2, 1, 11, (V[]){v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, v_root_243, v_rest_2410, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry, 2, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(V v_ps_240, V v_src_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_src_241)));
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam1, 2, 4, (V[]){v_a_245, v_src_241, v_ps_240, v_path_242});
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2418));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_242, v_t_2419));
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_path_242);
    return (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(v_k_247, v_src_241, v_ps_240, v_hd_246, heff_tag_re_n(v_ru_24x_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2414})));
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    switch (heff_tag_of(v_y_2415)) {
    case TAG_Left: {
      V v_err_2416 = heff_field(v_y_2415, 0);
      V v_ru_24y_2415_24Left = heff_take_reuse_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 5);
      heff_drop(v_path_242);
      heff_drop_cell(v_ru_24x_2413_24Right, 1);
      return (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(v_k_247, v_src_241, v_ps_240, v_hd_246, heff_tag_re_n(v_ru_24y_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2416})));
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_y_2415, 0);
      heff_take_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 5);
      V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam3, 1, 1, (V[]){v_path_242}), v_x_2417));
      V v_x_2421 = (g_list_2emap_24s219049803x1458391381(v_x_2420));
      return (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_2ek_24l0(v_k_247, v_src_241, v_ps_240, v_hd_246, heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Right, 1, (V[]){v_x_2421})));
    }
    default: return heff_nomatch(v_y_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2412, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_lam2, 1, 5, (V[]){v_k_247, v_src_241, v_ps_240, v_hd_246, v_path_242})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam0, 2, 3, (V[]){v_c_242, v_root_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_seen_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2417; V a_1 = v_seen_2415; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_2415); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2423;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_x_2420, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2426;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2424 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2426 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2429;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2432;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_field(v_x_2420, 1);
    heff_take_n(v_x_2420, 2ULL, 2);
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2432));
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2433));
  V v_x_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_t_2434});
  V f_ = v_k_244;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_seen_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_x_2412, 0));
    v_seen_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2416 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_2415)));
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam3, 1, 1, (V[]){v_seen_2415}), v_t_2416));
  heff_clo_take(self, 5);
  V v_t_2419 = (g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(v_ps_240, v_root_241, v_t_2418, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_t_2419;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam4, 1, 3, (V[]){v_x_245, v_x_2412, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_249;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_str0))) {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_str1);
  } else {
    v_t_249 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2410 = (g_list_2emap_24s675147852x248982264(v_t_249, heff_dup(heff_rfield(v_root_241, 2))));
  V v_t_2411 = (g_heff_2ebuild_2eload_2eversionsGo_24s1373199615x1234232951(heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248, heff_rfield(v_root_241, 0), v_t_2410, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  heff_clo_take(self, 4);
  V f_ = v_t_2411;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674_lam1, 1, 4, (V[]){v_root_241, v_ps_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str3, 0, "");
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam1, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_entry, 4, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394(V v_ps_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_z_242);
    V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_str3), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tail(v_z_243, 1, (V[]){v_t_246});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s432607290x1050312674(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam0, 1, 4, (V[]){v_ps_240, v_z_242, v_root_247, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam1(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam3(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_2410 = heff_env(self)[0];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2410, v_t_2425));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  V v_path_2410 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_path_2410);
    return ({ V a_0 = v_ps_240; V a_1 = v_z_242; V a_2 = v_root_247; V a_3 = v_x_249; V a_4 = v_z_243; V b_5 = heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_x_249); heff_drop(b_5); r_; });
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_path_2410);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      return ({ V a_0 = v_ps_240; V a_1 = v_z_242; V a_2 = v_root_247; V a_3 = v_x_249; V a_4 = v_z_243; V b_5 = heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_x_249); heff_drop(b_5); r_; });
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 6);
      V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam3, 1, 1, (V[]){v_path_2410}), v_x_2423));
      V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
      return ({ V a_0 = v_ps_240; V a_1 = v_z_242; V a_2 = v_root_247; V a_3 = v_x_249; V a_4 = v_z_243; V b_5 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2427}); V r_ = (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_x_249); heff_drop(b_5); r_; });
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_240, 1))));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2413 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam1_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394_lam2, 1, 6, (V[]){v_ps_240, v_z_242, v_root_247, v_x_249, v_z_243, v_path_2410})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_pl_243, 0))));
    V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_245); r_; });
    V v_a_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam1_clo)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    V v_a_2414 = (g_co_2eop_24s973071017x1608150717(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam2, 2, 3, (V[]){v_a_2414, v_rest_244, v_pl_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(a[0]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam1(V self, V *args) {
  V v_a_247 = args[0];
  return v_a_247;
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_pl_243 = heff_env(self)[0];
  V v_a_2420 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_t_2423 = heff_dup(heff_rfield(v_pl_243, 2));
  V v_p_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nil: {
    v_p_2426 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_t_2423, 0);
    V v_xs_2425 = heff_field(v_t_2423, 1);
    heff_take_n(v_t_2423, 3ULL, 2);
    v_p_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str1); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_p_2426, 0)) - ((int64_t)3ULL));
  V v_t_2428 = heff_strSlice_lent(v_p_2426, heff_box_word(v_t_2427), heff_strLength_lent(v_p_2426, 0), 6);
  V v_t_2430;
  if (heff_strEq_c(v_t_2428, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_str2))) {
    int64_t v_t_2429 = (heff_unbox_word(heff_strLength_lent(v_p_2426, 0)) - ((int64_t)3ULL));
    v_t_2430 = heff_strSlice(v_p_2426, MK_INT(0LL), heff_box_word(v_t_2429));
  } else {
    v_t_2430 = v_p_2426;
  }
  heff_clo_take(self, 3);
  V v_t_2431 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_a_2420, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4), v_t_2430});
  V v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_x_2422});
  V f_ = v_k_2416;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam3(V self, V *args) {
  V v_a_2417 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_pl_243 = heff_env(self)[3];
  switch (heff_tag_of(v_a_2417)) {
  case TAG_Left: {
    heff_take_n(v_a_2417, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop_rec(v_pl_243, 4);
    V v_t_2419 = (g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(v_rest_244));
    V f_ = v_t_2419;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_a_2420 = heff_field(v_a_2417, 0);
    heff_take_n(v_a_2417, 1ULL, 1);
    heff_clo_take(self, 4);
    V v_t_2421 = (g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(v_rest_244));
    V f_ = v_t_2421;
    heff_room[0] = v_hd_2415;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam4, 1, 3, (V[]){v_pl_243, v_a_2420, v_k_2416});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_a_2417);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_lam3, 1, 4, (V[]){v_rest_244, v_hd_2415, v_k_2416, v_pl_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str4, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str5, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str7, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str8, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str9, 74, ": names that differ only in case are one file where case is not told apart");
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(V v_ps_240, V v_d_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_d_241)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam0_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam1, 1, 7, (V[]){v_z_244, v_path_247, v_ps_240, v_d_241, v_x_245, v_rest_246, v_z_243})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_path_247 = heff_env(self)[0];
  V v_t_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2421));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_247, v_t_2422));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_a_2429 = v_n_2428;
  heff_clo_take(self, 1);
  V v_b_2430 = v_x_245;
  V v_x2_2431 = ({ V a_0 = MK_INT(65LL); V a_1 = v_a_2429; V a_2 = MK_INT(90LL); V a_3 = MK_INT(32LL); V a_4 = MK_INT(1LL); V a_5 = MK_INT(0LL); V a_6 = heff_strLength_lent(v_a_2429, 0); V r_ = (g_list_2emap_24f201346761x152404242(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_2429); r_; });
  V v_t_2434;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    v_t_2434 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    v_t_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str1); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2431);
  }
  V v_x2_2435 = ({ V a_0 = MK_INT(65LL); V a_1 = v_b_2430; V a_2 = MK_INT(90LL); V a_3 = MK_INT(32LL); V a_4 = MK_INT(1LL); V a_5 = MK_INT(0LL); V a_6 = heff_strLength_lent(v_b_2430, 0); V r_ = (g_list_2emap_24f201346761x152404242(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_b_2430); r_; });
  V v_t_2438;
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    v_t_2438 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_xs_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str3); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2435);
  }
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2434, v_t_2438, 0));
  heff_drop(v_t_2434);
  heff_drop(v_t_2438);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_path_247 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  V v_z_243 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    heff_take_n(v_x_2416, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_path_247);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_245);
    heff_drop(v_rest_246);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Left: {
      heff_take_n(v_y_2418, 0ULL, 1);
      heff_clo_take(self, 7);
      heff_drop(v_path_247);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_d_241);
      heff_drop(v_x_245);
      heff_drop(v_rest_246);
      heff_drop(v_z_243);
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 7);
      V v_x_2423 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam2, 1, 1, (V[]){v_path_247}), v_x_2420));
      V v_x_2424 = (g_list_2emap_24s219049803x1458391381(v_x_2423));
      V v_ps_2425 = heff_dup(v_ps_240);
      V v_d_2426 = heff_dup(v_d_241);
      V v_x_2427 = heff_dup(v_x_245);
      V v_ns_2439 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_lam3, 1, 1, (V[]){heff_dup(v_x_245)}), v_x_2424));
      V v_t_2457;
      switch (heff_tag_of(v_ns_2439)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2416_24Right, 1);
        heff_drop_rec(v_ps_2425, 6);
        heff_drop(v_d_2426);
        heff_drop(v_x_2427);
        v_t_2457 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_ns2_2441 = heff_dup(heff_field(v_ns_2439, 1));
        switch (heff_tag_of(v_ns2_2441)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_ns_2439)) {
          case TAG_Cons: {
            V v_n_2442 = heff_field(v_ns_2439, 0);
            heff_take_n(v_ns_2439, 1ULL, 2);
            if (heff_strEq_c_lent(v_n_2442, v_x_2427, 0)) {
              heff_drop_cell(v_ru_24x_2416_24Right, 1);
              heff_drop_rec(v_ps_2425, 6);
              heff_drop(v_d_2426);
              heff_drop(v_x_2427);
              heff_drop(v_n_2442);
              v_t_2457 = NTAG(TAG_Nothing);
            } else {
              V v_st_2444 = heff_get_n(v_ps_2425, 5, 6);
              V v_t_2445 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_d_2426));
              V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2444), heff_dup(v_x_2427)));
              V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
              V v_t_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
              V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str4)), v_n_2442);
              V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str5)), v_x_2427);
              v_t_2457 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Just, 1, (V[]){v_t_2450});
            }
            break;
          }
          default: heff_nomatch(v_ns_2439);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_ns2_2441, 0ULL, 2);
          heff_drop_rec(v_ps_2425, 6);
          heff_drop(v_x_2427);
          V v_t_2455;
          switch (heff_tag_of(v_ns_2439)) {
          case TAG_Nil: {
            v_t_2455 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str6);
            break;
          }
          case TAG_Cons: {
            V v_x_2453 = heff_field(v_ns_2439, 0);
            V v_xs_2454 = heff_field(v_ns_2439, 1);
            heff_take_n(v_ns_2439, 3ULL, 2);
            v_t_2455 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str7); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
            break;
          }
          default: heff_nomatch(v_ns_2439);
          }
          V v_t_2456 = heff_strAppend(heff_strAppend(v_d_2426, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str8)), v_t_2455);
          v_t_2457 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Just, 1, (V[]){heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_str9))});
          break;
        }
        default: heff_nomatch(v_ns2_2441);
        }
        break;
      }
      default: heff_nomatch(v_ns_2439);
      }
      switch (heff_tag_of(v_t_2457)) {
      case TAG_Nothing: {
        V v_st_2458 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_2458), v_d_241));
        V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_2458), v_x_245));
        V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
        V v_t_2462 = ({ V a_0 = v_st_2458; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2458); heff_drop(v_t_2461); r_; });
        return (g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(v_ps_240, v_t_2462, v_rest_246, v_z_243, v_z_244));
      }
      case TAG_Just: {
        V v_why_2463 = heff_field(v_t_2457, 0);
        heff_take_n(v_t_2457, 1ULL, 1);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_x_245);
        heff_drop(v_rest_246);
        heff_drop(v_z_243);
        V f_ = v_z_244;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2463});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2457);
      }
    }
    default: return heff_nomatch(v_y_2418);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_entry, 8, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_lam0, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_z_246, v_z_247})});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2414 = (g_prelude_2e_2b_2b(v_before_243, v_t_2413));
  V v_t_2417;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  return (g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553(v_ps_240, v_pkgs_241, v_from_242, v_t_2414, v_ms_249, v_t_2417, v_z_246, v_z_247));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam3, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V v_h_240, V v_file_241, V v_z_242, V v_z_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam0, 1, 4, (V[]){v_h_240, v_z_242, v_file_241, v_z_243})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam3(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam6(V self, V *args) {
  V v_m_2452 = args[0];
  V v_made_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2453 = ({ V a_0 = v_m_2452; V a_1 = v_made_2432; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2452); heff_drop(v_made_2432); r_; });
  {
    V v_field_2455 = v_t_2453.f[1];
    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
    if ((v_tag_2454 == ((int64_t)0ULL))) {
      V v_s_2456 = v_field_2455;
      return heff_get_n(v_s_2456, 6, 8);
    } else {
      heff_drop(v_field_2455);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam7(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2432 = heff_env(self)[2];
  V v_a_2427 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_z_243 = heff_env(self)[6];
  V v_t_2460;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_dup(heff_field(v_x_2457, 0));
    v_t_2460 = v_x_2458;
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V v_t_2461 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2462 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2463 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  heff_clo_take(self, 7);
  HeffT2 v_t_2464 = ({ V a_0 = v_m_2463; V a_1 = v_made_2432; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2463); heff_drop(v_made_2432); r_; });
  {
    V v_field_2466 = v_t_2464.f[1];
    int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
    V v_t_2468;
    if ((v_tag_2465 == ((int64_t)0ULL))) {
      V v_s_2467 = v_field_2466;
      v_t_2468 = heff_get_n(v_s_2467, 6, 8);
    } else {
      heff_drop(v_field_2466);
      v_t_2468 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
    V v_t_2471;
    switch (heff_tag_of(v_x_2457)) {
    case TAG_MkPair: {
      V v_y_2470 = heff_field(v_x_2457, 1);
      heff_take_n(v_x_2457, 2ULL, 2);
      v_t_2471 = v_y_2470;
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
    V v_t_2472 = (g_heff_2ebuild_2eload_2epushDone(v_t_2460, heff_dup(v_x_245), v_t_2461, v_t_2462, v_file_241, v_a_2427, v_t_2468, v_t_2471));
    V v_x_2473 = ({ V a_0 = v_x_245; V a_1 = v_x_246; V a_2 = v_x_2411; V a_3 = v_t_2472; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
    V f_ = v_z_243;
    args[0] = v_x_2473;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_a_2427 = heff_env(self)[3];
  V v_z_242 = heff_env(self)[4];
  V v_x_246 = heff_env(self)[5];
  V v_z_243 = heff_env(self)[6];
  V v_made_2432 = heff_get_n(v_x_2431, 0, 3);
  V v_t_2435;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2436 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2437 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2438 = ({ V a_0 = v_m_2437; V a_1 = v_made_2432; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2437); r_; });
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    V v_t_2442;
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_s_2441 = v_field_2440;
      v_t_2442 = heff_get_n(v_s_2441, 6, 8);
    } else {
      heff_drop(v_field_2440);
      v_t_2442 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
    HeffT4 v_t_2443 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(v_t_2442, heff_dup(v_a_2427)));
    {
      V v_field_2444 = v_t_2443.f[0];
      heff_drop(v_t_2443.f[1]);
      heff_drop(v_t_2443.f[2]);
      heff_drop(v_t_2443.f[3]);
      V v_imps_2448 = v_field_2444;
      V v_t_2449 = (g_list_2emap_24s1817208647x1282894070(v_imps_2448));
      V v_t_2450 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2449));
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(heff_dup(v_x_245), v_t_2435, v_t_2451, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam6, 1, 1, (V[]){heff_dup(v_made_2432)}), v_t_2450, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil), v_z_242, heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam7, 1, 7, (V[]){v_x_245, v_file_241, v_made_2432, v_a_2427, v_x_246, v_x_2411, v_z_243})));
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam4(V self, V *args) {
  V v_a_2422 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  V v_z_242 = heff_env(self)[5];
  switch (heff_tag_of(v_a_2422)) {
  case TAG_Left: {
    heff_take_n(v_a_2422, 0ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_z_242);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2424});
    V v_x_2426 = ({ V a_0 = v_x_245; V a_1 = v_x_246; V a_2 = v_x_2411; V a_3 = v_t_2425; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
    V f_ = v_z_243;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_a_2427 = heff_field(v_a_2422, 0);
    heff_take_n(v_a_2422, 1ULL, 1);
    V v_t_2430;
    heff_clo_take(self, 6);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_x_2428 = heff_dup(heff_field(v_x_2411, 0));
      v_t_2430 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return (g_heff_2ebuild_2eload_2emadeOfGo_24s1270217972x41787553(heff_dup(v_x_245), v_t_2430, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam5, 1, 7, (V[]){v_x_2411, v_x_245, v_file_241, v_a_2427, v_z_242, v_x_246, v_z_243})));
  }
  default: return heff_nomatch(v_a_2422);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  V v_a_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_file_241)));
  V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_2412); r_; });
  V v_a_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam3_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = (g_co_2eop_24s973071017x1608150717(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})));
  heff_clo_take(self, 5);
  V f_ = v_t_2421;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam4, 1, 6, (V[]){v_file_241, v_x_245, v_x_246, v_x_2411, v_z_243, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_t_2410;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_247 = heff_dup(heff_field(v_x_246, 0));
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      heff_take_n(v_x11_247, 0ULL, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Just, 1, (V[]){v_p_249});
      break;
    }
    default: heff_nomatch(v_x11_247);
    }
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394(heff_dup(v_x_245), v_t_2410, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam2, 1, 5, (V[]){v_file_241, v_z_242, v_x_245, v_x_246, v_z_243})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(v_h_240, heff_dup(v_x_245), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_lam1, 1, 4, (V[]){v_x_245, v_z_242, v_file_241, v_z_243})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_2422;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_x_2422 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_dup(heff_rfield(v_pl_244, 2));
    V v_p_2416;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_p_2416 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      V v_xs_2415 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      v_p_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice_lent(v_p_2416, heff_box_word(v_t_2417), heff_strLength_lent(v_p_2416, 0), 6);
    V v_t_2420;
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_str2))) {
      int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
      v_t_2420 = heff_strSlice(v_p_2416, MK_INT(0LL), heff_box_word(v_t_2419));
    } else {
      v_t_2420 = v_p_2416;
    }
    V v_t_2421 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4), v_t_2420});
    v_x_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(v_read_240, v_rest_245));
  V f_ = v_t_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str2, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str7, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_entry, 11, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248, V v_z_249, V v_z_2410) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    heff_drop(v_z_249);
    return heff_tail(v_z_2410, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248})});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(heff_dup(v_read_240), v_t_2413));
    return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam0, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_z_249, v_z_2410})});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam2(V self, V *args) {
  V v_x_2468 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_module_2429 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_named_2433 = heff_env(self)[3];
  V v_path_2432 = heff_env(self)[4];
  V v_source_2431 = heff_env(self)[5];
  V v_w_2411 = heff_env(self)[6];
  V v_rs_248 = heff_env(self)[7];
  V v_read_240 = heff_env(self)[8];
  V v_pkgs_242 = heff_env(self)[9];
  V v_stack_243 = heff_env(self)[10];
  V v_from_244 = heff_env(self)[11];
  V v_rest_2412 = heff_env(self)[12];
  V v_z_249 = heff_env(self)[13];
  V v_z_2410 = heff_env(self)[14];
  V v_t_2471;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_dup(heff_field(v_x_2468, 0));
    v_t_2471 = v_x_2469;
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(v_module_2429)}));
  V v_t_2475;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_MkPair: {
    V v_y_2474 = heff_field(v_x_2468, 1);
    heff_take_n(v_x_2468, 2ULL, 2);
    v_t_2475 = v_y_2474;
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  heff_clo_take(self, 15);
  V v_t_2476 = (g_heff_2ebuild_2eload_2epushDone(v_t_2471, heff_dup(v_ps_241), heff_dup(v_module_2429), v_named_2433, v_path_2432, v_source_2431, v_t_2472, v_t_2475));
  V v_m_2477 = v_module_2429;
  V v_t_2478;
  if (heff_strEq_c_lent(v_w_2411, v_m_2477, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2477);
    v_t_2478 = v_rs_248;
  } else {
    v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2477}), v_rs_248});
  }
  return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2476, v_t_2478, v_z_249, v_z_2410));
}
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam1(V self, V *args) {
  V v_x_2452 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_module_2429 = heff_env(self)[1];
  V v_source_2431 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_from_244 = heff_env(self)[4];
  V v_w_2411 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_stack_243 = heff_env(self)[9];
  V v_path_2432 = heff_env(self)[10];
  V v_z_249 = heff_env(self)[11];
  V v_named_2433 = heff_env(self)[12];
  V v_rs_248 = heff_env(self)[13];
  V v_rest_2412 = heff_env(self)[14];
  V v_z_2410 = heff_env(self)[15];
  V v_t_2453 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(v_module_2429)}));
  HeffT4 v_t_2454 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(v_t_2453, heff_dup(v_source_2431)));
  {
    V v_field_2455 = v_t_2454.f[0];
    heff_drop(v_t_2454.f[1]);
    heff_drop(v_t_2454.f[2]);
    heff_drop(v_t_2454.f[3]);
    V v_imps_2459 = v_field_2455;
    V v_t_2460 = (g_list_2emap_24s1817208647x1282894070(v_imps_2459));
    V v_t_2461 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2460));
    V v_t_2467;
    heff_clo_take(self, 16);
    switch (heff_tag_of(v_x_2452)) {
    case TAG_Nothing: {
      v_t_2467 = v_st_247;
      break;
    }
    case TAG_Just: {
      V v_why_2462 = heff_field(v_x_2452, 0);
      heff_take_n(v_x_2452, 1ULL, 1);
      V v_t_2463 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str9)), heff_dup(v_w_2411));
      V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str10)), v_why_2462);
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
      V v_t_2466 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2465));
      v_t_2467 = ({ V rv_2 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_x_2452);
    }
    return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2429), heff_dup(v_stack_243)}), heff_dup(v_path_2432), heff_dup(v_imp_245), v_t_2461, v_t_2467, NTAG(TAG_Nil), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam2, 1, 15, (V[]){v_imp_245, v_module_2429, v_ps_241, v_named_2433, v_path_2432, v_source_2431, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_z_249, v_z_2410})));
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_z_249 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2417 = (g_list_2emap_24s435407392x1528135477(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    heff_clo_take(self, 12);
    V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str2)), v_w_2411);
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str3)), v_t_2420);
    V v_e_2423 = heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str4));
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2426, v_rs_248, v_z_249, v_z_2410));
  }
  case TAG_Cons: {
    V v_f_2427 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2428 = heff_dup(heff_field(v_x_2415, 1));
    V v_module_2429 = heff_take_field(v_f_2427, 3);
    V v_place_2430 = heff_take_field(v_f_2427, 2);
    V v_source_2431 = heff_take_field(v_f_2427, 1);
    V v_path_2432 = heff_take_field(v_f_2427, 0);
    V v_named_2433 = heff_get_n(v_f_2427, 4, 5);
    V v_t_2434 = (g_list_2eany_24s1006624359x760861690(v_module_2429, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2428);
      heff_drop_rec(v_place_2430, 4);
      heff_drop(v_source_2431);
      heff_drop(v_path_2432);
      heff_drop(v_named_2433);
      heff_drop(v_t_2434);
      V v_m_2435 = v_module_2429;
      V v_t_2436;
      heff_clo_take(self, 12);
      if (heff_strEq_c_lent(v_w_2411, v_m_2435, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2435);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2435}), v_rs_248});
      }
      return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2436, v_z_249, v_z_2410));
    } else {
      heff_drop(v_t_2434);
      V v_t_2437 = (g_list_2eany_24s1006624359x760861690(v_module_2429, v_stack_243));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2428);
        heff_drop_rec(v_place_2430, 4);
        heff_drop(v_source_2431);
        heff_drop(v_path_2432);
        heff_drop(v_named_2433);
        heff_drop(v_t_2437);
        V v_m_2438 = heff_dup(v_module_2429);
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str7)), v_m_2438);
        V v_e_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_str8)), v_t_2444);
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
        heff_clo_take(self, 12);
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2447));
        V v_m_2449 = v_module_2429;
        V v_t_2450;
        if (heff_strEq_c_lent(v_w_2411, v_m_2449, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2449);
          v_t_2450 = v_rs_248;
        } else {
          v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2449}), v_rs_248});
        }
        V v_t_2451 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2451, v_t_2450, v_z_249, v_z_2410));
      } else {
        heff_drop(v_t_2437);
        switch (heff_tag_of(v_others_2428)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2415, 2);
          heff_clo_take(self, 12);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(heff_dup(v_ps_241), heff_dup(heff_rfield(v_place_2430, 1)), heff_get_n(v_place_2430, 2, 4), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920_lam1, 1, 16, (V[]){v_imp_245, v_module_2429, v_source_2431, v_st_247, v_from_244, v_w_2411, v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_path_2432, v_z_249, v_named_2433, v_rs_248, v_rest_2412, v_z_2410})));
        }
        case TAG_Cons: {
          V v_ru_24others_2428_24Cons = heff_take_reuse_n(v_others_2428, 0ULL, 2);
          heff_drop_rec(v_place_2430, 4);
          heff_drop(v_source_2431);
          heff_drop(v_path_2432);
          heff_drop(v_named_2433);
          V v_e_2481 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2415, heff_dup(v_from_244), heff_dup(v_w_2411)));
          heff_clo_take(self, 12);
          V v_t_2482 = heff_take_field(v_st_247, 0);
          V v_t_2483 = heff_take_field(v_st_247, 1);
          V v_t_2484 = heff_tag_at_n(v_ru_24others_2428_24Cons, TAG_Cons, 2, (V[]){v_e_2481, NTAG(TAG_Nil)});
          V v_t_2485 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2484));
          V v_m_2486 = heff_dup(v_module_2429);
          V v_t_2487;
          if (heff_strEq_c_lent(v_w_2411, v_m_2486, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2486);
            v_t_2487 = v_rs_248;
          } else {
            v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2486}), v_rs_248});
          }
          V v_t_2488 = ({ V rv_0 = v_t_2482; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_2429, v_t_2483}); V rv_2 = v_t_2485; V rr_ = heff_rec_reuse_nf(v_st_247, 0ULL, 3, shape_done__doneMods__errors, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2488, v_t_2487, v_z_249, v_z_2410));
        }
        default: return heff_nomatch(v_others_2428);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam6(V self, V *args) {
  V v_m_2443 = args[0];
  V v_made_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2444 = ({ V a_0 = v_m_2443; V a_1 = v_made_2423; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2443); heff_drop(v_made_2423); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_s_2447 = v_field_2446;
      return heff_get_n(v_s_2447, 6, 8);
    } else {
      heff_drop(v_field_2446);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2423 = heff_env(self)[2];
  V v_src_2418 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2451;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_dup(heff_field(v_x_2448, 0));
    v_t_2451 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V v_t_2452 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2453 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2454 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  heff_clo_take(self, 7);
  HeffT2 v_t_2455 = ({ V a_0 = v_m_2454; V a_1 = v_made_2423; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2454); heff_drop(v_made_2423); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    V v_t_2459;
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      V v_s_2458 = v_field_2457;
      v_t_2459 = heff_get_n(v_s_2458, 6, 8);
    } else {
      heff_drop(v_field_2457);
      v_t_2459 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
    V v_t_2462;
    switch (heff_tag_of(v_x_2448)) {
    case TAG_MkPair: {
      V v_y_2461 = heff_field(v_x_2448, 1);
      heff_take_n(v_x_2448, 2ULL, 2);
      v_t_2462 = v_y_2461;
      break;
    }
    default: heff_nomatch(v_x_2448);
    }
    V v_t_2463 = (g_heff_2ebuild_2eload_2epushDone(v_t_2451, heff_dup(v_x_246), v_t_2452, v_t_2453, v_file_242, v_src_2418, v_t_2459, v_t_2462));
    V v_x_2464 = ({ V a_0 = v_x_246; V a_1 = v_x_247; V a_2 = v_x_2412; V a_3 = v_t_2463; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2412); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2418 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_247 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_made_2423 = heff_get_n(v_x_2422, 0, 3);
  V v_t_2426;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_x_2412, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2427 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2428 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2429 = ({ V a_0 = v_m_2428; V a_1 = v_made_2423; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2428); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    V v_t_2433;
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_s_2432 = v_field_2431;
      v_t_2433 = heff_get_n(v_s_2432, 6, 8);
    } else {
      heff_drop(v_field_2431);
      v_t_2433 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
    HeffT4 v_t_2434 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(v_t_2433, heff_dup(v_src_2418)));
    {
      V v_field_2435 = v_t_2434.f[0];
      heff_drop(v_t_2434.f[1]);
      heff_drop(v_t_2434.f[2]);
      heff_drop(v_t_2434.f[3]);
      V v_imps_2439 = v_field_2435;
      V v_t_2440 = (g_list_2emap_24s1817208647x1282894070(v_imps_2439));
      V v_t_2441 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2440));
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      return (g_heff_2ebuild_2eload_2eloadMany_24s765435864x745638920(v_read_240, heff_dup(v_x_246), v_t_2426, v_t_2442, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam6, 1, 1, (V[]){heff_dup(v_made_2423)}), v_t_2441, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil), v_hd_244, heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam7, 1, 7, (V[]){v_x_246, v_file_242, v_made_2423, v_src_2418, v_x_247, v_x_2412, v_k_245})));
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_clo_take(self, 7);
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2416 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2415});
    V v_x_2417 = ({ V a_0 = v_x_246; V a_1 = v_x_247; V a_2 = v_x_2412; V a_3 = v_t_2416; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2412); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2418 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2421;
    heff_clo_take(self, 7);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_dup(heff_field(v_x_2412, 0));
      v_t_2421 = v_x_2419;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    return (g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(heff_dup(v_read_240), heff_dup(v_x_246), v_t_2421, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam5, 1, 8, (V[]){v_x_2412, v_x_246, v_file_242, v_src_2418, v_read_240, v_hd_244, v_x_247, v_k_245})));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_c_2413 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  heff_clo_take(self, 6);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_247, v_x_2412, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2eload_2epackagesOf_24s1972576090x290799394(heff_dup(v_x_246), v_t_2411, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_247, v_k_245})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(v_h_241, heff_dup(v_x_246), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}