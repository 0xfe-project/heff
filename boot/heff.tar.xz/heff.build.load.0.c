// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_col 308218
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_top 324559
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106(V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(V, V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s2087317732x355496638(V);
V g_list_2emap_24s2087317732x355496638_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 2, ": ");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_at_243 = heff_take_field(v_p_242, 0);
  V v_msg_244 = heff_get_n(v_p_242, 1, 2);
  V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_246;
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_j_245);
    v_t_246 = NTAG(TAG_Nothing);
  } else {
    v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_j_245});
  }
  V v_t_247 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_dup(v_at_243), MK_INT(0LL), MK_INT(0LL), v_t_246));
  V v_t_248 = heff_intAdd(heff_get_n(v_t_247, 0, 3), MK_INT(1LL));
  V v_t_249 = heff_strAppend(heff_strAppend(v_path_240, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1)), heff_intShow(v_t_248));
  V v_j_2410 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), v_src_241, MK_INT(0LL), 5);
  V v_t_2411;
  if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
    heff_drop(v_j_2410);
    v_t_2411 = NTAG(TAG_Nothing);
  } else {
    v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2410});
  }
  V v_t_2412 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, v_at_243, MK_INT(0LL), MK_INT(0LL), v_t_2411));
  V v_t_2413 = heff_intAdd(heff_get_n(v_t_2412, 2, 3), MK_INT(1LL));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3)), heff_intShow(v_t_2413));
  return heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4)), v_msg_244);
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eproblemMsg(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_mod_243 = heff_take_field(v_ps_240, 3);
  V v_style_244 = heff_get_n(v_ps_240, 5, 6);
  V v_d_245 = v_mod_243;
  V v_s_246 = heff_strAppend(heff_strAppend(v_path_241, ((V)&g_heff_2ebuild_2eload_2ecachedDir_str0)), v_v_242);
  V v_x2_247 = ({ V a_0 = v_s_246; V b_1 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_246); heff_drop(b_1); r_; });
  V v_p_2411;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_p_2411 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_style_244)) {
    case TAG_Posix: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_style_244);
    }
    v_p_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_st_2412 = v_style_244;
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_d_245));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_p_2411));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  return ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_k_244, 1)), heff_dup(v_from_243)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_ps_240);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_t_246);
      return heff_dup(v_k_244);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_ps_240;
      V t_1 = v_rest_245;
      V t_2 = v_project_242;
      V t_3 = v_from_243;
      v_ps_240 = t_0;
      v_x2_241 = t_1;
      v_project_242 = t_2;
      v_from_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2ekeepIf_24s1220809684x843195562(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_pkgs_241; V a_1 = v_p_249; HeffT2 r_ = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(a_0, a_1)); heff_drop(v_p_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2413 = v_field_2412;
          V v_src_2414 = heff_take_field(v_q_2413, 2);
          V v_own_2415 = heff_take_field(v_q_2413, 3);
          V v_top_2416 = heff_get_n(v_q_2413, 4, 7);
          V v_base_2417 = v_src_2414;
          V v_m_2418 = heff_strAppend(v_own_2415, heff_dup(v_rest_244));
          V v_xs_2419 = ({ V a_0 = v_m_2418; V b_1 = ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2418, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_2418); heff_drop(b_1); r_; });
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
          V v_parts_2424;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2424 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2421 = heff_field(v_t_2420, 0);
            V v_before_2422 = heff_field(v_t_2420, 1);
            heff_take_n(v_t_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2421, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), NTAG(TAG_Nil)});
            v_parts_2424 = (g_list_2efoldl_24s1370882877x364361272(v_t_2423, v_before_2422));
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2431 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2417), v_parts_2424));
          V v_t_2432 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2431, v_base_2417, v_parts_2424, heff_strAppend(v_top_2416, v_rest_244)});
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2425 = args[0];
  V v_p_2426 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2427 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_d_2425));
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_p_2426));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  return ({ V a_0 = v_st_2427; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2430); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadEvery(V v_e_240, V v_read_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_read_241);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = heff_tr(heff_call(heff_dup(v_read_241), 1, (V[]){heff_dup(heff_rfield(v_pl_245, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam1, 2, 5, (V[]){v_c_247, heff_dup(v_e_240), v_read_241, v_rest_246, v_pl_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ereadEvery(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2eload_2ereadEvery_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_pl_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2423;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_245, 4);
    v_x_2423 = v_x_2412;
    break;
  }
  case TAG_Just: {
    V v_s_2413 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_t_2414 = heff_dup(heff_rfield(v_pl_245, 2));
    V v_p_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_p_2417 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      V v_xs_2416 = heff_field(v_t_2414, 1);
      heff_take_n(v_t_2414, 3ULL, 2);
      v_p_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
    V v_t_2419 = heff_strSlice(heff_dup(v_p_2417), heff_box_word(v_t_2418), heff_strLength_lent(v_p_2417, 0));
    V v_t_2421;
    if (heff_strEq_c(v_t_2419, ((V)&g_heff_2ebuild_2eload_2ereadEvery_str2))) {
      int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
      v_t_2421 = heff_strSlice(v_p_2417, MK_INT(0LL), heff_box_word(v_t_2420));
    } else {
      v_t_2421 = v_p_2417;
    }
    V v_t_2422 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_245, 0)), v_s_2413, heff_dup(v_pl_245), heff_get_n(v_pl_245, 3, 4), v_t_2421});
    v_x_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_x_2412});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_249;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_read_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_pl_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = ({ V a_0 = v_e_240; V a_1 = v_read_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2eload_2ereadEvery(a_0, a_1, a_2)); heff_drop(v_e_240); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam3, 1, 3, (V[]){v_x_2410, v_pl_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_read_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_pl_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_lam2, 1, 6, (V[]){v_e_240, v_read_241, v_rest_246, v_hd_248, v_pl_245, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 8, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_named_243, V v_path_244, V v_src_245, V v_implicit_246, V v_renames_247) {
top: ;
  HeffT2 v_t_248 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_244)));
  V v_t_2416;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_rel_2411 = v_field_2410;
      V v_st_2412 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2eload_2epushDone_str0)));
      V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_rel_2411));
      V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
      v_t_2416 = ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
    } else {
      heff_drop(v_field_2410);
      v_t_2416 = heff_dup(v_path_244);
    }
  }
  HeffT2 v_t_2417 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_244)));
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    v_t_2421 = heff_bool(((v_tag_2418 == ((int64_t)0ULL)) && ({ V v_x_2420 = heff_dup(v_field_2419); int c_ = 1; heff_drop(v_x_2420); c_; })));
    heff_drop(v_field_2419);
  }
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_named_243, v_path_244, v_t_2416, v_src_245, v_renames_247, v_implicit_246, v_t_2421}), NTAG(TAG_Nil)});
  V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2423; V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 9, ": module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 55, ", and the imports of it, so that the name is one file's");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_t_244 = heff_strAppend(heff_strAppend(v_from_242, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0)), v_m_243);
  V v_x2_245 = (g_list_2emap_24s2087317732x355496638(heff_dup(v_found_241)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str3)), v_t_248);
  HeffT2 v_t_2415 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), v_found_241));
  V v_t_2421;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2418 = v_field_2417;
      v_t_2421 = heff_get_n(v_f_2418, 0, 5);
    } else {
      heff_drop(v_field_2417);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4);
        break;
      }
      case TAG_Cons: {
        V v_f_2419 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2421 = heff_get_n(v_f_2419, 0, 5);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
  }
  V v_t_2422 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str5)), v_t_2421);
  return heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str6));
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_2410, 0, 5)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) ? ({ V v_x_2414 = heff_dup(v_field_2413); int c_ = 0; heff_drop(v_x_2414); c_; }) : 1));
    heff_drop(v_field_2413);
    return v_ret_24bool;
  }
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry, 3, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V v_e_240, V v_h_241, V v_file_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_241, 3));
  HeffT3 v_t_244 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_243), heff_dup(v_file_242)));
  V v_t_2414;
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    V v_d_248 = v_field_245;
    V v_a_249 = v_field_246;
    V v_xs_2410 = v_field_247;
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    V v_xs_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2411; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
    v_t_2414 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_248, v_a_249, v_t_2413});
  }
  V v_t_2415 = ({ V a_0 = v_st_243; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2414); r_; });
  V v_st_2416 = heff_dup(heff_rfield(v_h_241, 3));
  HeffT3 v_t_2417 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2416), v_file_242));
  V v_t_2427;
  {
    V v_field_2418 = v_t_2417.f[0];
    V v_field_2419 = v_t_2417.f[1];
    V v_field_2420 = v_t_2417.f[2];
    V v_d_2421 = v_field_2418;
    V v_a_2422 = v_field_2419;
    V v_xs_2423 = v_field_2420;
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
    V v_xs_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2424; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    v_t_2427 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2421, v_a_2422, v_t_2426});
  }
  V v_t_2428 = ({ V a_0 = v_st_2416; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2427); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(v_e_240, v_h_241, v_t_2415, v_t_2428));
}
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str2, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str6, 16, " is the package ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str7, 6, ", not ");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam0, 3, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_entry, 4, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(V v_e_240, V v_ps_241, V v_dir_242, V v_path_243) {
top: ;
  V v_st_244 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), heff_dup(v_dir_242)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_249); r_; });
  V v_t_2411 = (g_exception_2eattempted(v_e_240));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam1, 2, 4, (V[]){v_c_2415, v_ps_241, v_dir_242, v_path_243});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2455;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 0ULL, 1);
    heff_drop(v_path_243);
    V v_st_2420 = heff_get_n(v_ps_241, 5, 6);
    V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_dir_242));
    V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2420), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str1)));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_t_2424 = ({ V a_0 = v_st_2420; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2423); r_; });
    v_x_2455 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str2))});
    break;
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    HeffT2 v_t_2426 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_y_2425)));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        heff_drop(v_path_243);
        heff_drop_cell(v_ru_24x_2418_24Right, 1);
        V v_p_2429 = v_field_2428;
        V v_st_2430 = heff_get_n(v_ps_241, 5, 6);
        V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2430), v_dir_242));
        V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2430), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str3)));
        V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
        V v_t_2434 = ({ V a_0 = v_st_2430; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2430); heff_drop(v_t_2433); r_; });
        V v_t_2435 = ({ V a_0 = v_t_2434; V a_1 = v_y_2425; V a_2 = v_p_2429; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2425); r_; });
        v_x_2455 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2435});
      } else {
        V v_x_2436 = v_field_2428;
        HeffT2 v_t_2437 = ({ V a_0 = v_x_2436; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2436); r_; });
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            heff_drop(v_path_243);
            heff_drop_cell(v_ru_24x_2418_24Right, 1);
            V v_p_2440 = v_field_2439;
            V v_st_2441 = heff_get_n(v_ps_241, 5, 6);
            V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2441), v_dir_242));
            V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2441), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str4)));
            V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
            V v_t_2445 = ({ V a_0 = v_st_2441; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2441); heff_drop(v_t_2444); r_; });
            V v_t_2446 = ({ V a_0 = v_t_2445; V a_1 = v_y_2425; V a_2 = v_p_2440; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2425); r_; });
            v_x_2455 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2446});
          } else {
            heff_drop(v_y_2425);
            V v_pk_2447 = v_field_2439;
            if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2447, 0)), heff_dup(v_path_243))) {
              heff_drop_rec(v_ps_241, 6);
              heff_drop(v_dir_242);
              heff_drop(v_path_243);
              v_x_2455 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Right, 1, (V[]){v_pk_2447});
            } else {
              heff_drop_cell(v_ru_24x_2418_24Right, 1);
              V v_st_2448 = heff_get_n(v_ps_241, 5, 6);
              V v_t_2449 = (g_std_2epath_2eparse(heff_dup(v_st_2448), v_dir_242));
              V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_2448), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str5)));
              V v_t_2451 = (g_std_2epath_2ejoin(v_t_2449, v_t_2450));
              V v_t_2452 = ({ V a_0 = v_st_2448; V a_1 = v_t_2451; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2448); heff_drop(v_t_2451); r_; });
              V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str6)), heff_get_n(v_pk_2447, 0, 4));
              V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_str7)), v_path_243);
              v_x_2455 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2454});
            }
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2417;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_lam2, 1, 4, (V[]){v_ps_241, v_dir_242, v_path_243, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str1, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str3, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str4, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str6, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str8, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str9, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str10, 20, ", and heff.sum says ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam0, 3, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_entry, 7, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513(V v_e_240, V v_ps_241, V v_root_242, V v_sums_243, V v_by_244, V v_path_245, V v_v_246) {
top: ;
  V v_require_247 = heff_take_field(v_root_242, 2);
  V v_replace_248 = heff_get_n(v_root_242, 3, 4);
  V v_t_249 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_245, v_require_247));
  V v_t_2415;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    heff_drop(v_replace_248);
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 2);
    V v_t_2412 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2410, v_replace_248));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 2);
      v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2413, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    V v_t_2416 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), heff_dup(v_v_246)));
    V v_s_2417 = heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str0));
    V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2417));
    V v_c_2419 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2418; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2418); r_; });
    V v_t_2420 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2424 = heff_tr(heff_call(v_c_2419, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam1, 2, 7, (V[]){v_c_2424, v_by_244, v_path_245, v_v_246, v_sums_243, v_ps_241, v_e_240});
  }
  case TAG_Just: {
    V v_d_2455 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop(v_by_244);
    heff_drop(v_v_246);
    V v_d_2456 = heff_dup(heff_rfield(v_ps_241, 0));
    V v_st_2457 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2457), v_d_2456));
    V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_2457), v_d_2455));
    V v_t_2460 = (g_std_2epath_2ejoin(v_t_2458, v_t_2459));
    V v_t_2461 = ({ V a_0 = v_st_2457; V a_1 = v_t_2460; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2457); heff_drop(v_t_2460); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(v_e_240, v_ps_241, v_t_2461, v_path_245));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_by_244 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_v_246 = heff_env(self)[2];
  V v_k_2426 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_hd_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 0ULL, 1);
    heff_drop(v_sums_243);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_e_240);
    heff_drop(v_hd_2425);
    V v_t_2429 = heff_strAppend(heff_strAppend(v_by_244, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str1)), v_path_245);
    V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str2)), v_v_246);
    V v_t_2431 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str3))});
    V f_ = v_k_2426;
    args[0] = v_t_2431;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop(v_by_244);
    V v_t_2433 = (g_list_2ekeepIf_24s25507577x707942422(v_path_245, v_v_246, v_sums_243));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_e_240);
      heff_drop(v_hd_2425);
      heff_drop(v_y_2432);
      heff_drop_cell(v_ru_24x_2427_24Right, 1);
      V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str4), v_path_245), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str5));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, v_v_246), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str6));
      V f_ = v_k_2426;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2435});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_s_2436 = heff_field(v_t_2433, 0);
      heff_take_n(v_t_2433, 1ULL, 2);
      V v_want_2438 = heff_get_n(v_s_2436, 2, 3);
      V v_t_2439 = (g_prelude_2eskipSpaces(v_y_2432, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_y_2432, 0)) - ((int64_t)1ULL));
      V v_t_2441 = (g_prelude_2eskipSpaces(v_y_2432, heff_box_word(v_t_2440), MK_INT(-1LL)));
      V v_t_2442 = heff_strSlice(heff_dup(v_y_2432), v_t_2439, heff_intAdd(v_t_2441, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2442, v_want_2438, 1)) {
        heff_drop(v_y_2432);
        heff_drop_cell(v_ru_24x_2427_24Right, 1);
        heff_drop(v_want_2438);
        V v_t_2443 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
        V v_t_2444 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(v_e_240, v_ps_241, v_t_2443, v_path_245));
        V f_ = v_t_2444;
        heff_room[0] = v_hd_2425;
        heff_room[1] = v_k_2426;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_hd_2425);
        V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_path_245), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str7)), heff_dup(v_v_246));
        V v_t_2446 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_241, v_path_245, v_v_246));
        V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str8)), v_t_2446);
        V v_t_2448 = (g_prelude_2eskipSpaces(v_y_2432, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2449 = (heff_unbox_word(heff_strLength_lent(v_y_2432, 0)) - ((int64_t)1ULL));
        V v_t_2450 = (g_prelude_2eskipSpaces(v_y_2432, heff_box_word(v_t_2449), MK_INT(-1LL)));
        V v_t_2451 = heff_strSlice(v_y_2432, v_t_2448, heff_intAdd(v_t_2450, MK_INT(1LL)));
        V v_t_2452 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str9)), v_t_2451);
        V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_str10)), v_want_2438);
        V v_x_2454 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Left, 1, (V[]){v_t_2453});
        V f_ = v_k_2426;
        args[0] = v_x_2454;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam1(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_by_244 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_v_246 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_lam2, 1, 8, (V[]){v_by_244, v_path_245, v_v_246, v_k_2426, v_sums_243, v_ps_241, v_e_240, v_hd_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str7, 24, " cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str10, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str11, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry, 3, 0};

V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(V v_e_240, V v_ps_241, V v_src_242) {
top: ;
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_src_242)));
  V v_c_244 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_243));
  V v_t_245 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2410 = heff_tr(heff_call(v_c_244, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam2, 2, 4, (V[]){v_c_2410, v_src_242, v_ps_241, v_e_240});
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_247 = (g_list_2emap_24s219049803x1458391381(v_x_246));
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam1, 2, 1, (V[]){v_x_247});
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2435 = (g_list_2emap_24s219049803x1458391381(v_x_2434));
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam5, 2, 1, (V[]){v_x_2435});
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_src_242 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    V v_ru_24x_2439_24Left = heff_take_reuse_n(v_x_2439, 0ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    V v_t_2441 = heff_strAppend(heff_strAppend(v_src_242, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str5)), v_x_2424);
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2439_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str6))});
    V f_ = v_k_2412;
    args[0] = v_t_2442;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_ru_24x_2439_24Right = heff_take_reuse_n(v_x_2439, 0ULL, 1);
    V v_st_2444 = heff_get_n(v_ps_241, 5, 6);
    V v_t_2445 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_src_242));
    V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2444), heff_dup(v_x_2424)));
    V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
    V v_dir_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
    HeffT2 v_t_2449 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2424));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      V v_t_2454;
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        heff_drop(v_x_2424);
        heff_drop_cell(v_ru_24x_2439_24Right, 1);
        V v_why_2452 = v_field_2451;
        V v_t_2453 = heff_strAppend(heff_strAppend(v_dir_2448, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str7)), v_why_2452);
        v_t_2454 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2453});
      } else {
        heff_drop(v_dir_2448);
        heff_drop(v_field_2451);
        v_t_2454 = heff_tag_at_n(v_ru_24x_2439_24Right, TAG_Right, 1, (V[]){v_x_2424});
      }
      V f_ = v_k_2412;
      args[0] = v_t_2454;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_src_242 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 0ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_e_240);
    heff_drop(v_hd_2411);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_src_242, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str0))});
    V f_ = v_k_2412;
    args[0] = v_t_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_e_240);
      heff_drop(v_hd_2411);
      V v_t_2419;
      switch (heff_tag_of(v_y_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_y_2416, 0);
        V v_xs_2418 = heff_field(v_y_2416, 1);
        heff_take_n(v_y_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str2); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_y_2416);
      }
      V v_t_2420 = heff_strAppend(heff_strAppend(v_src_242, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str3)), v_t_2419);
      V v_x_2421 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str4))});
      V f_ = v_k_2412;
      args[0] = v_x_2421;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_it12_2423 = heff_dup(heff_field(v_y_2416, 1));
      switch (heff_tag_of(v_it12_2423)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2413_24Right, 1);
        switch (heff_tag_of(v_y_2416)) {
        case TAG_Cons: {
          V v_x_2424 = heff_field(v_y_2416, 0);
          heff_take_n(v_y_2416, 1ULL, 2);
          V v_st_2426 = heff_dup(heff_rfield(v_ps_241, 5));
          V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2426), heff_dup(v_src_242)));
          V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2426), heff_dup(v_x_2424)));
          V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
          V v_s_2430 = ({ V a_0 = v_st_2426; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2429); r_; });
          V v_path_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2430));
          V v_c_2432 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2431));
          V v_t_2433 = (g_exception_2eattempted(v_e_240));
          V v_c_2438 = heff_tr(heff_call(v_c_2432, 2, (V[]){v_t_2433, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam4_clo)}));
          V f_ = v_c_2438;
          heff_room[0] = v_hd_2411;
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam6, 1, 4, (V[]){v_src_242, v_x_2424, v_k_2412, v_ps_241});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_y_2416);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2423, 0ULL, 2);
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_e_240);
        heff_drop(v_hd_2411);
        V v_t_2459;
        switch (heff_tag_of(v_y_2416)) {
        case TAG_Nil: {
          v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2457 = heff_field(v_y_2416, 0);
          V v_xs_2458 = heff_field(v_y_2416, 1);
          heff_take_n(v_y_2416, 3ULL, 2);
          v_t_2459 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str9); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
          break;
        }
        default: heff_nomatch(v_y_2416);
        }
        V v_t_2460 = heff_strAppend(heff_strAppend(v_src_242, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str10)), v_t_2459);
        V v_x_2461 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2460, ((V)&g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_str11))});
        V f_ = v_k_2412;
        args[0] = v_x_2461;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2423);
      }
    }
    default: return heff_nomatch(v_y_2416);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_src_242 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_lam3, 1, 5, (V[]){v_src_242, v_k_2412, v_ps_241, v_e_240, v_hd_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_entry, 6, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(V v_e_240, V v_ps_241, V v_root_242, V v_x3_243, V v_acc_244, V v_errs_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ps_241);
    heff_drop(v_root_242);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam0, 2, 2, (V[]){v_acc_244, v_errs_245});
  }
  case TAG_Cons: {
    V v_x31_248 = heff_field(v_x3_243, 0);
    V v_rest_249 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_2410 = heff_dup(heff_rfield(v_x31_248, 2));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_248, 3);
      V t_0 = v_e_240;
      V t_1 = v_ps_241;
      V t_2 = v_root_242;
      V t_3 = v_rest_249;
      V t_4 = v_acc_244;
      V t_5 = v_errs_245;
      v_e_240 = t_0;
      v_ps_241 = t_1;
      v_root_242 = t_2;
      v_x3_243 = t_3;
      v_acc_244 = t_4;
      v_errs_245 = t_5;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_c_2412 = (g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_root_242), v_x31_248, v_pk_2411));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam1, 2, 7, (V[]){v_c_2412, v_errs_245, v_e_240, v_ps_241, v_root_242, v_rest_249, v_acc_244});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_acc_244 = heff_env(self)[0];
  V v_errs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_244, v_errs_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_errs_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_root_242 = heff_env(self)[3];
  V v_rest_249 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2416, NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(v_errs_245, v_t_2417));
    V v_t_2419 = (g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(v_e_240, v_ps_241, v_root_242, v_rest_249, v_acc_244, v_t_2418));
    V f_ = v_t_2419;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2420 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2420, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_acc_244, v_t_2421));
    V v_t_2423 = (g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(v_e_240, v_ps_241, v_root_242, v_rest_249, v_t_2422, v_errs_245));
    V f_ = v_t_2423;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_errs_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_root_242 = heff_env(self)[4];
  V v_rest_249 = heff_env(self)[5];
  V v_acc_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_lam2, 1, 8, (V[]){v_errs_245, v_e_240, v_ps_241, v_root_242, v_rest_249, v_acc_244, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_entry, 10, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(V v_e_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_imp_246, V v_x7_247, V v_st_248, V v_rs_249) {
top: ;
  switch (heff_tag_of(v_x7_247)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    heff_drop(v_imp_246);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam0, 2, 2, (V[]){v_st_248, v_rs_249});
  }
  case TAG_Cons: {
    V v_w_2412 = heff_field(v_x7_247, 0);
    V v_rest_2413 = heff_field(v_x7_247, 1);
    heff_take_n(v_x7_247, 3ULL, 2);
    V v_t_2414 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2412)));
    V v_c_2415 = (g_heff_2ebuild_2eload_2ereadEvery(v_e_240, heff_dup(v_read_241), v_t_2414));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam1, 2, 12, (V[]){v_c_2415, v_ps_242, v_pkgs_243, v_from_245, v_w_2412, v_st_248, v_e_240, v_read_241, v_stack_244, v_imp_246, v_rest_2413, v_rs_249});
  }
  default: return heff_nomatch(v_x7_247);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_st_248 = heff_env(self)[0];
  V v_rs_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_248, v_rs_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_imp_246 = heff_env(self)[0];
  V v_module_2433 = heff_env(self)[1];
  V v_ps_242 = heff_env(self)[2];
  V v_named_2437 = heff_env(self)[3];
  V v_path_2435 = heff_env(self)[4];
  V v_source_2436 = heff_env(self)[5];
  V v_w_2412 = heff_env(self)[6];
  V v_rs_249 = heff_env(self)[7];
  V v_e_240 = heff_env(self)[8];
  V v_read_241 = heff_env(self)[9];
  V v_pkgs_243 = heff_env(self)[10];
  V v_stack_244 = heff_env(self)[11];
  V v_from_245 = heff_env(self)[12];
  V v_rest_2413 = heff_env(self)[13];
  V v_hd_2416 = heff_env(self)[14];
  V v_k_2417 = heff_env(self)[15];
  heff_clo_take(self, 16);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_imp_246), 1, (V[]){heff_dup(v_module_2433)}));
  V v_t_2479;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2478 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2479 = v_y_2478;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2480 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_242), heff_dup(v_module_2433), v_named_2437, v_path_2435, v_source_2436, v_t_2476, v_t_2479));
  V v_m_2481 = v_module_2433;
  V v_t_2482;
  if (heff_strEq_c_lent(v_w_2412, v_m_2481, 0)) {
    heff_drop(v_w_2412);
    heff_drop(v_m_2481);
    v_t_2482 = v_rs_249;
  } else {
    v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2481}), v_rs_249});
  }
  V v_t_2483 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_imp_246, v_rest_2413, v_t_2480, v_t_2482));
  V f_ = v_t_2483;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_imp_246 = heff_env(self)[0];
  V v_module_2433 = heff_env(self)[1];
  V v_source_2436 = heff_env(self)[2];
  V v_st_248 = heff_env(self)[3];
  V v_from_245 = heff_env(self)[4];
  V v_w_2412 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_ps_242 = heff_env(self)[8];
  V v_pkgs_243 = heff_env(self)[9];
  V v_stack_244 = heff_env(self)[10];
  V v_path_2435 = heff_env(self)[11];
  V v_hd_2416 = heff_env(self)[12];
  V v_named_2437 = heff_env(self)[13];
  V v_rs_249 = heff_env(self)[14];
  V v_rest_2413 = heff_env(self)[15];
  V v_k_2417 = heff_env(self)[16];
  heff_clo_take(self, 17);
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_imp_246), 1, (V[]){heff_dup(v_module_2433)}));
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2460, heff_dup(v_source_2436)));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_248;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str9)), heff_dup(v_w_2412));
    V v_t_2467 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str10)), v_why_2465);
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(heff_dup(v_e_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2433), heff_dup(v_stack_244)}), heff_dup(v_path_2435), heff_dup(v_imp_246), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam4, 1, 16, (V[]){v_imp_246, v_module_2433, v_ps_242, v_named_2437, v_path_2435, v_source_2436, v_w_2412, v_rs_249, v_e_240, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2413, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2412 = heff_env(self)[3];
  V v_st_248 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_imp_246 = heff_env(self)[8];
  V v_rest_2413 = heff_env(self)[9];
  V v_rs_249 = heff_env(self)[10];
  V v_hd_2416 = heff_env(self)[11];
  V v_k_2417 = heff_env(self)[12];
  heff_clo_take(self, 13);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    V v_places_2419 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2412)));
    V v_t_2420 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str0)), v_w_2412);
    V v_x2_2421 = (g_list_2emap_24s435407392x1528135477(v_places_2419));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str2); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str3)), v_t_2424);
    V v_e_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str4));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2426, NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2427));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2430 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_imp_246, v_rest_2413, v_t_2429, v_rs_249));
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2431 = heff_dup(heff_field(v_x_2418, 0));
    V v_others_2432 = heff_dup(heff_field(v_x_2418, 1));
    V v_module_2433 = heff_take_field(v_f_2431, 3);
    V v_place_2434 = heff_take_field(v_f_2431, 2);
    V v_path_2435 = heff_take_field(v_f_2431, 0);
    V v_source_2436 = heff_take_field(v_f_2431, 1);
    V v_named_2437 = heff_get_n(v_f_2431, 4, 5);
    V v_t_2438 = (g_list_2eany_24s1006624359x760861690(v_module_2433, heff_rfield(v_st_248, 1)));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2418, 2);
      heff_drop(v_others_2432);
      heff_drop_rec(v_place_2434, 4);
      heff_drop(v_path_2435);
      heff_drop(v_source_2436);
      heff_drop(v_named_2437);
      heff_drop(v_t_2438);
      V v_m_2439 = v_module_2433;
      V v_t_2440;
      if (heff_strEq_c_lent(v_w_2412, v_m_2439, 0)) {
        heff_drop(v_w_2412);
        heff_drop(v_m_2439);
        v_t_2440 = v_rs_249;
      } else {
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2439}), v_rs_249});
      }
      V v_t_2441 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_imp_246, v_rest_2413, v_st_248, v_t_2440));
      V f_ = v_t_2441;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2438);
      V v_t_2442 = (g_list_2eany_24s1006624359x760861690(v_module_2433, v_stack_244));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2418, 2);
        heff_drop(v_others_2432);
        heff_drop_rec(v_place_2434, 4);
        heff_drop(v_path_2435);
        heff_drop(v_source_2436);
        heff_drop(v_named_2437);
        heff_drop(v_t_2442);
        V v_m_2443 = heff_dup(v_module_2433);
        V v_t_2444 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str5)), heff_dup(v_m_2443));
        V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2443, NTAG(TAG_Nil)});
        V v_x2_2447 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2446));
        V v_t_2450;
        switch (heff_tag_of(v_x2_2447)) {
        case TAG_Nil: {
          v_t_2450 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2448 = heff_field(v_x2_2447, 0);
          V v_xs_2449 = heff_field(v_x2_2447, 1);
          heff_take_n(v_x2_2447, 3ULL, 2);
          v_t_2450 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str7); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2447);
        }
        V v_e_2451 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_str8)), v_t_2450);
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2451, NTAG(TAG_Nil)});
        V v_t_2453 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2452));
        V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2455 = v_module_2433;
        V v_t_2456;
        if (heff_strEq_c_lent(v_w_2412, v_m_2455, 0)) {
          heff_drop(v_w_2412);
          heff_drop(v_m_2455);
          v_t_2456 = v_rs_249;
        } else {
          v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2455}), v_rs_249});
        }
        V v_t_2457 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_imp_246, v_rest_2413, v_t_2454, v_t_2456));
        V f_ = v_t_2457;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2442);
        switch (heff_tag_of(v_others_2432)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2418, 2);
          V v_c_2458 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_ps_242); V a_2 = heff_take_field(v_place_2434, 1); V b_3 = heff_get_n(v_place_2434, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2416);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam3, 1, 17, (V[]){v_imp_246, v_module_2433, v_source_2436, v_st_248, v_from_245, v_w_2412, v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_path_2435, v_hd_2416, v_named_2437, v_rs_249, v_rest_2413, v_k_2417});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2432_24Cons = heff_take_reuse_n(v_others_2432, 0ULL, 2);
          heff_drop_rec(v_place_2434, 4);
          heff_drop(v_path_2435);
          heff_drop(v_source_2436);
          heff_drop(v_named_2437);
          V v_e_2486 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2418, heff_dup(v_from_245), heff_dup(v_w_2412)));
          V v_t_2487 = heff_take_field(v_st_248, 0);
          V v_t_2488 = heff_take_field(v_st_248, 1);
          V v_t_2489 = heff_tag_at_n(v_ru_24others_2432_24Cons, TAG_Cons, 2, (V[]){v_e_2486, NTAG(TAG_Nil)});
          V v_t_2490 = (g_prelude_2e_2b_2b(heff_get_n(v_st_248, 2, 3), v_t_2489));
          V v_t_2491 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2487, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2433), v_t_2488}), v_t_2490});
          V v_m_2492 = v_module_2433;
          V v_t_2493;
          if (heff_strEq_c_lent(v_w_2412, v_m_2492, 0)) {
            heff_drop(v_w_2412);
            heff_drop(v_m_2492);
            v_t_2493 = v_rs_249;
          } else {
            v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2492}), v_rs_249});
          }
          V v_t_2494 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_imp_246, v_rest_2413, v_t_2491, v_t_2493));
          V f_ = v_t_2494;
          heff_room[0] = v_hd_2416;
          heff_room[1] = v_k_2417;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2432);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2412 = heff_env(self)[4];
  V v_st_248 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_imp_246 = heff_env(self)[9];
  V v_rest_2413 = heff_env(self)[10];
  V v_rs_249 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595_lam2, 1, 13, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2412, v_st_248, v_e_240, v_read_241, v_stack_244, v_imp_246, v_rest_2413, v_rs_249, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str3, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam2(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam2, 3, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V v_e_240, V v_read_241, V v_h_242, V v_file_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), heff_dup(v_h_242), heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam0, 2, 5, (V[]){v_c_244, v_e_240, v_h_242, v_read_241, v_file_243});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_h_249 = heff_env(self)[1];
  V v_ps_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    heff_drop(v_h_249);
    heff_drop_rec(v_ps_2410, 6);
    V f_ = v_k_2424;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    V v_h_2428 = v_h_249;
    V v_ps_2429 = v_ps_2410;
    V v_root_2430 = heff_take_field(v_ps_2429, 0);
    V v_style_2431 = heff_get_n(v_ps_2429, 5, 6);
    V v_src_2432 = heff_dup(v_y_2427);
    HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2427));
    V v_x4_2438;
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        V v_p_2436 = v_field_2435;
        v_x4_2438 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2436});
      } else {
        V v_x_2437 = v_field_2435;
        v_x4_2438 = ({ V a_0 = v_x_2437; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2437); r_; });
      }
    }
    V v_t_2478;
    switch (heff_tag_of(v_x4_2438)) {
    case TAG_Left: {
      V v_p_2439 = heff_field(v_x4_2438, 0);
      V v_ru_24x4_2438_24Left = heff_take_reuse_n(v_x4_2438, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2425_24Right, 1);
      heff_drop(v_h_2428);
      V v_d_2440 = v_root_2430;
      V v_st_2441 = v_style_2431;
      V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2441), v_d_2440));
      V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2441), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str1)));
      V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
      V v_t_2445 = ({ V a_0 = v_st_2441; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2441); heff_drop(v_t_2444); r_; });
      V v_t_2446 = ({ V a_0 = v_t_2445; V a_1 = v_src_2432; V a_2 = v_p_2439; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2432); r_; });
      v_t_2478 = heff_tag_at_n(v_ru_24x4_2438_24Left, TAG_Left, 1, (V[]){v_t_2446});
      break;
    }
    case TAG_Right: {
      V v_pk_2447 = heff_field(v_x4_2438, 0);
      V v_ru_24x4_2438_24Right = heff_take_reuse_n(v_x4_2438, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2447, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        V v_x1_2448 = (g_heff_2ebuild_2eload_2eheffAt(v_h_2428, heff_dup(v_root_2430)));
        if (!(heff_dup(v_x1_2448) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x_2425_24Right, 1);
          heff_drop_rec(v_pk_2447, 4);
          heff_drop(v_x1_2448);
          V v_d_2449 = v_root_2430;
          V v_st_2450 = v_style_2431;
          V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_d_2449));
          V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str2)));
          V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
          V v_t_2454 = ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
          HeffT2 v_t_2455 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_2432)));
          V v_t_2476;
          {
            V v_field_2457 = v_t_2455.f[1];
            int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
            if ((v_tag_2456 == ((int64_t)0ULL))) {
              V v_x11_2458 = v_field_2457;
              heff_drop(v_x11_2458);
              v_t_2476 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
            } else {
              V v_x_2459 = v_field_2457;
              HeffT2 v_t_2460 = ({ V a_0 = heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()); V a_1 = v_x_2459; HeffT2 r_ = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(a_0, a_1)); heff_drop(v_x_2459); r_; });
              {
                V v_field_2462 = v_t_2460.f[1];
                int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
                if ((v_tag_2461 == ((int64_t)0ULL))) {
                  V v_x_2463 = v_field_2462;
                  heff_drop(v_x_2463);
                  v_t_2476 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                } else {
                  V v_x11_2464 = v_field_2462;
                  switch (heff_tag_of(v_x11_2464)) {
                  case TAG_Nil: {
                    v_t_2476 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                    break;
                  }
                  case TAG_Cons: {
                    V v_m_2465 = heff_field(v_x11_2464, 0);
                    heff_take_n(v_x11_2464, 1ULL, 2);
                    V v_t_2475;
                    switch (heff_tag_of(v_m_2465)) {
                    case TAG_LStr: {
                      V v_t_2468 = heff_field(v_m_2465, 1);
                      heff_take_n(v_m_2465, 2ULL, 2);
                      v_t_2475 = v_t_2468;
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_2470 = heff_field(v_m_2465, 1);
                      heff_take_n(v_m_2465, 2ULL, 2);
                      v_t_2475 = v_t_2470;
                      break;
                    }
                    case TAG_LList: {
                      V v_t_2472 = heff_field(v_m_2465, 1);
                      heff_take_n(v_m_2465, 2ULL, 2);
                      v_t_2475 = v_t_2472;
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_2474 = heff_field(v_m_2465, 1);
                      heff_take_n(v_m_2465, 2ULL, 2);
                      v_t_2475 = v_t_2474;
                      break;
                    }
                    default: heff_nomatch(v_m_2465);
                    }
                    v_t_2476 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2475, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                    break;
                  }
                  default: heff_nomatch(v_x11_2464);
                  }
                }
              }
            }
          }
          V v_t_2477 = ({ V a_0 = v_t_2454; V a_1 = v_src_2432; V a_2 = v_t_2476; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2432); r_; });
          v_t_2478 = heff_tag_at_n(v_ru_24x4_2438_24Right, TAG_Left, 1, (V[]){v_t_2477});
        } else {
          heff_drop(v_root_2430);
          heff_drop(v_style_2431);
          heff_drop(v_src_2432);
          heff_drop_cell(v_ru_24x4_2438_24Right, 1);
          heff_drop(v_x1_2448);
          v_t_2478 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_Right, 1, (V[]){v_pk_2447});
        }
      } else {
        heff_drop(v_h_2428);
        heff_drop(v_root_2430);
        heff_drop(v_style_2431);
        heff_drop(v_src_2432);
        heff_drop_cell(v_ru_24x4_2438_24Right, 1);
        v_t_2478 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_Right, 1, (V[]){v_pk_2447});
      }
      break;
    }
    default: heff_nomatch(v_x4_2438);
    }
    V v_x_2479 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2478});
    V f_ = v_k_2424;
    args[0] = v_x_2479;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_h_249 = heff_env(self)[1];
  V v_ps_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam4, 1, 3, (V[]){v_k_2424, v_h_249, v_ps_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam9(V self, V *args) {
  V v_m_24115 = args[0];
  V v_made_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24116 = ({ V a_0 = v_m_24115; V a_1 = v_made_2499; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_24115); heff_drop(v_made_2499); r_; });
  {
    V v_field_24118 = v_t_24116.f[1];
    int64_t v_tag_24117 = ((int64_t)v_t_24116.f[0]);
    if ((v_tag_24117 == ((int64_t)0ULL))) {
      V v_s_24119 = v_field_24118;
      return heff_get_n(v_s_24119, 6, 8);
    } else {
      heff_drop(v_field_24118);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam10(V self, V *args) {
  V v_x_24121 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_243 = heff_env(self)[1];
  V v_made_2499 = heff_env(self)[2];
  V v_src_2493 = heff_env(self)[3];
  V v_x_2481 = heff_env(self)[4];
  V v_x_2487 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24124;
  switch (heff_tag_of(v_x_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_dup(heff_field(v_x_24121, 0));
    v_t_24124 = v_x_24122;
    break;
  }
  default: heff_nomatch(v_x_24121);
  }
  V v_t_24125 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_file_243)));
  V v_t_24126 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_file_243)));
  V v_m_24127 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_file_243)));
  HeffT2 v_t_24128 = ({ V a_0 = v_m_24127; V a_1 = v_made_2499; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_24127); heff_drop(v_made_2499); r_; });
  V v_t_24132;
  {
    V v_field_24130 = v_t_24128.f[1];
    int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
    if ((v_tag_24129 == ((int64_t)0ULL))) {
      V v_s_24131 = v_field_24130;
      v_t_24132 = heff_get_n(v_s_24131, 6, 8);
    } else {
      heff_drop(v_field_24130);
      v_t_24132 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_24135;
  switch (heff_tag_of(v_x_24121)) {
  case TAG_MkPair: {
    V v_y_24134 = heff_field(v_x_24121, 1);
    heff_take_n(v_x_24121, 2ULL, 2);
    v_t_24135 = v_y_24134;
    break;
  }
  default: heff_nomatch(v_x_24121);
  }
  V v_t_24136 = (g_heff_2ebuild_2eload_2epushDone(v_t_24124, heff_dup(v_x_247), v_t_24125, v_t_24126, v_file_243, v_src_2493, v_t_24132, v_t_24135));
  V v_x_24137 = ({ V a_0 = v_x_247; V a_1 = v_x_2481; V a_2 = v_x_2487; V a_3 = v_t_24136; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2487); r_; });
  V f_ = v_k_246;
  args[0] = v_x_24137;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam8(V self, V *args) {
  V v_x_2498 = args[0];
  V v_x_2487 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_src_2493 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_x_2481 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_made_2499 = heff_get_n(v_x_2498, 0, 3);
  V v_t_24102;
  switch (heff_tag_of(v_x_2487)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_dup(heff_field(v_x_2487, 0));
    v_t_24102 = v_x_24100;
    break;
  }
  default: heff_nomatch(v_x_2487);
  }
  V v_t_24103 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_file_243)));
  V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
  V v_m_24105 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_file_243)));
  HeffT2 v_t_24106 = ({ V a_0 = v_m_24105; V a_1 = v_made_2499; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_24105); r_; });
  V v_t_24110;
  {
    V v_field_24108 = v_t_24106.f[1];
    int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
    if ((v_tag_24107 == ((int64_t)0ULL))) {
      V v_s_24109 = v_field_24108;
      v_t_24110 = heff_get_n(v_s_24109, 6, 8);
    } else {
      heff_drop(v_field_24108);
      v_t_24110 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_24111 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_24110, heff_dup(v_src_2493)));
  V v_imps_24112 = heff_get_n(v_t_24111, 0, 4);
  V v_t_24113 = (g_list_2emap_24s1817208647x1282894070(v_imps_24112));
  V v_t_24114 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_24113));
  V v_c_24120 = (g_heff_2ebuild_2eload_2eloadMany_24s138925452x123932595(v_e_240, v_read_241, heff_dup(v_x_247), v_t_24102, v_t_24104, heff_dup(v_file_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam9, 1, 1, (V[]){heff_dup(v_made_2499)}), v_t_24114, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_24120;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam10, 1, 7, (V[]){v_x_247, v_file_243, v_made_2499, v_src_2493, v_x_2481, v_x_2487, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam7(V self, V *args) {
  V v_x_2489 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2481 = heff_env(self)[2];
  V v_x_2487 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_hd_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2489)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_read_241);
    heff_drop(v_hd_245);
    V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str3), v_file_243), NTAG(TAG_Nil)});
    V v_t_2491 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2490});
    V v_x_2492 = ({ V a_0 = v_x_247; V a_1 = v_x_2481; V a_2 = v_x_2487; V a_3 = v_t_2491; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2487); r_; });
    V f_ = v_k_246;
    args[0] = v_x_2492;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2493 = heff_field(v_x_2489, 0);
    heff_take_n(v_x_2489, 1ULL, 1);
    V v_t_2496;
    switch (heff_tag_of(v_x_2487)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_dup(heff_field(v_x_2487, 0));
      v_t_2496 = v_x_2494;
      break;
    }
    default: heff_nomatch(v_x_2487);
    }
    V v_c_2497 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(heff_dup(v_e_240), heff_dup(v_read_241), heff_dup(v_x_247), v_t_2496, heff_dup(v_file_243), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2497;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam8, 1, 9, (V[]){v_x_2487, v_x_247, v_file_243, v_src_2493, v_e_240, v_read_241, v_hd_245, v_x_2481, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2489);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam6(V self, V *args) {
  V v_x_2487 = args[0];
  V v_read_241 = heff_env(self)[0];
  V v_file_243 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_x_2481 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2488 = heff_tr(heff_call(heff_dup(v_read_241), 1, (V[]){heff_dup(v_file_243)}));
  V f_ = v_c_2488;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam7, 1, 8, (V[]){v_file_243, v_x_247, v_x_2481, v_x_2487, v_k_246, v_e_240, v_read_241, v_hd_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam5(V self, V *args) {
  V v_x_2481 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_read_241 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2485;
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Nothing: {
    v_t_2485 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2482 = heff_dup(heff_field(v_x_2481, 0));
    switch (heff_tag_of(v_x11_2482)) {
    case TAG_Left: {
      heff_take_n(v_x11_2482, 0ULL, 1);
      v_t_2485 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2484 = heff_field(v_x11_2482, 0);
      V v_ru_24x11_2482_24Right = heff_take_reuse_n(v_x11_2482, 1ULL, 1);
      v_t_2485 = heff_tag_at_n(v_ru_24x11_2482_24Right, TAG_Just, 1, (V[]){v_p_2484});
      break;
    }
    default: heff_nomatch(v_x11_2482);
    }
    break;
  }
  default: heff_nomatch(v_x_2481);
  }
  V v_c_2486 = (g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106(heff_dup(v_e_240), heff_dup(v_x_247), v_t_2485));
  V f_ = v_c_2486;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam6, 1, 7, (V[]){v_read_241, v_file_243, v_hd_245, v_x_247, v_x_2481, v_k_246, v_e_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_read_241 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_e_248 = heff_dup(v_e_240);
  V v_h_249 = v_h_242;
  V v_ps_2410 = heff_dup(v_x_247);
  V v_st_2411 = heff_dup(heff_rfield(v_ps_2410, 5));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2411), heff_dup(heff_rfield(v_ps_2410, 0))));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2411), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_str0)));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_s_2415 = ({ V a_0 = v_st_2411; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2411); heff_drop(v_t_2414); r_; });
  V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2415));
  V v_c_2417 = ({ V a_0 = heff_dup(v_e_248); V a_1 = v_path_2416; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2416); r_; });
  V v_t_2418 = (g_exception_2eattempted(v_e_248));
  V v_c_2422 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam2_clo)}));
  V v_c_2480 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam3, 2, 3, (V[]){v_c_2422, v_h_249, v_ps_2410});
  V f_ = v_c_2480;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam5, 1, 6, (V[]){v_e_240, v_x_247, v_hd_245, v_read_241, v_file_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_read_241 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_lam1, 1, 6, (V[]){v_e_240, v_h_242, v_hd_245, v_read_241, v_file_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}