// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_col 308218
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1200694983x1257685262(V, V);
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1250280863x1570195177_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s917234327x1197288555(V);
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 1, ":");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_245 = NTAG(TAG_Nothing);
  } else {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
  }
  V v_t_246 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_dup(heff_rfield(v_p_242, 0)), MK_INT(0LL), MK_INT(0LL), v_t_245));
  V v_t_247 = heff_intAdd(heff_get_n(v_t_246, 0, 3), MK_INT(1LL));
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), v_src_241, MK_INT(0LL), 5);
  V v_t_2410;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_2410 = NTAG(TAG_Nothing);
  } else {
    v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  V v_t_2411 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_take_field(v_p_242, 0), MK_INT(0LL), MK_INT(0LL), v_t_2410));
  V v_t_2412 = heff_intAdd(heff_get_n(v_t_2411, 2, 3), MK_INT(1LL));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), heff_get_n(v_p_242, 1, 2));
  V v_t_2414 = heff_strAppend(heff_intShow(v_t_2412), v_t_2413);
  V v_t_2415 = heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3), v_t_2414));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4), v_t_2415));
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eproblemMsg(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_s_243 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedDir_str0), v_v_242));
  V v_x2_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_p_249;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_p_249 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Posix: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    v_p_249 = ({ V a_0 = v_t_248; V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return ({ V b_0 = heff_dup(heff_rfield(v_ps_240, 5)); V a_1 = heff_get_n(v_ps_240, 3, 6); V a_2 = v_p_249; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOfGo_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_d_246 = heff_dup(heff_rfield(v_k_244, 1));
    if (heff_strEq_c_lent(v_d_246, ((V)&g_heff_2ebuild_2eload_2epkgOfGo_str0), 2)) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_d_246);
      return heff_dup(v_k_244);
    } else {
      V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_d_246));
      V v_t_249 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_from_243)));
      V v_t_2410 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_248, v_t_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_project_242);
        heff_drop(v_from_243);
        heff_drop(v_t_2410);
        return heff_dup(v_k_244);
      } else {
        heff_drop(v_t_2410);
        V t_0 = v_ps_240;
        V t_1 = v_rest_245;
        V t_2 = v_project_242;
        V t_3 = v_from_243;
        v_ps_240 = t_0;
        v_x2_241 = t_1;
        v_project_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2efilter_24s1200694983x1257685262(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_pkgs_241);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_pkgs_241; V a_1 = v_p_249; HeffT2 r_ = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(a_0, a_1)); heff_drop(v_p_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2414 = v_field_2412;
          V v_base_2415 = heff_take_field(v_q_2414, 2);
          V v_m_2416 = heff_strAppend(heff_take_field(v_q_2414, 3), heff_dup(v_rest_244));
          V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0); V a_1 = v_m_2416; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2416, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2416); r_; });
          V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
          V v_parts_2422;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2419 = heff_field(v_t_2418, 0);
            V v_before_2420 = heff_field(v_t_2418, 1);
            heff_take_n(v_t_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2419, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), v_before_2420});
            v_parts_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2421));
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2425 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2415), v_parts_2422));
          V v_t_2426 = heff_strAppend(heff_get_n(v_q_2414, 4, 7), v_rest_244);
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2425, v_base_2415, v_parts_2422, v_t_2426}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2423 = args[0];
  V v_p_2424 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2423; V a_2 = v_p_2424; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 7, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_path_243, V v_src_244, V v_implicit_245, V v_renames_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_243)));
  V v_t_2412;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_rel_2411 = v_field_249;
      v_t_2412 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), ((V)&g_heff_2ebuild_2eload_2epushDone_str0), v_rel_2411));
    } else {
      heff_drop(v_field_249);
      v_t_2412 = heff_dup(v_path_243);
    }
  }
  HeffT2 v_t_2413 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_243)));
  V v_t_2418;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    v_t_2418 = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2417); c_; })));
    heff_drop(v_field_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_path_243, v_t_2412, v_src_244, v_renames_246, v_implicit_245, v_t_2418}), NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2419));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 55, ", and the imports of it, so that the name is one file's");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 9, ": module ");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s917234327x1197288555(heff_dup(v_found_241)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  HeffT2 v_t_2414 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), heff_dup(v_found_241)));
  V v_t_2421;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2418 = v_field_2416;
      v_t_2421 = heff_get_n(v_f_2418, 0, 4);
    } else {
      heff_drop(v_field_2416);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2);
        break;
      }
      case TAG_Cons: {
        V v_f_2419 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2421 = heff_get_n(v_f_2419, 0, 4);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
  }
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str3), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4)));
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str5), heff_strAppend(v_t_247, v_t_2422));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str6), heff_strAppend(v_m_243, v_t_2423));
  return heff_strAppend(v_from_242, v_t_2424);
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_248, 0, 4)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2413 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2413); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(V v_h_240, V v_ps_241) {
top: ;
  V v_path_242 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), heff_dup(heff_rfield(v_ps_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam0, 2, 3, (V[]){v_path_242, v_h_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2421;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    v_x_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2412 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Just = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    HeffT2 v_t_2413 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_2412));
    V v_t_2419;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_p_2417 = v_field_2415;
        v_t_2419 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2417});
      } else {
        V v_x_2418 = v_field_2415;
        v_t_2419 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2418));
      }
    }
    V v_t_2420 = ({ V a_0 = v_h_240; V a_1 = v_ps_241; V a_2 = v_src_2412; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2epackageRead(a_0, a_1, a_2, a_3)); heff_drop(v_src_2412); r_; });
    v_x_2421 = heff_tag_at_n(v_ru_24x_2411_24Just, TAG_Just, 1, (V[]){v_t_2420});
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V f_ = v_k_244;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_path_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_242, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), v_hd_243, heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_lam2, 1, 3, (V[]){v_h_240, v_ps_241, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str2, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str6, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str7, 16, " is the package ");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_path_243 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_dir_241), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam0, 2, 4, (V[]){v_path_243, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2435;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop(v_path_242);
    V v_t_2413 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_x_2435 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str2))});
    break;
  }
  case TAG_Just: {
    V v_t_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    HeffT2 v_t_2415 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2414));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_path_242);
        V v_p_2419 = v_field_2417;
        V v_t_2420 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str3); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_t_2414; V a_2 = v_p_2419; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
        v_x_2435 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2421});
      } else {
        V v_x_2422 = v_field_2417;
        HeffT2 v_t_2423 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2422));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_path_242);
            V v_p_2427 = v_field_2425;
            V v_t_2428 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str4); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_t_2414; V a_2 = v_p_2427; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
            v_x_2435 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2429});
          } else {
            heff_drop(v_t_2414);
            V v_pk_2430 = v_field_2425;
            if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2430, 0)), heff_dup(v_path_242))) {
              heff_drop_rec(v_ps_240, 6);
              heff_drop(v_dir_241);
              heff_drop(v_path_242);
              v_x_2435 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Right, 1, (V[]){v_pk_2430});
            } else {
              V v_t_2432 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str5); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
              V v_t_2433 = heff_strAppend(heff_get_n(v_pk_2430, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str6), v_path_242));
              V v_t_2434 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_str7), v_t_2433));
              v_x_2435 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_t_2434});
            }
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_245;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_hd_244, heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_lam2, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str7, 24, " cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str10, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str11, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam2(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam2, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry, 4, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(V v_ps_240, V v_src_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_src_241), ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam1, 1, 4, (V[]){v_src_241, v_k_243, v_ps_240, v_hd_242})));
}
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam2(V self, V *args) {
  V v_ns_2421 = args[0];
  return v_ns_2421;
}
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2437;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str5), heff_strAppend(v_x_2418, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str6)));
    v_x_2437 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2428)});
    break;
  }
  case TAG_Just: {
    V v_ru_24x_2427_24Just = heff_take_reuse_n(v_x_2427, 0ULL, 1);
    V v_dir_2430 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_src_241; V a_2 = heff_dup(v_x_2418); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    HeffT2 v_t_2431 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2418));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        heff_drop(v_x_2418);
        V v_why_2435 = v_field_2433;
        V v_t_2436 = heff_strAppend(v_dir_2430, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str7), v_why_2435));
        v_x_2437 = heff_tag_at_n(v_ru_24x_2427_24Just, TAG_Left, 1, (V[]){v_t_2436});
      } else {
        heff_drop(v_dir_2430);
        heff_drop(v_field_2433);
        v_x_2437 = heff_tag_at_n(v_ru_24x_2427_24Just, TAG_Right, 1, (V[]){v_x_2418});
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_243;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_242);
    V v_t_2411 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str0))});
    V f_ = v_k_243;
    args[0] = v_t_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_2412 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_242);
      V v_t_2415;
      switch (heff_tag_of(v_it1_2412)) {
      case TAG_Nil: {
        v_t_2415 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_it1_2412, 0);
        V v_xs_2414 = heff_field(v_it1_2412, 1);
        heff_take_n(v_it1_2412, 3ULL, 2);
        v_t_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_it1_2412);
      }
      V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str3), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str4)));
      V v_x_2417 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2416)});
      V f_ = v_k_243;
      args[0] = v_x_2417;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2418 = heff_dup(heff_field(v_it1_2412, 0));
      V v_it12_2419 = heff_dup(heff_field(v_it1_2412, 1));
      switch (heff_tag_of(v_it12_2419)) {
      case TAG_Nil: {
        heff_drop_tag(v_it1_2412, 2);
        V v_path_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_src_241), heff_dup(v_x_2418)));
        V v_t_2422 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_2420, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam2_clo)})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_242, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_lam3, 1, 4, (V[]){v_x_2418, v_src_241, v_ps_240, v_k_243})));
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2419, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_242);
        heff_drop(v_x_2418);
        V v_t_2442;
        switch (heff_tag_of(v_it1_2412)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_it1_2412, 0);
          V v_xs_2441 = heff_field(v_it1_2412, 1);
          heff_take_n(v_it1_2412, 3ULL, 2);
          v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str9); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_it1_2412);
        }
        V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str10), heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_str11)));
        V v_x_2444 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2443)});
        V f_ = v_k_243;
        args[0] = v_x_2444;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2419);
      }
    }
    default: return heff_nomatch(v_it1_2412);
    }
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str9, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str10, 30, "packages require one another: ");
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam3, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam5(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam5, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam7(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam7, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_entry, 2, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam1, 2, 3, (V[]){v_c_248, v_ps_240, v_root_247});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam3(V self, V *args) {
  V v_ns_2412 = args[0];
  return v_ns_2412;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam5(V self, V *args) {
  V v_ns_2423 = args[0];
  return v_ns_2423;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam7(V self, V *args) {
  V v_ns_2434 = args[0];
  return v_ns_2434;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_x_2444 = (g_list_2emap_24s1462590149x1582455373(v_t_2443));
  V v_t_2445 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_247, 2))));
  V v_t_2446 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str5), heff_dup(heff_rfield(v_root_247, 1)), v_t_2445});
  V v_t_2447 = (g_prelude_2e_2b_2b(v_x_2433, v_x_2444));
  V v_t_2448 = (g_prelude_2e_2b_2b(v_x_2422, v_t_2447));
  V v_t_2451;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2451 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2452 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2448, v_t_2451));
  V v_t_2455;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2454 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2455 = v_y_2454;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2456 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_247, 2)));
  V v_t_2457 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str7), heff_take_field(v_root_247, 1), v_t_2456});
  V v_t_2460;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 2);
    v_t_2460 = v_x_2458;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
  V v_t_2462 = (g_heff_2ebuild_2eload_2ecycleAmong(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2460}), NTAG(TAG_Nil), v_t_2461));
  V v_t_2467;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_Nothing: {
    v_t_2467 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2463 = heff_field(v_t_2462, 0);
    heff_take_n(v_t_2462, 1ULL, 1);
    V v_t_2466;
    switch (heff_tag_of(v_c_2463)) {
    case TAG_Nil: {
      v_t_2466 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2464 = heff_field(v_c_2463, 0);
      V v_xs_2465 = heff_field(v_c_2463, 1);
      heff_take_n(v_c_2463, 3ULL, 2);
      v_t_2466 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str9); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
      break;
    }
    default: heff_nomatch(v_c_2463);
    }
    v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_str10), v_t_2466), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  V v_t_2468 = (g_prelude_2e_2b_2b(v_t_2455, v_t_2467));
  V v_x_2469 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2452}), v_t_2468});
  V f_ = v_k_2410;
  args[0] = v_x_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nothing: {
    v_t_2432 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    v_t_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V v_x_2433 = (g_list_2emap_24s1462590149x1582455373(v_t_2432));
  V v_t_2435 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam7_clo)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s94900133x232571340(v_t_2440, v_hd_249, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam8, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2433, v_x_2422, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    v_t_2421 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_x_2422 = (g_list_2emap_24s1462590149x1582455373(v_t_2421));
  V v_t_2424 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam5_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s94900133x232571340(v_t_2429, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam6, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2422, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam3_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam4, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam1, 2, 10, (V[]){v_t_2412, v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam4(V self, V *args) {
  V v_x_2482 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_241 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_from_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2485;
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkPair: {
    V v_x_2483 = heff_dup(heff_field(v_x_2482, 0));
    v_t_2485 = v_x_2483;
    break;
  }
  default: heff_nomatch(v_x_2482);
  }
  V v_t_2486 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2489;
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkPair: {
    V v_y_2488 = heff_field(v_x_2482, 1);
    heff_take_n(v_x_2482, 2ULL, 2);
    v_t_2489 = v_y_2488;
    break;
  }
  default: heff_nomatch(v_x_2482);
  }
  V v_t_2490 = (g_heff_2ebuild_2eload_2epushDone(v_t_2485, heff_dup(v_ps_240), heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_f_2428, 0), heff_take_field(v_f_2428, 1), v_t_2486, v_t_2489));
  V v_m_2491 = heff_get_n(v_f_2428, 3, 4);
  V v_t_2493;
  if (heff_strEq_c_lent(v_w_2410, v_m_2491, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2491);
    v_t_2493 = v_rs_247;
  } else {
    v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2491}), v_rs_247});
  }
  V v_t_2494 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2490, v_t_2493));
  V f_ = v_t_2494;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam3(V self, V *args) {
  V v_x_2468 = args[0];
  V v_f_2428 = heff_env(self)[0];
  V v_stack_242 = heff_env(self)[1];
  V v_imp_244 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  V v_pkgs_241 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2414 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_dup(v_stack_242)});
  V v_t_2470 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2471 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2470, heff_dup(heff_rfield(v_f_2428, 1))));
  V v_imps_2472 = heff_get_n(v_t_2471, 0, 3);
  V v_t_2473 = (g_list_2emap_24s1817208647x1282894070(v_imps_2472));
  V v_t_2474 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2473));
  V v_t_2480;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Nothing: {
    v_t_2480 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2475 = heff_field(v_x_2468, 0);
    heff_take_n(v_x_2468, 1ULL, 1);
    V v_t_2476 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str9), v_why_2475));
    V v_t_2477 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str10), v_t_2476));
    V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
    V v_t_2479 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2478));
    v_t_2480 = ({ V rv_2 = v_t_2479; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  V v_c_2481 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(heff_dup(v_ps_240), heff_dup(v_pkgs_241), v_t_2469, heff_dup(heff_rfield(v_f_2428, 0)), heff_dup(v_imp_244), v_t_2474, v_t_2480, NTAG(TAG_Nil)));
  V f_ = v_c_2481;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam4, 1, 11, (V[]){v_imp_244, v_f_2428, v_ps_240, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2417 = (g_list_2emap_24s435407392x1528135477(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str3)));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str4), heff_strAppend(v_w_2410, v_t_2421));
    V v_e_2423 = heff_strAppend(heff_dup(v_from_243), v_t_2422);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2427 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2426, v_rs_247));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2428 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2429 = heff_dup(heff_field(v_x_2415, 1));
    V v_t_2430 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
    V v_t_2431 = (g_list_2eany(v_t_2430, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2429);
      heff_drop(v_t_2431);
      V v_m_2432 = heff_get_n(v_f_2428, 3, 4);
      V v_t_2434;
      if (heff_strEq_c_lent(v_w_2410, v_m_2432, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2432);
        v_t_2434 = v_rs_247;
      } else {
        v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2432}), v_rs_247});
      }
      V v_t_2435 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
      V v_t_2437 = (g_list_2eany(v_t_2436, v_stack_242));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2429);
        heff_drop(v_t_2437);
        V v_m_2438 = heff_dup(heff_rfield(v_f_2428, 3));
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_t_2445 = heff_strAppend(v_m_2438, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str7), v_t_2444));
        V v_e_2446 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_str8), v_t_2445));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2447));
        V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2450 = heff_get_n(v_f_2428, 3, 4);
        V v_t_2452;
        if (heff_strEq_c_lent(v_w_2410, v_m_2450, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2450);
          v_t_2452 = v_rs_247;
        } else {
          v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2450}), v_rs_247});
        }
        V v_t_2453 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2449, v_t_2452));
        V f_ = v_t_2453;
        heff_room[0] = v_hd_2413;
        heff_room[1] = v_k_2414;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2437);
        V v_t_2456;
        switch (heff_tag_of(v_others_2429)) {
        case TAG_Nil: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2429, 0ULL, 2);
          v_t_2456 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_others_2429);
        }
        if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
          heff_drop(v_t_2456);
          V v_e_2457 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_240), v_x_2415, heff_dup(v_from_243), heff_dup(v_w_2410)));
          V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2457, NTAG(TAG_Nil)});
          V v_t_2459 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2458));
          V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_st_246, 1)});
          V v_t_2461 = ({ V rv_1 = v_t_2460; V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2462 = heff_get_n(v_f_2428, 3, 4);
          V v_t_2464;
          if (heff_strEq_c_lent(v_w_2410, v_m_2462, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2462);
            v_t_2464 = v_rs_247;
          } else {
            v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2462}), v_rs_247});
          }
          V v_t_2465 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2461, v_t_2464));
          V f_ = v_t_2465;
          heff_room[0] = v_hd_2413;
          heff_room[1] = v_k_2414;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2415, 2);
          heff_drop(v_t_2456);
          V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 1, 4);
          V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(heff_dup(v_ps_240), v_t_2466, v_t_2467, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam3, 1, 12, (V[]){v_f_2428, v_stack_242, v_imp_244, v_st_246, v_w_2410, v_from_243, v_ps_240, v_pkgs_241, v_hd_2413, v_rs_247, v_rest_2411, v_k_2414})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_imp_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_lam2, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam1, 2, 8, (V[]){v_c_2412, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_244, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2417, v_ms_2410, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526_lam2, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam6(V self, V *args) {
  V v_m_2444 = args[0];
  V v_made_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = ({ V a_0 = v_m_2444; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2444); r_; });
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_s_2449 = v_field_2447;
      return heff_get_n(v_s_2449, 5, 7);
    } else {
      heff_drop(v_field_2447);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2427 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2454;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_dup(heff_field(v_x_2451, 0));
    v_t_2454 = v_x_2452;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2455 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2456 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2457 = ({ V a_0 = v_m_2456; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2456); r_; });
  V v_t_2462;
  {
    V v_field_2459 = v_t_2457.f[1];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_s_2461 = v_field_2459;
      v_t_2462 = heff_get_n(v_s_2461, 5, 7);
    } else {
      heff_drop(v_field_2459);
      v_t_2462 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2465;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_y_2464 = heff_field(v_x_2451, 1);
    heff_take_n(v_x_2451, 2ULL, 2);
    v_t_2465 = v_y_2464;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2466 = (g_heff_2ebuild_2eload_2epushDone(v_t_2454, heff_dup(v_x_246), v_t_2455, v_file_242, v_src_2421, v_t_2462, v_t_2465));
  V v_x_2467 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2466; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_made_2427 = heff_get_n(v_x_2426, 0, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_m_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2434 = ({ V a_0 = v_m_2433; V a_1 = heff_dup(v_made_2427); HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2433); r_; });
  V v_t_2439;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_s_2438 = v_field_2436;
      v_t_2439 = heff_get_n(v_s_2438, 5, 7);
    } else {
      heff_drop(v_field_2436);
      v_t_2439 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2440 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2439, heff_dup(v_src_2421)));
  V v_imps_2441 = heff_get_n(v_t_2440, 0, 3);
  V v_t_2442 = (g_list_2emap_24s1817208647x1282894070(v_imps_2441));
  V v_t_2443 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2442));
  V v_c_2450 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, heff_dup(v_x_246), v_t_2430, v_t_2432, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam6, 1, 1, (V[]){heff_dup(v_made_2427)}), v_t_2443, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2450;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam7, 1, 7, (V[]){v_x_246, v_file_242, v_made_2427, v_src_2421, v_x_248, v_x_2414, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1920100286x1899315526(heff_dup(v_read_240), heff_dup(v_x_246), v_t_2424, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2425;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam5, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2421, v_read_240, v_hd_244, v_x_248, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(heff_dup(v_x_246), v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(v_h_241, heff_dup(v_x_246)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}