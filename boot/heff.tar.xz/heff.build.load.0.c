// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_absolute 325777132
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_col 308218
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_segments 1801007612
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_imports__implicit__text[] = {LBL_imports, LBL_implicit, LBL_text};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module[] = {LBL_path, LBL_source, LBL_place, LBL_module};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
HeffT3 g_heff_2esyntax_2eimport_2eimportsGo_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1200694983x1257685262(V, V);
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1250280863x1570195177_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s776002836x391891384(V, V);
V g_list_2efoldl_24s776002836x391891384_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776002836x391891384_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s917234327x1197288555(V);
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 1, ":");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_243), MK_INT(0LL))) {
    heff_drop(v_j_243);
    v_t_245 = NTAG(TAG_Nothing);
  } else {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
  }
  V v_t_246 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_241), heff_dup(heff_rfield(v_p_242, 0)), MK_INT(0LL), MK_INT(0LL), v_t_245));
  V v_t_247 = heff_intAdd(heff_get_n(v_t_246, 0, 3), MK_INT(1LL));
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), v_src_241, MK_INT(0LL), 5);
  V v_t_2410;
  if (heff_intLt_c(heff_dup(v_j_248), MK_INT(0LL))) {
    heff_drop(v_j_248);
    v_t_2410 = NTAG(TAG_Nothing);
  } else {
    v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  V v_t_2411 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_take_field(v_p_242, 0), MK_INT(0LL), MK_INT(0LL), v_t_2410));
  V v_t_2412 = heff_intAdd(heff_get_n(v_t_2411, 2, 3), MK_INT(1LL));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), heff_get_n(v_p_242, 1, 2));
  V v_t_2414 = heff_strAppend(heff_intShow(v_t_2412), v_t_2413);
  V v_t_2415 = heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3), v_t_2414));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4), v_t_2415));
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eproblemMsg(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str5, 1, "\\");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_s_243 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedDir_str0), v_v_242));
  V v_x2_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ecachedDir_str1), heff_dup(v_s_243), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_s_243, MK_INT(0LL)), NTAG(TAG_Nil)));
  V v_p_249;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_p_249 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Posix: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
      break;
    }
    case TAG_Windows: {
      v_t_248 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str5);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    v_p_249 = ({ V a_0 = v_t_248; V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return ({ V b_0 = heff_dup(heff_rfield(v_ps_240, 5)); V a_1 = heff_get_n(v_ps_240, 3, 6); V a_2 = v_p_249; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_x_240);
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2etakeUntil(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOfGo_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_d_246 = heff_dup(heff_rfield(v_k_244, 1));
    if (heff_strEq_c_lent(v_d_246, ((V)&g_heff_2ebuild_2eload_2epkgOfGo_str0), 2)) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_d_246);
      return heff_dup(v_k_244);
    } else {
      V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_d_246));
      V v_t_249 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_from_243)));
      V v_t_2410 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_248, v_t_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_project_242);
        heff_drop(v_from_243);
        heff_drop(v_t_2410);
        return heff_dup(v_k_244);
      } else {
        heff_drop(v_t_2410);
        V t_0 = v_ps_240;
        V t_1 = v_rest_245;
        V t_2 = v_project_242;
        V t_3 = v_from_243;
        v_ps_240 = t_0;
        v_x2_241 = t_1;
        v_project_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2efilter_24s1200694983x1257685262(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_pkgs_241);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(v_pkgs_241, v_p_249));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2414 = v_field_2412;
          V v_base_2415 = heff_take_field(v_q_2414, 2);
          V v_m_2416 = heff_strAppend(heff_take_field(v_q_2414, 3), heff_dup(v_rest_244));
          V v_xs_2417 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0), heff_dup(v_m_2416), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2416, MK_INT(0LL)), NTAG(TAG_Nil)));
          V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
          V v_parts_2422;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2419 = heff_field(v_t_2418, 0);
            V v_before_2420 = heff_field(v_t_2418, 1);
            heff_take_n(v_t_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2419, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), v_before_2420});
            v_parts_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2421));
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          V v_t_2425 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2415), v_parts_2422));
          V v_t_2426 = heff_strAppend(heff_get_n(v_q_2414, 4, 7), v_rest_244);
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2425, v_base_2415, v_parts_2422, v_t_2426}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erequiredPlace(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2423 = args[0];
  V v_p_2424 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2423; V a_2 = v_p_2424; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 7, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_path_243, V v_src_244, V v_implicit_245, V v_renames_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_243)));
  V v_t_2412;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_rel_2411 = v_field_249;
      v_t_2412 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), ((V)&g_heff_2ebuild_2eload_2epushDone_str0), v_rel_2411));
    } else {
      heff_drop(v_field_249);
      v_t_2412 = heff_dup(v_path_243);
    }
  }
  HeffT2 v_t_2413 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_243)));
  V v_t_2418;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    v_t_2418 = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2417); c_; })));
    heff_drop(v_field_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_path_243, v_t_2412, v_src_244, v_renames_246, v_implicit_245, v_t_2418}), NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2419));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 55, ", and the imports of it, so that the name is one file's");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 9, ": module ");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s917234327x1197288555(heff_dup(v_found_241)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  HeffT2 v_t_2414 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), heff_dup(v_found_241)));
  V v_t_2421;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_found_241);
      V v_f_2418 = v_field_2416;
      v_t_2421 = heff_get_n(v_f_2418, 0, 4);
    } else {
      heff_drop(v_field_2416);
      switch (heff_tag_of(v_found_241)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2);
        break;
      }
      case TAG_Cons: {
        V v_f_2419 = heff_field(v_found_241, 0);
        heff_take_n(v_found_241, 1ULL, 2);
        v_t_2421 = heff_get_n(v_f_2419, 0, 4);
        break;
      }
      default: heff_nomatch(v_found_241);
      }
    }
  }
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str3), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4)));
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str5), heff_strAppend(v_t_247, v_t_2422));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str6), heff_strAppend(v_m_243, v_t_2423));
  return heff_strAppend(v_from_242, v_t_2424);
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 2, 6), heff_get_n(v_f_248, 0, 4)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) ? ({ V v_x_2413 = heff_dup(v_field_2411); int c_ = 0; heff_drop(v_x_2413); c_; }) : 1));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str1, 3, "src");
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_path_243 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_242), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0, 2, 4, (V[]){v_path_243, v_h_240, v_d_242, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_start_241);
    heff_drop(v_hd_244);
    heff_drop(v_t_2412);
    V v_t_2413 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_242), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str1)));
    V v_t_2422;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Nothing: {
      v_t_2422 = heff_dup(heff_rfield(v_h_240, 0));
      break;
    }
    case TAG_Just: {
      V v_hf_2414 = heff_field(v_x_2410, 0);
      V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
      HeffT2 v_t_2415 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_hf_2414));
      V v_t_2421;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_p_2419 = v_field_2417;
          v_t_2421 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){v_p_2419});
        } else {
          heff_drop_cell(v_ru_24x_2410_24Just, 1);
          V v_x_2420 = v_field_2417;
          v_t_2421 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2420));
        }
      }
      v_t_2422 = ({ V a_0 = heff_dup(v_h_240); V a_1 = heff_dup(v_d_242); V a_2 = v_t_2421; V r_ = (g_heff_2ebuild_2eload_2elibRead(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_x_2423 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2413, v_t_2422, heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
    V f_ = v_k_245;
    args[0] = v_x_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_t_2412);
    V v_st_2424 = heff_dup(heff_rfield(v_h_240, 3));
    HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(v_st_2424, heff_dup(v_d_242)));
    V v_t_2432;
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_field_2428 = v_t_2425.f[2];
      V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2428));
      V v_xs_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2429; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2429); r_; });
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      v_t_2432 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2426, v_field_2427, v_t_2431});
    }
    V v_t_2433 = ({ V a_0 = v_st_2424; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); r_; });
    if (heff_strEq_c_lent(v_t_2433, v_d_242, 1)) {
      heff_drop(v_d_242);
      heff_drop(v_hd_244);
      V v_t_2435 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
      V f_ = v_k_245;
      args[0] = v_t_2435;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_st_2436 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2437 = (g_std_2epath_2eparse_24cpr(v_st_2436, v_d_242));
      V v_t_2444;
      {
        V v_field_2438 = v_t_2437.f[0];
        V v_field_2439 = v_t_2437.f[1];
        V v_field_2440 = v_t_2437.f[2];
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2440));
        V v_xs_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2441; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2441); r_; });
        V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
        v_t_2444 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2438, v_field_2439, v_t_2443});
      }
      V v_t_2445 = ({ V a_0 = v_st_2436; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
      V v_t_2446 = (g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(v_h_240, v_start_241, v_t_2445));
      V f_ = v_t_2446;
      heff_room[0] = v_hd_244;
      heff_room[1] = v_k_245;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2, 1, 5, (V[]){v_h_240, v_d_242, v_k_245, v_start_241, v_hd_244})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(V v_h_240, V v_ps_241) {
top: ;
  V v_path_242 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), heff_dup(heff_rfield(v_ps_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0, 2, 3, (V[]){v_path_242, v_h_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    v_x_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
    HeffT2 v_t_2411 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_2410)));
    V v_t_2417;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_p_2415 = v_field_2413;
        v_t_2417 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2415});
      } else {
        V v_x_2416 = v_field_2413;
        v_t_2417 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2416));
      }
    }
    V v_t_2418 = (g_heff_2ebuild_2eload_2epackageRead(v_h_240, v_ps_241, v_src_2410, v_t_2417));
    v_x_2419 = heff_tag_at_n(v_ru_24x_249_24Just, TAG_Just, 1, (V[]){v_t_2418});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_244;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_path_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_242, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(v_t_248, v_hd_243, heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2, 1, 3, (V[]){v_h_240, v_ps_241, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V v_ps_240) {
top: ;
  V v_path_241 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0, 2, 2, (V[]){v_path_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    v_x_2419 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_t_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1), heff_dup(v_t_249), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2), v_t_249, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    HeffT2 v_t_2411 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2410));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_p_2415 = v_field_2413;
        V v_t_2416 = ({ V b_0 = heff_take_field(v_ps_240, 5); V a_1 = heff_get_n(v_ps_240, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str3); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2417 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2416, v_t_249, v_p_2415));
        v_x_2419 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){v_t_2417});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_t_249);
        V v_sums_2418 = v_field_2413;
        v_x_2419 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Right, 1, (V[]){v_sums_2418});
      }
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_k_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_path_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_241, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, v_hd_242, heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2, 1, 2, (V[]){v_ps_240, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str3, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str6, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str9, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str10, 1, " ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2efilter_24s2128134357x1680551385(heff_dup(v_path_244), heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2efilter_24s50027113x1989932102(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_path_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str0));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam0, 2, 6, (V[]){v_path_2414, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2450 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_t_2451 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), v_d_2450));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2451, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam1(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2415);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str1), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str2)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str3), heff_strAppend(v_path_244, v_t_2422));
    V v_t_2424 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_by_243, v_t_2423)});
    V f_ = v_k_2416;
    args[0] = v_t_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2425 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2426 = (g_list_2efilter_24s639151216x1214259357(heff_dup(v_path_244), heff_dup(v_v_245), v_sums_242));
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2421_24Just, 1);
      v_t_2429 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 2);
      v_t_2429 = heff_tag_at_n(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_get_n(v_s_2427, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2415);
      heff_drop(v_h_2425);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str5)));
      V v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str6), heff_strAppend(v_path_244, v_t_2430));
      V f_ = v_k_2416;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_want_2432 = heff_field(v_t_2429, 0);
      V v_ru_24t_2429_24Just = heff_take_reuse_n(v_t_2429, 1ULL, 1);
      V v_t_2433 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_h_2425, 0)) - ((int64_t)1ULL));
      V v_t_2435 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), heff_box_word(v_t_2434), MK_INT(-1LL)));
      V v_t_2436 = heff_strSlice(heff_dup(v_h_2425), v_t_2433, heff_intAdd(v_t_2435, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2436, v_want_2432, 1)) {
        heff_drop(v_h_2425);
        heff_drop(v_want_2432);
        heff_drop_cell(v_ru_24t_2429_24Just, 1);
        V v_t_2438 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2439 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2438, v_path_244));
        V f_ = v_t_2439;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2415);
        V v_t_2440 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2441 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_h_2425, 0)) - ((int64_t)1ULL));
        V v_t_2443 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), heff_box_word(v_t_2442), MK_INT(-1LL)));
        V v_t_2444 = heff_strSlice(v_h_2425, v_t_2441, heff_intAdd(v_t_2443, MK_INT(1LL)));
        V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str7), v_want_2432));
        V v_t_2446 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str8), v_t_2445));
        V v_t_2447 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str9), v_t_2446));
        V v_t_2448 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_str10), v_t_2447));
        V v_x_2449 = heff_tag_at_n(v_ru_24t_2429_24Just, TAG_Left, 1, (V[]){v_t_2448});
        V f_ = v_k_2416;
        args[0] = v_x_2449;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam1_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s409176245x1046647599_lam2, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2416, v_sums_242, v_ps_240, v_hd_2415})));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDir, 2, (V[]){heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1, 1, 6, (V[]){v_p_244, v_x_245, v_ps_240, v_d_241, v_rest_246, v_p_243})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args) {
  V v_ns_247 = args[0];
  return v_ns_247;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2eload_2esameButCase(v_n_2413, v_x_245));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2412));
    HeffT2 v_t_2415 = (g_heff_2ebuild_2eload_2ecasesIn_24cpr(heff_dup(v_ps_240), heff_dup(v_d_241), heff_dup(v_x_245), v_t_2414));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_x_245);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_rest_246);
        heff_drop(v_p_243);
        V v_why_2419 = v_field_2417;
        V f_ = v_p_244;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2419});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_field_2417);
        V v_t_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_241, v_x_245));
        return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(v_ps_240, v_t_2420, v_rest_246, v_p_243, v_p_244));
      }
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(V v_lit_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam1, 2, 10, (V[]){v_t_2412, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam4(V self, V *args) {
  V v_x_2489 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_from_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2492;
  switch (heff_tag_of(v_x_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_dup(heff_field(v_x_2489, 0));
    v_t_2492 = v_x_2490;
    break;
  }
  default: heff_nomatch(v_x_2489);
  }
  V v_t_2495;
  switch (heff_tag_of(v_x_2489)) {
  case TAG_MkPair: {
    V v_y_2494 = heff_field(v_x_2489, 1);
    heff_take_n(v_x_2489, 2ULL, 2);
    v_t_2495 = v_y_2494;
    break;
  }
  default: heff_nomatch(v_x_2489);
  }
  V v_t_2496 = (g_heff_2ebuild_2eload_2epushDone(v_t_2492, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_f_2428, 0), heff_take_field(v_f_2428, 1), heff_dup(v_lit_240), v_t_2495));
  V v_m_2497 = heff_get_n(v_f_2428, 3, 4);
  V v_t_2499;
  if (heff_strEq_c_lent(v_w_2410, v_m_2497, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2497);
    v_t_2499 = v_rs_247;
  } else {
    v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2497}), v_rs_247});
  }
  V v_t_24100 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2496, v_t_2499));
  V f_ = v_t_24100;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam3(V self, V *args) {
  V v_x_2468 = args[0];
  V v_f_2428 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  V v_pkgs_242 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2414 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_dup(v_stack_243)});
  HeffT3 v_t_2470 = (g_heff_2esyntax_2eimport_2eimportsGo_24cpr(heff_dup(heff_rfield(v_f_2428, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2481;
  {
    V v_field_2471 = v_t_2470.f[0];
    V v_field_2473 = v_t_2470.f[2];
    heff_drop(v_t_2470.f[1]);
    V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_lit_240)));
    V v_t_2475 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2474; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_2474); r_; });
    V v_t_2476 = (g_prelude_2e_2b_2b(v_t_2475, v_field_2471));
    V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_lit_240)));
    V v_t_2478 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2477; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_2477); r_; });
    V v_imps_2479 = heff_get_n(heff_rec_n(3, shape_imports__implicit__text, (V[]){v_t_2476, v_t_2478, v_field_2473}), 0, 3);
    V v_t_2480 = (g_list_2emap_24s1817208647x1282894070(v_imps_2479));
    v_t_2481 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2480));
  }
  V v_t_2487;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Nothing: {
    v_t_2487 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2482 = heff_field(v_x_2468, 0);
    heff_take_n(v_x_2468, 1ULL, 1);
    V v_t_2483 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str9), v_why_2482));
    V v_t_2484 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str10), v_t_2483));
    V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    V v_t_2486 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2485));
    v_t_2487 = ({ V rv_2 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  V v_c_2488 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(heff_dup(v_lit_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2469, heff_dup(heff_rfield(v_f_2428, 0)), v_t_2481, v_t_2487, NTAG(TAG_Nil)));
  V f_ = v_c_2488;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam4, 1, 11, (V[]){v_ps_241, v_f_2428, v_lit_240, v_w_2410, v_rs_247, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2417 = (g_list_2emap_24s435407392x1528135477(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str3)));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str4), heff_strAppend(v_w_2410, v_t_2421));
    V v_e_2423 = heff_strAppend(heff_dup(v_from_244), v_t_2422);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2427 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2426, v_rs_247));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2428 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2429 = heff_dup(heff_field(v_x_2415, 1));
    V v_t_2430 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
    V v_t_2431 = (g_list_2eany(v_t_2430, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2429);
      heff_drop(v_t_2431);
      V v_m_2432 = heff_get_n(v_f_2428, 3, 4);
      V v_t_2434;
      if (heff_strEq_c_lent(v_w_2410, v_m_2432, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2432);
        v_t_2434 = v_rs_247;
      } else {
        v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2432}), v_rs_247});
      }
      V v_t_2435 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
      V v_t_2437 = (g_list_2eany(v_t_2436, v_stack_243));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2429);
        heff_drop(v_t_2437);
        V v_m_2438 = heff_dup(heff_rfield(v_f_2428, 3));
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_t_2445 = heff_strAppend(v_m_2438, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str7), v_t_2444));
        V v_e_2446 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_str8), v_t_2445));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2447));
        V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2450 = heff_get_n(v_f_2428, 3, 4);
        V v_t_2452;
        if (heff_strEq_c_lent(v_w_2410, v_m_2450, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2450);
          v_t_2452 = v_rs_247;
        } else {
          v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2450}), v_rs_247});
        }
        V v_t_2453 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2449, v_t_2452));
        V f_ = v_t_2453;
        heff_room[0] = v_hd_2413;
        heff_room[1] = v_k_2414;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2437);
        V v_t_2456;
        switch (heff_tag_of(v_others_2429)) {
        case TAG_Nil: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2429, 0ULL, 2);
          v_t_2456 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_others_2429);
        }
        if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
          heff_drop(v_t_2456);
          V v_e_2457 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2415, heff_dup(v_from_244), heff_dup(v_w_2410)));
          V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2457, NTAG(TAG_Nil)});
          V v_t_2459 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2458));
          V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_st_246, 1)});
          V v_t_2461 = ({ V rv_1 = v_t_2460; V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2462 = heff_get_n(v_f_2428, 3, 4);
          V v_t_2464;
          if (heff_strEq_c_lent(v_w_2410, v_m_2462, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2462);
            v_t_2464 = v_rs_247;
          } else {
            v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2462}), v_rs_247});
          }
          V v_t_2465 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2461, v_t_2464));
          V f_ = v_t_2465;
          heff_room[0] = v_hd_2413;
          heff_room[1] = v_k_2414;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2415, 2);
          heff_drop(v_t_2456);
          V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 1, 4);
          V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_241), v_t_2466, v_t_2467, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam3, 1, 12, (V[]){v_f_2428, v_stack_243, v_lit_240, v_st_246, v_w_2410, v_from_244, v_ps_241, v_pkgs_242, v_hd_2413, v_rs_247, v_rest_2411, v_k_2414})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s472995819x2011916773(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1, 2, 7, (V[]){v_c_2411, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_before_243, v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2420 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(v_ps_240, v_pkgs_241, v_from_242, v_t_2416, v_ms_249, v_t_2419));
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(v_read_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(V v_lit_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(heff_dup(v_read_241), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam1, 2, 11, (V[]){v_c_2414, v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam4(V self, V *args) {
  V v_x_2491 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_pkgs_243 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_from_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2494;
  switch (heff_tag_of(v_x_2491)) {
  case TAG_MkPair: {
    V v_x_2492 = heff_dup(heff_field(v_x_2491, 0));
    v_t_2494 = v_x_2492;
    break;
  }
  default: heff_nomatch(v_x_2491);
  }
  V v_t_2497;
  switch (heff_tag_of(v_x_2491)) {
  case TAG_MkPair: {
    V v_y_2496 = heff_field(v_x_2491, 1);
    heff_take_n(v_x_2491, 2ULL, 2);
    v_t_2497 = v_y_2496;
    break;
  }
  default: heff_nomatch(v_x_2491);
  }
  V v_t_2498 = (g_heff_2ebuild_2eload_2epushDone(v_t_2494, heff_dup(v_ps_242), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), heff_dup(v_lit_240), v_t_2497));
  V v_m_2499 = heff_get_n(v_f_2430, 3, 4);
  V v_t_24101;
  if (heff_strEq_c_lent(v_w_2411, v_m_2499, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2499);
    v_t_24101 = v_rs_248;
  } else {
    v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2499}), v_rs_248});
  }
  V v_t_24102 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2498, v_t_24101));
  V f_ = v_t_24102;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam3(V self, V *args) {
  V v_x_2470 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_245 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_ps_242 = heff_env(self)[7];
  V v_pkgs_243 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_244)});
  HeffT3 v_t_2472 = (g_heff_2esyntax_2eimport_2eimportsGo_24cpr(heff_dup(heff_rfield(v_f_2430, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2483;
  {
    V v_field_2473 = v_t_2472.f[0];
    V v_field_2475 = v_t_2472.f[2];
    heff_drop(v_t_2472.f[1]);
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_lit_240)));
    V v_t_2477 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2476; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_2476); r_; });
    V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2477, v_field_2473));
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_lit_240)));
    V v_t_2480 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2479; V r_ = (g_list_2efoldl_24s776002836x391891384(a_0, a_1)); heff_drop(v_t_2479); r_; });
    V v_imps_2481 = heff_get_n(heff_rec_n(3, shape_imports__implicit__text, (V[]){v_t_2478, v_t_2480, v_field_2475}), 0, 3);
    V v_t_2482 = (g_list_2emap_24s1817208647x1282894070(v_imps_2481));
    v_t_2483 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2482));
  }
  V v_t_2489;
  switch (heff_tag_of(v_x_2470)) {
  case TAG_Nothing: {
    v_t_2489 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2484 = heff_field(v_x_2470, 0);
    heff_take_n(v_x_2470, 1ULL, 1);
    V v_t_2485 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str9), v_why_2484));
    V v_t_2486 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str10), v_t_2485));
    V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
    V v_t_2488 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2487));
    v_t_2489 = ({ V rv_2 = v_t_2488; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2470);
  }
  V v_c_2490 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(heff_dup(v_lit_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), v_t_2471, heff_dup(heff_rfield(v_f_2430, 0)), v_t_2483, v_t_2489, NTAG(TAG_Nil)));
  V f_ = v_c_2490;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam4, 1, 12, (V[]){v_ps_242, v_f_2430, v_lit_240, v_w_2411, v_rs_248, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_245), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 4);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_244));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 4);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        V v_t_2458;
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          v_t_2458 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2431, 0ULL, 2);
          v_t_2458 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_others_2431);
        }
        if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
          heff_drop(v_t_2458);
          V v_e_2459 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2417, heff_dup(v_from_245), heff_dup(v_w_2411)));
          V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2459, NTAG(TAG_Nil)});
          V v_t_2461 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2460));
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2463 = ({ V rv_1 = v_t_2462; V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2464 = heff_get_n(v_f_2430, 3, 4);
          V v_t_2466;
          if (heff_strEq_c_lent(v_w_2411, v_m_2464, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2464);
            v_t_2466 = v_rs_248;
          } else {
            v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2464}), v_rs_248});
          }
          V v_t_2467 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2463, v_t_2466));
          V f_ = v_t_2467;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2417, 2);
          heff_drop(v_t_2458);
          V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2469 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_242), v_t_2468, v_t_2469, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam3, 1, 13, (V[]){v_f_2430, v_stack_244, v_lit_240, v_st_247, v_w_2411, v_from_245, v_read_241, v_ps_242, v_pkgs_243, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981_lam2, 1, 12, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s633307358x1352372981(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1, 2, 8, (V[]){v_c_2412, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_244, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2417, v_ms_2410, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args) {
  V v_x_2484 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_from_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2487;
  switch (heff_tag_of(v_x_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_dup(heff_field(v_x_2484, 0));
    v_t_2487 = v_x_2485;
    break;
  }
  default: heff_nomatch(v_x_2484);
  }
  V v_t_2488 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2491;
  switch (heff_tag_of(v_x_2484)) {
  case TAG_MkPair: {
    V v_y_2490 = heff_field(v_x_2484, 1);
    heff_take_n(v_x_2484, 2ULL, 2);
    v_t_2491 = v_y_2490;
    break;
  }
  default: heff_nomatch(v_x_2484);
  }
  V v_t_2492 = (g_heff_2ebuild_2eload_2epushDone(v_t_2487, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), v_t_2488, v_t_2491));
  V v_m_2493 = heff_get_n(v_f_2430, 3, 4);
  V v_t_2495;
  if (heff_strEq_c_lent(v_w_2411, v_m_2493, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2493);
    v_t_2495 = v_rs_248;
  } else {
    v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2493}), v_rs_248});
  }
  V v_t_2496 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2492, v_t_2495));
  V f_ = v_t_2496;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args) {
  V v_x_2470 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_imp_245 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_243)});
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2473 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2472, heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2474 = heff_get_n(v_t_2473, 0, 3);
  V v_t_2475 = (g_list_2emap_24s1817208647x1282894070(v_imps_2474));
  V v_t_2476 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2475));
  V v_t_2482;
  switch (heff_tag_of(v_x_2470)) {
  case TAG_Nothing: {
    v_t_2482 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2477 = heff_field(v_x_2470, 0);
    heff_take_n(v_x_2470, 1ULL, 1);
    V v_t_2478 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9), v_why_2477));
    V v_t_2479 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10), v_t_2478));
    V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
    V v_t_2481 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2480));
    v_t_2482 = ({ V rv_2 = v_t_2481; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2470);
  }
  V v_c_2483 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2471, heff_dup(heff_rfield(v_f_2430, 0)), heff_dup(v_imp_245), v_t_2476, v_t_2482, NTAG(TAG_Nil)));
  V f_ = v_c_2483;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4, 1, 12, (V[]){v_imp_245, v_f_2430, v_ps_241, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_244), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 4);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_243));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 4);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        V v_t_2458;
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          v_t_2458 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2431, 0ULL, 2);
          v_t_2458 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_others_2431);
        }
        if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
          heff_drop(v_t_2458);
          V v_e_2459 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2417, heff_dup(v_from_244), heff_dup(v_w_2411)));
          V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2459, NTAG(TAG_Nil)});
          V v_t_2461 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2460));
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2463 = ({ V rv_1 = v_t_2462; V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2464 = heff_get_n(v_f_2430, 3, 4);
          V v_t_2466;
          if (heff_strEq_c_lent(v_w_2411, v_m_2464, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2464);
            v_t_2466 = v_rs_248;
          } else {
            v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2464}), v_rs_248});
          }
          V v_t_2467 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2463, v_t_2466));
          V f_ = v_t_2467;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2417, 2);
          heff_drop(v_t_2458);
          V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2469 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_241), v_t_2468, v_t_2469, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3, 1, 13, (V[]){v_f_2430, v_stack_243, v_imp_245, v_st_247, v_w_2411, v_from_244, v_read_240, v_ps_241, v_pkgs_242, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args) {
  V v_m_2444 = args[0];
  V v_made_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = (g_list_2efind_24s1250280863x1570195177_24cpr(v_m_2444, v_made_2427));
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_s_2449 = v_field_2447;
      return heff_get_n(v_s_2449, 5, 7);
    } else {
      heff_drop(v_field_2447);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2427 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2454;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_dup(heff_field(v_x_2451, 0));
    v_t_2454 = v_x_2452;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2455 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2456 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2457 = (g_list_2efind_24s1250280863x1570195177_24cpr(v_m_2456, v_made_2427));
  V v_t_2462;
  {
    V v_field_2459 = v_t_2457.f[1];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_s_2461 = v_field_2459;
      v_t_2462 = heff_get_n(v_s_2461, 5, 7);
    } else {
      heff_drop(v_field_2459);
      v_t_2462 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2465;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_y_2464 = heff_field(v_x_2451, 1);
    heff_take_n(v_x_2451, 2ULL, 2);
    v_t_2465 = v_y_2464;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2466 = (g_heff_2ebuild_2eload_2epushDone(v_t_2454, heff_dup(v_x_246), v_t_2455, v_file_242, v_src_2421, v_t_2462, v_t_2465));
  V v_x_2467 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2466; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_made_2427 = heff_get_n(v_x_2426, 0, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_m_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2434 = (g_list_2efind_24s1250280863x1570195177_24cpr(v_m_2433, heff_dup(v_made_2427)));
  V v_t_2439;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_s_2438 = v_field_2436;
      v_t_2439 = heff_get_n(v_s_2438, 5, 7);
    } else {
      heff_drop(v_field_2436);
      v_t_2439 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2440 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2439, heff_dup(v_src_2421)));
  V v_imps_2441 = heff_get_n(v_t_2440, 0, 3);
  V v_t_2442 = (g_list_2emap_24s1817208647x1282894070(v_imps_2441));
  V v_t_2443 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2442));
  V v_c_2450 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, heff_dup(v_x_246), v_t_2430, v_t_2432, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6, 1, 1, (V[]){heff_dup(v_made_2427)}), v_t_2443, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2450;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7, 1, 7, (V[]){v_x_246, v_file_242, v_made_2427, v_src_2421, v_x_248, v_x_2414, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(heff_dup(v_read_240), heff_dup(v_x_246), v_t_2424, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2425;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2421, v_read_240, v_hd_244, v_x_248, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(heff_dup(v_x_246), v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(v_h_241, heff_dup(v_x_246)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}