// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
#define LBL_absolute 325777132
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_col 308218
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_segments 1801007612
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module[] = {LBL_path, LBL_source, LBL_place, LBL_module};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecasesIn(V, V, V, V);
V g_heff_2ebuild_2eload_2ecasesIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecasesIn_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2efromCwd(V, V);
V g_heff_2ebuild_2eload_2efromCwd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efromCwd_clo;
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eofLibrary(V, V);
V g_heff_2ebuild_2eload_2eofLibrary_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eofLibrary_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2epkgByPath(V, V);
V g_heff_2ebuild_2eload_2epkgByPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgByPath_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2eshownOf(V, V);
V g_heff_2ebuild_2eload_2eshownOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eshownOf_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2esumGo(V, V);
V g_heff_2ebuild_2eproject_2esumGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumGo_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s917234327x1197288555(V);
V g_list_2emap_24s917234327x1197288555_entry(V self, V *a);
extern Clo g_list_2emap_24s917234327x1197288555_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erelative(V, V, V);
V g_std_2epath_2erelative_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2eload_2eunder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eunder_entry, 3, 0};

V g_heff_2ebuild_2eload_2eunder(V v_ps_240, V v_d_241, V v_p_242) {
top: ;
  V v_st_243 = heff_get_n(v_ps_240, 5, 6);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, v_d_241));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, v_p_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_p_246, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eunder(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eload_2eproblemMsg_str4, 1, ":");
Clo g_heff_2ebuild_2eload_2eproblemMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eproblemMsg_entry, 3, 0};

V g_heff_2ebuild_2eload_2eproblemMsg(V v_path_240, V v_src_241, V v_p_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str0), heff_dup(v_src_241), MK_INT(0LL)));
  V v_t_244 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_241), heff_dup(heff_rfield(v_p_242, 0)), MK_INT(0LL), MK_INT(0LL), v_t_243));
  V v_t_245 = heff_intAdd(heff_get_n(v_t_244, 0, 3), MK_INT(1LL));
  V v_t_246 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str1), heff_dup(v_src_241), MK_INT(0LL)));
  V v_t_247 = (g_heff_2elsp_2erender_2elineColAt(v_src_241, heff_take_field(v_p_242, 0), MK_INT(0LL), MK_INT(0LL), v_t_246));
  V v_t_248 = heff_intAdd(heff_get_n(v_t_247, 2, 3), MK_INT(1LL));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str2), heff_get_n(v_p_242, 1, 2));
  V v_t_2410 = heff_strAppend(heff_intShow(v_t_248), v_t_249);
  V v_t_2411 = heff_strAppend(heff_intShow(v_t_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str3), v_t_2410));
  return heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eproblemMsg_str4), v_t_2411));
}
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eproblemMsg(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2epkgByPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgByPath_entry, 2, 0};

V g_heff_2ebuild_2eload_2epkgByPath(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      heff_drop(v_p_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_242)});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eload_2epkgByPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2epkgByPath(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str1, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str2, 1, "@");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedDir_str4, 0, "");
Clo g_heff_2ebuild_2eload_2ecachedDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecachedDir(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_sep_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_sep_244 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str0);
    break;
  }
  case TAG_Windows: {
    v_sep_244 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedDir_str2), v_v_242));
  V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ecachedDir_str3), v_t_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_sep_244);
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2ecachedDir_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = v_sep_244; V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  HEFF_LAST return g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), heff_get_n(v_ps_240, 3, 6), v_t_249);
}
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedDir(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2etakeUntil(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_entry, 2, 0};

V g_heff_2ebuild_2eload_2enamedGo(V v_taken_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_242, 3)), MK_INT(1LL)));
    V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_242, 0), heff_take_field(v_k_242, 1), heff_take_field(v_k_242, 2), heff_dup(heff_rfield(v_k_242, 3)), v_t_244, heff_take_field(v_k_242, 5), heff_take_field(v_k_242, 6)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_t_247 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_242, 3, 7), MK_INT(1LL)));
    V v_u_248 = (g_heff_2ebuild_2eload_2enamedGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_taken_240}), v_rest_243, heff_dup(v_cell_246)));
    heff_drop(v_u_248);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOfGo_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2epkgOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOfGo_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOfGo(V v_ps_240, V v_x2_241, V v_project_242, V v_from_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_from_243);
    return v_project_242;
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_d_246 = heff_dup(heff_rfield(v_k_244, 1));
    if (heff_strEq_c(heff_dup(v_d_246), ((V)&g_heff_2ebuild_2eload_2epkgOfGo_str0))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_project_242);
      heff_drop(v_from_243);
      heff_drop(v_d_246);
      return heff_dup(v_k_244);
    } else {
      V v_t_248 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_246));
      V v_t_249 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_from_243)));
      V v_t_2410 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_248, v_t_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_project_242);
        heff_drop(v_from_243);
        heff_drop(v_t_2410);
        return heff_dup(v_k_244);
      } else {
        heff_drop(v_t_2410);
        V t_0 = v_ps_240;
        V t_1 = v_rest_245;
        V t_2 = v_project_242;
        V t_3 = v_from_243;
        v_ps_240 = t_0;
        v_x2_241 = t_1;
        v_project_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2epkgOfGo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_249 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 1, 1, (V[]){v_h_243}), heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_2410 = heff_field(v_it_249, 0);
    V v_ru_24it_249_24Cons = heff_take_reuse_n(v_it_249, 1ULL, 2);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_p_2413 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 2ULL, 2);
      V v_t_2414 = (g_heff_2ebuild_2eload_2epkgByPath(v_pkgs_241, v_p_2413));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_ps_240);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24it_249_24Cons, 2);
        heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_q_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        V v_base_2416 = heff_take_field(v_q_2415, 2);
        V v_t_2417 = heff_strAppend(heff_take_field(v_q_2415, 3), heff_dup(v_rest_244));
        V v_xs_2418 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0), v_t_2417, MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
        V v_parts_2423;
        switch (heff_tag_of(v_t_2419)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24it_249_24Cons, 2);
          v_parts_2423 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2420 = heff_field(v_t_2419, 0);
          V v_before_2421 = heff_field(v_t_2419, 1);
          heff_take_n(v_t_2419, 3ULL, 2);
          V v_t_2422 = heff_tag_at_n(v_ru_24it_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2420, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1)), v_before_2421});
          v_parts_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2422));
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eload_2eunder_clo), 1, (V[]){v_ps_240}));
        V v_t_2425 = (g_list_2efoldl(v_t_2424, heff_dup(v_base_2416), v_parts_2423));
        V v_t_2426 = heff_strAppend(heff_get_n(v_q_2415, 4, 7), v_rest_244);
        return heff_tag_at_n(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2425, v_base_2416, v_parts_2423, v_t_2426}), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 2);
    v_t_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return heff_strEq(v_t_248, v_h_243);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str0, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str1, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str4, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_str5, 74, ": names that differ only in case are one file where case is not told apart");
Clo g_heff_2ebuild_2eload_2ecasesIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecasesIn_entry, 4, 0};

V g_heff_2ebuild_2eload_2ecasesIn(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_ns_243, 0);
    V v_ns2_245 = heff_field(v_ns_243, 1);
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_n_244), heff_dup(v_x_242))) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_x_242);
        return NTAG(TAG_Nothing);
      } else {
        V v_st_247 = heff_get_n(v_ps_240, 5, 6);
        V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_241));
        V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_x_242)));
        V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
        V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
        V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_p_2410, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2413 = ({ V a_0 = v_st_247; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); r_; });
        V v_t_2414 = heff_strAppend(heff_dup(v_n_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str0), v_x_242));
        V v_t_2415 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str1), v_t_2414));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
      }
    }
    case TAG_Cons: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      V v_t_2420;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_ns_243, 0);
        V v_xs_2419 = heff_field(v_ns_243, 1);
        v_t_2420 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2eload_2ecasesIn_str3), heff_dup(v_x_2418), v_xs_2419));
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_str4), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2ecasesIn_str5)));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_d_241, v_t_2421)});
    }
    default: return heff_nomatch(v_ns2_245);
    }
  }
  default: return heff_nomatch(v_ns_243);
  }
}
V g_heff_2ebuild_2eload_2ecasesIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2ecasesIn(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eshownOf_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2eshownOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eshownOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2eshownOf(V v_ps_240, V v_path_241) {
top: ;
  V v_d_242 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_243 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_d_242)));
  V v_t_244 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
  V v_t_245 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_243, v_t_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), v_d_242));
    V v_t_247 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_240), heff_dup(v_path_241)));
    V v_t_248 = (g_std_2epath_2erelative(heff_rfield(v_ps_240, 5), v_t_246, v_t_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ps_240, 6);
      return v_path_241;
    }
    case TAG_Just: {
      V v_rel_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_path_241);
      V v_st_2410 = heff_get_n(v_ps_240, 5, 6);
      V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, ((V)&g_heff_2ebuild_2eload_2eshownOf_str0)));
      V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, v_rel_249));
      V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
      V v_t_2414 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2413, 1)), heff_rfield(v_p_2413, 2)));
      V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_p_2413, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return ({ V a_0 = v_st_2410; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); r_; });
    }
    default: return heff_nomatch(v_t_248);
    }
  } else {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_242);
    heff_drop(v_t_245);
    return v_path_241;
  }
}
V g_heff_2ebuild_2eload_2eshownOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eshownOf(a[0], a[1]);
}
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 7, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_path_243, V v_src_244, V v_implicit_245, V v_renames_246) {
top: ;
  V v_t_247 = (g_heff_2ebuild_2eload_2eshownOf(heff_dup(v_ps_241), heff_dup(v_path_243)));
  V v_t_248 = (g_heff_2ebuild_2eload_2eofLibrary(v_ps_241, heff_dup(v_path_243)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_path_243, v_t_247, v_src_244, v_renames_246, v_implicit_245, v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str3, 39, ", so it is loaded from neither: rename ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str4, 55, ", and the imports of it, so that the name is one file's");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str5, 24, " is more than one file: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eclashMsg_str6, 9, ": module ");
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eclashMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eclashMsg_entry, 4, 0};

V g_heff_2ebuild_2eload_2eclashMsg(V v_ps_240, V v_found_241, V v_from_242, V v_m_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s917234327x1197288555(heff_dup(v_found_241)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_2410 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2eload_2eclashMsg_lam0, 1, 1, (V[]){v_ps_240}), v_found_241));
  V v_t_2414;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_found_241)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eload_2eclashMsg_str2);
      break;
    }
    case TAG_Cons: {
      V v_f_2411 = heff_field(v_found_241, 0);
      heff_take_n(v_found_241, 1ULL, 2);
      v_t_2414 = heff_get_n(v_f_2411, 0, 4);
      break;
    }
    default: heff_nomatch(v_found_241);
    }
    break;
  }
  case TAG_Just: {
    V v_f_2413 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    heff_drop(v_found_241);
    v_t_2414 = heff_get_n(v_f_2413, 0, 4);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str3), heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2eload_2eclashMsg_str4)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str5), heff_strAppend(v_t_247, v_t_2415));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eclashMsg_str6), heff_strAppend(v_m_243, v_t_2416));
  return heff_strAppend(v_from_242, v_t_2417);
}
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eclashMsg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eclashMsg_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = (g_heff_2ebuild_2eload_2eofLibrary(v_ps_240, heff_get_n(v_f_248, 0, 4)));
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str1, 3, "src");
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_d_242)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str0)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_p_246, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_249 = ({ V a_0 = v_st_243; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); r_; });
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0, 2, 4, (V[]){v_path_249, v_h_240, v_d_242, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_start_241);
    heff_drop(v_hd_2410);
    heff_drop(v_t_2418);
    V v_st_2419 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_2420 = (g_std_2epath_2eparse(v_st_2419, heff_dup(v_d_242)));
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2419, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_str1)));
    V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
    V v_t_2423 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2422, 1)), heff_rfield(v_p_2422, 2)));
    V v_t_2424 = ({ V rv_2 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_p_2422, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2425 = ({ V a_0 = v_st_2419; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); r_; });
    V v_t_2431;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      v_t_2431 = heff_dup(heff_rfield(v_h_240, 0));
      break;
    }
    case TAG_Just: {
      V v_hf_2426 = heff_field(v_x_2416, 0);
      V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
      V v_x1_2427 = (g_heff_2ebuild_2eproject_2epackageLit(v_hf_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_Left: {
        V v_p_2428 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        v_t_2430 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_Left, 1, (V[]){v_p_2428});
        break;
      }
      case TAG_Right: {
        V v_x_2429 = heff_field(v_x1_2427, 0);
        heff_take_n(v_x1_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24x_2416_24Just, 1);
        v_t_2430 = ({ V a_0 = v_x_2429; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
      v_t_2431 = ({ V a_0 = heff_dup(v_h_240); V a_1 = heff_dup(v_d_242); V a_2 = v_t_2430; V r_ = (g_heff_2ebuild_2eload_2elibRead(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    V v_x_2432 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2425, v_t_2431, heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
    V f_ = v_k_2411;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_t_2418);
    V v_st_2433 = heff_dup(heff_rfield(v_h_240, 3));
    V v_p_2434 = (g_std_2epath_2eparse(v_st_2433, heff_dup(v_d_242)));
    V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2434, 2)));
    V v_xs_2436 = (g_list_2edrop(MK_INT(1LL), v_t_2435));
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2436));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_p_2434, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2439 = ({ V a_0 = v_st_2433; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2433); r_; });
    if (heff_strEq_c(v_t_2439, heff_dup(v_d_242))) {
      heff_drop(v_d_242);
      heff_drop(v_hd_2410);
      V v_t_2441 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
      V f_ = v_k_2411;
      args[0] = v_t_2441;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_st_2442 = heff_dup(heff_rfield(v_h_240, 3));
      V v_p_2443 = (g_std_2epath_2eparse(v_st_2442, v_d_242));
      V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2443, 2)));
      V v_xs_2445 = (g_list_2edrop(MK_INT(1LL), v_t_2444));
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2445));
      V v_t_2447 = ({ V rv_2 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_p_2443, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2448 = ({ V a_0 = v_st_2442; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2442); r_; });
      V v_t_2449 = (g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(v_h_240, v_start_241, v_t_2448));
      V f_ = v_t_2449;
      heff_room[0] = v_hd_2410;
      heff_room[1] = v_k_2411;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_path_249 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_249, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam1_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_lam2, 1, 5, (V[]){v_h_240, v_d_242, v_k_2411, v_start_241, v_hd_2410})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(V v_h_240, V v_ps_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_243 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_ps_241, 0))));
  V v_t_244 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_str0)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_245, 1)), heff_rfield(v_p_245, 2)));
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_nf(v_p_245, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_248 = ({ V a_0 = v_st_242; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0, 2, 3, (V[]){v_path_248, v_h_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    v_x_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_x1_2417 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_src_2416)));
    V v_t_2420;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Left: {
      V v_p_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      v_t_2420 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Left, 1, (V[]){v_p_2418});
      break;
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Just, 1);
      v_t_2420 = ({ V a_0 = v_x_2419; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    V v_t_2421 = (g_heff_2ebuild_2eload_2epackageRead(v_h_240, v_ps_241, v_src_2416, v_t_2420));
    v_x_2422 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2410;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_path_248 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam1_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_249, heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_lam2, 1, 3, (V[]){v_h_240, v_ps_241, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_244, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0, 2, 2, (V[]){v_path_247, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    v_x_2428 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str1), heff_dup(v_t_2415), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2eproject_2esumGo(a_0, a_1)); heff_drop(v_t_2416); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Left: {
      V v_p_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      V v_st_2419 = heff_take_field(v_ps_240, 5);
      V v_t_2420 = (g_std_2epath_2eparse(v_st_2419, heff_get_n(v_ps_240, 0, 6)));
      V v_t_2421 = (g_std_2epath_2eparse(v_st_2419, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_str2)));
      V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
      V v_t_2423 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2422, 1)), heff_rfield(v_p_2422, 2)));
      V v_t_2424 = ({ V rv_2 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_p_2422, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2425 = ({ V a_0 = v_st_2419; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); r_; });
      V v_t_2426 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2425, v_t_2415, v_p_2418));
      v_x_2428 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_Left, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_Right: {
      V v_sums_2427 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_t_2415);
      v_x_2428 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_Right, 1, (V[]){v_sums_2427});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_249;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam1_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, v_hd_248, heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_lam2, 1, 2, (V[]){v_ps_240, v_k_249})));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDir, 2, (V[]){heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1, 1, 6, (V[]){v_p_244, v_x_245, v_ps_240, v_d_241, v_rest_246, v_p_243})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam0(V self, V *args) {
  V v_ns_247 = args[0];
  return v_ns_247;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2eload_2esameButCase(v_n_2413, v_x_245));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_lam2, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2412));
    V v_t_2415 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = heff_dup(v_d_241); V a_2 = heff_dup(v_x_245); V a_3 = v_t_2414; V r_ = (g_heff_2ebuild_2eload_2ecasesIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      V v_st_2416 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2417 = (g_std_2epath_2eparse(v_st_2416, v_d_241));
      V v_t_2418 = (g_std_2epath_2eparse(v_st_2416, v_x_245));
      V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
      V v_t_2420 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2419, 1)), heff_rfield(v_p_2419, 2)));
      V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_p_2419, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2422 = ({ V a_0 = v_st_2416; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); r_; });
      return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(v_ps_240, v_t_2422, v_rest_246, v_p_243, v_p_244));
    }
    case TAG_Just: {
      V v_why_2423 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop(v_x_245);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_d_241);
      heff_drop(v_rest_246);
      heff_drop(v_p_243);
      V f_ = v_p_244;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2423});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1, 1, 1, (V[]){heff_dup(v_before_243)}), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2, 2, 7, (V[]){v_c_2412, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_before_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  return v_before_243;
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_243, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(v_ps_240, v_pkgs_241, v_from_242, v_t_2417, v_ms_249, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_lam3, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1, 1, 0};
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry, 2, 0};

V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(V v_st_240, V v_d_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, v_d_241));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_244, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  return heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0, 2, 1, (V[]){v_path_247});
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_x_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2414, 0ULL, 1);
    v_x_2416 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_249;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam1_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, v_hd_248, heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_lam2, 1, 1, (V[]){v_k_249})));
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_x_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4)});
    v_x_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(v_read_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1403228623x93286885(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4(V self, V *args) {
  V v_x_2486 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_from_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2489;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_dup(heff_field(v_x_2486, 0));
    v_t_2489 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_t_2490 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2493;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_MkPair: {
    V v_y_2492 = heff_field(v_x_2486, 1);
    heff_take_n(v_x_2486, 2ULL, 2);
    v_t_2493 = v_y_2492;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_t_2494 = (g_heff_2ebuild_2eload_2epushDone(v_t_2489, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), v_t_2490, v_t_2493));
  V v_m_2495 = heff_get_n(v_f_2430, 3, 4);
  V v_t_2497;
  if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2495))) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2495);
    v_t_2497 = v_rs_248;
  } else {
    v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2495}), v_rs_248});
  }
  V v_t_2498 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2494, v_t_2497));
  V f_ = v_t_2498;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3(V self, V *args) {
  V v_x_2472 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_imp_245 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_243)});
  V v_t_2474 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2475 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2474, heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2476 = heff_get_n(v_t_2475, 0, 3);
  V v_t_2477 = (g_list_2emap_24s1817208647x1282894070(v_imps_2476));
  V v_t_2478 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2477));
  V v_t_2484;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_Nothing: {
    v_t_2484 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2479 = heff_field(v_x_2472, 0);
    heff_take_n(v_x_2472, 1ULL, 1);
    V v_t_2480 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str9), v_why_2479));
    V v_t_2481 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str10), v_t_2480));
    V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
    V v_t_2483 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2482));
    v_t_2484 = ({ V rv_2 = v_t_2483; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_c_2485 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2473, heff_dup(heff_rfield(v_f_2430, 0)), heff_dup(v_imp_245), v_t_2478, v_t_2484, NTAG(TAG_Nil)));
  V f_ = v_c_2485;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam4, 1, 12, (V[]){v_imp_245, v_f_2430, v_ps_241, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_244), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 4);
      V v_t_2436;
      if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2434))) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_243));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 4);
        V v_t_2454;
        if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2452))) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        V v_x1_2458;
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          v_x1_2458 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2431, 0ULL, 2);
          v_x1_2458 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_others_2431);
        }
        V v_t_2459 = heff_bool(!(heff_dup(v_x1_2458) == NTAG(TAG_True)));
        heff_drop(v_x1_2458);
        if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
          heff_drop(v_t_2459);
          V v_e_2460 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2417, heff_dup(v_from_244), heff_dup(v_w_2411)));
          V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2460, NTAG(TAG_Nil)});
          V v_t_2462 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2461));
          V v_st_2463 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_2463, 1)});
          V v_t_2465 = ({ V rv_1 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_st_2463, 5ULL, 3, shape_done__doneMods__errors, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_m_2466 = heff_get_n(v_f_2430, 3, 4);
          V v_t_2468;
          if (heff_strEq_c(heff_dup(v_w_2411), heff_dup(v_m_2466))) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2466);
            v_t_2468 = v_rs_248;
          } else {
            v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2466}), v_rs_248});
          }
          V v_t_2469 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2465, v_t_2468));
          V f_ = v_t_2469;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2417, 2);
          heff_drop(v_t_2459);
          V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2471 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_241), v_t_2470, v_t_2471, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam3, 1, 13, (V[]){v_f_2430, v_stack_243, v_imp_245, v_st_247, v_w_2411, v_from_244, v_read_240, v_ps_241, v_pkgs_242, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1, 1, 1, (V[]){heff_dup(v_before_244)}), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2, 2, 8, (V[]){v_c_2413, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_before_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  return v_before_244;
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b(v_before_244, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 2);
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_t_2422 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2418, v_ms_2410, v_t_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977_lam3, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2434, 0, 7), v_m_2433);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2443, 0, 7), v_m_2442);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7(V self, V *args) {
  V v_m_2442 = args[0];
  V v_made_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam8, 1, 1, (V[]){v_m_2442}); V a_1 = v_made_2427; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_made_2427); r_; });
  switch (heff_tag_of(v_t_2444)) {
  case TAG_Nothing: {
    return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
  }
  case TAG_Just: {
    V v_s_2445 = heff_field(v_t_2444, 0);
    heff_take_n(v_t_2444, 1ULL, 1);
    return heff_get_n(v_s_2445, 5, 7);
  }
  default: return heff_nomatch(v_t_2444);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10(V self, V *args) {
  V v_s_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_s_2453, 0, 7), v_m_2452);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2427 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_dup(heff_field(v_x_2447, 0));
    v_t_2450 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2451 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2452 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2454 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam10, 1, 1, (V[]){v_m_2452}); V a_1 = v_made_2427; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_made_2427); r_; });
  V v_t_2456;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_Nothing: {
    v_t_2456 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2455 = heff_field(v_t_2454, 0);
    heff_take_n(v_t_2454, 1ULL, 1);
    v_t_2456 = heff_get_n(v_s_2455, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  V v_t_2459;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_y_2458 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 2ULL, 2);
    v_t_2459 = v_y_2458;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2460 = (g_heff_2ebuild_2eload_2epushDone(v_t_2450, heff_dup(v_x_246), v_t_2451, v_file_242, v_src_2421, v_t_2456, v_t_2459));
  V v_x_2461 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2460; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_made_2427 = heff_get_n(v_x_2426, 0, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_m_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2435 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam6, 1, 1, (V[]){v_m_2433}), v_made_2427));
  V v_t_2437;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Nothing: {
    v_t_2437 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2436 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 1);
    v_t_2437 = heff_get_n(v_s_2436, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_t_2438 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2437, heff_dup(v_src_2421)));
  V v_imps_2439 = heff_get_n(v_t_2438, 0, 3);
  V v_t_2440 = (g_list_2emap_24s1817208647x1282894070(v_imps_2439));
  V v_t_2441 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2440));
  V v_c_2446 = (g_heff_2ebuild_2eload_2eloadMany_24s1232078551x822692345(v_read_240, heff_dup(v_x_246), v_t_2430, v_t_2432, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam7, 1, 1, (V[]){heff_dup(v_made_2427)}), v_t_2441, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2446;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam9, 1, 7, (V[]){v_x_246, v_file_242, v_made_2427, v_src_2421, v_x_248, v_x_2414, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_pkgs_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_pkgs_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s155679786x1419501977(heff_dup(v_read_240), heff_dup(v_x_246), v_pkgs_2424, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2425;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam5, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2421, v_read_240, v_hd_244, v_x_248, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(heff_dup(v_x_246), v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(v_h_241, heff_dup(v_x_246)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}