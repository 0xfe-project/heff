// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_base 9511832
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(void);
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1620001354x1503070464(V);
V g_co_2eop_24s1620001354x1503070464_entry(V self, V *a);
extern Clo g_co_2eop_24s1620001354x1503070464_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_clo;
V g_heff_2ebuild_2eload_2emadeOfGo(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2enamedGo_24dps(V, V, V);
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo;
V g_heff_2ebuild_2eload_2epartsNamed(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2efiles_2ereadDirectory(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2eload_2etakeUntil_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_entry, 2, 0};

V g_heff_2ebuild_2eload_2etakeUntil(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_rest_243);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_242, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2eload_2etakeUntil_24dps(v_x_240, v_rest_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2enamedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2enamedGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2enamedGo_24dps(V v_taken_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_taken_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_dup(heff_rfield(v_k_243, 3)), MK_INT(1LL)));
    V v_t_246 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_take_field(v_k_243, 0), heff_take_field(v_k_243, 1), heff_take_field(v_k_243, 2), heff_dup(heff_rfield(v_k_243, 3)), v_t_245, heff_take_field(v_k_243, 5), heff_take_field(v_k_243, 6)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V v_t_249 = (g_heff_2ebuild_2eload_2efreeName(v_taken_240, heff_get_n(v_k_243, 3, 7), MK_INT(1LL)));
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_taken_240});
    V t_1 = v_rest_244;
    V t_2 = v_cell_247;
    v_taken_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2enamedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2enamedGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erequiredPlace_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erequiredPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erequiredPlace_entry, 5, 0};

V g_heff_2ebuild_2eload_2erequiredPlace(V v_ps_240, V v_pkgs_241, V v_k_242, V v_h_243, V v_rest_244) {
top: ;
  V v_it_245 = (g_list_2ekeepIf_24s1220809684x843195562(v_h_243, heff_get_n(v_k_242, 6, 7)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_rest_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_it1_246 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 1ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_p_249 = heff_field(v_it1_246, 1);
      V v_ru_24it1_246_24MkPair = heff_take_reuse_n(v_it1_246, 2ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_pkgs_241; V a_1 = v_p_249; HeffT2 r_ = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(a_0, a_1)); heff_drop(v_p_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_q_2413 = v_field_2412;
          V v_src_2414 = heff_take_field(v_q_2413, 2);
          V v_own_2415 = heff_take_field(v_q_2413, 3);
          V v_top_2416 = heff_get_n(v_q_2413, 4, 7);
          V v_base_2417 = v_src_2414;
          V v_m_2418 = heff_strAppend(v_own_2415, heff_dup(v_rest_244));
          V v_xs_2419 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str0); V a_1 = v_m_2418; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2erequiredPlace_str1), v_m_2418, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2418); r_; });
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
          V v_parts_2424;
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it_245_24Cons, 2);
            v_parts_2424 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2421 = heff_field(v_t_2420, 0);
            V v_before_2422 = heff_field(v_t_2420, 1);
            heff_take_n(v_t_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2421, ((V)&g_heff_2ebuild_2eload_2erequiredPlace_str2)), NTAG(TAG_Nil)});
            v_parts_2424 = (g_list_2efoldl_24s1370882877x364361272(v_t_2423, v_before_2422));
            break;
          }
          default: heff_nomatch(v_t_2420);
          }
          V v_t_2431 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2erequiredPlace_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2417), v_parts_2424));
          V v_t_2432 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2431, v_base_2417, v_parts_2424, heff_strAppend(v_top_2416, v_rest_244)});
          return heff_tag_at_n(v_ru_24it1_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24it_245_24Cons, 2);
          heff_drop_cell(v_ru_24it1_246_24MkPair, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2eload_2erequiredPlace(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2erequiredPlace_lam0(V self, V *args) {
  V v_d_2425 = args[0];
  V v_p_2426 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2427 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_d_2425));
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_p_2426));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  return ({ V a_0 = v_st_2427; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2430); r_; });
}
V g_heff_2ebuild_2eload_2epartsNamed_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_lam0, 2, 0};
V g_heff_2ebuild_2eload_2epartsNamed_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed(V v_e_240, V v_ev_241, V v_ps_242, V v_d_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ev_241);
    heff_drop_rec(v_ps_242, 6);
    heff_drop(v_d_243);
    return ((V)&g_heff_2ebuild_2eload_2epartsNamed_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_244, 0);
    V v_rest_248 = heff_field(v_x3_244, 1);
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_d_243)));
    V v_c_2410 = (g_heff_2eutil_2efiles_2ereadDirectory(heff_dup(v_e_240), heff_dup(v_ev_241), v_t_249));
    return heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_lam1, 2, 7, (V[]){v_c_2410, heff_dup(v_x_247), v_ps_242, v_d_243, v_e_240, v_ev_241, heff_dup(v_rest_248)});
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2eload_2epartsNamed(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2eload_2epartsNamed_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2415; V a_1 = v_x_247; V r_ = (g_heff_2ebuild_2eload_2esameButCase(a_0, a_1)); heff_drop(v_n_2415); heff_drop(v_x_247); r_; });
}
V g_heff_2ebuild_2eload_2epartsNamed_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_ps_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_ev_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  V v_hd_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop_rec(v_ps_242, 6);
    heff_drop(v_d_243);
    heff_drop(v_e_240);
    heff_drop(v_ev_241);
    heff_drop(v_rest_248);
    heff_drop(v_hd_2411);
    V f_ = v_k_2412;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_lam3, 1, 1, (V[]){heff_dup(v_x_247)}), v_ns_2414));
    HeffT2 v_t_2417 = ({ V a_0 = heff_dup(v_ps_242); V a_1 = heff_dup(v_d_243); V a_2 = heff_dup(v_x_247); V a_3 = v_t_2416; HeffT2 r_ = (g_heff_2ebuild_2eload_2ecasesIn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        heff_drop(v_x_247);
        heff_drop_rec(v_ps_242, 6);
        heff_drop(v_d_243);
        heff_drop(v_e_240);
        heff_drop(v_ev_241);
        heff_drop(v_rest_248);
        heff_drop(v_hd_2411);
        V v_why_2420 = v_field_2419;
        V f_ = v_k_2412;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2420});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_field_2419);
        V v_st_2421 = heff_dup(heff_rfield(v_ps_242, 5));
        V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2421), v_d_243));
        V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2421), v_x_247));
        V v_t_2424 = (g_std_2epath_2ejoin(v_t_2422, v_t_2423));
        V v_t_2425 = ({ V a_0 = v_st_2421; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2421); heff_drop(v_t_2424); r_; });
        V v_t_2426 = ({ V a_0 = v_e_240; V a_1 = v_ev_241; V a_2 = v_ps_242; V a_3 = v_t_2425; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2eload_2epartsNamed(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_248); r_; });
        V f_ = v_t_2426;
        heff_room[0] = v_hd_2411;
        heff_room[1] = v_k_2412;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_ps_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_ev_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_lam2, 1, 8, (V[]){v_k_2412, v_x_247, v_ps_242, v_d_243, v_e_240, v_ev_241, v_rest_248, v_hd_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

static V g_heff_2ebuild_2eload_2eemptySt_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2eemptySt_st;
static V g_heff_2ebuild_2eload_2eemptySt_init(void) {
  return heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2eload_2eemptySt_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2eemptySt_st)) return g_heff_2ebuild_2eload_2eemptySt_val;
  return heff_global(&g_heff_2ebuild_2eload_2eemptySt_val, &g_heff_2ebuild_2eload_2eemptySt_st, g_heff_2ebuild_2eload_2eemptySt_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epushDone_str0, 3, "lib");
Clo g_heff_2ebuild_2eload_2epushDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epushDone_entry, 8, 0};

V g_heff_2ebuild_2eload_2epushDone(V v_st_240, V v_ps_241, V v_m_242, V v_named_243, V v_path_244, V v_src_245, V v_implicit_246, V v_renames_247) {
top: ;
  HeffT2 v_t_248 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_dup(heff_rfield(v_ps_241, 2)), heff_dup(v_path_244)));
  V v_t_2416;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_rel_2411 = v_field_2410;
      V v_st_2412 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2eload_2epushDone_str0)));
      V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_rel_2411));
      V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
      v_t_2416 = ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
    } else {
      heff_drop(v_field_2410);
      v_t_2416 = heff_dup(v_path_244);
    }
  }
  HeffT2 v_t_2417 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_241), heff_get_n(v_ps_241, 2, 6), heff_dup(v_path_244)));
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    v_t_2421 = heff_bool(((v_tag_2418 == ((int64_t)0ULL)) && ({ V v_x_2420 = heff_dup(v_field_2419); int c_ = 1; heff_drop(v_x_2420); c_; })));
    heff_drop(v_field_2419);
  }
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_242), v_named_243, v_path_244, v_t_2416, v_src_245, v_renames_247, v_implicit_246, v_t_2421}), NTAG(TAG_Nil)});
  V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_st_240, 0), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_242, heff_take_field(v_st_240, 1)});
  return ({ V rv_0 = v_t_2423; V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_st_240, 4ULL, 3, shape_done__doneMods__errors, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epushDone(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_entry, 9, 0};

V g_heff_2ebuild_2eload_2emadeOfGo(V v_e_240, V v_ev_241, V v_read_242, V v_ps_243, V v_pkgs_244, V v_from_245, V v_before_246, V v_x6_247, V v_st_248) {
top: ;
  switch (heff_tag_of(v_x6_247)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ev_241);
    heff_drop(v_read_242);
    heff_drop(v_ps_243);
    heff_drop(v_pkgs_244);
    heff_drop(v_from_245);
    heff_drop(v_before_246);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_lam0, 2, 1, (V[]){v_st_248});
  }
  case TAG_Cons: {
    V v_m_2411 = heff_field(v_x6_247, 0);
    V v_ms_2412 = heff_field(v_x6_247, 1);
    V v_ru_24x6_247_24Cons = heff_take_reuse_n(v_x6_247, 3ULL, 2);
    V v_t_2413 = heff_tag_at_n(v_ru_24x6_247_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_2411), NTAG(TAG_Nil)});
    V v_c_2414 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(heff_dup(v_before_246), heff_dup(v_e_240), heff_dup(v_ev_241), heff_dup(v_read_242), heff_dup(v_ps_243), heff_dup(v_pkgs_244), NTAG(TAG_Nil), heff_dup(v_from_245), v_t_2413, v_st_248, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_lam1, 2, 10, (V[]){v_c_2414, v_m_2411, v_before_246, v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_from_245, v_ms_2412});
  }
  default: return heff_nomatch(v_x6_247);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_st_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_before_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_ev_241 = heff_env(self)[3];
  V v_read_242 = heff_env(self)[4];
  V v_ps_243 = heff_env(self)[5];
  V v_pkgs_244 = heff_env(self)[6];
  V v_from_245 = heff_env(self)[7];
  V v_ms_2412 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_k_2416 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2411, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_before_246, v_t_2418));
  V v_t_2422;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 2);
    v_t_2422 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2423 = (g_heff_2ebuild_2eload_2emadeOfGo(v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_from_245, v_t_2419, v_ms_2412, v_t_2422));
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_m_2411 = heff_env(self)[1];
  V v_before_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_ev_241 = heff_env(self)[4];
  V v_read_242 = heff_env(self)[5];
  V v_ps_243 = heff_env(self)[6];
  V v_pkgs_244 = heff_env(self)[7];
  V v_from_245 = heff_env(self)[8];
  V v_ms_2412 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_lam2, 1, 11, (V[]){v_m_2411, v_before_246, v_e_240, v_ev_241, v_read_242, v_ps_243, v_pkgs_244, v_from_245, v_ms_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str3, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str4, 3, "lib");
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_d_242)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam3, 2, 4, (V[]){v_c_2424, v_d_242, v_h_240, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_start_241 = heff_env(self)[2];
  V v_hd_2425 = heff_env(self)[3];
  V v_k_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    if (heff_strEq_c_lent(v_d_242, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str1), 2)) {
      heff_drop(v_d_242);
      V v_st_2429 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2430 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2429), heff_dup(heff_rfield(v_h_240, 2))));
      V v_t_2440;
      {
        V v_field_2431 = v_t_2430.f[0];
        V v_field_2432 = v_t_2430.f[1];
        V v_field_2433 = v_t_2430.f[2];
        V v_d_2434 = v_field_2431;
        V v_a_2435 = v_field_2432;
        V v_xs_2436 = v_field_2433;
        V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2436));
        V v_xs_2438 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2437; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2437); r_; });
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2438));
        v_t_2440 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2434, v_a_2435, v_t_2439});
      }
      V v_t_2441 = ({ V a_0 = v_st_2429; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2429); heff_drop(v_t_2440); r_; });
      V v_t_2442 = (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_start_241, v_t_2441));
      V f_ = v_t_2442;
      heff_room[0] = v_hd_2425;
      heff_room[1] = v_k_2426;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_st_2443 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2444 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2443), heff_dup(v_d_242)));
      V v_t_2454;
      {
        V v_field_2445 = v_t_2444.f[0];
        V v_field_2446 = v_t_2444.f[1];
        V v_field_2447 = v_t_2444.f[2];
        V v_d_2448 = v_field_2445;
        V v_a_2449 = v_field_2446;
        V v_xs_2450 = v_field_2447;
        V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2450));
        V v_xs_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2451); r_; });
        V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
        v_t_2454 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2448, v_a_2449, v_t_2453});
      }
      V v_t_2455 = ({ V a_0 = v_st_2443; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2443); heff_drop(v_t_2454); r_; });
      if (heff_strEq_c_lent(v_t_2455, v_d_242, 1)) {
        heff_drop(v_d_242);
        heff_drop(v_hd_2425);
        V v_t_2456 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
        V f_ = v_k_2426;
        args[0] = v_t_2456;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        V v_st_2457 = heff_dup(heff_rfield(v_h_240, 3));
        HeffT3 v_t_2458 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2457), v_d_242));
        V v_t_2468;
        {
          V v_field_2459 = v_t_2458.f[0];
          V v_field_2460 = v_t_2458.f[1];
          V v_field_2461 = v_t_2458.f[2];
          V v_d_2462 = v_field_2459;
          V v_a_2463 = v_field_2460;
          V v_xs_2464 = v_field_2461;
          V v_t_2465 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2464));
          V v_xs_2466 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2465; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2465); r_; });
          V v_t_2467 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2466));
          v_t_2468 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2462, v_a_2463, v_t_2467});
        }
        V v_t_2469 = ({ V a_0 = v_st_2457; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2457); heff_drop(v_t_2468); r_; });
        V v_t_2470 = (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_start_241, v_t_2469));
        V f_ = v_t_2470;
        heff_room[0] = v_hd_2425;
        heff_room[1] = v_k_2426;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_Right: {
    V v_y_2471 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop(v_start_241);
    heff_drop(v_hd_2425);
    V v_st_2472 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_2473 = (g_std_2epath_2eparse(heff_dup(v_st_2472), heff_dup(v_d_242)));
    V v_t_2474 = (g_std_2epath_2eparse(heff_dup(v_st_2472), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str2)));
    V v_t_2475 = (g_std_2epath_2ejoin(v_t_2473, v_t_2474));
    V v_t_2476 = ({ V a_0 = v_st_2472; V a_1 = v_t_2475; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2472); heff_drop(v_t_2475); r_; });
    V v_h_2477 = heff_dup(v_h_240);
    V v_d_2478 = heff_dup(v_d_242);
    HeffT2 v_t_2479 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2471));
    V v_x3_2484;
    {
      V v_field_2481 = v_t_2479.f[1];
      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
      if ((v_tag_2480 == ((int64_t)0ULL))) {
        V v_p_2482 = v_field_2481;
        v_x3_2484 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Left, 1, (V[]){v_p_2482});
      } else {
        heff_drop_cell(v_ru_24x_2427_24Right, 1);
        V v_x_2483 = v_field_2481;
        v_x3_2484 = ({ V a_0 = v_x_2483; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2483); r_; });
      }
    }
    V v_t_2498;
    switch (heff_tag_of(v_x3_2484)) {
    case TAG_Left: {
      heff_take_n(v_x3_2484, 0ULL, 1);
      heff_drop(v_d_2478);
      v_t_2498 = heff_get_n(v_h_2477, 0, 5);
      break;
    }
    case TAG_Right: {
      V v_pk_2486 = heff_field(v_x3_2484, 0);
      heff_take_n(v_x3_2484, 1ULL, 1);
      if (heff_strEq_c(heff_get_n(v_pk_2486, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        V v_t_2487 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_2477), heff_dup(v_d_2478)));
        if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
          heff_drop(v_t_2487);
          V v_st_2488 = heff_dup(heff_rfield(v_h_2477, 3));
          V v_t_2489 = (g_std_2epath_2eparse(heff_dup(v_st_2488), heff_dup(v_d_2478)));
          V v_t_2490 = (g_std_2epath_2eparse(heff_dup(v_st_2488), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str3)));
          V v_t_2491 = (g_std_2epath_2ejoin(v_t_2489, v_t_2490));
          V v_t_2492 = ({ V a_0 = v_st_2488; V a_1 = v_t_2491; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2488); heff_drop(v_t_2491); r_; });
          V v_x1_2493 = (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_2477), heff_dup(heff_rfield(v_h_2477, 0)), v_t_2492));
          if (!(heff_dup(v_x1_2493) == NTAG(TAG_True))) {
            heff_drop(v_x1_2493);
            V v_st_2494 = heff_get_n(v_h_2477, 3, 5);
            V v_t_2495 = (g_std_2epath_2eparse(heff_dup(v_st_2494), v_d_2478));
            V v_t_2496 = (g_std_2epath_2eparse(heff_dup(v_st_2494), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_str4)));
            V v_t_2497 = (g_std_2epath_2ejoin(v_t_2495, v_t_2496));
            v_t_2498 = ({ V a_0 = v_st_2494; V a_1 = v_t_2497; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2494); heff_drop(v_t_2497); r_; });
          } else {
            heff_drop(v_d_2478);
            heff_drop(v_x1_2493);
            v_t_2498 = heff_get_n(v_h_2477, 0, 5);
          }
        } else {
          heff_drop(v_d_2478);
          heff_drop(v_t_2487);
          v_t_2498 = heff_get_n(v_h_2477, 0, 5);
        }
      } else {
        heff_drop(v_d_2478);
        v_t_2498 = heff_get_n(v_h_2477, 0, 5);
      }
      break;
    }
    default: heff_nomatch(v_x3_2484);
    }
    V v_x_2499 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2476, v_t_2498, heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
    V f_ = v_k_2426;
    args[0] = v_x_2499;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_h_240 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_lam4, 1, 5, (V[]){v_d_242, v_h_240, v_start_241, v_hd_2425, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str2, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str6, 16, " is the package ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str7, 6, ", not ");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_dir_241)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam3, 2, 4, (V[]){v_c_2424, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2464;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 0ULL, 1);
    heff_drop(v_path_242);
    V v_st_2429 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_2429), v_dir_241));
    V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2429), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str1)));
    V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
    V v_t_2433 = ({ V a_0 = v_st_2429; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2429); heff_drop(v_t_2432); r_; });
    v_x_2464 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str2))});
    break;
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    HeffT2 v_t_2435 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_y_2434)));
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        heff_drop(v_path_242);
        heff_drop_cell(v_ru_24x_2427_24Right, 1);
        V v_p_2438 = v_field_2437;
        V v_st_2439 = heff_get_n(v_ps_240, 5, 6);
        V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_dir_241));
        V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str3)));
        V v_t_2442 = (g_std_2epath_2ejoin(v_t_2440, v_t_2441));
        V v_t_2443 = ({ V a_0 = v_st_2439; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2442); r_; });
        V v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = v_y_2434; V a_2 = v_p_2438; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2434); r_; });
        v_x_2464 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2444});
      } else {
        V v_x_2445 = v_field_2437;
        HeffT2 v_t_2446 = ({ V a_0 = v_x_2445; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2445); r_; });
        {
          V v_field_2448 = v_t_2446.f[1];
          int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
          if ((v_tag_2447 == ((int64_t)0ULL))) {
            heff_drop(v_path_242);
            heff_drop_cell(v_ru_24x_2427_24Right, 1);
            V v_p_2449 = v_field_2448;
            V v_st_2450 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_dir_241));
            V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str4)));
            V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
            V v_t_2454 = ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
            V v_t_2455 = ({ V a_0 = v_t_2454; V a_1 = v_y_2434; V a_2 = v_p_2449; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2434); r_; });
            v_x_2464 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2455});
          } else {
            heff_drop(v_y_2434);
            V v_pk_2456 = v_field_2448;
            if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2456, 0)), heff_dup(v_path_242))) {
              heff_drop_rec(v_ps_240, 6);
              heff_drop(v_dir_241);
              heff_drop(v_path_242);
              v_x_2464 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Right, 1, (V[]){v_pk_2456});
            } else {
              heff_drop_cell(v_ru_24x_2427_24Right, 1);
              V v_st_2457 = heff_get_n(v_ps_240, 5, 6);
              V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2457), v_dir_241));
              V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_2457), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str5)));
              V v_t_2460 = (g_std_2epath_2ejoin(v_t_2458, v_t_2459));
              V v_t_2461 = ({ V a_0 = v_st_2457; V a_1 = v_t_2460; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2457); heff_drop(v_t_2460); r_; });
              V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2461, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str6)), heff_get_n(v_pk_2456, 0, 4));
              V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_str7)), v_path_242);
              v_x_2464 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2463});
            }
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_2426;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_lam4, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str1, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str3, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str4, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str6, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str8, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str9, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str10, 20, ", and heff.sum says ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_require_246 = heff_take_field(v_root_241, 2);
  V v_replace_247 = heff_get_n(v_root_241, 3, 4);
  V v_t_248 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_244, v_require_246));
  V v_t_2414;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_replace_247);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 2);
    V v_t_2411 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_249, v_replace_247));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_s_2416 = heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str0));
    V v_path_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2416));
    V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2417; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2417); r_; });
    V v_a_2420 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0_clo)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_c_2433 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1_clo)));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam3, 2, 6, (V[]){v_c_2433, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2464 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_d_2465 = heff_dup(heff_rfield(v_ps_240, 0));
    V v_st_2466 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2467 = (g_std_2epath_2eparse(heff_dup(v_st_2466), v_d_2465));
    V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_2466), v_d_2464));
    V v_t_2469 = (g_std_2epath_2ejoin(v_t_2467, v_t_2468));
    V v_t_2470 = ({ V a_0 = v_st_2466; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2466); heff_drop(v_t_2469); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2470, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam2(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_err_2428 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2428})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2429));
  }
  case TAG_Right: {
    V v_x_2430 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam2, 2, 1, (V[]){v_x_2430});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2434 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 0ULL, 1);
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2434);
    V v_t_2438 = heff_strAppend(heff_strAppend(v_by_243, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str1)), v_path_244);
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str2)), v_v_245);
    V v_t_2440 = heff_tag_at_n(v_ru_24x_2436_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str3))});
    V f_ = v_k_2435;
    args[0] = v_t_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Right = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2442 = (g_list_2ekeepIf_24s25507577x707942422(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2434);
      heff_drop(v_y_2441);
      heff_drop_cell(v_ru_24x_2436_24Right, 1);
      V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str4), v_path_244), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str5));
      V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2443, v_v_245), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str6));
      V f_ = v_k_2435;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2444});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_s_2445 = heff_field(v_t_2442, 0);
      heff_take_n(v_t_2442, 1ULL, 2);
      V v_want_2447 = heff_get_n(v_s_2445, 2, 3);
      V v_t_2448 = (g_prelude_2eskipSpaces(v_y_2441, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2449 = (heff_unbox_word(heff_strLength_lent(v_y_2441, 0)) - ((int64_t)1ULL));
      V v_t_2450 = (g_prelude_2eskipSpaces(v_y_2441, heff_box_word(v_t_2449), MK_INT(-1LL)));
      V v_t_2451 = heff_strSlice(heff_dup(v_y_2441), v_t_2448, heff_intAdd(v_t_2450, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2451, v_want_2447, 1)) {
        heff_drop(v_y_2441);
        heff_drop_cell(v_ru_24x_2436_24Right, 1);
        heff_drop(v_want_2447);
        V v_t_2452 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2453 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_240, v_t_2452, v_path_244));
        V f_ = v_t_2453;
        heff_room[0] = v_hd_2434;
        heff_room[1] = v_k_2435;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2434);
        V v_t_2454 = heff_strAppend(heff_strAppend(heff_dup(v_path_244), ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str7)), heff_dup(v_v_245));
        V v_t_2455 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, v_path_244, v_v_245));
        V v_t_2456 = heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str8)), v_t_2455);
        V v_t_2457 = (g_prelude_2eskipSpaces(v_y_2441, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2458 = (heff_unbox_word(heff_strLength_lent(v_y_2441, 0)) - ((int64_t)1ULL));
        V v_t_2459 = (g_prelude_2eskipSpaces(v_y_2441, heff_box_word(v_t_2458), MK_INT(-1LL)));
        V v_t_2460 = heff_strSlice(v_y_2441, v_t_2457, heff_intAdd(v_t_2459, MK_INT(1LL)));
        V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str9)), v_t_2460);
        V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2461, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_str10)), v_want_2447);
        V v_x_2463 = heff_tag_at_n(v_ru_24x_2436_24Right, TAG_Left, 1, (V[]){v_t_2462});
        V f_ = v_k_2435;
        args[0] = v_x_2463;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_lam4, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2435, v_sums_242, v_ps_240, v_hd_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str7, 24, " cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str10, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str11, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam7(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam7, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam12(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam5(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry, 2, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V v_ps_240, V v_src_241) {
top: ;
  V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_src_241)));
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_c_2429 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1, 3, 1, (V[]){v_path_242})));
  return heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam5, 2, 3, (V[]){v_c_2429, v_src_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2420));
  return (g_std_2epath_2ejoin(v_path_242, v_t_2421));
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_2418 = args[1];
  V v_z_2419 = args[2];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2418);
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam3, 1, 1, (V[]){v_path_242}), v_x_2417));
  V v_x_2423 = (g_list_2emap_24s219049803x1458391381(v_x_2422));
  V f_ = v_z_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2425));
  return (g_std_2epath_2ejoin(v_path_242, v_t_2426));
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_2413 = args[1];
  V v_z_2414 = args[2];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2416, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam2, 3, 1, (V[]){v_path_242}), v_z_2413, v_z_2414));
  }
  case TAG_Right: {
    V v_x_2424 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_z_2413);
    V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam4, 1, 1, (V[]){v_path_242}), v_x_2424));
    V v_x_2428 = (g_list_2emap_24s219049803x1458391381(v_x_2427));
    V f_ = v_z_2414;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam7(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam10(V self, V *args) {
  V v_n_2468 = args[0];
  V v_path_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2468));
  return (g_std_2epath_2ejoin(v_path_2450, v_t_2469));
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam9(V self, V *args) {
  V v_x_2465 = args[0];
  V v_z_2466 = args[1];
  V v_z_2467 = args[2];
  V v_path_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2466);
  V v_x_2470 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam10, 1, 1, (V[]){v_path_2450}), v_x_2465));
  V v_x_2471 = (g_list_2emap_24s219049803x1458391381(v_x_2470));
  V f_ = v_z_2467;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2471});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam11(V self, V *args) {
  V v_n_2473 = args[0];
  V v_path_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2473));
  return (g_std_2epath_2ejoin(v_path_2450, v_t_2474));
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_z_2461 = args[1];
  V v_z_2462 = args[2];
  V v_path_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Left: {
    V v_err_2463 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Left = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    V v_t_2464 = heff_tag_at_n(v_ru_24x_2460_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2463})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2464, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam9, 3, 1, (V[]){v_path_2450}), v_z_2461, v_z_2462));
  }
  case TAG_Right: {
    V v_x_2472 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    heff_drop(v_z_2461);
    V v_x_2475 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam11, 1, 1, (V[]){v_path_2450}), v_x_2472));
    V v_x_2476 = (g_list_2emap_24s219049803x1458391381(v_x_2475));
    V f_ = v_z_2462;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2476});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam12(V self, V *args) {
  V v_x_2478 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2478)) {
  case TAG_Left: {
    V v_ru_24x_2478_24Left = heff_take_reuse_n(v_x_2478, 0ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    V v_t_2480 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str5)), v_x_2443);
    V v_t_2481 = heff_tag_at_n(v_ru_24x_2478_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str6))});
    V f_ = v_k_2431;
    args[0] = v_t_2481;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_ru_24x_2478_24Right = heff_take_reuse_n(v_x_2478, 0ULL, 1);
    V v_st_2483 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2484 = (g_std_2epath_2eparse(heff_dup(v_st_2483), v_src_241));
    V v_t_2485 = (g_std_2epath_2eparse(heff_dup(v_st_2483), heff_dup(v_x_2443)));
    V v_t_2486 = (g_std_2epath_2ejoin(v_t_2484, v_t_2485));
    V v_dir_2487 = ({ V a_0 = v_st_2483; V a_1 = v_t_2486; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2483); heff_drop(v_t_2486); r_; });
    HeffT2 v_t_2488 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_2443));
    {
      V v_field_2490 = v_t_2488.f[1];
      int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
      V v_t_2493;
      if ((v_tag_2489 == ((int64_t)0ULL))) {
        heff_drop(v_x_2443);
        heff_drop_cell(v_ru_24x_2478_24Right, 1);
        V v_why_2491 = v_field_2490;
        V v_t_2492 = heff_strAppend(heff_strAppend(v_dir_2487, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str7)), v_why_2491);
        v_t_2493 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2492});
      } else {
        heff_drop(v_dir_2487);
        heff_drop(v_field_2490);
        v_t_2493 = heff_tag_at_n(v_ru_24x_2478_24Right, TAG_Right, 1, (V[]){v_x_2443});
      }
      V f_ = v_k_2431;
      args[0] = v_t_2493;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2478);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 0ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2430);
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2432_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str0))});
    V f_ = v_k_2431;
    args[0] = v_t_2434;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Right = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    switch (heff_tag_of(v_y_2435)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2430);
      V v_t_2438;
      switch (heff_tag_of(v_y_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_y_2435, 0);
        V v_xs_2437 = heff_field(v_y_2435, 1);
        heff_take_n(v_y_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str2); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_y_2435);
      }
      V v_t_2439 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str3)), v_t_2438);
      V v_x_2440 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str4))});
      V f_ = v_k_2431;
      args[0] = v_x_2440;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_it12_2442 = heff_dup(heff_field(v_y_2435, 1));
      switch (heff_tag_of(v_it12_2442)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_y_2435)) {
        case TAG_Cons: {
          V v_x_2443 = heff_field(v_y_2435, 0);
          V v_ru_24y_2435_24Cons = heff_take_reuse_n(v_y_2435, 1ULL, 2);
          V v_st_2445 = heff_dup(heff_rfield(v_ps_240, 5));
          V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2445), heff_dup(v_src_241)));
          V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2445), heff_dup(v_x_2443)));
          V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
          V v_s_2449 = ({ V a_0 = v_st_2445; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2445); heff_drop(v_t_2448); r_; });
          V v_path_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2449));
          V v_t_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2450; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
          V v_a_2453 = heff_tag_at_n(v_ru_24y_2435_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_2451, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam7_clo)});
          V v_t_2454 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2453})});
          V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
          V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
          V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
          V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
          V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
          V v_c_2477 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam8, 3, 1, (V[]){v_path_2450})));
          V f_ = v_c_2477;
          heff_room[0] = v_hd_2430;
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam12, 1, 4, (V[]){v_src_241, v_x_2443, v_k_2431, v_ps_240});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_y_2435);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2442, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_2430);
        V v_t_2498;
        switch (heff_tag_of(v_y_2435)) {
        case TAG_Nil: {
          v_t_2498 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2496 = heff_field(v_y_2435, 0);
          V v_xs_2497 = heff_field(v_y_2435, 1);
          heff_take_n(v_y_2435, 3ULL, 2);
          v_t_2498 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str9); V a_1 = v_x_2496; V a_2 = v_xs_2497; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2497); r_; });
          break;
        }
        default: heff_nomatch(v_y_2435);
        }
        V v_t_2499 = heff_strAppend(heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str10)), v_t_2498);
        V v_x_24100 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2499, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_str11))});
        V f_ = v_k_2431;
        args[0] = v_x_24100;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2442);
      }
    }
    default: return heff_nomatch(v_y_2435);
    }
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_lam6, 1, 4, (V[]){v_src_241, v_k_2431, v_ps_240, v_hd_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x31_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s966012270x790786344(heff_dup(v_ps_240), heff_dup(v_root_241), v_x31_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    V f_ = v_t_2418;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    V f_ = v_t_2422;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0, 2, 3, (V[]){v_c_242, v_root_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_seen_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2417; V a_1 = v_seen_2415; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_2415); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_x_2420, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2426;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2424 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2426 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2429;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2432;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_field(v_x_2420, 1);
    heff_take_n(v_x_2420, 2ULL, 2);
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2432));
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2433));
  V v_x_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_t_2434});
  V f_ = v_k_244;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_x_2412, 0));
    v_seen_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2416 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_2415)));
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam3, 1, 1, (V[]){v_seen_2415}), v_t_2416));
  V v_c_2419 = (g_heff_2ebuild_2eload_2epkgsOf_24s773700013x589897303(v_ps_240, v_root_241, v_t_2418, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam4, 1, 3, (V[]){v_x_245, v_x_2412, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_249;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str0))) {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_str1);
  } else {
    v_t_249 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2410 = (g_list_2emap_24s675147852x248982264(v_t_249, heff_dup(heff_rfield(v_root_241, 2))));
  V v_c_2411 = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248, heff_rfield(v_root_241, 0), v_t_2410, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341_lam1, 1, 4, (V[]){v_root_241, v_ps_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str9, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str10, 30, "packages require one another: ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str16, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str17, 30, "packages require one another: ");
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam9(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam9, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam12(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam13(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam15(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam15, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam18(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam17(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam19(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam16(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam20(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam14(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry, 2, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s1817780530x403680341(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1, 2, 3, (V[]){v_c_248, v_ps_240, v_root_247});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2430));
  return (g_std_2epath_2ejoin(v_path_2412, v_t_2431));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_2428 = args[1];
  V v_z_2429 = args[2];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2428);
  V v_x_2432 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam6, 1, 1, (V[]){v_path_2412}), v_x_2427));
  V v_x_2433 = (g_list_2emap_24s219049803x1458391381(v_x_2432));
  V f_ = v_z_2429;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam7(V self, V *args) {
  V v_n_2435 = args[0];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2435));
  return (g_std_2epath_2ejoin(v_path_2412, v_t_2436));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_2423 = args[1];
  V v_z_2424 = args[2];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2425})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2426, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam5, 3, 1, (V[]){v_path_2412}), v_z_2423, v_z_2424));
  }
  case TAG_Right: {
    V v_x_2434 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    heff_drop(v_z_2423);
    V v_x_2437 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam7, 1, 1, (V[]){v_path_2412}), v_x_2434));
    V v_x_2438 = (g_list_2emap_24s219049803x1458391381(v_x_2437));
    V f_ = v_z_2424;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam9(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam12(V self, V *args) {
  V v_n_2463 = args[0];
  V v_path_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2463));
  return (g_std_2epath_2ejoin(v_path_2445, v_t_2464));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_z_2461 = args[1];
  V v_z_2462 = args[2];
  V v_path_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2461);
  V v_x_2465 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam12, 1, 1, (V[]){v_path_2445}), v_x_2460));
  V v_x_2466 = (g_list_2emap_24s219049803x1458391381(v_x_2465));
  V f_ = v_z_2462;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2466});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam13(V self, V *args) {
  V v_n_2468 = args[0];
  V v_path_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2468));
  return (g_std_2epath_2ejoin(v_path_2445, v_t_2469));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_z_2456 = args[1];
  V v_z_2457 = args[2];
  V v_path_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    V v_err_2458 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Left = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    V v_t_2459 = heff_tag_at_n(v_ru_24x_2455_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2458})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2459, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam11, 3, 1, (V[]){v_path_2445}), v_z_2456, v_z_2457));
  }
  case TAG_Right: {
    V v_x_2467 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    heff_drop(v_z_2456);
    V v_x_2470 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam13, 1, 1, (V[]){v_path_2445}), v_x_2467));
    V v_x_2471 = (g_list_2emap_24s219049803x1458391381(v_x_2470));
    V f_ = v_z_2457;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2471});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam15(V self, V *args) {
  V v_r_2480 = args[0];
  return v_r_2480;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam18(V self, V *args) {
  V v_n_2496 = args[0];
  V v_path_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2496));
  return (g_std_2epath_2ejoin(v_path_2478, v_t_2497));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam17(V self, V *args) {
  V v_x_2493 = args[0];
  V v_z_2494 = args[1];
  V v_z_2495 = args[2];
  V v_path_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2494);
  V v_x_2498 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam18, 1, 1, (V[]){v_path_2478}), v_x_2493));
  V v_x_2499 = (g_list_2emap_24s219049803x1458391381(v_x_2498));
  V f_ = v_z_2495;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2499});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam19(V self, V *args) {
  V v_n_24101 = args[0];
  V v_path_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_24101));
  return (g_std_2epath_2ejoin(v_path_2478, v_t_24102));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_z_2489 = args[1];
  V v_z_2490 = args[2];
  V v_path_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Left: {
    V v_err_2491 = heff_field(v_x_2488, 0);
    V v_ru_24x_2488_24Left = heff_take_reuse_n(v_x_2488, 1ULL, 1);
    V v_t_2492 = heff_tag_at_n(v_ru_24x_2488_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2491})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2492, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam17, 3, 1, (V[]){v_path_2478}), v_z_2489, v_z_2490));
  }
  case TAG_Right: {
    V v_x_24100 = heff_field(v_x_2488, 0);
    heff_take_n(v_x_2488, 1ULL, 1);
    heff_drop(v_z_2489);
    V v_x_24103 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam19, 1, 1, (V[]){v_path_2478}), v_x_24100));
    V v_x_24104 = (g_list_2emap_24s219049803x1458391381(v_x_24103));
    V f_ = v_z_2490;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24104});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2488);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam20(V self, V *args) {
  V v_x_24106 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2477 = heff_env(self)[2];
  V v_x_2444 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_24106)) {
  case TAG_Left: {
    heff_take_n(v_x_24106, 0ULL, 1);
    V v_t_24108 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_247, 2))));
    V v_t_24109 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str5), heff_dup(heff_rfield(v_root_247, 1)), v_t_24108});
    V v_t_24110 = (g_prelude_2e_2b_2b(v_x_2477, NTAG(TAG_Nil)));
    V v_t_24111 = (g_prelude_2e_2b_2b(v_x_2444, v_t_24110));
    V v_t_24114;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_dup(heff_field(v_x_2411, 0));
      v_t_24114 = v_x_24112;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24115 = (g_heff_2ebuild_2eload_2enamedGo(v_t_24111, v_t_24114));
    V v_t_24118;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_y_24117 = heff_dup(heff_field(v_x_2411, 1));
      v_t_24118 = v_y_24117;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24119 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_247, 2)));
    V v_t_24120 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str7), heff_take_field(v_root_247, 1), v_t_24119});
    V v_t_24123;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_x_24121 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 2);
      v_t_24123 = v_x_24121;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
    V v_t_24125 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24120, v_t_24123}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24124; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_24130;
    switch (heff_tag_of(v_t_24125)) {
    case TAG_Nothing: {
      v_t_24130 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_c_24126 = heff_field(v_t_24125, 0);
      heff_take_n(v_t_24125, 1ULL, 1);
      V v_t_24129;
      switch (heff_tag_of(v_c_24126)) {
      case TAG_Nil: {
        v_t_24129 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_24127 = heff_field(v_c_24126, 0);
        V v_xs_24128 = heff_field(v_c_24126, 1);
        heff_take_n(v_c_24126, 3ULL, 2);
        v_t_24129 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str9); V a_1 = v_x_24127; V a_2 = v_xs_24128; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24128); r_; });
        break;
      }
      default: heff_nomatch(v_c_24126);
      }
      v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str10), v_t_24129), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24125);
    }
    V v_t_24131 = (g_prelude_2e_2b_2b(v_t_24118, v_t_24130));
    V v_x_24132 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_t_24115}), v_t_24131});
    V f_ = v_k_2410;
    args[0] = v_x_24132;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_24133 = heff_field(v_x_24106, 0);
    heff_take_n(v_x_24106, 1ULL, 1);
    V v_x_24134 = (g_list_2emap_24s1462590149x1582455373(v_y_24133));
    V v_t_24135 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_247, 2))));
    V v_t_24136 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str11), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str12), heff_dup(heff_rfield(v_root_247, 1)), v_t_24135});
    V v_t_24137 = (g_prelude_2e_2b_2b(v_x_2477, v_x_24134));
    V v_t_24138 = (g_prelude_2e_2b_2b(v_x_2444, v_t_24137));
    V v_t_24141;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_x_24139 = heff_dup(heff_field(v_x_2411, 0));
      v_t_24141 = v_x_24139;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24142 = (g_heff_2ebuild_2eload_2enamedGo(v_t_24138, v_t_24141));
    V v_t_24145;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_y_24144 = heff_dup(heff_field(v_x_2411, 1));
      v_t_24145 = v_y_24144;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24146 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_247, 2)));
    V v_t_24147 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str13), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str14), heff_take_field(v_root_247, 1), v_t_24146});
    V v_t_24150;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_x_24148 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 2);
      v_t_24150 = v_x_24148;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_24151 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
    V v_t_24152 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, v_t_24150}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24151; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_24157;
    switch (heff_tag_of(v_t_24152)) {
    case TAG_Nothing: {
      v_t_24157 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_c_24153 = heff_field(v_t_24152, 0);
      heff_take_n(v_t_24152, 1ULL, 1);
      V v_t_24156;
      switch (heff_tag_of(v_c_24153)) {
      case TAG_Nil: {
        v_t_24156 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_24154 = heff_field(v_c_24153, 0);
        V v_xs_24155 = heff_field(v_c_24153, 1);
        heff_take_n(v_c_24153, 3ULL, 2);
        v_t_24156 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str16); V a_1 = v_x_24154; V a_2 = v_xs_24155; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24155); r_; });
        break;
      }
      default: heff_nomatch(v_c_24153);
      }
      v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_str17), v_t_24156), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24152);
    }
    V v_t_24158 = (g_prelude_2e_2b_2b(v_t_24145, v_t_24157));
    V v_x_24159 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, v_t_24142}), v_t_24158});
    V f_ = v_k_2410;
    args[0] = v_x_24159;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24106);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam14(V self, V *args) {
  V v_x_2473 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2444 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2476;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Left: {
    heff_take_n(v_x_2473, 0ULL, 1);
    v_t_2476 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2475 = heff_field(v_x_2473, 0);
    heff_take_n(v_x_2473, 1ULL, 1);
    v_t_2476 = v_y_2475;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_x_2477 = (g_list_2emap_24s1462590149x1582455373(v_t_2476));
  V v_path_2478 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_240, 2))));
  V v_t_2479 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2478; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2481 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2479, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam15_clo)});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
  V v_c_24105 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam16, 3, 1, (V[]){v_path_2478})));
  V f_ = v_c_24105;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam20, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2477, v_x_2444, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2443;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2442 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    v_t_2443 = v_y_2442;
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_x_2444 = (g_list_2emap_24s1462590149x1582455373(v_t_2443));
  V v_path_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2445; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2448 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam9_clo)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_c_2472 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam10, 3, 1, (V[]){v_path_2445})));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam14, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2444, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_240, 1))));
  V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2415 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam3_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_c_2439 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam4, 3, 1, (V[]){v_path_2412})));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam8, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam6(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam6, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam8(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam8, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam9(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam7(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam7, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam12(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam12, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam14(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam14, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam16(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam15(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam13(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam13, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam17(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam18(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam0, 2, 3, (V[]){v_c_242, v_h_240, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam4(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam6(V self, V *args) {
  V v_a_2434 = args[0];
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam8(V self, V *args) {
  V v_r_2443 = args[0];
  return v_r_2443;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam10(V self, V *args) {
  V v_a_2454 = args[0];
  V v_a_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457;
  switch (heff_tag_of(v_a_2454)) {
  case TAG_Left: {
    heff_take_n(v_a_2454, 0ULL, 1);
    v_t_2457 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_a_2456 = heff_field(v_a_2454, 0);
    V v_ru_24a_2454_24Right = heff_take_reuse_n(v_a_2454, 1ULL, 1);
    v_t_2457 = heff_tag_at_n(v_ru_24a_2454_24Right, TAG_Just, 1, (V[]){v_a_2456});
    break;
  }
  default: heff_nomatch(v_a_2454);
  }
  V f_ = v_a_2453;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam9(V self, V *args) {
  V v_a_2452 = args[0];
  V v_a_2453 = args[1];
  V v_a_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_a_2451;
  args[0] = v_a_2452;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam10, 1, 1, (V[]){v_a_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam7(V self, V *args) {
  V v_a_2440 = args[0];
  V v_a_2441 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_a_2440));
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_2441; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_2441); r_; });
  V v_a_2444 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2442, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam8_clo)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_a_2451 = (g_co_2eop_24s1620001354x1503070464(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam9, 2, 1, (V[]){v_a_2451});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam12(V self, V *args) {
  V v_a_2476 = args[0];
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam14(V self, V *args) {
  V v_r_2485 = args[0];
  return v_r_2485;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam16(V self, V *args) {
  V v_a_2496 = args[0];
  V v_a_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2499;
  switch (heff_tag_of(v_a_2496)) {
  case TAG_Left: {
    heff_take_n(v_a_2496, 0ULL, 1);
    v_t_2499 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_a_2498 = heff_field(v_a_2496, 0);
    V v_ru_24a_2496_24Right = heff_take_reuse_n(v_a_2496, 1ULL, 1);
    v_t_2499 = heff_tag_at_n(v_ru_24a_2496_24Right, TAG_Just, 1, (V[]){v_a_2498});
    break;
  }
  default: heff_nomatch(v_a_2496);
  }
  V f_ = v_a_2495;
  args[0] = v_t_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam15(V self, V *args) {
  V v_a_2494 = args[0];
  V v_a_2495 = args[1];
  V v_a_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_a_2493;
  args[0] = v_a_2494;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam16, 1, 1, (V[]){v_a_2495});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam13(V self, V *args) {
  V v_a_2482 = args[0];
  V v_a_2483 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_a_2482));
  V v_t_2484 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_2483; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_2483); r_; });
  V v_a_2486 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2484, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam14_clo)});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  V v_a_2493 = (g_co_2eop_24s1620001354x1503070464(heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam15, 2, 1, (V[]){v_a_2493});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam17(V self, V *args) {
  V v_m_24100 = args[0];
  V v_made_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24101 = ({ V a_0 = v_m_24100; V a_1 = v_made_2460; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_24100); heff_drop(v_made_2460); r_; });
  {
    V v_field_24103 = v_t_24101.f[1];
    int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
    if ((v_tag_24102 == ((int64_t)0ULL))) {
      V v_s_24104 = v_field_24103;
      return heff_get_n(v_s_24104, 6, 8);
    } else {
      heff_drop(v_field_24103);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam18(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2460 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24109;
  switch (heff_tag_of(v_x_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_dup(heff_field(v_x_24106, 0));
    v_t_24109 = v_x_24107;
    break;
  }
  default: heff_nomatch(v_x_24106);
  }
  V v_t_24110 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_24111 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_24112 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_24113 = ({ V a_0 = v_m_24112; V a_1 = v_made_2460; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_24112); heff_drop(v_made_2460); r_; });
  V v_t_24117;
  {
    V v_field_24115 = v_t_24113.f[1];
    int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
    if ((v_tag_24114 == ((int64_t)0ULL))) {
      V v_s_24116 = v_field_24115;
      v_t_24117 = heff_get_n(v_s_24116, 6, 8);
    } else {
      heff_drop(v_field_24115);
      v_t_24117 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_24120;
  switch (heff_tag_of(v_x_24106)) {
  case TAG_MkPair: {
    V v_y_24119 = heff_field(v_x_24106, 1);
    heff_take_n(v_x_24106, 2ULL, 2);
    v_t_24120 = v_y_24119;
    break;
  }
  default: heff_nomatch(v_x_24106);
  }
  V v_t_24121 = (g_heff_2ebuild_2eload_2epushDone(v_t_24109, heff_dup(v_x_245), v_t_24110, v_t_24111, v_file_241, v_a_2430, v_t_24117, v_t_24120));
  V v_x_24122 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_24121; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_24122;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_made_2460 = heff_get_n(v_x_2459, 0, 3);
  V v_t_2463;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2463 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2464 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
  V v_m_2466 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2467 = ({ V a_0 = v_m_2466; V a_1 = v_made_2460; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2466); r_; });
  V v_t_2471;
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    if ((v_tag_2468 == ((int64_t)0ULL))) {
      V v_s_2470 = v_field_2469;
      v_t_2471 = heff_get_n(v_s_2470, 6, 8);
    } else {
      heff_drop(v_field_2469);
      v_t_2471 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2472 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2471, heff_dup(v_a_2430)));
  V v_imps_2473 = heff_get_n(v_t_2472, 0, 4);
  V v_t_2474 = (g_list_2emap_24s1817208647x1282894070(v_imps_2473));
  V v_t_2475 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2474));
  V v_c_24105 = (g_heff_2ebuild_2eload_2eloadMany(heff_dup(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get()), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam12_clo), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam13_clo), heff_dup(v_x_245), v_t_2463, v_t_2465, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam17, 1, 1, (V[]){heff_dup(v_made_2460)}), v_t_2475, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_24105;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam18, 1, 7, (V[]){v_x_245, v_file_241, v_made_2460, v_a_2430, v_x_247, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam5(V self, V *args) {
  V v_a_2425 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_a_2425)) {
  case TAG_Left: {
    heff_take_n(v_a_2425, 0ULL, 1);
    heff_drop(v_hd_243);
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2428 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2427});
    V v_x_2429 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2428; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_a_2430 = heff_field(v_a_2425, 0);
    heff_take_n(v_a_2425, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2433 = v_x_2431;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2458 = (g_heff_2ebuild_2eload_2emadeOfGo(heff_dup(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get()), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam6_clo), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam7_clo), heff_dup(v_x_245), v_t_2433, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2458;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam11, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_a_2430, v_hd_243, v_x_247, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_a_2425);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_a_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_file_241)));
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_2414); r_; });
  V v_a_2417 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam4_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_a_2424 = (g_co_2eop_24s1620001354x1503070464(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})));
  V f_ = v_a_2424;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = (g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(heff_dup(v_x_245), v_t_2411));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(v_h_240, heff_dup(v_x_245)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_lam1, 1, 4, (V[]){v_h_240, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0, 2, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam6(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry, 3, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V v_ps_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    return ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_d_241)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    V v_c_2434 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2, 3, 1, (V[]){v_path_247})));
    return heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam6, 2, 5, (V[]){v_c_2434, v_x_245, v_ps_240, v_d_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam1(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2425));
  return (g_std_2epath_2ejoin(v_path_247, v_t_2426));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_2423 = args[1];
  V v_z_2424 = args[2];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2423);
  V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam4, 1, 1, (V[]){v_path_247}), v_x_2422));
  V v_x_2428 = (g_list_2emap_24s219049803x1458391381(v_x_2427));
  V f_ = v_z_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam5(V self, V *args) {
  V v_n_2430 = args[0];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2430));
  return (g_std_2epath_2ejoin(v_path_247, v_t_2431));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_2418 = args[1];
  V v_z_2419 = args[2];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2420})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2421, heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam3, 3, 1, (V[]){v_path_247}), v_z_2418, v_z_2419));
  }
  case TAG_Right: {
    V v_x_2429 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_z_2418);
    V v_x_2432 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam5, 1, 1, (V[]){v_path_247}), v_x_2429));
    V v_x_2433 = (g_list_2emap_24s219049803x1458391381(v_x_2432));
    V f_ = v_z_2419;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam8(V self, V *args) {
  V v_n_2440 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2440; V a_1 = v_x_245; V r_ = (g_heff_2ebuild_2eload_2esameButCase(a_0, a_1)); heff_drop(v_n_2440); heff_drop(v_x_245); r_; });
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_hd_2435 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    heff_take_n(v_x_2437, 0ULL, 1);
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_hd_2435);
    V f_ = v_k_2436;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2439 = heff_field(v_x_2437, 0);
    heff_take_n(v_x_2437, 1ULL, 1);
    V v_t_2441 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam8, 1, 1, (V[]){heff_dup(v_x_245)}), v_y_2439));
    HeffT2 v_t_2442 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = heff_dup(v_d_241); V a_2 = heff_dup(v_x_245); V a_3 = v_t_2441; HeffT2 r_ = (g_heff_2ebuild_2eload_2ecasesIn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2441); r_; });
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        heff_drop(v_x_245);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_rest_246);
        heff_drop(v_hd_2435);
        V v_why_2445 = v_field_2444;
        V f_ = v_k_2436;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2445});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_field_2444);
        V v_st_2446 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2446), v_d_241));
        V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_2446), v_x_245));
        V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
        V v_t_2450 = ({ V a_0 = v_st_2446; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2446); heff_drop(v_t_2449); r_; });
        V v_t_2451 = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(v_ps_240, v_t_2450, v_rest_246));
        V f_ = v_t_2451;
        heff_room[0] = v_hd_2435;
        heff_room[1] = v_k_2436;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  default: return heff_nomatch(v_x_2437);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_lam7, 1, 6, (V[]){v_k_2436, v_x_245, v_ps_240, v_d_241, v_rest_246, v_hd_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}