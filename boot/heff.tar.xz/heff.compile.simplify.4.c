// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Inlined 13187
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fuel 9649789
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_match 305026527
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2eremember(V, V, V);
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eremember_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2esetOff(V, V);
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetOff_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1049096277x601353451(V);
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2etakeL_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edropL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edropL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2efueled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efueled_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efueled(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_241});
  }
  case TAG_Just: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_p_241, 1)))) {
      V v_t_244 = heff_intSub(heff_take_field(v_p_241, 1), MK_INT(1LL));
      V v_t_245 = ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_nf(v_p_241, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_242, v_t_245));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_x_247}), v_s_248});
      }
      default: return heff_nomatch(v_x2_246);
      }
    } else {
      heff_drop(v_b_242);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_241});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efueled(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), v_safe_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_249 = heff_field(v_e_242, 0);
    V v_as_2410 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_249)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_e1_249, 0);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2412), v_total_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        if (heff_intLe_c(v_t_2415, v_ar_2414)) {
          V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2410)));
          return ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_249);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2454 = heff_field(v_e_242, 0);
    V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2454)));
    return ({ V a_0 = v_t_2459; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2459); r_; });
  }
  case TAG_EProj: {
    V v_e2_2460 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2460;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2465 = heff_field(v_e_242, 1);
    V v_t_2468 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2465)));
    return ({ V a_0 = v_t_2468; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2468); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2469 = heff_field(v_e_242, 0);
    V v_arms_2470 = heff_field(v_e_242, 1);
    V v_t_2471 = (g_heff_2ecompile_2esimplify_2epureIn(v_safe_240, v_total_241, v_sc_2469));
    if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
      heff_drop(v_t_2471);
      switch (heff_tag_of(v_arms_2470)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2479 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_arms_2470)));
        return ({ V a_0 = v_t_2479; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2479); r_; });
      }
      default: return heff_nomatch(v_arms_2470);
      }
    } else {
      heff_drop(v_t_2471);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2481 = heff_field(v_e_242, 0);
    V v_as_2482 = heff_field(v_e_242, 1);
    V v_x1_2483 = ({ V a_0 = heff_dup(v_p_2481); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2483) == NTAG(TAG_True))) {
      heff_drop(v_x1_2483);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2483);
      V v_t_2485 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2482)));
      return ({ V a_0 = v_t_2485; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2485); r_; });
    }
  }
  case TAG_ECall: {
    V v_g_2486 = heff_field(v_e_242, 0);
    V v_as_2487 = heff_field(v_e_242, 1);
    V v_t_2488 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2486), v_total_241));
    switch (heff_tag_of(v_t_2488)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2489 = heff_field(v_t_2488, 0);
      heff_take_n(v_t_2488, 1ULL, 1);
      V v_t_2490 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2487));
      if (heff_intLe_c(v_t_2490, v_ar_2489)) {
        V v_t_2493 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam5, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2487)));
        return ({ V a_0 = v_t_2493; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2493); r_; });
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_2488);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2417; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2417); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2456 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_e2_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2458; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2458); r_; });
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2467 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2467; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2467); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_b_2474 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478;
  switch (heff_tag_of(v_b_2474)) {
  case TAG_MkArm: {
    V v_b_2477 = heff_field(v_b_2474, 2);
    heff_take_n(v_b_2474, 4ULL, 3);
    v_t_2478 = v_b_2477;
    break;
  }
  default: heff_nomatch(v_b_2474);
  }
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_t_2478; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_t_2478); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2484 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2484; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2484); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args) {
  V v_a_2492 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2492; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2492); r_; });
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_x_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      V v_t_247 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop(v_x1_2410);
          V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_x1_2410);
          V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_241), NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_key_241, v_t_2413, heff_get_n(v_acc_240, 1, 2)));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2412, v_t_2414});
        }
      } else {
        heff_drop(v_t_247);
        V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
        return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        if ((heff_dup(v_x1_2419) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2419);
          return v_acc_240;
        } else {
          heff_drop(v_x1_2419);
          V v_t_2420 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
      } else {
        heff_drop(v_key_241);
        heff_drop(v_t_2416);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      if (heff_intLt_c(v_t_248, v_t_249)) {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){heff_take_field(v_s_240, 3), heff_get_n(v_s_240, 5, 9)}));
        V v_t_2412 = (g_list_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      } else {
        heff_drop_rec(v_s_240, 9);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialOf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  if (heff_intEq_c(heff_dup(v_o_244), MK_INT(0LL))) {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243});
  } else {
    V v_t_2440;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_t_2441 = heff_bool(((heff_dup(v_t_2440) == NTAG(TAG_True)) || heff_intEq_c(heff_dup(v_o_244), MK_INT(1LL))));
    heff_drop(v_t_2440);
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_o_244);
      heff_drop(v_t_2441);
      V v_m_2442 = (g_map_2einsert_24s1341440536x470972936(v_x_241, v_a_242, heff_dup(g_map_2eempty_get())));
      V v_t_2443 = (g_map_2esize(v_m_2442));
      V v_t_2445;
      if (heff_intEq_c(v_t_2443, MK_INT(0LL))) {
        heff_drop(v_m_2442);
        v_t_2445 = v_b_243;
      } else {
        v_t_2445 = ({ V a_0 = v_m_2442; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2442); r_; });
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2445});
    } else {
      heff_drop(v_t_2441);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eisValue(v_a_242));
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_x_2448 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2447));
        if (heff_intLt_c(MK_INT(12LL), v_x_2448)) {
          if (heff_intLe_c(v_o_244, MK_INT(4LL))) {
            V v_t_2451 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_242)));
            if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
              heff_drop(v_t_2451);
              V v_m_2452 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam0, 1, 2, (V[]){v_m_2452, v_r_240});
            } else {
              heff_drop(v_t_2451);
              V v_m_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam1, 1, 3, (V[]){v_m_2457, v_x_241, v_a_242});
            }
          } else {
            V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam2, 1, 3, (V[]){v_m_2462, v_x_241, v_a_242});
          }
        } else {
          heff_drop(v_o_244);
          V v_m_2467 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam3, 1, 2, (V[]){v_m_2467, v_r_240});
        }
      } else {
        heff_drop(v_o_244);
        heff_drop(v_t_2446);
        V v_m_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam4, 1, 3, (V[]){v_m_2472, v_x_241, v_a_242});
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args) {
  V v_s_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2453}));
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_MkPair: {
    V v_x_2455 = heff_field(v_x2_2454, 0);
    V v_s_2456 = heff_field(v_x2_2454, 1);
    heff_take_n(v_x2_2454, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2455;
    heff_room[1] = v_s_2456;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2460}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args) {
  V v_s_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2465}), v_s_2466});
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args) {
  V v_s_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_s_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_s_2471 = heff_field(v_x2_2469, 1);
    heff_take_n(v_x2_2469, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2470;
    heff_room[1] = v_s_2471;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args) {
  V v_s_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2475}), v_s_2476});
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
Clo g_heff_2ecompile_2esimplify_2efewerThan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efewerThan_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efewerThan(V v_as_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_240));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      return heff_intLt(v_t_247, v_t_248);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efewerThan(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eeta_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          heff_drop(v_t_2413);
          return v_f_2410;
        } else {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
      } else {
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 4);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eeta(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_g_244});
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_e_241, 0);
    V v_b_2411 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_2411}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_2412, v_xs_2410});
  }
  case TAG_EApp: {
    V v_e1_2420 = heff_field(v_e_241, 0);
    V v_as_2421 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2420)) {
    case TAG_EVar: {
      V v_m_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2423, v_r_240, v_as_2421});
    }
    case TAG_EGlobal: {
      V v_g_2433 = heff_field(v_e1_2420, 0);
      heff_take_n(v_e1_2420, 1ULL, 1);
      V v_m_2435 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam5, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam6, 1, 3, (V[]){v_m_2435, v_r_240, v_g_2433});
    }
    case TAG_ELam: {
      V v_m_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2442, v_r_240, v_as_2421});
    }
    case TAG_EApp: {
      V v_e11_2452 = heff_dup(heff_field(v_e1_2420, 0));
      V v_bs_2453 = heff_dup(heff_field(v_e1_2420, 1));
      switch (heff_tag_of(v_e11_2452)) {
      case TAG_EVar: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2455, v_r_240, v_as_2421});
      }
      case TAG_EGlobal: {
        V v_g_2465 = heff_field(v_e11_2452, 0);
        heff_take_n(v_e11_2452, 1ULL, 1);
        heff_drop_tag(v_e1_2420, 2);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2453, v_g_2465, v_as_2421, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2483, v_r_240, v_as_2421});
      }
      case TAG_EApp: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2495, v_r_240, v_as_2421});
      }
      case TAG_ELet: {
        heff_take_n(v_e11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24108 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24108, v_r_240, v_as_2421});
      }
      case TAG_ERecord: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24120 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24120, v_r_240, v_as_2421});
      }
      case TAG_EProj: {
        heff_take_n(v_e11_2452, 0ULL, 4);
        heff_drop(v_bs_2453);
        V v_m_24134 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24134, v_r_240, v_as_2421});
      }
      case TAG_ETag: {
        heff_take_n(v_e11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24147 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24147, v_r_240, v_as_2421});
      }
      case TAG_EMatch: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24159, v_r_240, v_as_2421});
      }
      case TAG_EPrim: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24170, v_r_240, v_as_2421});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24182, v_r_240, v_as_2421});
      }
      case TAG_ECall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24194 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24194, v_r_240, v_as_2421});
      }
      case TAG_EInt: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24205 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24205, v_r_240, v_as_2421});
      }
      case TAG_EFloat: {
        heff_take_na(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24216 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24216, v_r_240, v_as_2421});
      }
      case TAG_EStr: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24227 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24227, v_r_240, v_as_2421});
      }
      case TAG_EBytes: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24238 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24238, v_r_240, v_as_2421});
      }
      case TAG_EFixed: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24250 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24250, v_r_240, v_as_2421});
      }
      case TAG_EFloat32: {
        heff_take_na(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24261 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24261, v_r_240, v_as_2421});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2453);
        V v_m_24271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24271, v_r_240, v_as_2421});
      }
      case TAG_EFix: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24283 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24283, v_r_240, v_as_2421});
      }
      default: return heff_nomatch(v_e11_2452);
      }
    }
    case TAG_ELet: {
      V v_m_24296 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24296, v_r_240, v_as_2421});
    }
    case TAG_ERecord: {
      V v_m_24308 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24308, v_r_240, v_as_2421});
    }
    case TAG_EProj: {
      V v_m_24322 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24322, v_r_240, v_as_2421});
    }
    case TAG_ETag: {
      V v_m_24335 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24335, v_r_240, v_as_2421});
    }
    case TAG_EMatch: {
      V v_m_24347 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24347, v_r_240, v_as_2421});
    }
    case TAG_EPrim: {
      V v_m_24358 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24358, v_r_240, v_as_2421});
    }
    case TAG_EPrimCall: {
      V v_m_24370 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24370, v_r_240, v_as_2421});
    }
    case TAG_ECall: {
      V v_m_24382 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24382, v_r_240, v_as_2421});
    }
    case TAG_EInt: {
      V v_m_24393 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24393, v_r_240, v_as_2421});
    }
    case TAG_EFloat: {
      V v_m_24404 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24404, v_r_240, v_as_2421});
    }
    case TAG_EStr: {
      V v_m_24415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24415, v_r_240, v_as_2421});
    }
    case TAG_EBytes: {
      V v_m_24426 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24426, v_r_240, v_as_2421});
    }
    case TAG_EFixed: {
      V v_m_24438 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24438, v_r_240, v_as_2421});
    }
    case TAG_EFloat32: {
      V v_m_24449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24449, v_r_240, v_as_2421});
    }
    case TAG_EAbandon: {
      V v_m_24459 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam77, 1, 3, (V[]){v_m_24459, v_r_240, v_as_2421});
    }
    case TAG_EFix: {
      V v_m_24471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2420}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam79, 1, 3, (V[]){v_m_24471, v_r_240, v_as_2421});
    }
    default: return heff_nomatch(v_e1_2420);
    }
  }
  case TAG_ELet: {
    V v_x_24481 = heff_field(v_e_241, 0);
    V v_a_24482 = heff_field(v_e_241, 1);
    V v_b_24483 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24484 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24482}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam81, 1, 4, (V[]){v_m_24484, v_r_240, v_x_24481, v_b_24483});
  }
  case TAG_ERecord: {
    V v_fs_24490 = heff_field(v_e_241, 0);
    V v_ts_24491 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24500 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_r_240}), v_fs_24490));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam84, 1, 2, (V[]){v_m_24500, v_ts_24491});
  }
  case TAG_EProj: {
    V v_e2_24505 = heff_field(v_e_241, 0);
    V v_l_24506 = heff_field(v_e_241, 1);
    V v_sh_24507 = heff_field(v_e_241, 2);
    V v_t_24508 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_24509 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e2_24505}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam85, 1, 5, (V[]){v_m_24509, v_r_240, v_l_24506, v_sh_24507, v_t_24508});
  }
  case TAG_ETag: {
    V v_t_24514 = heff_field(v_e_241, 0);
    V v_as_24515 = heff_field(v_e_241, 1);
    V v_ts_24516 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24518 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam86, 1, 1, (V[]){v_r_240}), v_as_24515));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam87, 1, 3, (V[]){v_m_24518, v_t_24514, v_ts_24516});
  }
  case TAG_EMatch: {
    V v_s_24523 = heff_field(v_e_241, 0);
    V v_arms_24524 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24525 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24523}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam88, 1, 3, (V[]){v_m_24525, v_r_240, v_arms_24524});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam91, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24545 = heff_field(v_e_241, 0);
    V v_as_24546 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24548 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam92, 1, 1, (V[]){v_r_240}), v_as_24546));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam93, 1, 2, (V[]){v_m_24548, v_p_24545});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam95, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam96, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam97, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam98, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam99, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam100, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam101, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam102, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_g_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_s_245, 2)));
  V v_x_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    v_x_249 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_244});
    break;
  }
  case TAG_Just: {
    V v_b_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Just = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    V v_t_248 = (g_heff_2ecompile_2esimplify_2ewordLiteral(v_b_247));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_g_244);
      heff_drop_cell(v_ru_24x2_246_24Just, 1);
      heff_drop(v_t_248);
      v_x_249 = v_b_247;
    } else {
      heff_drop(v_b_247);
      heff_drop(v_t_248);
      v_x_249 = heff_tag_at_n(v_ru_24x2_246_24Just, TAG_EGlobal, 1, (V[]){v_g_244});
    }
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_2416, 7)), 1, 7);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2elam(v_xs_2410, v_x_2415));
    V v_x_2419 = ({ V a_0 = v_t_2417; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2417); r_; });
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2428 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    V v_m_2429 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_2430 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2427}));
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_s_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2426;
      heff_room[1] = v_x_2431;
      heff_room[2] = v_s_2432;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2430);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_a_2434 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2433});
    heff_room[1] = v_x_2438;
    heff_room[2] = v_s_2439;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    heff_take_n(v_x2_2444, 3ULL, 2);
    V v_m_2448 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2445;
      heff_room[1] = v_x_2450;
      heff_room[2] = v_s_2451;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2460 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2458;
      heff_room[1] = v_x_2463;
      heff_room[2] = v_s_2464;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2453 = heff_env(self)[0];
  V v_g_2465 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_2453));
  V v_t_2468 = (g_heff_2ecompile_2esimplify_2etakesMore(heff_dup(v_s_2466), heff_dup(v_g_2465), v_t_2467));
  if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
    heff_drop(v_t_2468);
    V v_t_2469 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2453, v_as_2421));
    V v_t_2470 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), v_t_2469});
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_s_2466;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2468);
    V v_t_2471 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), v_bs_2453});
    V v_m_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2471}));
    V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_s_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      V v_m_2477 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
      V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_s_2475}));
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_MkPair: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_s_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        V f_ = heff_get_n(v_r_240, 1, 4);
        heff_room[0] = v_x_2474;
        heff_room[1] = v_x_2479;
        heff_room[2] = v_s_2480;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_x2_2478);
      }
    }
    default: return heff_nomatch(v_x2_2473);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2488 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    heff_take_n(v_x2_2485, 3ULL, 2);
    V v_m_2489 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2487}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2486;
      heff_room[1] = v_x_2491;
      heff_room[2] = v_s_2492;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_24100 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    heff_take_n(v_x2_2497, 3ULL, 2);
    V v_m_24101 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24102 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_s_2499}));
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_MkPair: {
      V v_x_24103 = heff_field(v_x2_24102, 0);
      V v_s_24104 = heff_field(v_x2_24102, 1);
      heff_take_n(v_x2_24102, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2498;
      heff_room[1] = v_x_24103;
      heff_room[2] = v_s_24104;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24102);
    }
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24113 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_s_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_s_24112 = heff_field(v_x2_24110, 1);
    heff_take_n(v_x2_24110, 3ULL, 2);
    V v_m_24114 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_s_24112}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_s_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24111;
      heff_room[1] = v_x_24116;
      heff_room[2] = v_s_24117;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24125 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24125;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    heff_take_n(v_x2_24122, 3ULL, 2);
    V v_m_24126 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24127 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24124}));
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_s_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24123;
      heff_room[1] = v_x_24128;
      heff_room[2] = v_s_24129;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24139 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    heff_take_n(v_x2_24136, 3ULL, 2);
    V v_m_24140 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_s_24138}));
    switch (heff_tag_of(v_x2_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x2_24141, 0);
      V v_s_24143 = heff_field(v_x2_24141, 1);
      heff_take_n(v_x2_24141, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24137;
      heff_room[1] = v_x_24142;
      heff_room[2] = v_s_24143;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24141);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24152 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24152;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_s_24151 = heff_field(v_x2_24149, 1);
    heff_take_n(v_x2_24149, 3ULL, 2);
    V v_m_24153 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24154 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_s_24151}));
    switch (heff_tag_of(v_x2_24154)) {
    case TAG_MkPair: {
      V v_x_24155 = heff_field(v_x2_24154, 0);
      V v_s_24156 = heff_field(v_x2_24154, 1);
      heff_take_n(v_x2_24154, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24150;
      heff_room[1] = v_x_24155;
      heff_room[2] = v_s_24156;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24154);
    }
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24164 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24164;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24160 = args[0];
  V v_m_24159 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24161 = heff_tr(heff_call(v_m_24159, 1, (V[]){v_s_24160}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_MkPair: {
    V v_x_24162 = heff_field(v_x2_24161, 0);
    V v_s_24163 = heff_field(v_x2_24161, 1);
    heff_take_n(v_x2_24161, 3ULL, 2);
    V v_m_24165 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24166 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24163}));
    switch (heff_tag_of(v_x2_24166)) {
    case TAG_MkPair: {
      V v_x_24167 = heff_field(v_x2_24166, 0);
      V v_s_24168 = heff_field(v_x2_24166, 1);
      heff_take_n(v_x2_24166, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24162;
      heff_room[1] = v_x_24167;
      heff_room[2] = v_s_24168;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24166);
    }
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24175 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24175;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_s_24171}));
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_s_24174 = heff_field(v_x2_24172, 1);
    heff_take_n(v_x2_24172, 3ULL, 2);
    V v_m_24176 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24177 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_s_24174}));
    switch (heff_tag_of(v_x2_24177)) {
    case TAG_MkPair: {
      V v_x_24178 = heff_field(v_x2_24177, 0);
      V v_s_24179 = heff_field(v_x2_24177, 1);
      heff_take_n(v_x2_24177, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24173;
      heff_room[1] = v_x_24178;
      heff_room[2] = v_s_24179;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24177);
    }
  }
  default: return heff_nomatch(v_x2_24172);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24187 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24187;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_s_24183}));
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_x_24185 = heff_field(v_x2_24184, 0);
    V v_s_24186 = heff_field(v_x2_24184, 1);
    heff_take_n(v_x2_24184, 3ULL, 2);
    V v_m_24188 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_s_24186}));
    switch (heff_tag_of(v_x2_24189)) {
    case TAG_MkPair: {
      V v_x_24190 = heff_field(v_x2_24189, 0);
      V v_s_24191 = heff_field(v_x2_24189, 1);
      heff_take_n(v_x2_24189, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24185;
      heff_room[1] = v_x_24190;
      heff_room[2] = v_s_24191;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24189);
    }
  }
  default: return heff_nomatch(v_x2_24184);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24199 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24199;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    heff_take_n(v_x2_24196, 3ULL, 2);
    V v_m_24200 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24201 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_s_24198}));
    switch (heff_tag_of(v_x2_24201)) {
    case TAG_MkPair: {
      V v_x_24202 = heff_field(v_x2_24201, 0);
      V v_s_24203 = heff_field(v_x2_24201, 1);
      heff_take_n(v_x2_24201, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24197;
      heff_room[1] = v_x_24202;
      heff_room[2] = v_s_24203;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24201);
    }
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24210 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24210;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24206}));
  switch (heff_tag_of(v_x2_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_x2_24207, 0);
    V v_s_24209 = heff_field(v_x2_24207, 1);
    heff_take_n(v_x2_24207, 3ULL, 2);
    V v_m_24211 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24212 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_s_24209}));
    switch (heff_tag_of(v_x2_24212)) {
    case TAG_MkPair: {
      V v_x_24213 = heff_field(v_x2_24212, 0);
      V v_s_24214 = heff_field(v_x2_24212, 1);
      heff_take_n(v_x2_24212, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24208;
      heff_room[1] = v_x_24213;
      heff_room[2] = v_s_24214;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24212);
    }
  }
  default: return heff_nomatch(v_x2_24207);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24221 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24221;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_s_24217}));
  switch (heff_tag_of(v_x2_24218)) {
  case TAG_MkPair: {
    V v_x_24219 = heff_field(v_x2_24218, 0);
    V v_s_24220 = heff_field(v_x2_24218, 1);
    heff_take_n(v_x2_24218, 3ULL, 2);
    V v_m_24222 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24223 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_s_24220}));
    switch (heff_tag_of(v_x2_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x2_24223, 0);
      V v_s_24225 = heff_field(v_x2_24223, 1);
      heff_take_n(v_x2_24223, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24219;
      heff_room[1] = v_x_24224;
      heff_room[2] = v_s_24225;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24223);
    }
  }
  default: return heff_nomatch(v_x2_24218);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24232 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_s_24228}));
  switch (heff_tag_of(v_x2_24229)) {
  case TAG_MkPair: {
    V v_x_24230 = heff_field(v_x2_24229, 0);
    V v_s_24231 = heff_field(v_x2_24229, 1);
    heff_take_n(v_x2_24229, 3ULL, 2);
    V v_m_24233 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_s_24231}));
    switch (heff_tag_of(v_x2_24234)) {
    case TAG_MkPair: {
      V v_x_24235 = heff_field(v_x2_24234, 0);
      V v_s_24236 = heff_field(v_x2_24234, 1);
      heff_take_n(v_x2_24234, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24230;
      heff_room[1] = v_x_24235;
      heff_room[2] = v_s_24236;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24234);
    }
  }
  default: return heff_nomatch(v_x2_24229);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24243 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_s_24239}));
  switch (heff_tag_of(v_x2_24240)) {
  case TAG_MkPair: {
    V v_x_24241 = heff_field(v_x2_24240, 0);
    V v_s_24242 = heff_field(v_x2_24240, 1);
    heff_take_n(v_x2_24240, 3ULL, 2);
    V v_m_24244 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_s_24242}));
    switch (heff_tag_of(v_x2_24245)) {
    case TAG_MkPair: {
      V v_x_24246 = heff_field(v_x2_24245, 0);
      V v_s_24247 = heff_field(v_x2_24245, 1);
      heff_take_n(v_x2_24245, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24241;
      heff_room[1] = v_x_24246;
      heff_room[2] = v_s_24247;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24245);
    }
  }
  default: return heff_nomatch(v_x2_24240);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24255 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24255;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_s_24251}));
  switch (heff_tag_of(v_x2_24252)) {
  case TAG_MkPair: {
    V v_x_24253 = heff_field(v_x2_24252, 0);
    V v_s_24254 = heff_field(v_x2_24252, 1);
    heff_take_n(v_x2_24252, 3ULL, 2);
    V v_m_24256 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_s_24254}));
    switch (heff_tag_of(v_x2_24257)) {
    case TAG_MkPair: {
      V v_x_24258 = heff_field(v_x2_24257, 0);
      V v_s_24259 = heff_field(v_x2_24257, 1);
      heff_take_n(v_x2_24257, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24253;
      heff_room[1] = v_x_24258;
      heff_room[2] = v_s_24259;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24257);
    }
  }
  default: return heff_nomatch(v_x2_24252);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24266 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24266;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24262 = args[0];
  V v_m_24261 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24263 = heff_tr(heff_call(v_m_24261, 1, (V[]){v_s_24262}));
  switch (heff_tag_of(v_x2_24263)) {
  case TAG_MkPair: {
    V v_x_24264 = heff_field(v_x2_24263, 0);
    V v_s_24265 = heff_field(v_x2_24263, 1);
    heff_take_n(v_x2_24263, 3ULL, 2);
    V v_m_24267 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_s_24265}));
    switch (heff_tag_of(v_x2_24268)) {
    case TAG_MkPair: {
      V v_x_24269 = heff_field(v_x2_24268, 0);
      V v_s_24270 = heff_field(v_x2_24268, 1);
      heff_take_n(v_x2_24268, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24264;
      heff_room[1] = v_x_24269;
      heff_room[2] = v_s_24270;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24268);
    }
  }
  default: return heff_nomatch(v_x2_24263);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24276 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24276;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24272 = args[0];
  V v_m_24271 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24273 = heff_tr(heff_call(v_m_24271, 1, (V[]){v_s_24272}));
  switch (heff_tag_of(v_x2_24273)) {
  case TAG_MkPair: {
    V v_x_24274 = heff_field(v_x2_24273, 0);
    V v_s_24275 = heff_field(v_x2_24273, 1);
    heff_take_n(v_x2_24273, 3ULL, 2);
    V v_m_24277 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_s_24275}));
    switch (heff_tag_of(v_x2_24278)) {
    case TAG_MkPair: {
      V v_x_24279 = heff_field(v_x2_24278, 0);
      V v_s_24280 = heff_field(v_x2_24278, 1);
      heff_take_n(v_x2_24278, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24274;
      heff_room[1] = v_x_24279;
      heff_room[2] = v_s_24280;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24278);
    }
  }
  default: return heff_nomatch(v_x2_24273);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24288 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24288;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24284 = args[0];
  V v_m_24283 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24285 = heff_tr(heff_call(v_m_24283, 1, (V[]){v_s_24284}));
  switch (heff_tag_of(v_x2_24285)) {
  case TAG_MkPair: {
    V v_x_24286 = heff_field(v_x2_24285, 0);
    V v_s_24287 = heff_field(v_x2_24285, 1);
    heff_take_n(v_x2_24285, 3ULL, 2);
    V v_m_24289 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24290 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_s_24287}));
    switch (heff_tag_of(v_x2_24290)) {
    case TAG_MkPair: {
      V v_x_24291 = heff_field(v_x2_24290, 0);
      V v_s_24292 = heff_field(v_x2_24290, 1);
      heff_take_n(v_x2_24290, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24286;
      heff_room[1] = v_x_24291;
      heff_room[2] = v_s_24292;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24290);
    }
  }
  default: return heff_nomatch(v_x2_24285);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24301 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24301;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24298 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_s_24297}));
  switch (heff_tag_of(v_x2_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_field(v_x2_24298, 0);
    V v_s_24300 = heff_field(v_x2_24298, 1);
    heff_take_n(v_x2_24298, 3ULL, 2);
    V v_m_24302 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24303 = heff_tr(heff_call(v_m_24302, 1, (V[]){v_s_24300}));
    switch (heff_tag_of(v_x2_24303)) {
    case TAG_MkPair: {
      V v_x_24304 = heff_field(v_x2_24303, 0);
      V v_s_24305 = heff_field(v_x2_24303, 1);
      heff_take_n(v_x2_24303, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24299;
      heff_room[1] = v_x_24304;
      heff_room[2] = v_s_24305;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24303);
    }
  }
  default: return heff_nomatch(v_x2_24298);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24313 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24313;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24309 = args[0];
  V v_m_24308 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24310 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_s_24309}));
  switch (heff_tag_of(v_x2_24310)) {
  case TAG_MkPair: {
    V v_x_24311 = heff_field(v_x2_24310, 0);
    V v_s_24312 = heff_field(v_x2_24310, 1);
    heff_take_n(v_x2_24310, 3ULL, 2);
    V v_m_24314 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24315 = heff_tr(heff_call(v_m_24314, 1, (V[]){v_s_24312}));
    switch (heff_tag_of(v_x2_24315)) {
    case TAG_MkPair: {
      V v_x_24316 = heff_field(v_x2_24315, 0);
      V v_s_24317 = heff_field(v_x2_24315, 1);
      heff_take_n(v_x2_24315, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24311;
      heff_room[1] = v_x_24316;
      heff_room[2] = v_s_24317;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24315);
    }
  }
  default: return heff_nomatch(v_x2_24310);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24327 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24327;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24323 = args[0];
  V v_m_24322 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24324 = heff_tr(heff_call(v_m_24322, 1, (V[]){v_s_24323}));
  switch (heff_tag_of(v_x2_24324)) {
  case TAG_MkPair: {
    V v_x_24325 = heff_field(v_x2_24324, 0);
    V v_s_24326 = heff_field(v_x2_24324, 1);
    heff_take_n(v_x2_24324, 3ULL, 2);
    V v_m_24328 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24329 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_s_24326}));
    switch (heff_tag_of(v_x2_24329)) {
    case TAG_MkPair: {
      V v_x_24330 = heff_field(v_x2_24329, 0);
      V v_s_24331 = heff_field(v_x2_24329, 1);
      heff_take_n(v_x2_24329, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24325;
      heff_room[1] = v_x_24330;
      heff_room[2] = v_s_24331;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24329);
    }
  }
  default: return heff_nomatch(v_x2_24324);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24340 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24340;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24336 = args[0];
  V v_m_24335 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24337 = heff_tr(heff_call(v_m_24335, 1, (V[]){v_s_24336}));
  switch (heff_tag_of(v_x2_24337)) {
  case TAG_MkPair: {
    V v_x_24338 = heff_field(v_x2_24337, 0);
    V v_s_24339 = heff_field(v_x2_24337, 1);
    heff_take_n(v_x2_24337, 3ULL, 2);
    V v_m_24341 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24342 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_s_24339}));
    switch (heff_tag_of(v_x2_24342)) {
    case TAG_MkPair: {
      V v_x_24343 = heff_field(v_x2_24342, 0);
      V v_s_24344 = heff_field(v_x2_24342, 1);
      heff_take_n(v_x2_24342, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24338;
      heff_room[1] = v_x_24343;
      heff_room[2] = v_s_24344;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24342);
    }
  }
  default: return heff_nomatch(v_x2_24337);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24352 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24352;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24348 = args[0];
  V v_m_24347 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24349 = heff_tr(heff_call(v_m_24347, 1, (V[]){v_s_24348}));
  switch (heff_tag_of(v_x2_24349)) {
  case TAG_MkPair: {
    V v_x_24350 = heff_field(v_x2_24349, 0);
    V v_s_24351 = heff_field(v_x2_24349, 1);
    heff_take_n(v_x2_24349, 3ULL, 2);
    V v_m_24353 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24354 = heff_tr(heff_call(v_m_24353, 1, (V[]){v_s_24351}));
    switch (heff_tag_of(v_x2_24354)) {
    case TAG_MkPair: {
      V v_x_24355 = heff_field(v_x2_24354, 0);
      V v_s_24356 = heff_field(v_x2_24354, 1);
      heff_take_n(v_x2_24354, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24350;
      heff_room[1] = v_x_24355;
      heff_room[2] = v_s_24356;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24354);
    }
  }
  default: return heff_nomatch(v_x2_24349);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24363 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24363;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24359 = args[0];
  V v_m_24358 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24360 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_s_24359}));
  switch (heff_tag_of(v_x2_24360)) {
  case TAG_MkPair: {
    V v_x_24361 = heff_field(v_x2_24360, 0);
    V v_s_24362 = heff_field(v_x2_24360, 1);
    heff_take_n(v_x2_24360, 3ULL, 2);
    V v_m_24364 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24365 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_s_24362}));
    switch (heff_tag_of(v_x2_24365)) {
    case TAG_MkPair: {
      V v_x_24366 = heff_field(v_x2_24365, 0);
      V v_s_24367 = heff_field(v_x2_24365, 1);
      heff_take_n(v_x2_24365, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24361;
      heff_room[1] = v_x_24366;
      heff_room[2] = v_s_24367;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24365);
    }
  }
  default: return heff_nomatch(v_x2_24360);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24375 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24375;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24371 = args[0];
  V v_m_24370 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24372 = heff_tr(heff_call(v_m_24370, 1, (V[]){v_s_24371}));
  switch (heff_tag_of(v_x2_24372)) {
  case TAG_MkPair: {
    V v_x_24373 = heff_field(v_x2_24372, 0);
    V v_s_24374 = heff_field(v_x2_24372, 1);
    heff_take_n(v_x2_24372, 3ULL, 2);
    V v_m_24376 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24377 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_s_24374}));
    switch (heff_tag_of(v_x2_24377)) {
    case TAG_MkPair: {
      V v_x_24378 = heff_field(v_x2_24377, 0);
      V v_s_24379 = heff_field(v_x2_24377, 1);
      heff_take_n(v_x2_24377, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24373;
      heff_room[1] = v_x_24378;
      heff_room[2] = v_s_24379;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24377);
    }
  }
  default: return heff_nomatch(v_x2_24372);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24387 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24387;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24383 = args[0];
  V v_m_24382 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24384 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_s_24383}));
  switch (heff_tag_of(v_x2_24384)) {
  case TAG_MkPair: {
    V v_x_24385 = heff_field(v_x2_24384, 0);
    V v_s_24386 = heff_field(v_x2_24384, 1);
    heff_take_n(v_x2_24384, 3ULL, 2);
    V v_m_24388 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24389 = heff_tr(heff_call(v_m_24388, 1, (V[]){v_s_24386}));
    switch (heff_tag_of(v_x2_24389)) {
    case TAG_MkPair: {
      V v_x_24390 = heff_field(v_x2_24389, 0);
      V v_s_24391 = heff_field(v_x2_24389, 1);
      heff_take_n(v_x2_24389, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24385;
      heff_room[1] = v_x_24390;
      heff_room[2] = v_s_24391;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24389);
    }
  }
  default: return heff_nomatch(v_x2_24384);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24398 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24398;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_s_24394}));
  switch (heff_tag_of(v_x2_24395)) {
  case TAG_MkPair: {
    V v_x_24396 = heff_field(v_x2_24395, 0);
    V v_s_24397 = heff_field(v_x2_24395, 1);
    heff_take_n(v_x2_24395, 3ULL, 2);
    V v_m_24399 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24400 = heff_tr(heff_call(v_m_24399, 1, (V[]){v_s_24397}));
    switch (heff_tag_of(v_x2_24400)) {
    case TAG_MkPair: {
      V v_x_24401 = heff_field(v_x2_24400, 0);
      V v_s_24402 = heff_field(v_x2_24400, 1);
      heff_take_n(v_x2_24400, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24396;
      heff_room[1] = v_x_24401;
      heff_room[2] = v_s_24402;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24400);
    }
  }
  default: return heff_nomatch(v_x2_24395);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24409 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24409;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_s_24405}));
  switch (heff_tag_of(v_x2_24406)) {
  case TAG_MkPair: {
    V v_x_24407 = heff_field(v_x2_24406, 0);
    V v_s_24408 = heff_field(v_x2_24406, 1);
    heff_take_n(v_x2_24406, 3ULL, 2);
    V v_m_24410 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24411 = heff_tr(heff_call(v_m_24410, 1, (V[]){v_s_24408}));
    switch (heff_tag_of(v_x2_24411)) {
    case TAG_MkPair: {
      V v_x_24412 = heff_field(v_x2_24411, 0);
      V v_s_24413 = heff_field(v_x2_24411, 1);
      heff_take_n(v_x2_24411, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24407;
      heff_room[1] = v_x_24412;
      heff_room[2] = v_s_24413;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24411);
    }
  }
  default: return heff_nomatch(v_x2_24406);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24416 = args[0];
  V v_m_24415 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24417 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_s_24416}));
  switch (heff_tag_of(v_x2_24417)) {
  case TAG_MkPair: {
    V v_x_24418 = heff_field(v_x2_24417, 0);
    V v_s_24419 = heff_field(v_x2_24417, 1);
    heff_take_n(v_x2_24417, 3ULL, 2);
    V v_m_24421 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24422 = heff_tr(heff_call(v_m_24421, 1, (V[]){v_s_24419}));
    switch (heff_tag_of(v_x2_24422)) {
    case TAG_MkPair: {
      V v_x_24423 = heff_field(v_x2_24422, 0);
      V v_s_24424 = heff_field(v_x2_24422, 1);
      heff_take_n(v_x2_24422, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24418;
      heff_room[1] = v_x_24423;
      heff_room[2] = v_s_24424;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24422);
    }
  }
  default: return heff_nomatch(v_x2_24417);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24431 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24427 = args[0];
  V v_m_24426 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24428 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_s_24427}));
  switch (heff_tag_of(v_x2_24428)) {
  case TAG_MkPair: {
    V v_x_24429 = heff_field(v_x2_24428, 0);
    V v_s_24430 = heff_field(v_x2_24428, 1);
    heff_take_n(v_x2_24428, 3ULL, 2);
    V v_m_24432 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24433 = heff_tr(heff_call(v_m_24432, 1, (V[]){v_s_24430}));
    switch (heff_tag_of(v_x2_24433)) {
    case TAG_MkPair: {
      V v_x_24434 = heff_field(v_x2_24433, 0);
      V v_s_24435 = heff_field(v_x2_24433, 1);
      heff_take_n(v_x2_24433, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24429;
      heff_room[1] = v_x_24434;
      heff_room[2] = v_s_24435;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24433);
    }
  }
  default: return heff_nomatch(v_x2_24428);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24443 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24439 = args[0];
  V v_m_24438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24440 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_s_24439}));
  switch (heff_tag_of(v_x2_24440)) {
  case TAG_MkPair: {
    V v_x_24441 = heff_field(v_x2_24440, 0);
    V v_s_24442 = heff_field(v_x2_24440, 1);
    heff_take_n(v_x2_24440, 3ULL, 2);
    V v_m_24444 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24445 = heff_tr(heff_call(v_m_24444, 1, (V[]){v_s_24442}));
    switch (heff_tag_of(v_x2_24445)) {
    case TAG_MkPair: {
      V v_x_24446 = heff_field(v_x2_24445, 0);
      V v_s_24447 = heff_field(v_x2_24445, 1);
      heff_take_n(v_x2_24445, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24441;
      heff_room[1] = v_x_24446;
      heff_room[2] = v_s_24447;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24445);
    }
  }
  default: return heff_nomatch(v_x2_24440);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24454 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24450 = args[0];
  V v_m_24449 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24451 = heff_tr(heff_call(v_m_24449, 1, (V[]){v_s_24450}));
  switch (heff_tag_of(v_x2_24451)) {
  case TAG_MkPair: {
    V v_x_24452 = heff_field(v_x2_24451, 0);
    V v_s_24453 = heff_field(v_x2_24451, 1);
    heff_take_n(v_x2_24451, 3ULL, 2);
    V v_m_24455 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24456 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_s_24453}));
    switch (heff_tag_of(v_x2_24456)) {
    case TAG_MkPair: {
      V v_x_24457 = heff_field(v_x2_24456, 0);
      V v_s_24458 = heff_field(v_x2_24456, 1);
      heff_take_n(v_x2_24456, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24452;
      heff_room[1] = v_x_24457;
      heff_room[2] = v_s_24458;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24456);
    }
  }
  default: return heff_nomatch(v_x2_24451);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_a_24464 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24460 = args[0];
  V v_m_24459 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24461 = heff_tr(heff_call(v_m_24459, 1, (V[]){v_s_24460}));
  switch (heff_tag_of(v_x2_24461)) {
  case TAG_MkPair: {
    V v_x_24462 = heff_field(v_x2_24461, 0);
    V v_s_24463 = heff_field(v_x2_24461, 1);
    heff_take_n(v_x2_24461, 3ULL, 2);
    V v_m_24465 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam78, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24466 = heff_tr(heff_call(v_m_24465, 1, (V[]){v_s_24463}));
    switch (heff_tag_of(v_x2_24466)) {
    case TAG_MkPair: {
      V v_x_24467 = heff_field(v_x2_24466, 0);
      V v_s_24468 = heff_field(v_x2_24466, 1);
      heff_take_n(v_x2_24466, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24462;
      heff_room[1] = v_x_24467;
      heff_room[2] = v_s_24468;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24466);
    }
  }
  default: return heff_nomatch(v_x2_24461);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_a_24476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24472 = args[0];
  V v_m_24471 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24473 = heff_tr(heff_call(v_m_24471, 1, (V[]){v_s_24472}));
  switch (heff_tag_of(v_x2_24473)) {
  case TAG_MkPair: {
    V v_x_24474 = heff_field(v_x2_24473, 0);
    V v_s_24475 = heff_field(v_x2_24473, 1);
    heff_take_n(v_x2_24473, 3ULL, 2);
    V v_m_24477 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam80, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2421));
    V v_x2_24478 = heff_tr(heff_call(v_m_24477, 1, (V[]){v_s_24475}));
    switch (heff_tag_of(v_x2_24478)) {
    case TAG_MkPair: {
      V v_x_24479 = heff_field(v_x2_24478, 0);
      V v_s_24480 = heff_field(v_x2_24478, 1);
      heff_take_n(v_x2_24478, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24474;
      heff_room[1] = v_x_24479;
      heff_room[2] = v_s_24480;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24478);
    }
  }
  default: return heff_nomatch(v_x2_24473);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24485 = args[0];
  V v_m_24484 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24481 = heff_env(self)[2];
  V v_b_24483 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24486 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_s_24485}));
  switch (heff_tag_of(v_x2_24486)) {
  case TAG_MkPair: {
    V v_x_24487 = heff_field(v_x2_24486, 0);
    V v_s_24488 = heff_field(v_x2_24486, 1);
    heff_take_n(v_x2_24486, 3ULL, 2);
    V v_t_24489 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_24481, v_x_24487, v_b_24483));
    V f_ = v_t_24489;
    args[0] = v_s_24488;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24486);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24496 = args[0];
  V v_m_24495 = heff_env(self)[0];
  V v_l_24493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24497 = heff_tr(heff_call(v_m_24495, 1, (V[]){v_s_24496}));
  switch (heff_tag_of(v_x2_24497)) {
  case TAG_MkPair: {
    V v_x_24498 = heff_field(v_x2_24497, 0);
    V v_s_24499 = heff_field(v_x2_24497, 1);
    V v_ru_24x2_24497_24MkPair = heff_take_reuse_n(v_x2_24497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24493, v_x_24498}), v_s_24499});
  }
  default: return heff_nomatch(v_x2_24497);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_p_24492 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24492)) {
  case TAG_MkPair: {
    V v_l_24493 = heff_field(v_p_24492, 0);
    V v_e_24494 = heff_field(v_p_24492, 1);
    heff_take_n(v_p_24492, 3ULL, 2);
    V v_m_24495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_e_24494}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam83, 1, 2, (V[]){v_m_24495, v_l_24493});
  }
  default: return heff_nomatch(v_p_24492);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24501 = args[0];
  V v_m_24500 = heff_env(self)[0];
  V v_ts_24491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24502 = heff_tr(heff_call(v_m_24500, 1, (V[]){v_s_24501}));
  switch (heff_tag_of(v_x2_24502)) {
  case TAG_MkPair: {
    V v_x_24503 = heff_field(v_x2_24502, 0);
    V v_s_24504 = heff_field(v_x2_24502, 1);
    V v_ru_24x2_24502_24MkPair = heff_take_reuse_n(v_x2_24502, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24503, v_ts_24491}), v_s_24504});
  }
  default: return heff_nomatch(v_x2_24502);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_s_24510 = args[0];
  V v_m_24509 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24506 = heff_env(self)[2];
  V v_sh_24507 = heff_env(self)[3];
  V v_t_24508 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24511 = heff_tr(heff_call(v_m_24509, 1, (V[]){v_s_24510}));
  switch (heff_tag_of(v_x2_24511)) {
  case TAG_MkPair: {
    V v_x_24512 = heff_field(v_x2_24511, 0);
    V v_s_24513 = heff_field(v_x2_24511, 1);
    heff_take_n(v_x2_24511, 3ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 5, (V[]){v_l_24506, v_sh_24507, v_t_24508, v_x_24512, v_s_24513});
  }
  default: return heff_nomatch(v_x2_24511);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_a_24517 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24517;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24519 = args[0];
  V v_m_24518 = heff_env(self)[0];
  V v_t_24514 = heff_env(self)[1];
  V v_ts_24516 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24520 = heff_tr(heff_call(v_m_24518, 1, (V[]){v_s_24519}));
  switch (heff_tag_of(v_x2_24520)) {
  case TAG_MkPair: {
    V v_x_24521 = heff_field(v_x2_24520, 0);
    V v_s_24522 = heff_field(v_x2_24520, 1);
    V v_ru_24x2_24520_24MkPair = heff_take_reuse_n(v_x2_24520, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24514, v_x_24521, v_ts_24516}), v_s_24522});
  }
  default: return heff_nomatch(v_x2_24520);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_s_24535 = args[0];
  V v_m_24534 = heff_env(self)[0];
  V v_t_24531 = heff_env(self)[1];
  V v_vs_24532 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24536 = heff_tr(heff_call(v_m_24534, 1, (V[]){v_s_24535}));
  switch (heff_tag_of(v_x2_24536)) {
  case TAG_MkPair: {
    V v_x_24537 = heff_field(v_x2_24536, 0);
    V v_s_24538 = heff_field(v_x2_24536, 1);
    V v_ru_24x2_24536_24MkPair = heff_take_reuse_n(v_x2_24536, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24536_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24531, v_vs_24532, v_x_24537}), v_s_24538});
  }
  default: return heff_nomatch(v_x2_24536);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_a_24530 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24530)) {
  case TAG_MkArm: {
    V v_t_24531 = heff_field(v_a_24530, 0);
    V v_vs_24532 = heff_field(v_a_24530, 1);
    V v_b_24533 = heff_field(v_a_24530, 2);
    heff_take_n(v_a_24530, 7ULL, 3);
    V v_m_24534 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24533}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam90, 1, 3, (V[]){v_m_24534, v_t_24531, v_vs_24532});
  }
  default: return heff_nomatch(v_a_24530);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_s_24526 = args[0];
  V v_m_24525 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24524 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24527 = heff_tr(heff_call(v_m_24525, 1, (V[]){v_s_24526}));
  switch (heff_tag_of(v_x2_24527)) {
  case TAG_MkPair: {
    V v_x_24528 = heff_field(v_x2_24527, 0);
    V v_s_24529 = heff_field(v_x2_24527, 1);
    heff_take_n(v_x2_24527, 3ULL, 2);
    V v_m_24539 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam89, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24524));
    V v_x2_24540 = heff_tr(heff_call(v_m_24539, 1, (V[]){v_s_24529}));
    switch (heff_tag_of(v_x2_24540)) {
    case TAG_MkPair: {
      V v_x_24541 = heff_field(v_x2_24540, 0);
      V v_s_24542 = heff_field(v_x2_24540, 1);
      heff_take_n(v_x2_24540, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 3, 4);
      heff_room[0] = v_x_24528;
      heff_room[1] = v_x_24541;
      heff_room[2] = v_s_24542;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24540);
    }
  }
  default: return heff_nomatch(v_x2_24527);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24544 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24544});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_a_24547 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24547;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24549 = args[0];
  V v_m_24548 = heff_env(self)[0];
  V v_p_24545 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24550 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_s_24549}));
  switch (heff_tag_of(v_x2_24550)) {
  case TAG_MkPair: {
    V v_x_24551 = heff_field(v_x2_24550, 0);
    V v_s_24552 = heff_field(v_x2_24550, 1);
    V v_ru_24x2_24550_24MkPair = heff_take_reuse_n(v_x2_24550, 3ULL, 2);
    V v_x2_24559;
    switch (heff_tag_of(v_x_24551)) {
    case TAG_Nil: {
      v_x2_24559 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_24553 = heff_dup(heff_field(v_x_24551, 0));
      V v_x22_24554 = heff_dup(heff_field(v_x_24551, 1));
      switch (heff_tag_of(v_x22_24554)) {
      case TAG_Nil: {
        v_x2_24559 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_24545), v_a_24553));
        break;
      }
      case TAG_Cons: {
        V v_b_24555 = heff_field(v_x22_24554, 0);
        V v_x222_24556 = heff_field(v_x22_24554, 1);
        heff_take_n(v_x22_24554, 3ULL, 2);
        switch (heff_tag_of(v_x222_24556)) {
        case TAG_Nil: {
          v_x2_24559 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_24545), v_a_24553, v_b_24555));
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x222_24556, 0ULL, 2);
          heff_drop(v_a_24553);
          heff_drop(v_b_24555);
          v_x2_24559 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x222_24556);
        }
        break;
      }
      default: heff_nomatch(v_x22_24554);
      }
      break;
    }
    default: heff_nomatch(v_x_24551);
    }
    V v_t_24561;
    switch (heff_tag_of(v_x2_24559)) {
    case TAG_Nothing: {
      v_t_24561 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24545, v_x_24551});
      break;
    }
    case TAG_Just: {
      V v_x_24560 = heff_field(v_x2_24559, 0);
      heff_take_n(v_x2_24559, 1ULL, 1);
      heff_drop(v_p_24545);
      heff_drop(v_x_24551);
      v_t_24561 = v_x_24560;
      break;
    }
    default: heff_nomatch(v_x2_24559);
    }
    return heff_tag_at_n(v_ru_24x2_24550_24MkPair, TAG_MkPair, 2, (V[]){v_t_24561, v_s_24552});
  }
  default: return heff_nomatch(v_x2_24550);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_s_24564 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24564});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24566 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24566});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24568 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24568});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24570 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24570});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args) {
  V v_s_24572 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24572});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args) {
  V v_s_24575 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24575});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args) {
  V v_s_24577 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24577});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args) {
  V v_s_24578 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24578});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args) {
  V v_s_24581 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24581});
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_242), heff_rfield(v_s_244, 2)));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_b_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
    V v_x_248 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_247));
    v_t_249 = heff_intLt(MK_INT(50LL), v_x_248);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_g_242);
    heff_drop(v_t_249);
    V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_s_244});
  } else {
    heff_drop(v_t_249);
    V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(v_g_242, heff_rfield(v_s_244, 2)));
    V v_x2_2412 = (g_heff_2ecompile_2esimplify_2efueled(v_t_2411, v_s_244));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 4);
        V v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2414});
      }
      case TAG_Just: {
        V v_b_2416 = heff_field(v_x_2413, 0);
        heff_take_n(v_x_2413, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
        V v_t_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
        V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2416, v_as_243}));
        return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2417, v_t_2418, v_s_2414));
      }
      default: return heff_nomatch(v_x_2413);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlineCall(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str0), heff_intShow(v_t_245));
  V v_it_247 = (g_map_2elookup_24s1546226666x2146984184(heff_strAppend(heff_dup(v_g_242), v_t_246), heff_rfield(v_s_244, 6)));
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_x2_249 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_248, heff_dup(v_s_244)));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_t_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_242), heff_rfield(v_s_2411, 2)));
      V v_x2_2413 = (g_heff_2ecompile_2esimplify_2efueled(v_t_2412, v_s_2411));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
        switch (heff_tag_of(v_x_2414)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_g_242);
          heff_drop_rec(v_s_244, 9);
          heff_drop(v_x_2410);
          heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
          V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_s_2415});
        }
        case TAG_Just: {
          V v_b_2417 = heff_field(v_x_2414, 0);
          heff_take_n(v_x_2414, 1ULL, 1);
          V v_t_2418 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2410)));
          V v_m_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2417, v_t_2418}));
          V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_s_2415}));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
            V v_e_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
            V v_t_2424 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
            V v_t_2425 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2424));
            V v_lim_2426 = heff_intAdd(v_t_2425, MK_INT(24LL));
            V v_t_2427 = heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_Nil)});
            V v_x_2428 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2426), MK_INT(0LL), v_t_2427));
            V v_t_2430 = heff_bool(!heff_intLt_c(heff_dup(v_lim_2426), heff_dup(v_x_2428)));
            heff_drop(v_lim_2426);
            heff_drop(v_x_2428);
            if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
              heff_drop(v_f_241);
              heff_drop_rec(v_s_244, 9);
              heff_drop(v_t_2430);
              V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str1), heff_intShow(v_t_2431));
              V v_t_2433 = heff_strAppend(v_g_242, v_t_2432);
              V v_x2_2434 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2433, heff_tag_n(TAG_Inlined, 2, (V[]){heff_dup(v_x_2410), heff_dup(v_x_2421)}), v_s_2422));
              switch (heff_tag_of(v_x2_2434)) {
              case TAG_MkPair: {
                V v_s_2436 = heff_field(v_x2_2434, 1);
                heff_take_n(v_x2_2434, 2ULL, 2);
                V v_t_2437 = (g_heff_2ecompile_2esimplify_2ezipL(v_x_2410, v_as_243));
                V v_m_2438 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2437; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2437); r_; });
                V v_t_2439 = (g_map_2esize(v_m_2438));
                V v_x_2441;
                if (heff_intEq_c(v_t_2439, MK_INT(0LL))) {
                  heff_drop(v_m_2438);
                  v_x_2441 = v_x_2421;
                } else {
                  v_x_2441 = ({ V a_0 = v_m_2438; V a_1 = v_x_2421; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2438); r_; });
                }
                return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2441, v_s_2436});
              }
              default: return heff_nomatch(v_x2_2434);
              }
            } else {
              heff_drop(v_x_2410);
              heff_drop(v_x_2421);
              heff_drop(v_t_2430);
              V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str2), heff_intShow(v_t_2442));
              V v_t_2444 = heff_strAppend(v_g_242, v_t_2443);
              V v_t_2445 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_2422, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
              V v_x2_2446 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2444, NTAG(TAG_NotInlined), v_t_2445));
              switch (heff_tag_of(v_x2_2446)) {
              case TAG_MkPair: {
                V v_s_2448 = heff_field(v_x2_2446, 1);
                heff_take_n(v_x2_2446, 2ULL, 2);
                V v_x_2449 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
                return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2449, v_s_2448});
              }
              default: return heff_nomatch(v_x2_2446);
              }
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x_2414);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_Just: {
    V v_it1_2450 = heff_field(v_it_247, 0);
    heff_take_n(v_it_247, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_g_242);
    switch (heff_tag_of(v_it1_2450)) {
    case TAG_Inlined: {
      V v_ps_2451 = heff_field(v_it1_2450, 0);
      V v_e_2452 = heff_field(v_it1_2450, 1);
      V v_ru_24it1_2450_24Inlined = heff_take_reuse_n(v_it1_2450, 3ULL, 2);
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 1)))) {
        heff_drop(v_f_241);
        V v_t_2454 = heff_intSub(heff_take_field(v_s_244, 1), MK_INT(1LL));
        V v_t_2455 = ({ V rv_1 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_s_244, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x2_2456 = (g_heff_2ecompile_2esimplify_2ecopy(v_e_2452, v_t_2455));
        switch (heff_tag_of(v_x2_2456)) {
        case TAG_MkPair: {
          V v_x_2457 = heff_field(v_x2_2456, 0);
          V v_s_2458 = heff_field(v_x2_2456, 1);
          heff_take_n(v_x2_2456, 3ULL, 2);
          V v_t_2459 = (g_heff_2ecompile_2esimplify_2ezipL(v_ps_2451, v_as_243));
          V v_m_2460 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2459; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2459); r_; });
          V v_t_2461 = (g_map_2esize(v_m_2460));
          V v_x_2463;
          if (heff_intEq_c(v_t_2461, MK_INT(0LL))) {
            heff_drop(v_m_2460);
            v_x_2463 = v_x_2457;
          } else {
            v_x_2463 = ({ V a_0 = v_m_2460; V a_1 = v_x_2457; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2460); r_; });
          }
          return heff_tag_at_n(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_x_2463, v_s_2458});
        }
        default: return heff_nomatch(v_x2_2456);
        }
      } else {
        heff_drop(v_ps_2451);
        heff_drop(v_e_2452);
        V v_x_2464 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24it1_2450_24Inlined, TAG_MkPair, 2, (V[]){v_x_2464, v_s_244});
      }
    }
    case TAG_NotInlined: {
      V v_x_2465 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2465, v_s_244});
    }
    default: return heff_nomatch(v_it1_2450);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eworthIt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eworthIt_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eworthIt(V v_as_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_as_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_b_246 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2esimplify_2etoldTo(heff_dup(v_b_246), heff_dup(v_xs_245), v_as_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_b_246})});
      } else {
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_xs_245);
        heff_drop(v_b_246);
        heff_drop(v_t_247);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_as_240);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eworthIt(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopyCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_list_2emap_24s1049096277x601353451(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
        if (heff_intEq_c(v_t_2412, v_t_2413)) {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        } else {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
      } else {
        heff_drop(v_t_2411);
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EBytes: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_loop_240, V v_all_241, V v_as_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2410;
    if ((heff_dup(v_st_245) == NTAG(TAG_True))) {
      heff_drop(v_st_245);
      V v_x3_247 = (g_heff_2ecompile_2esimplify_2enthE(heff_dup(v_i_244), v_as_242));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        V v_t_249 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_248)));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_x_248);
          heff_drop(v_t_249);
          v_t_2410 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_249);
          if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
            v_t_2410 = (g_heff_2ecompile_2esimplify_2ecapturing(v_x_248));
          } else {
            heff_drop(v_x_248);
            v_t_2410 = NTAG(TAG_False);
          }
        }
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
    } else {
      heff_drop(v_st_245);
      v_t_2410 = NTAG(TAG_False);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2esimplify_2emarkGo_24dps(v_loop_240, v_all_241, v_as_242, v_rest_246, heff_intAdd(v_i_244, MK_INT(1LL)), heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str4, 1, ")");
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKey_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2especKey(V v_g_240, V v_marks_241, V v_vars_242, V v_as_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_marks_241));
  V v_t_245 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_244, v_as_243));
  V v_x2_249 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2esimplify_2especKey_lam0, 2, 1, (V[]){v_vars_242}), v_marks_241, v_t_245));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especKey_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2esimplify_2especKey_str4)));
  return heff_strAppend(v_g_240, v_t_2413);
}
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKey(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args) {
  V v_m_246 = args[0];
  V v_a_247 = args[1];
  V v_vars_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_m_246) == NTAG(TAG_True))) {
    heff_drop(v_m_246);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_242));
    return ({ V a_0 = v_t_248; V a_1 = v_a_247; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_a_247); r_; });
  } else {
    heff_drop(v_m_246);
    heff_drop(v_a_247);
    heff_drop(v_vars_242);
    return ((V)&g_heff_2ecompile_2esimplify_2especKey_str0);
  }
}
Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkCopySafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkCopySafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    v_t_244 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 4), heff_rfield(v_s_242, 5), v_b_241));
  }
  V v_t_248;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), heff_take_field(v_s_242, 4)));
    V v_s_246 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_242, 495ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_246, 3)));
    v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_246, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_h_240);
    heff_drop(v_t_244);
    v_t_248 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkCopySafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_x3_242, 0);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    HEFF_LAST return g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_as_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_g_2410 = heff_field(v_x31_247, 0);
      return (g_heff_2ecompile_2esimplify_2epartialMore(v_safe_240, v_all_241, heff_dup(v_g_2410), heff_dup(v_as_248)));
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_2444 = heff_field(v_x3_242, 1);
    V v_b_2445 = heff_field(v_x3_242, 2);
    V v_t_2446 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2444));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2445;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2446);
      return MK_INT(0LL);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2456 = heff_field(v_x3_242, 0);
    V v_arms_2457 = heff_field(v_x3_242, 1);
    V v_t_2458 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2456));
    if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
      heff_drop(v_t_2458);
      switch (heff_tag_of(v_arms_2457)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return MK_INT(0LL);
      }
      case TAG_Cons: {
        V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2462 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2457)));
        V v_x1_2463 = (g_list_2emap(v_t_2461, v_t_2462));
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2464 = heff_field(v_x1_2463, 0);
          V v_xs_2465 = heff_field(v_x1_2463, 1);
          heff_take_n(v_x1_2463, 3ULL, 2);
          return ({ V a_0 = v_x_2464; V a_1 = v_xs_2465; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_xs_2465); r_; });
        }
        default: return heff_nomatch(v_x1_2463);
        }
      }
      default: return heff_nomatch(v_arms_2457);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2458);
      return MK_INT(0LL);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_as_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2emarkedOf_24dps(v_ms_243, v_as_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_as_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_241, v_t_244}); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2411);
}
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2edepthOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = ({ V a_0 = v_n_246; V a_1 = v_ds_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_ds_240); r_; });
  V v_b_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_b_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_b_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  if (heff_intLe_c(heff_dup(v_b_249), heff_dup(v_d_245))) {
    heff_drop(v_b_249);
    return v_d_245;
  } else {
    heff_drop(v_d_245);
    return v_b_249;
  }
}
Clo g_heff_2ecompile_2esimplify_2esetOff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esetOff_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esetOff(V v_o_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_248 = ({ V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_o_240}); V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esetOff(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKnown_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especKnown(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_248 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especKnown_lam0, 1, 1, (V[]){heff_dup(v_s_245)}), v_as_244));
  V v_x1_2412;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_x1_2412 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_248);
    V v_t_249 = (g_list_2eany_24s378803910x892125795(v_as_244));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
      v_x1_2412 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2411); r_; });
    } else {
      heff_drop(v_t_249);
      v_x1_2412 = NTAG(TAG_False);
    }
  }
  V v_t_2413 = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
  heff_drop(v_x1_2412);
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_2413);
    V v_x_2414 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_245});
  } else {
    heff_drop(v_t_2413);
    V v_t_2415 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2416 = (g_heff_2ecompile_2eir_2enubI(v_t_2415));
    V v_loop_2417 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
    V v_t_2420;
    if ((heff_dup(v_loop_2417) == NTAG(TAG_True))) {
      V v_t_2419 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    } else {
      v_t_2420 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
    }
    V v_t_2421 = ({ V a_0 = v_loop_2417; V a_1 = v_t_2418; V a_2 = v_as_244; V a_3 = v_t_2420; V a_4 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2esimplify_2emarkGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_loop_2417); heff_drop(v_t_2418); r_; });
    return (g_heff_2ecompile_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2421, v_s_245));
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKnown(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_s_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_get_n(heff_get_n(v_s_245, 7, 9), 1, 7);
  return ({ V a_0 = v_t_247; V a_1 = v_a_246; V r_ = (g_heff_2ecompile_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_247); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eetaKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaKept(V v_saved_240, V v_x2_241, V v_lam1_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_bds_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_lam1_242)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop_rec(v_saved_240, 9);
      heff_drop(v_t_246);
      V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_bds_244, v_lam1_242})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_243});
    } else {
      heff_drop(v_lam1_242);
      heff_drop(v_bds_244);
      heff_drop(v_t_246);
      V v_t_248 = ({ V rv_2 = heff_take_field(v_saved_240, 2); V rv_5 = heff_get_n(v_saved_240, 5, 9); V rr_ = heff_rec_reuse_nf(v_p_243, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_t_248});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaKept(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq_lent(v_g_240, v_h_249, 1);
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ereplayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayed_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayed(V v_k_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 7);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b0_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_dup(heff_rfield(v_k_240, 4)), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop(v_x_245);
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ereplayBody(v_k_240, v_b0_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      } else {
        heff_drop_rec(v_k_240, 7);
        heff_drop(v_b0_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayed(a[0], a[1], a[2]);
}