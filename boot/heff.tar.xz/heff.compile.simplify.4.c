// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Inlined 13187
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ecallsW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(V, V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efromKept_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo;
V g_heff_2ecompile_2esimplify_2ehandedOn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo;
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptMade_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emadeKept_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emarkCopySafe_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo;
V g_heff_2ecompile_2esimplify_2esetGiven(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esetGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetGiven_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1794308634x1384130934(V, V, V, V, V);
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1794308634x1384130934_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edropL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edropL(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam7(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_safe_240, v_g_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_2411 = heff_field(v_e_242, 0);
    V v_argv_2412 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_2411)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2414 = heff_field(v_e1_2411, 0);
      HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_total_241, v_g_2414));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_ar_2418 = v_field_2417;
          V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2412));
          if (heff_intLe_c(v_t_2419, v_ar_2418)) {
            V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_argv_2412)));
            return ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2421); r_; });
          } else {
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_field_2417);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_2411);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2462 = heff_field(v_e_242, 0);
    V v_t_2467 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2462)));
    return ({ V a_0 = v_t_2467; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2467); r_; });
  }
  case TAG_EProj: {
    V v_e2_2468 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2468;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_argv_2473 = heff_field(v_e_242, 1);
    V v_t_2476 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_argv_2473)));
    return ({ V a_0 = v_t_2476; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2476); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2477 = heff_field(v_e_242, 0);
    V v_arms_2478 = heff_field(v_e_242, 1);
    V v_t_2479 = (g_heff_2ecompile_2esimplify_2epureIn(v_safe_240, v_total_241, v_sc_2477));
    if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
      heff_drop(v_t_2479);
      switch (heff_tag_of(v_arms_2478)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2487 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_arms_2478)));
        return ({ V a_0 = v_t_2487; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2487); r_; });
      }
      default: return heff_nomatch(v_arms_2478);
      }
    } else {
      heff_drop(v_t_2479);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2489 = heff_field(v_e_242, 0);
    V v_argv_2490 = heff_field(v_e_242, 1);
    V v_x1_2491 = ({ V a_0 = v_p_2489; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_x1_2491) == NTAG(TAG_True))) {
      heff_drop(v_x1_2491);
      V v_t_2493 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_argv_2490)));
      return ({ V a_0 = v_t_2493; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2493); r_; });
    } else {
      heff_drop(v_x1_2491);
      return NTAG(TAG_False);
    }
  }
  case TAG_ECall: {
    V v_g_2494 = heff_field(v_e_242, 0);
    V v_argv_2495 = heff_field(v_e_242, 1);
    HeffT2 v_t_2496 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_total_241, v_g_2494));
    {
      V v_field_2498 = v_t_2496.f[1];
      int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
      if ((v_tag_2497 == ((int64_t)0ULL))) {
        V v_ar_2499 = v_field_2498;
        V v_t_24100 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2495));
        if (heff_intLe_c(v_t_24100, v_ar_2499)) {
          V v_t_24102 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam5, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_argv_2495)));
          return ({ V a_0 = v_t_24102; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24102); r_; });
        } else {
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2498);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_24110 = heff_field(v_e_242, 0);
    V v_t_24111 = (g_heff_2ecompile_2eir_2econdOnto(v_c_24110, NTAG(TAG_Nil)));
    V v_t_24113 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam6, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_t_24111));
    return ({ V a_0 = v_t_24113; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24113); r_; });
  }
  case TAG_ESet: {
    V v_a_24115 = heff_field(v_e_242, 1);
    V v_b_24116 = heff_field(v_e_242, 2);
    V v_t_24117 = (g_heff_2ecompile_2esimplify_2epureIn(v_safe_240, v_total_241, v_a_24115));
    if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
      heff_drop(v_t_24117);
      V t_0 = v_safe_240;
      V t_1 = v_total_241;
      V t_2 = v_b_24116;
      v_safe_240 = t_0;
      v_total_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_24117);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24118 = heff_field(v_e_242, 0);
    V v_t_24120 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam7, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_es_24118)));
    return ({ V a_0 = v_t_24120; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24120); r_; });
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2420 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2420; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2420); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2464 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2464)) {
  case TAG_MkPair: {
    V v_e2_2466 = heff_field(v_p_2464, 1);
    heff_take_n(v_p_2464, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2466; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2466); r_; });
  }
  default: return heff_nomatch(v_p_2464);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2475 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2475; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2475); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_b_2482 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2486;
  switch (heff_tag_of(v_b_2482)) {
  case TAG_MkArm: {
    V v_b_2485 = heff_field(v_b_2482, 2);
    heff_take_n(v_b_2482, 4ULL, 3);
    v_t_2486 = v_b_2485;
    break;
  }
  default: heff_nomatch(v_b_2482);
  }
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_t_2486; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_t_2486); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2492 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2492; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2492); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args) {
  V v_a_24101 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_24101; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_24101); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam6(V self, V *args) {
  V v_a_24112 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_24112; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_24112); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam7(V self, V *args) {
  V v_a_24119 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_24119; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_24119); r_; });
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_x_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      V v_t_246 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
        V v_x1_249 = ({ V a_0 = v_key_241; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_248); r_; });
        if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
          heff_drop(v_x1_249);
          V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_acc_240, 0), heff_dup(v_key_241), NTAG(TAG_MkUnit)));
          V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2412 = (g_std_2emap_2einsert_24s93785294x875597928(heff_get_n(v_acc_240, 1, 2), v_key_241, v_t_2411));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2410, v_t_2412});
        } else {
          heff_drop(v_x1_249);
          V v_t_2413 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      V v_t_2415 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
        V v_x1_2418 = ({ V a_0 = v_key_241; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2417); r_; });
        if (!(heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_x1_2418);
          V v_t_2419 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_key_241);
          heff_drop(v_x1_2418);
          return v_acc_240;
        }
      } else {
        heff_drop(v_key_241);
        heff_drop(v_t_2415);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialOf(V v_s_240, V v_argv_241, V v_x3_242) {
top: ;
  V v_safe_243 = heff_take_field(v_s_240, 3);
  V v_total_244 = heff_get_n(v_s_240, 5, 9);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_argv_241);
    heff_drop(v_safe_243);
    heff_drop(v_total_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_EVar: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x31_245, 0);
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_241));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
      if (heff_intLt_c(v_t_2410, v_t_2411)) {
        V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){v_safe_243, v_total_244}));
        V v_t_2413 = (g_list_2emap(v_t_2412, v_argv_241));
        return ({ V a_0 = v_t_2413; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2413); r_; });
      } else {
        heff_drop(v_argv_241);
        heff_drop(v_safe_243);
        heff_drop(v_total_244);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_argv_241);
      heff_drop(v_safe_243);
      heff_drop(v_total_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialOf(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2esetGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esetGiven_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esetGiven(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_b_243)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_248 = v_field_247;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_EVar: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_MkPair: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_s_2413 = heff_field(v_x2_2411, 1);
          V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2412}), v_s_2413});
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2417}), v_s_2418});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      case TAG_ELam: {
        V v_ru_24it1_248_24ELam = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_s_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2423}), v_s_2424});
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      case TAG_EApp: {
        V v_ru_24it1_248_24EApp = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_MkPair: {
          V v_x_2429 = heff_field(v_x2_2428, 0);
          V v_s_2430 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2429}), v_s_2430});
        }
        default: return heff_nomatch(v_x2_2428);
        }
      }
      case TAG_ELet: {
        V v_ru_24it1_248_24ELet = heff_take_reuse_n(v_it1_248, 0ULL, 3);
        V v_m_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2435)) {
        case TAG_MkPair: {
          V v_x_2436 = heff_field(v_x2_2435, 0);
          V v_s_2437 = heff_field(v_x2_2435, 1);
          V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_248_24ELet, TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2436}), v_s_2437});
        }
        default: return heff_nomatch(v_x2_2435);
        }
      }
      case TAG_ERecord: {
        V v_ru_24it1_248_24ERecord = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_MkPair: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_s_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2442}), v_s_2443});
        }
        default: return heff_nomatch(v_x2_2441);
        }
      }
      case TAG_EProj: {
        heff_take_n(v_it1_248, 0ULL, 4);
        V v_m_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2449)) {
        case TAG_MkPair: {
          V v_x_2450 = heff_field(v_x2_2449, 0);
          V v_s_2451 = heff_field(v_x2_2449, 1);
          V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2450}), v_s_2451});
        }
        default: return heff_nomatch(v_x2_2449);
        }
      }
      case TAG_ETag: {
        V v_ru_24it1_248_24ETag = heff_take_reuse_n(v_it1_248, 0ULL, 3);
        V v_m_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2456 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2456)) {
        case TAG_MkPair: {
          V v_x_2457 = heff_field(v_x2_2456, 0);
          V v_s_2458 = heff_field(v_x2_2456, 1);
          V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_248_24ETag, TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2457}), v_s_2458});
        }
        default: return heff_nomatch(v_x2_2456);
        }
      }
      case TAG_EMatch: {
        V v_ru_24it1_248_24EMatch = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2462)) {
        case TAG_MkPair: {
          V v_x_2463 = heff_field(v_x2_2462, 0);
          V v_s_2464 = heff_field(v_x2_2462, 1);
          heff_take_n(v_x2_2462, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2463}), v_s_2464});
        }
        default: return heff_nomatch(v_x2_2462);
        }
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2467 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2467)) {
        case TAG_MkPair: {
          V v_x_2468 = heff_field(v_x2_2467, 0);
          V v_s_2469 = heff_field(v_x2_2467, 1);
          V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2468}), v_s_2469});
        }
        default: return heff_nomatch(v_x2_2467);
        }
      }
      case TAG_EPrimCall: {
        V v_ru_24it1_248_24EPrimCall = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2473)) {
        case TAG_MkPair: {
          V v_x_2474 = heff_field(v_x2_2473, 0);
          V v_s_2475 = heff_field(v_x2_2473, 1);
          heff_take_n(v_x2_2473, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2474}), v_s_2475});
        }
        default: return heff_nomatch(v_x2_2473);
        }
      }
      case TAG_ECall: {
        V v_ru_24it1_248_24ECall = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2479)) {
        case TAG_MkPair: {
          V v_x_2480 = heff_field(v_x2_2479, 0);
          V v_s_2481 = heff_field(v_x2_2479, 1);
          heff_take_n(v_x2_2479, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2480}), v_s_2481});
        }
        default: return heff_nomatch(v_x2_2479);
        }
      }
      case TAG_EInt: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2484 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2484)) {
        case TAG_MkPair: {
          V v_x_2485 = heff_field(v_x2_2484, 0);
          V v_s_2486 = heff_field(v_x2_2484, 1);
          V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2485}), v_s_2486});
        }
        default: return heff_nomatch(v_x2_2484);
        }
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_248, 0ULL, 1);
        V v_m_2488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2489)) {
        case TAG_MkPair: {
          V v_x_2490 = heff_field(v_x2_2489, 0);
          V v_s_2491 = heff_field(v_x2_2489, 1);
          V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2490}), v_s_2491});
        }
        default: return heff_nomatch(v_x2_2489);
        }
      }
      case TAG_EStr: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2494 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2494)) {
        case TAG_MkPair: {
          V v_x_2495 = heff_field(v_x2_2494, 0);
          V v_s_2496 = heff_field(v_x2_2494, 1);
          V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2495}), v_s_2496});
        }
        default: return heff_nomatch(v_x2_2494);
        }
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_2498 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2499)) {
        case TAG_MkPair: {
          V v_x_24100 = heff_field(v_x2_2499, 0);
          V v_s_24101 = heff_field(v_x2_2499, 1);
          V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24100}), v_s_24101});
        }
        default: return heff_nomatch(v_x2_2499);
        }
      }
      case TAG_EFixed: {
        V v_ru_24it1_248_24EFixed = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24105 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24105)) {
        case TAG_MkPair: {
          V v_x_24106 = heff_field(v_x2_24105, 0);
          V v_s_24107 = heff_field(v_x2_24105, 1);
          heff_take_n(v_x2_24105, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24EFixed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24106}), v_s_24107});
        }
        default: return heff_nomatch(v_x2_24105);
        }
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_248, 0ULL, 1);
        V v_m_24109 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24110)) {
        case TAG_MkPair: {
          V v_x_24111 = heff_field(v_x2_24110, 0);
          V v_s_24112 = heff_field(v_x2_24110, 1);
          V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24111}), v_s_24112});
        }
        default: return heff_nomatch(v_x2_24110);
        }
      }
      case TAG_EAbandon: {
        V v_m_24113 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24114)) {
        case TAG_MkPair: {
          V v_x_24115 = heff_field(v_x2_24114, 0);
          V v_s_24116 = heff_field(v_x2_24114, 1);
          V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24115}), v_s_24116});
        }
        default: return heff_nomatch(v_x2_24114);
        }
      }
      case TAG_EBool: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24119)) {
        case TAG_MkPair: {
          V v_x_24120 = heff_field(v_x2_24119, 0);
          V v_s_24121 = heff_field(v_x2_24119, 1);
          V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24120}), v_s_24121});
        }
        default: return heff_nomatch(v_x2_24119);
        }
      }
      case TAG_ESet: {
        V v_ys_24122 = heff_field(v_it1_248, 0);
        V v_a2_24123 = heff_field(v_it1_248, 1);
        V v_body_24124 = heff_field(v_it1_248, 2);
        V v_ru_24it1_248_24ESet = heff_take_reuse_n(v_it1_248, 7ULL, 3);
        heff_drop(v_x_241);
        heff_drop(v_a_242);
        heff_drop(v_b_243);
        V v_m_24125 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_body_24124}));
        V v_x2_24126 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24126)) {
        case TAG_MkPair: {
          V v_x_24127 = heff_field(v_x2_24126, 0);
          V v_s_24128 = heff_field(v_x2_24126, 1);
          V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_248_24ESet, TAG_ESet, 3, (V[]){v_ys_24122, v_a2_24123, v_x_24127}), v_s_24128});
        }
        default: return heff_nomatch(v_x2_24126);
        }
      }
      case TAG_EValues: {
        heff_take_n(v_it1_248, 0ULL, 1);
        V v_m_24130 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24131)) {
        case TAG_MkPair: {
          V v_x_24132 = heff_field(v_x2_24131, 0);
          V v_s_24133 = heff_field(v_x2_24131, 1);
          V v_ru_24x2_24131_24MkPair = heff_take_reuse_n(v_x2_24131, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_24131_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24132}), v_s_24133});
        }
        default: return heff_nomatch(v_x2_24131);
        }
      }
      case TAG_EFix: {
        V v_ru_24it1_248_24EFix = heff_take_reuse_n(v_it1_248, 0ULL, 2);
        V v_m_24136 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_24137 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_24137)) {
        case TAG_MkPair: {
          V v_x_24138 = heff_field(v_x2_24137, 0);
          V v_s_24139 = heff_field(v_x2_24137, 1);
          heff_take_n(v_x2_24137, 3ULL, 2);
          return heff_tag_at_n(v_ru_24it1_248_24EFix, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24138}), v_s_24139});
        }
        default: return heff_nomatch(v_x2_24137);
        }
      }
      default: return heff_nomatch(v_it1_248);
      }
    } else {
      heff_drop(v_field_247);
      V v_m_24140 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
      V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x2_24141)) {
      case TAG_MkPair: {
        V v_x_24142 = heff_field(v_x2_24141, 0);
        V v_s_24143 = heff_field(v_x2_24141, 1);
        V v_ru_24x2_24141_24MkPair = heff_take_reuse_n(v_x2_24141, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24142}), v_s_24143});
      }
      default: return heff_nomatch(v_x2_24141);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2esetGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esetGiven(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedOn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ehandedOn(V v_kinds_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_ys_247 = heff_field(v_a_242, 0);
    V v_body_248 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    V v_ret_24bool = heff_bool((heff_intLe_c_lent(v_o_244, MK_INT(2LL), 2) && ({ V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_ys_247), heff_dup(v_body_248)}), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), heff_dup(v_t_249))); int c_ = (heff_intLt_c_lent(MK_INT(160LL), v_x_2410, 1) ? 0 : ({ V v_t_2411 = heff_tr(heff_call(((V)&g_list_2eany_24s604143829x1495140576_clo), 1, (V[]){heff_dup(v_kinds_240)})); int c_ = ({ V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2448 = (g_heff_2ecompile_2esimplify_2ecallsW(v_x_241, heff_dup(v_t_2411), MK_INT(0LL), heff_dup(v_t_2412))); int c_ = heff_intEq_c_lent(v_t_2448, v_o_244, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; })); heff_drop(v_x_2410); c_; }); heff_drop(v_t_249); c_; })));
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    heff_drop(v_ys_247);
    heff_drop(v_body_248);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_242, 0ULL, 4);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedOn(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244, V v_s_245) {
top: ;
  if (heff_intEq_c_lent(v_o_244, MK_INT(0LL), 2)) {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_b_243, v_s_245});
  } else {
    V v_t_2445;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if (((heff_dup(v_t_2445) == NTAG(TAG_True)) || heff_intEq_c_lent(v_o_244, MK_INT(1LL), 2))) {
      heff_drop(v_o_244);
      heff_drop(v_t_2445);
      V v_m_2446 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(g_std_2emap_2eempty_get()), v_x_241, v_a_242));
      V v_t_2447 = (g_std_2emap_2esize(v_m_2446));
      V v_t_2448;
      if (heff_intEq_c(v_t_2447, MK_INT(0LL))) {
        heff_drop(v_m_2446);
        v_t_2448 = v_b_243;
      } else {
        v_t_2448 = ({ V a_0 = v_m_2446; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2446); r_; });
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_t_2448, v_s_245});
    } else {
      heff_drop(v_t_2445);
      V v_t_2449 = (g_heff_2ecompile_2eir_2eisValue(v_a_242));
      V v_t_2458;
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_x_2451 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2450));
        if (!heff_intLt_c_lent(MK_INT(12LL), v_x_2451, 1)) {
          heff_drop(v_o_244);
          heff_drop(v_x_2451);
          v_t_2458 = NTAG(TAG_True);
        } else {
          heff_drop(v_x_2451);
          V v_t_2452;
          if (heff_intLe_c_lent(v_o_244, MK_INT(4LL), 2)) {
            v_t_2452 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_242)));
          } else {
            v_t_2452 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
            heff_drop(v_o_244);
            heff_drop(v_t_2452);
            v_t_2458 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2452);
            if (heff_intLe_c_lent(v_o_244, MK_INT(8LL), 2)) {
              V v_t_2453 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_a_242)));
              if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
                heff_drop(v_o_244);
                heff_drop(v_t_2453);
                v_t_2458 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2453);
                V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
                V v_t_2455 = (g_heff_2ecompile_2esimplify_2ehandedOn(v_t_2454, v_x_241, heff_dup(v_a_242), heff_dup(v_b_243), heff_dup(v_o_244)));
                if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
                  heff_drop(v_o_244);
                  heff_drop(v_t_2455);
                  v_t_2458 = NTAG(TAG_True);
                } else {
                  heff_drop(v_t_2455);
                  v_t_2458 = (g_heff_2ecompile_2esimplify_2erunsGiven(v_x_241, heff_dup(v_a_242), heff_dup(v_b_243), v_o_244));
                }
              }
            } else {
              V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
              V v_t_2457 = (g_heff_2ecompile_2esimplify_2ehandedOn(v_t_2456, v_x_241, heff_dup(v_a_242), heff_dup(v_b_243), heff_dup(v_o_244)));
              if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
                heff_drop(v_o_244);
                heff_drop(v_t_2457);
                v_t_2458 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2457);
                v_t_2458 = (g_heff_2ecompile_2esimplify_2erunsGiven(v_x_241, heff_dup(v_a_242), heff_dup(v_b_243), v_o_244));
              }
            }
          }
        }
      } else {
        heff_drop(v_o_244);
        heff_drop(v_t_2449);
        v_t_2458 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop(v_t_2458);
        V v_m_2459 = ({ V a_0 = v_x_241; V a_1 = v_a_242; V a_2 = v_b_243; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_241); r_; });
        V v_x2_2460 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_245}));
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_MkPair: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          V v_s_2462 = heff_field(v_x2_2460, 1);
          heff_take_n(v_x2_2460, 3ULL, 2);
          return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_x_2461, v_s_2462});
        }
        default: return heff_nomatch(v_x2_2460);
        }
      } else {
        heff_drop(v_t_2458);
        V v_m_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2464 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_245}));
        switch (heff_tag_of(v_x2_2464)) {
        case TAG_MkPair: {
          V v_x_2465 = heff_field(v_x2_2464, 0);
          V v_s_2466 = heff_field(v_x2_2464, 1);
          V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
          HeffT2 v_t_2467 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_x_2465)));
          {
            V v_field_2469 = v_t_2467.f[1];
            int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
            V v_t_2471;
            if ((v_tag_2468 == ((int64_t)0ULL))) {
              heff_drop(v_x_241);
              heff_drop(v_a_242);
              heff_drop(v_x_2465);
              V v_x_2470 = v_field_2469;
              v_t_2471 = v_x_2470;
            } else {
              heff_drop(v_field_2469);
              v_t_2471 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2465});
            }
            return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){v_t_2471, v_s_2466});
          }
        }
        default: return heff_nomatch(v_x2_2464);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V v_base_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_fuel_243 = heff_take_field(v_s_241, 1);
  V v_defs_244 = heff_take_field(v_s_241, 2);
  V v_safe_245 = heff_take_field(v_s_241, 3);
  V v_base_246 = heff_take_field(v_s_241, 4);
  V v_total_247 = heff_take_field(v_s_241, 5);
  V v_plain_248 = heff_take_field(v_s_241, 6);
  V v_sp_249 = heff_take_field(v_s_241, 7);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  V v_n_2411 = v_supply_242;
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0), heff_intShow(heff_dup(v_n_2411)));
  V v_f_2413 = heff_strAppend(v_base_240, v_t_2412);
  V v_f_2414 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_intAdd(v_n_2411, MK_INT(1LL)), v_fuel_243, v_defs_244, v_safe_245, v_base_246, v_total_247, v_plain_248, v_sp_249, v_kp_2410});
  return ((HeffT2){{v_f_2413, v_f_2414}});
}
Clo g_heff_2ecompile_2esimplify_2efewerThan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efewerThan_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efewerThan(V v_argv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_240));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_t_247, v_t_248, 0));
      heff_drop(v_t_247);
      heff_drop(v_t_248);
      return v_ret_24bool;
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efewerThan(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str0, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str1, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str2, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str3, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str5, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str6, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str8, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str9, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str10, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str11, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str12, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str13, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str14, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str15, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str16, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str17, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str18, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str19, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str20, 1, "t");
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam42(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldBound(V v_tag_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_tag_240);
    V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam0, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam1, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_tag_240);
    V v_t_2415 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam2, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2415);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam3, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ELam: {
    heff_drop(v_tag_240);
    V v_t_2428 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam4, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2428);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam5, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EApp: {
    heff_drop(v_tag_240);
    V v_t_2441 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam6, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2441);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam7, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ELet: {
    V v_y_2452 = heff_field(v_a_241, 0);
    V v_e_2453 = heff_field(v_a_241, 1);
    V v_c_2454 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    V v_m_2455 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(v_tag_240, v_c_2454));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam8, 1, 3, (V[]){v_m_2455, v_y_2452, v_e_2453});
  }
  case TAG_ERecord: {
    heff_drop(v_tag_240);
    V v_t_2469 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam9, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam10, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EProj: {
    heff_drop(v_tag_240);
    V v_t_2484 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam11, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam12, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ETag: {
    V v_a1_2495 = heff_field(v_a_241, 0);
    V v_argv_2496 = heff_field(v_a_241, 1);
    V v_ts_2497 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    return heff_tail(v_tag_240, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_a1_2495, v_argv_2496, v_ts_2497})});
  }
  case TAG_EMatch: {
    heff_drop(v_tag_240);
    V v_t_24100 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
      heff_drop(v_t_24100);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam13, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24100);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam14, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_tag_240);
    V v_t_24112 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
      heff_drop(v_t_24112);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam15, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24112);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam16, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EPrimCall: {
    heff_drop(v_tag_240);
    V v_t_24125 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
      heff_drop(v_t_24125);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam17, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24125);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam18, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ECall: {
    heff_drop(v_tag_240);
    V v_t_24138 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24138) == NTAG(TAG_True))) {
      heff_drop(v_t_24138);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam19, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24138);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam20, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EInt: {
    heff_drop(v_tag_240);
    V v_t_24150 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24150) == NTAG(TAG_True))) {
      heff_drop(v_t_24150);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam21, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24150);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam22, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFloat: {
    heff_drop(v_tag_240);
    V v_t_24162 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
      heff_drop(v_t_24162);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam23, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24162);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam24, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EStr: {
    heff_drop(v_tag_240);
    V v_t_24174 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24174) == NTAG(TAG_True))) {
      heff_drop(v_t_24174);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam25, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24174);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam26, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EBytes: {
    heff_drop(v_tag_240);
    V v_t_24186 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24186) == NTAG(TAG_True))) {
      heff_drop(v_t_24186);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam27, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24186);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam28, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFixed: {
    heff_drop(v_tag_240);
    V v_t_24199 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24199) == NTAG(TAG_True))) {
      heff_drop(v_t_24199);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam29, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24199);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam30, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFloat32: {
    heff_drop(v_tag_240);
    V v_t_24211 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
      heff_drop(v_t_24211);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam31, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24211);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam32, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_tag_240);
    V v_t_24222 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24222) == NTAG(TAG_True))) {
      heff_drop(v_t_24222);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam33, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24222);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam34, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EBool: {
    heff_drop(v_tag_240);
    V v_t_24234 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24234) == NTAG(TAG_True))) {
      heff_drop(v_t_24234);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam35, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24234);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam36, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ESet: {
    heff_drop(v_tag_240);
    V v_t_24248 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24248) == NTAG(TAG_True))) {
      heff_drop(v_t_24248);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam37, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24248);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam38, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EValues: {
    heff_drop(v_tag_240);
    V v_t_24260 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24260) == NTAG(TAG_True))) {
      heff_drop(v_t_24260);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam39, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24260);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam40, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFix: {
    heff_drop(v_tag_240);
    V v_t_24273 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24273) == NTAG(TAG_True))) {
      heff_drop(v_t_24273);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam41, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24273);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam42, 1, 1, (V[]){v_a_241});
    }
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_s_244});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str0), v_s_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2410})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_s_2411});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_s_2416});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str1), v_s_2418));
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_x_2422 = v_field_2420;
    V v_s_2423 = v_field_2421;
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2422), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2422})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_s_2423});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_s_2429});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str2), v_s_2431));
  {
    V v_field_2433 = v_t_2432.f[0];
    V v_field_2434 = v_t_2432.f[1];
    V v_x_2435 = v_field_2433;
    V v_s_2436 = v_field_2434;
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2435), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2435})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_s_2436});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam6(V self, V *args) {
  V v_s_2442 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str3), v_s_2444));
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_x_2448 = v_field_2446;
    V v_s_2449 = v_field_2447;
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2448), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2448})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2449});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam8(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_y_2452 = heff_env(self)[1];
  V v_e_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_MkPair: {
      V v_x_2460 = heff_dup(heff_field(v_x_2458, 0));
      v_t_2462 = v_x_2460;
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_y_2452, v_e_2453}), v_t_2462});
    V v_t_2466;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_MkPair: {
      V v_y_2465 = heff_field(v_x_2458, 1);
      heff_take_n(v_x_2458, 2ULL, 2);
      v_t_2466 = v_y_2465;
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_t_2466}), v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam9(V self, V *args) {
  V v_s_2470 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2471, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam10(V self, V *args) {
  V v_s_2472 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2473 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str4), v_s_2472));
  {
    V v_field_2474 = v_t_2473.f[0];
    V v_field_2475 = v_t_2473.f[1];
    V v_x_2476 = v_field_2474;
    V v_s_2477 = v_field_2475;
    V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2476), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2479 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2476})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2479, v_s_2477});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam11(V self, V *args) {
  V v_s_2485 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_s_2485});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam12(V self, V *args) {
  V v_s_2487 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2488 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str5), v_s_2487));
  {
    V v_field_2489 = v_t_2488.f[0];
    V v_field_2490 = v_t_2488.f[1];
    V v_x_2491 = v_field_2489;
    V v_s_2492 = v_field_2490;
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2491), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2494 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2493, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2491})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_s_2492});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam13(V self, V *args) {
  V v_s_24101 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24102, v_s_24101});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam14(V self, V *args) {
  V v_s_24103 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24104 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str6), v_s_24103));
  {
    V v_field_24105 = v_t_24104.f[0];
    V v_field_24106 = v_t_24104.f[1];
    V v_x_24107 = v_field_24105;
    V v_s_24108 = v_field_24106;
    V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24107), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24109, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24107})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24110, v_s_24108});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam15(V self, V *args) {
  V v_s_24113 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24114, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam16(V self, V *args) {
  V v_s_24115 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24116 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str7), v_s_24115));
  {
    V v_field_24117 = v_t_24116.f[0];
    V v_field_24118 = v_t_24116.f[1];
    V v_x_24119 = v_field_24117;
    V v_s_24120 = v_field_24118;
    V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24119), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24122 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24121, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24119})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24122, v_s_24120});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam17(V self, V *args) {
  V v_s_24126 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24127 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24127, v_s_24126});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam18(V self, V *args) {
  V v_s_24128 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24129 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str8), v_s_24128));
  {
    V v_field_24130 = v_t_24129.f[0];
    V v_field_24131 = v_t_24129.f[1];
    V v_x_24132 = v_field_24130;
    V v_s_24133 = v_field_24131;
    V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24132), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24135 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24134, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24132})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24135, v_s_24133});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam19(V self, V *args) {
  V v_s_24139 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24140 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24140, v_s_24139});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam20(V self, V *args) {
  V v_s_24141 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24142 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str9), v_s_24141));
  {
    V v_field_24143 = v_t_24142.f[0];
    V v_field_24144 = v_t_24142.f[1];
    V v_x_24145 = v_field_24143;
    V v_s_24146 = v_field_24144;
    V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24145), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24148 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24147, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24145})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24148, v_s_24146});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam21(V self, V *args) {
  V v_s_24151 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24152 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24152, v_s_24151});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam22(V self, V *args) {
  V v_s_24153 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24154 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str10), v_s_24153));
  {
    V v_field_24155 = v_t_24154.f[0];
    V v_field_24156 = v_t_24154.f[1];
    V v_x_24157 = v_field_24155;
    V v_s_24158 = v_field_24156;
    V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24157), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24160 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24159, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24157})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24160, v_s_24158});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam23(V self, V *args) {
  V v_s_24163 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24164 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24164, v_s_24163});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam24(V self, V *args) {
  V v_s_24165 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24166 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str11), v_s_24165));
  {
    V v_field_24167 = v_t_24166.f[0];
    V v_field_24168 = v_t_24166.f[1];
    V v_x_24169 = v_field_24167;
    V v_s_24170 = v_field_24168;
    V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24169), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24172 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24171, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24169})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24172, v_s_24170});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam25(V self, V *args) {
  V v_s_24175 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24176 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24176, v_s_24175});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam26(V self, V *args) {
  V v_s_24177 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24178 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str12), v_s_24177));
  {
    V v_field_24179 = v_t_24178.f[0];
    V v_field_24180 = v_t_24178.f[1];
    V v_x_24181 = v_field_24179;
    V v_s_24182 = v_field_24180;
    V v_t_24183 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24181), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24184 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24183, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24181})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24184, v_s_24182});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam27(V self, V *args) {
  V v_s_24187 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24188 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24188, v_s_24187});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam28(V self, V *args) {
  V v_s_24189 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24190 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str13), v_s_24189));
  {
    V v_field_24191 = v_t_24190.f[0];
    V v_field_24192 = v_t_24190.f[1];
    V v_x_24193 = v_field_24191;
    V v_s_24194 = v_field_24192;
    V v_t_24195 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24193), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24196 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24195, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24193})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24196, v_s_24194});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam29(V self, V *args) {
  V v_s_24200 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24201 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24201, v_s_24200});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam30(V self, V *args) {
  V v_s_24202 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24203 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str14), v_s_24202));
  {
    V v_field_24204 = v_t_24203.f[0];
    V v_field_24205 = v_t_24203.f[1];
    V v_x_24206 = v_field_24204;
    V v_s_24207 = v_field_24205;
    V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24206), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24209 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24208, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24206})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24209, v_s_24207});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam31(V self, V *args) {
  V v_s_24212 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24213, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam32(V self, V *args) {
  V v_s_24214 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24215 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str15), v_s_24214));
  {
    V v_field_24216 = v_t_24215.f[0];
    V v_field_24217 = v_t_24215.f[1];
    V v_x_24218 = v_field_24216;
    V v_s_24219 = v_field_24217;
    V v_t_24220 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24218), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24221 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24220, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24218})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24221, v_s_24219});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam33(V self, V *args) {
  V v_s_24223 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24224 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24224, v_s_24223});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam34(V self, V *args) {
  V v_s_24225 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24226 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str16), v_s_24225));
  {
    V v_field_24227 = v_t_24226.f[0];
    V v_field_24228 = v_t_24226.f[1];
    V v_x_24229 = v_field_24227;
    V v_s_24230 = v_field_24228;
    V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24229), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24232 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24231, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24229})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24232, v_s_24230});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam35(V self, V *args) {
  V v_s_24235 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24236 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24236, v_s_24235});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam36(V self, V *args) {
  V v_s_24237 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24238 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str17), v_s_24237));
  {
    V v_field_24239 = v_t_24238.f[0];
    V v_field_24240 = v_t_24238.f[1];
    V v_x_24241 = v_field_24239;
    V v_s_24242 = v_field_24240;
    V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24241), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24241})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24244, v_s_24242});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam37(V self, V *args) {
  V v_s_24249 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24250 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24250, v_s_24249});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam38(V self, V *args) {
  V v_s_24251 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24252 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str18), v_s_24251));
  {
    V v_field_24253 = v_t_24252.f[0];
    V v_field_24254 = v_t_24252.f[1];
    V v_x_24255 = v_field_24253;
    V v_s_24256 = v_field_24254;
    V v_t_24257 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24255), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24258 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24257, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24255})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24258, v_s_24256});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam39(V self, V *args) {
  V v_s_24261 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24262 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24262, v_s_24261});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam40(V self, V *args) {
  V v_s_24263 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24264 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str19), v_s_24263));
  {
    V v_field_24265 = v_t_24264.f[0];
    V v_field_24266 = v_t_24264.f[1];
    V v_x_24267 = v_field_24265;
    V v_s_24268 = v_field_24266;
    V v_t_24269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24267), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24270 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24269, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24267})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24270, v_s_24268});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam41(V self, V *args) {
  V v_s_24274 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24275 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24275, v_s_24274});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam42(V self, V *args) {
  V v_s_24276 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24277 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str20), v_s_24276));
  {
    V v_field_24278 = v_t_24277.f[0];
    V v_field_24279 = v_t_24277.f[1];
    V v_x_24280 = v_field_24278;
    V v_s_24281 = v_field_24279;
    V v_t_24282 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24280), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24283 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24282, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24280})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24283, v_s_24281});
  }
}
Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2erecordSplit(V v_r_240, V v_x_241, V v_x3_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2425}), v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  case TAG_ELet: {
    V v_m_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      V v_s_2433 = heff_field(v_x2_2431, 1);
      V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2432}), v_s_2433});
    }
    default: return heff_nomatch(v_x2_2431);
    }
  }
  case TAG_ERecord: {
    V v_fs_2434 = heff_field(v_x3_242, 0);
    V v_ts_2435 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ERecord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2436 = (g_list_2emap_24s366344330x1145113647(heff_dup(v_fs_2434)));
    V v_x2_2437 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_t_2436, v_z_244));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
      V v_t_2442;
      switch (heff_tag_of(v_x_2438)) {
      case TAG_MkPair: {
        V v_y_2441 = heff_dup(heff_field(v_x_2438, 1));
        v_t_2442 = v_y_2441;
        break;
      }
      default: heff_nomatch(v_x_2438);
      }
      V v_t_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2434, v_t_2442));
      V v_t_2444 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, heff_tag_at_n(v_ru_24x3_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2443, v_ts_2435}), v_b_243});
      V v_m_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2444}));
      V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_s_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        V v_t_2451;
        switch (heff_tag_of(v_x_2438)) {
        case TAG_MkPair: {
          V v_x_2449 = heff_field(v_x_2438, 0);
          heff_take_n(v_x_2438, 1ULL, 2);
          v_t_2451 = v_x_2449;
          break;
        }
        default: heff_nomatch(v_x_2438);
        }
        V v_x_2452 = ({ V a_0 = v_t_2451; V a_1 = v_x_2447; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2451); r_; });
        return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_x_2452, v_s_2448});
      }
      default: return heff_nomatch(v_x2_2446);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  case TAG_EProj: {
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2458 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_s_2460 = heff_field(v_x2_2458, 1);
      V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2459}), v_s_2460});
    }
    default: return heff_nomatch(v_x2_2458);
    }
  }
  case TAG_ETag: {
    V v_m_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_s_2467 = heff_field(v_x2_2465, 1);
      V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2466}), v_s_2467});
    }
    default: return heff_nomatch(v_x2_2465);
    }
  }
  case TAG_EMatch: {
    V v_m_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2472}), v_s_2473});
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  case TAG_EPrim: {
    V v_m_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_s_2478 = heff_field(v_x2_2476, 1);
      V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2477}), v_s_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2483}), v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  case TAG_ECall: {
    V v_m_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  case TAG_EInt: {
    V v_m_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_s_2495 = heff_field(v_x2_2493, 1);
      V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2494}), v_s_2495});
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  case TAG_EFloat: {
    V v_m_2497 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2498 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_MkPair: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_s_24100 = heff_field(v_x2_2498, 1);
      V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2499}), v_s_24100});
    }
    default: return heff_nomatch(v_x2_2498);
    }
  }
  case TAG_EStr: {
    V v_m_24102 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24103 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24103)) {
    case TAG_MkPair: {
      V v_x_24104 = heff_field(v_x2_24103, 0);
      V v_s_24105 = heff_field(v_x2_24103, 1);
      V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24104}), v_s_24105});
    }
    default: return heff_nomatch(v_x2_24103);
    }
  }
  case TAG_EBytes: {
    V v_m_24107 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_s_24110 = heff_field(v_x2_24108, 1);
      V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24109}), v_s_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  case TAG_EFixed: {
    V v_m_24113 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24115}), v_s_24116});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  case TAG_EFloat32: {
    V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_MkPair: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_s_24121 = heff_field(v_x2_24119, 1);
      V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24120}), v_s_24121});
    }
    default: return heff_nomatch(v_x2_24119);
    }
  }
  case TAG_EAbandon: {
    V v_m_24122 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24123 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24123)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_x2_24123, 0);
      V v_s_24125 = heff_field(v_x2_24123, 1);
      V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24124}), v_s_24125});
    }
    default: return heff_nomatch(v_x2_24123);
    }
  }
  case TAG_EBool: {
    V v_m_24127 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24128 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24128)) {
    case TAG_MkPair: {
      V v_x_24129 = heff_field(v_x2_24128, 0);
      V v_s_24130 = heff_field(v_x2_24128, 1);
      V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24129}), v_s_24130});
    }
    default: return heff_nomatch(v_x2_24128);
    }
  }
  case TAG_ESet: {
    V v_m_24134 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24135 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24135)) {
    case TAG_MkPair: {
      V v_x_24136 = heff_field(v_x2_24135, 0);
      V v_s_24137 = heff_field(v_x2_24135, 1);
      V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24136}), v_s_24137});
    }
    default: return heff_nomatch(v_x2_24135);
    }
  }
  case TAG_EValues: {
    V v_m_24139 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24140 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24140)) {
    case TAG_MkPair: {
      V v_x_24141 = heff_field(v_x2_24140, 0);
      V v_s_24142 = heff_field(v_x2_24140, 1);
      V v_ru_24x2_24140_24MkPair = heff_take_reuse_n(v_x2_24140, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24141}), v_s_24142});
    }
    default: return heff_nomatch(v_x2_24140);
    }
  }
  case TAG_EFix: {
    V v_m_24145 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24146 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24146)) {
    case TAG_MkPair: {
      V v_x_24147 = heff_field(v_x2_24146, 0);
      V v_s_24148 = heff_field(v_x2_24146, 1);
      V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24147}), v_s_24148});
    }
    default: return heff_nomatch(v_x2_24146);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordSplit(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esimpF_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2esimpF_str1, 5, "False");
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam103(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam104(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam105(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam106(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam107(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam108(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam109(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam110(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam111(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam112(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam113(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam114(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam115(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam116(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam117(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam118(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam119(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_g_244});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_241, 0);
    V v_b_249 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_249}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_e1_2418 = heff_field(v_e_241, 0);
    V v_argv_2419 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2418)) {
    case TAG_EVar: {
      V v_m_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2421, v_r_240, v_argv_2419});
    }
    case TAG_EGlobal: {
      V v_g_2431 = heff_field(v_e1_2418, 0);
      heff_take_n(v_e1_2418, 1ULL, 1);
      V v_m_2433 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam5, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam6, 1, 3, (V[]){v_m_2433, v_r_240, v_g_2431});
    }
    case TAG_ELam: {
      V v_m_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2440, v_r_240, v_argv_2419});
    }
    case TAG_EApp: {
      V v_e11_2450 = heff_dup(heff_field(v_e1_2418, 0));
      switch (heff_tag_of(v_e11_2450)) {
      case TAG_EVar: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2453, v_r_240, v_argv_2419});
      }
      case TAG_EGlobal: {
        V v_g_2463 = heff_field(v_e11_2450, 0);
        heff_take_n(v_e11_2450, 1ULL, 1);
        switch (heff_tag_of(v_e1_2418)) {
        case TAG_EApp: {
          V v_bs_2465 = heff_field(v_e1_2418, 1);
          heff_take_n(v_e1_2418, 2ULL, 2);
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2465, v_g_2463, v_argv_2419, v_r_240});
        }
        default: return heff_nomatch(v_e1_2418);
        }
      }
      case TAG_ELam: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2483, v_r_240, v_argv_2419});
      }
      case TAG_EApp: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2495, v_r_240, v_argv_2419});
      }
      case TAG_ELet: {
        heff_take_n(v_e11_2450, 0ULL, 3);
        V v_m_24108 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24108, v_r_240, v_argv_2419});
      }
      case TAG_ERecord: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24120 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24120, v_r_240, v_argv_2419});
      }
      case TAG_EProj: {
        heff_take_n(v_e11_2450, 0ULL, 4);
        V v_m_24134 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24134, v_r_240, v_argv_2419});
      }
      case TAG_ETag: {
        heff_take_n(v_e11_2450, 0ULL, 3);
        V v_m_24147 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24147, v_r_240, v_argv_2419});
      }
      case TAG_EMatch: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24159, v_r_240, v_argv_2419});
      }
      case TAG_EPrim: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24170, v_r_240, v_argv_2419});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24182, v_r_240, v_argv_2419});
      }
      case TAG_ECall: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24194 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24194, v_r_240, v_argv_2419});
      }
      case TAG_EInt: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24205 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24205, v_r_240, v_argv_2419});
      }
      case TAG_EFloat: {
        heff_take_na(v_e11_2450, 0ULL, 1);
        V v_m_24216 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24216, v_r_240, v_argv_2419});
      }
      case TAG_EStr: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24227 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24227, v_r_240, v_argv_2419});
      }
      case TAG_EBytes: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24238 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24238, v_r_240, v_argv_2419});
      }
      case TAG_EFixed: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24250 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24250, v_r_240, v_argv_2419});
      }
      case TAG_EFloat32: {
        heff_take_na(v_e11_2450, 0ULL, 1);
        V v_m_24261 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24261, v_r_240, v_argv_2419});
      }
      case TAG_EAbandon: {
        V v_m_24271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24271, v_r_240, v_argv_2419});
      }
      case TAG_EBool: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24282 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24282, v_r_240, v_argv_2419});
      }
      case TAG_ESet: {
        heff_take_n(v_e11_2450, 0ULL, 3);
        V v_m_24295 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24295, v_r_240, v_argv_2419});
      }
      case TAG_EValues: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        V v_m_24306 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24306, v_r_240, v_argv_2419});
      }
      case TAG_EFix: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        V v_m_24318 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24318, v_r_240, v_argv_2419});
      }
      default: return heff_nomatch(v_e11_2450);
      }
    }
    case TAG_ELet: {
      V v_m_24331 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24331, v_r_240, v_argv_2419});
    }
    case TAG_ERecord: {
      V v_m_24343 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24343, v_r_240, v_argv_2419});
    }
    case TAG_EProj: {
      V v_m_24357 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24357, v_r_240, v_argv_2419});
    }
    case TAG_ETag: {
      V v_m_24370 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24370, v_r_240, v_argv_2419});
    }
    case TAG_EMatch: {
      V v_m_24382 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24382, v_r_240, v_argv_2419});
    }
    case TAG_EPrim: {
      V v_m_24393 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24393, v_r_240, v_argv_2419});
    }
    case TAG_EPrimCall: {
      V v_m_24405 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24405, v_r_240, v_argv_2419});
    }
    case TAG_ECall: {
      V v_m_24417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24417, v_r_240, v_argv_2419});
    }
    case TAG_EInt: {
      V v_m_24428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24428, v_r_240, v_argv_2419});
    }
    case TAG_EFloat: {
      V v_m_24439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24439, v_r_240, v_argv_2419});
    }
    case TAG_EStr: {
      V v_m_24450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24450, v_r_240, v_argv_2419});
    }
    case TAG_EBytes: {
      V v_m_24461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam77, 1, 3, (V[]){v_m_24461, v_r_240, v_argv_2419});
    }
    case TAG_EFixed: {
      V v_m_24473 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam79, 1, 3, (V[]){v_m_24473, v_r_240, v_argv_2419});
    }
    case TAG_EFloat32: {
      V v_m_24484 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam81, 1, 3, (V[]){v_m_24484, v_r_240, v_argv_2419});
    }
    case TAG_EAbandon: {
      V v_m_24494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam83, 1, 3, (V[]){v_m_24494, v_r_240, v_argv_2419});
    }
    case TAG_EBool: {
      V v_m_24505 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam85, 1, 3, (V[]){v_m_24505, v_r_240, v_argv_2419});
    }
    case TAG_ESet: {
      V v_m_24518 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam87, 1, 3, (V[]){v_m_24518, v_r_240, v_argv_2419});
    }
    case TAG_EValues: {
      V v_m_24529 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam89, 1, 3, (V[]){v_m_24529, v_r_240, v_argv_2419});
    }
    case TAG_EFix: {
      V v_m_24541 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam91, 1, 3, (V[]){v_m_24541, v_r_240, v_argv_2419});
    }
    default: return heff_nomatch(v_e1_2418);
    }
  }
  case TAG_ELet: {
    V v_x_24551 = heff_field(v_e_241, 0);
    V v_a_24552 = heff_field(v_e_241, 1);
    V v_b_24553 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24554 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24552}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam93, 1, 4, (V[]){v_m_24554, v_r_240, v_x_24551, v_b_24553});
  }
  case TAG_ERecord: {
    V v_fs_24560 = heff_field(v_e_241, 0);
    V v_ts_24561 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24570 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_r_240}), v_fs_24560));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam96, 1, 2, (V[]){v_m_24570, v_ts_24561});
  }
  case TAG_EProj: {
    V v_e2_24575 = heff_field(v_e_241, 0);
    V v_l_24576 = heff_field(v_e_241, 1);
    V v_sh_24577 = heff_field(v_e_241, 2);
    V v_t_24578 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_24579 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e2_24575}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam97, 1, 5, (V[]){v_m_24579, v_r_240, v_l_24576, v_sh_24577, v_t_24578});
  }
  case TAG_ETag: {
    V v_t_24584 = heff_field(v_e_241, 0);
    V v_argv_24585 = heff_field(v_e_241, 1);
    V v_ts_24586 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24588 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam98, 1, 1, (V[]){v_r_240}), v_argv_24585));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam99, 1, 3, (V[]){v_m_24588, v_t_24584, v_ts_24586});
  }
  case TAG_EMatch: {
    V v_s_24593 = heff_field(v_e_241, 0);
    V v_arms_24594 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24595 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24593}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam100, 1, 3, (V[]){v_m_24595, v_r_240, v_arms_24594});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam103, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24615 = heff_field(v_e_241, 0);
    V v_argv_24616 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24618 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam104, 1, 1, (V[]){v_r_240}), v_argv_24616));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam105, 1, 2, (V[]){v_m_24618, v_p_24615});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam106, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam107, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam108, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam109, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam110, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam111, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam112, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam113, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    V v_c_24641 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_m_24643 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam114, 1, 1, (V[]){v_r_240}), v_c_24641));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam115, 1, 1, (V[]){v_m_24643});
  }
  case TAG_ESet: {
    V v_xs_24658 = heff_field(v_e_241, 0);
    V v_a_24659 = heff_field(v_e_241, 1);
    V v_b_24660 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24661 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24659}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam116, 1, 4, (V[]){v_m_24661, v_r_240, v_b_24660, v_xs_24658});
  }
  case TAG_EValues: {
    V v_es_24795 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_m_24797 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam117, 1, 1, (V[]){v_r_240}), v_es_24795));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam118, 1, 1, (V[]){v_m_24797});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam119, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_g_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_245, 2), v_g_244));
  V v_x_247 = (g_heff_2ecompile_2esimplify_2eglobalLiteral(v_g_244, v_t_246));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_s_2414, 7)), 1, 7);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2elam(v_xs_248, v_x_2413));
    V v_x_2417 = ({ V a_0 = v_t_2415; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2426 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    V v_m_2427 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2425}));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_s_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2424;
      heff_room[1] = v_x_2429;
      heff_room[2] = v_s_2430;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_a_2432 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2431});
    heff_room[1] = v_x_2436;
    heff_room[2] = v_s_2437;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2445 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    heff_take_n(v_x2_2442, 3ULL, 2);
    V v_m_2446 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_s_2444}));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_s_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2443;
      heff_room[1] = v_x_2448;
      heff_room[2] = v_s_2449;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2458 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    heff_take_n(v_x2_2455, 3ULL, 2);
    V v_m_2459 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_2460 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2457}));
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_MkPair: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_s_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2456;
      heff_room[1] = v_x_2461;
      heff_room[2] = v_s_2462;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2460);
    }
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2465 = heff_env(self)[0];
  V v_g_2463 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_2465));
  V v_t_2468 = (g_heff_2ecompile_2esimplify_2etakesMore(heff_dup(v_s_2466), v_g_2463, v_t_2467));
  if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
    heff_drop(v_t_2468);
    V v_t_2469 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2465, v_argv_2419));
    V v_t_2470 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2463}), v_t_2469});
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_s_2466;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2468);
    V v_t_2471 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2463}), v_bs_2465});
    V v_m_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2471}));
    V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_s_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      V v_m_2477 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
      V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_s_2475}));
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_MkPair: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_s_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        V f_ = heff_get_n(v_r_240, 1, 4);
        heff_room[0] = v_x_2474;
        heff_room[1] = v_x_2479;
        heff_room[2] = v_s_2480;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_x2_2478);
      }
    }
    default: return heff_nomatch(v_x2_2473);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2488 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_s_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_s_2487 = heff_field(v_x2_2485, 1);
    heff_take_n(v_x2_2485, 3ULL, 2);
    V v_m_2489 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2487}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2486;
      heff_room[1] = v_x_2491;
      heff_room[2] = v_s_2492;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_24100 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    heff_take_n(v_x2_2497, 3ULL, 2);
    V v_m_24101 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24102 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_s_2499}));
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_MkPair: {
      V v_x_24103 = heff_field(v_x2_24102, 0);
      V v_s_24104 = heff_field(v_x2_24102, 1);
      heff_take_n(v_x2_24102, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2498;
      heff_room[1] = v_x_24103;
      heff_room[2] = v_s_24104;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24102);
    }
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24113 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_s_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_s_24112 = heff_field(v_x2_24110, 1);
    heff_take_n(v_x2_24110, 3ULL, 2);
    V v_m_24114 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_s_24112}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_s_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24111;
      heff_room[1] = v_x_24116;
      heff_room[2] = v_s_24117;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24125 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24125;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    heff_take_n(v_x2_24122, 3ULL, 2);
    V v_m_24126 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24127 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24124}));
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_s_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24123;
      heff_room[1] = v_x_24128;
      heff_room[2] = v_s_24129;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24139 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    heff_take_n(v_x2_24136, 3ULL, 2);
    V v_m_24140 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_s_24138}));
    switch (heff_tag_of(v_x2_24141)) {
    case TAG_MkPair: {
      V v_x_24142 = heff_field(v_x2_24141, 0);
      V v_s_24143 = heff_field(v_x2_24141, 1);
      heff_take_n(v_x2_24141, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24137;
      heff_room[1] = v_x_24142;
      heff_room[2] = v_s_24143;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24141);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24152 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24152;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_s_24151 = heff_field(v_x2_24149, 1);
    heff_take_n(v_x2_24149, 3ULL, 2);
    V v_m_24153 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24154 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_s_24151}));
    switch (heff_tag_of(v_x2_24154)) {
    case TAG_MkPair: {
      V v_x_24155 = heff_field(v_x2_24154, 0);
      V v_s_24156 = heff_field(v_x2_24154, 1);
      heff_take_n(v_x2_24154, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24150;
      heff_room[1] = v_x_24155;
      heff_room[2] = v_s_24156;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24154);
    }
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24164 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24164;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24160 = args[0];
  V v_m_24159 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24161 = heff_tr(heff_call(v_m_24159, 1, (V[]){v_s_24160}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_MkPair: {
    V v_x_24162 = heff_field(v_x2_24161, 0);
    V v_s_24163 = heff_field(v_x2_24161, 1);
    heff_take_n(v_x2_24161, 3ULL, 2);
    V v_m_24165 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24166 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24163}));
    switch (heff_tag_of(v_x2_24166)) {
    case TAG_MkPair: {
      V v_x_24167 = heff_field(v_x2_24166, 0);
      V v_s_24168 = heff_field(v_x2_24166, 1);
      heff_take_n(v_x2_24166, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24162;
      heff_room[1] = v_x_24167;
      heff_room[2] = v_s_24168;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24166);
    }
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24175 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24175;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_s_24171}));
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_s_24174 = heff_field(v_x2_24172, 1);
    heff_take_n(v_x2_24172, 3ULL, 2);
    V v_m_24176 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24177 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_s_24174}));
    switch (heff_tag_of(v_x2_24177)) {
    case TAG_MkPair: {
      V v_x_24178 = heff_field(v_x2_24177, 0);
      V v_s_24179 = heff_field(v_x2_24177, 1);
      heff_take_n(v_x2_24177, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24173;
      heff_room[1] = v_x_24178;
      heff_room[2] = v_s_24179;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24177);
    }
  }
  default: return heff_nomatch(v_x2_24172);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24187 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24187;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_s_24183}));
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_x_24185 = heff_field(v_x2_24184, 0);
    V v_s_24186 = heff_field(v_x2_24184, 1);
    heff_take_n(v_x2_24184, 3ULL, 2);
    V v_m_24188 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_s_24186}));
    switch (heff_tag_of(v_x2_24189)) {
    case TAG_MkPair: {
      V v_x_24190 = heff_field(v_x2_24189, 0);
      V v_s_24191 = heff_field(v_x2_24189, 1);
      heff_take_n(v_x2_24189, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24185;
      heff_room[1] = v_x_24190;
      heff_room[2] = v_s_24191;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24189);
    }
  }
  default: return heff_nomatch(v_x2_24184);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24199 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24199;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    heff_take_n(v_x2_24196, 3ULL, 2);
    V v_m_24200 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24201 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_s_24198}));
    switch (heff_tag_of(v_x2_24201)) {
    case TAG_MkPair: {
      V v_x_24202 = heff_field(v_x2_24201, 0);
      V v_s_24203 = heff_field(v_x2_24201, 1);
      heff_take_n(v_x2_24201, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24197;
      heff_room[1] = v_x_24202;
      heff_room[2] = v_s_24203;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24201);
    }
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24210 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24210;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24206}));
  switch (heff_tag_of(v_x2_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_x2_24207, 0);
    V v_s_24209 = heff_field(v_x2_24207, 1);
    heff_take_n(v_x2_24207, 3ULL, 2);
    V v_m_24211 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24212 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_s_24209}));
    switch (heff_tag_of(v_x2_24212)) {
    case TAG_MkPair: {
      V v_x_24213 = heff_field(v_x2_24212, 0);
      V v_s_24214 = heff_field(v_x2_24212, 1);
      heff_take_n(v_x2_24212, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24208;
      heff_room[1] = v_x_24213;
      heff_room[2] = v_s_24214;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24212);
    }
  }
  default: return heff_nomatch(v_x2_24207);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24221 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24221;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_s_24217}));
  switch (heff_tag_of(v_x2_24218)) {
  case TAG_MkPair: {
    V v_x_24219 = heff_field(v_x2_24218, 0);
    V v_s_24220 = heff_field(v_x2_24218, 1);
    heff_take_n(v_x2_24218, 3ULL, 2);
    V v_m_24222 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24223 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_s_24220}));
    switch (heff_tag_of(v_x2_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x2_24223, 0);
      V v_s_24225 = heff_field(v_x2_24223, 1);
      heff_take_n(v_x2_24223, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24219;
      heff_room[1] = v_x_24224;
      heff_room[2] = v_s_24225;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24223);
    }
  }
  default: return heff_nomatch(v_x2_24218);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24232 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_s_24228}));
  switch (heff_tag_of(v_x2_24229)) {
  case TAG_MkPair: {
    V v_x_24230 = heff_field(v_x2_24229, 0);
    V v_s_24231 = heff_field(v_x2_24229, 1);
    heff_take_n(v_x2_24229, 3ULL, 2);
    V v_m_24233 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_s_24231}));
    switch (heff_tag_of(v_x2_24234)) {
    case TAG_MkPair: {
      V v_x_24235 = heff_field(v_x2_24234, 0);
      V v_s_24236 = heff_field(v_x2_24234, 1);
      heff_take_n(v_x2_24234, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24230;
      heff_room[1] = v_x_24235;
      heff_room[2] = v_s_24236;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24234);
    }
  }
  default: return heff_nomatch(v_x2_24229);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24243 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_s_24239}));
  switch (heff_tag_of(v_x2_24240)) {
  case TAG_MkPair: {
    V v_x_24241 = heff_field(v_x2_24240, 0);
    V v_s_24242 = heff_field(v_x2_24240, 1);
    heff_take_n(v_x2_24240, 3ULL, 2);
    V v_m_24244 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_s_24242}));
    switch (heff_tag_of(v_x2_24245)) {
    case TAG_MkPair: {
      V v_x_24246 = heff_field(v_x2_24245, 0);
      V v_s_24247 = heff_field(v_x2_24245, 1);
      heff_take_n(v_x2_24245, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24241;
      heff_room[1] = v_x_24246;
      heff_room[2] = v_s_24247;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24245);
    }
  }
  default: return heff_nomatch(v_x2_24240);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24255 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24255;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_s_24251}));
  switch (heff_tag_of(v_x2_24252)) {
  case TAG_MkPair: {
    V v_x_24253 = heff_field(v_x2_24252, 0);
    V v_s_24254 = heff_field(v_x2_24252, 1);
    heff_take_n(v_x2_24252, 3ULL, 2);
    V v_m_24256 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_s_24254}));
    switch (heff_tag_of(v_x2_24257)) {
    case TAG_MkPair: {
      V v_x_24258 = heff_field(v_x2_24257, 0);
      V v_s_24259 = heff_field(v_x2_24257, 1);
      heff_take_n(v_x2_24257, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24253;
      heff_room[1] = v_x_24258;
      heff_room[2] = v_s_24259;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24257);
    }
  }
  default: return heff_nomatch(v_x2_24252);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24266 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24266;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24262 = args[0];
  V v_m_24261 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24263 = heff_tr(heff_call(v_m_24261, 1, (V[]){v_s_24262}));
  switch (heff_tag_of(v_x2_24263)) {
  case TAG_MkPair: {
    V v_x_24264 = heff_field(v_x2_24263, 0);
    V v_s_24265 = heff_field(v_x2_24263, 1);
    heff_take_n(v_x2_24263, 3ULL, 2);
    V v_m_24267 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_s_24265}));
    switch (heff_tag_of(v_x2_24268)) {
    case TAG_MkPair: {
      V v_x_24269 = heff_field(v_x2_24268, 0);
      V v_s_24270 = heff_field(v_x2_24268, 1);
      heff_take_n(v_x2_24268, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24264;
      heff_room[1] = v_x_24269;
      heff_room[2] = v_s_24270;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24268);
    }
  }
  default: return heff_nomatch(v_x2_24263);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24276 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24276;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24272 = args[0];
  V v_m_24271 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24273 = heff_tr(heff_call(v_m_24271, 1, (V[]){v_s_24272}));
  switch (heff_tag_of(v_x2_24273)) {
  case TAG_MkPair: {
    V v_x_24274 = heff_field(v_x2_24273, 0);
    V v_s_24275 = heff_field(v_x2_24273, 1);
    heff_take_n(v_x2_24273, 3ULL, 2);
    V v_m_24277 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_s_24275}));
    switch (heff_tag_of(v_x2_24278)) {
    case TAG_MkPair: {
      V v_x_24279 = heff_field(v_x2_24278, 0);
      V v_s_24280 = heff_field(v_x2_24278, 1);
      heff_take_n(v_x2_24278, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24274;
      heff_room[1] = v_x_24279;
      heff_room[2] = v_s_24280;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24278);
    }
  }
  default: return heff_nomatch(v_x2_24273);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24287 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24287;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24284 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_s_24283}));
  switch (heff_tag_of(v_x2_24284)) {
  case TAG_MkPair: {
    V v_x_24285 = heff_field(v_x2_24284, 0);
    V v_s_24286 = heff_field(v_x2_24284, 1);
    heff_take_n(v_x2_24284, 3ULL, 2);
    V v_m_24288 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24289 = heff_tr(heff_call(v_m_24288, 1, (V[]){v_s_24286}));
    switch (heff_tag_of(v_x2_24289)) {
    case TAG_MkPair: {
      V v_x_24290 = heff_field(v_x2_24289, 0);
      V v_s_24291 = heff_field(v_x2_24289, 1);
      heff_take_n(v_x2_24289, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24285;
      heff_room[1] = v_x_24290;
      heff_room[2] = v_s_24291;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24289);
    }
  }
  default: return heff_nomatch(v_x2_24284);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24300 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24300;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_s_24296}));
  switch (heff_tag_of(v_x2_24297)) {
  case TAG_MkPair: {
    V v_x_24298 = heff_field(v_x2_24297, 0);
    V v_s_24299 = heff_field(v_x2_24297, 1);
    heff_take_n(v_x2_24297, 3ULL, 2);
    V v_m_24301 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_s_24299}));
    switch (heff_tag_of(v_x2_24302)) {
    case TAG_MkPair: {
      V v_x_24303 = heff_field(v_x2_24302, 0);
      V v_s_24304 = heff_field(v_x2_24302, 1);
      heff_take_n(v_x2_24302, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24298;
      heff_room[1] = v_x_24303;
      heff_room[2] = v_s_24304;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24302);
    }
  }
  default: return heff_nomatch(v_x2_24297);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24311 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24311;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_s_24307}));
  switch (heff_tag_of(v_x2_24308)) {
  case TAG_MkPair: {
    V v_x_24309 = heff_field(v_x2_24308, 0);
    V v_s_24310 = heff_field(v_x2_24308, 1);
    heff_take_n(v_x2_24308, 3ULL, 2);
    V v_m_24312 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24313 = heff_tr(heff_call(v_m_24312, 1, (V[]){v_s_24310}));
    switch (heff_tag_of(v_x2_24313)) {
    case TAG_MkPair: {
      V v_x_24314 = heff_field(v_x2_24313, 0);
      V v_s_24315 = heff_field(v_x2_24313, 1);
      heff_take_n(v_x2_24313, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24309;
      heff_room[1] = v_x_24314;
      heff_room[2] = v_s_24315;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24313);
    }
  }
  default: return heff_nomatch(v_x2_24308);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24323 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24323;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24319 = args[0];
  V v_m_24318 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24320 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_s_24319}));
  switch (heff_tag_of(v_x2_24320)) {
  case TAG_MkPair: {
    V v_x_24321 = heff_field(v_x2_24320, 0);
    V v_s_24322 = heff_field(v_x2_24320, 1);
    heff_take_n(v_x2_24320, 3ULL, 2);
    V v_m_24324 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24325 = heff_tr(heff_call(v_m_24324, 1, (V[]){v_s_24322}));
    switch (heff_tag_of(v_x2_24325)) {
    case TAG_MkPair: {
      V v_x_24326 = heff_field(v_x2_24325, 0);
      V v_s_24327 = heff_field(v_x2_24325, 1);
      heff_take_n(v_x2_24325, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24321;
      heff_room[1] = v_x_24326;
      heff_room[2] = v_s_24327;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24325);
    }
  }
  default: return heff_nomatch(v_x2_24320);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24336 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24336;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24333 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_s_24332}));
  switch (heff_tag_of(v_x2_24333)) {
  case TAG_MkPair: {
    V v_x_24334 = heff_field(v_x2_24333, 0);
    V v_s_24335 = heff_field(v_x2_24333, 1);
    heff_take_n(v_x2_24333, 3ULL, 2);
    V v_m_24337 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24338 = heff_tr(heff_call(v_m_24337, 1, (V[]){v_s_24335}));
    switch (heff_tag_of(v_x2_24338)) {
    case TAG_MkPair: {
      V v_x_24339 = heff_field(v_x2_24338, 0);
      V v_s_24340 = heff_field(v_x2_24338, 1);
      heff_take_n(v_x2_24338, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24334;
      heff_room[1] = v_x_24339;
      heff_room[2] = v_s_24340;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24338);
    }
  }
  default: return heff_nomatch(v_x2_24333);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24348 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24348;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24344 = args[0];
  V v_m_24343 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24345 = heff_tr(heff_call(v_m_24343, 1, (V[]){v_s_24344}));
  switch (heff_tag_of(v_x2_24345)) {
  case TAG_MkPair: {
    V v_x_24346 = heff_field(v_x2_24345, 0);
    V v_s_24347 = heff_field(v_x2_24345, 1);
    heff_take_n(v_x2_24345, 3ULL, 2);
    V v_m_24349 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24350 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_s_24347}));
    switch (heff_tag_of(v_x2_24350)) {
    case TAG_MkPair: {
      V v_x_24351 = heff_field(v_x2_24350, 0);
      V v_s_24352 = heff_field(v_x2_24350, 1);
      heff_take_n(v_x2_24350, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24346;
      heff_room[1] = v_x_24351;
      heff_room[2] = v_s_24352;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24350);
    }
  }
  default: return heff_nomatch(v_x2_24345);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24362 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24362;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24358 = args[0];
  V v_m_24357 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24359 = heff_tr(heff_call(v_m_24357, 1, (V[]){v_s_24358}));
  switch (heff_tag_of(v_x2_24359)) {
  case TAG_MkPair: {
    V v_x_24360 = heff_field(v_x2_24359, 0);
    V v_s_24361 = heff_field(v_x2_24359, 1);
    heff_take_n(v_x2_24359, 3ULL, 2);
    V v_m_24363 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24364 = heff_tr(heff_call(v_m_24363, 1, (V[]){v_s_24361}));
    switch (heff_tag_of(v_x2_24364)) {
    case TAG_MkPair: {
      V v_x_24365 = heff_field(v_x2_24364, 0);
      V v_s_24366 = heff_field(v_x2_24364, 1);
      heff_take_n(v_x2_24364, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24360;
      heff_room[1] = v_x_24365;
      heff_room[2] = v_s_24366;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24364);
    }
  }
  default: return heff_nomatch(v_x2_24359);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24375 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24375;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24371 = args[0];
  V v_m_24370 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24372 = heff_tr(heff_call(v_m_24370, 1, (V[]){v_s_24371}));
  switch (heff_tag_of(v_x2_24372)) {
  case TAG_MkPair: {
    V v_x_24373 = heff_field(v_x2_24372, 0);
    V v_s_24374 = heff_field(v_x2_24372, 1);
    heff_take_n(v_x2_24372, 3ULL, 2);
    V v_m_24376 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24377 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_s_24374}));
    switch (heff_tag_of(v_x2_24377)) {
    case TAG_MkPair: {
      V v_x_24378 = heff_field(v_x2_24377, 0);
      V v_s_24379 = heff_field(v_x2_24377, 1);
      heff_take_n(v_x2_24377, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24373;
      heff_room[1] = v_x_24378;
      heff_room[2] = v_s_24379;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24377);
    }
  }
  default: return heff_nomatch(v_x2_24372);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24387 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24387;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24383 = args[0];
  V v_m_24382 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24384 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_s_24383}));
  switch (heff_tag_of(v_x2_24384)) {
  case TAG_MkPair: {
    V v_x_24385 = heff_field(v_x2_24384, 0);
    V v_s_24386 = heff_field(v_x2_24384, 1);
    heff_take_n(v_x2_24384, 3ULL, 2);
    V v_m_24388 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24389 = heff_tr(heff_call(v_m_24388, 1, (V[]){v_s_24386}));
    switch (heff_tag_of(v_x2_24389)) {
    case TAG_MkPair: {
      V v_x_24390 = heff_field(v_x2_24389, 0);
      V v_s_24391 = heff_field(v_x2_24389, 1);
      heff_take_n(v_x2_24389, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24385;
      heff_room[1] = v_x_24390;
      heff_room[2] = v_s_24391;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24389);
    }
  }
  default: return heff_nomatch(v_x2_24384);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24398 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24398;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_s_24394}));
  switch (heff_tag_of(v_x2_24395)) {
  case TAG_MkPair: {
    V v_x_24396 = heff_field(v_x2_24395, 0);
    V v_s_24397 = heff_field(v_x2_24395, 1);
    heff_take_n(v_x2_24395, 3ULL, 2);
    V v_m_24399 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24400 = heff_tr(heff_call(v_m_24399, 1, (V[]){v_s_24397}));
    switch (heff_tag_of(v_x2_24400)) {
    case TAG_MkPair: {
      V v_x_24401 = heff_field(v_x2_24400, 0);
      V v_s_24402 = heff_field(v_x2_24400, 1);
      heff_take_n(v_x2_24400, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24396;
      heff_room[1] = v_x_24401;
      heff_room[2] = v_s_24402;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24400);
    }
  }
  default: return heff_nomatch(v_x2_24395);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24406 = args[0];
  V v_m_24405 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24407 = heff_tr(heff_call(v_m_24405, 1, (V[]){v_s_24406}));
  switch (heff_tag_of(v_x2_24407)) {
  case TAG_MkPair: {
    V v_x_24408 = heff_field(v_x2_24407, 0);
    V v_s_24409 = heff_field(v_x2_24407, 1);
    heff_take_n(v_x2_24407, 3ULL, 2);
    V v_m_24411 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24412 = heff_tr(heff_call(v_m_24411, 1, (V[]){v_s_24409}));
    switch (heff_tag_of(v_x2_24412)) {
    case TAG_MkPair: {
      V v_x_24413 = heff_field(v_x2_24412, 0);
      V v_s_24414 = heff_field(v_x2_24412, 1);
      heff_take_n(v_x2_24412, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24408;
      heff_room[1] = v_x_24413;
      heff_room[2] = v_s_24414;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24412);
    }
  }
  default: return heff_nomatch(v_x2_24407);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24422 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24418 = args[0];
  V v_m_24417 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24419 = heff_tr(heff_call(v_m_24417, 1, (V[]){v_s_24418}));
  switch (heff_tag_of(v_x2_24419)) {
  case TAG_MkPair: {
    V v_x_24420 = heff_field(v_x2_24419, 0);
    V v_s_24421 = heff_field(v_x2_24419, 1);
    heff_take_n(v_x2_24419, 3ULL, 2);
    V v_m_24423 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24424 = heff_tr(heff_call(v_m_24423, 1, (V[]){v_s_24421}));
    switch (heff_tag_of(v_x2_24424)) {
    case TAG_MkPair: {
      V v_x_24425 = heff_field(v_x2_24424, 0);
      V v_s_24426 = heff_field(v_x2_24424, 1);
      heff_take_n(v_x2_24424, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24420;
      heff_room[1] = v_x_24425;
      heff_room[2] = v_s_24426;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24424);
    }
  }
  default: return heff_nomatch(v_x2_24419);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24433 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24429 = args[0];
  V v_m_24428 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24430 = heff_tr(heff_call(v_m_24428, 1, (V[]){v_s_24429}));
  switch (heff_tag_of(v_x2_24430)) {
  case TAG_MkPair: {
    V v_x_24431 = heff_field(v_x2_24430, 0);
    V v_s_24432 = heff_field(v_x2_24430, 1);
    heff_take_n(v_x2_24430, 3ULL, 2);
    V v_m_24434 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24435 = heff_tr(heff_call(v_m_24434, 1, (V[]){v_s_24432}));
    switch (heff_tag_of(v_x2_24435)) {
    case TAG_MkPair: {
      V v_x_24436 = heff_field(v_x2_24435, 0);
      V v_s_24437 = heff_field(v_x2_24435, 1);
      heff_take_n(v_x2_24435, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24431;
      heff_room[1] = v_x_24436;
      heff_room[2] = v_s_24437;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24435);
    }
  }
  default: return heff_nomatch(v_x2_24430);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24444 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24440 = args[0];
  V v_m_24439 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24441 = heff_tr(heff_call(v_m_24439, 1, (V[]){v_s_24440}));
  switch (heff_tag_of(v_x2_24441)) {
  case TAG_MkPair: {
    V v_x_24442 = heff_field(v_x2_24441, 0);
    V v_s_24443 = heff_field(v_x2_24441, 1);
    heff_take_n(v_x2_24441, 3ULL, 2);
    V v_m_24445 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24446 = heff_tr(heff_call(v_m_24445, 1, (V[]){v_s_24443}));
    switch (heff_tag_of(v_x2_24446)) {
    case TAG_MkPair: {
      V v_x_24447 = heff_field(v_x2_24446, 0);
      V v_s_24448 = heff_field(v_x2_24446, 1);
      heff_take_n(v_x2_24446, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24442;
      heff_room[1] = v_x_24447;
      heff_room[2] = v_s_24448;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24446);
    }
  }
  default: return heff_nomatch(v_x2_24441);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24455 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24451 = args[0];
  V v_m_24450 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24452 = heff_tr(heff_call(v_m_24450, 1, (V[]){v_s_24451}));
  switch (heff_tag_of(v_x2_24452)) {
  case TAG_MkPair: {
    V v_x_24453 = heff_field(v_x2_24452, 0);
    V v_s_24454 = heff_field(v_x2_24452, 1);
    heff_take_n(v_x2_24452, 3ULL, 2);
    V v_m_24456 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24457 = heff_tr(heff_call(v_m_24456, 1, (V[]){v_s_24454}));
    switch (heff_tag_of(v_x2_24457)) {
    case TAG_MkPair: {
      V v_x_24458 = heff_field(v_x2_24457, 0);
      V v_s_24459 = heff_field(v_x2_24457, 1);
      heff_take_n(v_x2_24457, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24453;
      heff_room[1] = v_x_24458;
      heff_room[2] = v_s_24459;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24457);
    }
  }
  default: return heff_nomatch(v_x2_24452);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_a_24466 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24462 = args[0];
  V v_m_24461 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24463 = heff_tr(heff_call(v_m_24461, 1, (V[]){v_s_24462}));
  switch (heff_tag_of(v_x2_24463)) {
  case TAG_MkPair: {
    V v_x_24464 = heff_field(v_x2_24463, 0);
    V v_s_24465 = heff_field(v_x2_24463, 1);
    heff_take_n(v_x2_24463, 3ULL, 2);
    V v_m_24467 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam78, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24468 = heff_tr(heff_call(v_m_24467, 1, (V[]){v_s_24465}));
    switch (heff_tag_of(v_x2_24468)) {
    case TAG_MkPair: {
      V v_x_24469 = heff_field(v_x2_24468, 0);
      V v_s_24470 = heff_field(v_x2_24468, 1);
      heff_take_n(v_x2_24468, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24464;
      heff_room[1] = v_x_24469;
      heff_room[2] = v_s_24470;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24468);
    }
  }
  default: return heff_nomatch(v_x2_24463);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_a_24478 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24474 = args[0];
  V v_m_24473 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24475 = heff_tr(heff_call(v_m_24473, 1, (V[]){v_s_24474}));
  switch (heff_tag_of(v_x2_24475)) {
  case TAG_MkPair: {
    V v_x_24476 = heff_field(v_x2_24475, 0);
    V v_s_24477 = heff_field(v_x2_24475, 1);
    heff_take_n(v_x2_24475, 3ULL, 2);
    V v_m_24479 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam80, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24480 = heff_tr(heff_call(v_m_24479, 1, (V[]){v_s_24477}));
    switch (heff_tag_of(v_x2_24480)) {
    case TAG_MkPair: {
      V v_x_24481 = heff_field(v_x2_24480, 0);
      V v_s_24482 = heff_field(v_x2_24480, 1);
      heff_take_n(v_x2_24480, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24476;
      heff_room[1] = v_x_24481;
      heff_room[2] = v_s_24482;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24480);
    }
  }
  default: return heff_nomatch(v_x2_24475);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_a_24489 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24485 = args[0];
  V v_m_24484 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24486 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_s_24485}));
  switch (heff_tag_of(v_x2_24486)) {
  case TAG_MkPair: {
    V v_x_24487 = heff_field(v_x2_24486, 0);
    V v_s_24488 = heff_field(v_x2_24486, 1);
    heff_take_n(v_x2_24486, 3ULL, 2);
    V v_m_24490 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam82, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24491 = heff_tr(heff_call(v_m_24490, 1, (V[]){v_s_24488}));
    switch (heff_tag_of(v_x2_24491)) {
    case TAG_MkPair: {
      V v_x_24492 = heff_field(v_x2_24491, 0);
      V v_s_24493 = heff_field(v_x2_24491, 1);
      heff_take_n(v_x2_24491, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24487;
      heff_room[1] = v_x_24492;
      heff_room[2] = v_s_24493;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24491);
    }
  }
  default: return heff_nomatch(v_x2_24486);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_a_24499 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24495 = args[0];
  V v_m_24494 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24496 = heff_tr(heff_call(v_m_24494, 1, (V[]){v_s_24495}));
  switch (heff_tag_of(v_x2_24496)) {
  case TAG_MkPair: {
    V v_x_24497 = heff_field(v_x2_24496, 0);
    V v_s_24498 = heff_field(v_x2_24496, 1);
    heff_take_n(v_x2_24496, 3ULL, 2);
    V v_m_24500 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam84, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24501 = heff_tr(heff_call(v_m_24500, 1, (V[]){v_s_24498}));
    switch (heff_tag_of(v_x2_24501)) {
    case TAG_MkPair: {
      V v_x_24502 = heff_field(v_x2_24501, 0);
      V v_s_24503 = heff_field(v_x2_24501, 1);
      heff_take_n(v_x2_24501, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24497;
      heff_room[1] = v_x_24502;
      heff_room[2] = v_s_24503;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24501);
    }
  }
  default: return heff_nomatch(v_x2_24496);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_a_24510 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24510;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_s_24506 = args[0];
  V v_m_24505 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24507 = heff_tr(heff_call(v_m_24505, 1, (V[]){v_s_24506}));
  switch (heff_tag_of(v_x2_24507)) {
  case TAG_MkPair: {
    V v_x_24508 = heff_field(v_x2_24507, 0);
    V v_s_24509 = heff_field(v_x2_24507, 1);
    heff_take_n(v_x2_24507, 3ULL, 2);
    V v_m_24511 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam86, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24512 = heff_tr(heff_call(v_m_24511, 1, (V[]){v_s_24509}));
    switch (heff_tag_of(v_x2_24512)) {
    case TAG_MkPair: {
      V v_x_24513 = heff_field(v_x2_24512, 0);
      V v_s_24514 = heff_field(v_x2_24512, 1);
      heff_take_n(v_x2_24512, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24508;
      heff_room[1] = v_x_24513;
      heff_room[2] = v_s_24514;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24512);
    }
  }
  default: return heff_nomatch(v_x2_24507);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_a_24523 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24523;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24519 = args[0];
  V v_m_24518 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24520 = heff_tr(heff_call(v_m_24518, 1, (V[]){v_s_24519}));
  switch (heff_tag_of(v_x2_24520)) {
  case TAG_MkPair: {
    V v_x_24521 = heff_field(v_x2_24520, 0);
    V v_s_24522 = heff_field(v_x2_24520, 1);
    heff_take_n(v_x2_24520, 3ULL, 2);
    V v_m_24524 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam88, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24525 = heff_tr(heff_call(v_m_24524, 1, (V[]){v_s_24522}));
    switch (heff_tag_of(v_x2_24525)) {
    case TAG_MkPair: {
      V v_x_24526 = heff_field(v_x2_24525, 0);
      V v_s_24527 = heff_field(v_x2_24525, 1);
      heff_take_n(v_x2_24525, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24521;
      heff_room[1] = v_x_24526;
      heff_room[2] = v_s_24527;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24525);
    }
  }
  default: return heff_nomatch(v_x2_24520);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_a_24534 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24534;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_s_24530 = args[0];
  V v_m_24529 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24531 = heff_tr(heff_call(v_m_24529, 1, (V[]){v_s_24530}));
  switch (heff_tag_of(v_x2_24531)) {
  case TAG_MkPair: {
    V v_x_24532 = heff_field(v_x2_24531, 0);
    V v_s_24533 = heff_field(v_x2_24531, 1);
    heff_take_n(v_x2_24531, 3ULL, 2);
    V v_m_24535 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam90, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24536 = heff_tr(heff_call(v_m_24535, 1, (V[]){v_s_24533}));
    switch (heff_tag_of(v_x2_24536)) {
    case TAG_MkPair: {
      V v_x_24537 = heff_field(v_x2_24536, 0);
      V v_s_24538 = heff_field(v_x2_24536, 1);
      heff_take_n(v_x2_24536, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24532;
      heff_room[1] = v_x_24537;
      heff_room[2] = v_s_24538;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24536);
    }
  }
  default: return heff_nomatch(v_x2_24531);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_a_24546 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24546;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24542 = args[0];
  V v_m_24541 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_argv_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24543 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_s_24542}));
  switch (heff_tag_of(v_x2_24543)) {
  case TAG_MkPair: {
    V v_x_24544 = heff_field(v_x2_24543, 0);
    V v_s_24545 = heff_field(v_x2_24543, 1);
    heff_take_n(v_x2_24543, 3ULL, 2);
    V v_m_24547 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam92, 1, 1, (V[]){heff_dup(v_r_240)}), v_argv_2419));
    V v_x2_24548 = heff_tr(heff_call(v_m_24547, 1, (V[]){v_s_24545}));
    switch (heff_tag_of(v_x2_24548)) {
    case TAG_MkPair: {
      V v_x_24549 = heff_field(v_x2_24548, 0);
      V v_s_24550 = heff_field(v_x2_24548, 1);
      heff_take_n(v_x2_24548, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24544;
      heff_room[1] = v_x_24549;
      heff_room[2] = v_s_24550;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24548);
    }
  }
  default: return heff_nomatch(v_x2_24543);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24555 = args[0];
  V v_m_24554 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24551 = heff_env(self)[2];
  V v_b_24553 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24556 = heff_tr(heff_call(v_m_24554, 1, (V[]){v_s_24555}));
  switch (heff_tag_of(v_x2_24556)) {
  case TAG_MkPair: {
    V v_x_24557 = heff_field(v_x2_24556, 0);
    V v_s_24558 = heff_field(v_x2_24556, 1);
    heff_take_n(v_x2_24556, 3ULL, 2);
    V v_t_24559 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_24551, v_x_24557, v_b_24553));
    V f_ = v_t_24559;
    args[0] = v_s_24558;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24556);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24566 = args[0];
  V v_m_24565 = heff_env(self)[0];
  V v_l_24563 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24567 = heff_tr(heff_call(v_m_24565, 1, (V[]){v_s_24566}));
  switch (heff_tag_of(v_x2_24567)) {
  case TAG_MkPair: {
    V v_x_24568 = heff_field(v_x2_24567, 0);
    V v_s_24569 = heff_field(v_x2_24567, 1);
    V v_ru_24x2_24567_24MkPair = heff_take_reuse_n(v_x2_24567, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24567_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24563, v_x_24568}), v_s_24569});
  }
  default: return heff_nomatch(v_x2_24567);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_p_24562 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24562)) {
  case TAG_MkPair: {
    V v_l_24563 = heff_field(v_p_24562, 0);
    V v_e_24564 = heff_field(v_p_24562, 1);
    heff_take_n(v_p_24562, 3ULL, 2);
    V v_m_24565 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_e_24564}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam95, 1, 2, (V[]){v_m_24565, v_l_24563});
  }
  default: return heff_nomatch(v_p_24562);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24571 = args[0];
  V v_m_24570 = heff_env(self)[0];
  V v_ts_24561 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24572 = heff_tr(heff_call(v_m_24570, 1, (V[]){v_s_24571}));
  switch (heff_tag_of(v_x2_24572)) {
  case TAG_MkPair: {
    V v_x_24573 = heff_field(v_x2_24572, 0);
    V v_s_24574 = heff_field(v_x2_24572, 1);
    V v_ru_24x2_24572_24MkPair = heff_take_reuse_n(v_x2_24572, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24572_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24573, v_ts_24561}), v_s_24574});
  }
  default: return heff_nomatch(v_x2_24572);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24580 = args[0];
  V v_m_24579 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24576 = heff_env(self)[2];
  V v_sh_24577 = heff_env(self)[3];
  V v_t_24578 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24581 = heff_tr(heff_call(v_m_24579, 1, (V[]){v_s_24580}));
  switch (heff_tag_of(v_x2_24581)) {
  case TAG_MkPair: {
    V v_x_24582 = heff_field(v_x2_24581, 0);
    V v_s_24583 = heff_field(v_x2_24581, 1);
    heff_take_n(v_x2_24581, 3ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 5, (V[]){v_l_24576, v_sh_24577, v_t_24578, v_x_24582, v_s_24583});
  }
  default: return heff_nomatch(v_x2_24581);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args) {
  V v_a_24587 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24587;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args) {
  V v_s_24589 = args[0];
  V v_m_24588 = heff_env(self)[0];
  V v_t_24584 = heff_env(self)[1];
  V v_ts_24586 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24590 = heff_tr(heff_call(v_m_24588, 1, (V[]){v_s_24589}));
  switch (heff_tag_of(v_x2_24590)) {
  case TAG_MkPair: {
    V v_x_24591 = heff_field(v_x2_24590, 0);
    V v_s_24592 = heff_field(v_x2_24590, 1);
    V v_ru_24x2_24590_24MkPair = heff_take_reuse_n(v_x2_24590, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24590_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24584, v_x_24591, v_ts_24586}), v_s_24592});
  }
  default: return heff_nomatch(v_x2_24590);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args) {
  V v_s_24605 = args[0];
  V v_m_24604 = heff_env(self)[0];
  V v_t_24601 = heff_env(self)[1];
  V v_vs_24602 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24606 = heff_tr(heff_call(v_m_24604, 1, (V[]){v_s_24605}));
  switch (heff_tag_of(v_x2_24606)) {
  case TAG_MkPair: {
    V v_x_24607 = heff_field(v_x2_24606, 0);
    V v_s_24608 = heff_field(v_x2_24606, 1);
    V v_ru_24x2_24606_24MkPair = heff_take_reuse_n(v_x2_24606, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24606_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24601, v_vs_24602, v_x_24607}), v_s_24608});
  }
  default: return heff_nomatch(v_x2_24606);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args) {
  V v_a_24600 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24600)) {
  case TAG_MkArm: {
    V v_t_24601 = heff_field(v_a_24600, 0);
    V v_vs_24602 = heff_field(v_a_24600, 1);
    V v_b_24603 = heff_field(v_a_24600, 2);
    heff_take_n(v_a_24600, 7ULL, 3);
    V v_m_24604 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24603}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam102, 1, 3, (V[]){v_m_24604, v_t_24601, v_vs_24602});
  }
  default: return heff_nomatch(v_a_24600);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args) {
  V v_s_24596 = args[0];
  V v_m_24595 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24594 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24597 = heff_tr(heff_call(v_m_24595, 1, (V[]){v_s_24596}));
  switch (heff_tag_of(v_x2_24597)) {
  case TAG_MkPair: {
    V v_x_24598 = heff_field(v_x2_24597, 0);
    V v_s_24599 = heff_field(v_x2_24597, 1);
    heff_take_n(v_x2_24597, 3ULL, 2);
    V v_m_24609 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam101, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24594));
    V v_x2_24610 = heff_tr(heff_call(v_m_24609, 1, (V[]){v_s_24599}));
    switch (heff_tag_of(v_x2_24610)) {
    case TAG_MkPair: {
      V v_x_24611 = heff_field(v_x2_24610, 0);
      V v_s_24612 = heff_field(v_x2_24610, 1);
      heff_take_n(v_x2_24610, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 3, 4);
      heff_room[0] = v_x_24598;
      heff_room[1] = v_x_24611;
      heff_room[2] = v_s_24612;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24610);
    }
  }
  default: return heff_nomatch(v_x2_24597);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam103(V self, V *args) {
  V v_s_24614 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24614});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam104(V self, V *args) {
  V v_a_24617 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24617;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam105(V self, V *args) {
  V v_s_24619 = args[0];
  V v_m_24618 = heff_env(self)[0];
  V v_p_24615 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24620 = heff_tr(heff_call(v_m_24618, 1, (V[]){v_s_24619}));
  switch (heff_tag_of(v_x2_24620)) {
  case TAG_MkPair: {
    V v_x_24621 = heff_field(v_x2_24620, 0);
    V v_s_24622 = heff_field(v_x2_24620, 1);
    V v_ru_24x2_24620_24MkPair = heff_take_reuse_n(v_x2_24620, 3ULL, 2);
    V v_x_24623 = (g_heff_2ecompile_2esimplify_2efoldPrim(v_p_24615, v_x_24621));
    return heff_tag_at_n(v_ru_24x2_24620_24MkPair, TAG_MkPair, 2, (V[]){v_x_24623, v_s_24622});
  }
  default: return heff_nomatch(v_x2_24620);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam106(V self, V *args) {
  V v_s_24626 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24626});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam107(V self, V *args) {
  V v_s_24628 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24628});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam108(V self, V *args) {
  V v_s_24630 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24630});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam109(V self, V *args) {
  V v_s_24632 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24632});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam110(V self, V *args) {
  V v_s_24634 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24634});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam111(V self, V *args) {
  V v_s_24637 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24637});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam112(V self, V *args) {
  V v_s_24639 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24639});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam113(V self, V *args) {
  V v_s_24640 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24640});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam114(V self, V *args) {
  V v_a_24642 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24642;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam115(V self, V *args) {
  V v_s_24644 = args[0];
  V v_m_24643 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24645 = heff_tr(heff_call(v_m_24643, 1, (V[]){v_s_24644}));
  switch (heff_tag_of(v_x2_24645)) {
  case TAG_MkPair: {
    V v_x_24646 = heff_field(v_x2_24645, 0);
    V v_s_24647 = heff_field(v_x2_24645, 1);
    V v_ru_24x2_24645_24MkPair = heff_take_reuse_n(v_x2_24645, 3ULL, 2);
    V v_c_24648 = (g_heff_2ecompile_2esimplify_2efoldCond(v_x_24646));
    V v_t_24657;
    switch (heff_tag_of(v_c_24648)) {
    case TAG_CTrue: {
      v_t_24657 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2esimpF_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CFalse: {
      v_t_24657 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2esimpF_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CRel: {
      v_t_24657 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24648});
      break;
    }
    case TAG_CTest: {
      V v_e_24652 = heff_field(v_c_24648, 0);
      heff_take_n(v_c_24648, 1ULL, 1);
      v_t_24657 = v_e_24652;
      break;
    }
    case TAG_CNot: {
      v_t_24657 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24648});
      break;
    }
    case TAG_CIf: {
      v_t_24657 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_24648});
      break;
    }
    default: heff_nomatch(v_c_24648);
    }
    return heff_tag_at_n(v_ru_24x2_24645_24MkPair, TAG_MkPair, 2, (V[]){v_t_24657, v_s_24647});
  }
  default: return heff_nomatch(v_x2_24645);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam116(V self, V *args) {
  V v_s_24662 = args[0];
  V v_m_24661 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_24660 = heff_env(self)[2];
  V v_xs_24658 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24663 = heff_tr(heff_call(v_m_24661, 1, (V[]){v_s_24662}));
  switch (heff_tag_of(v_x2_24663)) {
  case TAG_MkPair: {
    V v_x_24664 = heff_field(v_x2_24663, 0);
    V v_s_24665 = heff_field(v_x2_24663, 1);
    V v_ru_24x2_24663_24MkPair = heff_take_reuse_n(v_x2_24663, 3ULL, 2);
    switch (heff_tag_of(v_x_24664)) {
    case TAG_EVar: {
      V v_m_24667 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24668 = heff_tr(heff_call(v_m_24667, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24668)) {
      case TAG_MkPair: {
        V v_x_24669 = heff_field(v_x2_24668, 0);
        V v_s_24670 = heff_field(v_x2_24668, 1);
        heff_take_n(v_x2_24668, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24669}), v_s_24670});
      }
      default: return heff_nomatch(v_x2_24668);
      }
    }
    case TAG_EGlobal: {
      V v_m_24672 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24673 = heff_tr(heff_call(v_m_24672, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24673)) {
      case TAG_MkPair: {
        V v_x_24674 = heff_field(v_x2_24673, 0);
        V v_s_24675 = heff_field(v_x2_24673, 1);
        heff_take_n(v_x2_24673, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24674}), v_s_24675});
      }
      default: return heff_nomatch(v_x2_24673);
      }
    }
    case TAG_ELam: {
      V v_m_24678 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24679 = heff_tr(heff_call(v_m_24678, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24679)) {
      case TAG_MkPair: {
        V v_x_24680 = heff_field(v_x2_24679, 0);
        V v_s_24681 = heff_field(v_x2_24679, 1);
        heff_take_n(v_x2_24679, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24680}), v_s_24681});
      }
      default: return heff_nomatch(v_x2_24679);
      }
    }
    case TAG_EApp: {
      V v_m_24684 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24685 = heff_tr(heff_call(v_m_24684, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24685)) {
      case TAG_MkPair: {
        V v_x_24686 = heff_field(v_x2_24685, 0);
        V v_s_24687 = heff_field(v_x2_24685, 1);
        heff_take_n(v_x2_24685, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24686}), v_s_24687});
      }
      default: return heff_nomatch(v_x2_24685);
      }
    }
    case TAG_ELet: {
      V v_m_24691 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24692 = heff_tr(heff_call(v_m_24691, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24692)) {
      case TAG_MkPair: {
        V v_x_24693 = heff_field(v_x2_24692, 0);
        V v_s_24694 = heff_field(v_x2_24692, 1);
        heff_take_n(v_x2_24692, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24693}), v_s_24694});
      }
      default: return heff_nomatch(v_x2_24692);
      }
    }
    case TAG_ERecord: {
      V v_m_24697 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24698 = heff_tr(heff_call(v_m_24697, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24698)) {
      case TAG_MkPair: {
        V v_x_24699 = heff_field(v_x2_24698, 0);
        V v_s_24700 = heff_field(v_x2_24698, 1);
        heff_take_n(v_x2_24698, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24699}), v_s_24700});
      }
      default: return heff_nomatch(v_x2_24698);
      }
    }
    case TAG_EProj: {
      V v_m_24705 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24706 = heff_tr(heff_call(v_m_24705, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24706)) {
      case TAG_MkPair: {
        V v_x_24707 = heff_field(v_x2_24706, 0);
        V v_s_24708 = heff_field(v_x2_24706, 1);
        heff_take_n(v_x2_24706, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24707}), v_s_24708});
      }
      default: return heff_nomatch(v_x2_24706);
      }
    }
    case TAG_ETag: {
      V v_m_24712 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24713 = heff_tr(heff_call(v_m_24712, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24713)) {
      case TAG_MkPair: {
        V v_x_24714 = heff_field(v_x2_24713, 0);
        V v_s_24715 = heff_field(v_x2_24713, 1);
        heff_take_n(v_x2_24713, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24714}), v_s_24715});
      }
      default: return heff_nomatch(v_x2_24713);
      }
    }
    case TAG_EMatch: {
      V v_m_24718 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24719 = heff_tr(heff_call(v_m_24718, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24719)) {
      case TAG_MkPair: {
        V v_x_24720 = heff_field(v_x2_24719, 0);
        V v_s_24721 = heff_field(v_x2_24719, 1);
        heff_take_n(v_x2_24719, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24720}), v_s_24721});
      }
      default: return heff_nomatch(v_x2_24719);
      }
    }
    case TAG_EPrim: {
      V v_m_24723 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24724 = heff_tr(heff_call(v_m_24723, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24724)) {
      case TAG_MkPair: {
        V v_x_24725 = heff_field(v_x2_24724, 0);
        V v_s_24726 = heff_field(v_x2_24724, 1);
        heff_take_n(v_x2_24724, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24725}), v_s_24726});
      }
      default: return heff_nomatch(v_x2_24724);
      }
    }
    case TAG_EPrimCall: {
      V v_m_24729 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24730 = heff_tr(heff_call(v_m_24729, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24730)) {
      case TAG_MkPair: {
        V v_x_24731 = heff_field(v_x2_24730, 0);
        V v_s_24732 = heff_field(v_x2_24730, 1);
        heff_take_n(v_x2_24730, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24731}), v_s_24732});
      }
      default: return heff_nomatch(v_x2_24730);
      }
    }
    case TAG_ECall: {
      V v_m_24735 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24736 = heff_tr(heff_call(v_m_24735, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24736)) {
      case TAG_MkPair: {
        V v_x_24737 = heff_field(v_x2_24736, 0);
        V v_s_24738 = heff_field(v_x2_24736, 1);
        heff_take_n(v_x2_24736, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24737}), v_s_24738});
      }
      default: return heff_nomatch(v_x2_24736);
      }
    }
    case TAG_EInt: {
      V v_m_24740 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24741 = heff_tr(heff_call(v_m_24740, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24741)) {
      case TAG_MkPair: {
        V v_x_24742 = heff_field(v_x2_24741, 0);
        V v_s_24743 = heff_field(v_x2_24741, 1);
        heff_take_n(v_x2_24741, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24742}), v_s_24743});
      }
      default: return heff_nomatch(v_x2_24741);
      }
    }
    case TAG_EFloat: {
      V v_m_24745 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24746 = heff_tr(heff_call(v_m_24745, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24746)) {
      case TAG_MkPair: {
        V v_x_24747 = heff_field(v_x2_24746, 0);
        V v_s_24748 = heff_field(v_x2_24746, 1);
        heff_take_n(v_x2_24746, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24747}), v_s_24748});
      }
      default: return heff_nomatch(v_x2_24746);
      }
    }
    case TAG_EStr: {
      V v_m_24750 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24751 = heff_tr(heff_call(v_m_24750, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24751)) {
      case TAG_MkPair: {
        V v_x_24752 = heff_field(v_x2_24751, 0);
        V v_s_24753 = heff_field(v_x2_24751, 1);
        heff_take_n(v_x2_24751, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24752}), v_s_24753});
      }
      default: return heff_nomatch(v_x2_24751);
      }
    }
    case TAG_EBytes: {
      V v_m_24755 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24756 = heff_tr(heff_call(v_m_24755, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24756)) {
      case TAG_MkPair: {
        V v_x_24757 = heff_field(v_x2_24756, 0);
        V v_s_24758 = heff_field(v_x2_24756, 1);
        heff_take_n(v_x2_24756, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24757}), v_s_24758});
      }
      default: return heff_nomatch(v_x2_24756);
      }
    }
    case TAG_EFixed: {
      V v_m_24761 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24762 = heff_tr(heff_call(v_m_24761, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24762)) {
      case TAG_MkPair: {
        V v_x_24763 = heff_field(v_x2_24762, 0);
        V v_s_24764 = heff_field(v_x2_24762, 1);
        heff_take_n(v_x2_24762, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24763}), v_s_24764});
      }
      default: return heff_nomatch(v_x2_24762);
      }
    }
    case TAG_EFloat32: {
      V v_m_24766 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24767 = heff_tr(heff_call(v_m_24766, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24767)) {
      case TAG_MkPair: {
        V v_x_24768 = heff_field(v_x2_24767, 0);
        V v_s_24769 = heff_field(v_x2_24767, 1);
        heff_take_n(v_x2_24767, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24768}), v_s_24769});
      }
      default: return heff_nomatch(v_x2_24767);
      }
    }
    case TAG_EAbandon: {
      V v_m_24770 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24771 = heff_tr(heff_call(v_m_24770, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24771)) {
      case TAG_MkPair: {
        V v_x_24772 = heff_field(v_x2_24771, 0);
        V v_s_24773 = heff_field(v_x2_24771, 1);
        heff_take_n(v_x2_24771, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24772}), v_s_24773});
      }
      default: return heff_nomatch(v_x2_24771);
      }
    }
    case TAG_EBool: {
      V v_m_24775 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24776 = heff_tr(heff_call(v_m_24775, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24776)) {
      case TAG_MkPair: {
        V v_x_24777 = heff_field(v_x2_24776, 0);
        V v_s_24778 = heff_field(v_x2_24776, 1);
        heff_take_n(v_x2_24776, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24777}), v_s_24778});
      }
      default: return heff_nomatch(v_x2_24776);
      }
    }
    case TAG_ESet: {
      V v_m_24782 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24783 = heff_tr(heff_call(v_m_24782, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24783)) {
      case TAG_MkPair: {
        V v_x_24784 = heff_field(v_x2_24783, 0);
        V v_s_24785 = heff_field(v_x2_24783, 1);
        heff_take_n(v_x2_24783, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24784}), v_s_24785});
      }
      default: return heff_nomatch(v_x2_24783);
      }
    }
    case TAG_EValues: {
      V v_es_24786 = heff_field(v_x_24664, 0);
      heff_take_n(v_x_24664, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_24663_24MkPair, 2);
      V v_t_24787 = (g_heff_2ecompile_2esimplify_2ezipL(v_xs_24658, v_es_24786));
      V v_t_24788 = ({ V a_0 = v_t_24787; V a_1 = v_b_24660; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_24787); r_; });
      V f_ = heff_get_n(v_r_240, 0, 4);
      heff_room[0] = v_t_24788;
      heff_room[1] = v_s_24665;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_EFix: {
      V v_m_24791 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24660}));
      V v_x2_24792 = heff_tr(heff_call(v_m_24791, 1, (V[]){v_s_24665}));
      switch (heff_tag_of(v_x2_24792)) {
      case TAG_MkPair: {
        V v_x_24793 = heff_field(v_x2_24792, 0);
        V v_s_24794 = heff_field(v_x2_24792, 1);
        heff_take_n(v_x2_24792, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24663_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24658, v_x_24664, v_x_24793}), v_s_24794});
      }
      default: return heff_nomatch(v_x2_24792);
      }
    }
    default: return heff_nomatch(v_x_24664);
    }
  }
  default: return heff_nomatch(v_x2_24663);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam117(V self, V *args) {
  V v_a_24796 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24796;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam118(V self, V *args) {
  V v_s_24798 = args[0];
  V v_m_24797 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24799 = heff_tr(heff_call(v_m_24797, 1, (V[]){v_s_24798}));
  switch (heff_tag_of(v_x2_24799)) {
  case TAG_MkPair: {
    V v_x_24800 = heff_field(v_x2_24799, 0);
    V v_s_24801 = heff_field(v_x2_24799, 1);
    V v_ru_24x2_24799_24MkPair = heff_take_reuse_n(v_x2_24799, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24799_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24800}), v_s_24801});
  }
  default: return heff_nomatch(v_x2_24799);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam119(V self, V *args) {
  V v_s_24804 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24804});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0, 1, "p");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V v_k_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_fuel_243 = heff_take_field(v_s_241, 1);
  V v_defs_244 = heff_take_field(v_s_241, 2);
  V v_safe_245 = heff_take_field(v_s_241, 3);
  V v_base_246 = heff_take_field(v_s_241, 4);
  V v_total_247 = heff_take_field(v_s_241, 5);
  V v_plain_248 = heff_take_field(v_s_241, 6);
  V v_sp_249 = heff_take_field(v_s_241, 7);
  V v_kp_2410 = heff_get_n(v_s_241, 8, 9);
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_supply_242});
  V v_t_2412 = (g_list_2erange(MK_INT(1LL), v_k_240));
  V v_t_2413 = (g_list_2efoldl_24s1794308634x1384130934(((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0), ((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1), MK_INT(1LL), v_t_2411, v_t_2412));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_MkPair: {
    V v_xs_2414 = heff_field(v_t_2413, 0);
    V v_n_2415 = heff_field(v_t_2413, 1);
    heff_take_n(v_t_2413, 3ULL, 2);
    V v_f_2416 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n_2415, v_fuel_243, v_defs_244, v_safe_245, v_base_246, v_total_247, v_plain_248, v_sp_249, v_kp_2410});
    return ((HeffT2){{v_xs_2414, v_f_2416}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_2413)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_argv_243, V v_s_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str0), heff_intShow(v_t_245));
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_s_244, 6); V b_1 = heff_strAppend(heff_dup(v_g_242), v_t_246); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_g_242);
      V v_it1_2410 = v_field_249;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Inlined: {
        V v_ps_2411 = heff_field(v_it1_2410, 0);
        V v_e_2412 = heff_field(v_it1_2410, 1);
        V v_ru_24it1_2410_24Inlined = heff_take_reuse_n(v_it1_2410, 3ULL, 2);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 1)))) {
          heff_drop(v_f_241);
          V v_t_2413 = heff_intSub(heff_take_field(v_s_244, 1), MK_INT(1LL));
          V v_t_2414 = ({ V rv_1 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_244, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_2412, v_t_2414));
          {
            V v_field_2416 = v_t_2415.f[0];
            V v_field_2417 = v_t_2415.f[1];
            V v_x_2418 = v_field_2416;
            V v_s_2419 = v_field_2417;
            V v_t_2420 = (g_heff_2ecompile_2esimplify_2ezipL(v_ps_2411, v_argv_243));
            V v_m_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_2420); r_; });
            V v_t_2422 = (g_std_2emap_2esize(v_m_2421));
            V v_x_2423;
            if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
              heff_drop(v_m_2421);
              v_x_2423 = v_x_2418;
            } else {
              v_x_2423 = ({ V a_0 = v_m_2421; V a_1 = v_x_2418; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2421); r_; });
            }
            return heff_tag_at_n(v_ru_24it1_2410_24Inlined, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2419});
          }
        } else {
          heff_drop(v_ps_2411);
          heff_drop(v_e_2412);
          V v_x_2424 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
          return heff_tag_at_n(v_ru_24it1_2410_24Inlined, TAG_MkPair, 2, (V[]){v_x_2424, v_s_244});
        }
      }
      case TAG_NotInlined: {
        V v_x_2425 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_s_244});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    } else {
      heff_drop(v_field_249);
      V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
      HeffT2 v_t_2427 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2426, heff_dup(v_s_244)));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_x_2430 = v_field_2428;
        V v_s_2431 = v_field_2429;
        V v_t_2432 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_2431, 2), v_g_242));
        HeffT2 v_t_2433 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2432, v_s_2431));
        {
          V v_field_2434 = v_t_2433.f[0];
          V v_field_2435 = v_t_2433.f[1];
          V v_x_2436 = v_field_2434;
          V v_s_2437 = v_field_2435;
          switch (heff_tag_of(v_x_2436)) {
          case TAG_Nothing: {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_g_242);
            heff_drop_rec(v_s_244, 9);
            heff_drop(v_x_2430);
            V v_x_2438 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_s_2437});
          }
          case TAG_Just: {
            V v_b_2439 = heff_field(v_x_2436, 0);
            V v_ru_24x_2436_24Just = heff_take_reuse_n(v_x_2436, 1ULL, 1);
            V v_t_2440 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24x_2436_24Just, heff_dup(v_x_2430)));
            V v_m_2441 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2439, v_t_2440}));
            V v_x2_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_s_2437}));
            switch (heff_tag_of(v_x2_2442)) {
            case TAG_MkPair: {
              V v_x_2443 = heff_field(v_x2_2442, 0);
              V v_s_2444 = heff_field(v_x2_2442, 1);
              V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
              V v_e_2445 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_argv_243)));
              V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2445, NTAG(TAG_Nil)});
              V v_t_2447 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2446));
              V v_lim_2448 = heff_intAdd(v_t_2447, MK_INT(24LL));
              V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2443), NTAG(TAG_Nil)});
              V v_x_2450 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2448), MK_INT(0LL), v_t_2449));
              if (!heff_intLt_c_lent(v_lim_2448, v_x_2450, 0)) {
                heff_drop(v_f_241);
                heff_drop_rec(v_s_244, 9);
                heff_drop(v_lim_2448);
                heff_drop(v_x_2450);
                V v_t_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
                V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str1), heff_intShow(v_t_2451));
                V v_t_2453 = heff_strAppend(v_g_242, v_t_2452);
                HeffT2 v_t_2454 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2453, heff_tag_n(TAG_Inlined, 2, (V[]){heff_dup(v_x_2430), heff_dup(v_x_2443)}), v_s_2444));
                {
                  V v_field_2455 = v_t_2454.f[0];
                  V v_field_2456 = v_t_2454.f[1];
                  V v_x_2457 = v_field_2455;
                  heff_drop(v_x_2457);
                  V v_s_2458 = v_field_2456;
                  V v_t_2459 = (g_heff_2ecompile_2esimplify_2ezipL(v_x_2430, v_argv_243));
                  V v_m_2460 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2459; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_t_2459); r_; });
                  V v_t_2461 = (g_std_2emap_2esize(v_m_2460));
                  V v_x_2462;
                  if (heff_intEq_c(v_t_2461, MK_INT(0LL))) {
                    heff_drop(v_m_2460);
                    v_x_2462 = v_x_2443;
                  } else {
                    v_x_2462 = ({ V a_0 = v_m_2460; V a_1 = v_x_2443; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2460); r_; });
                  }
                  return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){v_x_2462, v_s_2458});
                }
              } else {
                heff_drop(v_x_2430);
                heff_drop(v_x_2443);
                heff_drop(v_lim_2448);
                heff_drop(v_x_2450);
                V v_t_2463 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
                V v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str2), heff_intShow(v_t_2463));
                V v_t_2465 = heff_strAppend(v_g_242, v_t_2464);
                V v_t_2466 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_2444, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
                HeffT2 v_t_2467 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2465, NTAG(TAG_NotInlined), v_t_2466));
                {
                  V v_field_2468 = v_t_2467.f[0];
                  V v_field_2469 = v_t_2467.f[1];
                  V v_x_2470 = v_field_2468;
                  heff_drop(v_x_2470);
                  V v_s_2471 = v_field_2469;
                  V v_x_2472 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_argv_243));
                  return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_s_2471});
                }
              }
            }
            default: return heff_nomatch(v_x2_2442);
            }
          }
          default: return heff_nomatch(v_x_2436);
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eworthIt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eworthIt_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eworthIt(V v_kinds_240, V v_argv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_argv_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_b_247 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2esimplify_2etoldTo(heff_dup(v_b_247), heff_dup(v_xs_246), heff_dup(v_argv_241)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_argv_241);
        heff_drop_cell(v_ru_24x31_243_24ELam, 2);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_b_247})});
      } else {
        heff_drop(v_t_248);
        V v_t_249 = ({ V a_0 = v_kinds_240; V b_1 = heff_tag_at_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_246), heff_dup(v_b_247)}); V a_2 = v_argv_241; V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_b_247})});
        } else {
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_xs_246);
          heff_drop(v_b_247);
          heff_drop(v_t_249);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBool: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EValues: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_argv_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eworthIt(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str4, 1, ")");
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKey_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2especKey(V v_g_240, V v_marks_241, V v_vars_242, V v_argv_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_marks_241));
  V v_t_245 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_244, v_argv_243));
  V v_x2_249 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2esimplify_2especKey_lam0, 2, 1, (V[]){v_vars_242}), v_marks_241, v_t_245));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especKey_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2esimplify_2especKey_str4)));
  return heff_strAppend(v_g_240, v_t_2413);
}
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKey(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args) {
  V v_m_246 = args[0];
  V v_a_247 = args[1];
  V v_vars_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_m_246) == NTAG(TAG_True))) {
    heff_drop(v_m_246);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_242));
    return ({ V a_0 = v_t_248; V a_1 = v_a_247; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_a_247); r_; });
  } else {
    heff_drop(v_m_246);
    heff_drop(v_a_247);
    heff_drop(v_vars_242);
    return ((V)&g_heff_2ecompile_2esimplify_2especKey_str0);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_f_247;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
    v_f_247 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 3), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
      v_f_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_245);
      v_f_247 = v_s_242;
    }
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_247}});
}

HeffT2 g_heff_2ecompile_2esimplify_2emarkCopySafe_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_f_249;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 4), heff_dup(v_h_240), NTAG(TAG_MkUnit)));
    V v_t_245 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
    v_f_249 = ({ V rv_3 = v_t_245; V rv_4 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 4), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 4), heff_dup(v_h_240), NTAG(TAG_MkUnit)));
      V v_t_248 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
      v_f_249 = ({ V rv_3 = v_t_248; V rv_4 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_246);
      v_f_249 = v_s_242;
    }
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_249}});
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_x3_242, 0);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    HEFF_LAST return g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_argv_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_g_2410 = heff_field(v_x31_247, 0);
      return (g_heff_2ecompile_2esimplify_2epartialMore(v_safe_240, v_all_241, v_g_2410, heff_dup(v_argv_248)));
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_2449 = heff_field(v_x3_242, 1);
    V v_b_2450 = heff_field(v_x3_242, 2);
    V v_t_2451 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2449));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2450;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2451);
      return MK_INT(0LL);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2461 = heff_field(v_x3_242, 0);
    V v_arms_2462 = heff_field(v_x3_242, 1);
    V v_t_2463 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2461));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      switch (heff_tag_of(v_arms_2462)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return MK_INT(0LL);
      }
      case TAG_Cons: {
        V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2467 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2462)));
        V v_x1_2468 = (g_list_2emap(v_t_2466, v_t_2467));
        switch (heff_tag_of(v_x1_2468)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2469 = heff_field(v_x1_2468, 0);
          V v_xs_2470 = heff_field(v_x1_2468, 1);
          heff_take_n(v_x1_2468, 3ULL, 2);
          return ({ V a_0 = v_x_2469; V a_1 = v_xs_2470; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_xs_2470); r_; });
        }
        default: return heff_nomatch(v_x1_2468);
        }
      }
      default: return heff_nomatch(v_arms_2462);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2463);
      return MK_INT(0LL);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    V v_a_2485 = heff_field(v_x3_242, 1);
    V v_b_2486 = heff_field(v_x3_242, 2);
    V v_t_2487 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2485));
    if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
      heff_drop(v_t_2487);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2486;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2487);
      return MK_INT(0LL);
    }
  }
  case TAG_EValues: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_argv_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2emarkedOf_24dps(v_ms_243, v_argv_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_argv_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efromKept_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2esimplify_2efromKept_24cpr(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 8)), 0, 5);
  HeffT2 v_t_243 = ({ V a_0 = v_t_242; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_v_246 = v_field_245;
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 8)), 1, 5);
      HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_kc_2411 = v_field_2410;
          if ((heff_strEq_c(heff_dup(heff_rfield(v_kc_2411, 0)), heff_dup(v_v_246)) && !heff_strEq_c_lent(v_v_246, ((V)&g_heff_2ecompile_2esimplify_2efromKept_24cpr_str0), 2))) {
            heff_drop(v_v_246);
            V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
            return ({ V a_0 = v_h_240; V a_1 = v_kc_2411; V a_2 = v_t_2412; V a_3 = v_s_241; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2easkKept_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
          } else {
            heff_drop(v_h_240);
            heff_drop(v_v_246);
            heff_drop_rec(v_kc_2411, 5);
            return ((HeffT2){{NTAG(TAG_False), v_s_241}});
          }
        } else {
          heff_drop(v_h_240);
          heff_drop(v_v_246);
          heff_drop(v_field_2410);
          return ((HeffT2){{NTAG(TAG_False), v_s_241}});
        }
      }
    } else {
      heff_drop(v_h_240);
      heff_drop(v_field_245);
      return ((HeffT2){{NTAG(TAG_False), v_s_241}});
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2emadeKept_24cpr(V v_km_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_km_240, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_get_n(v_km_240, 1, 2), v_p_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_243, v_s_248));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_s_2413 = v_field_2411;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413}});
        }
      } else {
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ekeptMade_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2esimplify_2ekeptMade_24cpr(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 8)), 0, 5);
  HeffT2 v_t_243 = ({ V a_0 = v_t_242; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_v_246 = v_field_245;
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 8)), 1, 5);
      HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_kc_2411 = v_field_2410;
          V v_ver_2412 = heff_take_field(v_kc_2411, 0);
          V v_made_2413 = heff_get_n(v_kc_2411, 4, 5);
          if ((heff_strEq_c_lent(v_ver_2412, v_v_246, 0) && !heff_strEq_c_lent(v_v_246, ((V)&g_heff_2ecompile_2esimplify_2ekeptMade_24cpr_str0), 2))) {
            heff_drop(v_v_246);
            heff_drop(v_ver_2412);
            switch (heff_tag_of(v_made_2413)) {
            case TAG_Nothing: {
              return ((HeffT2){{NTAG(TAG_Nothing), v_s_241}});
            }
            case TAG_Just: {
              V v_km_2414 = heff_field(v_made_2413, 0);
              heff_take_n(v_made_2413, 1ULL, 1);
              V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_km_2414, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
              return (g_heff_2ecompile_2esimplify_2emadeKept_24cpr(v_km_2414, v_t_2415, v_s_241));
            }
            default: return ((HeffT2){{heff_nomatch(v_made_2413)}});
            }
          } else {
            heff_drop(v_v_246);
            heff_drop(v_ver_2412);
            heff_drop(v_made_2413);
            return ((HeffT2){{NTAG(TAG_Nothing), v_s_241}});
          }
        } else {
          heff_drop(v_v_246);
          heff_drop(v_field_2410);
          return ((HeffT2){{NTAG(TAG_Nothing), v_s_241}});
        }
      }
    } else {
      heff_drop(v_field_245);
      return ((HeffT2){{NTAG(TAG_Nothing), v_s_241}});
    }
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especKnown_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKnown_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especKnown(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_made_245, V v_s_246) {
top: ;
  V v_t_2415 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especKnown_lam0, 1, 3, (V[]){heff_dup(v_s_246), heff_dup(v_argv_244), heff_dup(v_g_241)}), v_argv_244));
  V v_t_2422;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2422 = NTAG(TAG_False);
  } else {
    heff_drop(v_t_2415);
    V v_t_2416 = (g_list_2eany_24s378803910x892125795(v_argv_244));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
      V v_t_2419 = ({ V a_0 = v_g_241; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        v_t_2422 = NTAG(TAG_False);
      } else {
        heff_drop(v_t_2419);
        V v_x1_2420 = (g_list_2eany_24s228396297x1310020012(v_made_245));
        v_t_2422 = heff_bool(!(heff_dup(v_x1_2420) == NTAG(TAG_True)));
        heff_drop(v_x1_2420);
      }
    } else {
      heff_drop(v_t_2416);
      V v_x1_2421 = (g_list_2eany_24s228396297x1310020012(v_made_245));
      v_t_2422 = heff_bool(!(heff_dup(v_x1_2421) == NTAG(TAG_True)));
      heff_drop(v_x1_2421);
    }
  }
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_made_245);
    heff_drop(v_t_2422);
    V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_246});
  } else {
    heff_drop(v_t_2422);
    V v_t_2424 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2425 = (g_heff_2ecompile_2eir_2enubI(v_t_2424));
    V v_loop_2426 = ({ V a_0 = v_g_241; V a_1 = v_t_2425; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2429;
    if ((heff_dup(v_loop_2426) == NTAG(TAG_True))) {
      V v_t_2428 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
    } else {
      v_t_2429 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
    }
    V v_t_2436 = ({ V a_0 = v_loop_2426; V a_1 = v_t_2427; V a_2 = heff_clo_n(g_heff_2ecompile_2esimplify_2especKnown_lam1, 1, 3, (V[]){heff_dup(v_s_246), heff_dup(v_argv_244), heff_dup(v_g_241)}); V a_3 = heff_dup(v_argv_244); V a_4 = v_t_2429; V a_5 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2esimplify_2emarkGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_loop_2426); heff_drop(v_t_2427); r_; });
    V v_t_2437 = (g_heff_2ecompile_2esimplify_2eorMarks(v_t_2436, v_made_245));
    HEFF_LAST return g_heff_2ecompile_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_t_2437, v_s_246);
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKnown(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args) {
  V v_a_247 = args[0];
  V v_s_246 = heff_env(self)[0];
  V v_argv_244 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = heff_dup(v_a_247); V r_ = (g_heff_2ecompile_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_248); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_a_247);
    heff_drop_rec(v_s_246, 9);
    heff_drop(v_argv_244);
    heff_drop(v_g_241);
    heff_drop(v_t_249);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_249);
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
    V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_a_247; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      heff_drop_rec(v_s_246, 9);
      heff_drop(v_argv_244);
      heff_drop(v_g_241);
      heff_drop(v_t_2411);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
      V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_argv_244; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_argv_244); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = heff_get_n(heff_get_n(v_s_246, 7, 9), 0, 7);
        return ({ V a_0 = v_t_2414; V a_1 = v_g_241; V a_2 = v_a_247; V r_ = (g_heff_2ecompile_2esimplify_2eloopBack(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
      } else {
        heff_drop(v_a_247);
        heff_drop_rec(v_s_246, 9);
        heff_drop(v_g_241);
        heff_drop(v_t_2413);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_lam1(V self, V *args) {
  V v_e_2430 = args[0];
  V v_s_246 = heff_env(self)[0];
  V v_argv_244 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
  V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = v_e_2430; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2431); r_; });
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop(v_e_2430);
    heff_drop_rec(v_s_246, 9);
    heff_drop(v_argv_244);
    heff_drop(v_g_241);
    heff_drop(v_t_2432);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2432);
    V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2434 = ({ V a_0 = v_t_2433; V a_1 = v_argv_244; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2433); heff_drop(v_argv_244); r_; });
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      V v_t_2435 = heff_get_n(heff_get_n(v_s_246, 7, 9), 0, 7);
      return ({ V a_0 = v_t_2435; V a_1 = v_g_241; V a_2 = v_e_2430; V r_ = (g_heff_2ecompile_2esimplify_2eloopBack(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
    } else {
      heff_drop(v_e_2430);
      heff_drop_rec(v_s_246, 9);
      heff_drop(v_g_241);
      heff_drop(v_t_2434);
      return NTAG(TAG_False);
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2eetaKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaKept(V v_saved_240, V v_x2_241, V v_lam1_242, V v_p_243) {
top: ;
  V v_defs_244 = heff_take_field(v_saved_240, 2);
  V v_total_245 = heff_get_n(v_saved_240, 5, 9);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_bds_246 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2esimplify_2eetaCapturing(heff_dup(v_lam1_242)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_defs_244);
      heff_drop(v_total_245);
      heff_drop(v_t_248);
      V v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_bds_246, v_lam1_242})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_p_243});
    } else {
      heff_drop(v_lam1_242);
      heff_drop(v_bds_246);
      heff_drop(v_t_248);
      V v_t_2410 = ({ V rv_2 = v_defs_244; V rv_5 = v_total_245; V rr_ = heff_rec_reuse_nf(v_p_243, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_t_2410});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaKept(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_240, v_h_249, 0));
      return v_ret_24bool;
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_kp_243 = heff_take_field(v_s_242, 8);
  V v_supply_244 = heff_take_field(v_s_242, 0);
  V v_fuel_245 = heff_take_field(v_s_242, 1);
  V v_defs_246 = heff_take_field(v_s_242, 2);
  V v_safe_247 = heff_take_field(v_s_242, 3);
  V v_base_248 = heff_take_field(v_s_242, 4);
  V v_total_249 = heff_take_field(v_s_242, 5);
  V v_plain_2410 = heff_take_field(v_s_242, 6);
  V v_sp_2411 = heff_get_n(v_s_242, 7, 9);
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_kp_243, 4), v_h_240));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    V v_k_2415 = heff_dup(v_kp_243);
    V v_vers_2416 = heff_take_field(v_k_2415, 0);
    V v_kept_2417 = heff_take_field(v_k_2415, 1);
    V v_fresh_2418 = heff_take_field(v_k_2415, 3);
    V v_madeFresh_2419 = heff_get_n(v_k_2415, 4, 5);
    V v_t_2421;
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2414;
      v_t_2421 = v_x_2420;
    } else {
      heff_drop(v_field_2414);
      v_t_2421 = NTAG(TAG_Nil);
    }
    V v_t_2422 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_244, v_fuel_245, v_defs_246, v_safe_247, v_base_248, v_total_249, v_plain_2410, v_sp_2411, heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2416, v_kept_2417, v_t_2421, v_fresh_2418, v_madeFresh_2419})});
    HeffT2 v_t_2423 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_t_2422));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_x_2426 = v_field_2424;
      heff_drop(v_x_2426);
      V v_s_2427 = v_field_2425;
      V v_m_2428 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b_241));
      V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2427}));
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_MkPair: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_s_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2430, v_s_2431));
        {
          V v_field_2433 = v_t_2432.f[0];
          V v_field_2434 = v_t_2432.f[1];
          V v_x_2435 = v_field_2433;
          V v_s_2436 = v_field_2434;
          V v_kp_2437 = heff_take_field(v_s_2436, 8);
          V v_supply_2438 = heff_take_field(v_s_2436, 0);
          V v_fuel_2439 = heff_take_field(v_s_2436, 1);
          V v_defs_2440 = heff_take_field(v_s_2436, 2);
          V v_safe_2441 = heff_take_field(v_s_2436, 3);
          V v_base_2442 = heff_take_field(v_s_2436, 4);
          V v_total_2443 = heff_take_field(v_s_2436, 5);
          V v_plain_2444 = heff_take_field(v_s_2436, 6);
          V v_sp_2445 = heff_get_n(v_s_2436, 7, 9);
          V v_k_2446 = heff_dup(v_kp_2437);
          V v_vers_2447 = heff_take_field(v_k_2446, 0);
          V v_kept_2448 = heff_take_field(v_k_2446, 1);
          V v_fresh_2449 = heff_take_field(v_k_2446, 3);
          V v_madeFresh_2450 = heff_get_n(v_k_2446, 4, 5);
          V v_t_2451 = (g_std_2emap_2einsert_24s93785294x875597928(v_madeFresh_2450, v_h_240, heff_get_n(v_kp_2437, 2, 5)));
          V v_k_2452 = ({ V rv_0 = v_vers_2447; V rv_1 = v_kept_2448; V rv_3 = v_fresh_2449; V rv_4 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_kp_243, 4ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_f_2453 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_2438, v_fuel_2439, v_defs_2440, v_safe_2441, v_base_2442, v_total_2443, v_plain_2444, v_sp_2445, v_k_2452});
          return ((HeffT2){{v_x_2435, v_f_2453}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2429)}});
      }
    }
  }
}