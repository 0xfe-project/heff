// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Inlined 13187
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define TAG_Perform 19235
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_unrolled 706233391
#define LBL_vers 10111479
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static uint32_t shape_tags__names__body[] = {LBL_tags, LBL_names, LBL_body};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ebuilds(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_clo;
V g_heff_2ecompile_2esimplify_2ecallsW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallsW_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efirstCalled(V, V);
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo;
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(V, V);
V g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024_clo;
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efreshNames(V, V, V);
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshNames_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshNames_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ehandedOn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_clo;
V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348_clo;
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_clo;
V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s477650497x932674259(V, V);
V g_list_2eany_24s477650497x932674259_entry(V self, V *a);
extern Clo g_list_2eany_24s477650497x932674259_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1587638778x899913804(V, V, V, V, V);
V g_list_2efoldl_24s1587638778x899913804_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1587638778x899913804_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f658301291x587486003(V, V);
V g_prelude_2e_2b_2b_24f658301291x587486003_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f658301291x587486003_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_safe_240; V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_g_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_247); c_; })));
      heff_drop(v_field_246);
      return v_ret_24bool;
    }
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_2410 = heff_field(v_e_242, 0);
    V v_argv_2411 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2410)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_e1_2410, 0);
      heff_take_n(v_e1_2410, 1ULL, 1);
      HeffT2 v_t_2414 = ({ V a_0 = v_total_241; V a_1 = v_g_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2413); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_ar_2417 = v_field_2416;
          V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2411));
          if (heff_intLe_c(v_t_2418, v_ar_2417)) {
            V v_t_2420 = (g_list_2emap_24tok2(v_ru_24e_242_24EApp, heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_argv_2411));
            return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
          } else {
            heff_drop(v_argv_2411);
            heff_drop_cell(v_ru_24e_242_24EApp, 2);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_argv_2411);
          heff_drop_cell(v_ru_24e_242_24EApp, 2);
          heff_drop(v_field_2416);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2410, 0ULL, 4);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2410, 0ULL, 3);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2410, 0ULL, 1);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2410, 0ULL, 2);
      heff_drop(v_argv_2411);
      heff_drop_cell(v_ru_24e_242_24EApp, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_2410);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_e_242, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_sc_2461 = heff_field(v_e_242, 0);
    V v_arms_2462 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2463 = (g_heff_2ecompile_2esimplify_2epureIn(v_safe_240, v_total_241, v_sc_2461));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      switch (heff_tag_of(v_arms_2462)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24e_242_24EMatch, 2);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2471 = (g_list_2emap_24tok2(v_ru_24e_242_24EMatch, heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_arms_2462));
        return ({ V a_0 = v_t_2471; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2471); r_; });
      }
      default: return heff_nomatch(v_arms_2462);
      }
    } else {
      heff_drop(v_arms_2462);
      heff_drop_cell(v_ru_24e_242_24EMatch, 2);
      heff_drop(v_t_2463);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrimCall: {
    V v_p_2472 = heff_field(v_e_242, 0);
    V v_argv_2473 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_p_2472)) {
    case TAG_IntShl: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      heff_drop(v_argv_2473);
      heff_drop_cell(v_ru_24e_242_24EPrimCall, 2);
      return NTAG(TAG_False);
    }
    default: {
      heff_drop(v_p_2472);
      V v_t_2475 = (g_list_2emap_24tok2(v_ru_24e_242_24EPrimCall, heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_argv_2473));
      return ({ V a_0 = v_t_2475; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2475); r_; });
    }
    }
  }
  case TAG_ECall: {
    V v_g_2476 = heff_field(v_e_242, 0);
    V v_argv_2477 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2478 = ({ V a_0 = v_total_241; V a_1 = v_g_2476; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2476); r_; });
    {
      V v_field_2480 = v_t_2478.f[1];
      int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
      if ((v_tag_2479 == ((int64_t)0ULL))) {
        V v_ar_2481 = v_field_2480;
        V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2477));
        if (heff_intLe_c(v_t_2482, v_ar_2481)) {
          V v_t_2484 = (g_list_2emap_24tok2(v_ru_24e_242_24ECall, heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_argv_2477));
          return ({ V a_0 = v_t_2484; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2484); r_; });
        } else {
          heff_drop(v_argv_2477);
          heff_drop_cell(v_ru_24e_242_24ECall, 2);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_argv_2477);
        heff_drop_cell(v_ru_24e_242_24ECall, 2);
        heff_drop(v_field_2480);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: {
    V v_t_2487 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, NTAG(TAG_Nil)));
    V v_t_2489 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), v_t_2487));
    return ({ V a_0 = v_t_2489; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2489); r_; });
  }
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2419 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2419; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_b_2466 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470;
  switch (heff_tag_of(v_b_2466)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_b_2466, 2);
    heff_take_n(v_b_2466, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_b_2466);
  }
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_t_2470; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2474 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2474; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_a_2483 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2483; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2488 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2488; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); r_; });
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_x_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      V v_t_246 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), heff_dup(v_b_244)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_xs_248 = (g_heff_2ecompile_2eir_2enubI(v_t_247));
        V v_x1_249 = ({ V a_0 = v_key_241; V a_1 = v_xs_248; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_248); r_; });
        if (!(heff_dup(v_x1_249) == NTAG(TAG_True))) {
          heff_drop(v_x1_249);
          V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_acc_240, 0), heff_dup(v_key_241), NTAG(TAG_MkUnit)));
          V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2412 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_get_n(v_acc_240, 1, 2), v_key_241, v_t_2411));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2410, v_t_2412});
        } else {
          heff_drop(v_x1_249);
          V v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2414 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      V v_t_2415 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), heff_dup(v_b_244)));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_xs_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
        V v_x1_2418 = ({ V a_0 = v_key_241; V a_1 = v_xs_2417; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2417); r_; });
        if (!(heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_x1_2418);
          V v_t_2419 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_key_241);
          heff_drop(v_x1_2418);
          return v_acc_240;
        }
      } else {
        heff_drop(v_key_241);
        heff_drop(v_t_2415);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str1, 6, "MkLazy");

HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_e1_2420 = heff_field(v_e_241, 0);
    V v_e2_2421 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2420)) {
    case TAG_EVar: {
      V v_z_2422 = heff_field(v_e1_2420, 0);
      heff_take_n(v_e1_2420, 1ULL, 1);
      switch (heff_tag_of(v_e2_2421)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24e_241_24EMatch, 2);
        heff_drop(v_z_2422);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_e21_2423 = heff_field(v_e2_2421, 0);
        V v_e22_2424 = heff_field(v_e2_2421, 1);
        V v_ru_24e2_2421_24Cons = heff_take_reuse_n(v_e2_2421, 3ULL, 2);
        switch (heff_tag_of(v_e21_2423)) {
        case TAG_MkArm: {
          V v_t_2425 = heff_field(v_e21_2423, 0);
          V v_vs_2426 = heff_field(v_e21_2423, 1);
          V v_b_2427 = heff_field(v_e21_2423, 2);
          heff_take_n(v_e21_2423, 7ULL, 3);
          switch (heff_tag_of(v_e22_2424)) {
          case TAG_Nil: {
            V v_t_24109;
            if (heff_strEq_c_lent(v_x_240, v_z_2422, 2)) {
              if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str0), 2)) {
                v_t_24109 = NTAG(TAG_False);
              } else {
                V v_t_24119;
                switch (heff_tag_of(v_vs_2426)) {
                case TAG_Nil: {
                  v_t_24119 = NTAG(TAG_False);
                  break;
                }
                case TAG_Cons: {
                  v_t_24119 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_vs_2426);
                }
                switch (heff_tag_of(v_t_24119)) {
                case TAG_True: {
                  v_t_24109 = heff_bool(((heff_strEq_c_lent(v_t_2425, ((V)&g_heff_2ecompile_2esimplify_2eapartOf_24cpr_str1), 2) ? 0 : ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2425, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2425, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)) && ({ V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2427), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2431 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2430))); int c_ = ({ V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2427), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2433 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2432))); int c_ = ({ V v_t_24120 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2431), heff_dup(v_t_2433)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_24120, MK_INT(0LL), 2); heff_drop(v_t_24120); c_; }); heff_drop(v_t_2433); c_; }); heff_drop(v_t_2432); c_; }); heff_drop(v_t_2431); c_; }); heff_drop(v_t_2430); c_; })));
                  break;
                }
                case TAG_False: {
                  v_t_24109 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_t_24119);
                }
              }
            } else {
              v_t_24109 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_24109)) {
            case TAG_True: {
              V v_t_2434 = v_t_2425;
              V v_vs_2435 = heff_dup(v_vs_2426);
              V v_b_2436 = heff_dup(v_b_2427);
              V v_x1_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2426));
              V v_x4_2440;
              switch (heff_tag_of(v_x1_2437)) {
              case TAG_Nil: {
                heff_drop(v_b_2427);
                v_x4_2440 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_x_2438 = heff_field(v_x1_2437, 0);
                heff_take_n(v_x1_2437, 1ULL, 2);
                v_x4_2440 = ({ V a_0 = v_x_2438; V a_1 = v_b_2427; V r_ = (g_heff_2ecompile_2esimplify_2eapartOf(a_0, a_1)); heff_drop(v_x_2438); r_; });
                break;
              }
              default: heff_nomatch(v_x1_2437);
              }
              V v_f_2447;
              switch (heff_tag_of(v_x4_2440)) {
              case TAG_Nothing: {
                V v_t_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2435));
                V v_t_2442 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e2_2421_24Cons, TAG_MkPair, 2, (V[]){v_t_2434, v_t_2441}), NTAG(TAG_Nil)});
                v_f_2447 = heff_rec_n(3, shape_tags__names__body, (V[]){v_t_2442, v_vs_2435, v_b_2436});
                break;
              }
              case TAG_Just: {
                V v_ap_2443 = heff_field(v_x4_2440, 0);
                heff_take_n(v_x4_2440, 1ULL, 1);
                heff_drop(v_b_2436);
                V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2435));
                V v_t_2445 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e2_2421_24Cons, TAG_MkPair, 2, (V[]){v_t_2434, v_t_2444}), heff_dup(heff_rfield(v_ap_2443, 0))});
                V v_t_2446 = (g_prelude_2e_2b_2b_24f658301291x587486003(heff_take_field(v_ap_2443, 1), v_vs_2435));
                v_f_2447 = ({ V rv_0 = v_t_2445; V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_ap_2443, 4ULL, 3, shape_tags__names__body, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                break;
              }
              default: heff_nomatch(v_x4_2440);
              }
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2447}});
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24e_241_24EMatch, 2);
              heff_drop_cell(v_ru_24e2_2421_24Cons, 2);
              heff_drop(v_t_2425);
              heff_drop(v_vs_2426);
              heff_drop(v_b_2427);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24109)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_e22_2424, 0ULL, 2);
            heff_drop_cell(v_ru_24e_241_24EMatch, 2);
            heff_drop(v_z_2422);
            heff_drop_cell(v_ru_24e2_2421_24Cons, 2);
            heff_drop(v_t_2425);
            heff_drop(v_vs_2426);
            heff_drop(v_b_2427);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_e22_2424)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_e21_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_e2_2421)}});
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2420, 0ULL, 4);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2420, 0ULL, 3);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2420, 0ULL, 1);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2420, 0ULL, 2);
      heff_drop(v_e2_2421);
      heff_drop_cell(v_ru_24e_241_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_2420)}});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2ebuilds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuilds_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebuilds(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_x312_247 = heff_field(v_x31_243, 1);
      switch (heff_tag_of(v_x312_247)) {
      case TAG_EVar: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EGlobal: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_x312_247, 0);
        V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
        if (heff_intEq_c(v_t_2419, v_n_241)) {
          switch (heff_tag_of(v_fs_2417)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_t_2422 = (g_list_2emap_24s549405518x243689326(heff_dup(v_fs_2417)));
            V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2422); r_; });
            if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
              heff_drop(v_t_2423);
              V v_t_2424 = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(v_fs_2417));
              V v_xs_2425 = (g_heff_2ecompile_2eir_2enubI(v_t_2424));
              V v_x1_2426 = ({ V a_0 = v_g_240; V a_1 = v_xs_2425; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2425); r_; });
              V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
              heff_drop(v_x1_2426);
              return v_ret_24bool;
            } else {
              heff_drop(v_t_2423);
              return NTAG(TAG_False);
            }
          }
          default: return heff_nomatch(v_fs_2417);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EProj: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x312_247);
      }
    }
    case TAG_EApp: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ebuilds(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedOn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ehandedOn(V v_kinds_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_ys_247 = heff_field(v_a_242, 0);
    V v_body_248 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    V v_ret_24bool = heff_bool((heff_intLe_c_lent(v_o_244, MK_INT(2LL), 2) && ({ V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_ys_247), heff_dup(v_body_248)}), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), heff_dup(v_t_249))); int c_ = (heff_intLt_c_lent(MK_INT(160LL), v_x_2410, 1) ? 0 : ({ V v_t_2411 = heff_tr(heff_call(((V)&g_list_2eany_24s604143829x1495140576_clo), 1, (V[]){heff_dup(v_kinds_240)})); int c_ = ({ V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2448 = (g_heff_2ecompile_2esimplify_2ecallsW(v_x_241, heff_dup(v_t_2411), MK_INT(0LL), heff_dup(v_t_2412))); int c_ = heff_intEq_c_lent(v_t_2448, v_o_244, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; })); heff_drop(v_x_2410); c_; }); heff_drop(v_t_249); c_; })));
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    heff_drop(v_ys_247);
    heff_drop(v_body_248);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_242, 0ULL, 4);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_kinds_240);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedOn(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_f_243 = heff_strAppend(heff_strAppend(v_base_240, ((V)&g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0)), heff_intShow(heff_dup(v_n_242)));
  V v_f_244 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_241, 1022ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048572u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return ((HeffT2){{v_f_243, v_f_244}});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldBound(V v_tag_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_a_241, 0);
    V v_e_243 = heff_field(v_a_241, 1);
    V v_c_244 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(v_tag_240, v_c_244));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_e_243});
  }
  case TAG_ETag: {
    V v_a1_2417 = heff_field(v_a_241, 0);
    V v_argv_2418 = heff_field(v_a_241, 1);
    V v_ts_2419 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    return heff_tail(v_tag_240, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_a1_2417, v_argv_2418, v_ts_2419})});
  }
  default: {
    heff_drop(v_tag_240);
    V v_t_2420 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam1, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam2, 1, 1, (V[]){v_a_241});
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_dup(heff_field(v_x_248, 0));
      v_t_2412 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_y_242, v_e_243}), v_t_2412});
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_y_2415 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 2ULL, 2);
      v_t_2416 = v_y_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_t_2416}), v_s_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args) {
  V v_s_2421 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_s_2421});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str0), v_s_2423));
  {
    V v_field_2425 = v_t_2424.f[0];
    V v_field_2426 = v_t_2424.f[1];
    V v_x_2427 = v_field_2425;
    V v_s_2428 = v_field_2426;
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2427), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2427})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_s_2428});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0, 1, "p");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_take_field(v_s_241, 0)});
  V v_t_243 = (g_list_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_list_2efoldl_24s1587638778x899913804(((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0), ((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1), MK_INT(1LL), v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_f_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 1022ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048572u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_xs_245, v_f_247}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_loop_240, V v_all_241, V v_back_242, V v_argv_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_loop_240);
    heff_drop(v_all_241);
    heff_drop(v_back_242);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_246 = heff_field(v_x5_244, 0);
    V v_rest_247 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2425;
    if ((heff_dup(v_st_246) == NTAG(TAG_True))) {
      heff_drop(v_st_246);
      HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), v_argv_243));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          V v_loop_2412 = heff_dup(v_loop_240);
          V v_kinds_2413 = heff_dup(v_all_241);
          V v_back_2414 = heff_dup(v_back_242);
          V v_e_2415 = v_x_2411;
          switch (heff_tag_of(v_e_2415)) {
          case TAG_EGlobal: {
            V v_g_2416 = heff_dup(heff_field(v_e_2415, 0));
            HeffT2 v_t_2417 = ({ V a_0 = v_kinds_2413; V a_1 = v_g_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_kinds_2413); heff_drop(v_g_2416); r_; });
            {
              V v_field_2419 = v_t_2417.f[1];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                heff_drop(v_loop_2412);
                heff_drop(v_back_2414);
                heff_drop_tag(v_e_2415, 1);
                V v_x_2420 = v_field_2419;
                heff_drop(v_x_2420);
                v_t_2425 = NTAG(TAG_True);
              } else {
                heff_drop(v_field_2419);
                if ((heff_dup(v_loop_2412) == NTAG(TAG_True))) {
                  heff_drop(v_loop_2412);
                  V v_t_2421 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_e_2415)));
                  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                    heff_drop(v_back_2414);
                    heff_drop_tag(v_e_2415, 1);
                    heff_drop(v_t_2421);
                    v_t_2425 = NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2421);
                    v_t_2425 = heff_tr(heff_call(v_back_2414, 1, (V[]){v_e_2415}));
                  }
                } else {
                  heff_drop(v_loop_2412);
                  v_t_2425 = heff_tr(heff_call(v_back_2414, 1, (V[]){v_e_2415}));
                }
              }
            }
            break;
          }
          default: {
            heff_drop(v_kinds_2413);
            V v_t_2422 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_e_2415)));
            if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
              heff_drop(v_loop_2412);
              heff_drop(v_back_2414);
              heff_drop(v_e_2415);
              heff_drop(v_t_2422);
              v_t_2425 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2422);
              V v_t_2423 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_e_2415)));
              if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
                heff_drop(v_loop_2412);
                heff_drop(v_back_2414);
                heff_drop(v_e_2415);
                heff_drop(v_t_2423);
                v_t_2425 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2423);
                if ((heff_dup(v_loop_2412) == NTAG(TAG_True))) {
                  heff_drop(v_loop_2412);
                  V v_t_2424 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_e_2415)));
                  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
                    heff_drop(v_back_2414);
                    heff_drop(v_e_2415);
                    heff_drop(v_t_2424);
                    v_t_2425 = NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2424);
                    v_t_2425 = heff_tr(heff_call(v_back_2414, 1, (V[]){v_e_2415}));
                  }
                } else {
                  heff_drop(v_loop_2412);
                  v_t_2425 = heff_tr(heff_call(v_back_2414, 1, (V[]){v_e_2415}));
                }
              }
            }
            break;
          }
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2425 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_246);
      v_t_2425 = NTAG(TAG_False);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = (g_heff_2ecompile_2esimplify_2emarkGo_24dps(v_loop_240, v_all_241, v_back_242, v_argv_243, v_rest_247, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_2426)));
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_x3_242, 0);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    HEFF_LAST return g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_argv_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_g_2410 = heff_field(v_x31_247, 0);
      V v_safe_2411 = v_safe_240;
      V v_all_2412 = v_all_241;
      V v_g_2413 = heff_dup(v_g_2410);
      V v_argv_2414 = heff_dup(v_argv_248);
      V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 2, (V[]){v_safe_2411, heff_dup(v_all_2412)}));
      V v_t_2416 = (g_list_2emap(v_t_2415, heff_dup(v_argv_2414)));
      V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_t_2417);
        V v_x_2418 = (g_heff_2ecompile_2esimplify_2earityIn(v_all_2412, v_g_2413));
        V v_y_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2414));
        if (heff_intLt_c(v_y_2419, v_x_2418)) {
          V v_t_2420 = ({ V a_0 = v_all_2412; V a_1 = v_g_2413; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_all_2412); heff_drop(v_g_2413); r_; });
          V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_2414); r_; });
          return heff_intSub(v_t_2420, v_t_2421);
        } else {
          heff_drop(v_all_2412);
          heff_drop(v_g_2413);
          heff_drop(v_argv_2414);
          return MK_INT(0LL);
        }
      } else {
        heff_drop(v_all_2412);
        heff_drop(v_g_2413);
        heff_drop(v_argv_2414);
        heff_drop(v_t_2417);
        return MK_INT(0LL);
      }
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_2460 = heff_field(v_x3_242, 1);
    V v_b_2461 = heff_field(v_x3_242, 2);
    V v_t_2462 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), heff_dup(v_a_2460)));
    if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
      heff_drop(v_t_2462);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2461;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2462);
      return MK_INT(0LL);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2472 = heff_field(v_x3_242, 0);
    V v_arms_2473 = heff_field(v_x3_242, 1);
    V v_t_2474 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), heff_dup(v_sc_2472)));
    if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
      heff_drop(v_t_2474);
      switch (heff_tag_of(v_arms_2473)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return MK_INT(0LL);
      }
      case TAG_Cons: {
        V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2478 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2473)));
        V v_x1_2479 = (g_list_2emap(v_t_2477, v_t_2478));
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2480 = heff_field(v_x1_2479, 0);
          V v_xs_2481 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 3ULL, 2);
          return ({ V a_0 = v_x_2480; V a_1 = v_xs_2481; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_xs_2481); r_; });
        }
        default: return heff_nomatch(v_x1_2479);
        }
      }
      default: return heff_nomatch(v_arms_2473);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2474);
      return MK_INT(0LL);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    V v_a_2496 = heff_field(v_x3_242, 1);
    V v_b_2497 = heff_field(v_x3_242, 2);
    V v_t_2498 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), heff_dup(v_a_2496)));
    if ((heff_dup(v_t_2498) == NTAG(TAG_True))) {
      heff_drop(v_t_2498);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2497;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2498);
      return MK_INT(0LL);
    }
  }
  case TAG_EValues: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_True), v_p_241}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eargPure_24cpr(heff_dup(v_a_242), v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        V t_0 = v_argv_243;
        V t_1 = v_s_248;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      } else {
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_False), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_240, v_h_249, 0));
      return v_ret_24bool;
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2efirstCalled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efirstCalled_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efirstCalled(V v_k_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    V v_e1_246 = heff_field(v_e_241, 0);
    V v_argv_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EVar: {
      V v_k2_248 = heff_field(v_e1_246, 0);
      heff_take_n(v_e1_246, 1ULL, 1);
      if (heff_strEq_c_lent(v_k_240, v_k2_248, 2)) {
        return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_247); r_; });
      } else {
        heff_drop(v_argv_247);
        return MK_INT(0LL);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ELam: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_take_n(v_e1_246, 0ULL, 4);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EBool: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_ESet: {
      heff_take_n(v_e1_246, 0ULL, 3);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EValues: {
      heff_take_n(v_e1_246, 0ULL, 1);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_take_n(v_e1_246, 0ULL, 2);
      heff_drop(v_argv_247);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_e1_246);
    }
  }
  case TAG_ELet: {
    V v_b_2449 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_k_240;
    V t_1 = v_b_2449;
    v_k_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_e2_2460 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    switch (heff_tag_of(v_e2_2460)) {
    case TAG_Nil: {
      return MK_INT(0LL);
    }
    case TAG_Cons: {
      V v_a_2461 = heff_field(v_e2_2460, 0);
      heff_take_n(v_e2_2460, 1ULL, 2);
      V v_t_2466;
      switch (heff_tag_of(v_a_2461)) {
      case TAG_MkArm: {
        V v_b_2465 = heff_field(v_a_2461, 2);
        heff_take_n(v_a_2461, 4ULL, 3);
        v_t_2466 = v_b_2465;
        break;
      }
      default: heff_nomatch(v_a_2461);
      }
      V t_0 = v_k_240;
      V t_1 = v_t_2466;
      v_k_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_e2_2460);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    V v_b_2482 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_k_240;
    V t_1 = v_b_2482;
    v_k_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2efirstCalled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2efirstCalled(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2efreshNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshNames_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efreshNames(V v_base_240, V v_n_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2efreshNames_24cpr(v_base_240, v_n_241, v_p_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2esimplify_2efreshNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshNames(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps(V v_b_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x2_241, 0);
    V v_ys_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_y_244);
      heff_drop(v_ys_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_x3_242, 0);
      V v_vs_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2447;
      switch (heff_tag_of(v_v_246)) {
      case TAG_EVar: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFixed: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_246);
      }
      if (((heff_dup(v_t_2447) == NTAG(TAG_True)) || ({ V v_c_2454 = (g_heff_2ecompile_2eir_2eisValue(v_v_246)); int c_ = ((heff_dup(v_c_2454) == NTAG(TAG_True)) && ({ V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2449 = (g_heff_2ecompile_2eir_2ecountW(v_y_244, MK_INT(0LL), heff_dup(v_t_2448))); int c_ = ({ V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2451 = (g_heff_2ecompile_2eir_2elamW(v_y_244, heff_dup(v_t_2450))); int c_ = ({ V v_t_2455 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2449), heff_dup(v_t_2451)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2455, MK_INT(0LL), 2); heff_drop(v_t_2455); c_; }); heff_drop(v_t_2451); c_; }); heff_drop(v_t_2450); c_; }); heff_drop(v_t_2449); c_; }); heff_drop(v_t_2448); c_; })); heff_drop(v_c_2454); c_; }))) {
        heff_drop(v_y_244);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_v_246);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2447);
        V t_0 = v_b_240;
        V t_1 = v_ys_245;
        V t_2 = v_vs_247;
        V t_3 = v_d_243;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_2447);
        V v_cell_2452 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_y_244, v_v_246}), heff_hole()});
        V v_u_2453 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2452));
        heff_drop(v_u_2453);
        V t_0 = v_b_240;
        V t_1 = v_ys_245;
        V t_2 = v_vs_247;
        V t_3 = v_cell_2452;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2evaluesGiven_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674(V v_f_240, V v_g_241, V v_argv_242, V v_s_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
  V v_t_245 = heff_strAppend(heff_strAppend(heff_dup(v_g_241), ((V)&g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str0)), heff_intShow(v_t_244));
  HeffT2 v_t_246 = ({ V a_0 = heff_rfield(v_s_243, 6); V a_1 = v_t_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_g_241);
      V v_it1_249 = v_field_248;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Inlined: {
        V v_ps_2410 = heff_field(v_it1_249, 0);
        V v_e_2411 = heff_field(v_it1_249, 1);
        V v_ru_24it1_249_24Inlined = heff_take_reuse_n(v_it1_249, 3ULL, 2);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_243, 1)))) {
          heff_drop(v_f_240);
          V v_t_2412 = heff_intSub(heff_take_field(v_s_243, 1), MK_INT(1LL));
          V v_t_2413 = ({ V rv_1 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_243, 1021ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048563u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          HeffT2 v_t_2414 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_2411, v_t_2413));
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_x_2417 = v_field_2415;
            V v_s_2418 = v_field_2416;
            V v_t_2419 = (g_list_2ezipWith_24s1876717925x1404326288(v_ps_2410, v_argv_242));
            V v_m_2420 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_t_2419); r_; });
            V v_t_2421 = (g_std_2eordmap_2esize(v_m_2420));
            V v_x_2422;
            if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
              heff_drop(v_m_2420);
              v_x_2422 = v_x_2417;
            } else {
              v_x_2422 = ({ V a_0 = v_m_2420; V a_1 = v_x_2417; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2420); r_; });
            }
            return heff_tag_at_n(v_ru_24it1_249_24Inlined, TAG_MkPair, 2, (V[]){v_x_2422, v_s_2418});
          }
        } else {
          heff_drop(v_ps_2410);
          heff_drop(v_e_2411);
          V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
          return heff_tag_at_n(v_ru_24it1_249_24Inlined, TAG_MkPair, 2, (V[]){v_x_2423, v_s_243});
        }
      }
      case TAG_NotInlined: {
        V v_x_2424 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2424, v_s_243});
      }
      default: return heff_nomatch(v_it1_249);
      }
    } else {
      heff_drop(v_field_248);
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
      HeffT2 v_t_2426 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2425, heff_dup(v_s_243)));
      {
        V v_field_2427 = v_t_2426.f[0];
        V v_field_2428 = v_t_2426.f[1];
        V v_x_2429 = v_field_2427;
        V v_s_2430 = v_field_2428;
        V v_t_2431 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_2430, 2), v_g_241));
        HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2431, v_s_2430));
        {
          V v_field_2433 = v_t_2432.f[0];
          V v_field_2434 = v_t_2432.f[1];
          V v_x_2435 = v_field_2433;
          V v_s_2436 = v_field_2434;
          switch (heff_tag_of(v_x_2435)) {
          case TAG_Nothing: {
            heff_drop(v_g_241);
            heff_drop_rec(v_s_243, 10);
            heff_drop(v_x_2429);
            V v_x_2437 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_s_2436});
          }
          case TAG_Just: {
            V v_b_2438 = heff_field(v_x_2435, 0);
            V v_ru_24x_2435_24Just = heff_take_reuse_n(v_x_2435, 1ULL, 1);
            V v_argv_2439 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24x_2435_24Just, heff_dup(v_x_2429)));
            V v_m_2440 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(v_b_2438, v_argv_2439));
            V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2436}));
            switch (heff_tag_of(v_x2_2441)) {
            case TAG_MkPair: {
              V v_x_2442 = heff_field(v_x2_2441, 0);
              V v_s_2443 = heff_field(v_x2_2441, 1);
              V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
              V v_e_2444 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_240), heff_dup(v_argv_242)));
              V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2444, NTAG(TAG_Nil)});
              V v_t_2446 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2445));
              V v_lim_2447 = heff_intAdd(v_t_2446, MK_INT(24LL));
              V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2442), NTAG(TAG_Nil)});
              V v_x_2449 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2447), MK_INT(0LL), v_t_2448));
              if (!heff_intLt_c_lent(v_lim_2447, v_x_2449, 0)) {
                heff_drop(v_f_240);
                heff_drop_rec(v_s_243, 10);
                heff_drop(v_lim_2447);
                heff_drop(v_x_2449);
                V v_t_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
                V v_t_2451 = heff_strAppend(heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str1)), heff_intShow(v_t_2450));
                HeffT2 v_t_2452 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2451, heff_tag_n(TAG_Inlined, 2, (V[]){heff_dup(v_x_2429), heff_dup(v_x_2442)}), v_s_2443));
                {
                  V v_field_2453 = v_t_2452.f[0];
                  V v_field_2454 = v_t_2452.f[1];
                  V v_x_2455 = v_field_2453;
                  heff_drop(v_x_2455);
                  V v_s_2456 = v_field_2454;
                  V v_t_2457 = (g_list_2ezipWith_24s1876717925x1404326288(v_x_2429, v_argv_242));
                  V v_m_2458 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2457; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_t_2457); r_; });
                  V v_t_2459 = (g_std_2eordmap_2esize(v_m_2458));
                  V v_x_2460;
                  if (heff_intEq_c(v_t_2459, MK_INT(0LL))) {
                    heff_drop(v_m_2458);
                    v_x_2460 = v_x_2442;
                  } else {
                    v_x_2460 = ({ V a_0 = v_m_2458; V a_1 = v_x_2442; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2458); r_; });
                  }
                  return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2460, v_s_2456});
                }
              } else {
                heff_drop(v_x_2429);
                heff_drop(v_x_2442);
                heff_drop(v_lim_2447);
                heff_drop(v_x_2449);
                V v_t_2461 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
                V v_t_2462 = heff_strAppend(heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_str2)), heff_intShow(v_t_2461));
                V v_t_2463 = ({ V rv_2 = heff_take_field(v_s_243, 2); V rv_5 = heff_get_n(v_s_243, 5, 10); V rr_ = heff_rec_reuse_nf(v_s_2443, 987ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1045455u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
                HeffT2 v_t_2464 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2462, NTAG(TAG_NotInlined), v_t_2463));
                {
                  V v_field_2465 = v_t_2464.f[0];
                  V v_field_2466 = v_t_2464.f[1];
                  V v_x_2467 = v_field_2465;
                  heff_drop(v_x_2467);
                  V v_s_2468 = v_field_2466;
                  V v_x_2469 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_240, v_argv_242));
                  return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2469, v_s_2468});
                }
              }
            }
            default: return heff_nomatch(v_x2_2441);
            }
          }
          default: return heff_nomatch(v_x_2435);
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall_24s1888172068x2132000674(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(V v_own_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c_lent(MK_INT(16LL), v_d_248, 1)) {
    heff_drop(v_own_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2410 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_z_249});
  } else {
    HeffT2 v_t_2411 = (g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr(v_own_240, v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_x_2414 = v_field_2412;
      heff_drop(v_x_2414);
      V v_s_2415 = v_field_2413;
      V v_t_2416 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_argv_244));
      V v_argv_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_sh_246, 2, 3), v_t_2416));
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2eapplyToF_24s1222514530x261831815(heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_argv_2417));
      return heff_tail(v_t_2418, 1, (V[]){v_s_2415});
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed_24s1863378249x707456681(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam6(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(V v_k_240, V v_f_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_243, v_k_240, 0)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_f_241});
    } else {
      heff_drop(v_f_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EApp: {
    V v_e1_245 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_245)) {
    case TAG_EVar: {
      V v_y_247 = heff_field(v_e1_245, 0);
      heff_take_n(v_e1_245, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_EApp: {
        V v_argv_249 = heff_field(v_e_242, 1);
        heff_take_n(v_e_242, 2ULL, 2);
        if (heff_strEq_c_lent(v_y_247, v_k_240, 0)) {
          heff_drop(v_y_247);
          V v_m_2411 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam1, 1, 2, (V[]){heff_dup(v_k_240), heff_dup(v_f_241)}), v_argv_249));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam2, 1, 2, (V[]){v_m_2411, v_f_241});
        } else {
          V v_m_2423 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam3, 1, 2, (V[]){heff_dup(v_k_240), v_f_241}), v_argv_249));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam4, 1, 2, (V[]){v_m_2423, v_y_247});
        }
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: {
      heff_drop(v_e1_245);
      return (g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam5, 2, 2, (V[]){heff_dup(v_k_240), v_f_241}), v_e_242));
    }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(heff_clo_n(g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam6, 2, 2, (V[]){heff_dup(v_k_240), v_f_241}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam1(V self, V *args) {
  V v_q_2410 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_k_240; V a_1 = v_f_241; V a_2 = v_q_2410; V r_ = (g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_f_241, v_s_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_x_2419 = v_field_2417;
      V v_s_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2ecompile_2esimplify_2efollowerGiven_24s514141109x942028024(v_x_2419, v_x_2414));
      V f_ = v_t_2421;
      args[0] = v_s_2420;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam3(V self, V *args) {
  V v_q_2422 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_k_240; V a_1 = v_f_241; V a_2 = v_q_2422; V r_ = (g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_y_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EVar, 1, (V[]){v_y_247}), v_x_2426));
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_q_2430 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  return ({ V a_0 = v_k_240; V a_1 = v_f_241; V a_2 = v_q_2430; V r_ = (g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_q_2432 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  return ({ V a_0 = v_k_240; V a_1 = v_f_241; V a_2 = v_q_2432; V r_ = (g_heff_2ecompile_2esimplify_2efollowersIn_24s1247983612x386469194(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
}
Clo g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209(V v_x_240, V v_x3_241, V v_b_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_ERecord: {
    V v_fs_244 = heff_field(v_x3_241, 0);
    V v_ts_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24ERecord = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246 = (g_list_2emap_24s366344330x1145113647(heff_dup(v_fs_244)));
    V v_x2_247 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_t_246, v_z_243));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_MkPair: {
        V v_y_2411 = heff_dup(heff_field(v_x_248, 1));
        v_t_2412 = v_y_2411;
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      V v_t_2413 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_244, v_t_2412));
      V v_e_2414 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, heff_tag_at_n(v_ru_24x3_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2413, v_ts_245}), v_b_242});
      V v_m_2415 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2414));
      V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_249}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_t_2421;
        switch (heff_tag_of(v_x_248)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x_248, 0);
          heff_take_n(v_x_248, 1ULL, 2);
          v_t_2421 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        V v_x_2422 = ({ V a_0 = v_t_2421; V a_1 = v_x_2417; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2421); r_; });
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  default: {
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_z_243}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_x3_241, v_x_2425}), v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921(V v_x_240, V v_a_241, V v_b_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EApp: {
    V v_f_244 = heff_field(v_a_241, 0);
    V v_argv_245 = heff_field(v_a_241, 1);
    V v_ru_24a_241_24EApp = heff_take_reuse_n(v_a_241, 3ULL, 2);
    V v_x2_246 = heff_tr(g_heff_2ecompile_2esimplify_2esplitArgs(v_argv_245, v_z_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      V v_args_249 = heff_take_field(v_x_247, 1);
      V v_binds_2410 = heff_get_n(v_x_247, 0, 2);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_t_2414 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2413));
      V v_t_2415 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2412, v_t_2414}), 0, 2);
      V v_x2_2416 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(v_x_240, heff_tag_at_n(v_ru_24a_241_24EApp, TAG_EApp, 2, (V[]){v_f_244, v_args_249}), v_b_242, v_t_2415, v_s_248));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = ({ V a_0 = v_binds_2410; V a_1 = v_x_2417; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_binds_2410); r_; });
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: {
    V v_m_2420 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_z_243}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_s_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_2422}), v_s_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_x_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 2, 5);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 4, 5);
  HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_h_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_k_248 = heff_take_field(v_s_242, 8);
    V v_t_2410;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_t_2410 = NTAG(TAG_Nil);
    }
    V v_t_2411 = ({ V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_k_248, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2412 = ({ V rv_8 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_s_242, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_t_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      heff_drop(v_x_2416);
      V v_s_2417 = v_field_2415;
      V v_m_2418 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_241));
      V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_s_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2420, v_s_2421));
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_x_2425 = v_field_2423;
          V v_s_2426 = v_field_2424;
          V v_k_2427 = heff_dup(heff_rfield(v_s_2426, 8));
          V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_s_2426, 8)), 2, 5);
          V v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2427, 4), v_h_240, v_t_2428));
          V v_k_2430 = ({ V rv_2 = v_x_243; V rv_4 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_k_2427, 11ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 207u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_f_2431 = ({ V rv_8 = v_k_2430; V rr_ = heff_rec_reuse_nf(v_s_2426, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
          return ((HeffT2){{v_x_2425, v_f_2431}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2419)}});
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599(V v_lit_240, V v_lit_241, V v_h_242, V v_calls_243, V v_d_244) {
top: ;
  V v_t_245 = (g_list_2eany_24s477650497x932674259(heff_dup(v_d_244), v_calls_243));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_244, 2))));
    V v_xs_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
    V v_t_248 = ({ V a_0 = v_h_242; V a_1 = v_xs_247; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_m_249 = (g_heff_2ecompile_2esimplify_2etieGo_24s955684140x2145708348(v_lit_240, v_lit_241, v_h_242, heff_dup(heff_rfield(v_d_244, 2))));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam0, 1, 2, (V[]){v_m_249, v_d_244});
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_h_242);
      heff_drop(v_t_248);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam2, 1, 1, (V[]){v_d_244});
    }
  } else {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_h_242);
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam3, 1, 1, (V[]){v_d_244});
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam1(V self, V *args) {
  V v_acc_2424 = args[0];
  V v_h_2425 = args[1];
  V v_s_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_get_n(heff_get_n(v_s_2416, 7, 10), 2, 7);
  HeffT2 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_h_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2426); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_x_2430 = v_field_2429;
      heff_drop(v_x_2430);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2425, v_acc_2424});
    } else {
      heff_drop(v_h_2425);
      heff_drop(v_field_2429);
      return v_acc_2424;
    }
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_k_2414 = heff_dup(heff_rfield(v_d_244, 0));
    V v_b_2415 = heff_dup(v_x_2412);
    V v_s_2416 = v_s_2413;
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_2416, 8)), 4, 5);
    HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_t_2435;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_t_2421 = v_field_2420;
        V v_t_2422 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2415));
        V v_hs_2423 = (g_heff_2ecompile_2eir_2enubI(v_t_2422));
        V v_t_2431 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam1, 2, 1, (V[]){heff_dup(v_s_2416)}); V a_1 = v_t_2421; V a_2 = v_hs_2423; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_2423); r_; });
        V v_k_2432 = heff_take_field(v_s_2416, 8);
        V v_t_2433 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2432, 4), v_k_2414, v_t_2431));
        V v_k_2434 = ({ V rv_4 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_k_2432, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        v_t_2435 = ({ V rv_8 = v_k_2434; V rr_ = heff_rec_reuse_nf(v_s_2416, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
      } else {
        heff_drop(v_k_2414);
        heff_drop(v_b_2415);
        heff_drop(v_field_2420);
        v_t_2435 = v_s_2416;
      }
    }
    V v_x2_2436 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2435});
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_s_2438 = heff_field(v_x2_2436, 1);
      V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 2ULL, 2);
      V v_t_2439 = ({ V rv_2 = v_x_2412; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){v_t_2439, v_s_2438});
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam2(V self, V *args) {
  V v_s_2440 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_244, v_s_2440});
}
V g_heff_2ecompile_2esimplify_2etieOne_24s580614110x383944599_lam3(V self, V *args) {
  V v_s_2441 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_244, v_s_2441});
}