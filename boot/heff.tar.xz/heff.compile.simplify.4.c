// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Inlined 13187
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecapturing(V);
V g_heff_2ecompile_2esimplify_2ecapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecapturing_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyCall_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral(V, V);
V g_heff_2ecompile_2esimplify_2eglobalLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eglobalLiteral_clo;
V g_heff_2ecompile_2esimplify_2ehandedOn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo;
V g_heff_2ecompile_2esimplify_2ehandedW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedW_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkGo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2enthE_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialMore(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epartialMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialMore_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eremember_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especKnown(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKnown_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakeL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2etakeL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_24dps_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etoldTo(V, V, V);
V g_heff_2ecompile_2esimplify_2etoldTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoldTo_clo;
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2esimplify_2eworthIt(V, V, V);
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eworthIt_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s155774913x881635560(V, V, V);
V g_list_2eany_24s155774913x881635560_entry(V self, V *a);
extern Clo g_list_2eany_24s155774913x881635560_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s378803910x892125795(V);
V g_list_2eany_24s378803910x892125795_entry(V self, V *a);
extern Clo g_list_2eany_24s378803910x892125795_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1794308634x1384130934(V, V, V, V, V);
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1794308634x1384130934_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s86307863x1047527532(V, V);
V g_list_2efoldl_24s86307863x1047527532_entry(V self, V *a);
extern Clo g_list_2efoldl_24s86307863x1047527532_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1049096277x601353451(V);
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2etakeL_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edropL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edropL(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_safe_240, v_g_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_as_2413 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_e1_2412, 0);
      HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_total_241, v_g_2415));
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_ar_2420 = v_field_2418;
          V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2413));
          if (heff_intLe_c(v_t_2421, v_ar_2420)) {
            V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2413)));
            return ({ V a_0 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2424); r_; });
          } else {
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_field_2418);
          return NTAG(TAG_False);
        }
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2460 = heff_field(v_e_242, 0);
    V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2460)));
    return ({ V a_0 = v_t_2465; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2465); r_; });
  }
  case TAG_EProj: {
    V v_e2_2466 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2466;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2471 = heff_field(v_e_242, 1);
    V v_t_2474 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2471)));
    return ({ V a_0 = v_t_2474; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2474); r_; });
  }
  case TAG_EMatch: {
    V v_sc_2475 = heff_field(v_e_242, 0);
    V v_arms_2476 = heff_field(v_e_242, 1);
    V v_t_2477 = (g_heff_2ecompile_2esimplify_2epureIn(v_safe_240, v_total_241, v_sc_2475));
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_t_2477);
      switch (heff_tag_of(v_arms_2476)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_t_2485 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_arms_2476)));
        return ({ V a_0 = v_t_2485; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2485); r_; });
      }
      default: return heff_nomatch(v_arms_2476);
      }
    } else {
      heff_drop(v_t_2477);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2487 = heff_field(v_e_242, 0);
    V v_as_2488 = heff_field(v_e_242, 1);
    V v_x1_2489 = ({ V a_0 = v_p_2487; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2489) == NTAG(TAG_True))) {
      heff_drop(v_x1_2489);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2489);
      V v_t_2491 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2488)));
      return ({ V a_0 = v_t_2491; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2491); r_; });
    }
  }
  case TAG_ECall: {
    V v_g_2492 = heff_field(v_e_242, 0);
    V v_as_2493 = heff_field(v_e_242, 1);
    HeffT2 v_t_2494 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_total_241, v_g_2492));
    {
      V v_field_2496 = v_t_2494.f[1];
      int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
      if ((v_tag_2495 == ((int64_t)0ULL))) {
        V v_ar_2498 = v_field_2496;
        V v_t_2499 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2493));
        if (heff_intLe_c(v_t_2499, v_ar_2498)) {
          V v_t_24102 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam5, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2493)));
          return ({ V a_0 = v_t_24102; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24102); r_; });
        } else {
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2496);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2423; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2423); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2462 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2462)) {
  case TAG_MkPair: {
    V v_e2_2464 = heff_field(v_p_2462, 1);
    heff_take_n(v_p_2462, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2464; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2464); r_; });
  }
  default: return heff_nomatch(v_p_2462);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2473 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2473; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2473); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_b_2480 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2484;
  switch (heff_tag_of(v_b_2480)) {
  case TAG_MkArm: {
    V v_b_2483 = heff_field(v_b_2480, 2);
    heff_take_n(v_b_2480, 4ULL, 3);
    v_t_2484 = v_b_2483;
    break;
  }
  default: heff_nomatch(v_b_2480);
  }
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_t_2484; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_t_2484); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2490 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2490; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2490); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam5(V self, V *args) {
  V v_a_24101 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_24101; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_24101); r_; });
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_x_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      V v_t_247 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = v_key_241; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop(v_x1_2410);
          V v_t_2411 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_x1_2410);
          V v_t_2412 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_240, 0), heff_dup(v_key_241), NTAG(TAG_MkUnit)));
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_get_n(v_acc_240, 1, 2), v_key_241, v_t_2413));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2412, v_t_2414});
        }
      } else {
        heff_drop(v_t_247);
        V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
        return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    } else {
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = v_key_241; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        if ((heff_dup(v_x1_2419) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2419);
          return v_acc_240;
        } else {
          heff_drop(v_x1_2419);
          V v_t_2420 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_240, 0), v_key_241, NTAG(TAG_MkUnit)));
          return ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_safe__total, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
      } else {
        heff_drop(v_key_241);
        heff_drop(v_t_2416);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      if (heff_intLt_c(v_t_248, v_t_249)) {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){heff_take_field(v_s_240, 3), heff_get_n(v_s_240, 5, 9)}));
        V v_t_2412 = (g_list_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      } else {
        heff_drop_rec(v_s_240, 9);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialOf(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedOn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ehandedOn(V v_kinds_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_ys_247 = heff_field(v_a_242, 0);
    V v_body_248 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    V v_ret_24bool = heff_bool((heff_intLe_c_lent(v_o_244, MK_INT(2LL), 2) && ({ V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_ys_247), heff_dup(v_body_248)}), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(160LL), MK_INT(0LL), heff_dup(v_t_2410))); int c_ = (heff_intLt_c_lent(MK_INT(160LL), v_x_2411, 1) ? 0 : ({ V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2414 = (g_heff_2ecompile_2esimplify_2ehandedW(v_x_241, v_kinds_240, MK_INT(0LL), heff_dup(v_t_2413))); int c_ = heff_intEq_c_lent(v_t_2414, v_o_244, 0); heff_drop(v_t_2414); c_; }); heff_drop(v_t_2413); c_; })); heff_drop(v_x_2411); c_; }); heff_drop(v_t_2410); c_; })));
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    heff_drop(v_ys_247);
    heff_drop(v_body_248);
    return v_ret_24bool;
  }
  case TAG_EApp: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_242, 0ULL, 4);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_242, 0ULL, 3);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_242, 0ULL, 1);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_242, 0ULL, 2);
    heff_drop(v_b_243);
    heff_drop(v_o_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedOn(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244, V v_s_245) {
top: ;
  if (heff_intEq_c_lent(v_o_244, MK_INT(0LL), 2)) {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_b_243, v_s_245});
  } else {
    V v_t_2441;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EApp: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_ELet: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_ERecord: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EProj: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_ETag: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EMatch: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EPrim: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_ECall: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EInt: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2441 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    case TAG_EFix: {
      v_t_2441 = heff_intEq_lent(v_o_244, MK_INT(1LL), 2);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_o_244);
      heff_drop(v_t_2441);
      V v_m_2442 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(g_std_2emap_2eempty_get()), v_x_241, v_a_242));
      V v_t_2443 = (g_std_2emap_2esize(v_m_2442));
      V v_t_2445;
      if (heff_intEq_c(v_t_2443, MK_INT(0LL))) {
        heff_drop(v_m_2442);
        v_t_2445 = v_b_243;
      } else {
        v_t_2445 = ({ V a_0 = v_m_2442; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2442); r_; });
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_t_2445, v_s_245});
    } else {
      heff_drop(v_t_2441);
      V v_t_2446 = (g_heff_2ecompile_2eir_2eisValue(v_a_242));
      V v_t_2460;
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_x_2448 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2447));
        if (heff_intLt_c(MK_INT(12LL), v_x_2448)) {
          if (heff_intLe_c_lent(v_o_244, MK_INT(4LL), 2)) {
            V v_t_2451 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_242)));
            if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
              heff_drop(v_o_244);
              heff_drop(v_t_2451);
              v_t_2460 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2451);
              if (heff_intLe_c_lent(v_o_244, MK_INT(8LL), 2)) {
                V v_t_2453 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_a_242)));
                if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
                  heff_drop(v_o_244);
                  heff_drop(v_t_2453);
                  v_t_2460 = NTAG(TAG_True);
                } else {
                  heff_drop(v_t_2453);
                  V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
                  v_t_2460 = ({ V a_0 = v_t_2454; V a_1 = v_x_241; V a_2 = heff_dup(v_a_242); V a_3 = heff_dup(v_b_243); V a_4 = v_o_244; V r_ = (g_heff_2ecompile_2esimplify_2ehandedOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2454); r_; });
                }
              } else {
                V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
                v_t_2460 = ({ V a_0 = v_t_2455; V a_1 = v_x_241; V a_2 = heff_dup(v_a_242); V a_3 = heff_dup(v_b_243); V a_4 = v_o_244; V r_ = (g_heff_2ecompile_2esimplify_2ehandedOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2455); r_; });
              }
            }
          } else {
            if (heff_intLe_c_lent(v_o_244, MK_INT(8LL), 2)) {
              V v_t_2457 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_a_242)));
              if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
                heff_drop(v_o_244);
                heff_drop(v_t_2457);
                v_t_2460 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2457);
                V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
                v_t_2460 = ({ V a_0 = v_t_2458; V a_1 = v_x_241; V a_2 = heff_dup(v_a_242); V a_3 = heff_dup(v_b_243); V a_4 = v_o_244; V r_ = (g_heff_2ecompile_2esimplify_2ehandedOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2458); r_; });
              }
            } else {
              V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
              v_t_2460 = ({ V a_0 = v_t_2459; V a_1 = v_x_241; V a_2 = heff_dup(v_a_242); V a_3 = heff_dup(v_b_243); V a_4 = v_o_244; V r_ = (g_heff_2ecompile_2esimplify_2ehandedOn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2459); r_; });
            }
          }
        } else {
          heff_drop(v_o_244);
          v_t_2460 = NTAG(TAG_True);
        }
      } else {
        heff_drop(v_o_244);
        heff_drop(v_t_2446);
        v_t_2460 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
        heff_drop(v_t_2460);
        V v_m_2461 = ({ V a_0 = v_x_241; V a_1 = v_a_242; V a_2 = v_b_243; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_241); r_; });
        V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_245}));
        switch (heff_tag_of(v_x2_2462)) {
        case TAG_MkPair: {
          V v_x_2463 = heff_field(v_x2_2462, 0);
          V v_s_2464 = heff_field(v_x2_2462, 1);
          heff_take_n(v_x2_2462, 3ULL, 2);
          return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_x_2463, v_s_2464});
        }
        default: return heff_nomatch(v_x2_2462);
        }
      } else {
        heff_drop(v_t_2460);
        V v_m_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2466 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_s_245}));
        switch (heff_tag_of(v_x2_2466)) {
        case TAG_MkPair: {
          V v_x_2467 = heff_field(v_x2_2466, 0);
          V v_s_2468 = heff_field(v_x2_2466, 1);
          V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2467}), v_s_2468});
        }
        default: return heff_nomatch(v_x2_2466);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_24cpr_str0), heff_intShow(heff_dup(v_n_242)));
  V v_f_244 = heff_strAppend(v_base_240, v_t_243);
  V v_f_245 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return ((HeffT2){{v_f_244, v_f_245}});
}
Clo g_heff_2ecompile_2esimplify_2efewerThan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efewerThan_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efewerThan(V v_as_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_240));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      return heff_intLt(v_t_247, v_t_248);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efewerThan(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2earmsPushable_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2earmsPushable(V v_budget_240, V v_a_241, V v_arms_242) {
top: ;
  V v_x1_243 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_241)));
  V v_t_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_ts_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    V v_x_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_244); r_; });
    v_t_247 = heff_intLt(MK_INT(0LL), v_x_246);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_241))); int c_ = ({ V v_x1_249 = (g_list_2eany_24s155774913x881635560(heff_dup(v_budget_240), heff_dup(v_t_248), v_arms_242)); int c_ = !(heff_dup(v_x1_249) == NTAG(TAG_True)); heff_drop(v_x1_249); c_; }); heff_drop(v_t_248); c_; })));
  heff_drop(v_budget_240);
  heff_drop(v_a_241);
  heff_drop(v_t_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2earmsPushable(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str0, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str1, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str2, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str3, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str5, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str6, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str8, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str9, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str10, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str11, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str12, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str13, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str14, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str15, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str16, 1, "t");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efieldBound_str17, 1, "t");
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2efieldBound_lam36(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldBound(V v_tag_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_tag_240);
    V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam0, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam1, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_tag_240);
    V v_t_2415 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam2, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2415);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam3, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ELam: {
    heff_drop(v_tag_240);
    V v_t_2428 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam4, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2428);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam5, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EApp: {
    heff_drop(v_tag_240);
    V v_t_2441 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam6, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2441);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam7, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ELet: {
    V v_y_2452 = heff_field(v_a_241, 0);
    V v_e_2453 = heff_field(v_a_241, 1);
    V v_c_2454 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    V v_m_2455 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(v_tag_240, v_c_2454));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam8, 1, 3, (V[]){v_m_2455, v_y_2452, v_e_2453});
  }
  case TAG_ERecord: {
    heff_drop(v_tag_240);
    V v_t_2469 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam9, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2469);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam10, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EProj: {
    heff_drop(v_tag_240);
    V v_t_2484 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam11, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam12, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ETag: {
    V v_a1_2495 = heff_field(v_a_241, 0);
    V v_as_2496 = heff_field(v_a_241, 1);
    V v_ts_2497 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    return heff_tail(v_tag_240, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_a1_2495, v_as_2496, v_ts_2497})});
  }
  case TAG_EMatch: {
    heff_drop(v_tag_240);
    V v_t_24100 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
      heff_drop(v_t_24100);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam13, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24100);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam14, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_tag_240);
    V v_t_24112 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
      heff_drop(v_t_24112);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam15, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24112);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam16, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EPrimCall: {
    heff_drop(v_tag_240);
    V v_t_24125 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
      heff_drop(v_t_24125);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam17, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24125);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam18, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_ECall: {
    heff_drop(v_tag_240);
    V v_t_24138 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24138) == NTAG(TAG_True))) {
      heff_drop(v_t_24138);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam19, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24138);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam20, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EInt: {
    heff_drop(v_tag_240);
    V v_t_24150 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24150) == NTAG(TAG_True))) {
      heff_drop(v_t_24150);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam21, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24150);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam22, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFloat: {
    heff_drop(v_tag_240);
    V v_t_24162 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
      heff_drop(v_t_24162);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam23, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24162);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam24, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EStr: {
    heff_drop(v_tag_240);
    V v_t_24174 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24174) == NTAG(TAG_True))) {
      heff_drop(v_t_24174);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam25, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24174);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam26, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EBytes: {
    heff_drop(v_tag_240);
    V v_t_24186 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24186) == NTAG(TAG_True))) {
      heff_drop(v_t_24186);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam27, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24186);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam28, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFixed: {
    heff_drop(v_tag_240);
    V v_t_24199 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24199) == NTAG(TAG_True))) {
      heff_drop(v_t_24199);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam29, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24199);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam30, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFloat32: {
    heff_drop(v_tag_240);
    V v_t_24211 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
      heff_drop(v_t_24211);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam31, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24211);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam32, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_tag_240);
    V v_t_24222 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24222) == NTAG(TAG_True))) {
      heff_drop(v_t_24222);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam33, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24222);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam34, 1, 1, (V[]){v_a_241});
    }
  }
  case TAG_EFix: {
    heff_drop(v_tag_240);
    V v_t_24235 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
    if ((heff_dup(v_t_24235) == NTAG(TAG_True))) {
      heff_drop(v_t_24235);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam35, 1, 1, (V[]){v_a_241});
    } else {
      heff_drop(v_t_24235);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldBound_lam36, 1, 1, (V[]){v_a_241});
    }
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_s_244});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str0), v_s_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2410})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_s_2411});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_s_2416});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str1), v_s_2418));
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_x_2422 = v_field_2420;
    V v_s_2423 = v_field_2421;
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2422), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2422})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_s_2423});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_s_2429});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str2), v_s_2431));
  {
    V v_field_2433 = v_t_2432.f[0];
    V v_field_2434 = v_t_2432.f[1];
    V v_x_2435 = v_field_2433;
    V v_s_2436 = v_field_2434;
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2435), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2435})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_s_2436});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam6(V self, V *args) {
  V v_s_2442 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2442});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str3), v_s_2444));
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_x_2448 = v_field_2446;
    V v_s_2449 = v_field_2447;
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2448), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2448})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_s_2449});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam8(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_y_2452 = heff_env(self)[1];
  V v_e_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_MkPair: {
      V v_x_2460 = heff_dup(heff_field(v_x_2458, 0));
      v_t_2462 = v_x_2460;
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_y_2452, v_e_2453}), v_t_2462});
    V v_t_2466;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_MkPair: {
      V v_y_2465 = heff_field(v_x_2458, 1);
      heff_take_n(v_x_2458, 2ULL, 2);
      v_t_2466 = v_y_2465;
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_t_2466}), v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam9(V self, V *args) {
  V v_s_2470 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2471, v_s_2470});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam10(V self, V *args) {
  V v_s_2472 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2473 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str4), v_s_2472));
  {
    V v_field_2474 = v_t_2473.f[0];
    V v_field_2475 = v_t_2473.f[1];
    V v_x_2476 = v_field_2474;
    V v_s_2477 = v_field_2475;
    V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2476), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2479 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2476})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2479, v_s_2477});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam11(V self, V *args) {
  V v_s_2485 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_s_2485});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam12(V self, V *args) {
  V v_s_2487 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2488 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str5), v_s_2487));
  {
    V v_field_2489 = v_t_2488.f[0];
    V v_field_2490 = v_t_2488.f[1];
    V v_x_2491 = v_field_2489;
    V v_s_2492 = v_field_2490;
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2491), v_a_241}), NTAG(TAG_Nil)});
    V v_t_2494 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2493, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2491})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_s_2492});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam13(V self, V *args) {
  V v_s_24101 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24102, v_s_24101});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam14(V self, V *args) {
  V v_s_24103 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24104 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str6), v_s_24103));
  {
    V v_field_24105 = v_t_24104.f[0];
    V v_field_24106 = v_t_24104.f[1];
    V v_x_24107 = v_field_24105;
    V v_s_24108 = v_field_24106;
    V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24107), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24109, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24107})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24110, v_s_24108});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam15(V self, V *args) {
  V v_s_24113 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24114, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam16(V self, V *args) {
  V v_s_24115 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24116 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str7), v_s_24115));
  {
    V v_field_24117 = v_t_24116.f[0];
    V v_field_24118 = v_t_24116.f[1];
    V v_x_24119 = v_field_24117;
    V v_s_24120 = v_field_24118;
    V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24119), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24122 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24121, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24119})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24122, v_s_24120});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam17(V self, V *args) {
  V v_s_24126 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24127 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24127, v_s_24126});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam18(V self, V *args) {
  V v_s_24128 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24129 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str8), v_s_24128));
  {
    V v_field_24130 = v_t_24129.f[0];
    V v_field_24131 = v_t_24129.f[1];
    V v_x_24132 = v_field_24130;
    V v_s_24133 = v_field_24131;
    V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24132), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24135 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24134, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24132})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24135, v_s_24133});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam19(V self, V *args) {
  V v_s_24139 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24140 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24140, v_s_24139});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam20(V self, V *args) {
  V v_s_24141 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24142 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str9), v_s_24141));
  {
    V v_field_24143 = v_t_24142.f[0];
    V v_field_24144 = v_t_24142.f[1];
    V v_x_24145 = v_field_24143;
    V v_s_24146 = v_field_24144;
    V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24145), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24148 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24147, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24145})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24148, v_s_24146});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam21(V self, V *args) {
  V v_s_24151 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24152 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24152, v_s_24151});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam22(V self, V *args) {
  V v_s_24153 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24154 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str10), v_s_24153));
  {
    V v_field_24155 = v_t_24154.f[0];
    V v_field_24156 = v_t_24154.f[1];
    V v_x_24157 = v_field_24155;
    V v_s_24158 = v_field_24156;
    V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24157), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24160 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24159, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24157})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24160, v_s_24158});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam23(V self, V *args) {
  V v_s_24163 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24164 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24164, v_s_24163});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam24(V self, V *args) {
  V v_s_24165 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24166 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str11), v_s_24165));
  {
    V v_field_24167 = v_t_24166.f[0];
    V v_field_24168 = v_t_24166.f[1];
    V v_x_24169 = v_field_24167;
    V v_s_24170 = v_field_24168;
    V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24169), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24172 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24171, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24169})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24172, v_s_24170});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam25(V self, V *args) {
  V v_s_24175 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24176 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24176, v_s_24175});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam26(V self, V *args) {
  V v_s_24177 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24178 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str12), v_s_24177));
  {
    V v_field_24179 = v_t_24178.f[0];
    V v_field_24180 = v_t_24178.f[1];
    V v_x_24181 = v_field_24179;
    V v_s_24182 = v_field_24180;
    V v_t_24183 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24181), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24184 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24183, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24181})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24184, v_s_24182});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam27(V self, V *args) {
  V v_s_24187 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24188 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24188, v_s_24187});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam28(V self, V *args) {
  V v_s_24189 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24190 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str13), v_s_24189));
  {
    V v_field_24191 = v_t_24190.f[0];
    V v_field_24192 = v_t_24190.f[1];
    V v_x_24193 = v_field_24191;
    V v_s_24194 = v_field_24192;
    V v_t_24195 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24193), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24196 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24195, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24193})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24196, v_s_24194});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam29(V self, V *args) {
  V v_s_24200 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24201 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24201, v_s_24200});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam30(V self, V *args) {
  V v_s_24202 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24203 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str14), v_s_24202));
  {
    V v_field_24204 = v_t_24203.f[0];
    V v_field_24205 = v_t_24203.f[1];
    V v_x_24206 = v_field_24204;
    V v_s_24207 = v_field_24205;
    V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24206), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24209 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24208, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24206})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24209, v_s_24207});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam31(V self, V *args) {
  V v_s_24212 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24213, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam32(V self, V *args) {
  V v_s_24214 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24215 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str15), v_s_24214));
  {
    V v_field_24216 = v_t_24215.f[0];
    V v_field_24217 = v_t_24215.f[1];
    V v_x_24218 = v_field_24216;
    V v_s_24219 = v_field_24217;
    V v_t_24220 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24218), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24221 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24220, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24218})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24221, v_s_24219});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam33(V self, V *args) {
  V v_s_24223 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24224 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24224, v_s_24223});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam34(V self, V *args) {
  V v_s_24225 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24226 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str16), v_s_24225));
  {
    V v_field_24227 = v_t_24226.f[0];
    V v_field_24228 = v_t_24226.f[1];
    V v_x_24229 = v_field_24227;
    V v_s_24230 = v_field_24228;
    V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24229), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24232 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24231, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24229})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24232, v_s_24230});
  }
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam35(V self, V *args) {
  V v_s_24236 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24237 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_a_241});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24237, v_s_24236});
}
V g_heff_2ecompile_2esimplify_2efieldBound_lam36(V self, V *args) {
  V v_s_24238 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24239 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2efieldBound_str17), v_s_24238));
  {
    V v_field_24240 = v_t_24239.f[0];
    V v_field_24241 = v_t_24239.f[1];
    V v_x_24242 = v_field_24240;
    V v_s_24243 = v_field_24241;
    V v_t_24244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_24242), v_a_241}), NTAG(TAG_Nil)});
    V v_t_24245 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24244, heff_tag_n(TAG_EVar, 1, (V[]){v_x_24242})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24245, v_s_24243});
  }
}
Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2erecordSplit(V v_r_240, V v_x_241, V v_x3_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2425}), v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  case TAG_ELet: {
    V v_m_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      V v_s_2433 = heff_field(v_x2_2431, 1);
      V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2432}), v_s_2433});
    }
    default: return heff_nomatch(v_x2_2431);
    }
  }
  case TAG_ERecord: {
    V v_fs_2434 = heff_field(v_x3_242, 0);
    V v_ts_2435 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ERecord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2436 = (g_list_2emap_24s366344330x1145113647(heff_dup(v_fs_2434)));
    V v_x2_2437 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_t_2436, v_z_244));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
      V v_t_2442;
      switch (heff_tag_of(v_x_2438)) {
      case TAG_MkPair: {
        V v_y_2441 = heff_dup(heff_field(v_x_2438, 1));
        v_t_2442 = v_y_2441;
        break;
      }
      default: heff_nomatch(v_x_2438);
      }
      V v_t_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2434, v_t_2442));
      V v_t_2444 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, heff_tag_at_n(v_ru_24x3_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2443, v_ts_2435}), v_b_243});
      V v_m_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2444}));
      V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_s_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        V v_t_2451;
        switch (heff_tag_of(v_x_2438)) {
        case TAG_MkPair: {
          V v_x_2449 = heff_field(v_x_2438, 0);
          heff_take_n(v_x_2438, 1ULL, 2);
          v_t_2451 = v_x_2449;
          break;
        }
        default: heff_nomatch(v_x_2438);
        }
        V v_x_2452 = ({ V a_0 = v_t_2451; V a_1 = v_x_2447; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2451); r_; });
        return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_x_2452, v_s_2448});
      }
      default: return heff_nomatch(v_x2_2446);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  case TAG_EProj: {
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2458 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_s_2460 = heff_field(v_x2_2458, 1);
      V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2459}), v_s_2460});
    }
    default: return heff_nomatch(v_x2_2458);
    }
  }
  case TAG_ETag: {
    V v_m_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_s_2467 = heff_field(v_x2_2465, 1);
      V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2466}), v_s_2467});
    }
    default: return heff_nomatch(v_x2_2465);
    }
  }
  case TAG_EMatch: {
    V v_m_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2472}), v_s_2473});
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  case TAG_EPrim: {
    V v_m_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_s_2478 = heff_field(v_x2_2476, 1);
      V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2477}), v_s_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2483}), v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  case TAG_ECall: {
    V v_m_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  case TAG_EInt: {
    V v_m_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_s_2495 = heff_field(v_x2_2493, 1);
      V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2494}), v_s_2495});
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  case TAG_EFloat: {
    V v_m_2497 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2498 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_MkPair: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_s_24100 = heff_field(v_x2_2498, 1);
      V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_2499}), v_s_24100});
    }
    default: return heff_nomatch(v_x2_2498);
    }
  }
  case TAG_EStr: {
    V v_m_24102 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24103 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24103)) {
    case TAG_MkPair: {
      V v_x_24104 = heff_field(v_x2_24103, 0);
      V v_s_24105 = heff_field(v_x2_24103, 1);
      V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24104}), v_s_24105});
    }
    default: return heff_nomatch(v_x2_24103);
    }
  }
  case TAG_EBytes: {
    V v_m_24107 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_s_24110 = heff_field(v_x2_24108, 1);
      V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24109}), v_s_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  case TAG_EFixed: {
    V v_m_24113 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24115}), v_s_24116});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  case TAG_EFloat32: {
    V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_MkPair: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_s_24121 = heff_field(v_x2_24119, 1);
      V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24120}), v_s_24121});
    }
    default: return heff_nomatch(v_x2_24119);
    }
  }
  case TAG_EAbandon: {
    V v_m_24122 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24123 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24123)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_x2_24123, 0);
      V v_s_24125 = heff_field(v_x2_24123, 1);
      V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24124}), v_s_24125});
    }
    default: return heff_nomatch(v_x2_24123);
    }
  }
  case TAG_EFix: {
    V v_m_24128 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24129 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_s_24131 = heff_field(v_x2_24129, 1);
      V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_x3_242, v_x_24130}), v_s_24131});
    }
    default: return heff_nomatch(v_x2_24129);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordSplit(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eeta_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          heff_drop(v_t_2413);
          return v_f_2410;
        } else {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
      } else {
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 4);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EBytes: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eeta(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_g_244});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_241, 0);
    V v_b_249 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_249}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_e1_2418 = heff_field(v_e_241, 0);
    V v_as_2419 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2418)) {
    case TAG_EVar: {
      V v_m_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2421, v_r_240, v_as_2419});
    }
    case TAG_EGlobal: {
      V v_g_2431 = heff_field(v_e1_2418, 0);
      heff_take_n(v_e1_2418, 1ULL, 1);
      V v_m_2433 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam5, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam6, 1, 3, (V[]){v_m_2433, v_r_240, v_g_2431});
    }
    case TAG_ELam: {
      V v_m_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2440, v_r_240, v_as_2419});
    }
    case TAG_EApp: {
      V v_e11_2450 = heff_dup(heff_field(v_e1_2418, 0));
      V v_bs_2451 = heff_dup(heff_field(v_e1_2418, 1));
      switch (heff_tag_of(v_e11_2450)) {
      case TAG_EVar: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2453, v_r_240, v_as_2419});
      }
      case TAG_EGlobal: {
        V v_g_2463 = heff_field(v_e11_2450, 0);
        heff_take_n(v_e11_2450, 1ULL, 1);
        heff_drop_tag(v_e1_2418, 2);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2451, v_g_2463, v_as_2419, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2481, v_r_240, v_as_2419});
      }
      case TAG_EApp: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2493, v_r_240, v_as_2419});
      }
      case TAG_ELet: {
        heff_take_n(v_e11_2450, 0ULL, 3);
        heff_drop(v_bs_2451);
        V v_m_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24106, v_r_240, v_as_2419});
      }
      case TAG_ERecord: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24118, v_r_240, v_as_2419});
      }
      case TAG_EProj: {
        heff_take_n(v_e11_2450, 0ULL, 4);
        heff_drop(v_bs_2451);
        V v_m_24132 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24132, v_r_240, v_as_2419});
      }
      case TAG_ETag: {
        heff_take_n(v_e11_2450, 0ULL, 3);
        heff_drop(v_bs_2451);
        V v_m_24145 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24145, v_r_240, v_as_2419});
      }
      case TAG_EMatch: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24157 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24157, v_r_240, v_as_2419});
      }
      case TAG_EPrim: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24168 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24168, v_r_240, v_as_2419});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24180 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24180, v_r_240, v_as_2419});
      }
      case TAG_ECall: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24192 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24192, v_r_240, v_as_2419});
      }
      case TAG_EInt: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24203 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24203, v_r_240, v_as_2419});
      }
      case TAG_EFloat: {
        heff_take_na(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24214 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24214, v_r_240, v_as_2419});
      }
      case TAG_EStr: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24225 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24225, v_r_240, v_as_2419});
      }
      case TAG_EBytes: {
        heff_take_n(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24236 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24236, v_r_240, v_as_2419});
      }
      case TAG_EFixed: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24248, v_r_240, v_as_2419});
      }
      case TAG_EFloat32: {
        heff_take_na(v_e11_2450, 0ULL, 1);
        heff_drop(v_bs_2451);
        V v_m_24259 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24259, v_r_240, v_as_2419});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2451);
        V v_m_24269 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24269, v_r_240, v_as_2419});
      }
      case TAG_EFix: {
        heff_take_n(v_e11_2450, 0ULL, 2);
        heff_drop(v_bs_2451);
        V v_m_24281 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24281, v_r_240, v_as_2419});
      }
      default: return heff_nomatch(v_e11_2450);
      }
    }
    case TAG_ELet: {
      V v_m_24294 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24294, v_r_240, v_as_2419});
    }
    case TAG_ERecord: {
      V v_m_24306 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24306, v_r_240, v_as_2419});
    }
    case TAG_EProj: {
      V v_m_24320 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24320, v_r_240, v_as_2419});
    }
    case TAG_ETag: {
      V v_m_24333 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24333, v_r_240, v_as_2419});
    }
    case TAG_EMatch: {
      V v_m_24345 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24345, v_r_240, v_as_2419});
    }
    case TAG_EPrim: {
      V v_m_24356 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24356, v_r_240, v_as_2419});
    }
    case TAG_EPrimCall: {
      V v_m_24368 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24368, v_r_240, v_as_2419});
    }
    case TAG_ECall: {
      V v_m_24380 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24380, v_r_240, v_as_2419});
    }
    case TAG_EInt: {
      V v_m_24391 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24391, v_r_240, v_as_2419});
    }
    case TAG_EFloat: {
      V v_m_24402 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24402, v_r_240, v_as_2419});
    }
    case TAG_EStr: {
      V v_m_24413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24413, v_r_240, v_as_2419});
    }
    case TAG_EBytes: {
      V v_m_24424 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24424, v_r_240, v_as_2419});
    }
    case TAG_EFixed: {
      V v_m_24436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24436, v_r_240, v_as_2419});
    }
    case TAG_EFloat32: {
      V v_m_24447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24447, v_r_240, v_as_2419});
    }
    case TAG_EAbandon: {
      V v_m_24457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam77, 1, 3, (V[]){v_m_24457, v_r_240, v_as_2419});
    }
    case TAG_EFix: {
      V v_m_24469 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2418}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam79, 1, 3, (V[]){v_m_24469, v_r_240, v_as_2419});
    }
    default: return heff_nomatch(v_e1_2418);
    }
  }
  case TAG_ELet: {
    V v_x_24479 = heff_field(v_e_241, 0);
    V v_a_24480 = heff_field(v_e_241, 1);
    V v_b_24481 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24482 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24480}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam81, 1, 4, (V[]){v_m_24482, v_r_240, v_x_24479, v_b_24481});
  }
  case TAG_ERecord: {
    V v_fs_24488 = heff_field(v_e_241, 0);
    V v_ts_24489 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24498 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_r_240}), v_fs_24488));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam84, 1, 2, (V[]){v_m_24498, v_ts_24489});
  }
  case TAG_EProj: {
    V v_e2_24503 = heff_field(v_e_241, 0);
    V v_l_24504 = heff_field(v_e_241, 1);
    V v_sh_24505 = heff_field(v_e_241, 2);
    V v_t_24506 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_24507 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e2_24503}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam85, 1, 5, (V[]){v_m_24507, v_r_240, v_l_24504, v_sh_24505, v_t_24506});
  }
  case TAG_ETag: {
    V v_t_24512 = heff_field(v_e_241, 0);
    V v_as_24513 = heff_field(v_e_241, 1);
    V v_ts_24514 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24516 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam86, 1, 1, (V[]){v_r_240}), v_as_24513));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam87, 1, 3, (V[]){v_m_24516, v_t_24512, v_ts_24514});
  }
  case TAG_EMatch: {
    V v_s_24521 = heff_field(v_e_241, 0);
    V v_arms_24522 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24523 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24521}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam88, 1, 3, (V[]){v_m_24523, v_r_240, v_arms_24522});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam91, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24543 = heff_field(v_e_241, 0);
    V v_as_24544 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24546 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam92, 1, 1, (V[]){v_r_240}), v_as_24544));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam93, 1, 2, (V[]){v_m_24546, v_p_24543});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam95, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam96, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam97, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam98, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam99, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam100, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam101, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam102, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_g_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_s_245, 2), v_g_244));
  V v_x_247 = (g_heff_2ecompile_2esimplify_2eglobalLiteral(v_g_244, v_t_246));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_s_2414, 7)), 1, 7);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2elam(v_xs_248, v_x_2413));
    V v_x_2417 = ({ V a_0 = v_t_2415; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2426 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    V v_m_2427 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2425}));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_s_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2424;
      heff_room[1] = v_x_2429;
      heff_room[2] = v_s_2430;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_a_2432 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_g_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_s_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2431});
    heff_room[1] = v_x_2436;
    heff_room[2] = v_s_2437;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2445 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    heff_take_n(v_x2_2442, 3ULL, 2);
    V v_m_2446 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_s_2444}));
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_s_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2443;
      heff_room[1] = v_x_2448;
      heff_room[2] = v_s_2449;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2447);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2458 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    heff_take_n(v_x2_2455, 3ULL, 2);
    V v_m_2459 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_2460 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2457}));
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_MkPair: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_s_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2456;
      heff_room[1] = v_x_2461;
      heff_room[2] = v_s_2462;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2460);
    }
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2474 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2464 = args[0];
  V v_bs_2451 = heff_env(self)[0];
  V v_g_2463 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_bs_2451));
  V v_t_2466 = (g_heff_2ecompile_2esimplify_2etakesMore(heff_dup(v_s_2464), v_g_2463, v_t_2465));
  if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
    heff_drop(v_t_2466);
    V v_t_2467 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2451, v_as_2419));
    V v_t_2468 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2463}), v_t_2467});
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_t_2468;
    heff_room[1] = v_s_2464;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2466);
    V v_t_2469 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2463}), v_bs_2451});
    V v_m_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2469}));
    V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_s_2464}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      V v_m_2475 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
      V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2473}));
      switch (heff_tag_of(v_x2_2476)) {
      case TAG_MkPair: {
        V v_x_2477 = heff_field(v_x2_2476, 0);
        V v_s_2478 = heff_field(v_x2_2476, 1);
        heff_take_n(v_x2_2476, 3ULL, 2);
        V f_ = heff_get_n(v_r_240, 1, 4);
        heff_room[0] = v_x_2472;
        heff_room[1] = v_x_2477;
        heff_room[2] = v_s_2478;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_x2_2476);
      }
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_s_2485 = heff_field(v_x2_2483, 1);
    heff_take_n(v_x2_2483, 3ULL, 2);
    V v_m_2487 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2485}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      heff_take_n(v_x2_2488, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2484;
      heff_room[1] = v_x_2489;
      heff_room[2] = v_s_2490;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_2498 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_s_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_s_2497 = heff_field(v_x2_2495, 1);
    heff_take_n(v_x2_2495, 3ULL, 2);
    V v_m_2499 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24100 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_s_2497}));
    switch (heff_tag_of(v_x2_24100)) {
    case TAG_MkPair: {
      V v_x_24101 = heff_field(v_x2_24100, 0);
      V v_s_24102 = heff_field(v_x2_24100, 1);
      heff_take_n(v_x2_24100, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2496;
      heff_room[1] = v_x_24101;
      heff_room[2] = v_s_24102;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24100);
    }
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24111 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24111;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    heff_take_n(v_x2_24108, 3ULL, 2);
    V v_m_24112 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24113 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24110}));
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_MkPair: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_s_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24109;
      heff_room[1] = v_x_24114;
      heff_room[2] = v_s_24115;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24113);
    }
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24123 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24120 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    heff_take_n(v_x2_24120, 3ULL, 2);
    V v_m_24124 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_s_24122}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24121;
      heff_room[1] = v_x_24126;
      heff_room[2] = v_s_24127;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24137 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24137;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_s_24133}));
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    V v_s_24136 = heff_field(v_x2_24134, 1);
    heff_take_n(v_x2_24134, 3ULL, 2);
    V v_m_24138 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24136}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24135;
      heff_room[1] = v_x_24140;
      heff_room[2] = v_s_24141;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24150 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24150;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_s_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_s_24149 = heff_field(v_x2_24147, 1);
    heff_take_n(v_x2_24147, 3ULL, 2);
    V v_m_24151 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24152 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_s_24149}));
    switch (heff_tag_of(v_x2_24152)) {
    case TAG_MkPair: {
      V v_x_24153 = heff_field(v_x2_24152, 0);
      V v_s_24154 = heff_field(v_x2_24152, 1);
      heff_take_n(v_x2_24152, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24148;
      heff_room[1] = v_x_24153;
      heff_room[2] = v_s_24154;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24152);
    }
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24162 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24162;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    heff_take_n(v_x2_24159, 3ULL, 2);
    V v_m_24163 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24164 = heff_tr(heff_call(v_m_24163, 1, (V[]){v_s_24161}));
    switch (heff_tag_of(v_x2_24164)) {
    case TAG_MkPair: {
      V v_x_24165 = heff_field(v_x2_24164, 0);
      V v_s_24166 = heff_field(v_x2_24164, 1);
      heff_take_n(v_x2_24164, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24160;
      heff_room[1] = v_x_24165;
      heff_room[2] = v_s_24166;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24164);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24173 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24173;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24169 = args[0];
  V v_m_24168 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24170 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_s_24169}));
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_MkPair: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    V v_s_24172 = heff_field(v_x2_24170, 1);
    heff_take_n(v_x2_24170, 3ULL, 2);
    V v_m_24174 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24175 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_s_24172}));
    switch (heff_tag_of(v_x2_24175)) {
    case TAG_MkPair: {
      V v_x_24176 = heff_field(v_x2_24175, 0);
      V v_s_24177 = heff_field(v_x2_24175, 1);
      heff_take_n(v_x2_24175, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24171;
      heff_room[1] = v_x_24176;
      heff_room[2] = v_s_24177;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24175);
    }
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24185 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24185;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_s_24181}));
  switch (heff_tag_of(v_x2_24182)) {
  case TAG_MkPair: {
    V v_x_24183 = heff_field(v_x2_24182, 0);
    V v_s_24184 = heff_field(v_x2_24182, 1);
    heff_take_n(v_x2_24182, 3ULL, 2);
    V v_m_24186 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24187 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_s_24184}));
    switch (heff_tag_of(v_x2_24187)) {
    case TAG_MkPair: {
      V v_x_24188 = heff_field(v_x2_24187, 0);
      V v_s_24189 = heff_field(v_x2_24187, 1);
      heff_take_n(v_x2_24187, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24183;
      heff_room[1] = v_x_24188;
      heff_room[2] = v_s_24189;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24187);
    }
  }
  default: return heff_nomatch(v_x2_24182);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24197 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24197;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_s_24193}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_MkPair: {
    V v_x_24195 = heff_field(v_x2_24194, 0);
    V v_s_24196 = heff_field(v_x2_24194, 1);
    heff_take_n(v_x2_24194, 3ULL, 2);
    V v_m_24198 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24199 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_s_24196}));
    switch (heff_tag_of(v_x2_24199)) {
    case TAG_MkPair: {
      V v_x_24200 = heff_field(v_x2_24199, 0);
      V v_s_24201 = heff_field(v_x2_24199, 1);
      heff_take_n(v_x2_24199, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24195;
      heff_room[1] = v_x_24200;
      heff_room[2] = v_s_24201;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24199);
    }
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24208 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24208;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_s_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_s_24207 = heff_field(v_x2_24205, 1);
    heff_take_n(v_x2_24205, 3ULL, 2);
    V v_m_24209 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24210 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_s_24207}));
    switch (heff_tag_of(v_x2_24210)) {
    case TAG_MkPair: {
      V v_x_24211 = heff_field(v_x2_24210, 0);
      V v_s_24212 = heff_field(v_x2_24210, 1);
      heff_take_n(v_x2_24210, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24206;
      heff_room[1] = v_x_24211;
      heff_room[2] = v_s_24212;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24210);
    }
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24219 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24219;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24215 = args[0];
  V v_m_24214 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24216 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_s_24215}));
  switch (heff_tag_of(v_x2_24216)) {
  case TAG_MkPair: {
    V v_x_24217 = heff_field(v_x2_24216, 0);
    V v_s_24218 = heff_field(v_x2_24216, 1);
    heff_take_n(v_x2_24216, 3ULL, 2);
    V v_m_24220 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24221 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_s_24218}));
    switch (heff_tag_of(v_x2_24221)) {
    case TAG_MkPair: {
      V v_x_24222 = heff_field(v_x2_24221, 0);
      V v_s_24223 = heff_field(v_x2_24221, 1);
      heff_take_n(v_x2_24221, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24217;
      heff_room[1] = v_x_24222;
      heff_room[2] = v_s_24223;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24221);
    }
  }
  default: return heff_nomatch(v_x2_24216);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24230 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24230;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_s_24226}));
  switch (heff_tag_of(v_x2_24227)) {
  case TAG_MkPair: {
    V v_x_24228 = heff_field(v_x2_24227, 0);
    V v_s_24229 = heff_field(v_x2_24227, 1);
    heff_take_n(v_x2_24227, 3ULL, 2);
    V v_m_24231 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24232 = heff_tr(heff_call(v_m_24231, 1, (V[]){v_s_24229}));
    switch (heff_tag_of(v_x2_24232)) {
    case TAG_MkPair: {
      V v_x_24233 = heff_field(v_x2_24232, 0);
      V v_s_24234 = heff_field(v_x2_24232, 1);
      heff_take_n(v_x2_24232, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24228;
      heff_room[1] = v_x_24233;
      heff_room[2] = v_s_24234;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24232);
    }
  }
  default: return heff_nomatch(v_x2_24227);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24241 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    heff_take_n(v_x2_24238, 3ULL, 2);
    V v_m_24242 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24243 = heff_tr(heff_call(v_m_24242, 1, (V[]){v_s_24240}));
    switch (heff_tag_of(v_x2_24243)) {
    case TAG_MkPair: {
      V v_x_24244 = heff_field(v_x2_24243, 0);
      V v_s_24245 = heff_field(v_x2_24243, 1);
      heff_take_n(v_x2_24243, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24239;
      heff_room[1] = v_x_24244;
      heff_room[2] = v_s_24245;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24243);
    }
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24253 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24253;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24249 = args[0];
  V v_m_24248 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24250 = heff_tr(heff_call(v_m_24248, 1, (V[]){v_s_24249}));
  switch (heff_tag_of(v_x2_24250)) {
  case TAG_MkPair: {
    V v_x_24251 = heff_field(v_x2_24250, 0);
    V v_s_24252 = heff_field(v_x2_24250, 1);
    heff_take_n(v_x2_24250, 3ULL, 2);
    V v_m_24254 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24255 = heff_tr(heff_call(v_m_24254, 1, (V[]){v_s_24252}));
    switch (heff_tag_of(v_x2_24255)) {
    case TAG_MkPair: {
      V v_x_24256 = heff_field(v_x2_24255, 0);
      V v_s_24257 = heff_field(v_x2_24255, 1);
      heff_take_n(v_x2_24255, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24251;
      heff_room[1] = v_x_24256;
      heff_room[2] = v_s_24257;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24255);
    }
  }
  default: return heff_nomatch(v_x2_24250);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24264 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24264;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24260 = args[0];
  V v_m_24259 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24261 = heff_tr(heff_call(v_m_24259, 1, (V[]){v_s_24260}));
  switch (heff_tag_of(v_x2_24261)) {
  case TAG_MkPair: {
    V v_x_24262 = heff_field(v_x2_24261, 0);
    V v_s_24263 = heff_field(v_x2_24261, 1);
    heff_take_n(v_x2_24261, 3ULL, 2);
    V v_m_24265 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24266 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_s_24263}));
    switch (heff_tag_of(v_x2_24266)) {
    case TAG_MkPair: {
      V v_x_24267 = heff_field(v_x2_24266, 0);
      V v_s_24268 = heff_field(v_x2_24266, 1);
      heff_take_n(v_x2_24266, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24262;
      heff_room[1] = v_x_24267;
      heff_room[2] = v_s_24268;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24266);
    }
  }
  default: return heff_nomatch(v_x2_24261);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24274 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24274;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_s_24270}));
  switch (heff_tag_of(v_x2_24271)) {
  case TAG_MkPair: {
    V v_x_24272 = heff_field(v_x2_24271, 0);
    V v_s_24273 = heff_field(v_x2_24271, 1);
    heff_take_n(v_x2_24271, 3ULL, 2);
    V v_m_24275 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24276 = heff_tr(heff_call(v_m_24275, 1, (V[]){v_s_24273}));
    switch (heff_tag_of(v_x2_24276)) {
    case TAG_MkPair: {
      V v_x_24277 = heff_field(v_x2_24276, 0);
      V v_s_24278 = heff_field(v_x2_24276, 1);
      heff_take_n(v_x2_24276, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24272;
      heff_room[1] = v_x_24277;
      heff_room[2] = v_s_24278;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24276);
    }
  }
  default: return heff_nomatch(v_x2_24271);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24286 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24286;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24283 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_s_24282}));
  switch (heff_tag_of(v_x2_24283)) {
  case TAG_MkPair: {
    V v_x_24284 = heff_field(v_x2_24283, 0);
    V v_s_24285 = heff_field(v_x2_24283, 1);
    heff_take_n(v_x2_24283, 3ULL, 2);
    V v_m_24287 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24288 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_s_24285}));
    switch (heff_tag_of(v_x2_24288)) {
    case TAG_MkPair: {
      V v_x_24289 = heff_field(v_x2_24288, 0);
      V v_s_24290 = heff_field(v_x2_24288, 1);
      heff_take_n(v_x2_24288, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24284;
      heff_room[1] = v_x_24289;
      heff_room[2] = v_s_24290;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24288);
    }
  }
  default: return heff_nomatch(v_x2_24283);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24299 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24299;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24295 = args[0];
  V v_m_24294 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24296 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_s_24295}));
  switch (heff_tag_of(v_x2_24296)) {
  case TAG_MkPair: {
    V v_x_24297 = heff_field(v_x2_24296, 0);
    V v_s_24298 = heff_field(v_x2_24296, 1);
    heff_take_n(v_x2_24296, 3ULL, 2);
    V v_m_24300 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_s_24298}));
    switch (heff_tag_of(v_x2_24301)) {
    case TAG_MkPair: {
      V v_x_24302 = heff_field(v_x2_24301, 0);
      V v_s_24303 = heff_field(v_x2_24301, 1);
      heff_take_n(v_x2_24301, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24297;
      heff_room[1] = v_x_24302;
      heff_room[2] = v_s_24303;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24301);
    }
  }
  default: return heff_nomatch(v_x2_24296);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24311 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24311;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_s_24307}));
  switch (heff_tag_of(v_x2_24308)) {
  case TAG_MkPair: {
    V v_x_24309 = heff_field(v_x2_24308, 0);
    V v_s_24310 = heff_field(v_x2_24308, 1);
    heff_take_n(v_x2_24308, 3ULL, 2);
    V v_m_24312 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24313 = heff_tr(heff_call(v_m_24312, 1, (V[]){v_s_24310}));
    switch (heff_tag_of(v_x2_24313)) {
    case TAG_MkPair: {
      V v_x_24314 = heff_field(v_x2_24313, 0);
      V v_s_24315 = heff_field(v_x2_24313, 1);
      heff_take_n(v_x2_24313, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24309;
      heff_room[1] = v_x_24314;
      heff_room[2] = v_s_24315;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24313);
    }
  }
  default: return heff_nomatch(v_x2_24308);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24325 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24325;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_s_24321}));
  switch (heff_tag_of(v_x2_24322)) {
  case TAG_MkPair: {
    V v_x_24323 = heff_field(v_x2_24322, 0);
    V v_s_24324 = heff_field(v_x2_24322, 1);
    heff_take_n(v_x2_24322, 3ULL, 2);
    V v_m_24326 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24327 = heff_tr(heff_call(v_m_24326, 1, (V[]){v_s_24324}));
    switch (heff_tag_of(v_x2_24327)) {
    case TAG_MkPair: {
      V v_x_24328 = heff_field(v_x2_24327, 0);
      V v_s_24329 = heff_field(v_x2_24327, 1);
      heff_take_n(v_x2_24327, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24323;
      heff_room[1] = v_x_24328;
      heff_room[2] = v_s_24329;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24327);
    }
  }
  default: return heff_nomatch(v_x2_24322);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24338 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24338;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24334 = args[0];
  V v_m_24333 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24335 = heff_tr(heff_call(v_m_24333, 1, (V[]){v_s_24334}));
  switch (heff_tag_of(v_x2_24335)) {
  case TAG_MkPair: {
    V v_x_24336 = heff_field(v_x2_24335, 0);
    V v_s_24337 = heff_field(v_x2_24335, 1);
    heff_take_n(v_x2_24335, 3ULL, 2);
    V v_m_24339 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24340 = heff_tr(heff_call(v_m_24339, 1, (V[]){v_s_24337}));
    switch (heff_tag_of(v_x2_24340)) {
    case TAG_MkPair: {
      V v_x_24341 = heff_field(v_x2_24340, 0);
      V v_s_24342 = heff_field(v_x2_24340, 1);
      heff_take_n(v_x2_24340, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24336;
      heff_room[1] = v_x_24341;
      heff_room[2] = v_s_24342;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24340);
    }
  }
  default: return heff_nomatch(v_x2_24335);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24350 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24350;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24346 = args[0];
  V v_m_24345 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24347 = heff_tr(heff_call(v_m_24345, 1, (V[]){v_s_24346}));
  switch (heff_tag_of(v_x2_24347)) {
  case TAG_MkPair: {
    V v_x_24348 = heff_field(v_x2_24347, 0);
    V v_s_24349 = heff_field(v_x2_24347, 1);
    heff_take_n(v_x2_24347, 3ULL, 2);
    V v_m_24351 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24352 = heff_tr(heff_call(v_m_24351, 1, (V[]){v_s_24349}));
    switch (heff_tag_of(v_x2_24352)) {
    case TAG_MkPair: {
      V v_x_24353 = heff_field(v_x2_24352, 0);
      V v_s_24354 = heff_field(v_x2_24352, 1);
      heff_take_n(v_x2_24352, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24348;
      heff_room[1] = v_x_24353;
      heff_room[2] = v_s_24354;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24352);
    }
  }
  default: return heff_nomatch(v_x2_24347);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24361 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24361;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_s_24357}));
  switch (heff_tag_of(v_x2_24358)) {
  case TAG_MkPair: {
    V v_x_24359 = heff_field(v_x2_24358, 0);
    V v_s_24360 = heff_field(v_x2_24358, 1);
    heff_take_n(v_x2_24358, 3ULL, 2);
    V v_m_24362 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24363 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_s_24360}));
    switch (heff_tag_of(v_x2_24363)) {
    case TAG_MkPair: {
      V v_x_24364 = heff_field(v_x2_24363, 0);
      V v_s_24365 = heff_field(v_x2_24363, 1);
      heff_take_n(v_x2_24363, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24359;
      heff_room[1] = v_x_24364;
      heff_room[2] = v_s_24365;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24363);
    }
  }
  default: return heff_nomatch(v_x2_24358);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24373 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24373;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24369 = args[0];
  V v_m_24368 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24370 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_s_24369}));
  switch (heff_tag_of(v_x2_24370)) {
  case TAG_MkPair: {
    V v_x_24371 = heff_field(v_x2_24370, 0);
    V v_s_24372 = heff_field(v_x2_24370, 1);
    heff_take_n(v_x2_24370, 3ULL, 2);
    V v_m_24374 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24375 = heff_tr(heff_call(v_m_24374, 1, (V[]){v_s_24372}));
    switch (heff_tag_of(v_x2_24375)) {
    case TAG_MkPair: {
      V v_x_24376 = heff_field(v_x2_24375, 0);
      V v_s_24377 = heff_field(v_x2_24375, 1);
      heff_take_n(v_x2_24375, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24371;
      heff_room[1] = v_x_24376;
      heff_room[2] = v_s_24377;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24375);
    }
  }
  default: return heff_nomatch(v_x2_24370);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24385 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24385;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24381 = args[0];
  V v_m_24380 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24382 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_s_24381}));
  switch (heff_tag_of(v_x2_24382)) {
  case TAG_MkPair: {
    V v_x_24383 = heff_field(v_x2_24382, 0);
    V v_s_24384 = heff_field(v_x2_24382, 1);
    heff_take_n(v_x2_24382, 3ULL, 2);
    V v_m_24386 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24387 = heff_tr(heff_call(v_m_24386, 1, (V[]){v_s_24384}));
    switch (heff_tag_of(v_x2_24387)) {
    case TAG_MkPair: {
      V v_x_24388 = heff_field(v_x2_24387, 0);
      V v_s_24389 = heff_field(v_x2_24387, 1);
      heff_take_n(v_x2_24387, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24383;
      heff_room[1] = v_x_24388;
      heff_room[2] = v_s_24389;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24387);
    }
  }
  default: return heff_nomatch(v_x2_24382);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24396 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24396;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_s_24392}));
  switch (heff_tag_of(v_x2_24393)) {
  case TAG_MkPair: {
    V v_x_24394 = heff_field(v_x2_24393, 0);
    V v_s_24395 = heff_field(v_x2_24393, 1);
    heff_take_n(v_x2_24393, 3ULL, 2);
    V v_m_24397 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24398 = heff_tr(heff_call(v_m_24397, 1, (V[]){v_s_24395}));
    switch (heff_tag_of(v_x2_24398)) {
    case TAG_MkPair: {
      V v_x_24399 = heff_field(v_x2_24398, 0);
      V v_s_24400 = heff_field(v_x2_24398, 1);
      heff_take_n(v_x2_24398, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24394;
      heff_room[1] = v_x_24399;
      heff_room[2] = v_s_24400;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24398);
    }
  }
  default: return heff_nomatch(v_x2_24393);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24407 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24407;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_s_24403}));
  switch (heff_tag_of(v_x2_24404)) {
  case TAG_MkPair: {
    V v_x_24405 = heff_field(v_x2_24404, 0);
    V v_s_24406 = heff_field(v_x2_24404, 1);
    heff_take_n(v_x2_24404, 3ULL, 2);
    V v_m_24408 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24409 = heff_tr(heff_call(v_m_24408, 1, (V[]){v_s_24406}));
    switch (heff_tag_of(v_x2_24409)) {
    case TAG_MkPair: {
      V v_x_24410 = heff_field(v_x2_24409, 0);
      V v_s_24411 = heff_field(v_x2_24409, 1);
      heff_take_n(v_x2_24409, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24405;
      heff_room[1] = v_x_24410;
      heff_room[2] = v_s_24411;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24409);
    }
  }
  default: return heff_nomatch(v_x2_24404);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24418 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24414 = args[0];
  V v_m_24413 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24415 = heff_tr(heff_call(v_m_24413, 1, (V[]){v_s_24414}));
  switch (heff_tag_of(v_x2_24415)) {
  case TAG_MkPair: {
    V v_x_24416 = heff_field(v_x2_24415, 0);
    V v_s_24417 = heff_field(v_x2_24415, 1);
    heff_take_n(v_x2_24415, 3ULL, 2);
    V v_m_24419 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24420 = heff_tr(heff_call(v_m_24419, 1, (V[]){v_s_24417}));
    switch (heff_tag_of(v_x2_24420)) {
    case TAG_MkPair: {
      V v_x_24421 = heff_field(v_x2_24420, 0);
      V v_s_24422 = heff_field(v_x2_24420, 1);
      heff_take_n(v_x2_24420, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24416;
      heff_room[1] = v_x_24421;
      heff_room[2] = v_s_24422;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24420);
    }
  }
  default: return heff_nomatch(v_x2_24415);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24429 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24425 = args[0];
  V v_m_24424 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24426 = heff_tr(heff_call(v_m_24424, 1, (V[]){v_s_24425}));
  switch (heff_tag_of(v_x2_24426)) {
  case TAG_MkPair: {
    V v_x_24427 = heff_field(v_x2_24426, 0);
    V v_s_24428 = heff_field(v_x2_24426, 1);
    heff_take_n(v_x2_24426, 3ULL, 2);
    V v_m_24430 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24431 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_s_24428}));
    switch (heff_tag_of(v_x2_24431)) {
    case TAG_MkPair: {
      V v_x_24432 = heff_field(v_x2_24431, 0);
      V v_s_24433 = heff_field(v_x2_24431, 1);
      heff_take_n(v_x2_24431, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24427;
      heff_room[1] = v_x_24432;
      heff_room[2] = v_s_24433;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24431);
    }
  }
  default: return heff_nomatch(v_x2_24426);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24441 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24437 = args[0];
  V v_m_24436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24438 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_s_24437}));
  switch (heff_tag_of(v_x2_24438)) {
  case TAG_MkPair: {
    V v_x_24439 = heff_field(v_x2_24438, 0);
    V v_s_24440 = heff_field(v_x2_24438, 1);
    heff_take_n(v_x2_24438, 3ULL, 2);
    V v_m_24442 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24443 = heff_tr(heff_call(v_m_24442, 1, (V[]){v_s_24440}));
    switch (heff_tag_of(v_x2_24443)) {
    case TAG_MkPair: {
      V v_x_24444 = heff_field(v_x2_24443, 0);
      V v_s_24445 = heff_field(v_x2_24443, 1);
      heff_take_n(v_x2_24443, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24439;
      heff_room[1] = v_x_24444;
      heff_room[2] = v_s_24445;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24443);
    }
  }
  default: return heff_nomatch(v_x2_24438);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24452 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24448 = args[0];
  V v_m_24447 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24449 = heff_tr(heff_call(v_m_24447, 1, (V[]){v_s_24448}));
  switch (heff_tag_of(v_x2_24449)) {
  case TAG_MkPair: {
    V v_x_24450 = heff_field(v_x2_24449, 0);
    V v_s_24451 = heff_field(v_x2_24449, 1);
    heff_take_n(v_x2_24449, 3ULL, 2);
    V v_m_24453 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24454 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_s_24451}));
    switch (heff_tag_of(v_x2_24454)) {
    case TAG_MkPair: {
      V v_x_24455 = heff_field(v_x2_24454, 0);
      V v_s_24456 = heff_field(v_x2_24454, 1);
      heff_take_n(v_x2_24454, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24450;
      heff_room[1] = v_x_24455;
      heff_room[2] = v_s_24456;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24454);
    }
  }
  default: return heff_nomatch(v_x2_24449);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_a_24462 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24458 = args[0];
  V v_m_24457 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24459 = heff_tr(heff_call(v_m_24457, 1, (V[]){v_s_24458}));
  switch (heff_tag_of(v_x2_24459)) {
  case TAG_MkPair: {
    V v_x_24460 = heff_field(v_x2_24459, 0);
    V v_s_24461 = heff_field(v_x2_24459, 1);
    heff_take_n(v_x2_24459, 3ULL, 2);
    V v_m_24463 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam78, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24464 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_s_24461}));
    switch (heff_tag_of(v_x2_24464)) {
    case TAG_MkPair: {
      V v_x_24465 = heff_field(v_x2_24464, 0);
      V v_s_24466 = heff_field(v_x2_24464, 1);
      heff_take_n(v_x2_24464, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24460;
      heff_room[1] = v_x_24465;
      heff_room[2] = v_s_24466;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24464);
    }
  }
  default: return heff_nomatch(v_x2_24459);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_a_24474 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24470 = args[0];
  V v_m_24469 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24471 = heff_tr(heff_call(v_m_24469, 1, (V[]){v_s_24470}));
  switch (heff_tag_of(v_x2_24471)) {
  case TAG_MkPair: {
    V v_x_24472 = heff_field(v_x2_24471, 0);
    V v_s_24473 = heff_field(v_x2_24471, 1);
    heff_take_n(v_x2_24471, 3ULL, 2);
    V v_m_24475 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam80, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2419));
    V v_x2_24476 = heff_tr(heff_call(v_m_24475, 1, (V[]){v_s_24473}));
    switch (heff_tag_of(v_x2_24476)) {
    case TAG_MkPair: {
      V v_x_24477 = heff_field(v_x2_24476, 0);
      V v_s_24478 = heff_field(v_x2_24476, 1);
      heff_take_n(v_x2_24476, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24472;
      heff_room[1] = v_x_24477;
      heff_room[2] = v_s_24478;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24476);
    }
  }
  default: return heff_nomatch(v_x2_24471);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24483 = args[0];
  V v_m_24482 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24479 = heff_env(self)[2];
  V v_b_24481 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24484 = heff_tr(heff_call(v_m_24482, 1, (V[]){v_s_24483}));
  switch (heff_tag_of(v_x2_24484)) {
  case TAG_MkPair: {
    V v_x_24485 = heff_field(v_x2_24484, 0);
    V v_s_24486 = heff_field(v_x2_24484, 1);
    heff_take_n(v_x2_24484, 3ULL, 2);
    V v_t_24487 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_24479, v_x_24485, v_b_24481));
    V f_ = v_t_24487;
    args[0] = v_s_24486;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24484);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24494 = args[0];
  V v_m_24493 = heff_env(self)[0];
  V v_l_24491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24495 = heff_tr(heff_call(v_m_24493, 1, (V[]){v_s_24494}));
  switch (heff_tag_of(v_x2_24495)) {
  case TAG_MkPair: {
    V v_x_24496 = heff_field(v_x2_24495, 0);
    V v_s_24497 = heff_field(v_x2_24495, 1);
    V v_ru_24x2_24495_24MkPair = heff_take_reuse_n(v_x2_24495, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24491, v_x_24496}), v_s_24497});
  }
  default: return heff_nomatch(v_x2_24495);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_p_24490 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24490)) {
  case TAG_MkPair: {
    V v_l_24491 = heff_field(v_p_24490, 0);
    V v_e_24492 = heff_field(v_p_24490, 1);
    heff_take_n(v_p_24490, 3ULL, 2);
    V v_m_24493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_e_24492}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam83, 1, 2, (V[]){v_m_24493, v_l_24491});
  }
  default: return heff_nomatch(v_p_24490);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24499 = args[0];
  V v_m_24498 = heff_env(self)[0];
  V v_ts_24489 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24500 = heff_tr(heff_call(v_m_24498, 1, (V[]){v_s_24499}));
  switch (heff_tag_of(v_x2_24500)) {
  case TAG_MkPair: {
    V v_x_24501 = heff_field(v_x2_24500, 0);
    V v_s_24502 = heff_field(v_x2_24500, 1);
    V v_ru_24x2_24500_24MkPair = heff_take_reuse_n(v_x2_24500, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24500_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24501, v_ts_24489}), v_s_24502});
  }
  default: return heff_nomatch(v_x2_24500);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_s_24508 = args[0];
  V v_m_24507 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24504 = heff_env(self)[2];
  V v_sh_24505 = heff_env(self)[3];
  V v_t_24506 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24509 = heff_tr(heff_call(v_m_24507, 1, (V[]){v_s_24508}));
  switch (heff_tag_of(v_x2_24509)) {
  case TAG_MkPair: {
    V v_x_24510 = heff_field(v_x2_24509, 0);
    V v_s_24511 = heff_field(v_x2_24509, 1);
    heff_take_n(v_x2_24509, 3ULL, 2);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 5, (V[]){v_l_24504, v_sh_24505, v_t_24506, v_x_24510, v_s_24511});
  }
  default: return heff_nomatch(v_x2_24509);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_a_24515 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24515;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24517 = args[0];
  V v_m_24516 = heff_env(self)[0];
  V v_t_24512 = heff_env(self)[1];
  V v_ts_24514 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24518 = heff_tr(heff_call(v_m_24516, 1, (V[]){v_s_24517}));
  switch (heff_tag_of(v_x2_24518)) {
  case TAG_MkPair: {
    V v_x_24519 = heff_field(v_x2_24518, 0);
    V v_s_24520 = heff_field(v_x2_24518, 1);
    V v_ru_24x2_24518_24MkPair = heff_take_reuse_n(v_x2_24518, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24518_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24512, v_x_24519, v_ts_24514}), v_s_24520});
  }
  default: return heff_nomatch(v_x2_24518);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_s_24533 = args[0];
  V v_m_24532 = heff_env(self)[0];
  V v_t_24529 = heff_env(self)[1];
  V v_vs_24530 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24534 = heff_tr(heff_call(v_m_24532, 1, (V[]){v_s_24533}));
  switch (heff_tag_of(v_x2_24534)) {
  case TAG_MkPair: {
    V v_x_24535 = heff_field(v_x2_24534, 0);
    V v_s_24536 = heff_field(v_x2_24534, 1);
    V v_ru_24x2_24534_24MkPair = heff_take_reuse_n(v_x2_24534, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24534_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24529, v_vs_24530, v_x_24535}), v_s_24536});
  }
  default: return heff_nomatch(v_x2_24534);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_a_24528 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24528)) {
  case TAG_MkArm: {
    V v_t_24529 = heff_field(v_a_24528, 0);
    V v_vs_24530 = heff_field(v_a_24528, 1);
    V v_b_24531 = heff_field(v_a_24528, 2);
    heff_take_n(v_a_24528, 7ULL, 3);
    V v_m_24532 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24531}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam90, 1, 3, (V[]){v_m_24532, v_t_24529, v_vs_24530});
  }
  default: return heff_nomatch(v_a_24528);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_s_24524 = args[0];
  V v_m_24523 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24522 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24525 = heff_tr(heff_call(v_m_24523, 1, (V[]){v_s_24524}));
  switch (heff_tag_of(v_x2_24525)) {
  case TAG_MkPair: {
    V v_x_24526 = heff_field(v_x2_24525, 0);
    V v_s_24527 = heff_field(v_x2_24525, 1);
    heff_take_n(v_x2_24525, 3ULL, 2);
    V v_m_24537 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam89, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24522));
    V v_x2_24538 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_s_24527}));
    switch (heff_tag_of(v_x2_24538)) {
    case TAG_MkPair: {
      V v_x_24539 = heff_field(v_x2_24538, 0);
      V v_s_24540 = heff_field(v_x2_24538, 1);
      heff_take_n(v_x2_24538, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 3, 4);
      heff_room[0] = v_x_24526;
      heff_room[1] = v_x_24539;
      heff_room[2] = v_s_24540;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24538);
    }
  }
  default: return heff_nomatch(v_x2_24525);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24542 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24542});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_a_24545 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24545;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24547 = args[0];
  V v_m_24546 = heff_env(self)[0];
  V v_p_24543 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24548 = heff_tr(heff_call(v_m_24546, 1, (V[]){v_s_24547}));
  switch (heff_tag_of(v_x2_24548)) {
  case TAG_MkPair: {
    V v_x_24549 = heff_field(v_x2_24548, 0);
    V v_s_24550 = heff_field(v_x2_24548, 1);
    V v_ru_24x2_24548_24MkPair = heff_take_reuse_n(v_x2_24548, 3ULL, 2);
    V v_x_24551 = (g_heff_2ecompile_2esimplify_2efoldPrim(v_p_24543, v_x_24549));
    return heff_tag_at_n(v_ru_24x2_24548_24MkPair, TAG_MkPair, 2, (V[]){v_x_24551, v_s_24550});
  }
  default: return heff_nomatch(v_x2_24548);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_s_24554 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24554});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24556 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24556});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24558 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24558});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24560 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24560});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam98(V self, V *args) {
  V v_s_24562 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24562});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam99(V self, V *args) {
  V v_s_24565 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24565});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam100(V self, V *args) {
  V v_s_24567 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24567});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam101(V self, V *args) {
  V v_s_24568 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24568});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam102(V self, V *args) {
  V v_s_24571 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24571});
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_s_244, 2), v_g_242));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_b_249 = v_field_247;
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_249, NTAG(TAG_Nil)});
      V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_2410));
      if (heff_intLt_c(MK_INT(50LL), v_x_2411)) {
        heff_drop_rec(v_r_240, 4);
        V v_x_2413 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_244});
      } else {
        V v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_s_244, 2), v_g_242));
        HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2414, v_s_244));
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          V v_x_2418 = v_field_2416;
          V v_s_2419 = v_field_2417;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nothing: {
            heff_drop_rec(v_r_240, 4);
            V v_x_2420 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_2419});
          }
          case TAG_Just: {
            V v_b_2421 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 1);
            V v_orig_2422 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
            V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2421, v_as_243}));
            return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2422, v_m_2423, v_s_2419));
          }
          default: return heff_nomatch(v_x_2418);
          }
        }
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2424 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_s_244, 2), v_g_242));
      HeffT2 v_t_2425 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2424, v_s_244));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_s_2429 = v_field_2427;
        switch (heff_tag_of(v_x_2428)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2430 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2430, v_s_2429});
        }
        case TAG_Just: {
          V v_b_2431 = heff_field(v_x_2428, 0);
          heff_take_n(v_x_2428, 1ULL, 1);
          V v_orig_2432 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
          V v_m_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2431, v_as_243}));
          return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), v_orig_2432, v_m_2433, v_s_2429));
        }
        default: return heff_nomatch(v_x_2428);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2einlineCall(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0, 1, "p");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1, 1, "$");

HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_take_field(v_s_241, 0)});
  V v_t_243 = (g_list_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_list_2efoldl_24s1794308634x1384130934(((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str0), ((V)&g_heff_2ecompile_2esimplify_2efreshParams_24cpr_str1), MK_INT(1LL), v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    V v_f_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_xs_245, v_f_247}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str0), heff_intShow(v_t_245));
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_s_244, 6); V b_1 = heff_strAppend(heff_dup(v_g_242), v_t_246); HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_g_242);
      V v_it1_2411 = v_field_249;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_Inlined: {
        V v_ps_2412 = heff_field(v_it1_2411, 0);
        V v_e_2413 = heff_field(v_it1_2411, 1);
        V v_ru_24it1_2411_24Inlined = heff_take_reuse_n(v_it1_2411, 3ULL, 2);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 1)))) {
          heff_drop(v_f_241);
          V v_t_2415 = heff_intSub(heff_take_field(v_s_244, 1), MK_INT(1LL));
          V v_t_2416 = ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_244, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          HeffT2 v_t_2417 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_e_2413, v_t_2416));
          {
            V v_field_2418 = v_t_2417.f[0];
            V v_field_2419 = v_t_2417.f[1];
            V v_x_2420 = v_field_2418;
            V v_s_2421 = v_field_2419;
            V v_t_2422 = (g_heff_2ecompile_2esimplify_2ezipL(v_ps_2412, v_as_243));
            V v_m_2423 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_t_2422); r_; });
            V v_t_2424 = (g_std_2emap_2esize(v_m_2423));
            V v_x_2426;
            if (heff_intEq_c(v_t_2424, MK_INT(0LL))) {
              heff_drop(v_m_2423);
              v_x_2426 = v_x_2420;
            } else {
              v_x_2426 = ({ V a_0 = v_m_2423; V a_1 = v_x_2420; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2423); r_; });
            }
            return heff_tag_at_n(v_ru_24it1_2411_24Inlined, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2421});
          }
        } else {
          heff_drop(v_ps_2412);
          heff_drop(v_e_2413);
          V v_x_2427 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24it1_2411_24Inlined, TAG_MkPair, 2, (V[]){v_x_2427, v_s_244});
        }
      }
      case TAG_NotInlined: {
        V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_244});
      }
      default: return heff_nomatch(v_it1_2411);
      }
    } else {
      heff_drop(v_field_249);
      V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
      HeffT2 v_t_2430 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2429, heff_dup(v_s_244)));
      {
        V v_field_2431 = v_t_2430.f[0];
        V v_field_2432 = v_t_2430.f[1];
        V v_x_2433 = v_field_2431;
        V v_s_2434 = v_field_2432;
        V v_t_2435 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_s_2434, 2), v_g_242));
        HeffT2 v_t_2436 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2435, v_s_2434));
        {
          V v_field_2437 = v_t_2436.f[0];
          V v_field_2438 = v_t_2436.f[1];
          V v_x_2439 = v_field_2437;
          V v_s_2440 = v_field_2438;
          switch (heff_tag_of(v_x_2439)) {
          case TAG_Nothing: {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_g_242);
            heff_drop_rec(v_s_244, 9);
            heff_drop(v_x_2433);
            V v_x_2441 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_s_2440});
          }
          case TAG_Just: {
            V v_b_2442 = heff_field(v_x_2439, 0);
            heff_take_n(v_x_2439, 1ULL, 1);
            V v_t_2443 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2433)));
            V v_m_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2442, v_t_2443}));
            V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2440}));
            switch (heff_tag_of(v_x2_2445)) {
            case TAG_MkPair: {
              V v_x_2446 = heff_field(v_x2_2445, 0);
              V v_s_2447 = heff_field(v_x2_2445, 1);
              V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
              V v_e_2448 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
              V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
              V v_t_2450 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2449));
              V v_lim_2451 = heff_intAdd(v_t_2450, MK_INT(24LL));
              V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2446), NTAG(TAG_Nil)});
              V v_x_2453 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2451), MK_INT(0LL), v_t_2452));
              if (heff_intLt_c(v_lim_2451, v_x_2453)) {
                heff_drop(v_x_2433);
                heff_drop(v_x_2446);
                V v_t_2455 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
                V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str1), heff_intShow(v_t_2455));
                V v_t_2457 = heff_strAppend(v_g_242, v_t_2456);
                V v_t_2458 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_2447, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
                HeffT2 v_t_2459 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2457, NTAG(TAG_NotInlined), v_t_2458));
                {
                  V v_field_2460 = v_t_2459.f[0];
                  V v_field_2461 = v_t_2459.f[1];
                  V v_x_2462 = v_field_2460;
                  heff_drop(v_x_2462);
                  V v_s_2463 = v_field_2461;
                  V v_x_2464 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
                  return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){v_x_2464, v_s_2463});
                }
              } else {
                heff_drop(v_f_241);
                heff_drop_rec(v_s_244, 9);
                V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
                V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str2), heff_intShow(v_t_2465));
                V v_t_2467 = heff_strAppend(v_g_242, v_t_2466);
                HeffT2 v_t_2468 = (g_heff_2ecompile_2esimplify_2eremember_24cpr(v_t_2467, heff_tag_n(TAG_Inlined, 2, (V[]){heff_dup(v_x_2433), heff_dup(v_x_2446)}), v_s_2447));
                {
                  V v_field_2469 = v_t_2468.f[0];
                  V v_field_2470 = v_t_2468.f[1];
                  V v_x_2471 = v_field_2469;
                  heff_drop(v_x_2471);
                  V v_s_2472 = v_field_2470;
                  V v_t_2473 = (g_heff_2ecompile_2esimplify_2ezipL(v_x_2433, v_as_243));
                  V v_m_2474 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2473; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_t_2473); r_; });
                  V v_t_2475 = (g_std_2emap_2esize(v_m_2474));
                  V v_x_2477;
                  if (heff_intEq_c(v_t_2475, MK_INT(0LL))) {
                    heff_drop(v_m_2474);
                    v_x_2477 = v_x_2446;
                  } else {
                    v_x_2477 = ({ V a_0 = v_m_2474; V a_1 = v_x_2446; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2474); r_; });
                  }
                  return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){v_x_2477, v_s_2472});
                }
              }
            }
            default: return heff_nomatch(v_x2_2445);
            }
          }
          default: return heff_nomatch(v_x_2439);
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eworthIt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eworthIt_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eworthIt(V v_kinds_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_as_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_b_247 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2esimplify_2etoldTo(heff_dup(v_b_247), heff_dup(v_xs_246), heff_dup(v_as_241)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_as_241);
        heff_drop(v_t_248);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_b_247})});
      } else {
        heff_drop(v_t_248);
        V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_241));
        V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
        if (heff_intLt_c(v_y_2410, v_x_249)) {
          V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
          V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_as_241));
          V v_t_2414 = ({ V a_0 = v_kinds_240; V a_1 = v_t_2413; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2413); r_; });
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_b_247})});
          } else {
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_xs_246);
            heff_drop(v_b_247);
            heff_drop(v_t_2414);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_as_241);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_xs_246);
          heff_drop(v_b_247);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EApp: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x31_243, 0ULL, 4);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 3);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_as_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eworthIt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eworthIt(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopyCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_list_2emap_24s1049096277x601353451(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_243));
        if (heff_intEq_c(v_t_2412, v_t_2413)) {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        } else {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
      } else {
        heff_drop(v_t_2411);
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EBytes: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_loop_240, V v_all_241, V v_back_242, V v_as_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_back_242);
    heff_drop(v_as_243);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_246 = heff_field(v_x5_244, 0);
    V v_rest_247 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2415;
    if ((heff_dup(v_st_246) == NTAG(TAG_True))) {
      heff_drop(v_st_246);
      HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2enthE_24cpr(heff_dup(v_i_245), heff_dup(v_as_243)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_t_2413 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_241, heff_dup(v_x_2412)));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_x_2412);
            heff_drop(v_t_2413);
            v_t_2415 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2413);
            if ((heff_dup(v_loop_240) == NTAG(TAG_True))) {
              V v_t_2414 = (g_heff_2ecompile_2esimplify_2ecapturing(heff_dup(v_x_2412)));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_x_2412);
                heff_drop(v_t_2414);
                v_t_2415 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2414);
                v_t_2415 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2412}));
              }
            } else {
              v_t_2415 = heff_tr(heff_call(heff_dup(v_back_242), 1, (V[]){v_x_2412}));
            }
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2415 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_st_246);
      v_t_2415 = NTAG(TAG_False);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_heff_2ecompile_2esimplify_2emarkGo_24dps(v_loop_240, v_all_241, v_back_242, v_as_243, v_rest_247, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especKey_str4, 1, ")");
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKey_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2especKey(V v_g_240, V v_marks_241, V v_vars_242, V v_as_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_marks_241));
  V v_t_245 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_244, v_as_243));
  V v_x2_249 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2esimplify_2especKey_lam0, 2, 1, (V[]){v_vars_242}), v_marks_241, v_t_245));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especKey_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especKey_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2esimplify_2especKey_str4)));
  return heff_strAppend(v_g_240, v_t_2413);
}
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKey(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2especKey_lam0(V self, V *args) {
  V v_m_246 = args[0];
  V v_a_247 = args[1];
  V v_vars_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_m_246) == NTAG(TAG_True))) {
    heff_drop(v_m_246);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_242));
    return ({ V a_0 = v_t_248; V a_1 = v_a_247; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_a_247); r_; });
  } else {
    heff_drop(v_m_246);
    heff_drop(v_a_247);
    heff_drop(v_vars_242);
    return ((V)&g_heff_2ecompile_2esimplify_2especKey_str0);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_f_247;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
    v_f_247 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 3), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
      v_f_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_245);
      v_f_247 = v_s_242;
    }
  }
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_247}});
}
Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkCopySafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkCopySafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_249;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 4), heff_dup(v_h_240), NTAG(TAG_MkUnit)));
    V v_t_245 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
    v_t_249 = ({ V rv_3 = v_t_245; V rv_4 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 4), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 4), heff_dup(v_h_240), NTAG(TAG_MkUnit)));
      V v_t_248 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_242, 3), v_h_240, NTAG(TAG_MkUnit)));
      v_t_249 = ({ V rv_3 = v_t_248; V rv_4 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_242, 487ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_246);
      v_t_249 = v_s_242;
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_249});
}
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkCopySafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_x3_242, 0);
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    HEFF_LAST return g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_as_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EGlobal: {
      V v_g_2410 = heff_field(v_x31_247, 0);
      return (g_heff_2ecompile_2esimplify_2epartialMore(v_safe_240, v_all_241, v_g_2410, heff_dup(v_as_248)));
    }
    case TAG_ELam: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EApp: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ELet: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ERecord: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EProj: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ETag: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EMatch: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrim: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EPrimCall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_ECall: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EInt: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EStr: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EBytes: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFixed: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFloat32: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EAbandon: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    case TAG_EFix: {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_2444 = heff_field(v_x3_242, 1);
    V v_b_2445 = heff_field(v_x3_242, 2);
    V v_t_2446 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_a_2444));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      V t_0 = v_safe_240;
      V t_1 = v_all_241;
      V t_2 = v_b_2445;
      v_safe_240 = t_0;
      v_all_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2446);
      return MK_INT(0LL);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2456 = heff_field(v_x3_242, 0);
    V v_arms_2457 = heff_field(v_x3_242, 1);
    V v_t_2458 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), heff_dup(v_all_241), v_sc_2456));
    if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
      heff_drop(v_t_2458);
      switch (heff_tag_of(v_arms_2457)) {
      case TAG_Nil: {
        heff_drop(v_safe_240);
        heff_drop(v_all_241);
        return MK_INT(0LL);
      }
      case TAG_Cons: {
        V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 2, (V[]){v_safe_240, v_all_241}));
        V v_t_2462 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2457)));
        V v_x1_2463 = (g_list_2emap(v_t_2461, v_t_2462));
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2464 = heff_field(v_x1_2463, 0);
          V v_xs_2465 = heff_field(v_x1_2463, 1);
          heff_take_n(v_x1_2463, 3ULL, 2);
          return ({ V a_0 = v_x_2464; V a_1 = v_xs_2465; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_xs_2465); r_; });
        }
        default: return heff_nomatch(v_x1_2463);
        }
      }
      default: return heff_nomatch(v_arms_2457);
      }
    } else {
      heff_drop(v_safe_240);
      heff_drop(v_all_241);
      heff_drop(v_t_2458);
      return MK_INT(0LL);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    heff_drop(v_all_241);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_as_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2esimplify_2emarkedOf_24dps(v_ms_243, v_as_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        heff_drop(v_m_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_as_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_241, v_t_244}); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2414);
}
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2edepthOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_ds_240; V a_1 = v_n_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_ds_240); heff_drop(v_n_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_b_2412;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      v_b_2412 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      v_b_2412 = MK_INT(0LL);
    }
    if (heff_intLe_c_lent(v_b_2412, v_d_245, 0)) {
      heff_drop(v_b_2412);
      return v_d_245;
    } else {
      heff_drop(v_d_245);
      return v_b_2412;
    }
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2especKnown_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKnown_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2especKnown_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especKnown_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2especKnown_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKnown_lam2, 1, 0};
Clo g_heff_2ecompile_2esimplify_2especKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especKnown_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especKnown(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_made_245, V v_s_246) {
top: ;
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
  V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_as_244; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_back_2411;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
    v_back_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eloopBack_clo), 2, (V[]){v_t_249, heff_dup(v_g_241)}));
  } else {
    heff_drop(v_t_248);
    v_back_2411 = ((V)&g_heff_2ecompile_2esimplify_2especKnown_lam0_clo);
  }
  V v_t_2415 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especKnown_lam1, 1, 2, (V[]){heff_dup(v_s_246), v_back_2411}), v_as_244));
  V v_t_2422 = heff_bool(((heff_dup(v_t_2415) == NTAG(TAG_True)) ? 0 : ({ V v_t_2416 = (g_list_2eany_24s378803910x892125795(v_as_244)); int c_ = ((heff_dup(v_t_2416) == NTAG(TAG_True)) ? ({ V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243))); int c_ = ({ V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(heff_dup(v_t_2417))); int c_ = ({ V v_t_2419 = (g_heff_2ecompile_2esimplify_2eelemStr(v_g_241, v_t_2418)); int c_ = ((heff_dup(v_t_2419) == NTAG(TAG_True)) ? 0 : ({ V v_x1_2420 = (g_list_2eany_24s228396297x1310020012(v_made_245)); int c_ = !(heff_dup(v_x1_2420) == NTAG(TAG_True)); heff_drop(v_x1_2420); c_; })); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; }) : ({ V v_x1_2421 = (g_list_2eany_24s228396297x1310020012(v_made_245)); int c_ = !(heff_dup(v_x1_2421) == NTAG(TAG_True)); heff_drop(v_x1_2421); c_; })); heff_drop(v_t_2416); c_; })));
  heff_drop(v_t_2415);
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_made_245);
    heff_drop(v_t_2422);
    V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_246});
  } else {
    heff_drop(v_t_2422);
    V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_as_244; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_back_2428;
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 0, 7);
      v_back_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eloopBack_clo), 2, (V[]){v_t_2426, heff_dup(v_g_241)}));
    } else {
      heff_drop(v_t_2425);
      v_back_2428 = ((V)&g_heff_2ecompile_2esimplify_2especKnown_lam2_clo);
    }
    V v_t_2429 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2430 = (g_heff_2ecompile_2eir_2enubI(v_t_2429));
    V v_loop_2431 = ({ V a_0 = v_g_241; V a_1 = v_t_2430; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_s_246, 7)), 1, 7);
    V v_t_2434;
    if ((heff_dup(v_loop_2431) == NTAG(TAG_True))) {
      V v_t_2433 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2434 = ({ V a_0 = v_t_2433; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
    } else {
      v_t_2434 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
    }
    V v_t_2435 = ({ V a_0 = v_loop_2431; V a_1 = v_t_2432; V a_2 = v_back_2428; V a_3 = heff_dup(v_as_244); V a_4 = v_t_2434; V a_5 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2esimplify_2emarkGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_loop_2431); heff_drop(v_t_2432); r_; });
    V v_t_2436 = (g_heff_2ecompile_2esimplify_2eorMarks(v_t_2435, v_made_245));
    HEFF_LAST return g_heff_2ecompile_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2436, v_s_246);
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especKnown(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2esimplify_2especKnown_lam0(V self, V *args) {
  V v_e_2410 = args[0];
  heff_drop(v_e_2410);
  return NTAG(TAG_False);
}
V g_heff_2ecompile_2esimplify_2especKnown_lam1(V self, V *args) {
  V v_a_2412 = args[0];
  V v_s_246 = heff_env(self)[0];
  V v_back_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(heff_get_n(v_s_246, 7, 9), 1, 7);
  V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = heff_dup(v_a_2412); V r_ = (g_heff_2ecompile_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_2413); r_; });
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_a_2412);
    heff_drop(v_back_2411);
    heff_drop(v_t_2414);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2414);
    V f_ = v_back_2411;
    args[0] = v_a_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ecompile_2esimplify_2especKnown_lam2(V self, V *args) {
  V v_e_2427 = args[0];
  heff_drop(v_e_2427);
  return NTAG(TAG_False);
}
Clo g_heff_2ecompile_2esimplify_2eetaKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaKept(V v_saved_240, V v_x2_241, V v_lam1_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_bds_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eetaCapturing(heff_dup(v_lam1_242)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop_rec(v_saved_240, 9);
      heff_drop(v_t_246);
      V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_bds_244, v_lam1_242})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_243});
    } else {
      heff_drop(v_lam1_242);
      heff_drop(v_bds_244);
      heff_drop(v_t_246);
      V v_t_248 = ({ V rv_2 = heff_take_field(v_saved_240, 2); V rv_5 = heff_get_n(v_saved_240, 5, 9); V rr_ = heff_rec_reuse_nf(v_p_243, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_t_248});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaKept(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_True), v_p_241}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eargPure_24cpr(v_a_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        V t_0 = v_as_243;
        V t_1 = v_s_248;
        v_x1_240 = t_0;
        v_p_241 = t_1;
        goto top;
      } else {
        heff_drop(v_as_243);
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_False), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq_lent(v_g_240, v_h_249, 0);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 4, 5);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_k_247 = heff_dup(heff_rfield(v_s_242, 8));
    V v_t_2410;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_246;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_246);
      v_t_2410 = NTAG(TAG_Nil);
    }
    V v_t_2411 = ({ V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_k_247, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2412 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_2411});
    HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_t_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      heff_drop(v_x_2416);
      V v_s_2417 = v_field_2415;
      V v_m_2418 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b_241));
      V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_s_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2420, v_s_2421));
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_x_2425 = v_field_2423;
          V v_s_2426 = v_field_2424;
          V v_k_2427 = heff_dup(heff_rfield(v_s_2426, 8));
          V v_t_2428 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
          V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_s_2426, 8)), 2, 5);
          V v_t_2430 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_k_2427, 4), v_h_240, v_t_2429));
          V v_k_2431 = ({ V rv_2 = v_t_2428; V rv_4 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_k_2427, 11ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 207u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_f_2432 = ({ V rv_8 = v_k_2431; V rr_ = heff_rec_reuse_nf(v_s_2426, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
          return ((HeffT2){{v_x_2425, v_f_2432}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2419)}});
      }
    }
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V v_k_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 7);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_Just: {
    V v_b0_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_dup(heff_rfield(v_k_240, 4)), v_p_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ereplayBody_24cpr(v_k_240, v_b0_243, v_s_248));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_s_2413 = v_field_2411;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413}});
        }
      } else {
        heff_drop_rec(v_k_240, 7);
        heff_drop(v_b0_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_247);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_248}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}