// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BadShape 33347
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_NoShape 40346
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_RecordShape 6130
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_TagShape 40544
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_applies 1586106057
#define LBL_bodies 563425515
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_ctype 296362551
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_env 310119
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_grown 299987669
#define LBL_js 10160
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_supply 1056026650
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_tighter 1059982480
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_ty 10476
#define LBL_witness 1587180415
static uint32_t shape_bodies__after__supply[] = {LBL_bodies, LBL_after, LBL_supply};
static uint32_t shape_bodies__grown__supply[] = {LBL_bodies, LBL_grown, LBL_supply};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edriver_2ewithEntry(V, V, V);
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithEntry_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
HeffT2 g_heff_2ecompile_2edefun_2eanalyse_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2edefun_2egrow_24cpr(V, V, V);
V g_heff_2ecompile_2edefun_2ehandsW(V, V);
V g_heff_2ecompile_2edefun_2ehandsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2ehandsW_clo;
HeffT2 g_heff_2ecompile_2edefun_2eplanOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2edefun_2erw(V, V);
V g_heff_2ecompile_2edefun_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2erw_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efacts_2esureRecW(V, V);
V g_heff_2ecompile_2efacts_2esureRecW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureRecW_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1562730082x1519471820(V);
V g_list_2eall_24s1562730082x1519471820_entry(V self, V *a);
extern Clo g_list_2eall_24s1562730082x1519471820_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1606644238x788321190(V, V);
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a);
extern Clo g_list_2eany_24s1606644238x788321190_clo;
V g_list_2eany_24s442143688x2133738513(V, V);
V g_list_2eany_24s442143688x2133738513_entry(V self, V *a);
extern Clo g_list_2eany_24s442143688x2133738513_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2eany_24s935688233x1434116625(V, V);
V g_list_2eany_24s935688233x1434116625_entry(V self, V *a);
extern Clo g_list_2eany_24s935688233x1434116625_clo;
V g_list_2eascending_24s1147438953x64854941(V, V, V);
V g_list_2eascending_24s1147438953x64854941_entry(V self, V *a);
extern Clo g_list_2eascending_24s1147438953x64854941_clo;
V g_list_2ecollapse_24s945166865x820780714(V, V);
V g_list_2ecollapse_24s945166865x820780714_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s945166865x820780714_clo;
V g_list_2edescending_24s1092102222x1336838254(V, V, V);
V g_list_2edescending_24s1092102222x1336838254_entry(V self, V *a);
extern Clo g_list_2edescending_24s1092102222x1336838254_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1424316379x433407702_24cpr(V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1083429683x1325725555(V, V);
V g_list_2efoldl_24s1083429683x1325725555_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1083429683x1325725555_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513798766x1460159176(V, V);
V g_list_2efoldl_24s1513798766x1460159176_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513798766x1460159176_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s1780126197x1319226274(V, V);
V g_list_2efoldl_24s1780126197x1319226274_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1780126197x1319226274_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s509733942x1507005169(V, V, V, V);
V g_list_2efoldl_24s509733942x1507005169_entry(V self, V *a);
extern Clo g_list_2efoldl_24s509733942x1507005169_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s75764538x1218461500(V, V, V);
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a);
extern Clo g_list_2efoldl_24s75764538x1218461500_clo;
V g_list_2ekeepIf_24s1220809684x843195562_24dps(V, V, V);
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo;
V g_list_2ekeepIf_24s1814523351x214817707(V);
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_clo;
V g_list_2ekeepIf_24s1814523351x214817707_24dps(V, V);
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2ekeepIf_24s304198972x561714839_24dps(V, V, V);
V g_list_2ekeepIf_24s304198972x561714839_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_24dps_clo;
V g_list_2ekeepIf_24s614579978x208602650_24dps(V, V, V);
V g_list_2ekeepIf_24s614579978x208602650_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1832335087x1608171547_24dps(V, V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_24dps_clo;
V g_list_2emap_24f230958709x841260712(V, V, V, V, V, V);
V g_list_2emap_24f230958709x841260712_entry(V self, V *a);
extern Clo g_list_2emap_24f230958709x841260712_clo;
V g_list_2emap_24f230958709x841260712_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f230958709x841260712_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f230958709x841260712_24dps_clo;
V g_list_2emap_24f530523215x314966509(V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_clo;
V g_list_2emap_24f530523215x314966509_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_24dps_clo;
V g_list_2emap_24s1215346472x331828322(V);
V g_list_2emap_24s1215346472x331828322_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_clo;
V g_list_2emap_24s1215346472x331828322_24dps(V, V);
V g_list_2emap_24s1215346472x331828322_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s1561756891x1126436879_24dps(V, V);
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_24dps_clo;
V g_list_2emap_24s170737852x2114895588(V, V, V);
V g_list_2emap_24s170737852x2114895588_entry(V self, V *a);
extern Clo g_list_2emap_24s170737852x2114895588_clo;
V g_list_2emap_24s170737852x2114895588_24dps(V, V, V, V);
V g_list_2emap_24s170737852x2114895588_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s170737852x2114895588_24dps_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1936967306x1304226505_24dps(V, V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_24dps_clo;
V g_list_2emap_24s1960706388x853997965_24dps(V, V);
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_24dps_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2090270526x1588636862_24dps(V, V);
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_24dps_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2emap_24s763976875x1978337183_24dps(V, V);
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_24dps_clo;
V g_list_2emap_24s878634257x1677201747_24dps(V, V);
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_24dps_clo;
V g_list_2emap_24s930532762x1764747629_24dps(V, V, V);
V g_list_2emap_24s930532762x1764747629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s930532762x1764747629_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emergeRuns_24s111750985x43270407(V, V);
V g_list_2emergeRuns_24s111750985x43270407_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s111750985x43270407_clo;
V g_list_2epushRun_24s1176929257x15617969(V, V, V);
V g_list_2epushRun_24s1176929257x15617969_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1176929257x15617969_clo;
V g_list_2epushRun_24s1839415905x1299165467(V, V, V, V, V);
V g_list_2epushRun_24s1839415905x1299165467_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1839415905x1299165467_clo;
V g_list_2ezipWith_24s1448987994x473765958_24dps(V, V, V);
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo;
V g_list_2ezipWith_24s1680834068x1673006787(V, V);
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1713677103x1107896282_24dps(V, V, V);
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo;
V g_list_2ezipWith_24s270223073x952913921(V, V);
V g_list_2ezipWith_24s270223073x952913921_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s270223073x952913921_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1764298183x420715364_24cpr(V, V, V);
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  HeffT3 v_t_242 = (g_list_2edrop_24cpr(v_n_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, v_field_245});
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nil);
    }
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2edrop(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s878634257x1677201747_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_24dps_entry, 2, 0};

V g_list_2emap_24s878634257x1677201747_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s935688233x1434116625_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s935688233x1434116625_entry, 2, 0};

V g_list_2eany_24s935688233x1434116625(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s935688233x1434116625_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s935688233x1434116625(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str0, 1, "_");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str10, 7, "Float64");
HEFF_LIT(g_list_2emap_24s2090270526x1588636862_24dps_str11, 3, "Int");
Clo g_list_2emap_24s2090270526x1588636862_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2090270526x1588636862_24dps_entry, 2, 0};

V g_list_2emap_24s2090270526x1588636862_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str10);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = ((V)&g_list_2emap_24s2090270526x1588636862_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2090270526x1588636862_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2090270526x1588636862_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_entry, 2, 0};

V g_list_2ezipWith_24s1713677103x1107896282(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      if (heff_intLt_c(v_x_242, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_244)) {
        case TAG_FtFloat: {
          v_t_248 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_246 = heff_field(v_y_244, 0);
          V v_ru_24y_244_24FtFixed = heff_take_reuse_n(v_y_244, 1ULL, 1);
          int64_t v_t_247;
          switch (heff_tag_of(v_w_246)) {
          case TAG_I8: {
            v_t_247 = ((int64_t)8ULL);
            break;
          }
          case TAG_I16: {
            v_t_247 = ((int64_t)16ULL);
            break;
          }
          case TAG_I32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          case TAG_I64: {
            v_t_247 = ((int64_t)64ULL);
            break;
          }
          case TAG_U8: {
            v_t_247 = ((int64_t)8ULL);
            break;
          }
          case TAG_U16: {
            v_t_247 = ((int64_t)16ULL);
            break;
          }
          case TAG_U32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          case TAG_U64: {
            v_t_247 = ((int64_t)64ULL);
            break;
          }
          case TAG_F32: {
            v_t_247 = ((int64_t)32ULL);
            break;
          }
          default: heff_nomatch(v_w_246);
          }
          if ((v_t_247 == ((int64_t)64ULL))) {
            v_t_248 = heff_tag_at_n(v_ru_24y_244_24FtFixed, TAG_RepFix, 1, (V[]){v_w_246});
          } else {
            heff_drop(v_w_246);
            heff_drop_cell(v_ru_24y_244_24FtFixed, 1);
            v_t_248 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_248 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_248 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_244);
        }
      } else {
        heff_drop(v_y_244);
        v_t_248 = NTAG(TAG_RepV);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1713677103x1107896282_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1713677103x1107896282_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1713677103x1107896282_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1713677103x1107896282_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      if (heff_intLt_c(v_x_243, MK_INT(16LL))) {
        switch (heff_tag_of(v_y_245)) {
        case TAG_FtFloat: {
          v_t_249 = NTAG(TAG_RepF64);
          break;
        }
        case TAG_FtFixed: {
          V v_w_247 = heff_field(v_y_245, 0);
          V v_ru_24y_245_24FtFixed = heff_take_reuse_n(v_y_245, 1ULL, 1);
          int64_t v_t_248;
          switch (heff_tag_of(v_w_247)) {
          case TAG_I8: {
            v_t_248 = ((int64_t)8ULL);
            break;
          }
          case TAG_I16: {
            v_t_248 = ((int64_t)16ULL);
            break;
          }
          case TAG_I32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          case TAG_I64: {
            v_t_248 = ((int64_t)64ULL);
            break;
          }
          case TAG_U8: {
            v_t_248 = ((int64_t)8ULL);
            break;
          }
          case TAG_U16: {
            v_t_248 = ((int64_t)16ULL);
            break;
          }
          case TAG_U32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          case TAG_U64: {
            v_t_248 = ((int64_t)64ULL);
            break;
          }
          case TAG_F32: {
            v_t_248 = ((int64_t)32ULL);
            break;
          }
          default: heff_nomatch(v_w_247);
          }
          if ((v_t_248 == ((int64_t)64ULL))) {
            v_t_249 = heff_tag_at_n(v_ru_24y_245_24FtFixed, TAG_RepFix, 1, (V[]){v_w_247});
          } else {
            heff_drop(v_w_247);
            heff_drop_cell(v_ru_24y_245_24FtFixed, 1);
            v_t_249 = NTAG(TAG_RepV);
          }
          break;
        }
        case TAG_FtOther: {
          v_t_249 = NTAG(TAG_RepV);
          break;
        }
        case TAG_FtAny: {
          v_t_249 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_y_245);
        }
      } else {
        heff_drop(v_y_245);
        v_t_249 = NTAG(TAG_RepV);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2410;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1713677103x1107896282_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1713677103x1107896282_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2096135476x728523350_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2096135476x728523350_entry, 2, 0};

V g_list_2efoldl_24s2096135476x728523350(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2096135476x728523350(a[0], a[1]);
}
V g_list_2efoldl_24s1083429683x1325725555_lam0(V self, V *args);
Clo g_list_2efoldl_24s1083429683x1325725555_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1083429683x1325725555_entry, 2, 0};

V g_list_2efoldl_24s1083429683x1325725555(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_seen_246 = heff_dup(v_z_240);
    V v_key_247 = heff_dup(v_key_244);
    V v_b_248 = v_body_245;
    V v_b_249 = heff_dup(v_b_248);
    V v_t_2449;
    switch (heff_tag_of(v_b_249)) {
    case TAG_EVar: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_b_249, 0);
      heff_take_n(v_b_249, 1ULL, 2);
      v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_b_249, 0ULL, 3);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_b_249, 0ULL, 4);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_b_249, 0ULL, 3);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EAbandon: {
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_b_249, 0ULL, 3);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_b_249, 0ULL, 1);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_b_249, 0ULL, 2);
      v_t_2449 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_b_249);
    }
    V v_t_2459;
    if (heff_intEq_c(v_t_2449, MK_INT(0LL))) {
      V v_t_2450 = (g_heff_2ecompile_2eir_2eisValue(v_b_248));
      if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
        heff_drop(v_t_2450);
        V v_t_2451 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_248));
        V v_t_2452 = (g_heff_2ecompile_2eir_2enubI(v_t_2451));
        V v_x1_2458 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s1083429683x1325725555_lam0, 1, 2, (V[]){v_key_247, v_seen_246}); V a_1 = v_t_2452; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2452); r_; });
        v_t_2459 = heff_bool(!(heff_dup(v_x1_2458) == NTAG(TAG_True)));
        heff_drop(v_x1_2458);
      } else {
        heff_drop(v_seen_246);
        heff_drop(v_key_247);
        heff_drop(v_b_248);
        heff_drop(v_t_2450);
        v_t_2459 = NTAG(TAG_True);
      }
    } else {
      heff_drop(v_seen_246);
      heff_drop(v_key_247);
      heff_drop(v_b_248);
      v_t_2459 = NTAG(TAG_False);
    }
    V v_t_2460 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_key_244, v_t_2459));
    V t_0 = v_t_2460;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1083429683x1325725555_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1083429683x1325725555(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1083429683x1325725555_lam0(V self, V *args) {
  V v_k_2453 = args[0];
  V v_key_247 = heff_env(self)[0];
  V v_seen_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (!heff_strEq_c_lent(v_k_2453, v_key_247, 0)) {
    heff_drop(v_key_247);
    HeffT2 v_t_2454 = ({ V a_0 = v_seen_246; V a_1 = v_k_2453; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_seen_246); heff_drop(v_k_2453); r_; });
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_lz_2457 = v_field_2456;
        V v_ret_24bool = heff_bool(!(heff_dup(v_lz_2457) == NTAG(TAG_True)));
        heff_drop(v_lz_2457);
        return v_ret_24bool;
      } else {
        heff_drop(v_field_2456);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop(v_k_2453);
    heff_drop(v_key_247);
    heff_drop(v_seen_246);
    return NTAG(TAG_False);
  }
}
Clo g_list_2efoldl_24s1738438673x24732785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1738438673x24732785_entry, 2, 0};

V g_list_2efoldl_24s1738438673x24732785(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), NTAG(TAG_Nil)});
    V v_t_245 = (g_heff_2ecompile_2efacts_2esureRecW(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1738438673x24732785(a[0], a[1]);
}
Clo g_list_2efoldl_24s1766906699x9526323_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1766906699x9526323_entry, 2, 0};

V g_list_2efoldl_24s1766906699x9526323(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_s_244 = v_z_240;
    V v_o_245 = v_x_242;
    V v_t_2432;
    switch (heff_tag_of(v_o_245)) {
    case TAG_OutTag: {
      V v_t_246 = heff_field(v_o_245, 0);
      V v_ts_247 = heff_field(v_o_245, 1);
      heff_take_n(v_o_245, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      switch (heff_tag_of(v_s_244)) {
      case TAG_NoShape: {
        V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), v_t_246, v_ts_247));
        v_t_2432 = heff_tag_n(TAG_TagShape, 1, (V[]){v_t_248});
        break;
      }
      case TAG_RecordShape: {
        heff_take_n(v_s_244, 0ULL, 2);
        heff_drop(v_t_246);
        heff_drop(v_ts_247);
        v_t_2432 = NTAG(TAG_BadShape);
        break;
      }
      case TAG_TagShape: {
        V v_m_2411 = heff_field(v_s_244, 0);
        V v_ru_24s_244_24TagShape = heff_take_reuse_n(v_s_244, 1ULL, 1);
        V v_m_2412 = heff_dup(v_m_2411);
        V v_t_2413 = heff_dup(v_t_246);
        V v_ts_2414 = v_ts_247;
        HeffT2 v_t_2415 = ({ V a_0 = v_m_2411; V a_1 = v_t_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_2411); heff_drop(v_t_246); r_; });
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_ts0_2418 = v_field_2417;
            V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts0_2418));
            V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2414));
            if (heff_intEq_c(v_t_2419, v_t_2420)) {
              V v_t_2421 = (g_list_2ezipWith_24s270223073x952913921(v_ts0_2418, v_ts_2414));
              V v_t_2422 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2412, v_t_2413, v_t_2421));
              v_t_2432 = heff_tag_at_n(v_ru_24s_244_24TagShape, TAG_TagShape, 1, (V[]){v_t_2422});
            } else {
              heff_drop_cell(v_ru_24s_244_24TagShape, 1);
              heff_drop(v_m_2412);
              heff_drop(v_t_2413);
              heff_drop(v_ts_2414);
              heff_drop(v_ts0_2418);
              v_t_2432 = NTAG(TAG_BadShape);
            }
          } else {
            heff_drop(v_field_2417);
            V v_t_2423 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2412, v_t_2413, v_ts_2414));
            v_t_2432 = heff_tag_at_n(v_ru_24s_244_24TagShape, TAG_TagShape, 1, (V[]){v_t_2423});
          }
        }
        break;
      }
      case TAG_BadShape: {
        heff_drop(v_t_246);
        heff_drop(v_ts_247);
        v_t_2432 = NTAG(TAG_BadShape);
        break;
      }
      default: heff_nomatch(v_s_244);
      }
      break;
    }
    case TAG_OutRecord: {
      V v_o1_2424 = heff_field(v_o_245, 0);
      V v_o2_2425 = heff_field(v_o_245, 1);
      heff_take_n(v_o_245, 3ULL, 2);
      switch (heff_tag_of(v_s_244)) {
      case TAG_NoShape: {
        v_t_2432 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RecordShape, 2, (V[]){v_o1_2424, v_o2_2425});
        break;
      }
      case TAG_RecordShape: {
        V v_ls_2426 = heff_field(v_s_244, 0);
        V v_ts_2427 = heff_field(v_s_244, 1);
        heff_take_n(v_s_244, 3ULL, 2);
        V v_t_2428 = ({ V a_0 = v_ls_2426; V a_1 = v_o1_2424; V r_ = (g_heff_2ecompile_2ecpr_2esameLabels(a_0, a_1)); heff_drop(v_o1_2424); r_; });
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop(v_t_2428);
          V v_t_2429 = (g_list_2ezipWith_24s1680834068x1673006787(v_ts_2427, v_o2_2425));
          v_t_2432 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RecordShape, 2, (V[]){v_ls_2426, v_t_2429});
        } else {
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_o2_2425);
          heff_drop(v_ls_2426);
          heff_drop(v_ts_2427);
          heff_drop(v_t_2428);
          v_t_2432 = NTAG(TAG_BadShape);
        }
        break;
      }
      case TAG_TagShape: {
        heff_take_n(v_s_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_o1_2424);
        heff_drop(v_o2_2425);
        v_t_2432 = NTAG(TAG_BadShape);
        break;
      }
      case TAG_BadShape: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_o1_2424);
        heff_drop(v_o2_2425);
        v_t_2432 = NTAG(TAG_BadShape);
        break;
      }
      default: heff_nomatch(v_s_244);
      }
      break;
    }
    case TAG_OutCall: {
      heff_take_n(v_o_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2432 = v_s_244;
      break;
    }
    case TAG_OutOther: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_s_244);
      v_t_2432 = NTAG(TAG_BadShape);
      break;
    }
    default: heff_nomatch(v_o_245);
    }
    V t_0 = v_t_2432;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1766906699x9526323(a[0], a[1]);
}
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam0(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam1(V self, V *args);
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam2(V self, V *args);
Clo g_list_2ekeepIf_24s614579978x208602650_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s614579978x208602650_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s614579978x208602650_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_bodies_245 = heff_dup(v_lit_240);
    V v_ks_246 = heff_dup(v_x_243);
    V v_t_2415 = (g_list_2eany(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_24dps_lam0, 1, 1, (V[]){heff_dup(v_bodies_245)}), v_ks_246));
    if (((heff_dup(v_t_2415) == NTAG(TAG_True)) && ({ V v_t_2416 = (g_list_2efoldl_24s278088687x1269971185(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_246)); int c_ = ({ V v_t_2422 = (g_list_2emap(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_24dps_lam1, 1, 1, (V[]){heff_dup(v_bodies_245)}), heff_dup(v_ks_246))); int c_ = ({ V v_c_2434 = heff_tr(g_heff_2ecompile_2edefun_2ehandsW(heff_dup(v_t_2416), heff_dup(v_t_2422))); int c_ = ((heff_dup(v_c_2434) == NTAG(TAG_True)) && ({ V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_list_2ekeepIf_24s614579978x208602650_24dps_lam2, 2, 1, (V[]){heff_dup(v_bodies_245)}), MK_INT(0LL), v_ks_246)); int c_ = heff_intLe_c_lent(v_t_2435, MK_INT(20000LL), 2); heff_drop(v_t_2435); c_; })); heff_drop(v_c_2434); c_; }); heff_drop(v_t_2422); c_; }); heff_drop(v_t_2416); c_; }))) {
      heff_drop(v_bodies_245);
      heff_drop(v_ks_246);
      heff_drop(v_t_2415);
      V v_cell_2432 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2433 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2432));
      heff_drop(v_u_2433);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2432;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_bodies_245);
      heff_drop(v_ks_246);
      heff_drop(v_t_2415);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s614579978x208602650_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s614579978x208602650_24dps(a[0], a[1], a[2]);
}
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_bodies_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_bodies_245; V a_1 = v_k_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_245); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2412;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = NTAG(TAG_EAbandon);
    }
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_2412));
    V v_xs_2414 = (g_heff_2ecompile_2eir_2enubI(v_t_2413));
    return ({ V a_0 = v_k_247; V a_1 = v_xs_2414; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_247); heff_drop(v_xs_2414); r_; });
  }
}
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam1(V self, V *args) {
  V v_k_2417 = args[0];
  V v_bodies_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2418 = ({ V a_0 = v_bodies_245; V a_1 = v_k_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_245); heff_drop(v_k_2417); r_; });
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2420;
      return v_x_2421;
    } else {
      heff_drop(v_field_2420);
      return NTAG(TAG_EAbandon);
    }
  }
}
V g_list_2ekeepIf_24s614579978x208602650_24dps_lam2(V self, V *args) {
  V v_n_2423 = args[0];
  V v_k_2424 = args[1];
  V v_bodies_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2425 = ({ V a_0 = v_bodies_245; V a_1 = v_k_2424; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_245); heff_drop(v_k_2424); r_; });
  V v_t_2431;
  {
    V v_field_2427 = v_t_2425.f[1];
    int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
    V v_t_2429;
    if ((v_tag_2426 == ((int64_t)0ULL))) {
      V v_x_2428 = v_field_2427;
      v_t_2429 = v_x_2428;
    } else {
      heff_drop(v_field_2427);
      v_t_2429 = NTAG(TAG_EAbandon);
    }
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    v_t_2431 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2430));
  }
  return heff_intAdd(v_n_2423, v_t_2431);
}
HEFF_LIT(g_list_2efoldl_24s1780126197x1319226274_str0, 0, "");
V g_list_2efoldl_24s1780126197x1319226274_lam0(V self, V *args);
V g_list_2efoldl_24s1780126197x1319226274_lam1(V self, V *args);
Clo g_list_2efoldl_24s1780126197x1319226274_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1780126197x1319226274_entry, 2, 0};

V g_list_2efoldl_24s1780126197x1319226274(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_d_244 = v_z_240;
    V v_g_245 = v_x_242;
    V v_ps_2412 = (g_list_2emap_24tok2(v_ru_24x3_241_24Cons, heff_clo_n(g_list_2efoldl_24s1780126197x1319226274_lam0, 1, 1, (V[]){heff_dup(v_d_244)}), heff_dup(heff_rfield(v_g_245, 0))));
    V v_t_2413 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2412; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2412); r_; });
    V v_t_2414 = heff_rec_n(3, shape_bodies__grown__supply, (V[]){v_t_2413, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_d_244, 2))});
    HeffT2 v_t_2415 = (g_heff_2ecompile_2edefun_2egrow_24cpr(heff_dup(v_g_245), MK_INT(6LL), v_t_2414));
    V v_t_2458;
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_gr_2418 = v_field_2417;
        HeffT2 v_t_2419 = (g_heff_2ecompile_2edefun_2eanalyse_24cpr(NTAG(TAG_True), heff_dup(v_g_245), heff_dup(heff_rfield(v_gr_2418, 0))));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_s_2422 = v_field_2421;
            V v_d_2423 = v_d_244;
            V v_g_2424 = heff_dup(v_g_245);
            V v_gr_2425 = heff_dup(v_gr_2418);
            V v_bodies_2426 = heff_take_field(v_gr_2425, 0);
            V v_supply_2427 = heff_get_n(v_gr_2425, 2, 3);
            HeffT2 v_t_2428 = ({ V a_0 = v_g_245; V b_1 = heff_take_field(v_gr_2418, 1); V b_2 = heff_get_n(v_gr_2418, 0, 3); V a_3 = v_s_2422; HeffT2 r_ = (g_heff_2ecompile_2edefun_2eplanOf_24cpr(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); r_; });
            {
              V v_field_2430 = v_t_2428.f[1];
              int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
              if ((v_tag_2429 == ((int64_t)0ULL))) {
                V v_p_2431 = v_field_2430;
                V v_ps_2432 = ({ V a_0 = v_bodies_2426; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_bodies_2426); r_; });
                V v_t_2433 = ({ V a_0 = heff_take_field(v_d_2423, 0); V a_1 = v_ps_2432; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2432); r_; });
                V v_d_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_d_2423, 6ULL, 3, shape_bodies__after__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                V v_bodies_2435 = heff_take_field(v_d_2434, 0);
                V v_after_2436 = heff_get_n(v_d_2434, 1, 3);
                V v_g_2437 = v_g_2424;
                V v_p_2438 = heff_dup(v_p_2431);
                HeffT2 v_t_2439 = (g_prelude_2etraverse_24s1764298183x420715364_24cpr(heff_dup(v_p_2431), heff_get_n(v_p_2431, 2, 4), v_supply_2427));
                {
                  V v_field_2440 = v_t_2439.f[0];
                  V v_field_2441 = v_t_2439.f[1];
                  V v_ads_2442 = v_field_2440;
                  V v_n_2443 = v_field_2441;
                  V v_t_2452 = (g_list_2efoldl(heff_clo_n(g_list_2efoldl_24s1780126197x1319226274_lam1, 2, 1, (V[]){v_p_2438}), v_bodies_2435, heff_rfield(v_g_2437, 0)));
                  V v_x1_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_g_2437, 0, 3)));
                  V v_t_2456;
                  switch (heff_tag_of(v_x1_2453)) {
                  case TAG_Nil: {
                    v_t_2456 = ((V)&g_list_2efoldl_24s1780126197x1319226274_str0);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_2454 = heff_field(v_x1_2453, 0);
                    heff_take_n(v_x1_2453, 1ULL, 2);
                    v_t_2456 = v_x_2454;
                    break;
                  }
                  default: heff_nomatch(v_x1_2453);
                  }
                  V v_t_2457 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_after_2436, v_t_2456, v_ads_2442));
                  v_t_2458 = heff_rec_n(3, shape_bodies__after__supply, (V[]){v_t_2452, v_t_2457, v_n_2443});
                }
              } else {
                heff_drop(v_g_2424);
                heff_drop(v_bodies_2426);
                heff_drop(v_supply_2427);
                heff_drop(v_field_2430);
                v_t_2458 = v_d_2423;
              }
            }
          } else {
            heff_drop_rec(v_g_245, 3);
            heff_drop_rec(v_gr_2418, 3);
            heff_drop(v_field_2421);
            v_t_2458 = v_d_244;
          }
        }
      } else {
        heff_drop_rec(v_g_245, 3);
        heff_drop(v_field_2417);
        v_t_2458 = v_d_244;
      }
    }
    V t_0 = v_t_2458;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1780126197x1319226274_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1780126197x1319226274(a[0], a[1]);
}
V g_list_2efoldl_24s1780126197x1319226274_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_d_244, 0, 3); V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2411;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = NTAG(TAG_EAbandon);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, v_t_2411});
}
V g_list_2efoldl_24s1780126197x1319226274_lam1(V self, V *args) {
  V v_m_2444 = args[0];
  V v_k_2445 = args[1];
  V v_p_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2446 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_2444, v_k_2445));
  V v_t_2450;
  {
    V v_field_2448 = v_t_2446.f[1];
    int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
    if ((v_tag_2447 == ((int64_t)0ULL))) {
      V v_x_2449 = v_field_2448;
      v_t_2450 = v_x_2449;
    } else {
      heff_drop(v_field_2448);
      v_t_2450 = NTAG(TAG_EAbandon);
    }
  }
  V v_t_2451 = (g_heff_2ecompile_2edefun_2erw(v_p_2438, v_t_2450));
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2444, v_k_2445, v_t_2451));
}
Clo g_list_2emap_24s170737852x2114895588_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s170737852x2114895588_entry, 3, 0};

V g_list_2emap_24s170737852x2114895588(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 6);
    V v_t_246 = heff_tr(heff_call(v_t_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_247 = heff_get_n(heff_get_n(v_x_243, 0, 3), 1, 6);
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_lit_240)), v_t_247);
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, heff_dup(v_lit_241)), heff_hole()});
    V v_u_2410 = (g_list_2emap_24s170737852x2114895588_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s170737852x2114895588_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s170737852x2114895588(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s1562730082x1519471820_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1562730082x1519471820_entry, 1, 0};

V g_list_2eall_24s1562730082x1519471820(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EBytes: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1562730082x1519471820_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1562730082x1519471820(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s1448987994x473765958_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1448987994x473765958_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1448987994x473765958_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      case TAG_RepInt: {
        heff_drop(v_y_245);
        v_t_248 = v_x_243;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1448987994x473765958_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1448987994x473765958_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1985010810x1780722131_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_entry, 4, 0};

V g_list_2emap_24s1985010810x1780722131(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1985010810x1780722131_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s509733942x1507005169_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s509733942x1507005169_entry, 4, 0};

V g_list_2efoldl_24s509733942x1507005169(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_244), heff_dup(v_lit_240)));
    V v_t_247 = (g_heff_2ecompile_2eemit_2esafe(v_t_246));
    HeffT2 v_t_248 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(heff_take_field(v_z_242, 1), v_x_244, v_t_247, heff_dup(v_lit_241)));
    V v_t_2413;
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_t_2411 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_field_249, NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_get_n(v_z_242, 0, 2), v_t_2411));
      v_t_2413 = heff_rec_n(2, shape_js__env, (V[]){v_t_2412, v_field_2410});
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s509733942x1507005169_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s509733942x1507005169(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str1, 4, "  V ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str2, 2, "v_");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str3, 11, "heff_field(");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str4, 2, ", ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str5, 1, ")");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str6, 20, "heff_dup(heff_field(");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str7, 2, ", ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str8, 2, "))");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str9, 3, " = ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_24dps_str10, 1, ";");
Clo g_list_2emap_24s1518131677x2038133191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_24dps_entry, 4, 0};

V g_list_2emap_24s1518131677x2038133191_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_sv_246 = heff_dup(v_lit_240);
    V v_plain_247 = heff_dup(v_lit_241);
    V v_x3_248 = v_x_244;
    V v_t_2419;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_MkPair: {
      V v_v_249 = heff_field(v_x3_248, 0);
      V v_i_2410 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_v_249; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_v_249); r_; });
      V v_t_2412 = heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_24dps_str1), heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_24dps_str2), v_t_2411));
      V v_t_2417;
      if ((heff_dup(v_plain_247) == NTAG(TAG_True))) {
        heff_drop(v_plain_247);
        V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_24dps_str3), v_sv_246), ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str4));
        V v_t_2414 = heff_strAppend(v_t_2413, heff_intShow(v_i_2410));
        v_t_2417 = heff_strAppend(v_t_2414, ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str5));
      } else {
        heff_drop(v_plain_247);
        V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_24dps_str6), v_sv_246), ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str7));
        V v_t_2416 = heff_strAppend(v_t_2415, heff_intShow(v_i_2410));
        v_t_2417 = heff_strAppend(v_t_2416, ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str8));
      }
      V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str9)), v_t_2417);
      v_t_2419 = heff_strAppend(v_t_2418, ((V)&g_list_2emap_24s1518131677x2038133191_24dps_str10));
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2420;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1518131677x2038133191_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str0, 2, "  ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str1, 1, " ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str3, 2, "v_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str4, 13, " = heff_tget_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str5, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str6, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str7, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str8, 13, " = heff_tget_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str9, 1, "v");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str10, 3, "f64");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str11, 4, "word");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str12, 1, "(");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str13, 2, ", ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_str14, 2, ");");
Clo g_list_2emap_24s1936967306x1304226505_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936967306x1304226505_entry, 4, 0};

V g_list_2emap_24s1936967306x1304226505(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_k_246 = heff_dup(v_lit_240);
    V v_sv_247 = heff_dup(v_lit_241);
    V v_sure_248 = heff_dup(v_lit_242);
    V v_x4_249 = v_x_244;
    V v_t_2426;
    switch (heff_tag_of(v_x4_249)) {
    case TAG_MkPair: {
      V v_v_2410 = heff_field(v_x4_249, 0);
      V v_x42_2411 = heff_field(v_x4_249, 1);
      heff_take_n(v_x4_249, 3ULL, 2);
      switch (heff_tag_of(v_x42_2411)) {
      case TAG_MkPair: {
        V v_i_2412 = heff_field(v_x42_2411, 0);
        V v_r_2413 = heff_field(v_x42_2411, 1);
        heff_take_n(v_x42_2411, 3ULL, 2);
        V v_t_2414 = heff_tr(heff_call(heff_get_n(v_k_246, 2, 6), 1, (V[]){heff_dup(v_v_2410)}));
        V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1936967306x1304226505_str0), v_t_2414), ((V)&g_list_2emap_24s1936967306x1304226505_str1));
        V v_t_2416 = ({ V a_0 = v_v_2410; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s1936967306x1304226505_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_v_2410); r_; });
        V v_t_2417 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_list_2emap_24s1936967306x1304226505_str3), v_t_2416));
        V v_t_2418 = ({ V a_0 = heff_dup(v_i_2412); V a_1 = v_sure_248; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_sure_248); r_; });
        V v_t_2420;
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_t_2418);
          switch (heff_tag_of(v_r_2413)) {
          case TAG_RepV: {
            v_t_2420 = ((V)&g_list_2emap_24s1936967306x1304226505_str4);
            break;
          }
          case TAG_RepFix: {
            v_t_2420 = ((V)&g_list_2emap_24s1936967306x1304226505_str5);
            break;
          }
          case TAG_RepF64: {
            v_t_2420 = ((V)&g_list_2emap_24s1936967306x1304226505_str6);
            break;
          }
          case TAG_RepInt: {
            v_t_2420 = ((V)&g_list_2emap_24s1936967306x1304226505_str7);
            break;
          }
          default: heff_nomatch(v_r_2413);
          }
        } else {
          heff_drop(v_t_2418);
          v_t_2420 = ((V)&g_list_2emap_24s1936967306x1304226505_str8);
        }
        V v_t_2422;
        switch (heff_tag_of(v_r_2413)) {
        case TAG_RepV: {
          v_t_2422 = ((V)&g_list_2emap_24s1936967306x1304226505_str9);
          break;
        }
        case TAG_RepFix: {
          V v_w_2421 = heff_field(v_r_2413, 0);
          heff_take_n(v_r_2413, 1ULL, 1);
          v_t_2422 = ({ V a_0 = v_w_2421; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_2421); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2422 = ((V)&g_list_2emap_24s1936967306x1304226505_str10);
          break;
        }
        case TAG_RepInt: {
          v_t_2422 = ((V)&g_list_2emap_24s1936967306x1304226505_str11);
          break;
        }
        default: heff_nomatch(v_r_2413);
        }
        V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2417, v_t_2420), v_t_2422);
        V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_list_2emap_24s1936967306x1304226505_str12)), v_sv_247);
        V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_list_2emap_24s1936967306x1304226505_str13)), heff_intShow(v_i_2412));
        v_t_2426 = heff_strAppend(v_t_2425, ((V)&g_list_2emap_24s1936967306x1304226505_str14));
        break;
      }
      default: heff_nomatch(v_x42_2411);
      }
      break;
    }
    default: heff_nomatch(v_x4_249);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = (g_list_2emap_24s1936967306x1304226505_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2427)));
    heff_drop(v_u_2428);
    return v_cell_2427;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1936967306x1304226505(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str0, 6, "double");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str1, 4, "bool");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str2, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str3, 12, "const char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str4, 6, "char *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str5, 2, " *");
HEFF_LIT(g_list_2emap_24s1215346472x331828322_str6, 4, "void");
Clo g_list_2emap_24s1215346472x331828322_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1215346472x331828322_entry, 1, 0};

V g_list_2emap_24s1215346472x331828322(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_246 = v_t_243;
      break;
    }
    case TAG_CDouble: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str0);
      break;
    }
    case TAG_CBool: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str1);
      break;
    }
    case TAG_CString: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str2);
      break;
    }
    case TAG_CText: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_244 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_246 = heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1215346472x331828322_str5));
      break;
    }
    case TAG_CVoid: {
      v_t_246 = ((V)&g_list_2emap_24s1215346472x331828322_str6);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1215346472x331828322_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1215346472x331828322_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1215346472x331828322(a[0]);
}
Clo g_list_2eany_24s1606644238x788321190_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1606644238x788321190_entry, 2, 0};

V g_list_2eany_24s1606644238x788321190(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1606644238x788321190(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1814523351x214817707_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1814523351x214817707_entry, 1, 0};

V g_list_2ekeepIf_24s1814523351x214817707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(v_t_245); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_246) == NTAG(TAG_True))) {
      heff_drop(v_a_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1814523351x214817707_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1814523351x214817707(a[0]);
}
Clo g_list_2emap_24s1960706388x853997965_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1960706388x853997965_24dps_entry, 2, 0};

V g_list_2emap_24s1960706388x853997965_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1960706388x853997965_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2efoldl_24s1261443129x1682844402_str0, 1, "#");
HEFF_LIT(g_list_2efoldl_24s1261443129x1682844402_str1, 2, "#T");
V g_list_2efoldl_24s1261443129x1682844402_lam0(V self, V *args);
Clo g_list_2efoldl_24s1261443129x1682844402_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1261443129x1682844402_entry, 2, 0};

V g_list_2efoldl_24s1261443129x1682844402(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_c_244 = heff_dup(v_x_242);
    V v_g_245 = v_z_240;
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_c_244, 0)), ((V)&g_list_2efoldl_24s1261443129x1682844402_str0));
    V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_c_244, 0)), ((V)&g_list_2efoldl_24s1261443129x1682844402_str1));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_244, 5)), 0, 10);
    V v_t_249 = ({ V b_0 = heff_get_n(v_t_248, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2410 = (g_list_2emap_24s1415906091x1371825187(v_t_249));
    V v_t_2411 = ({ V a_0 = v_g_245; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1513798766x1460159176(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2414 = (g_list_2efoldl(heff_clo_n(g_list_2efoldl_24s1261443129x1682844402_lam0, 2, 1, (V[]){heff_dup(v_c_244)}), v_t_2411, heff_rfield(v_c_244, 7)));
    V v_t_2415 = (g_heff_2ebuild_2edriver_2ewithEntry(v_t_247, heff_dup(v_c_244), v_t_2414));
    V v_t_2416 = (g_heff_2ebuild_2edriver_2ewithEntry(v_t_246, v_c_244, v_t_2415));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1261443129x1682844402(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1261443129x1682844402_lam0(V self, V *args) {
  V v_g2_2412 = args[0];
  V v_o_2413 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2ewithEntry(heff_get_n(v_o_2413, 1, 2), v_c_244, v_g2_2412));
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_24dps_str0, 0, "");
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_24dps_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_24dps_entry, 2, 0};

V g_list_2emap_24s214260857x938990544_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_24dps_lam0_clo); V rr_ = heff_rec_reuse_nf(v_x_242, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544_24dps(a[0], a[1]);
}
V g_list_2emap_24s214260857x938990544_24dps_lam0(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return ((V)&g_list_2emap_24s214260857x938990544_24dps_str0);
}
Clo g_list_2efoldl_24s75764538x1218461500_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s75764538x1218461500_entry, 3, 0};

V g_list_2efoldl_24s75764538x1218461500(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_to_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_z_241;
    V v_b_247 = heff_dup(v_x_243);
    V v_t_2421;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      V v_t_2410;
      switch (heff_tag_of(v_b_247)) {
      case TAG_MkPair: {
        V v_y_249 = heff_dup(heff_field(v_b_247, 1));
        v_t_2410 = v_y_249;
        break;
      }
      default: heff_nomatch(v_b_247);
      }
      if (heff_intLe_c(v_to_245, heff_get_n(v_t_2410, 0, 2))) {
        v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){v_b_247});
      } else {
        heff_drop(v_b_247);
        v_t_2421 = NTAG(TAG_Nothing);
      }
      break;
    }
    case TAG_Just: {
      V v_a_2411 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24Just = heff_take_reuse_n(v_x2_246, 1ULL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_b_247)) {
      case TAG_MkPair: {
        V v_y_2413 = heff_dup(heff_field(v_b_247, 1));
        v_t_2414 = v_y_2413;
        break;
      }
      default: heff_nomatch(v_b_247);
      }
      V v_t_2424;
      if (heff_intLe_c(v_to_245, heff_get_n(v_t_2414, 0, 2))) {
        V v_t_2417;
        switch (heff_tag_of(v_b_247)) {
        case TAG_MkPair: {
          V v_y_2416 = heff_dup(heff_field(v_b_247, 1));
          v_t_2417 = v_y_2416;
          break;
        }
        default: heff_nomatch(v_b_247);
        }
        V v_t_2429 = heff_get_n(v_t_2417, 0, 2);
        V v_t_2420;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_MkPair: {
          V v_y_2419 = heff_dup(heff_field(v_a_2411, 1));
          v_t_2420 = v_y_2419;
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        V v_t_2430 = heff_get_n(v_t_2420, 0, 2);
        v_t_2424 = heff_intLt(v_t_2429, v_t_2430);
      } else {
        v_t_2424 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_a_2411);
        v_t_2421 = heff_tag_at_n(v_ru_24x2_246_24Just, TAG_Just, 1, (V[]){v_b_247});
        break;
      }
      case TAG_False: {
        heff_drop(v_b_247);
        v_t_2421 = heff_tag_at_n(v_ru_24x2_246_24Just, TAG_Just, 1, (V[]){v_a_2411});
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2421;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s75764538x1218461500(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_list_2epushRun_24s1839415905x1299165467_lam0(V self, V *args);
Clo g_list_2epushRun_24s1839415905x1299165467_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s1839415905x1299165467_entry, 5, 0};

V g_list_2epushRun_24s1839415905x1299165467(V v_lit_240, V v_lit_241, V v_k_242, V v_run_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_j_247 = heff_field(v_x41_245, 0);
      V v_below_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_247, v_k_242, 0)) {
        heff_drop_cell(v_ru_24x4_244_24Cons, 2);
        heff_drop(v_j_247);
        heff_drop_cell(v_ru_24x41_245_24MkPair, 2);
        V v_t_2413 = (g_list_2emerge(heff_clo_n(g_list_2epushRun_24s1839415905x1299165467_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_below_248, v_run_243));
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
        V t_3 = v_t_2413;
        V t_4 = v_rest_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_k_242 = t_2;
        v_run_243 = t_3;
        v_x4_244 = t_4;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        V v_t_2414 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_MkPair, 2, (V[]){v_j_247, v_below_248}), v_rest_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), v_t_2414});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2epushRun_24s1839415905x1299165467_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s1839415905x1299165467(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2epushRun_24s1839415905x1299165467_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_intSub(v_lit_240, heff_get_n(v_a_249, 0, 10));
  V v_t_2412 = heff_intSub(v_lit_241, heff_get_n(v_a_2410, 0, 10));
  V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_t_2411, v_t_2412, 0));
  heff_drop(v_t_2411);
  heff_drop(v_t_2412);
  return v_ret_24bool;
}
Clo g_list_2emap_24s930532762x1764747629_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s930532762x1764747629_24dps_entry, 3, 0};

V g_list_2emap_24s930532762x1764747629_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_245 = heff_take_field(v_x_243, 0);
    V v_looser_246 = heff_get_n(v_x_243, 1, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(v_tighter_245, heff_dup(v_lit_240)), v_looser_246);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_248;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s930532762x1764747629_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s930532762x1764747629_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_entry, 1, 0};

V g_list_2emap_24s1462590149x1582455373(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) - ((int64_t)3ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), heff_box_word(v_t_243), heff_strLength_lent(v_x_241, 0));
    V v_t_246;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1462590149x1582455373_str0))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) - ((int64_t)3ULL));
      v_t_246 = heff_strSlice(v_x_241, MK_INT(0LL), heff_box_word(v_t_245));
    } else {
      v_t_246 = v_x_241;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1462590149x1582455373_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373(a[0]);
}
Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1220809684x843195562_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1220809684x843195562_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1220809684x843195562_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emergeRuns_24s111750985x43270407_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s111750985x43270407_entry, 2, 0};

V g_list_2emergeRuns_24s111750985x43270407(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s945166865x820780714(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s1176929257x15617969(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2416;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2416 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 1, 2);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_x_244, 0)), 0, 2);
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_y_248, 0)), 1, 2);
        V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_y_248, 0)), 0, 2);
        if (heff_intLe_c(heff_intSub(v_t_2410, v_t_2411), heff_intSub(v_t_2412, v_t_2413))) {
          V v_t_2414 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2416 = (g_list_2eascending_24s1147438953x64854941(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2414}), v_ys_249));
        } else {
          V v_t_2415 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2416 = (g_list_2edescending_24s1092102222x1336838254(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2415}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2416;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s111750985x43270407_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s111750985x43270407(a[0], a[1]);
}
Clo g_list_2emap_24s1561756891x1126436879_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_24dps_entry, 2, 0};

V g_list_2emap_24s1561756891x1126436879_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2epatKey(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s763976875x1978337183_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s763976875x1978337183_entry, 1, 0};

V g_list_2emap_24s763976875x1978337183(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edocpages_2epage(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s763976875x1978337183_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s763976875x1978337183(a[0]);
}

HeffT2 g_list_2efind_24s1424316379x433407702_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_241), heff_dup(heff_rfield(v_x_246, 0)));
    V v_t_249 = heff_strFind(heff_strAppend(v_t_248, heff_dup(v_lit_242)), heff_dup(v_lit_243), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_240, v_t_249, 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_246)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_245)}});
  }
}
Clo g_list_2ekeepIf_24s304198972x561714839_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s304198972x561714839_entry, 2, 0};

V g_list_2ekeepIf_24s304198972x561714839(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s304198972x561714839_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s304198972x561714839(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eany_24s442143688x2133738513_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s442143688x2133738513_entry, 2, 0};

V g_list_2eany_24s442143688x2133738513(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 8);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_x_242))) {
      heff_drop_rec(v_lit_240, 8);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s442143688x2133738513_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s442143688x2133738513(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1645967390x252727070_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1645967390x252727070_entry, 2, 0};

V g_list_2efoldl_24f1645967390x252727070(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1645967390x252727070(a[0], a[1]);
}
Clo g_list_2emap_24f230958709x841260712_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f230958709x841260712_entry, 6, 0};

V g_list_2emap_24f230958709x841260712(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_p_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_244), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
      V v_t_2410 = heff_strAppend(v_t_249, heff_intShow(v_x_246));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, heff_dup(v_lit_243)), heff_hole()});
      V v_u_2412 = (g_list_2emap_24f230958709x841260712_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_p_244, v_xs_247, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_p_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_p_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f230958709x841260712_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f230958709x841260712(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f530523215x314966509_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f530523215x314966509_entry, 7, 0};

V g_list_2emap_24f530523215x314966509(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_target_249 = heff_take_field(v_x_247, 0);
    V v_name_2410 = heff_take_field(v_x_247, 1);
    V v_span_2411 = heff_get_n(v_x_247, 2, 3);
    V v_t_2412 = heff_get_n(v_target_249, 1, 3);
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_name_2410);
      heff_drop(v_span_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_2412, 0ULL, 1);
      V v_t_2414 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2415 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2414);
      V v_t_2416;
      if (heff_strEq_c_lent(v_t_2415, v_lit_243, 1)) {
        v_t_2416 = heff_dup(v_lit_244);
      } else {
        v_t_2416 = heff_dup(v_lit_245);
      }
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_name_2410, v_t_2416, v_span_2411}), heff_hole()});
      V v_u_2418 = (g_list_2emap_24f530523215x314966509_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f530523215x314966509_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24f530523215x314966509(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1832335087x1608171547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1832335087x1608171547_24dps_entry, 5, 0};

V g_list_2emap_24f1832335087x1608171547_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242))) {
      V v_t_248;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_240))) {
        V v_t_247 = heff_intAdd(heff_take_field(v_x_245, 3), heff_dup(v_lit_241));
        v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_x_245, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_248 = v_x_245;
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1832335087x1608171547_24dps(a[0], a[1], a[2], a[3], a[4]);
}