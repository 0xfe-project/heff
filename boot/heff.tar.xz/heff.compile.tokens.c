// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_byFun 295539138
#define LBL_cells 295903083
#define LBL_count 296209705
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_underLam 296337946
static uint32_t shape_byFun__cells[] = {LBL_byFun, LBL_cells};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2etokens_2earmSites(V, V);
V g_heff_2ecompile_2etokens_2earmSites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2earmSites_clo;
V g_heff_2ecompile_2etokens_2ebareCalls(V, V);
V g_heff_2ecompile_2etokens_2ebareCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebareCalls_clo;
V g_heff_2ecompile_2etokens_2ebuildsW(V, V);
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebuildsW_clo;
V g_heff_2ecompile_2etokens_2ecopiable(V, V, V);
V g_heff_2ecompile_2etokens_2ecopiable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ecopiable_clo;
V g_heff_2ecompile_2etokens_2ecopies(V, V, V);
V g_heff_2ecompile_2etokens_2ecopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ecopies_clo;
HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2etokens_2ecopyOf_24cpr(V, V, V);
V g_heff_2ecompile_2etokens_2egivesBack(V, V);
V g_heff_2ecompile_2etokens_2egivesBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2egivesBack_clo;
V g_heff_2ecompile_2etokens_2esitesW(V, V);
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2esitesW_clo;
HeffT3 g_heff_2ecompile_2etokens_2etokensProgram_24cpr(V, V, V);
V g_list_2eall_24s743242824x1965727204(V);
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a);
extern Clo g_list_2eall_24s743242824x1965727204_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s277053946x716662586(V, V);
V g_list_2eany_24s277053946x716662586_entry(V self, V *a);
extern Clo g_list_2eany_24s277053946x716662586_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1045503831x402406784(V, V, V);
V g_list_2efoldl_24s1045503831x402406784_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1045503831x402406784_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s740336339x1862813792(V, V);
V g_list_2efoldl_24s740336339x1862813792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s740336339x1862813792_clo;
V g_list_2efoldl_24s878937540x987476648(V, V);
V g_list_2efoldl_24s878937540x987476648_entry(V self, V *a);
extern Clo g_list_2efoldl_24s878937540x987476648_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2etokens_2ebuildsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ebuildsW_entry, 2, 0};

V g_heff_2ecompile_2etokens_2ebuildsW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_n_240;
      V t_1 = v_t_2414;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = v_t_2417;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_n_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_2422 = heff_field(v_x21_242, 0);
      V v_argv_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2423));
      if ((heff_intEq_c_lent(v_t_2425, v_n_240, 0) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2422, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2422, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1))) {
        heff_drop(v_n_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2422);
        heff_drop(v_argv_2423);
        heff_drop(v_t_2425);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2422);
        heff_drop(v_t_2425);
        V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2423, v_rest_243));
        V t_0 = v_n_240;
        V t_1 = v_t_2426;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EMatch: {
      V v_s_2427 = heff_field(v_x21_242, 0);
      V v_arms_2428 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2427, v_t_2429});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2432 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2432, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = v_t_2433;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2435 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2435, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = v_t_2436;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2444 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2445 = ({ V a_0 = v_c_2444; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2444); r_; });
      V t_0 = v_n_240;
      V t_1 = v_t_2445;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2447 = heff_field(v_x21_242, 1);
      V v_b_2448 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2449 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2448, v_rest_243})});
      V t_0 = v_n_240;
      V t_1 = v_t_2449;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2450 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2451 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2450, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = v_t_2451;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2ebuildsW(a[0], a[1]);
}
Clo g_heff_2ecompile_2etokens_2egivesBack_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2egivesBack_entry, 2, 0};

V g_heff_2ecompile_2etokens_2egivesBack(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_e_241, 0);
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242, 0));
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_argv_2424 = heff_field(v_e_241, 1);
    return (g_list_2eall_24s743242824x1965727204(v_argv_2424));
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etokens_2egivesBack_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2etokens_2egivesBack(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam0(V self, V *args);
V g_heff_2ecompile_2etokens_2ebareCalls_lam1(V self, V *args);
V g_heff_2ecompile_2etokens_2ebareCalls_lam2(V self, V *args);
Clo g_heff_2ecompile_2etokens_2ebareCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ebareCalls_entry, 2, 0};

V g_heff_2ecompile_2etokens_2ebareCalls(V v_n_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_e2_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    switch (heff_tag_of(v_e2_249)) {
    case TAG_EVar: {
      heff_drop(v_x_248);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2413 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2412));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2413);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2413);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EGlobal: {
      heff_drop(v_x_248);
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2415));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2416);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ELam: {
      heff_drop(v_x_248);
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2420 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2419));
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2420);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2420);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      heff_drop(v_x_248);
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2423));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2424);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2424);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ELet: {
      heff_drop(v_x_248);
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2429 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2428));
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2429);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2429);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ERecord: {
      heff_drop(v_x_248);
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2433 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2432));
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2433);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2433);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EProj: {
      heff_drop(v_x_248);
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2439 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2438));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2439);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2439);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ETag: {
      heff_drop(v_x_248);
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2444 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2443));
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2444);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2444);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EMatch: {
      heff_drop(v_x_248);
      V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2448 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2447));
      if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2448);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2448);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_drop(v_x_248);
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2451 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2450));
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2451);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2451);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_248);
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2455 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2454));
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2455);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2455);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ECall: {
      V v_g_2456 = heff_field(v_e2_249, 0);
      V v_argv_2457 = heff_field(v_e2_249, 1);
      V v_ru_24e2_249_24ECall = heff_take_reuse_n(v_e2_249, 3ULL, 2);
      V v_t_2460 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam0, 1, 1, (V[]){heff_dup(v_n_240)}); V a_1 = v_argv_2457; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_argv_2457); r_; });
      if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_x_248);
        heff_drop(v_b_2410);
        heff_drop(v_g_2456);
        heff_drop_cell(v_ru_24e2_249_24ECall, 2);
        heff_drop(v_t_2460);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2460);
        V v_t_2461 = heff_tag_at_n(v_ru_24e2_249_24ECall, TAG_Cons, 2, (V[]){heff_dup(v_b_2410), NTAG(TAG_Nil)});
        V v_t_2462 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2461));
        if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
          heff_drop(v_n_240);
          heff_drop(v_x_248);
          heff_drop(v_b_2410);
          heff_drop(v_g_2456);
          heff_drop(v_t_2462);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2462);
          V v_t_2463 = ({ V a_0 = v_x_248; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2etokens_2egivesBack(a_0, a_1)); heff_drop(v_x_248); r_; });
          if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
            heff_drop(v_n_240);
            heff_drop(v_b_2410);
            heff_drop(v_t_2463);
            return heff_tag_n(TAG_Cons, 2, (V[]){v_g_2456, NTAG(TAG_Nil)});
          } else {
            heff_drop(v_g_2456);
            heff_drop(v_t_2463);
            V t_0 = v_n_240;
            V t_1 = v_b_2410;
            v_n_240 = t_0;
            v_e_241 = t_1;
            goto top;
          }
        }
      }
    }
    case TAG_EInt: {
      heff_drop(v_x_248);
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2466 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2465));
      if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2466);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2466);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EFloat: {
      heff_drop(v_x_248);
      V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2469 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2468));
      if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2469);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2469);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EStr: {
      heff_drop(v_x_248);
      V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2472 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2471));
      if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2472);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2472);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EBytes: {
      heff_drop(v_x_248);
      V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2475 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2474));
      if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2475);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2475);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EFixed: {
      heff_drop(v_x_248);
      V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2479 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2478));
      if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2479);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2479);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EFloat32: {
      heff_drop(v_x_248);
      V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2482 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2481));
      if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2482);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2482);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EAbandon: {
      heff_drop(v_x_248);
      V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2484 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2483));
      if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2484);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2484);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EBool: {
      heff_drop(v_x_248);
      V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2487 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2486));
      if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2487);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2487);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_ESet: {
      heff_drop(v_x_248);
      V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2492 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2491));
      if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2492);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2492);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EValues: {
      heff_drop(v_x_248);
      V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2495 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2494));
      if ((heff_dup(v_t_2495) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2495);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2495);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EFix: {
      heff_drop(v_x_248);
      V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2499 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2498));
      if ((heff_dup(v_t_2499) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2499);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2499);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_e2_249);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_24109 = heff_field(v_e_241, 0);
    V v_arms_24110 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_24111 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_Cons, 2, (V[]){v_s_24109, NTAG(TAG_Nil)});
    V v_t_24112 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_24111));
    if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_arms_24110);
      heff_drop(v_t_24112);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_24112);
      V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24110));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam1, 2, 1, (V[]){v_n_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24113; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24113); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_24124 = heff_field(v_e_241, 0);
    V v_argv_24125 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_24128 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam2, 1, 1, (V[]){v_n_240}); V a_1 = v_argv_24125; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_argv_24125); r_; });
    if ((heff_dup(v_t_24128) == NTAG(TAG_True))) {
      heff_drop(v_g_24124);
      heff_drop_cell(v_ru_24e_241_24ECall, 2);
      heff_drop(v_t_24128);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_24128);
      return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_Cons, 2, (V[]){v_g_24124, NTAG(TAG_Nil)});
    }
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_a_24138 = heff_field(v_e_241, 1);
    V v_b_24139 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 6ULL, 3);
    V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_24138, NTAG(TAG_Nil)});
    V v_t_24141 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_24140));
    if ((heff_dup(v_t_24141) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_24139);
      heff_drop(v_t_24141);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_24141);
      V t_0 = v_n_240;
      V t_1 = v_b_24139;
      v_n_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etokens_2ebareCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2ebareCalls(a[0], a[1]);
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam0(V self, V *args) {
  V v_e_2458 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2458, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2etokens_2ebuildsW(v_n_240, v_t_2459));
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam1(V self, V *args) {
  V v_acc_24114 = args[0];
  V v_x_24115 = args[1];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24119;
  switch (heff_tag_of(v_x_24115)) {
  case TAG_MkArm: {
    V v_b_24118 = heff_field(v_x_24115, 2);
    heff_take_n(v_x_24115, 4ULL, 3);
    v_t_24119 = v_b_24118;
    break;
  }
  default: heff_nomatch(v_x_24115);
  }
  V v_t_24120 = (g_heff_2ecompile_2etokens_2ebareCalls(v_n_240, v_t_24119));
  return (g_prelude_2e_2b_2b(v_t_24120, v_acc_24114));
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam2(V self, V *args) {
  V v_e_24126 = args[0];
  V v_n_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_24126, NTAG(TAG_Nil)});
  return (g_heff_2ecompile_2etokens_2ebuildsW(v_n_240, v_t_24127));
}
V g_heff_2ecompile_2etokens_2earmSites_lam0(V self, V *args);
Clo g_heff_2ecompile_2etokens_2earmSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2earmSites_entry, 2, 0};

V g_heff_2ecompile_2etokens_2earmSites(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkArm: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_vs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_242, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_242, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      return NTAG(TAG_Nil);
    } else {
      switch (heff_tag_of(v_vs_243)) {
      case TAG_Nil: {
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_244), NTAG(TAG_Nil)});
        V v_t_248 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_247));
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_244), NTAG(TAG_Nil)});
        V v_t_2410 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_249));
        V v_x_2411 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_248, v_t_2410}), 0, 2);
        if (heff_intLt_c(MK_INT(0LL), v_x_2411)) {
          return NTAG(TAG_Nil);
        } else {
          V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
          V v_t_2413 = (g_heff_2ecompile_2etokens_2ebareCalls(v_t_2412, heff_dup(v_b_244)));
          HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ecompile_2etokens_2earmSites_lam0, 1, 1, (V[]){heff_dup(v_vs_243)}), v_t_2413);
        }
      }
      default: return heff_nomatch(v_vs_243);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etokens_2earmSites_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2etokens_2earmSites(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2etokens_2earmSites_lam0(V self, V *args) {
  V v_g_2414 = args[0];
  V v_vs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_243); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_g_2414, v_t_2415});
}
V g_heff_2ecompile_2etokens_2esitesW_lam0(V self, V *args);
Clo g_heff_2ecompile_2etokens_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2esitesW_entry, 2, 0};

V g_heff_2ecompile_2etokens_2esitesW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2414;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2417;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2423, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2425;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_x211_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2426)) {
      case TAG_EVar: {
        V v_x_2428 = heff_field(v_x211_2426, 0);
        heff_take_n(v_x211_2426, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2432 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2etokens_2esitesW_lam0, 2, 1, (V[]){v_x_2428}), v_acc_240, v_arms_2427));
        V v_t_2433 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_t_2432;
        V t_1 = v_t_2433;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EGlobal: {
        V v_t_2435 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2435});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ELam: {
        V v_t_2438 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2438});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EApp: {
        V v_t_2441 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2441});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ELet: {
        V v_t_2445 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2445});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ERecord: {
        V v_t_2448 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2448});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EProj: {
        V v_t_2453 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2453});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ETag: {
        V v_t_2457 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2457});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EMatch: {
        V v_t_2460 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2460});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EPrim: {
        V v_t_2462 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2462});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_t_2465 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2465});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ECall: {
        V v_t_2468 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2468});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EInt: {
        V v_t_2470 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2470});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EFloat: {
        V v_t_2472 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2472});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EStr: {
        V v_t_2474 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2474});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EBytes: {
        V v_t_2476 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2476});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EFixed: {
        V v_t_2479 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2479});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EFloat32: {
        V v_t_2481 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2481});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EAbandon: {
        V v_t_2482 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2482});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EBool: {
        V v_t_2484 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2484});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ESet: {
        V v_t_2488 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2488});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EValues: {
        V v_t_2490 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2490});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EFix: {
        V v_t_2493 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x211_2426, v_t_2493});
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x211_2426);
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2496 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2497 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2496, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2497;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2499 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_24100 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2499, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_24100;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_24108 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_24109 = ({ V a_0 = v_c_24108; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24108); r_; });
      V t_0 = v_acc_240;
      V t_1 = v_t_24109;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_24111 = heff_field(v_x21_242, 1);
      V v_b_24112 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_24113 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_24111, heff_tag_n(TAG_Cons, 2, (V[]){v_b_24112, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_24113;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_24114 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24115 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_24114, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_24115;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2esitesW(a[0], a[1]);
}
V g_heff_2ecompile_2etokens_2esitesW_lam0(V self, V *args) {
  V v_a_2429 = args[0];
  V v_arm_2430 = args[1];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = ({ V a_0 = v_x_2428; V a_1 = v_arm_2430; V r_ = (g_heff_2ecompile_2etokens_2earmSites(a_0, a_1)); heff_drop(v_x_2428); heff_drop(v_arm_2430); r_; });
  return (g_heff_2ecompile_2eir_2eappendI(v_t_2431, v_a_2429));
}
Clo g_heff_2ecompile_2etokens_2ecopiable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ecopiable_entry, 3, 0};

V g_heff_2ecompile_2etokens_2ecopiable(V v_tuples_240, V v_n_241, V v_d_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24ELam = heff_take_reuse_n(v_t_243, 2ULL, 2);
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_tuples_240, heff_rfield(v_d_242, 0)));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop(v_n_241);
        heff_drop_rec(v_d_242, 3);
        heff_drop(v_b_247);
        heff_drop_cell(v_ru_24t_243_24ELam, 2);
        V v_x_2411 = v_field_2410;
        heff_drop(v_x_2411);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_field_2410);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_247)));
        V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
        V v_x1_2414 = ({ V a_0 = v_d_242; V a_1 = v_t_2413; V r_ = (g_list_2eany_24s277053946x716662586(a_0, a_1)); heff_drop(v_t_2413); r_; });
        if (!(heff_dup(v_x1_2414) == NTAG(TAG_True))) {
          heff_drop(v_x1_2414);
          V v_t_2415 = heff_tag_at_n(v_ru_24t_243_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
          V v_t_2416 = (g_heff_2ecompile_2etokens_2ebuildsW(v_n_241, v_t_2415));
          if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
            heff_drop(v_t_2416);
            V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
            V v_x_2418 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(150LL), MK_INT(0LL), v_t_2417));
            V v_ret_24bool = heff_bool(!heff_intLt_c_lent(MK_INT(150LL), v_x_2418, 1));
            heff_drop(v_x_2418);
            return v_ret_24bool;
          } else {
            heff_drop(v_b_247);
            heff_drop(v_t_2416);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_n_241);
          heff_drop(v_b_247);
          heff_drop_cell(v_ru_24t_243_24ELam, 2);
          heff_drop(v_x1_2414);
          return NTAG(TAG_False);
        }
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    heff_drop_rec(v_d_242, 3);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2etokens_2ecopiable_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etokens_2ecopiable(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopies_str0, 4, "$tok");
V g_heff_2ecompile_2etokens_2ecopies_lam0(V self, V *args);
Clo g_heff_2ecompile_2etokens_2ecopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ecopies_entry, 3, 0};

V g_heff_2ecompile_2etokens_2ecopies(V v_tuples_240, V v_byKey_241, V v_sites_242) {
top: ;
  V v_m_2426 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2etokens_2ecopies_lam0, 2, 2, (V[]){heff_dup(v_byKey_241), heff_dup(v_tuples_240)}), heff_dup(g_std_2emap_2eempty_get()), v_sites_242));
  V v_t_2427 = ({ V a_0 = v_m_2426; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2426); r_; });
  return (g_list_2emap_24s366344330x1145113647(v_t_2427));
}
V g_heff_2ecompile_2etokens_2ecopies_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2etokens_2ecopies(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2etokens_2ecopies_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_s_244 = args[1];
  V v_byKey_241 = heff_env(self)[0];
  V v_tuples_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247;
  switch (heff_tag_of(v_s_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_s_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_s_244);
  }
  HeffT2 v_t_248 = ({ V a_0 = v_byKey_241; V a_1 = v_t_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_byKey_241); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_d_2411 = v_field_2410;
      V v_t_2414;
      switch (heff_tag_of(v_s_244)) {
      case TAG_MkPair: {
        V v_y_2413 = heff_dup(heff_field(v_s_244, 1));
        v_t_2414 = v_y_2413;
        break;
      }
      default: heff_nomatch(v_s_244);
      }
      V v_t_2415 = ({ V a_0 = v_tuples_240; V a_1 = v_t_2414; V a_2 = heff_dup(v_d_2411); V r_ = (g_heff_2ecompile_2etokens_2ecopiable(a_0, a_1, a_2)); heff_drop(v_tuples_240); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2418;
        switch (heff_tag_of(v_s_244)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_dup(heff_field(v_s_244, 0));
          v_t_2418 = v_x_2416;
          break;
        }
        default: heff_nomatch(v_s_244);
        }
        V v_t_2421;
        switch (heff_tag_of(v_s_244)) {
        case TAG_MkPair: {
          V v_y_2420 = heff_dup(heff_field(v_s_244, 1));
          v_t_2421 = v_y_2420;
          break;
        }
        default: heff_nomatch(v_s_244);
        }
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2etokens_2ecopies_str0), heff_intShow(v_t_2421));
        V v_t_2425;
        switch (heff_tag_of(v_s_244)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_s_244, 1);
          heff_take_n(v_s_244, 2ULL, 2);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_s_244);
        }
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_243, heff_strAppend(v_t_2418, v_t_2422), heff_tag_n(TAG_MkPair, 2, (V[]){v_d_2411, v_t_2425})));
      } else {
        heff_drop(v_s_244);
        heff_drop(v_d_2411);
        heff_drop(v_t_2415);
        return v_m_243;
      }
    } else {
      heff_drop(v_s_244);
      heff_drop(v_tuples_240);
      heff_drop(v_field_2410);
      return v_m_243;
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str1, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str2, 3, "tok");

HeffT2 g_heff_2ecompile_2etokens_2ecopyOf_24cpr(V v_d_240, V v_n_241, V v_s_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_240, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_t_243, 0);
    V v_b_247 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24ELam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str0), heff_intShow(v_n_241));
    V v_t_249 = heff_strAppend(heff_take_field(v_d_240, 0), v_t_248);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str1), heff_intShow(heff_dup(v_s_242)));
    V v_t_2411 = heff_tag_at_n(v_ru_24t_243_24ELam, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str2), v_t_2410), v_xs_246});
    V v_f_2412 = ({ V rv_0 = v_t_249; V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2411, v_b_247}); V rr_ = heff_rec_reuse_nf(v_d_240, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2413 = heff_intAdd(v_s_242, MK_INT(1LL));
    return ((HeffT2){{v_f_2412, v_f_2413}});
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EBool: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ESet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EValues: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}

HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_s_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_d_244 = heff_field(v_x11_242, 0);
      V v_n_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2etokens_2ecopyOf_24cpr(v_d_244, v_n_245, v_s_241));
      {
        V v_field_247 = v_t_246.f[0];
        V v_field_248 = v_t_246.f[1];
        V v_d2_249 = v_field_247;
        V v_s2_2410 = v_field_248;
        HeffT2 v_t_2411 = (g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(v_cs_243, v_s2_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_ds_2414 = v_field_2412;
          V v_s_2415 = v_field_2413;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_d2_249, v_ds_2414}), v_s_2415}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2etokens_2etokensProgram_24cpr_str0, 4, "$tok");

HeffT3 g_heff_2ecompile_2etokens_2etokensProgram_24cpr(V v_tuples_240, V v_s_241, V v_defs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s740336339x1862813792(heff_dup(g_std_2emap_2eempty_get()), v_defs_242));
  V v_t_244 = (g_list_2emap_24s45270243x110012769(heff_dup(v_defs_242)));
  V v_t_245 = (g_heff_2ecompile_2etokens_2esitesW(NTAG(TAG_Nil), v_t_244));
  V v_cs_246 = ({ V a_0 = v_tuples_240; V a_1 = v_t_243; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2etokens_2ecopies(a_0, a_1, a_2)); heff_drop(v_t_243); heff_drop(v_t_245); r_; });
  HeffT2 v_t_247 = (g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(heff_dup(v_cs_246), v_s_241));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_copied_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    V v_f_2412 = (g_heff_2ecompile_2eir_2eappendI(v_defs_242, v_copied_2410));
    V v_t_2413 = (g_list_2efoldl_24s878937540x987476648(heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_cs_246)));
    V v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2etokens_2etokensProgram_24cpr_str0); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_cs_246; V r_ = (g_list_2efoldl_24s1045503831x402406784(a_0, a_1, a_2)); heff_drop(v_cs_246); r_; });
    V v_f_2415 = heff_rec_n(2, shape_byFun__cells, (V[]){v_t_2413, v_t_2414});
    return ((HeffT3){{v_f_2412, v_s_2411, v_f_2415}});
  }
}