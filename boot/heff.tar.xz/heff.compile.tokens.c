// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_underLam 296337946
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2etokens_2ebareCalls(V, V);
V g_heff_2ecompile_2etokens_2ebareCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebareCalls_clo;
V g_heff_2ecompile_2etokens_2ebuildsW(V, V);
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2ebuildsW_clo;
HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24dps_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2etokens_2ecopyOf_24cpr(V, V, V);
V g_heff_2ecompile_2etokens_2esitesW(V, V);
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etokens_2esitesW_clo;
V g_list_2eall_24s743242824x1965727204(V);
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a);
extern Clo g_list_2eall_24s743242824x1965727204_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2ecompile_2etokens_2ebuildsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ebuildsW_entry, 2, 0};

V g_heff_2ecompile_2etokens_2ebuildsW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_n_240;
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_t_246 = heff_field(v_x21_242, 0);
      V v_argv_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_247));
      if ((heff_intEq_c_lent(v_t_249, v_n_240, 0) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_246, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_246, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1))) {
        heff_drop(v_n_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_246);
        heff_drop(v_argv_247);
        heff_drop(v_t_249);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_246);
        heff_drop(v_t_249);
        V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_247, v_rest_243));
        V t_0 = v_n_240;
        V t_1 = v_t_2410;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_n_240;
      V t_1 = v_t_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etokens_2ebuildsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2ebuildsW(a[0], a[1]);
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam0(V self, V *args);
V g_heff_2ecompile_2etokens_2ebareCalls_lam1(V self, V *args);
V g_heff_2ecompile_2etokens_2ebareCalls_lam2(V self, V *args);
Clo g_heff_2ecompile_2etokens_2ebareCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2ebareCalls_entry, 2, 0};

V g_heff_2ecompile_2etokens_2ebareCalls(V v_n_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_e2_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    switch (heff_tag_of(v_e2_249)) {
    case TAG_ECall: {
      V v_g_2411 = heff_field(v_e2_249, 0);
      V v_argv_2412 = heff_field(v_e2_249, 1);
      V v_ru_24e2_249_24ECall = heff_take_reuse_n(v_e2_249, 3ULL, 2);
      V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam0, 1, 1, (V[]){heff_dup(v_n_240)}); V a_1 = v_argv_2412; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_argv_2412); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_x_248);
        heff_drop(v_b_2410);
        heff_drop(v_g_2411);
        heff_drop_cell(v_ru_24e2_249_24ECall, 2);
        heff_drop(v_t_2415);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2415);
        V v_t_2416 = heff_tag_at_n(v_ru_24e2_249_24ECall, TAG_Cons, 2, (V[]){heff_dup(v_b_2410), NTAG(TAG_Nil)});
        V v_t_2417 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2416));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_n_240);
          heff_drop(v_x_248);
          heff_drop(v_b_2410);
          heff_drop(v_g_2411);
          heff_drop(v_t_2417);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2417);
          V v_x_2418 = v_x_248;
          V v_e_2419 = heff_dup(v_b_2410);
          V v_t_2459;
          switch (heff_tag_of(v_e_2419)) {
          case TAG_EVar: {
            V v_y_2420 = heff_field(v_e_2419, 0);
            heff_take_n(v_e_2419, 1ULL, 1);
            v_t_2459 = heff_bool(heff_strEq_c_lent(v_x_2418, v_y_2420, 0));
            heff_drop(v_x_2418);
            heff_drop(v_y_2420);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_e_2419, 0ULL, 3);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_e_2419, 0ULL, 4);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_e_2419, 0ULL, 3);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrimCall: {
            V v_argv_2442 = heff_field(v_e_2419, 1);
            heff_take_n(v_e_2419, 2ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = ({ V a_0 = v_argv_2442; V r_ = (g_list_2eall_24s743242824x1965727204(a_0)); heff_drop(v_argv_2442); r_; });
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EAbandon: {
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_e_2419, 0ULL, 3);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_e_2419, 0ULL, 1);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_e_2419, 0ULL, 2);
            heff_drop(v_x_2418);
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_e_2419);
          }
          if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
            heff_drop(v_n_240);
            heff_drop(v_b_2410);
            heff_drop(v_t_2459);
            return heff_tag_n(TAG_Cons, 2, (V[]){v_g_2411, NTAG(TAG_Nil)});
          } else {
            heff_drop(v_g_2411);
            heff_drop(v_t_2459);
            V t_0 = v_n_240;
            V t_1 = v_b_2410;
            v_n_240 = t_0;
            v_e_241 = t_1;
            goto top;
          }
        }
      }
    }
    default: {
      heff_drop(v_x_248);
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e2_249, NTAG(TAG_Nil)});
      V v_t_2461 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2460));
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop(v_n_240);
        heff_drop(v_b_2410);
        heff_drop(v_t_2461);
        return NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2461);
        V t_0 = v_n_240;
        V t_1 = v_b_2410;
        v_n_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_e_241, 0);
    V v_arms_2472 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2473 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_Cons, 2, (V[]){v_s_2471, NTAG(TAG_Nil)});
    V v_t_2474 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_2473));
    if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_arms_2472);
      heff_drop(v_t_2474);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2474);
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2472));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam1, 2, 1, (V[]){v_n_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2475; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2475); r_; });
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2486 = heff_field(v_e_241, 0);
    V v_argv_2487 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2490 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etokens_2ebareCalls_lam2, 1, 1, (V[]){v_n_240}); V a_1 = v_argv_2487; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_argv_2487); r_; });
    if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
      heff_drop(v_g_2486);
      heff_drop_cell(v_ru_24e_241_24ECall, 2);
      heff_drop(v_t_2490);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2490);
      return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_Cons, 2, (V[]){v_g_2486, NTAG(TAG_Nil)});
    }
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_a_24100 = heff_field(v_e_241, 1);
    V v_b_24101 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 6ULL, 3);
    V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_24100, NTAG(TAG_Nil)});
    V v_t_24103 = (g_heff_2ecompile_2etokens_2ebuildsW(heff_dup(v_n_240), v_t_24102));
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_n_240);
      heff_drop(v_b_24101);
      heff_drop(v_t_24103);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_24103);
      V t_0 = v_n_240;
      V t_1 = v_b_24101;
      v_n_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etokens_2ebareCalls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2ebareCalls(a[0], a[1]);
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam0(V self, V *args) {
  V v_e_2413 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2413, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2etokens_2ebuildsW(v_n_240, v_t_2414));
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam1(V self, V *args) {
  V v_acc_2476 = args[0];
  V v_x_2477 = args[1];
  V v_n_240 = heff_env(self)[0];
  V v_t_2481;
  switch (heff_tag_of(v_x_2477)) {
  case TAG_MkArm: {
    V v_b_2480 = heff_field(v_x_2477, 2);
    heff_take_n(v_x_2477, 4ULL, 3);
    v_t_2481 = v_b_2480;
    break;
  }
  default: heff_nomatch(v_x_2477);
  }
  heff_clo_take(self, 1);
  V v_t_2482 = (g_heff_2ecompile_2etokens_2ebareCalls(v_n_240, v_t_2481));
  return (g_prelude_2e_2b_2b(v_t_2482, v_acc_2476));
}
V g_heff_2ecompile_2etokens_2ebareCalls_lam2(V self, V *args) {
  V v_e_2488 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2488, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2etokens_2ebuildsW(v_n_240, v_t_2489));
}
V g_heff_2ecompile_2etokens_2esitesW_lam1(V self, V *args);
V g_heff_2ecompile_2etokens_2esitesW_lam0(V self, V *args);
Clo g_heff_2ecompile_2etokens_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etokens_2esitesW_entry, 2, 0};

V g_heff_2ecompile_2etokens_2esitesW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EMatch: {
      V v_x211_244 = heff_dup(heff_field(v_x21_242, 0));
      switch (heff_tag_of(v_x211_244)) {
      case TAG_EVar: {
        V v_x_246 = heff_field(v_x211_244, 0);
        heff_take_n(v_x211_244, 1ULL, 1);
        switch (heff_tag_of(v_x21_242)) {
        case TAG_EMatch: {
          V v_arms_248 = heff_field(v_x21_242, 1);
          heff_take_n(v_x21_242, 2ULL, 2);
          V v_t_2428 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2etokens_2esitesW_lam0, 2, 1, (V[]){v_x_246}), v_acc_240, v_arms_248));
          V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_248, v_rest_243));
          V t_0 = v_t_2428;
          V t_1 = v_t_2429;
          v_acc_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x21_242);
        }
      }
      default: {
        heff_drop(v_x211_244);
        V v_t_2430 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
        V t_0 = v_acc_240;
        V t_1 = v_t_2430;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      }
    }
    default: {
      V v_t_2431 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2431;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etokens_2esitesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etokens_2esitesW(a[0], a[1]);
}
V g_heff_2ecompile_2etokens_2esitesW_lam1(V self, V *args) {
  V v_g_2425 = args[0];
  V v_vs_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_vs_2414, 2); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_g_2425, v_t_2426});
}
V g_heff_2ecompile_2etokens_2esitesW_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_arm_2410 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2411 = v_x_246;
  V v_x2_2412 = v_arm_2410;
  V v_t_2427;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkArm: {
    V v_t_2413 = heff_field(v_x2_2412, 0);
    V v_vs_2414 = heff_field(v_x2_2412, 1);
    V v_b_2415 = heff_field(v_x2_2412, 2);
    heff_take_n(v_x2_2412, 7ULL, 3);
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2413, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2413, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_x_2411);
      heff_drop(v_t_2413);
      heff_drop(v_vs_2414);
      heff_drop(v_b_2415);
      v_t_2427 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_vs_2414)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2415);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)});
        V v_t_2419 = (g_heff_2ecompile_2eir_2ecountW(v_x_2411, MK_INT(0LL), v_t_2418));
        V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)});
        V v_t_2421 = ({ V a_0 = v_x_2411; V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2411); r_; });
        V v_x_2422 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2419, v_t_2421}), 0, 2);
        if (heff_intLt_c(MK_INT(0LL), v_x_2422)) {
          heff_drop_tag(v_vs_2414, 2);
          heff_drop(v_b_2415);
          v_t_2427 = NTAG(TAG_Nil);
        } else {
          V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2414));
          V v_t_2424 = (g_heff_2ecompile_2etokens_2ebareCalls(v_t_2423, v_b_2415));
          v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2etokens_2esitesW_lam1, 1, 1, (V[]){v_vs_2414}), v_t_2424));
        }
        break;
      }
      default: heff_nomatch(v_vs_2414);
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  return (g_heff_2ecompile_2eir_2eappendI(v_t_2427, v_a_249));
}
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str1, 4, "tok$");

HeffT2 g_heff_2ecompile_2etokens_2ecopyOf_24cpr(V v_d_240, V v_n_241, V v_s_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_240, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_t_243, 0);
    V v_b_247 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24ELam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_take_field(v_d_240, 0), ((V)&g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str0));
    V v_t_249 = heff_strAppend(v_t_248, heff_intShow(v_n_241));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2etokens_2ecopyOf_24cpr_str1), heff_intShow(heff_dup(v_s_242)));
    V v_t_2411 = heff_tag_re_n(v_ru_24t_243_24ELam, TAG_ELam, 2, 2ULL, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_xs_246}), v_b_247});
    V v_f_2412 = ({ V rv_0 = v_t_249; V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_d_240, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2413 = heff_intAdd(v_s_242, MK_INT(1LL));
    return ((HeffT2){{v_f_2412, v_f_2413}});
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EBool: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_ESet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EValues: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{v_d_240, v_s_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}

HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24cpr(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_s_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_d_244 = heff_field(v_x11_242, 0);
      V v_n_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2etokens_2ecopyOf_24cpr(v_d_244, v_n_245, v_s_241));
      {
        V v_field_247 = v_t_246.f[0];
        V v_field_248 = v_t_246.f[1];
        V v_d2_249 = v_field_247;
        V v_s2_2410 = v_field_248;
        V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_d2_249, heff_hole()});
        HeffT2 v_t_2412 = (g_heff_2ecompile_2etokens_2ecopiesOf_24dps_24cpr(v_cs_243, v_s2_2410, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          V v_s_2416 = v_field_2414;
          return ((HeffT2){{v_cell_2411, v_s_2416}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2etokens_2ecopiesOf_24dps_24cpr(V v_x1_240, V v_s_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_s_241}});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_cs_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_d_247 = heff_field(v_x11_245, 0);
      V v_n_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2etokens_2ecopyOf_24cpr(v_d_247, v_n_248, v_s_241));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_d2_2412 = v_field_2410;
        V v_s2_2413 = v_field_2411;
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_d2_2412, heff_hole()});
        V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
        V t_0 = v_cs_246;
        V t_1 = v_s2_2413;
        V t_2 = v_u_2415;
        v_x1_240 = t_0;
        v_s_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}