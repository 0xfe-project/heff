// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_MkAbs 54862
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SApp 57081
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_selfKey 62480824
#define LBL_solve 310977625
#define LBL_syntax 1059664654
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2enominalBody(V);
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enominalBody_clo;
HeffT2 g_heff_2eelab_2eunify_2enominalOf_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezipL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_argv_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          if (heff_intEq_c_lent(v_l_248, v_l_27_249, 0)) {
            V t_0 = v_argv_245;
            V t_1 = v_bs_247;
            v_x1_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_PSelf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_b_246);
        }
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          return NTAG(TAG_False);
        }
        case TAG_PSelf: {
          V t_0 = v_argv_245;
          V t_1 = v_bs_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_b_246);
        }
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eeqPatArgs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eelab_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eunify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2emetasSpF(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_entry, 6, 0};

V g_heff_2eelab_2eunify_2epoisonMany(V v_w_240, V v_ms_241, V v_uf_242, V v_ms_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam0, 1, 1, (V[]){heff_dup(v_ms_243)})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_248, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam1, 1, 4, (V[]){v_ms_241, v_w_240, v_z_244, v_z_245})));
}
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2epoisonMany(a[0], a[1], a2, a3, a[4], a[5]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_247 = ({ V a_0 = heff_take_field(v_c_246, 2); V a_1 = v_ms_243; V r_ = (g_list_2efoldl_24s1583117218x1471782720(a_0, a_1)); heff_drop(v_ms_243); r_; });
  return ({ V rv_2 = v_ps_247; V rr_ = heff_rec_reuse_nf(v_c_246, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(v_ms_241, 1, (V[]){v_t_2410}));
  return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2411, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_take_field(v_ft_2420, 2));
    V v_t_2423 = (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = ({ V rv_2 = heff_arrayFromList(v_t_2423); V rr_ = heff_rec_reuse_nf(v_ft_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2427 = heff_take_field(v_vs_2425, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2427, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam0, 1, 2, (V[]){v_xs_2427, v_f_2426}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_vs_2425, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2433});
  }
  case TAG_SIsTy: {
    V v_a_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2434}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2435});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2426;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2429, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2429, v_f_2426}));
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24PVar = heff_take_reuse_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_intEq_c(v_a_247, v_a_248)) {
            v_t_2411 = heff_tag_at_n(v_ru_24a_245_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_245_24PVar, 1);
            v_t_2411 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_245_24PVar, 1);
          v_t_2411 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2411 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_2412;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2eunify_2enominalOf_24cpr(V v_g_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_HGlobal: {
    V v_k_244 = heff_field(v_h_241, 0);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 1), v_k_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_rec(v_g_240, 8);
        V v_e_249 = v_field_247;
        V v_t_2410 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_249, 0, 4)));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_244), v_sp_242})}});
        } else {
          heff_drop(v_sp_242);
          heff_drop(v_t_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_field_247);
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 2), v_k_244));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_k2_2415 = v_field_2413;
            HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k2_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2415); r_; });
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_e_2420 = v_field_2418;
                V v_t_2421 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_2420, 0, 4)));
                if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                  heff_drop(v_t_2421);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_244), v_sp_242})}});
                } else {
                  heff_drop(v_sp_242);
                  heff_drop(v_t_2421);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_sp_242);
                heff_drop(v_field_2418);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_sp_242);
            heff_drop(v_field_2413);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
  case TAG_HMeta: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_HError: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_h_241)}});
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2434 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2433));
  V f_ = v_c_2434;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2436 = heff_env(self)[1];
  V v_x_2442 = heff_env(self)[2];
  V v_implicit_2439 = heff_env(self)[3];
  V v_dflt_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2436, v_x_2442, v_x_2444, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2437 = heff_env(self)[3];
  V v_cod_2438 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2436 = heff_env(self)[7];
  V v_implicit_2439 = heff_env(self)[8];
  V v_dflt_2440 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2443 = (g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917(v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438));
  V f_ = v_c_2443;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam10, 1, 5, (V[]){v_k_245, v_level_2436, v_x_2442, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_fieldTypes_2447 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2445 = heff_env(self)[2];
  V v_defaults_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = ({ V rv_2 = heff_arrayFromList(v_x_2451); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2447, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2445, v_t_2452, v_defaults_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam13(V self, V *args) {
  V v_a_2460 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2461 = heff_tr(heff_call(v_a_2460, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2461;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam15(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_k_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2458, heff_arrayFromList(v_x_2465)});
  V f_ = v_k_2464;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam14(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_c_2462 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2462;
  args[0] = v_hd_2463;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam15, 1, 2, (V[]){v_k_2458, v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam12(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_args_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    V v_c_2462 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2459)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam14, 2, 2, (V[]){v_c_2462, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam16(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2468)));
  V v_t_2470 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2468));
  V v_t_2471 = (g_list_2emap_24s1173914895x100384474(v_x_2468));
  V v_t_2472 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2469), v_t_2470, heff_arrayFromList(v_t_2471)});
  V v_x_2473 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2472});
  V f_ = v_k_245;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam17(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2475});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2417;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2426, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at_n(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2429}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2430;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam6, 1, 1, (V[]){v_k_245})));
      }
    }
    case TAG_HError: {
      V v_c_2432 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2432;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2436 = heff_field(v_x_249, 0);
    V v_dom_2437 = heff_field(v_x_249, 1);
    V v_cod_2438 = heff_field(v_x_249, 2);
    V v_implicit_2439 = heff_field(v_x_249, 3);
    V v_dflt_2440 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 6);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2437), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438, v_hd_244, v_k_245, v_level_2436, v_implicit_2439, v_dflt_2440})));
  }
  case TAG_VRecord: {
    V v_level_2445 = heff_field(v_x_249, 0);
    V v_capture_2446 = heff_field(v_x_249, 1);
    V v_fieldTypes_2447 = heff_field(v_x_249, 2);
    V v_defaults_2448 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2449 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2447, 2)));
    V v_c_2450 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s412365251x1251923025(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2446, v_t_2449));
    V f_ = v_c_2450;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam11, 1, 4, (V[]){v_fieldTypes_2447, v_k_245, v_level_2445, v_defaults_2448});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_take_field(v_vs_2453, 0));
    V v_t_2455 = heff_arrayToList(heff_get_n(v_vs_2453, 2, 3));
    V v_t_2456 = (g_heff_2eutil_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2467 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    V f_ = v_c_2467;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2474 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, v_pr_242, v_a_2474, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2476 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2476});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_st;
static V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_st)) return g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_val;
  return heff_global(&g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_val, &g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_st, g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_init);
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1075335204x1358500169_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}