// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_selfKey 62480824
#define LBL_syntax 1059664654
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2enominalBody(V);
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enominalBody_clo;
HeffT2 g_heff_2eelab_2eunify_2enominalOf_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo;
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo;
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezipL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1583117218x1471782720(V, V);
V g_list_2efoldl_24s1583117218x1471782720_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1583117218x1471782720_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_argv_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          if (heff_intEq_c_lent(v_l_248, v_l_27_249, 0)) {
            V t_0 = v_argv_245;
            V t_1 = v_bs_247;
            v_x1_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_PSelf: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_b_246);
        }
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          return NTAG(TAG_False);
        }
        case TAG_PSelf: {
          V t_0 = v_argv_245;
          V t_1 = v_bs_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_b_246);
        }
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eeqPatArgs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eelab_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eunify_2ezipL_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2emetasSpF(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_entry, 6, 0};

V g_heff_2eelab_2eunify_2epoisonMany(V v_w_240, V v_ms_241, V v_uf_242, V v_ms_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam0, 1, 1, (V[]){heff_dup(v_ms_243)})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_248, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam1, 1, 4, (V[]){v_ms_241, v_w_240, v_z_244, v_z_245})));
}
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2epoisonMany(a[0], a[1], a2, a3, a[4], a[5]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_247 = ({ V a_0 = heff_take_field(v_c_246, 2); V a_1 = v_ms_243; V r_ = (g_list_2efoldl_24s1583117218x1471782720(a_0, a_1)); heff_drop(v_ms_243); r_; });
  return ({ V rv_2 = v_ps_247; V rr_ = heff_rec_reuse_nf(v_c_246, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(v_ms_241, 1, (V[]){v_t_2410}));
  return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2411, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_take_field(v_ft_2420, 2));
    V v_t_2423 = (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = ({ V rv_2 = heff_arrayFromList(v_t_2423); V rr_ = heff_rec_reuse_nf(v_ft_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2427 = heff_take_field(v_vs_2425, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2427, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam0, 1, 2, (V[]){v_xs_2427, v_f_2426}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_vs_2425, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2433});
  }
  case TAG_SIsTy: {
    V v_a_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2434}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2435});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2426;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2429, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2429, v_f_2426}));
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24PVar = heff_take_reuse_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_intEq_c(v_a_247, v_a_248)) {
            v_t_2411 = heff_tag_at_n(v_ru_24a_245_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_245_24PVar, 1);
            v_t_2411 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_245_24PVar, 1);
          v_t_2411 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2411 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_2412;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2eunify_2enominalOf_24cpr(V v_g_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_HGlobal: {
    V v_k_244 = heff_field(v_h_241, 0);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 1), v_k_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_rec(v_g_240, 8);
        V v_e_249 = v_field_247;
        V v_t_2410 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_249, 0, 4)));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_244), v_sp_242})}});
        } else {
          heff_drop(v_sp_242);
          heff_drop(v_t_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_field_247);
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 2), v_k_244));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_k2_2415 = v_field_2413;
            HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k2_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2415); r_; });
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_e_2420 = v_field_2418;
                V v_t_2421 = (g_heff_2eelab_2eunify_2enominalBody(heff_get_n(v_e_2420, 0, 4)));
                if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                  heff_drop(v_t_2421);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_244), v_sp_242})}});
                } else {
                  heff_drop(v_sp_242);
                  heff_drop(v_t_2421);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_sp_242);
                heff_drop(v_field_2418);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_sp_242);
            heff_drop(v_field_2413);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
  case TAG_HMeta: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_HError: {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_sp_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_h_241)}});
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4(V self, V *args) {
  V v_a_2423 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2423)) {
  case TAG_PVar: {
    V v_l_2424 = heff_field(v_a_2423, 0);
    heff_take_n(v_a_2423, 1ULL, 1);
    HeffT2 v_t_2425 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2424; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2426 == ((int64_t)0ULL)) ? ({ V v_x_2429 = heff_dup(v_field_2427); int c_ = 0; heff_drop(v_x_2429); c_; }) : 1));
      heff_drop(v_field_2427);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2423);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6(V self, V *args) {
  V v_i_2433 = args[0];
  V v_a_2434 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2434)) {
  case TAG_PVar: {
    V v_l_2435 = heff_field(v_a_2434, 0);
    V v_ru_24a_2434_24PVar = heff_take_reuse_n(v_a_2434, 1ULL, 1);
    HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2435; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2438 = v_t_2436.f[1];
      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
      if ((v_tag_2437 == ((int64_t)0ULL))) {
        V v_x_2440 = v_field_2438;
        heff_drop(v_x_2440);
        return heff_tag_at_n(v_ru_24a_2434_24PVar, TAG_Just, 1, (V[]){v_i_2433});
      } else {
        heff_drop(v_i_2433);
        heff_drop_cell(v_ru_24a_2434_24PVar, 1);
        heff_drop(v_field_2438);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2433);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2434);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2444 = ({ V a_0 = v_x_2443; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_v_2444, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_args_2422 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
  V v_t_2441 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2422));
  V v_t_2442 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2441));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2431, v_t_2432, v_t_2442, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8(V self, V *args) {
  V v_c_2446 = args[0];
  return heff_get_n(v_c_2446, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2450 = ({ V a_0 = v_x_2449; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2449); r_; });
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2454 = v_field_2452;
      V f_ = v_k_2445;
      args[0] = v_e_2454;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2452);
      V v_t_2455 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2456}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2457;
      heff_room[1] = v_k_2445;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2467);
  V v_t_2469 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2466);
  V f_ = v_k_2468;
  args[0] = heff_intSub(v_t_2469, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_t_2472 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tr(heff_call(heff_take_field(v_hd_2470, 2), 1, (V[]){v_t_2473}));
  V f_ = heff_get_n(v_hd_2470, 1, 3);
  args[0] = v_t_2474;
  args[1] = v_k2_2471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_t_2477 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2478}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2479;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12(V self, V *args) {
  V v_a_2460 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2460)) {
  case TAG_PVar: {
    V v_l_2461 = heff_field(v_a_2460, 0);
    heff_take_n(v_a_2460, 1ULL, 1);
    HeffT2 v_t_2462 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_pr_242, 2), v_l_2461));
    {
      V v_field_2464 = v_t_2462.f[1];
      int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
      if ((v_tag_2463 == ((int64_t)0ULL))) {
        V v_l_27_2466 = v_field_2464;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2466});
      } else {
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_field_2464);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam15_clo);
  }
  default: return heff_nomatch(v_a_2460);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16(V self, V *args) {
  V v_x_2481 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2482 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2481), v_x_2459});
  V f_ = v_k_246;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2422 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2480 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam12, 1, 1, (V[]){v_pr_242}), v_args_2422));
  V f_ = v_c_2480;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam16, 1, 3, (V[]){v_m_27_243, v_x_2459, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2422 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2458, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam11, 1, 5, (V[]){v_pr_242, v_args_2422, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17(V self, V *args) {
  V v_c_2484 = args[0];
  return heff_get_n(v_c_2484, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18(V self, V *args) {
  V v_x_2487 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2483 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2488 = ({ V a_0 = v_x_2487; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2487); r_; });
  {
    V v_field_2490 = v_t_2488.f[1];
    int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
    if ((v_tag_2489 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2492 = v_field_2490;
      V f_ = v_k_2483;
      args[0] = v_e_2492;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2490);
      V v_t_2493 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2494}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2495;
      heff_room[1] = v_k_2483;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); heff_drop(v_x_2410); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2419)));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2420); r_; });
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_args_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
        V v_t_2430 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2422));
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop(v_t_2430);
          V v_k_2445 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam5, 1, 8, (V[]){v_args_2422, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam8_clo)})});
          V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2447}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2448;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam9, 1, 3, (V[]){v_m_27_243, v_k_2445, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_sp_244);
          heff_drop(v_t_2430);
          V v_k_2483 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2422, heff_dup(v_m_27_243), v_k_246});
          V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam17_clo)})});
          V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2485}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2486;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam18, 1, 3, (V[]){v_m_27_243, v_k_2483, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_sp_244);
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_m_27_243);
        heff_drop(v_items_2419);
        heff_drop(v_t_2421);
        V v_t_2496 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2497}));
        V f_ = heff_get_n(v_hd_245, 1, 3);
        heff_room[0] = v_t_2498;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_sp_244);
      heff_drop_rec(v_pr_242, 3);
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_m_27_243);
      heff_drop(v_field_2417);
      V v_t_2499 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
      V v_t_24101 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24100}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24101;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam2, 2, 5, (V[]){v_v_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_2411, v_v_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_v_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_v_2416)) {
  case TAG_Nom: {
    V v_v_2419 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419}));
    break;
  }
  case TAG_Describe: {
    V v_v_2420 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2420}));
    break;
  }
  case TAG_Become: {
    V v_v_2421 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2421});
    break;
  }
  default: heff_nomatch(v_v_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_242, v_v_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430}));
    break;
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2431}));
    break;
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_t_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2eelab_2eunify_2erenameSpine_24s1005947687x381410231(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2429));
  V f_ = v_t_2430;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_fty_2433 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2434 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2437 = heff_tr(heff_call(v_fty_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2438 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2437)));
  V v_t_2450;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2441 = heff_field(v_t_2438, 1);
    heff_take_n(v_t_2438, 2ULL, 4);
    heff_drop(v_t_2437);
    v_t_2450 = v_dom_2441;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2438, 0ULL, 3);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeInt: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeString: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeRune: {
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2450 = v_t_2437;
    break;
  }
  case TAG_NoRules: {
    v_t_2450 = v_t_2437;
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_c_2451 = (g_heff_2eelab_2eunify_2erenameClo_24s1697502887x144299062(v_g_240, v_m_241, v_pr_242, v_t_2450, v_body_2434));
  V f_ = v_c_2451;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam7, 1, 2, (V[]){v_k_245, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam11(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam10(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_242, v_v_2464, v_hd_2465, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam11, 1, 1, (V[]){v_k_2466})));
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam12(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_2461 = heff_env(self)[0];
  V v_k_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2458, v_x_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam9(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_x_2459 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2468;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nom: {
    V v_v_2462 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2462}));
    break;
  }
  case TAG_Describe: {
    V v_v_2463 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2463}));
    break;
  }
  case TAG_Become: {
    V v_v_2464 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam10, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2464});
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V f_ = v_t_2468;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam12, 1, 2, (V[]){v_k_2461, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam8(V self, V *args) {
  V v_p_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_p_2457, 0);
    V v_x_2459 = heff_field(v_p_2457, 1);
    heff_take_n(v_p_2457, 3ULL, 2);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam9, 2, 5, (V[]){v_x_2459, v_g_240, v_m_241, v_pr_242, v_k_2458});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2471)));
  V v_t_2473 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2471));
  V v_t_2474 = (g_list_2emap_24s1173914895x100384474(v_x_2471));
  V v_t_2475 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2472), v_t_2473, heff_arrayFromList(v_t_2474)});
  V v_x_2476 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2475});
  V f_ = v_k_245;
  args[0] = v_x_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2420;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2423, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2425 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2426 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2426}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2427;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(v_g_240, v_m_241, v_pr_242, v_m_27_2423, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    case TAG_HError: {
      V v_c_2428 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2428;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_240, v_m_241, v_pr_242, v_t_2431, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2433 = heff_field(v_x_249, 0);
    V v_body_2434 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_call(heff_dup(v_fty_2433), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2435, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam6, 1, 7, (V[]){v_fty_2433, v_g_240, v_m_241, v_pr_242, v_body_2434, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2453 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2454 = heff_arrayToList(heff_take_field(v_d_2453, 0));
    V v_t_2455 = heff_arrayToList(heff_get_n(v_d_2453, 2, 3));
    V v_t_2456 = (g_heff_2eutil_2edict_2ezipKV(v_t_2454, v_t_2455));
    V v_c_2470 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2456));
    V f_ = v_c_2470;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam2, 2, 5, (V[]){v_t_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_240, v_m_241, v_pr_2411, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_t_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nom: {
    V v_a_2419 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419}));
    break;
  }
  case TAG_Describe: {
    V v_a_2420 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2420}));
    break;
  }
  case TAG_Become: {
    V v_a_2421 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2421});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_240, v_m_241, v_pr_242, v_a_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_a_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430}));
    break;
  }
  case TAG_Describe: {
    V v_a_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2431}));
    break;
  }
  case TAG_Become: {
    V v_a_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1173766939x79428626_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_args_27_2440 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ezipL(v_args_2423, v_args_27_2440));
  V v_t_2448 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(MK_INT(0LL), v_t_2447));
  V v_t_2449 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2448));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2445, v_t_2446, v_t_2449, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam6(V self, V *args) {
  V v_c_2452 = args[0];
  return heff_get_n(v_c_2452, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2456 = ({ V a_0 = v_x_2455; V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2455); r_; });
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2460 = v_field_2458;
      V f_ = v_k_2451;
      args[0] = v_e_2460;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2458);
      V v_t_2461 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_2451;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2420)));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2421); r_; });
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_t_2422);
        V v_args_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2420));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2424 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2425 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2424)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2431 = heff_field(v_v1_2424, 0);
            V v_ru_24v1_2424_24HMeta = heff_take_reuse_n(v_v1_2424, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2431, v_m_242, 1)) {
              HeffT2 v_t_2433 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2425; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_items_2437 = v_field_2435;
                  V v_t_2438 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2437)));
                  V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2438); r_; });
                  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                    heff_drop(v_t_2439);
                    V v_args_27_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2437));
                    V v_t_2441 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2440, v_args_2423));
                    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2423);
                      heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                      heff_drop(v_args_27_2440);
                      heff_drop(v_t_2441);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2441);
                      V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2440));
                      V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
                      if (heff_intEq_c(v_t_2442, v_t_2443)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2451 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam4, 1, 6, (V[]){v_args_2423, v_args_27_2440, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2453 = heff_tag_at_n(v_ru_24v1_2424_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam6_clo)})});
                        V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2453}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2454;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam7, 1, 3, (V[]){v_m_242, v_k_2451, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2423);
                        heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                        heff_drop(v_args_27_2440);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2423);
                    heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                    heff_drop(v_items_2437);
                    heff_drop(v_t_2439);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2423);
                  heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                  heff_drop(v_field_2435);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2425);
              heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2424);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2420);
        heff_drop(v_t_2422);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}