// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2elsp_2ejtrue_val;
static int g_heff_2elsp_2ejtrue_st;
static V g_heff_2elsp_2ejtrue_init(void) {
  return heff_tag(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2ejtrue_get(void) {
  if (g_heff_2elsp_2ejtrue_st == 2) return g_heff_2elsp_2ejtrue_val;
  if (g_heff_2elsp_2ejtrue_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ejtrue_st = 1;
  g_heff_2elsp_2ejtrue_val = heff_tr(g_heff_2elsp_2ejtrue_init());
  g_heff_2elsp_2ejtrue_st = 2;
  return g_heff_2elsp_2ejtrue_val;
}

static V g_heff_2elsp_2ejfalse_val;
static int g_heff_2elsp_2ejfalse_st;
static V g_heff_2elsp_2ejfalse_init(void) {
  return heff_tag(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2ejfalse_get(void) {
  if (g_heff_2elsp_2ejfalse_st == 2) return g_heff_2elsp_2ejfalse_val;
  if (g_heff_2elsp_2ejfalse_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ejfalse_st = 1;
  g_heff_2elsp_2ejfalse_val = heff_tr(g_heff_2elsp_2ejfalse_init());
  g_heff_2elsp_2ejfalse_st = 2;
  return g_heff_2elsp_2ejfalse_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eoffsetGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eoffsetGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_line_241), heff_dup(v_l_244));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    heff_drop(v_t_245);
    V v_t_246 = heff_intLe(MK_INT(0LL), heff_dup(v_ch_242));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      v_t_247 = v_ch_242;
      break;
    }
    case TAG_False: {
      heff_drop(v_ch_242);
      heff_drop(v_t_246);
      v_t_247 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_a_248 = heff_intAdd(heff_dup(v_i_243), v_t_247);
    V v_x2_249 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2eoffsetGo_str0), heff_dup(v_src_240), v_i_243));
    V v_b_2411;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      heff_drop(v_x2_249);
      v_b_2411 = heff_strLength(v_src_240);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take(v_x2_249, 1ULL);
      heff_drop(v_src_240);
      v_b_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2412 = heff_intLe(heff_dup(v_a_248), heff_dup(v_b_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return v_a_248;
    }
    case TAG_False: {
      heff_drop(v_a_248);
      heff_drop(v_t_2412);
      return v_b_2411;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2eoffsetGo_str1), heff_dup(v_src_240), v_i_243));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_t_2413);
      return heff_strLength(v_src_240);
    }
    case TAG_Just: {
      V v_e_2414 = heff_field(v_t_2413, 0);
      heff_take(v_t_2413, 1ULL);
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_e_2414, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eoffsetGo(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2eposition_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {99, 104, 97, 114, 97, 99, 116, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eposition_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 110, 101}};
Clo g_heff_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_a_242 = heff_strLength(heff_dup(v_src_240));
  V v_t_243 = heff_intLe(heff_dup(v_a_242), heff_dup(v_i_241));
  V v_b_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    v_b_244 = v_a_242;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_242);
    heff_drop(v_t_243);
    v_b_244 = heff_dup(v_i_241);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_b_244));
  V v_i_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    v_i_246 = v_b_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_244);
    heff_drop(v_t_245);
    v_i_246 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), v_i_246, MK_INT(0LL), MK_INT(0LL)));
  V v_t_248 = heff_tag(TAG_JInt, 1, (V[]){heff_get(v_t_247, LBL_line)});
  V v_a_249 = heff_strLength(heff_dup(v_src_240));
  V v_t_2410 = heff_intLe(heff_dup(v_a_249), heff_dup(v_i_241));
  V v_b_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_i_241);
    heff_drop(v_t_2410);
    v_b_2411 = v_a_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_249);
    heff_drop(v_t_2410);
    v_b_2411 = v_i_241;
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_intLe(MK_INT(0LL), heff_dup(v_b_2411));
  V v_i_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_t_2412);
    v_i_2413 = v_b_2411;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2411);
    heff_drop(v_t_2412);
    v_i_2413 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = (g_heff_2erender_2elineColGo(v_src_240, v_i_2413, MK_INT(0LL), MK_INT(0LL)));
  V v_t_2415 = heff_tag(TAG_JInt, 1, (V[]){heff_get(v_t_2414, LBL_col)});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eposition_str0), v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eposition_str1), v_t_248}), v_t_2416});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2417});
}
V g_heff_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eposition(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erange_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 97, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2erange_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 110, 100}};
Clo g_heff_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erange_str0), (g_heff_2elsp_2eposition(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_start)))});
  V v_a_243 = heff_get(heff_dup(v_sp_241), LBL_start);
  V v_b_244 = heff_get(v_sp_241, LBL_end);
  V v_t_245 = heff_intLe(heff_dup(v_a_243), heff_dup(v_b_244));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_a_243);
    heff_drop(v_t_245);
    v_t_246 = v_b_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_244);
    heff_drop(v_t_245);
    v_t_246 = v_a_243;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erange_str1), (g_heff_2elsp_2eposition(v_src_240, v_t_246))});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_248})});
}
V g_heff_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erange(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eoffsetIn_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eoffsetIn_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2eoffsetIn_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {99, 104, 97, 114, 97, 99, 116, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eoffsetIn_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {112, 111, 115, 105, 116, 105, 111, 110}};
Clo g_heff_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2412;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_it_243);
    v_x2_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop(v_it1_244);
      heff_drop(v_ru_24it_243_24Just);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_246 = heff_field(v_it1_244, 0);
      heff_take(v_it1_244, 1ULL);
      v_x2_2412 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_i_246});
      break;
    }
    case TAG_JFloat: {
      V v_x_247 = heff_field(v_it1_244, 0);
      heff_take(v_it1_244, 1ULL);
      V v_t_248 = heff_floatFloor(v_x_247);
      v_x2_2412 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_t_248});
      break;
    }
    case TAG_JString: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  V v_line_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2412);
    v_line_2414 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take(v_x2_2412, 1ULL);
    v_line_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
  V v_it_2416 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str3), v_t_2415}); V a_1 = v_params_241; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425;
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nothing: {
    heff_drop(v_it_2416);
    v_x2_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2417 = heff_field(v_it_2416, 0);
    V v_ru_24it_2416_24Just = heff_take_reuse(v_it_2416, 1ULL);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_JNull: {
      heff_drop(v_it1_2417);
      heff_drop(v_ru_24it_2416_24Just);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_2417, 0ULL);
      heff_drop(v_ru_24it_2416_24Just);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_2419 = heff_field(v_it1_2417, 0);
      heff_take(v_it1_2417, 1ULL);
      v_x2_2425 = heff_tag_at(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_i_2419});
      break;
    }
    case TAG_JFloat: {
      V v_x_2420 = heff_field(v_it1_2417, 0);
      heff_take(v_it1_2417, 1ULL);
      V v_t_2421 = heff_floatFloor(v_x_2420);
      v_x2_2425 = heff_tag_at(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_t_2421});
      break;
    }
    case TAG_JString: {
      heff_take(v_it1_2417, 0ULL);
      heff_drop(v_ru_24it_2416_24Just);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_2417, 0ULL);
      heff_drop(v_ru_24it_2416_24Just);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_2417, 0ULL);
      heff_drop(v_ru_24it_2416_24Just);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2417);
    }
    break;
  }
  default: heff_nomatch(v_it_2416);
  }
  V v_ch_2427;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2425);
    v_ch_2427 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take(v_x2_2425, 1ULL);
    v_ch_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  return (g_heff_2elsp_2eoffsetGo(v_src_240, v_line_2414, v_ch_2427, MK_INT(0LL), MK_INT(0LL)));
}
V g_heff_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eoffsetIn(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ediagnostic_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ediagnostic_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 101, 118, 101, 114, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ediagnostic_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 111, 117, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ediagnostic_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {87}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 111, 100, 101}};
Clo g_heff_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str0), (g_heff_2elsp_2erange(v_src_240, heff_get(heff_dup(v_d_241), LBL_span)))});
  V v_t_243 = heff_get(heff_dup(v_d_241), LBL_severity);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    heff_drop(v_t_243);
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    heff_drop(v_t_243);
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    heff_drop(v_t_243);
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str1), heff_tag(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str2), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ediagnostic_str3)})});
  V v_t_247 = heff_get(heff_dup(v_d_241), LBL_note);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_t_247);
    v_t_249 = heff_get(heff_dup(v_d_241), LBL_msg);
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    v_t_249 = heff_strAppend(heff_get(heff_dup(v_d_241), LBL_msg), heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str4), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str5), heff_tag(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_intEq(heff_get(heff_dup(v_d_241), LBL_code), MK_INT(0LL));
  V v_t_2423;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_d_241);
    heff_drop(v_t_2413);
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2413);
    V v_t_2414 = heff_get(heff_dup(v_d_241), LBL_severity);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_SError: {
      heff_drop(v_t_2414);
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      heff_drop(v_t_2414);
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      heff_drop(v_t_2414);
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2416 = heff_intShow(heff_get(heff_dup(v_d_241), LBL_code));
    V v_t_2417 = heff_intShow(heff_get(heff_dup(v_d_241), LBL_code));
    V v_t_2418 = heff_strLength(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str9), v_t_2417));
    V v_t_2419 = heff_intShow(heff_get(v_d_241, LBL_code));
    V v_t_2420 = heff_strLength(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str10), v_t_2419));
    V v_t_2421 = heff_strSlice(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str11), v_t_2416), heff_intSub(v_t_2418, MK_INT(4LL)), v_t_2420);
    V v_t_2422 = heff_tag(TAG_JString, 1, (V[]){heff_strAppend(v_t_2415, v_t_2421)});
    v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str12), v_t_2422}), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  return heff_tag(TAG_JObject, 1, (V[]){(g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2412}), v_t_2423))});
}
V g_heff_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ediagnostic(a[0], a[1]);
}

static V g_heff_2elsp_2ezeroSpan_val;
static int g_heff_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2ezeroSpan_init(void) {
  return heff_rec(2, shape_305_78, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2ezeroSpan_get(void) {
  if (g_heff_2elsp_2ezeroSpan_st == 2) return g_heff_2elsp_2ezeroSpan_val;
  if (g_heff_2elsp_2ezeroSpan_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ezeroSpan_st = 1;
  g_heff_2elsp_2ezeroSpan_val = heff_tr(g_heff_2elsp_2ezeroSpan_init());
  g_heff_2elsp_2ezeroSpan_st = 2;
  return g_heff_2elsp_2ezeroSpan_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eloadError_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eloadError_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2elsp_2eloadError_lam0(V self, V *args);
Clo g_heff_2elsp_2eloadError_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadError_entry, 2, 0};

V g_heff_2elsp_2eloadError(V v_imports_240, V v_e_241) {
top: ;
  V v_t_246 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2eloadError_lam0, 1, 1, (V[]){heff_dup(v_e_241)}), v_imports_240));
  V v_sp_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_t_246);
    v_sp_248 = heff_dup(g_heff_2elsp_2ezeroSpan_get());
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    v_sp_248 = heff_get(v_i_247, LBL_span);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_rec(5, shape_44_284_185_299_197, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_241, v_sp_248, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2eloadError_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eloadError(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2eloadError_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_e_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_243 = heff_strAppend(((V)&g_heff_2elsp_2eloadError_str0), heff_strAppend(heff_get(v_i_242, LBL_name), ((V)&g_heff_2elsp_2eloadError_str1)));
  V v_x3_244 = (g_prelude_2eindexFrom(v_t_243, v_e_241, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_x3_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take(v_x3_244, 0ULL);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ebrokenImport_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ebrokenImport_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ebrokenImport_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ebrokenImport_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2ebrokenImport_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {41, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ebrokenImport_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 101, 114, 114, 111, 114}};
V g_heff_2elsp_2ebrokenImport_lam0(V self, V *args);
V g_heff_2elsp_2ebrokenImport_lam1(V self, V *args);
Clo g_heff_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_prelude_2efilter_24s519(heff_get(heff_dup(v_c_241), LBL_diags)));
  V v_x1_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_x1_242);
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_x1_242, 0ULL);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    heff_drop(v_x1_245);
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_245);
    v_t_247 = (g_prelude_2eany(heff_clo(g_heff_2elsp_2ebrokenImport_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_t_247);
    V v_t_249 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2ebrokenImport_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    V v_sp_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_249);
      v_sp_2411 = heff_dup(g_heff_2elsp_2ezeroSpan_get());
      break;
    }
    case TAG_Just: {
      V v_i_2410 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      v_sp_2411 = heff_get(v_i_2410, LBL_span);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_xs_2412 = (g_prelude_2efilter_24s519(heff_get(heff_dup(v_c_241), LBL_diags)));
    V v_t_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2412); r_; });
    V v_xs_2414 = (g_prelude_2efilter_24s519(heff_get(heff_dup(v_c_241), LBL_diags)));
    V v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2414); r_; });
    V v_t_2416 = heff_intEq(v_t_2415, MK_INT(1LL));
    V v_t_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_t_2416);
      v_t_2417 = ((V)&g_heff_2elsp_2ebrokenImport_str0);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2416);
      v_t_2417 = ((V)&g_heff_2elsp_2ebrokenImport_str1);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_msg_2418 = heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str2), heff_strAppend(heff_get(heff_dup(v_c_241), LBL_module), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str3), heff_strAppend(heff_get(v_c_241, LBL_path), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str4), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str5), v_t_2417)))))));
    V v_t_2419 = heff_rec(5, shape_44_284_185_299_197, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2418, v_sp_2411, NTAG(TAG_Nothing)});
    return heff_tag(TAG_Just, 1, (V[]){v_t_2419});
  }
  case TAG_False: {
    heff_drop(v_c_241);
    heff_drop(v_t_247);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2ebrokenImport(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2ebrokenImport_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_i_246, LBL_name), heff_get(v_c_241, LBL_module));
}
V g_heff_2elsp_2ebrokenImport_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_i_248, LBL_name), heff_get(v_c_241, LBL_module));
}
Clo g_heff_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x11_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take(v_x11_241, 1ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2elsp_2ecatMaybesL(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ecatMaybesL(a[0]);
}
V g_heff_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_x1_243);
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take(v_x1_243, 1ULL);
    v_t_246 = heff_get(v_x_244, LBL_diags);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_program_241));
  V v_xs_2411 = (g_prelude_2edrop(MK_INT(1LL), v_t_2410));
  V v_t_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2411));
  V v_t_2415 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2412));
  V v_t_2416 = (g_heff_2elsp_2ecatMaybesL(v_t_2415));
  V v_t_2417 = (g_prelude_2econcatList(v_t_249, v_t_2416));
  return (g_prelude_2econcatList(v_t_246, v_t_2417));
}
V g_heff_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get(v_t_248, LBL_imports); V a_1 = v_e_247; V r_ = (g_heff_2elsp_2eloadError(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2413 = args[0];
  V v_src_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get(v_t_2414, LBL_imports); V a_1 = v_c_2413; V r_ = (g_heff_2elsp_2ebrokenImport(b_0, a_1)); heff_drop(b_0); r_; });
}
Clo g_heff_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    heff_drop(v_x1_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse(v_x1_241, 1ULL);
    V v_t_244 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = (g_prelude_2edrop(MK_INT(1LL), v_t_244));
    V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_prelude_2emap_24s830(v_t_246));
    V v_t_248 = (g_heff_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2econcatList(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ekeptOf(a[0]);
}
V g_heff_2elsp_2edependentsOf_lam1(V self, V *args);
V g_heff_2elsp_2edependentsOf_lam0(V self, V *args);
Clo g_heff_2elsp_2edependentsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edependentsOf_entry, 2, 0};

V g_heff_2elsp_2edependentsOf(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(v_st_240, LBL_checked); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2edependentsOf_lam0, 1, 1, (V[]){v_f_241}), v_t_242));
  return (g_prelude_2emap_24s5(v_t_2412));
}
V g_heff_2elsp_2edependentsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edependentsOf(a[0], a[1]);
}
V g_heff_2elsp_2edependentsOf_lam1(V self, V *args) {
  V v_c_2411 = args[0];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_c_2411, LBL_path), v_f_241);
}
V g_heff_2elsp_2edependentsOf_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_x1_247 = heff_strEq(v_t_246, heff_dup(v_f_241));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    heff_drop(v_p_243);
    heff_drop(v_f_241);
    heff_drop(v_x1_247);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_247);
    V v_t_2410;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_p_243, 1);
      heff_take(v_p_243, 2ULL);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    return ({ V a_0 = heff_clo(g_heff_2elsp_2edependentsOf_lam1, 1, 1, (V[]){v_f_241}); V b_1 = heff_get(v_t_2410, LBL_program); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2elsp_2enubPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubPaths_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2elsp_2enubPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2enubPaths_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2enubSources_lam0(V self, V *args);
Clo g_heff_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubSources_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_ss_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_241, (g_heff_2elsp_2enubSources(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubSources(a[0]);
}
V g_heff_2elsp_2enubSources_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_s_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(heff_get(v_t_243, LBL_path), heff_get(v_s_241, LBL_path));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ecapabilities_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 104, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2ecapabilities_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {105, 110, 99, 108, 117, 100, 101, 84, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2ecapabilities_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {111, 112, 101, 110, 67, 108, 111, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2elsp_2ecapabilities_str4 = {{0x80000000u, K_STR, 0}, 16, 16, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 83, 121, 110, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ecapabilities_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2elsp_2ecapabilities_str6 = {{0x80000000u, K_STR, 0}, 17, 17, {116, 114, 105, 103, 103, 101, 114, 67, 104, 97, 114, 97, 99, 116, 101, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str7 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2elsp_2ecapabilities_str8 = {{0x80000000u, K_STR, 0}, 15, 15, {112, 114, 101, 112, 97, 114, 101, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2ecapabilities_str9 = {{0x80000000u, K_STR, 0}, 14, 14, {114, 101, 110, 97, 109, 101, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2ecapabilities_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {119, 111, 114, 107, 115, 112, 97, 99, 101, 83, 121, 109, 98, 111, 108, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2ecapabilities_str11 = {{0x80000000u, K_STR, 0}, 22, 22, {100, 111, 99, 117, 109, 101, 110, 116, 83, 121, 109, 98, 111, 108, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {114, 101, 102, 101, 114, 101, 110, 99, 101, 115, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2elsp_2ecapabilities_str13 = {{0x80000000u, K_STR, 0}, 26, 26, {100, 111, 99, 117, 109, 101, 110, 116, 70, 111, 114, 109, 97, 116, 116, 105, 110, 103, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str14 = {{0x80000000u, K_STR, 0}, 18, 18, {100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2ecapabilities_str15 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 111, 118, 101, 114, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str16 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2ecapabilities_str18 = {{0x80000000u, K_STR, 0}, 10, 10, {115, 101, 114, 118, 101, 114, 73, 110, 102, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2ecapabilities_str19 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 112, 97, 98, 105, 108, 105, 116, 105, 101, 115}};

static V g_heff_2elsp_2ecapabilities_val;
static int g_heff_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str0), heff_tag(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str2), heff_tag(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str4), heff_tag(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str6), heff_tag(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str7), heff_tag(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str9), heff_tag(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str10), heff_dup(g_heff_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str11), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2412});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str12), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str13), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2414})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2415});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2416});
  V v_t_2418 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_t_2417})});
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str16), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ecapabilities_str17)})});
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str18), heff_tag(TAG_JObject, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str19), v_t_2418}), v_t_2422});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2ecapabilities_get(void) {
  if (g_heff_2elsp_2ecapabilities_st == 2) return g_heff_2elsp_2ecapabilities_val;
  if (g_heff_2elsp_2ecapabilities_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ecapabilities_st = 1;
  g_heff_2elsp_2ecapabilities_val = heff_tr(g_heff_2elsp_2ecapabilities_init());
  g_heff_2elsp_2ecapabilities_st = 2;
  return g_heff_2elsp_2ecapabilities_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ehoverOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {109, 97, 114, 107, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {96, 96, 96, 104, 101, 102, 102, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ehoverOf_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {10, 96, 96, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ehoverOf_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 111, 110, 116, 101, 110, 116, 115}};
Clo g_heff_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_a_240), LBL_program)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_p_241);
    heff_drop(v_x1_242);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse(v_x1_242, 1ULL);
    V v_t_245 = (g_heff_2elsp_2eoffsetIn(heff_get(v_a_240, LBL_text), v_p_241));
    V v_t_246 = (g_heff_2equery_2etypeAt(v_x_243, v_t_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_ru_24x1_242_24Cons);
      heff_drop(v_t_246);
      return NTAG(TAG_JNull);
    }
    case TAG_Just: {
      V v_t_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Just = heff_take_reuse(v_t_246, 1ULL);
      V v_t_248 = heff_tag_at(v_ru_24x1_242_24Cons, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ehoverOf_str1)})});
      V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2ehoverOf_str2), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2ehoverOf_str3)));
      V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str4), heff_tag_at(v_ru_24t_246_24Just, TAG_JString, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      V v_t_2412 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2411})});
      V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str5), v_t_2412}), NTAG(TAG_Nil)});
      return heff_tag(TAG_JObject, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ehoverOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2echildJson_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2echildJson_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 101, 108, 101, 99, 116, 105, 111, 110, 82, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2echildJson_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2echildJson_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
Clo g_heff_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_m_241), LBL_name)});
  V v_t_243 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_m_241), LBL_kind)});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str0), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_get(heff_dup(v_m_241), LBL_span)))});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str1), (g_heff_2elsp_2erange(v_src_240, heff_get(v_m_241, LBL_span)))});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str2), v_t_243}), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str3), v_t_242}), v_t_247});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_248});
}
V g_heff_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echildJson(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2edocSymbol_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2edocSymbol_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 101, 108, 101, 99, 116, 105, 111, 110, 82, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2edocSymbol_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 104, 105, 108, 100, 114, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2edocSymbol_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2edocSymbol_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
V g_heff_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_t_242 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_y_241), LBL_name)});
  V v_t_243 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_y_241), LBL_kind)});
  V v_a_244 = heff_get(heff_get(heff_dup(v_y_241), LBL_span), LBL_end);
  V v_b_245 = heff_get(heff_get(heff_dup(v_y_241), LBL_selection), LBL_end);
  V v_t_246 = heff_intLe(heff_dup(v_a_244), heff_dup(v_b_245));
  V v_e_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_a_244);
    heff_drop(v_t_246);
    v_e_247 = v_b_245;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_245);
    heff_drop(v_t_246);
    v_e_247 = v_a_244;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = heff_get(heff_get(heff_dup(v_y_241), LBL_span), LBL_start);
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str0), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_rec(2, shape_305_78, (V[]){v_t_248, v_e_247})))});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str1), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_get(heff_dup(v_y_241), LBL_selection)))});
  V v_t_2412 = heff_tag(TAG_JArray, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), heff_get(v_y_241, LBL_children)))});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str2), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str3), v_t_243}), v_t_2414});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str4), v_t_242}), v_t_2415});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2416});
}
V g_heff_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_src_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2echildJson(v_src_240, v_m_2411));
}
Clo g_heff_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return v_acc_242;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V v_t_245 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(90LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_t_245);
        V v_t_246 = heff_intAdd(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL));
        v_t_247 = heff_strFromCharCode(v_t_246);
        break;
      }
      case TAG_False: {
        heff_drop(v_t_245);
        v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_247);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elowerGo(a[0], a[1], a[2]);
}
V g_heff_2elsp_2etargetIn_lam0(V self, V *args);
V g_heff_2elsp_2etargetIn_lam1(V self, V *args);
Clo g_heff_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  V v_t_246 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2etargetIn_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), v_program_244));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_d_242);
    heff_drop(v_p_243);
    heff_drop(v_program_244);
    heff_drop(v_t_246);
    return heff_rec(3, shape_303_201_318, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_c_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse(v_t_246, 1ULL);
    V v_t_248 = heff_strEq(heff_get(heff_dup(v_c_247), LBL_source), heff_get(heff_dup(v_d_242), LBL_text));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2etargetIn_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), heff_dup(v_program_244)));
      V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_c_247, NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2econcatList(v_t_2411, v_t_2412));
      V v_t_2414 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_d_242), LBL_text), heff_dup(v_p_243)));
      V v_t_2415 = (g_heff_2equery_2etargetAt(v_t_2413, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_f_241);
        heff_drop(v_d_242);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop(v_ru_24t_246_24Just);
        heff_drop(v_t_2415);
        return heff_rec(3, shape_303_201_318, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
      case TAG_Just: {
        V v_t_2416 = heff_field(v_t_2415, 0);
        heff_take(v_t_2415, 1ULL);
        V v_off_2417 = (g_heff_2elsp_2eoffsetIn(heff_get(v_d_242, LBL_text), v_p_243));
        V v_occurrences_2418 = (g_heff_2equery_2eoccurrences(v_program_244, heff_get(heff_dup(v_t_2416), LBL_target), heff_get(heff_dup(v_t_2416), LBL_name)));
        V v_t_2419 = heff_rec(4, shape_228_318_190_200, (V[]){v_f_241, heff_get(heff_dup(v_t_2416), LBL_target), heff_get(v_t_2416, LBL_name), v_occurrences_2418});
        V v_target_2420 = heff_tag_at(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2419});
        return heff_rec(3, shape_303_201_318, (V[]){v_st_240, v_off_2417, v_target_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      heff_drop(v_f_241);
      heff_drop(v_d_242);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop(v_c_247);
      heff_drop(v_ru_24t_246_24Just);
      heff_drop(v_t_248);
      return heff_rec(3, shape_303_201_318, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2etargetIn_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_c_245, LBL_path), v_f_241);
}
V g_heff_2elsp_2etargetIn_lam1(V self, V *args) {
  V v_c2_249 = args[0];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2410 = heff_strEq(heff_get(v_c2_249, LBL_path), v_f_241);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_2410);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erenamedText_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2erenamedText_lam0(V self, V *args);
Clo g_heff_2elsp_2erenamedText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamedText_entry, 2, 0};

V g_heff_2elsp_2erenamedText(V v_new_240, V v_os_241) {
top: ;
  V v_z_244;
  switch (heff_tag_of(v_os_241)) {
  case TAG_Nil: {
    v_z_244 = ((V)&g_heff_2elsp_2erenamedText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_os_241, 0));
    v_z_244 = heff_get(v_x_242, LBL_source);
    break;
  }
  default: heff_nomatch(v_os_241);
  }
  V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_os_241));
  return ({ V a_0 = heff_clo(g_heff_2elsp_2erenamedText_lam0, 2, 1, (V[]){v_new_240}); V a_1 = v_z_244; V a_2 = v_t_245; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2elsp_2erenamedText_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamedText(a[0], a[1]);
}
V g_heff_2elsp_2erenamedText_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_new_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = heff_get(heff_get(heff_dup(v_x_247), LBL_span), LBL_start);
  V v_t_249 = heff_get(heff_get(v_x_247, LBL_span), LBL_end);
  V v_t_2410 = heff_strSlice(heff_dup(v_acc_246), v_t_249, heff_strLength(heff_dup(v_acc_246)));
  return heff_strAppend(heff_strSlice(v_acc_246, MK_INT(0LL), v_t_248), heff_strAppend(v_new_240, v_t_2410));
}
V g_heff_2elsp_2enubCheckedPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubCheckedPaths_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_cs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_241, (g_heff_2elsp_2enubCheckedPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubCheckedPaths(a[0]);
}
V g_heff_2elsp_2enubCheckedPaths_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(heff_get(v_d_243, LBL_path), heff_get(v_c_241, LBL_path));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2eshiftOf_lam0(V self, V *args);
Clo g_heff_2elsp_2eshiftOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eshiftOf_entry, 3, 0};

V g_heff_2elsp_2eshiftOf(V v_t_240, V v_new_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strLength(heff_get(heff_dup(v_t_240), LBL_name));
  V v_t_244 = heff_intSub(heff_strLength(v_new_241), v_t_243);
  V v_xs_248 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2eshiftOf_lam0, 1, 2, (V[]){heff_dup(v_t_240), v_b_242}), heff_get(v_t_240, LBL_occurrences)));
  V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_248); r_; });
  return heff_intMul(v_t_244, v_t_249);
}
V g_heff_2elsp_2eshiftOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eshiftOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eshiftOf_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_t_240 = heff_dup(heff_env(self)[0]);
  V v_b_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_strEq(heff_get(heff_dup(v_o_245), LBL_path), heff_get(v_t_240, LBL_path));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    V v_t_247 = heff_get(heff_get(v_o_245, LBL_span), LBL_start);
    return heff_intLt(v_t_247, heff_get(v_b_242, LBL_start));
  }
  case TAG_False: {
    heff_drop(v_o_245);
    heff_drop(v_b_242);
    heff_drop(v_t_246);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_local);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    V v_t_243 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_member);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      V v_t_244 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_key);
      V v_t_245 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_key);
      V v_t_246 = heff_strLength(heff_get(v_t_240, LBL_name));
      V v_t_247 = heff_intSub(heff_strLength(v_t_245), v_t_246);
      V v_t_248 = heff_strAppend(heff_strSlice(v_t_244, MK_INT(0LL), v_t_247), v_new_241);
      return heff_rec(3, shape_145_180_170, (V[]){v_t_248, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take(v_t_243, 0ULL);
      V v_t_2410 = heff_get(heff_get(v_t_240, LBL_target), LBL_key);
      return heff_rec(3, shape_145_180_170, (V[]){v_t_2410, heff_tag(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Just: {
    V v_b_2411 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    V v_t_2412 = (g_heff_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2411)));
    V v_s_2413 = heff_intAdd(heff_get(heff_dup(v_b_2411), LBL_start), v_t_2412);
    V v_t_2414 = (g_heff_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2411)));
    V v_t_2415 = heff_intAdd(heff_get(v_b_2411, LBL_start), v_t_2414);
    V v_e_2416 = heff_intAdd(v_t_2415, heff_strLength(v_new_241));
    V v_b_2417 = heff_rec(2, shape_305_78, (V[]){v_s_2413, v_e_2416});
    V v_t_2418 = heff_get(heff_get(v_t_240, LBL_target), LBL_key);
    return heff_rec(3, shape_145_180_170, (V[]){v_t_2418, NTAG(TAG_Nothing), heff_tag(TAG_Just, 1, (V[]){v_b_2417})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamedTarget(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erenameVerdict_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 101, 110, 97, 109, 105, 110, 103, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2erenameVerdict_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {96, 32, 116, 111, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2erenameVerdict_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {96, 32, 119, 111, 117, 108, 100, 32, 109, 97, 107, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2erenameVerdict_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 109, 111, 114, 101, 32, 101, 114, 114, 111, 114, 40, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erenameVerdict_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2elsp_2erenameVerdict_str5 = {{0x80000000u, K_STR, 0}, 60, 60, {96, 32, 105, 115, 32, 97, 108, 114, 101, 97, 100, 121, 32, 97, 32, 110, 97, 109, 101, 32, 115, 111, 109, 101, 32, 111, 102, 32, 116, 104, 101, 115, 101, 32, 111, 99, 99, 117, 114, 114, 101, 110, 99, 101, 115, 32, 119, 111, 117, 108, 100, 32, 114, 101, 102, 101, 114, 32, 116, 111}};
Clo g_heff_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_246 = heff_intLt(heff_dup(v_errorsBefore_243), heff_dup(v_errorsAfter_244));
  V v_t_2415;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_after_245);
    heff_drop(v_t_246);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str0), heff_strAppend(heff_get(v_t_241, LBL_name), heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str1), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str2), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2erenameVerdict_str3)))))));
    v_t_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_248});
    break;
  }
  case TAG_False: {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    heff_drop(v_t_246);
    V v_t_249 = (g_heff_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2410 = (g_heff_2equery_2eoccurrences(v_after_245, v_t_249, heff_dup(v_new_242)));
    V v_a_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2410); r_; });
    V v_b_2412 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_t_241, LBL_occurrences); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2413 = heff_intEq(v_a_2411, v_b_2412);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_new_242);
      heff_drop(v_t_2413);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2413);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2erenameVerdict_str5)));
      v_t_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_before_240, LBL_st), v_t_2415});
}
V g_heff_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_c_243), LBL_path)}));
    V v_t_246 = (g_prelude_2eany(v_t_245, v_changed_240));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_mods_241});
      return heff_tag(TAG_Cons, 2, (V[]){heff_get(v_c_243, LBL_path), (g_heff_2elsp_2eaffectedGo(v_changed_240, v_t_247, v_rest_244))});
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V v_t_2410 = ({ V a_0 = heff_clo(g_heff_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V b_1 = heff_get(heff_dup(v_c_243), LBL_deps); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_mods_241});
        return heff_tag(TAG_Cons, 2, (V[]){heff_get(v_c_243, LBL_path), (g_heff_2elsp_2eaffectedGo(v_changed_240, v_t_2411, v_rest_244))});
      }
      case TAG_False: {
        heff_drop(v_c_243);
        heff_drop(v_ru_24x3_242_24Cons);
        heff_drop(v_t_2410);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eaffectedGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_mods_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_249 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_d_248}));
  return ({ V a_0 = v_t_249; V a_1 = v_mods_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2enubRoots_lam0(V self, V *args);
Clo g_heff_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubRoots_lam0, 1, 1, (V[]){heff_dup(v_r_241)}), v_rs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_r_241, (g_heff_2elsp_2enubRoots(v_t_2411))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubRoots(a[0]);
}
V g_heff_2elsp_2enubRoots_lam0(V self, V *args) {
  V v_q_243 = args[0];
  V v_r_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246;
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_q_243, 0);
    heff_take(v_q_243, 1ULL);
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_t_249;
  switch (heff_tag_of(v_r_241)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_r_241, 0);
    heff_take(v_r_241, 1ULL);
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_r_241);
  }
  V v_x1_2410 = heff_strEq(v_t_246, v_t_249);
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_True: {
    heff_drop(v_x1_2410);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_2410);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eregistration_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2eregistration_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2eregistration_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2eregistration_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 45, 119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2elsp_2eregistration_str5 = {{0x80000000u, K_STR, 0}, 25, 25, {99, 108, 105, 101, 110, 116, 47, 114, 101, 103, 105, 115, 116, 101, 114, 67, 97, 112, 97, 98, 105, 108, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2eregistration_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2eregistration_str7 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 45, 119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2eregistration_str9 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2eregistration_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {103, 108, 111, 98, 80, 97, 116, 116, 101, 114, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eregistration_str11 = {{0x80000000u, K_STR, 0}, 7, 7, {42, 42, 47, 42, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eregistration_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {119, 97, 116, 99, 104, 101, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2elsp_2eregistration_str13 = {{0x80000000u, K_STR, 0}, 15, 15, {114, 101, 103, 105, 115, 116, 101, 114, 79, 112, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2eregistration_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {114, 101, 103, 105, 115, 116, 114, 97, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};

static V g_heff_2elsp_2eregistration_val;
static int g_heff_2elsp_2eregistration_st;
static V g_heff_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str2), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str4), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str6), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str8), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str10), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str12), heff_tag(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str13), heff_tag(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str14), heff_tag(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str15), heff_tag(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2eregistration_get(void) {
  if (g_heff_2elsp_2eregistration_st == 2) return g_heff_2elsp_2eregistration_val;
  if (g_heff_2elsp_2eregistration_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2eregistration_st = 1;
  g_heff_2elsp_2eregistration_val = heff_tr(g_heff_2elsp_2eregistration_init());
  g_heff_2elsp_2eregistration_st = 2;
  return g_heff_2elsp_2eregistration_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2elastChange_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {99, 111, 110, 116, 101, 110, 116, 67, 104, 97, 110, 103, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2elastChange_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 120, 116}};
Clo g_heff_2elsp_2elastChange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elastChange_entry, 1, 0};

V g_heff_2elsp_2elastChange(V v_p_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elastChange_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V a_0 = v_t_241; V a_1 = v_p_240; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop(v_t_241); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    heff_drop(v_it_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse(v_it_242, 1ULL);
    V v_t_2410;
    switch (heff_tag_of(v_it1_243)) {
    case TAG_JNull: {
      heff_drop(v_it1_243);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_243, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_243, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_243, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take(v_it1_243, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      V v_xs_248 = heff_field(v_it1_243, 0);
      heff_take(v_it1_243, 1ULL);
      v_t_2410 = heff_tag_at(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_xs_248});
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_243, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_243);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop(v_t_2410);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_cs_2411 = heff_field(v_t_2410, 0);
      V v_ru_24t_2410_24Just = heff_take_reuse(v_t_2410, 1ULL);
      V v_x1_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_cs_2411));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        heff_drop(v_ru_24t_2410_24Just);
        heff_drop(v_x1_2412);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        V v_ru_24x1_2412_24Cons = heff_take_reuse(v_x1_2412, 1ULL);
        V v_t_2415 = heff_tag_at(v_ru_24x1_2412_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elastChange_str1), NTAG(TAG_Nil)});
        V v_it_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_2413; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop(v_t_2415); r_; });
        switch (heff_tag_of(v_it_2416)) {
        case TAG_Nothing: {
          heff_drop(v_ru_24t_2410_24Just);
          heff_drop(v_it_2416);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_it1_2417 = heff_field(v_it_2416, 0);
          heff_take(v_it_2416, 1ULL);
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            heff_drop(v_ru_24t_2410_24Just);
            heff_drop(v_it1_2417);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take(v_it1_2417, 0ULL);
            heff_drop(v_ru_24t_2410_24Just);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take(v_it1_2417, 0ULL);
            heff_drop(v_ru_24t_2410_24Just);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take(v_it1_2417, 0ULL);
            heff_drop(v_ru_24t_2410_24Just);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            V v_s_2421 = heff_field(v_it1_2417, 0);
            heff_take(v_it1_2417, 1ULL);
            return heff_tag_at(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){v_s_2421});
          }
          case TAG_JArray: {
            heff_take(v_it1_2417, 0ULL);
            heff_drop(v_ru_24t_2410_24Just);
            return NTAG(TAG_Nothing);
          }
          case TAG_JObject: {
            heff_take(v_it1_2417, 0ULL);
            heff_drop(v_ru_24t_2410_24Just);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2417);
          }
        }
        default: return heff_nomatch(v_it_2416);
        }
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2elastChange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elastChange(a[0]);
}
Clo g_heff_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  V v_t_243 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_text_242);
    heff_drop(v_t_243);
    return v_st_240;
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_245 = heff_rec(2, shape_344_321, (V[]){heff_get(v_d_244, LBL_uri), v_text_242});
    V v_d_246 = (g_map_2einsert_24s7(v_f_241, v_t_245, heff_get(heff_dup(v_st_240), LBL_docs)));
    return heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){v_d_246, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echanged(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_due); V r_ = (g_map_2edelete_24s831(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_243 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2edelete_24s831(a_0, b_1)); heff_drop(b_1); r_; });
  V v_d_244 = ({ V a_0 = v_f_241; V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2edelete_24s831(a_0, b_1)); heff_drop(b_1); r_; });
  V v_s_245 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){v_d_244, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  V v_s_246 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_s_245), LBL_docs), v_c_243, heff_get(heff_dup(v_s_245), LBL_due), heff_get(heff_dup(v_s_245), LBL_project), heff_get(heff_dup(v_s_245), LBL_watch), heff_get(heff_dup(v_s_245), LBL_shutdown), heff_get(v_s_245, LBL_lib)});
  return heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_s_246), LBL_docs), heff_get(heff_dup(v_s_246), LBL_checked), v_t_242, heff_get(heff_dup(v_s_246), LBL_project), heff_get(heff_dup(v_s_246), LBL_watch), heff_get(heff_dup(v_s_246), LBL_shutdown), heff_get(v_s_246, LBL_lib)});
}
V g_heff_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eclosed(a[0], a[1]);
}
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam1(V self, V *args); static Clo g_heff_2elsp_2ereadOpen_24s970_24s1158_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereadOpen_24s970_24s1158_lam1, 1, 0};
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam0(V self, V *args);
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam2(V self, V *args);
Clo g_heff_2elsp_2ereadOpen_24s970_24s1158_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereadOpen_24s970_24s1158_entry, 2, 0};

V g_heff_2elsp_2ereadOpen_24s970_24s1158(V v_st_240, V v_p_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_p_241); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    return heff_clo(g_heff_2elsp_2ereadOpen_24s970_24s1158_lam0, 2, 1, (V[]){v_p_241});
  }
  case TAG_Just: {
    V v_d_249 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    heff_drop(v_p_241);
    return heff_clo(g_heff_2elsp_2ereadOpen_24s970_24s1158_lam2, 2, 1, (V[]){v_d_249});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2ereadOpen_24s970_24s1158_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ereadOpen_24s970_24s1158(a[0], a[1]);
}
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam1(V self, V *args) {
  V v_t_245 = args[0];
  heff_drop(self);
  return v_t_245;
}
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_p_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_p_241, ((V)&g_heff_2elsp_2ereadOpen_24s970_24s1158_lam1_clo)})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_248, v_k2_244});
}
V g_heff_2elsp_2ereadOpen_24s970_24s1158_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_d_249, LBL_text)});
  return heff_tail(v_k_2411, 1, (V[]){v_t_2412});
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam0(V self, V *args); static Clo g_heff_2elsp_2erootsOf_24s978_24s1164_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erootsOf_24s978_24s1164_lam0, 2, 0};
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam3(V self, V *args);
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam2(V self, V *args);
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam1(V self, V *args);
Clo g_heff_2elsp_2erootsOf_24s978_24s1164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erootsOf_24s978_24s1164_entry, 2, 0};

V g_heff_2elsp_2erootsOf_24s978_24s1164(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2elsp_2erootsOf_24s978_24s1164_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_c_246 = (g_heff_2eload_2epathsFor_24s868_24s1082(heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_244)));
    return heff_clo(g_heff_2elsp_2erootsOf_24s978_24s1164_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erootsOf_24s978_24s1164(a[0], a[1]);
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_f_244 = heff_dup(heff_env(self)[1]);
  V v_k_248 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_x_249, LBL_root), v_f_244});
  return heff_tail(v_k_248, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411})});
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_f_244 = heff_dup(heff_env(self)[3]);
  V v_k_248 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2410 = (g_heff_2elsp_2erootsOf_24s978_24s1164(v_st_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2elsp_2erootsOf_24s978_24s1164_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248})});
}
V g_heff_2elsp_2erootsOf_24s978_24s1164_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  V v_f_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2elsp_2erootsOf_24s978_24s1164_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248})});
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam0(V self, V *args); static Clo g_heff_2elsp_2eloadAll_24s983_24s1169_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadAll_24s983_24s1169_lam0, 2, 0};
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam3(V self, V *args);
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam2(V self, V *args);
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam1(V self, V *args);
Clo g_heff_2elsp_2eloadAll_24s983_24s1169_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadAll_24s983_24s1169_entry, 3, 0};

V g_heff_2elsp_2eloadAll_24s983_24s1169(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2eloadAll_24s983_24s1169_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2eload_2eloadProgramWith_24s867_24s1159(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo(g_heff_2elsp_2eloadAll_24s983_24s1169_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eloadAll_24s983_24s1169(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_dup(heff_env(self)[0]);
  V v_k_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2413 = (g_prelude_2econcatList(heff_get(v_x_2410, LBL_sources), v_x_2412));
  return heff_tail(v_k_249, 1, (V[]){v_x_2413});
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_dup(heff_env(self)[0]);
  V v_lib_241 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_hd_248 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2eloadAll_24s983_24s1169(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2eloadAll_24s983_24s1169_lam3, 1, 2, (V[]){v_x_2410, v_k_249})});
}
V g_heff_2elsp_2eloadAll_24s983_24s1169_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_read_240 = heff_dup(heff_env(self)[1]);
  V v_lib_241 = heff_dup(heff_env(self)[2]);
  V v_rest_246 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2eloadAll_24s983_24s1169_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2edocPath_24s967_24s1196_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2edocPath_24s967_24s1196_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
V g_heff_2elsp_2edocPath_24s967_24s1196_lam0(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s967_24s1196_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s967_24s1196_lam0, 2, 0};
V g_heff_2elsp_2edocPath_24s967_24s1196_lam1(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s967_24s1196_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s967_24s1196_lam1, 2, 0};
V g_heff_2elsp_2edocPath_24s967_24s1196_lam3(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s967_24s1196_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s967_24s1196_lam3, 1, 0};
V g_heff_2elsp_2edocPath_24s967_24s1196_lam2(V self, V *args);
Clo g_heff_2elsp_2edocPath_24s967_24s1196_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s967_24s1196_entry, 1, 0};

V g_heff_2elsp_2edocPath_24s967_24s1196(V v_p_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2edocPath_24s967_24s1196_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2edocPath_24s967_24s1196_str1), v_t_241}); V a_1 = v_p_240; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    heff_drop(v_it_242);
    return ((V)&g_heff_2elsp_2edocPath_24s967_24s1196_lam0_clo);
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse(v_it_242, 1ULL);
    V v_t_2412;
    switch (heff_tag_of(v_it1_245)) {
    case TAG_JNull: {
      heff_drop(v_it1_245);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_245, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_245, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_245, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_249 = heff_field(v_it1_245, 0);
      heff_take(v_it1_245, 1ULL);
      v_t_2412 = heff_tag_at(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_s_249});
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_245, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_245, 0ULL);
      heff_drop(v_ru_24it_242_24Just);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_245);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop(v_t_2412);
      return ((V)&g_heff_2elsp_2edocPath_24s967_24s1196_lam1_clo);
    }
    case TAG_Just: {
      V v_u_2415 = heff_field(v_t_2412, 0);
      heff_take(v_t_2412, 1ULL);
      return heff_clo(g_heff_2elsp_2edocPath_24s967_24s1196_lam2, 2, 1, (V[]){v_u_2415});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2edocPath_24s967_24s1196_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edocPath_24s967_24s1196(a[0]);
}
V g_heff_2elsp_2edocPath_24s967_24s1196_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2edocPath_24s967_24s1196_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2413);
  return heff_tail(v_k_2414, 1, (V[]){NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2edocPath_24s967_24s1196_lam3(V self, V *args) {
  V v_p_2418 = args[0];
  heff_drop(self);
  return v_p_2418;
}
V g_heff_2elsp_2edocPath_24s967_24s1196_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_u_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_UriPath, 2, (V[]){v_u_2415, ((V)&g_heff_2elsp_2edocPath_24s967_24s1196_lam3_clo)})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_2416, LBL_bind), 2, (V[]){v_t_2420, v_k2_2417});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2enotify_24s971_24s1199_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotify_24s971_24s1199_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2enotify_24s971_24s1199_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2enotify_24s971_24s1199_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};
V g_heff_2elsp_2enotify_24s971_24s1199_lam1(V self, V *args);
V g_heff_2elsp_2enotify_24s971_24s1199_lam0(V self, V *args);
Clo g_heff_2elsp_2enotify_24s971_24s1199_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotify_24s971_24s1199_entry, 2, 0};

V g_heff_2elsp_2enotify_24s971_24s1199(V v_method_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s971_24s1199_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2enotify_24s971_24s1199_str1)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s971_24s1199_str2), heff_tag(TAG_JString, 1, (V[]){v_method_240})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s971_24s1199_str3), v_params_241}), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V b_0 = heff_tag(TAG_JObject, 1, (V[]){v_t_245}); V r_ = (g_heff_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_t_247 = heff_tag(TAG_Send, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
  V v_p_248 = heff_tag(TAG_InR, 1, (V[]){v_t_247});
  return heff_clo(g_heff_2elsp_2enotify_24s971_24s1199_lam0, 2, 1, (V[]){v_p_248});
}
V g_heff_2elsp_2enotify_24s971_24s1199_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotify_24s971_24s1199(a[0], a[1]);
}
V g_heff_2elsp_2enotify_24s971_24s1199_lam1(V self, V *args) {
  V v_c_2411 = args[0];
  V v_hd_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_249), heff_get(v_hd_249, LBL_ret)});
}
V g_heff_2elsp_2enotify_24s971_24s1199_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_p_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s857_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2enotify_24s971_24s1199_lam1, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2413, v_k2_2410});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {100, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str2 = {{0x80000000u, K_STR, 0}, 31, 31, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 117, 98, 108, 105, 115, 104, 68, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam0(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam1(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam5(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam7(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam8(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam6(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam4(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam3(V self, V *args);
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam2(V self, V *args);
Clo g_heff_2elsp_2echeck_24s969_24s1157_24s1198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeck_24s969_24s1157_24s1198_entry, 2, 0};

V g_heff_2elsp_2echeck_24s969_24s1157_24s1198(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_t_242);
    return heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    V v_c_247 = (g_heff_2eload_2eloadProgramWith_24s867_24s1159(heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam1, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_241)));
    return heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam2, 2, 4, (V[]){v_c_247, v_d_245, v_f_241, v_st_240});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echeck_24s969_24s1157_24s1198(a[0], a[1]);
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2ereadOpen_24s970_24s1158(v_st_240, v_p_246));
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2414);
  return heff_tail(v_k_2415, 1, (V[]){v_x_2413});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_d_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2ediagnostic(heff_get(v_d_245, LBL_text), v_x_2419));
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_d_245 = heff_dup(heff_env(self)[0]);
  V v_x_2417 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_rec(2, shape_321_246, (V[]){heff_get(v_d_245, LBL_text), v_x_2417});
  V v_c_2428 = (g_map_2einsert_24s7(v_f_241, v_t_2427, heff_get(heff_dup(v_st_240), LBL_checked)));
  V v_x_2429 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), v_c_2428, heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  return heff_tail(v_k_249, 1, (V[]){v_x_2429});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_d_245 = heff_dup(heff_env(self)[0]);
  V v_x_2410 = heff_dup(heff_env(self)[1]);
  V v_hd_248 = heff_dup(heff_env(self)[2]);
  V v_f_241 = heff_dup(heff_env(self)[3]);
  V v_st_240 = heff_dup(heff_env(self)[4]);
  V v_k_249 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2418 = (g_heff_2elsp_2ediagsOf(heff_get(heff_dup(v_d_245), LBL_text), heff_dup(v_x_2417), heff_get(v_x_2410, LBL_errors)));
  V v_ds_2420 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam7, 1, 1, (V[]){heff_dup(v_d_245)}), v_t_2418));
  V v_t_2421 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_d_245), LBL_uri)});
  V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str0), heff_tag(TAG_JArray, 1, (V[]){v_ds_2420})});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str1), v_t_2421}), v_t_2423});
  V v_c_2425 = (g_heff_2elsp_2enotify_24s971_24s1199(((V)&g_heff_2elsp_2echeck_24s969_24s1157_24s1198_str2), heff_tag(TAG_JObject, 1, (V[]){v_t_2424})));
  return heff_tail(v_c_2425, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam8, 1, 5, (V[]){v_d_245, v_x_2417, v_f_241, v_st_240, v_k_249})});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_248 = heff_dup(heff_env(self)[0]);
  V v_d_245 = heff_dup(heff_env(self)[1]);
  V v_x_2410 = heff_dup(heff_env(self)[2]);
  V v_f_241 = heff_dup(heff_env(self)[3]);
  V v_st_240 = heff_dup(heff_env(self)[4]);
  V v_k_249 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_x_2413 = (g_heff_2elsp_2ekeptOf(v_x_2412));
  V v_c_2416 = heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam5, 2, 1, (V[]){v_x_2413});
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam6, 1, 6, (V[]){v_d_245, v_x_2410, v_hd_248, v_f_241, v_st_240, v_k_249})});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_dup(heff_env(self)[0]);
  V v_d_245 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2411 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(heff_dup(v_x_2410)));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam4, 1, 6, (V[]){v_hd_248, v_d_245, v_x_2410, v_f_241, v_st_240, v_k_249})});
}
V g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_d_245 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2echeck_24s969_24s1157_24s1198_lam3, 1, 5, (V[]){v_hd_248, v_d_245, v_f_241, v_st_240, v_k_249})});
}
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam0(V self, V *args);
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam2(V self, V *args);
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam1(V self, V *args);
Clo g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_entry, 2, 0};

V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2echeck_24s969_24s1157_24s1198(v_st_240, heff_dup(v_f_244)));
    return heff_clo(g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_245 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_k_248 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2410, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197_lam2, 1, 3, (V[]){v_rest_245, v_hd_247, v_k_248})});
}
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam1(V self, V *args);
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam0(V self, V *args);
Clo g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_entry, 2, 0};

V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_due); V r_ = (g_map_2edelete_24s831(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_243 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), v_t_242, heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(heff_dup(v_st_240), LBL_lib)});
  V v_c_244 = (g_heff_2elsp_2echeck_24s969_24s1157_24s1198(v_t_243, heff_dup(v_f_241)));
  return heff_clo(g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam0, 2, 3, (V[]){v_c_244, v_st_240, v_f_241});
}
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(a[0], a[1]);
}
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_f_241 = heff_dup(heff_env(self)[1]);
  V v_hd_245 = heff_dup(heff_env(self)[2]);
  V v_k_246 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_248 = (g_heff_2elsp_2edependentsOf(v_st_240, v_f_241));
  V v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_t_248; V r_ = (g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(a_0, a_1)); heff_drop(v_t_248); r_; });
  return heff_tail(v_t_249, 2, (V[]){v_hd_245, v_k_246});
}
V g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_245, v_k_246})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 120, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {105, 110, 105, 116, 105, 97, 108, 105, 122, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str2 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str3 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 79, 112, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str8 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str10 = {{0x80000000u, K_STR, 0}, 22, 22, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str11 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 83, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str12 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 67, 108, 111, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str13 = {{0x80000000u, K_STR, 0}, 11, 11, {100, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str15 = {{0x80000000u, K_STR, 0}, 31, 31, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 117, 98, 108, 105, 115, 104, 68, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam3(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam2(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam4(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam5(V self, V *args); static Clo g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam5, 1, 0};
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam6(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam7(V self, V *args); static Clo g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam7, 2, 0};
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam8(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam1(V self, V *args);
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam0(V self, V *args);
Clo g_heff_2elsp_2enotified_24s966_24s1155_24s1195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s966_24s1155_24s1195_entry, 3, 0};

V g_heff_2elsp_2enotified_24s966_24s1155_24s1195(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2edocPath_24s967_24s1196(heff_dup(v_p_242)));
  return heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam0, 2, 4, (V[]){v_c_243, v_m_241, v_st_240, v_p_242});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotified_24s966_24s1155_24s1195(a[0], a[1], a[2]);
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam3(V self, V *args) {
  V v_c_2419 = args[0];
  V v_hd_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_2417), heff_get(v_hd_2417, LBL_ret)});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_p_2416 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s857_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam3, 1, 1, (V[]){heff_dup(v_hd_2417)}), v_p_2416}));
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2421, v_k2_2418});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2423);
  return heff_tail(v_k_245, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam5(V self, V *args) {
  V v_n_2460 = args[0];
  heff_drop(self);
  return v_n_2460;
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam6(V self, V *args) {
  V v_x_2463 = args[0];
  V v_f_2428 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_text_2459 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2464 = (g_map_2einsert_24s7(heff_dup(v_f_2428), heff_intAdd(v_x_2463, MK_INT(200LL)), heff_get(heff_dup(v_st_240), LBL_due)));
  V v_s_2465 = (g_heff_2elsp_2echanged(v_st_240, v_f_2428, v_text_2459));
  V v_x_2466 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_s_2465), LBL_docs), heff_get(heff_dup(v_s_2465), LBL_checked), v_t_2464, heff_get(heff_dup(v_s_2465), LBL_project), heff_get(heff_dup(v_s_2465), LBL_watch), heff_get(heff_dup(v_s_2465), LBL_shutdown), heff_get(v_s_2465, LBL_lib)});
  return heff_tail(v_k_245, 1, (V[]){v_x_2466});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam7(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2471);
  return heff_tail(v_k_2472, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam8(V self, V *args) {
  V v_x_2479 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_f_2428 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2479);
  V v_x_2480 = (g_heff_2elsp_2eclosed(v_st_240, v_f_2428));
  return heff_tail(v_k_245, 1, (V[]){v_x_2480});
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  V v_p_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_247 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str0));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    heff_drop(v_t_247);
    V v_t_248 = heff_get(v_st_240, LBL_shutdown);
    V v_code_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      v_code_249 = MK_INT(0LL);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      v_code_249 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Quit, 1, (V[]){v_code_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2411, v_k_245});
  }
  case TAG_False: {
    heff_drop(v_t_247);
    V v_t_2412 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str1));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      heff_drop(v_t_2412);
      V v_t_2413 = heff_get(heff_dup(v_st_240), LBL_watch);
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop(v_t_2413);
        V v_t_2414 = ({ V b_0 = heff_dup(g_heff_2elsp_2eregistration_get()); V r_ = (g_heff_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_t_2415 = heff_tag(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_p_2416 = heff_tag(TAG_InR, 1, (V[]){v_t_2415});
        V v_c_2422 = heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam2, 2, 1, (V[]){v_p_2416});
        return heff_tail(v_c_2422, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam4, 1, 2, (V[]){v_k_245, v_st_240})});
      }
      case TAG_False: {
        heff_drop(v_hd_244);
        heff_drop(v_t_2413);
        return heff_tail(v_k_245, 1, (V[]){v_st_240});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_False: {
      heff_drop(v_t_2412);
      V v_t_2424 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str2));
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        heff_drop(v_t_2424);
        V v_t_2425 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_docs); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2426 = (g_prelude_2emap_24s5(v_t_2425));
        V v_t_2427 = ({ V a_0 = v_st_240; V a_1 = v_t_2426; V r_ = (g_heff_2elsp_2echeckAll_24s968_24s1156_24s1197(a_0, a_1)); heff_drop(v_t_2426); r_; });
        return heff_tail(v_t_2427, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_False: {
        heff_drop(v_t_2424);
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_x_246);
          heff_drop(v_m_241);
          heff_drop(v_hd_244);
          heff_drop(v_p_242);
          return heff_tail(v_k_245, 1, (V[]){v_st_240});
        }
        case TAG_Just: {
          V v_f_2428 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse(v_x_246, 1ULL);
          V v_t_2429 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str3));
          switch (heff_tag_of(v_t_2429)) {
          case TAG_True: {
            heff_drop(v_m_241);
            heff_drop(v_t_2429);
            V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str4), NTAG(TAG_Nil)});
            V v_it_2431 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str5), v_t_2430}); V a_1 = heff_dup(v_p_242); V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2439;
            switch (heff_tag_of(v_it_2431)) {
            case TAG_Nothing: {
              heff_drop(v_ru_24x_246_24Just);
              heff_drop(v_it_2431);
              v_x2_2439 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2432 = heff_field(v_it_2431, 0);
              heff_take(v_it_2431, 1ULL);
              switch (heff_tag_of(v_it1_2432)) {
              case TAG_JNull: {
                heff_drop(v_ru_24x_246_24Just);
                heff_drop(v_it1_2432);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take(v_it1_2432, 0ULL);
                heff_drop(v_ru_24x_246_24Just);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take(v_it1_2432, 0ULL);
                heff_drop(v_ru_24x_246_24Just);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take(v_it1_2432, 0ULL);
                heff_drop(v_ru_24x_246_24Just);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2436 = heff_field(v_it1_2432, 0);
                heff_take(v_it1_2432, 1ULL);
                v_x2_2439 = heff_tag_at(v_ru_24x_246_24Just, TAG_Just, 1, (V[]){v_s_2436});
                break;
              }
              case TAG_JArray: {
                heff_take(v_it1_2432, 0ULL);
                heff_drop(v_ru_24x_246_24Just);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take(v_it1_2432, 0ULL);
                heff_drop(v_ru_24x_246_24Just);
                v_x2_2439 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2432);
              }
              break;
            }
            default: heff_nomatch(v_it_2431);
            }
            V v_uri_2441;
            switch (heff_tag_of(v_x2_2439)) {
            case TAG_Nothing: {
              heff_drop(v_x2_2439);
              v_uri_2441 = ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str6);
              break;
            }
            case TAG_Just: {
              V v_x_2440 = heff_field(v_x2_2439, 0);
              heff_take(v_x2_2439, 1ULL);
              v_uri_2441 = v_x_2440;
              break;
            }
            default: heff_nomatch(v_x2_2439);
            }
            V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str7), NTAG(TAG_Nil)});
            V v_it_2443 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str8), v_t_2442}); V a_1 = v_p_242; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2451;
            switch (heff_tag_of(v_it_2443)) {
            case TAG_Nothing: {
              heff_drop(v_it_2443);
              v_x2_2451 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2444 = heff_field(v_it_2443, 0);
              V v_ru_24it_2443_24Just = heff_take_reuse(v_it_2443, 1ULL);
              switch (heff_tag_of(v_it1_2444)) {
              case TAG_JNull: {
                heff_drop(v_it1_2444);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take(v_it1_2444, 0ULL);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take(v_it1_2444, 0ULL);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take(v_it1_2444, 0ULL);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2448 = heff_field(v_it1_2444, 0);
                heff_take(v_it1_2444, 1ULL);
                v_x2_2451 = heff_tag_at(v_ru_24it_2443_24Just, TAG_Just, 1, (V[]){v_s_2448});
                break;
              }
              case TAG_JArray: {
                heff_take(v_it1_2444, 0ULL);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take(v_it1_2444, 0ULL);
                heff_drop(v_ru_24it_2443_24Just);
                v_x2_2451 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2444);
              }
              break;
            }
            default: heff_nomatch(v_it_2443);
            }
            V v_text_2453;
            switch (heff_tag_of(v_x2_2451)) {
            case TAG_Nothing: {
              heff_drop(v_x2_2451);
              v_text_2453 = ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str9);
              break;
            }
            case TAG_Just: {
              V v_x_2452 = heff_field(v_x2_2451, 0);
              heff_take(v_x2_2451, 1ULL);
              v_text_2453 = v_x_2452;
              break;
            }
            default: heff_nomatch(v_x2_2451);
            }
            V v_d_2454 = (g_map_2einsert_24s7(heff_dup(v_f_2428), heff_rec(2, shape_344_321, (V[]){v_uri_2441, v_text_2453}), heff_get(heff_dup(v_st_240), LBL_docs)));
            V v_t_2455 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){v_d_2454, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
            V v_t_2456 = (g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(v_t_2455, v_f_2428));
            return heff_tail(v_t_2456, 2, (V[]){v_hd_244, v_k_245});
          }
          case TAG_False: {
            heff_drop(v_t_2429);
            V v_t_2457 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str10));
            switch (heff_tag_of(v_t_2457)) {
            case TAG_True: {
              heff_drop(v_m_241);
              heff_drop(v_t_2457);
              V v_t_2458 = (g_heff_2elsp_2elastChange(v_p_242));
              switch (heff_tag_of(v_t_2458)) {
              case TAG_Nothing: {
                heff_drop(v_hd_244);
                heff_drop(v_f_2428);
                heff_drop(v_ru_24x_246_24Just);
                heff_drop(v_t_2458);
                return heff_tail(v_k_245, 1, (V[]){v_st_240});
              }
              case TAG_Just: {
                V v_text_2459 = heff_field(v_t_2458, 0);
                heff_take(v_t_2458, 1ULL);
                V v_t_2461 = heff_tag_at(v_ru_24x_246_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam5_clo)})});
                V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2461}));
                return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2462, heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam6, 1, 4, (V[]){v_f_2428, v_st_240, v_text_2459, v_k_245})});
              }
              default: return heff_nomatch(v_t_2458);
              }
            }
            case TAG_False: {
              heff_drop(v_p_242);
              heff_drop(v_t_2457);
              V v_t_2467 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str11));
              switch (heff_tag_of(v_t_2467)) {
              case TAG_True: {
                heff_drop(v_m_241);
                heff_drop(v_ru_24x_246_24Just);
                heff_drop(v_t_2467);
                V v_t_2468 = (g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(v_st_240, v_f_2428));
                return heff_tail(v_t_2468, 2, (V[]){v_hd_244, v_k_245});
              }
              case TAG_False: {
                heff_drop(v_t_2467);
                V v_t_2469 = heff_strEq(v_m_241, ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str12));
                switch (heff_tag_of(v_t_2469)) {
                case TAG_True: {
                  heff_drop(v_t_2469);
                  V v_t_2470 = ({ V a_0 = heff_dup(v_f_2428); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
                  V v_c_2478;
                  switch (heff_tag_of(v_t_2470)) {
                  case TAG_Nothing: {
                    heff_drop(v_ru_24x_246_24Just);
                    heff_drop(v_t_2470);
                    v_c_2478 = ((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam7_clo);
                    break;
                  }
                  case TAG_Just: {
                    V v_d_2473 = heff_field(v_t_2470, 0);
                    V v_ru_24t_2470_24Just = heff_take_reuse(v_t_2470, 1ULL);
                    V v_t_2474 = heff_tag_at(v_ru_24x_246_24Just, TAG_JString, 1, (V[]){heff_get(v_d_2473, LBL_uri)});
                    V v_t_2475 = heff_tag_at(v_ru_24t_2470_24Just, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
                    V v_t_2476 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str13), v_t_2475}), NTAG(TAG_Nil)});
                    V v_t_2477 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str14), v_t_2474}), v_t_2476});
                    v_c_2478 = (g_heff_2elsp_2enotify_24s971_24s1199(((V)&g_heff_2elsp_2enotified_24s966_24s1155_24s1195_str15), heff_tag(TAG_JObject, 1, (V[]){v_t_2477})));
                    break;
                  }
                  default: heff_nomatch(v_t_2470);
                  }
                  return heff_tail(v_c_2478, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam8, 1, 3, (V[]){v_st_240, v_f_2428, v_k_245})});
                }
                case TAG_False: {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2428);
                  heff_drop(v_ru_24x_246_24Just);
                  heff_drop(v_t_2469);
                  return heff_tail(v_k_245, 1, (V[]){v_st_240});
                }
                default: return heff_nomatch(v_t_2469);
                }
              }
              default: return heff_nomatch(v_t_2467);
              }
            }
            default: return heff_nomatch(v_t_2457);
            }
          }
          default: return heff_nomatch(v_t_2429);
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  V v_p_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2enotified_24s966_24s1155_24s1195_lam1, 1, 5, (V[]){v_m_241, v_st_240, v_hd_244, v_k_245, v_p_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2enotification_24s965_24s1154_24s1194_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotification_24s965_24s1154_24s1194_str1 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
Clo g_heff_2elsp_2enotification_24s965_24s1154_24s1194_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotification_24s965_24s1154_24s1194_entry, 3, 0};

V g_heff_2elsp_2enotification_24s965_24s1154_24s1194(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_m_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2elsp_2enotification_24s965_24s1154_24s1194_str0));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    v_t_245 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
    break;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotification_24s965_24s1154_24s1194_str1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      v_t_245 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_t_245 = v_st_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return (g_heff_2elsp_2enotified_24s966_24s1155_24s1195(v_t_245, v_m_241, v_p_242));
}
V g_heff_2elsp_2enotification_24s965_24s1154_24s1194_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotification_24s965_24s1154_24s1194(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ereplyError_24s973_24s1201_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
V g_heff_2elsp_2ereplyError_24s973_24s1201_lam1(V self, V *args);
V g_heff_2elsp_2ereplyError_24s973_24s1201_lam0(V self, V *args);
Clo g_heff_2elsp_2ereplyError_24s973_24s1201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereplyError_24s973_24s1201_entry, 3, 0};

V g_heff_2elsp_2ereplyError_24s973_24s1201(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str1)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str2), heff_tag(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str3), heff_tag(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s973_24s1201_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_tag(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_p_2413 = heff_tag(TAG_InR, 1, (V[]){v_t_2412});
  return heff_clo(g_heff_2elsp_2ereplyError_24s973_24s1201_lam0, 2, 1, (V[]){v_p_2413});
}
V g_heff_2elsp_2ereplyError_24s973_24s1201_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ereplyError_24s973_24s1201(a[0], a[1], a[2]);
}
V g_heff_2elsp_2ereplyError_24s973_24s1201_lam1(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2414), heff_get(v_hd_2414, LBL_ret)});
}
V g_heff_2elsp_2ereplyError_24s973_24s1201_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_p_2413 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s857_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2ereplyError_24s973_24s1201_lam1, 1, 1, (V[]){heff_dup(v_hd_2414)}), v_p_2413}));
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2418, v_k2_2415});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereply_24s975_24s1203_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2ereply_24s975_24s1203_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ereply_24s975_24s1203_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 101, 115, 117, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ereply_24s975_24s1203_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
V g_heff_2elsp_2ereply_24s975_24s1203_lam1(V self, V *args);
V g_heff_2elsp_2ereply_24s975_24s1203_lam0(V self, V *args);
Clo g_heff_2elsp_2ereply_24s975_24s1203_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereply_24s975_24s1203_entry, 2, 0};

V g_heff_2elsp_2ereply_24s975_24s1203(V v_id_240, V v_result_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s975_24s1203_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ereply_24s975_24s1203_str1)})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s975_24s1203_str2), v_result_241}), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s975_24s1203_str3), v_id_240}), v_t_243});
  V v_t_245 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = heff_tag(TAG_Send, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
  V v_p_248 = heff_tag(TAG_InR, 1, (V[]){v_t_247});
  return heff_clo(g_heff_2elsp_2ereply_24s975_24s1203_lam0, 2, 1, (V[]){v_p_248});
}
V g_heff_2elsp_2ereply_24s975_24s1203_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ereply_24s975_24s1203(a[0], a[1]);
}
V g_heff_2elsp_2ereply_24s975_24s1203_lam1(V self, V *args) {
  V v_c_2411 = args[0];
  V v_hd_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_249), heff_get(v_hd_249, LBL_ret)});
}
V g_heff_2elsp_2ereply_24s975_24s1203_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_p_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s857_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2ereply_24s975_24s1203_lam1, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2413, v_k2_2410});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam2(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam3(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam1(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam0(V self, V *args);
Clo g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_entry, 2, 0};

V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2edocPath_24s967_24s1196(v_p_241));
  return heff_clo(g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(a[0], a[1]);
}
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_d_2410 = heff_dup(heff_env(self)[0]);
  V v_f_247 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_text_2414 = heff_get(v_d_2410, LBL_text);
  V v_t_2415 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_x_2413), LBL_checked); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    heff_drop(v_t_2415);
    v_x_2418 = heff_rec(3, shape_303_321_246, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_2415, 0);
    heff_take(v_t_2415, 1ULL);
    V v_t_2417 = heff_strEq(heff_get(heff_dup(v_c_2416), LBL_text), heff_dup(v_text_2414));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_t_2417);
      v_x_2418 = heff_rec(3, shape_303_321_246, (V[]){v_x_2413, v_text_2414, heff_get(v_c_2416, LBL_program)});
      break;
    }
    case TAG_False: {
      heff_drop(v_c_2416);
      heff_drop(v_t_2417);
      v_x_2418 = heff_rec(3, shape_303_321_246, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  return heff_tail(v_k_244, 1, (V[]){v_x_2418});
}
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_2410 = heff_dup(heff_env(self)[0]);
  V v_f_247 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_text_2428 = heff_get(v_d_2410, LBL_text);
  V v_t_2429 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_x_2427), LBL_checked); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    heff_drop(v_t_2429);
    v_x_2432 = heff_rec(3, shape_303_321_246, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2430 = heff_field(v_t_2429, 0);
    heff_take(v_t_2429, 1ULL);
    V v_t_2431 = heff_strEq(heff_get(heff_dup(v_c_2430), LBL_text), heff_dup(v_text_2428));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_t_2431);
      v_x_2432 = heff_rec(3, shape_303_321_246, (V[]){v_x_2427, v_text_2428, heff_get(v_c_2430, LBL_program)});
      break;
    }
    case TAG_False: {
      heff_drop(v_c_2430);
      heff_drop(v_t_2431);
      v_x_2432 = heff_rec(3, shape_303_321_246, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  return heff_tail(v_k_244, 1, (V[]){v_x_2432});
}
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_k_244 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec(3, shape_303_321_246, (V[]){v_st_240, ((V)&g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_str0), NTAG(TAG_Nil)});
    return heff_tail(v_k_244, 1, (V[]){v_t_246});
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take(v_x_245, 1ULL);
    V v_t_248 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_f_247);
      heff_drop(v_t_248);
      V v_t_249 = heff_rec(3, shape_303_321_246, (V[]){v_st_240, ((V)&g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_str1), NTAG(TAG_Nil)});
      return heff_tail(v_k_244, 1, (V[]){v_t_249});
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take(v_t_248, 1ULL);
      V v_t_2411 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_t_2411);
        V v_c_2412 = (g_heff_2elsp_2echeck_24s969_24s1157_24s1198(v_st_240, heff_dup(v_f_247)));
        return heff_tail(v_c_2412, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam2, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244})});
      }
      case TAG_Just: {
        V v_c_2419 = heff_field(v_t_2411, 0);
        heff_take(v_t_2411, 1ULL);
        V v_t_2420 = heff_strEq(heff_get(v_c_2419, LBL_text), heff_get(heff_dup(v_d_2410), LBL_text));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_hd_243);
          heff_drop(v_t_2420);
          V v_text_2421 = heff_get(v_d_2410, LBL_text);
          V v_t_2422 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
          V v_x_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            heff_drop(v_t_2422);
            v_x_2425 = heff_rec(3, shape_303_321_246, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            break;
          }
          case TAG_Just: {
            V v_c_2423 = heff_field(v_t_2422, 0);
            heff_take(v_t_2422, 1ULL);
            V v_t_2424 = heff_strEq(heff_get(heff_dup(v_c_2423), LBL_text), heff_dup(v_text_2421));
            switch (heff_tag_of(v_t_2424)) {
            case TAG_True: {
              heff_drop(v_t_2424);
              v_x_2425 = heff_rec(3, shape_303_321_246, (V[]){v_st_240, v_text_2421, heff_get(v_c_2423, LBL_program)});
              break;
            }
            case TAG_False: {
              heff_drop(v_c_2423);
              heff_drop(v_t_2424);
              v_x_2425 = heff_rec(3, shape_303_321_246, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
              break;
            }
            default: heff_nomatch(v_t_2424);
            }
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          return heff_tail(v_k_244, 1, (V[]){v_x_2425});
        }
        case TAG_False: {
          heff_drop(v_t_2420);
          V v_c_2426 = (g_heff_2elsp_2echeck_24s969_24s1157_24s1198(v_st_240, heff_dup(v_f_247)));
          return heff_tail(v_c_2426, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam3, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244})});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243})});
}
V g_heff_2elsp_2euriOf_24s977_24s1205_lam1(V self, V *args); static Clo g_heff_2elsp_2euriOf_24s977_24s1205_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2euriOf_24s977_24s1205_lam1, 1, 0};
V g_heff_2elsp_2euriOf_24s977_24s1205_lam0(V self, V *args);
V g_heff_2elsp_2euriOf_24s977_24s1205_lam2(V self, V *args);
Clo g_heff_2elsp_2euriOf_24s977_24s1205_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2euriOf_24s977_24s1205_entry, 2, 0};

V g_heff_2elsp_2euriOf_24s977_24s1205(V v_st_240, V v_p_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_p_241); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    return heff_clo(g_heff_2elsp_2euriOf_24s977_24s1205_lam0, 2, 1, (V[]){v_p_241});
  }
  case TAG_Just: {
    V v_d_248 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    heff_drop(v_p_241);
    return heff_clo(g_heff_2elsp_2euriOf_24s977_24s1205_lam2, 2, 1, (V[]){v_d_248});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2euriOf_24s977_24s1205_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2euriOf_24s977_24s1205(a[0], a[1]);
}
V g_heff_2elsp_2euriOf_24s977_24s1205_lam1(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(self);
  return v_u_245;
}
V g_heff_2elsp_2euriOf_24s977_24s1205_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_p_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_PathUri, 2, (V[]){v_p_241, ((V)&g_heff_2elsp_2euriOf_24s977_24s1205_lam1_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_247, v_k2_244});
}
V g_heff_2elsp_2euriOf_24s977_24s1205_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_249);
  return heff_tail(v_k_2410, 1, (V[]){heff_get(v_d_248, LBL_uri)});
}
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam0(V self, V *args); static Clo g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam0, 1, 0};
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam2(V self, V *args);
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam1(V self, V *args);
Clo g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_entry, 6, 0};

V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209(V v_read_240, V v_lib_241, V v_root_242, V v_f_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProjectFiles, 2, (V[]){v_root_242, ((V)&g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam0_clo)})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam1, 1, 5, (V[]){v_f_243, v_read_240, v_lib_241, v_hd_244, v_k_245})});
}
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam0(V self, V *args) {
  V v_fs_246 = args[0];
  heff_drop(self);
  return v_fs_246;
}
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_sources_2415 = (g_heff_2elsp_2enubSources(v_x_2414));
  V v_x_2416 = (g_prelude_2efoldl_24s507(NTAG(TAG_Nil), v_sources_2415));
  return heff_tail(v_k_245, 1, (V[]){v_x_2416});
}
V g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_243 = heff_dup(heff_env(self)[0]);
  V v_read_240 = heff_dup(heff_env(self)[1]);
  V v_lib_241 = heff_dup(heff_env(self)[2]);
  V v_hd_244 = heff_dup(heff_env(self)[3]);
  V v_k_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
  V v_files_2411 = (g_prelude_2econcatList(v_x_249, v_t_2410));
  V v_t_2412 = (g_heff_2elsp_2enubPaths(v_files_2411));
  V v_c_2413 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_t_2412; V r_ = (g_heff_2elsp_2eloadAll_24s983_24s1169(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  return heff_tail(v_c_2413, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209_lam2, 1, 1, (V[]){v_k_245})});
}
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam0(V self, V *args);
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam1(V self, V *args);
Clo g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_entry, 5, 0};

V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2elsp_2eelabProject_24s982_24s1168_24s1209(heff_clo(g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam0, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_root_241), v_f_242, v_hd_243, heff_clo(g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam1, 1, 3, (V[]){v_root_241, v_st_240, v_k_244})));
}
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2ereadOpen_24s970_24s1158(v_st_240, v_p_245));
}
V g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_root_241 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_272_246, (V[]){v_root_241, heff_dup(v_x_246)})});
  V v_t_248 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), v_t_247, heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  return heff_tail(v_k_244, 1, (V[]){heff_rec(2, shape_303_246, (V[]){v_t_248, v_x_246})});
}
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam1(V self, V *args);
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam0(V self, V *args);
Clo g_heff_2elsp_2eproject_24s980_24s1166_24s1207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eproject_24s980_24s1166_24s1207_entry, 2, 0};

V g_heff_2elsp_2eproject_24s980_24s1166_24s1207(V v_st_240, V v_f_241) {
top: ;
  V v_c_242 = (g_heff_2eload_2epathsFor_24s868_24s1082(heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_241)));
  return heff_clo(g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_f_241});
}
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eproject_24s980_24s1166_24s1207(a[0], a[1]);
}
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_f_241 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_246 = heff_get(heff_dup(v_st_240), LBL_project);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_t_246);
    return (g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208(v_st_240, heff_get(v_x_245, LBL_root), v_f_241, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_pr_247 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    V v_t_248 = heff_strEq(heff_get(heff_dup(v_pr_247), LBL_root), heff_get(heff_dup(v_x_245), LBL_root));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_x_245);
      heff_drop(v_f_241);
      heff_drop(v_hd_243);
      heff_drop(v_t_248);
      V v_t_249 = heff_rec(2, shape_303_246, (V[]){v_st_240, heff_get(v_pr_247, LBL_program)});
      return heff_tail(v_k_244, 1, (V[]){v_t_249});
    }
    case TAG_False: {
      heff_drop(v_pr_247);
      heff_drop(v_t_248);
      return (g_heff_2elsp_2eprojectAnew_24s981_24s1167_24s1208(v_st_240, heff_get(v_x_245, LBL_root), v_f_241, v_hd_243, v_k_244));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2elsp_2eproject_24s980_24s1166_24s1207_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_243, v_k_244})});
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam0(V self, V *args);
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam3(V self, V *args);
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam2(V self, V *args);
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam1(V self, V *args);
Clo g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_entry, 2, 0};

V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2eproject_24s980_24s1166_24s1207(v_st_240, heff_dup(v_f_248)));
      return heff_clo(g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eprojects_24s979_24s1165_24s1206(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec(2, shape_303_246, (V[]){v_st_240, NTAG(TAG_Nil)});
  return heff_tail(v_k_243, 1, (V[]){v_t_244});
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_dup(heff_env(self)[0]);
  V v_k_2411 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_program_2415 = (g_prelude_2econcatList(heff_get(v_x_2412, LBL_program), heff_get(heff_dup(v_x_2414), LBL_program)));
  V v_x_2416 = heff_rec(2, shape_303_246, (V[]){heff_get(v_x_2414, LBL_st), v_program_2415});
  return heff_tail(v_k_2411, 1, (V[]){v_x_2416});
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_dup(heff_env(self)[0]);
  V v_hd_2410 = heff_dup(heff_env(self)[1]);
  V v_k_2411 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_2413 = ({ V a_0 = heff_get(heff_dup(v_x_2412), LBL_st); V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2eprojects_24s979_24s1165_24s1206(a_0, a_1)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2413, 2, (V[]){v_hd_2410, heff_clo(g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam3, 1, 2, (V[]){v_x_2412, v_k_2411})});
}
V g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_2410), heff_clo(g_heff_2elsp_2eprojects_24s979_24s1165_24s1206_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {108, 111, 99, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 111, 110, 116, 97, 105, 110, 101, 114, 78, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2esymbolJson_24s986_24s1212_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
V g_heff_2elsp_2esymbolJson_24s986_24s1212_lam1(V self, V *args);
V g_heff_2elsp_2esymbolJson_24s986_24s1212_lam0(V self, V *args);
Clo g_heff_2elsp_2esymbolJson_24s986_24s1212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolJson_24s986_24s1212_entry, 3, 0};

V g_heff_2elsp_2esymbolJson_24s986_24s1212(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2euriOf_24s977_24s1205(v_st_240, heff_get(heff_dup(v_c_241), LBL_path)));
  return heff_clo(g_heff_2elsp_2esymbolJson_24s986_24s1212_lam0, 2, 3, (V[]){v_c_243, v_y_242, v_c_241});
}
V g_heff_2elsp_2esymbolJson_24s986_24s1212_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esymbolJson_24s986_24s1212(a[0], a[1], a[2]);
}
V g_heff_2elsp_2esymbolJson_24s986_24s1212_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_y_242 = heff_dup(heff_env(self)[0]);
  V v_c_241 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_y_242), LBL_name)});
  V v_t_248 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_y_242), LBL_kind)});
  V v_t_249 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_c_241), LBL_module)});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str0), heff_tag(TAG_JString, 1, (V[]){v_x_246})});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str1), (g_heff_2elsp_2erange(heff_get(v_c_241, LBL_source), heff_get(v_y_242, LBL_selection)))});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412})});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str2), v_t_2413}), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str3), v_t_249}), v_t_2414});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str4), v_t_248}), v_t_2415});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s986_24s1212_str5), v_t_247}), v_t_2416});
  V v_x_2418 = heff_tag(TAG_JObject, 1, (V[]){v_t_2417});
  return heff_tail(v_k_245, 1, (V[]){v_x_2418});
}
V g_heff_2elsp_2esymbolJson_24s986_24s1212_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_y_242 = heff_dup(heff_env(self)[1]);
  V v_c_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2esymbolJson_24s986_24s1212_lam1, 1, 3, (V[]){v_y_242, v_c_241, v_k_245})});
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam0(V self, V *args); static Clo g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam0, 2, 0};
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam3(V self, V *args);
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam2(V self, V *args);
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam1(V self, V *args);
Clo g_heff_2elsp_2eeachSymbol_24s985_24s1211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eeachSymbol_24s985_24s1211_entry, 3, 0};

V g_heff_2elsp_2eeachSymbol_24s985_24s1211(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    heff_drop(v_x3_242);
    return ((V)&g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take(v_x3_242, 3ULL);
    V v_c_247 = (g_heff_2elsp_2esymbolJson_24s986_24s1212(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo(g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eeachSymbol_24s985_24s1211(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_dup(heff_env(self)[0]);
  V v_x_2410 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_249, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412})});
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_c_241 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_hd_248 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2411 = (g_heff_2elsp_2eeachSymbol_24s985_24s1211(v_st_240, v_c_241, v_rest_246));
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam3, 1, 2, (V[]){v_k_249, v_x_2410})});
}
V g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_c_241 = heff_dup(heff_env(self)[2]);
  V v_rest_246 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2eeachSymbol_24s985_24s1211_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2esymbolsJson_24s984_24s1210_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam0(V self, V *args); static Clo g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam0, 2, 0};
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam1(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam4(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam3(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam2(V self, V *args);
Clo g_heff_2elsp_2esymbolsJson_24s984_24s1210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolsJson_24s984_24s1210_entry, 3, 0};

V g_heff_2elsp_2esymbolsJson_24s984_24s1210(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_query_241);
    return ((V)&g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2413 = (g_heff_2elsp_2eeachSymbol_24s985_24s1211(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2412));
    return heff_clo(g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam2, 2, 4, (V[]){v_c_2413, v_st_240, v_query_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2esymbolsJson_24s984_24s1210(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_s_249 = (g_heff_2elsp_2elowerGo(heff_get(v_y_248, LBL_name), MK_INT(0LL), ((V)&g_heff_2elsp_2esymbolsJson_24s984_24s1210_str0)));
  V v_x3_2410 = (g_prelude_2eindexFrom(v_query_241, v_s_249, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x3_2410);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take(v_x3_2410, 0ULL);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_dup(heff_env(self)[0]);
  V v_k_2415 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2419 = (g_prelude_2econcatList(v_x_2416, v_x_2418));
  return heff_tail(v_k_2415, 1, (V[]){v_x_2419});
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_query_241 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_hd_2414 = heff_dup(heff_env(self)[3]);
  V v_k_2415 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2417 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2esymbolsJson_24s984_24s1210(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo(g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam4, 1, 2, (V[]){v_x_2416, v_k_2415})});
}
V g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_query_241 = heff_dup(heff_env(self)[2]);
  V v_rest_246 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2elsp_2esymbolsJson_24s984_24s1210_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2414, v_k_2415})});
}
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam2(V self, V *args);
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam1(V self, V *args);
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam0(V self, V *args);
Clo g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_entry, 2, 0};

V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2edocPath_24s967_24s1196(heff_dup(v_p_241)));
  return heff_clo(g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(a[0], a[1]);
}
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_247 = heff_dup(heff_env(self)[0]);
  V v_d_2410 = heff_dup(heff_env(self)[1]);
  V v_p_241 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_x_2413 = (g_heff_2elsp_2etargetIn(heff_get(heff_dup(v_x_2412), LBL_st), v_f_247, v_d_2410, v_p_241, heff_get(v_x_2412, LBL_program)));
  return heff_tail(v_k_244, 1, (V[]){v_x_2413});
}
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_k_244 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  V v_p_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop(v_hd_243);
    heff_drop(v_p_241);
    V v_t_246 = heff_rec(3, shape_303_201_318, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    return heff_tail(v_k_244, 1, (V[]){v_t_246});
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take(v_x_245, 1ULL);
    V v_t_248 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_p_241);
      heff_drop(v_f_247);
      heff_drop(v_t_248);
      V v_t_249 = heff_rec(3, shape_303_201_318, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      return heff_tail(v_k_244, 1, (V[]){v_t_249});
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take(v_t_248, 1ULL);
      V v_c_2411 = (g_heff_2elsp_2eproject_24s980_24s1166_24s1207(v_st_240, heff_dup(v_f_247)));
      return heff_tail(v_c_2411, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam2, 1, 4, (V[]){v_f_247, v_d_2410, v_p_241, v_k_244})});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_p_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213_lam1, 1, 4, (V[]){v_st_240, v_k_244, v_hd_243, v_p_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2elocationOf_24s989_24s1215_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2elocationOf_24s989_24s1215_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
V g_heff_2elsp_2elocationOf_24s989_24s1215_lam1(V self, V *args);
V g_heff_2elsp_2elocationOf_24s989_24s1215_lam0(V self, V *args);
Clo g_heff_2elsp_2elocationOf_24s989_24s1215_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocationOf_24s989_24s1215_entry, 2, 0};

V g_heff_2elsp_2elocationOf_24s989_24s1215(V v_st_240, V v_o_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2euriOf_24s977_24s1205(v_st_240, heff_get(heff_dup(v_o_241), LBL_path)));
  return heff_clo(g_heff_2elsp_2elocationOf_24s989_24s1215_lam0, 2, 2, (V[]){v_c_242, v_o_241});
}
V g_heff_2elsp_2elocationOf_24s989_24s1215_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elocationOf_24s989_24s1215(a[0], a[1]);
}
V g_heff_2elsp_2elocationOf_24s989_24s1215_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_241 = heff_dup(heff_env(self)[0]);
  V v_k_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elocationOf_24s989_24s1215_str0), heff_tag(TAG_JString, 1, (V[]){v_x_245})});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elocationOf_24s989_24s1215_str1), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_241), LBL_source), heff_get(v_o_241, LBL_span)))});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_x_249 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
  return heff_tail(v_k_244, 1, (V[]){v_x_249});
}
V g_heff_2elsp_2elocationOf_24s989_24s1215_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_o_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2elocationOf_24s989_24s1215_lam1, 1, 2, (V[]){v_o_241, v_k_244})});
}
V g_heff_2elsp_2elocations_24s988_24s1214_lam0(V self, V *args); static Clo g_heff_2elsp_2elocations_24s988_24s1214_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocations_24s988_24s1214_lam0, 2, 0};
V g_heff_2elsp_2elocations_24s988_24s1214_lam3(V self, V *args);
V g_heff_2elsp_2elocations_24s988_24s1214_lam2(V self, V *args);
V g_heff_2elsp_2elocations_24s988_24s1214_lam1(V self, V *args);
Clo g_heff_2elsp_2elocations_24s988_24s1214_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocations_24s988_24s1214_entry, 2, 0};

V g_heff_2elsp_2elocations_24s988_24s1214(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_x2_241);
    return ((V)&g_heff_2elsp_2elocations_24s988_24s1214_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_c_246 = (g_heff_2elsp_2elocationOf_24s989_24s1215(heff_dup(v_st_240), v_o_244));
    return heff_clo(g_heff_2elsp_2elocations_24s988_24s1214_lam1, 2, 3, (V[]){v_c_246, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elocations_24s988_24s1214_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elocations_24s988_24s1214(a[0], a[1]);
}
V g_heff_2elsp_2elocations_24s988_24s1214_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2elocations_24s988_24s1214_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_248, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411})});
}
V g_heff_2elsp_2elocations_24s988_24s1214_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_2410 = (g_heff_2elsp_2elocations_24s988_24s1214(v_st_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2elsp_2elocations_24s988_24s1214_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2elsp_2elocations_24s988_24s1214_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2elsp_2elocations_24s988_24s1214_lam2, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_247, v_k_248})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eprepared_24s990_24s1216_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2eprepared_24s990_24s1216_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {96, 32, 105, 115, 32, 110, 111, 116, 32, 119, 114, 105, 116, 116, 101, 110, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2eprepared_24s990_24s1216_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2eprepared_24s990_24s1216_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {112, 108, 97, 99, 101, 104, 111, 108, 100, 101, 114}};
V g_heff_2elsp_2eprepared_24s990_24s1216_lam1(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam0(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam2(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam4(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam3(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam6(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam5(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam8(V self, V *args);
V g_heff_2elsp_2eprepared_24s990_24s1216_lam7(V self, V *args);
Clo g_heff_2elsp_2eprepared_24s990_24s1216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprepared_24s990_24s1216_entry, 2, 0};

V g_heff_2elsp_2eprepared_24s990_24s1216(V v_id_240, V v_tg_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_tg_241), LBL_target);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    V v_c_243 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_240, NTAG(TAG_JNull)));
    return heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam0, 2, 2, (V[]){v_c_243, v_tg_241});
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse(v_t_242, 1ULL);
    V v_t_248 = (g_heff_2equery_2erenameRefused(heff_get(heff_dup(v_t_247), LBL_target), heff_get(heff_dup(v_t_247), LBL_name), heff_get(heff_dup(v_t_247), LBL_name)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_t_248);
      V v_off_249 = heff_get(heff_dup(v_tg_241), LBL_off);
      V v_t_2415 = ({ V a_0 = heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam2, 1, 2, (V[]){heff_dup(v_t_247), v_off_249}); V b_1 = heff_get(heff_dup(v_t_247), LBL_occurrences); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24t_242_24Just);
        heff_drop(v_t_2415);
        V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2eprepared_24s990_24s1216_str0), heff_strAppend(heff_get(v_t_247, LBL_name), ((V)&g_heff_2elsp_2eprepared_24s990_24s1216_str1)));
        V v_c_2417 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_240, MK_INT(-32803LL), v_t_2416));
        return heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam3, 2, 2, (V[]){v_c_2417, v_tg_241});
      }
      case TAG_Just: {
        V v_o_2421 = heff_field(v_t_2415, 0);
        V v_ru_24t_2415_24Just = heff_take_reuse(v_t_2415, 1ULL);
        V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eprepared_24s990_24s1216_str2), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_2421), LBL_source), heff_get(v_o_2421, LBL_span)))});
        V v_t_2423 = heff_tag_at(v_ru_24t_242_24Just, TAG_JString, 1, (V[]){heff_get(v_t_247, LBL_name)});
        V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eprepared_24s990_24s1216_str3), v_t_2423}), NTAG(TAG_Nil)});
        V v_t_2425 = heff_tag_at(v_ru_24t_2415_24Just, TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2422, v_t_2424})});
        V v_c_2426 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_240, v_t_2425));
        return heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam5, 2, 2, (V[]){v_c_2426, v_tg_241});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_Just: {
      V v_why_2430 = heff_field(v_t_248, 0);
      heff_take(v_t_248, 1ULL);
      heff_drop(v_t_247);
      heff_drop(v_ru_24t_242_24Just);
      V v_c_2431 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_240, MK_INT(-32803LL), v_why_2430));
      return heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam7, 2, 2, (V[]){v_c_2431, v_tg_241});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2eprepared_24s990_24s1216_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eprepared_24s990_24s1216(a[0], a[1]);
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_246);
  return heff_tail(v_k_245, 1, (V[]){heff_get(v_tg_241, LBL_st)});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam1, 1, 2, (V[]){v_k_245, v_tg_241})});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam2(V self, V *args) {
  V v_o_2410 = args[0];
  V v_t_247 = heff_dup(heff_env(self)[0]);
  V v_off_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2411 = heff_strEq(heff_get(heff_dup(v_o_2410), LBL_path), heff_get(v_t_247, LBL_path));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_t_2411);
    V v_t_2412 = heff_get(heff_get(heff_dup(v_o_2410), LBL_span), LBL_start);
    V v_t_2413 = heff_intLe(v_t_2412, heff_dup(v_off_249));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_t_2413);
      V v_t_2414 = heff_get(heff_get(v_o_2410, LBL_span), LBL_end);
      return heff_intLe(v_off_249, v_t_2414);
    }
    case TAG_False: {
      heff_drop(v_o_2410);
      heff_drop(v_off_249);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_False: {
    heff_drop(v_o_2410);
    heff_drop(v_off_249);
    heff_drop(v_t_2411);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2420);
  return heff_tail(v_k_2419, 1, (V[]){heff_get(v_tg_241, LBL_st)});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2418, heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam4, 1, 2, (V[]){v_k_2419, v_tg_241})});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2429);
  return heff_tail(v_k_2428, 1, (V[]){heff_get(v_tg_241, LBL_st)});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam5(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2426, 2, (V[]){v_hd_2427, heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam6, 1, 2, (V[]){v_k_2428, v_tg_241})});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2433 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2434);
  return heff_tail(v_k_2433, 1, (V[]){heff_get(v_tg_241, LBL_st)});
}
V g_heff_2elsp_2eprepared_24s990_24s1216_lam7(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_dup(heff_env(self)[0]);
  V v_tg_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2431, 2, (V[]){v_hd_2432, heff_clo(g_heff_2elsp_2eprepared_24s990_24s1216_lam8, 1, 2, (V[]){v_k_2433, v_tg_241})});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam3(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam2(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam4(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam8(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam7(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam9(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam10(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam11(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam6(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam13(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam12(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam15(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam16(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam14(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam5(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam1(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam0(V self, V *args);
Clo g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_entry, 3, 0};

V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2eproject_24s980_24s1166_24s1207(heff_dup(v_st_240), heff_get(heff_dup(v_t_241), LBL_path)));
  return heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam0, 2, 4, (V[]){v_c_243, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218(a[0], a[1], a[2]);
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam3(V self, V *args) {
  V v_o_2411 = args[0];
  V v_p_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_2411, LBL_path), v_p_2410);
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_os_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_os_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam3, 1, 1, (V[]){heff_dup(v_p_2410)}), v_os_247));
  return heff_rec(2, shape_228_200, (V[]){v_p_2410, v_os_2412});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2416);
  return heff_tail(v_k_2417, 1, (V[]){v_x_2415});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam8(V self, V *args) {
  V v_o_2426 = args[0];
  V v_p_2425 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_2426, LBL_path), v_p_2425);
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam7(V self, V *args) {
  V v_p_2425 = args[0];
  V v_os_2422 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_os_2427 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam8, 1, 1, (V[]){heff_dup(v_p_2425)}), v_os_2422));
  return heff_rec(2, shape_228_200, (V[]){v_p_2425, v_os_2427});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam9(V self, V *args) {
  V v_b_2429 = args[0];
  V v_new_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_b_2429), LBL_path), (g_heff_2elsp_2erenamedText(v_new_242, heff_get(v_b_2429, LBL_occurrences)))});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam10(V self, V *args) {
  V v_q_2431 = args[0];
  V v_p_2421 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2434;
  switch (heff_tag_of(v_q_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_q_2431, 0);
    heff_take(v_q_2431, 1ULL);
    v_t_2434 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_q_2431);
  }
  return heff_strEq(v_t_2434, v_p_2421);
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam11(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_txt_2439 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2440);
  return heff_tail(v_k_2441, 1, (V[]){heff_tag(TAG_Just, 1, (V[]){v_txt_2439})});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam6(V self, V *args) {
  V v_p_2421 = args[0];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  V v_new_242 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_os_2422 = heff_get(v_t_241, LBL_occurrences);
  V v_t_2423 = (g_prelude_2emap_24s750(heff_dup(v_os_2422)));
  V v_t_2424 = (g_heff_2elsp_2enubPaths(v_t_2423));
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam7, 1, 1, (V[]){v_os_2422}), v_t_2424));
  V v_texts_2430 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam9, 1, 1, (V[]){v_new_242}), v_t_2428));
  V v_t_2435 = ({ V a_0 = heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam10, 1, 1, (V[]){heff_dup(v_p_2421)}); V a_1 = v_texts_2430; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_texts_2430); r_; });
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Nothing: {
    heff_drop(v_t_2435);
    return (g_heff_2elsp_2ereadOpen_24s970_24s1158(v_st_240, v_p_2421));
  }
  case TAG_Just: {
    V v_q_2436 = heff_field(v_t_2435, 0);
    heff_take(v_t_2435, 1ULL);
    heff_drop(v_p_2421);
    heff_drop(v_st_240);
    V v_txt_2439;
    switch (heff_tag_of(v_q_2436)) {
    case TAG_MkPair: {
      V v_y_2438 = heff_field(v_q_2436, 1);
      heff_take(v_q_2436, 2ULL);
      v_txt_2439 = v_y_2438;
      break;
    }
    default: heff_nomatch(v_q_2436);
    }
    return heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam11, 2, 1, (V[]){v_txt_2439});
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam13(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2444 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_sources_2446 = (g_heff_2elsp_2enubSources(v_x_2445));
  V v_x_2447 = (g_prelude_2efoldl_24s507(NTAG(TAG_Nil), v_sources_2446));
  return heff_tail(v_k_2444, 1, (V[]){v_x_2447});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam12(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(v_c_2442, 2, (V[]){v_hd_2443, heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam13, 1, 1, (V[]){v_k_2444})});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam15(V self, V *args) {
  V v_c_2450 = args[0];
  V v_x_2419 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2451 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_2450, LBL_path)}));
  return ({ V a_0 = v_t_2451; V a_1 = v_x_2419; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_x_2419); r_; });
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam16(V self, V *args) {
  V v_c_2455 = args[0];
  V v_x_2419 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2456 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_2455, LBL_path)}));
  return ({ V a_0 = v_t_2456; V a_1 = v_x_2419; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_x_2419); r_; });
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam14(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2419 = heff_dup(heff_env(self)[0]);
  V v_x_246 = heff_dup(heff_env(self)[1]);
  V v_t_241 = heff_dup(heff_env(self)[2]);
  V v_new_242 = heff_dup(heff_env(self)[3]);
  V v_k_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_program_2452 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam15, 1, 1, (V[]){heff_dup(v_x_2419)}), heff_get(heff_dup(v_x_246), LBL_program)));
  V v_t_2453 = (g_heff_2elsp_2enubCheckedPaths(v_program_2452));
  V v_t_2454 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2453; V r_ = (g_prelude_2efoldl_24s832(a_0, a_1)); heff_drop(v_t_2453); r_; });
  V v_program_2457 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam16, 1, 1, (V[]){v_x_2419}), heff_dup(v_x_2449)));
  V v_t_2458 = (g_heff_2elsp_2enubCheckedPaths(v_program_2457));
  V v_t_2459 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2458; V r_ = (g_prelude_2efoldl_24s832(a_0, a_1)); heff_drop(v_t_2458); r_; });
  V v_x_2460 = (g_heff_2elsp_2erenameVerdict(v_x_246, v_t_241, v_new_242, v_t_2454, v_t_2459, v_x_2449));
  return heff_tail(v_k_245, 1, (V[]){v_x_2460});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  V v_new_242 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  V v_hd_244 = heff_dup(heff_env(self)[3]);
  V v_x_246 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2420 = (g_heff_2elsp_2enubPaths(heff_dup(v_x_2419)));
  V v_c_2442 = ({ V a_0 = heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam6, 1, 3, (V[]){heff_dup(v_t_241), heff_dup(v_new_242), heff_dup(v_st_240)}); V a_1 = heff_get(v_st_240, LBL_lib); V a_2 = v_t_2420; V r_ = (g_heff_2elsp_2eloadAll_24s983_24s1169(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  V v_c_2448 = heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam12, 2, 1, (V[]){v_c_2442});
  return heff_tail(v_c_2448, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam14, 1, 5, (V[]){v_x_2419, v_x_246, v_t_241, v_new_242, v_k_245})});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_t_241 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_new_242 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  V v_k_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_os_247 = heff_get(heff_dup(v_t_241), LBL_occurrences);
  V v_t_248 = (g_prelude_2emap_24s750(heff_dup(v_os_247)));
  V v_t_249 = (g_heff_2elsp_2enubPaths(v_t_248));
  V v_t_2413 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam2, 1, 1, (V[]){v_os_247}), v_t_249));
  V v_t_2414 = (g_prelude_2emap_24s750(v_t_2413));
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V a_2 = heff_get(heff_dup(v_x_246), LBL_program); V r_ = (g_heff_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_c_2418 = heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam4, 2, 1, (V[]){v_x_2415});
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam5, 1, 6, (V[]){v_t_241, v_new_242, v_st_240, v_hd_244, v_x_246, v_k_245})});
}
V g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_t_241 = heff_dup(heff_env(self)[1]);
  V v_new_242 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218_lam1, 1, 5, (V[]){v_t_241, v_hd_244, v_new_242, v_st_240, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2echangesOf_24s993_24s1219_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2echangesOf_24s993_24s1219_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 84, 101, 120, 116}};
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam0(V self, V *args); static Clo g_heff_2elsp_2echangesOf_24s993_24s1219_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echangesOf_24s993_24s1219_lam0, 2, 0};
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam4(V self, V *args);
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam3(V self, V *args);
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam2(V self, V *args);
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam1(V self, V *args);
Clo g_heff_2elsp_2echangesOf_24s993_24s1219_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echangesOf_24s993_24s1219_entry, 3, 0};

V g_heff_2elsp_2echangesOf_24s993_24s1219(V v_st_240, V v_new_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_new_241);
    heff_drop(v_x3_242);
    return ((V)&g_heff_2elsp_2echangesOf_24s993_24s1219_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take(v_x3_242, 3ULL);
    V v_c_247 = (g_heff_2elsp_2euriOf_24s977_24s1205(heff_dup(v_st_240), heff_get(heff_dup(v_b_245), LBL_path)));
    return heff_clo(g_heff_2elsp_2echangesOf_24s993_24s1219_lam1, 2, 5, (V[]){v_c_247, v_st_240, v_new_241, v_rest_246, v_b_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echangesOf_24s993_24s1219(a[0], a[1], a[2]);
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam4(V self, V *args) {
  V v_o_2413 = args[0];
  V v_new_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echangesOf_24s993_24s1219_str0), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_2413), LBL_source), heff_get(v_o_2413, LBL_span)))});
  V v_t_2415 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echangesOf_24s993_24s1219_str1), heff_tag(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})});
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_new_241 = heff_dup(heff_env(self)[0]);
  V v_b_245 = heff_dup(heff_env(self)[1]);
  V v_x_2410 = heff_dup(heff_env(self)[2]);
  V v_k_249 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2417 = heff_tag(TAG_JArray, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2elsp_2echangesOf_24s993_24s1219_lam4, 1, 1, (V[]){v_new_241}), heff_get(v_b_245, LBL_occurrences)))});
  V v_x_2418 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2410, v_t_2417}), v_x_2412});
  return heff_tail(v_k_249, 1, (V[]){v_x_2418});
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_new_241 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_hd_248 = heff_dup(heff_env(self)[3]);
  V v_b_245 = heff_dup(heff_env(self)[4]);
  V v_k_249 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_2411 = (g_heff_2elsp_2echangesOf_24s993_24s1219(v_st_240, heff_dup(v_new_241), v_rest_246));
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2echangesOf_24s993_24s1219_lam3, 1, 4, (V[]){v_new_241, v_b_245, v_x_2410, v_k_249})});
}
V g_heff_2elsp_2echangesOf_24s993_24s1219_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_new_241 = heff_dup(heff_env(self)[2]);
  V v_rest_246 = heff_dup(heff_env(self)[3]);
  V v_b_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2elsp_2echangesOf_24s993_24s1219_lam2, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_hd_248, v_b_245, v_k_249})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 104, 97, 110, 103, 101, 115}};
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam1(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam0(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam5(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam4(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam7(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam6(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam8(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam3(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam2(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam10(V self, V *args);
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam9(V self, V *args);
Clo g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_entry, 3, 0};

V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217(V v_id_240, V v_new_241, V v_tg_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_tg_242), LBL_target);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    heff_drop(v_t_243);
    V v_c_244 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_240, NTAG(TAG_JNull)));
    return heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam0, 2, 2, (V[]){v_c_244, v_tg_242});
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_249 = (g_heff_2equery_2erenameRefused(heff_get(heff_dup(v_t_248), LBL_target), heff_get(heff_dup(v_t_248), LBL_name), heff_dup(v_new_241)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_249);
      V v_c_2410 = (g_heff_2elsp_2erenameChecked_24s992_24s1172_24s1218(heff_get(v_tg_242, LBL_st), heff_dup(v_t_248), heff_dup(v_new_241)));
      return heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam2, 2, 4, (V[]){v_c_2410, v_t_248, v_new_241, v_id_240});
    }
    case TAG_Just: {
      V v_why_2442 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      heff_drop(v_new_241);
      heff_drop(v_t_248);
      V v_c_2443 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_240, MK_INT(-32803LL), v_why_2442));
      return heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam9, 2, 2, (V[]){v_c_2443, v_tg_242});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamed_24s991_24s1171_24s1217(a[0], a[1], a[2]);
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_dup(heff_env(self)[0]);
  V v_tg_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_247);
  return heff_tail(v_k_246, 1, (V[]){heff_get(v_tg_242, LBL_st)});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  V v_tg_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_244, 2, (V[]){v_hd_245, heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam1, 1, 2, (V[]){v_k_246, v_tg_242})});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam5(V self, V *args) {
  V v_o_2424 = args[0];
  V v_p_2423 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_2424, LBL_path), v_p_2423);
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam4(V self, V *args) {
  V v_p_2423 = args[0];
  V v_os_2420 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_os_2425 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam5, 1, 1, (V[]){heff_dup(v_p_2423)}), v_os_2420));
  return heff_rec(2, shape_228_200, (V[]){v_p_2423, v_os_2425});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2413 = heff_dup(heff_env(self)[0]);
  V v_k_2412 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2432);
  V v_x_2435;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x_2413, 0);
    heff_take(v_x_2413, 1ULL);
    v_x_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return heff_tail(v_k_2412, 1, (V[]){v_x_2435});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_id_240 = heff_dup(heff_env(self)[0]);
  V v_hd_2411 = heff_dup(heff_env(self)[1]);
  V v_x_2413 = heff_dup(heff_env(self)[2]);
  V v_k_2412 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_str0), heff_tag(TAG_JObject, 1, (V[]){v_x_2428})});
  V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_c_2431 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_240, heff_tag(TAG_JObject, 1, (V[]){v_t_2430})));
  return heff_tail(v_c_2431, 2, (V[]){v_hd_2411, heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam7, 1, 2, (V[]){v_x_2413, v_k_2412})});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2413 = heff_dup(heff_env(self)[0]);
  V v_k_2412 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2438);
  V v_x_2441;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x_2413, 0);
    heff_take(v_x_2413, 1ULL);
    v_x_2441 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return heff_tail(v_k_2412, 1, (V[]){v_x_2441});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_248 = heff_dup(heff_env(self)[0]);
  V v_new_241 = heff_dup(heff_env(self)[1]);
  V v_hd_2411 = heff_dup(heff_env(self)[2]);
  V v_id_240 = heff_dup(heff_env(self)[3]);
  V v_k_2412 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_dup(heff_field(v_x_2413, 1));
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    heff_drop(v_t_2416);
    V v_t_2419;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_os_2420 = heff_get(v_t_248, LBL_occurrences);
    V v_t_2421 = (g_prelude_2emap_24s750(heff_dup(v_os_2420)));
    V v_t_2422 = (g_heff_2elsp_2enubPaths(v_t_2421));
    V v_t_2426 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam4, 1, 1, (V[]){v_os_2420}), v_t_2422));
    V v_c_2427 = (g_heff_2elsp_2echangesOf_24s993_24s1219(v_t_2419, v_new_241, v_t_2426));
    return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam6, 1, 4, (V[]){v_id_240, v_hd_2411, v_x_2413, v_k_2412})});
  }
  case TAG_Just: {
    V v_why_2436 = heff_field(v_t_2416, 0);
    heff_take(v_t_2416, 1ULL);
    heff_drop(v_t_248);
    heff_drop(v_new_241);
    V v_c_2437 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_240, MK_INT(-32803LL), v_why_2436));
    return heff_tail(v_c_2437, 2, (V[]){v_hd_2411, heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam8, 1, 2, (V[]){v_x_2413, v_k_2412})});
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_dup(heff_env(self)[0]);
  V v_t_248 = heff_dup(heff_env(self)[1]);
  V v_new_241 = heff_dup(heff_env(self)[2]);
  V v_id_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam3, 1, 5, (V[]){v_t_248, v_new_241, v_hd_2411, v_id_240, v_k_2412})});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam10(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2445 = heff_dup(heff_env(self)[0]);
  V v_tg_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2446);
  return heff_tail(v_k_2445, 1, (V[]){heff_get(v_tg_242, LBL_st)});
}
V g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam9(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_dup(heff_env(self)[0]);
  V v_tg_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2443, 2, (V[]){v_hd_2444, heff_clo(g_heff_2elsp_2erenamed_24s991_24s1171_24s1217_lam10, 1, 2, (V[]){v_k_2445, v_tg_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {104, 101, 102, 102, 58, 32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str3 = {{0x80000000u, K_STR, 0}, 18, 18, {119, 105, 110, 100, 111, 119, 47, 115, 104, 111, 119, 77, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eformattedIn_24s995_24s1221_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 84, 101, 120, 116}};
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam2(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam1(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam0(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam4(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam3(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam6(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam5(V self, V *args);
Clo g_heff_2elsp_2eformattedIn_24s995_24s1221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eformattedIn_24s995_24s1221_entry, 4, 0};

V g_heff_2elsp_2eformattedIn_24s995_24s1221(V v_st_240, V v_id_241, V v_d_242, V v_fix_243) {
top: ;
  V v_src_244 = heff_get(heff_dup(v_d_242), LBL_text);
  V v_t_245 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_244)));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_why_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Left = heff_take_reuse(v_t_245, 1ULL);
    heff_drop(v_src_244);
    v_t_248 = heff_tag_at(v_ru_24t_245_24Left, TAG_Left, 1, (V[]){v_why_246});
    break;
  }
  case TAG_Right: {
    V v_out_247 = heff_field(v_t_245, 0);
    heff_take(v_t_245, 1ULL);
    v_t_248 = (g_heff_2eformat_2echeck(v_src_244, v_out_247));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Left = heff_take_reuse(v_t_248, 1ULL);
    heff_drop(v_d_242);
    V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str0), heff_tag_at(v_ru_24t_248_24Left, TAG_JInt, 1, (V[]){MK_INT(2LL)})});
    V v_t_2411 = heff_tag(TAG_JString, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str1), v_why_249)});
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str2), v_t_2411}), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412})});
    V v_c_2414 = (g_heff_2elsp_2enotify_24s971_24s1199(((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str3), v_t_2413));
    return heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam0, 2, 3, (V[]){v_c_2414, v_id_241, v_st_240});
  }
  case TAG_Right: {
    V v_t_2421 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Right = heff_take_reuse(v_t_248, 1ULL);
    V v_t_2422 = heff_strEq(heff_dup(v_t_2421), heff_get(heff_dup(v_d_242), LBL_text));
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_d_242);
      heff_drop(v_t_2421);
      heff_drop(v_t_2422);
      V v_t_2423 = heff_tag_at(v_ru_24t_248_24Right, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_c_2424 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_241, v_t_2423));
      return heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam3, 2, 2, (V[]){v_c_2424, v_st_240});
    }
    case TAG_False: {
      heff_drop(v_t_2422);
      V v_t_2428 = heff_strLength(heff_get(heff_dup(v_d_242), LBL_text));
      V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str4), (g_heff_2elsp_2erange(heff_get(v_d_242, LBL_text), heff_rec(2, shape_305_78, (V[]){MK_INT(0LL), v_t_2428})))});
      V v_t_2430 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s995_24s1221_str5), heff_tag_at(v_ru_24t_248_24Right, TAG_JString, 1, (V[]){v_t_2421})});
      V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      V v_t_2432 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_t_2431})});
      V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      V v_c_2434 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_241, heff_tag(TAG_JArray, 1, (V[]){v_t_2433})));
      return heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam5, 2, 2, (V[]){v_c_2434, v_st_240});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eformattedIn_24s995_24s1221(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2416 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2420);
  return heff_tail(v_k_2416, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_id_241 = heff_dup(heff_env(self)[0]);
  V v_hd_2415 = heff_dup(heff_env(self)[1]);
  V v_k_2416 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
  V v_c_2419 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_241, v_t_2418));
  return heff_tail(v_c_2419, 2, (V[]){v_hd_2415, heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam2, 1, 2, (V[]){v_k_2416, v_st_240})});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_dup(heff_env(self)[0]);
  V v_id_241 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_2415), heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam1, 1, 4, (V[]){v_id_241, v_hd_2415, v_k_2416, v_st_240})});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2427);
  return heff_tail(v_k_2426, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){v_hd_2425, heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam4, 1, 2, (V[]){v_k_2426, v_st_240})});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2437);
  return heff_tail(v_k_2436, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2eformattedIn_24s995_24s1221_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2434, 2, (V[]){v_hd_2435, heff_clo(g_heff_2elsp_2eformattedIn_24s995_24s1221_lam6, 1, 2, (V[]){v_k_2436, v_st_240})});
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam2(V self, V *args);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam3(V self, V *args);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam4(V self, V *args);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam5(V self, V *args);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam1(V self, V *args);
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam0(V self, V *args);
Clo g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_entry, 3, 0};

V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2edocPath_24s967_24s1196(v_p_242));
  return heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam0, 2, 3, (V[]){v_c_243, v_id_241, v_st_240});
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eformatted_24s994_24s1173_24s1220(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_249);
  return heff_tail(v_k_245, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2414);
  return heff_tail(v_k_245, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam4(V self, V *args) {
  V v_q_2416 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2ereadOpen_24s970_24s1158(v_st_240, v_q_2416));
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_id_241 = heff_dup(heff_env(self)[1]);
  V v_d_2415 = heff_dup(heff_env(self)[2]);
  V v_hd_244 = heff_dup(heff_env(self)[3]);
  V v_k_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2419 = (g_heff_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get(v_x_2418, LBL_sources)));
  V v_t_2420 = (g_heff_2elsp_2eformattedIn_24s995_24s1221(v_st_240, v_id_241, v_d_2415, v_t_2419));
  return heff_tail(v_t_2420, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_st_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_246);
    V v_t_247 = heff_tag(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_c_248 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_241, v_t_247));
    return heff_tail(v_c_248, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam2, 1, 2, (V[]){v_k_245, v_st_240})});
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse(v_x_246, 1ULL);
    V v_t_2411 = ({ V a_0 = heff_dup(v_f_2410); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop(v_f_2410);
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_at(v_ru_24x_246_24Just, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_c_2413 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_241, v_t_2412));
      return heff_tail(v_c_2413, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam3, 1, 2, (V[]){v_k_245, v_st_240})});
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_t_2411, 0);
      heff_take(v_t_2411, 1ULL);
      heff_drop(v_ru_24x_246_24Just);
      V v_c_2417 = (g_heff_2eload_2eloadProgramWith_24s867_24s1159(heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam4, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), v_f_2410));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam5, 1, 5, (V[]){v_st_240, v_id_241, v_d_2415, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_id_241 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2eformatted_24s994_24s1173_24s1220_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {105, 110, 105, 116, 105, 97, 108, 105, 122, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {100, 121, 110, 97, 109, 105, 99, 82, 101, 103, 105, 115, 116, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {119, 111, 114, 107, 115, 112, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str3 = {{0x80000000u, K_STR, 0}, 21, 21, {100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 112, 97, 98, 105, 108, 105, 116, 105, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 104, 117, 116, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 104, 111, 118, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str7 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str11 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 111, 99, 117, 109, 101, 110, 116, 83, 121, 109, 98, 111, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 115, 121, 109, 98, 111, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {113, 117, 101, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str16 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 114, 101, 102, 101, 114, 101, 110, 99, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str17 = {{0x80000000u, K_STR, 0}, 18, 18, {105, 110, 99, 108, 117, 100, 101, 68, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str18 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 116, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str19 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 114, 101, 112, 97, 114, 101, 82, 101, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str20 = {{0x80000000u, K_STR, 0}, 19, 19, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 114, 101, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str21 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 78, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str23 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 102, 111, 114, 109, 97, 116, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str24 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 109, 101, 116, 104, 111, 100, 32}};
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam1(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam0(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam3(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam2(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam6(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam5(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam4(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam10(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam9(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam11(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam8(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam7(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam14(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam13(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam12(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam17(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam18(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam16(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam15(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam23(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam22(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam21(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam20(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam19(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam26(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam28(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam27(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam29(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam25(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam24(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam31(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam30(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam33(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam32(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam35(V self, V *args);
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam34(V self, V *args);
Clo g_heff_2elsp_2erequest_24s974_24s1162_24s1202_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erequest_24s974_24s1162_24s1202_entry, 4, 0};

V g_heff_2elsp_2erequest_24s974_24s1162_24s1202(V v_st_240, V v_m_241, V v_id_242, V v_p_243) {
top: ;
  V v_t_244 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_m_241);
    heff_drop(v_t_244);
    V v_c_245 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, heff_dup(g_heff_2elsp_2ecapabilities_get())));
    return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam0, 2, 3, (V[]){v_c_245, v_p_243, v_st_240});
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_2423 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str5));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      heff_drop(v_t_2423);
      V v_c_2424 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, NTAG(TAG_JNull)));
      return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam2, 2, 2, (V[]){v_c_2424, v_st_240});
    }
    case TAG_False: {
      heff_drop(v_t_2423);
      V v_t_2429 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str6));
      switch (heff_tag_of(v_t_2429)) {
      case TAG_True: {
        heff_drop(v_m_241);
        heff_drop(v_t_2429);
        V v_c_2430 = (g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(v_st_240, heff_dup(v_p_243)));
        return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam4, 2, 3, (V[]){v_c_2430, v_p_243, v_id_242});
      }
      case TAG_False: {
        heff_drop(v_t_2429);
        V v_t_2437 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str7));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          heff_drop(v_m_241);
          heff_drop(v_t_2437);
          V v_c_2438 = (g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(v_st_240, heff_dup(v_p_243)));
          return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam7, 2, 3, (V[]){v_c_2438, v_p_243, v_id_242});
        }
        case TAG_False: {
          heff_drop(v_t_2437);
          V v_t_2456 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str10));
          switch (heff_tag_of(v_t_2456)) {
          case TAG_True: {
            heff_drop(v_m_241);
            heff_drop(v_t_2456);
            V v_c_2457 = (g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(v_st_240, heff_dup(v_p_243)));
            return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam12, 2, 3, (V[]){v_c_2457, v_p_243, v_id_242});
          }
          case TAG_False: {
            heff_drop(v_t_2456);
            V v_t_2469 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str11));
            switch (heff_tag_of(v_t_2469)) {
            case TAG_True: {
              heff_drop(v_m_241);
              heff_drop(v_t_2469);
              V v_c_2470 = (g_heff_2elsp_2ewithProgram_24s976_24s1163_24s1204(v_st_240, v_p_243));
              return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam15, 2, 2, (V[]){v_c_2470, v_id_242});
            }
            case TAG_False: {
              heff_drop(v_t_2469);
              V v_t_2482 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str12));
              switch (heff_tag_of(v_t_2482)) {
              case TAG_True: {
                heff_drop(v_m_241);
                heff_drop(v_t_2482);
                V v_t_2483 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_docs); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_2484 = (g_prelude_2emap_24s5(v_t_2483));
                V v_c_2485 = (g_heff_2elsp_2erootsOf_24s978_24s1164(heff_dup(v_st_240), v_t_2484));
                return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam19, 2, 4, (V[]){v_c_2485, v_st_240, v_p_243, v_id_242});
              }
              case TAG_False: {
                heff_drop(v_t_2482);
                V v_t_24110 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str16));
                switch (heff_tag_of(v_t_24110)) {
                case TAG_True: {
                  heff_drop(v_m_241);
                  heff_drop(v_t_24110);
                  V v_c_24111 = (g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(v_st_240, heff_dup(v_p_243)));
                  return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam24, 2, 3, (V[]){v_c_24111, v_id_242, v_p_243});
                }
                case TAG_False: {
                  heff_drop(v_t_24110);
                  V v_t_24138 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str19));
                  switch (heff_tag_of(v_t_24138)) {
                  case TAG_True: {
                    heff_drop(v_m_241);
                    heff_drop(v_t_24138);
                    V v_c_24139 = (g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(v_st_240, v_p_243));
                    return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam30, 2, 2, (V[]){v_c_24139, v_id_242});
                  }
                  case TAG_False: {
                    heff_drop(v_t_24138);
                    V v_t_24144 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str20));
                    switch (heff_tag_of(v_t_24144)) {
                    case TAG_True: {
                      heff_drop(v_m_241);
                      heff_drop(v_t_24144);
                      V v_c_24145 = (g_heff_2elsp_2ewithTarget_24s987_24s1170_24s1213(v_st_240, heff_dup(v_p_243)));
                      return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam32, 2, 3, (V[]){v_c_24145, v_p_243, v_id_242});
                    }
                    case TAG_False: {
                      heff_drop(v_t_24144);
                      V v_t_24162 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str23));
                      switch (heff_tag_of(v_t_24162)) {
                      case TAG_True: {
                        heff_drop(v_m_241);
                        heff_drop(v_t_24162);
                        return (g_heff_2elsp_2eformatted_24s994_24s1173_24s1220(v_st_240, v_id_242, v_p_243));
                      }
                      case TAG_False: {
                        heff_drop(v_p_243);
                        heff_drop(v_t_24162);
                        V v_c_24163 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str24), v_m_241)));
                        return heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam34, 2, 2, (V[]){v_c_24163, v_st_240});
                      }
                      default: return heff_nomatch(v_t_24162);
                      }
                    }
                    default: return heff_nomatch(v_t_24144);
                    }
                  }
                  default: return heff_nomatch(v_t_24138);
                  }
                }
                default: return heff_nomatch(v_t_24110);
                }
              }
              default: return heff_nomatch(v_t_2482);
              }
            }
            default: return heff_nomatch(v_t_2469);
            }
          }
          default: return heff_nomatch(v_t_2456);
          }
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2429);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erequest_24s974_24s1162_24s1202(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_k_247 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_248);
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str1), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str3), v_t_249})});
  V v_it_2411 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str4), v_t_2410}); V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2419;
  switch (heff_tag_of(v_it_2411)) {
  case TAG_Nothing: {
    heff_drop(v_it_2411);
    v_x2_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2412 = heff_field(v_it_2411, 0);
    V v_ru_24it_2411_24Just = heff_take_reuse(v_it_2411, 1ULL);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_JNull: {
      heff_drop(v_it1_2412);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_2413 = heff_field(v_it1_2412, 0);
      heff_take(v_it1_2412, 1ULL);
      v_x2_2419 = heff_tag_at(v_ru_24it_2411_24Just, TAG_Just, 1, (V[]){v_b_2413});
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_2412, 0ULL);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_2412, 0ULL);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take(v_it1_2412, 0ULL);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_2412, 0ULL);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_2412, 0ULL);
      heff_drop(v_ru_24it_2411_24Just);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2412);
    }
    break;
  }
  default: heff_nomatch(v_it_2411);
  }
  V v_w_2421;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2419);
    v_w_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take(v_x2_2419, 1ULL);
    v_w_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V v_x_2422 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), v_w_2421, heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  return heff_tail(v_k_247, 1, (V[]){v_x_2422});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_st_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_245, 2, (V[]){v_hd_246, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam1, 1, 3, (V[]){v_p_243, v_st_240, v_k_247})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_k_2426 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), NTAG(TAG_True), heff_get(v_st_240, LBL_lib)});
  return heff_tail(v_k_2426, 1, (V[]){v_t_2428});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){v_hd_2425, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam3, 1, 2, (V[]){v_st_240, v_k_2426})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2432 = heff_dup(heff_env(self)[0]);
  V v_x_2433 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2436);
  return heff_tail(v_k_2432, 1, (V[]){heff_get(v_x_2433, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_hd_2431 = heff_dup(heff_env(self)[2]);
  V v_k_2432 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2434 = (g_heff_2elsp_2ehoverOf(heff_dup(v_x_2433), v_p_243));
  V v_c_2435 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, v_t_2434));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_2431, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam6, 1, 2, (V[]){v_k_2432, v_x_2433})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_2431), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam5, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2431, v_k_2432})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam10(V self, V *args) {
  V v_x_2448 = args[0];
  V v_d_2444 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_hd_2446 = heff_dup(heff_env(self)[2]);
  V v_k_2447 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2449 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str8), heff_tag(TAG_JString, 1, (V[]){v_x_2448})});
  V v_t_2450 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str9), (g_heff_2elsp_2erange(heff_get(heff_dup(v_d_2444), LBL_source), heff_get(v_d_2444, LBL_span)))});
  V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
  V v_t_2452 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2449, v_t_2451})});
  V v_t_2453 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, v_t_2452));
  return heff_tail(v_t_2453, 2, (V[]){v_hd_2446, v_k_2447});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam9(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_dup(heff_env(self)[0]);
  V v_d_2444 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_2446), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam10, 1, 4, (V[]){v_d_2444, v_id_242, v_hd_2446, v_k_2447})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_2440 = heff_dup(heff_env(self)[0]);
  V v_x_2441 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2455);
  return heff_tail(v_k_2440, 1, (V[]){heff_get(v_x_2441, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_hd_2439 = heff_dup(heff_env(self)[2]);
  V v_k_2440 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2442 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_x_2441), LBL_text), v_p_243));
  V v_t_2443 = (g_heff_2equery_2edefinitionAt(heff_get(heff_dup(v_x_2441), LBL_program), v_t_2442));
  V v_c_2454;
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    heff_drop(v_t_2443);
    v_c_2454 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, NTAG(TAG_JNull)));
    break;
  }
  case TAG_Just: {
    V v_d_2444 = heff_field(v_t_2443, 0);
    heff_take(v_t_2443, 1ULL);
    V v_c_2445 = (g_heff_2elsp_2euriOf_24s977_24s1205(heff_get(heff_dup(v_x_2441), LBL_st), heff_get(heff_dup(v_d_2444), LBL_path)));
    v_c_2454 = heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam9, 2, 3, (V[]){v_c_2445, v_d_2444, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_2443);
  }
  return heff_tail(v_c_2454, 2, (V[]){v_hd_2439, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam11, 1, 2, (V[]){v_k_2440, v_x_2441})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam7(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_hd_2439), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam8, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2439, v_k_2440})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam14(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2459 = heff_dup(heff_env(self)[0]);
  V v_x_2460 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2468);
  return heff_tail(v_k_2459, 1, (V[]){heff_get(v_x_2460, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam13(V self, V *args) {
  V v_x_2460 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_hd_2458 = heff_dup(heff_env(self)[2]);
  V v_k_2459 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_x1_2461 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_x_2460), LBL_program)));
  V v_t_2466;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    heff_drop(v_x1_2461);
    v_t_2466 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2462 = heff_field(v_x1_2461, 0);
    heff_take(v_x1_2461, 1ULL);
    V v_t_2464 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_x_2460), LBL_text), v_p_243));
    V v_t_2465 = (g_heff_2equery_2ecompletionsAt(v_x_2462, v_t_2464));
    v_t_2466 = (g_prelude_2emap_24s833(v_t_2465));
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  V v_c_2467 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_t_2466})));
  return heff_tail(v_c_2467, 2, (V[]){v_hd_2458, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam14, 1, 2, (V[]){v_k_2459, v_x_2460})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam12(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_2458), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam13, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2458, v_k_2459})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam17(V self, V *args) {
  V v_y_2478 = args[0];
  V v_x_2473 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elsp_2edocSymbol(heff_get(v_x_2473, LBL_text), v_y_2478));
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam18(V self, V *args) {
  V v_x_2481 = args[0];
  V v_k_2472 = heff_dup(heff_env(self)[0]);
  V v_x_2473 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2481);
  return heff_tail(v_k_2472, 1, (V[]){heff_get(v_x_2473, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam16(V self, V *args) {
  V v_x_2473 = args[0];
  V v_id_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2471 = heff_dup(heff_env(self)[1]);
  V v_k_2472 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_x1_2474 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_x_2473), LBL_program)));
  V v_t_2479;
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_Nil: {
    heff_drop(v_x1_2474);
    v_t_2479 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_x1_2474, 0);
    heff_take(v_x1_2474, 1ULL);
    V v_t_2477 = (g_heff_2equery_2esymbols(v_x_2475));
    v_t_2479 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam17, 1, 1, (V[]){heff_dup(v_x_2473)}), v_t_2477));
    break;
  }
  default: heff_nomatch(v_x1_2474);
  }
  V v_c_2480 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_t_2479})));
  return heff_tail(v_c_2480, 2, (V[]){v_hd_2471, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam18, 1, 2, (V[]){v_k_2472, v_x_2473})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam15(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2470, 2, (V[]){heff_dup(v_hd_2471), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam16, 1, 3, (V[]){v_id_242, v_hd_2471, v_k_2472})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam23(V self, V *args) {
  V v_x_24109 = args[0];
  V v_k_2487 = heff_dup(heff_env(self)[0]);
  V v_x_2491 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_24109);
  return heff_tail(v_k_2487, 1, (V[]){heff_get(v_x_2491, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam22(V self, V *args) {
  V v_x_24107 = args[0];
  V v_id_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2486 = heff_dup(heff_env(self)[1]);
  V v_k_2487 = heff_dup(heff_env(self)[2]);
  V v_x_2491 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_24108 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_x_24107})));
  return heff_tail(v_c_24108, 2, (V[]){v_hd_2486, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam23, 1, 2, (V[]){v_k_2487, v_x_2491})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam21(V self, V *args) {
  V v_x_2491 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_hd_2486 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  V v_k_2487 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2492 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str13), NTAG(TAG_Nil)});
  V v_it_2493 = ({ V a_0 = v_t_2492; V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop(v_t_2492); r_; });
  V v_x2_24101;
  switch (heff_tag_of(v_it_2493)) {
  case TAG_Nothing: {
    heff_drop(v_it_2493);
    v_x2_24101 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2494 = heff_field(v_it_2493, 0);
    V v_ru_24it_2493_24Just = heff_take_reuse(v_it_2493, 1ULL);
    switch (heff_tag_of(v_it1_2494)) {
    case TAG_JNull: {
      heff_drop(v_it1_2494);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_2494, 0ULL);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_2494, 0ULL);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_2494, 0ULL);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_2498 = heff_field(v_it1_2494, 0);
      heff_take(v_it1_2494, 1ULL);
      v_x2_24101 = heff_tag_at(v_ru_24it_2493_24Just, TAG_Just, 1, (V[]){v_s_2498});
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_2494, 0ULL);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_2494, 0ULL);
      heff_drop(v_ru_24it_2493_24Just);
      v_x2_24101 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2494);
    }
    break;
  }
  default: heff_nomatch(v_it_2493);
  }
  V v_s_24103;
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_Nothing: {
    heff_drop(v_x2_24101);
    v_s_24103 = ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str14);
    break;
  }
  case TAG_Just: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    heff_take(v_x2_24101, 1ULL);
    v_s_24103 = v_x_24102;
    break;
  }
  default: heff_nomatch(v_x2_24101);
  }
  V v_t_24104 = (g_heff_2elsp_2elowerGo(v_s_24103, MK_INT(0LL), ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str15)));
  V v_t_24105 = (g_heff_2elsp_2enubCheckedPaths(heff_get(heff_dup(v_x_2491), LBL_program)));
  V v_c_24106 = ({ V a_0 = heff_get(heff_dup(v_x_2491), LBL_st); V a_1 = v_t_24104; V a_2 = v_t_24105; V r_ = (g_heff_2elsp_2esymbolsJson_24s984_24s1210(a_0, a_1, a_2)); heff_drop(v_t_24105); r_; });
  return heff_tail(v_c_24106, 2, (V[]){heff_dup(v_hd_2486), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam22, 1, 4, (V[]){v_id_242, v_hd_2486, v_k_2487, v_x_2491})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam20(V self, V *args) {
  V v_x_2488 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_hd_2486 = heff_dup(heff_env(self)[1]);
  V v_p_243 = heff_dup(heff_env(self)[2]);
  V v_id_242 = heff_dup(heff_env(self)[3]);
  V v_k_2487 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2489 = (g_heff_2elsp_2enubRoots(v_x_2488));
  V v_c_2490 = ({ V a_0 = v_st_240; V a_1 = v_t_2489; V r_ = (g_heff_2elsp_2eprojects_24s979_24s1165_24s1206(a_0, a_1)); heff_drop(v_t_2489); r_; });
  return heff_tail(v_c_2490, 2, (V[]){heff_dup(v_hd_2486), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam21, 1, 4, (V[]){v_p_243, v_hd_2486, v_id_242, v_k_2487})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam19(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_c_2485 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_p_243 = heff_dup(heff_env(self)[2]);
  V v_id_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2485, 2, (V[]){heff_dup(v_hd_2486), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam20, 1, 5, (V[]){v_st_240, v_hd_2486, v_p_243, v_id_242, v_k_2487})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam26(V self, V *args) {
  V v_o_24117 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24118 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str17), NTAG(TAG_Nil)});
  V v_it_24119 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str18), v_t_24118}); V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_24127;
  switch (heff_tag_of(v_it_24119)) {
  case TAG_Nothing: {
    heff_drop(v_it_24119);
    v_x2_24127 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24120 = heff_field(v_it_24119, 0);
    V v_ru_24it_24119_24Just = heff_take_reuse(v_it_24119, 1ULL);
    switch (heff_tag_of(v_it1_24120)) {
    case TAG_JNull: {
      heff_drop(v_it1_24120);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_24121 = heff_field(v_it1_24120, 0);
      heff_take(v_it1_24120, 1ULL);
      v_x2_24127 = heff_tag_at(v_ru_24it_24119_24Just, TAG_Just, 1, (V[]){v_b_24121});
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_24120, 0ULL);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_24120, 0ULL);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take(v_it1_24120, 0ULL);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_24120, 0ULL);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_24120, 0ULL);
      heff_drop(v_ru_24it_24119_24Just);
      v_x2_24127 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24120);
    }
    break;
  }
  default: heff_nomatch(v_it_24119);
  }
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_Nothing: {
    heff_drop(v_o_24117);
    heff_drop(v_x2_24127);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    heff_take(v_x2_24127, 1ULL);
    switch (heff_tag_of(v_x_24128)) {
    case TAG_True: {
      heff_drop(v_o_24117);
      heff_drop(v_x_24128);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_x_24128);
      V v_t_24129 = heff_get(v_o_24117, LBL_defines);
      switch (heff_tag_of(v_t_24129)) {
      case TAG_True: {
        heff_drop(v_t_24129);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        heff_drop(v_t_24129);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_24129);
      }
    }
    default: return heff_nomatch(v_x_24128);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam28(V self, V *args) {
  V v_x_24134 = args[0];
  V v_id_242 = heff_dup(heff_env(self)[0]);
  V v_hd_24132 = heff_dup(heff_env(self)[1]);
  V v_k_24133 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_24135 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_x_24134})));
  return heff_tail(v_t_24135, 2, (V[]){v_hd_24132, v_k_24133});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam27(V self, V *args) {
  V v_hd_24132 = args[0];
  V v_k_24133 = args[1];
  V v_c_24131 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_24131, 2, (V[]){heff_dup(v_hd_24132), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam28, 1, 3, (V[]){v_id_242, v_hd_24132, v_k_24133})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam29(V self, V *args) {
  V v_x_24137 = args[0];
  V v_k_24113 = heff_dup(heff_env(self)[0]);
  V v_x_24114 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_24137);
  return heff_tail(v_k_24113, 1, (V[]){heff_get(v_x_24114, LBL_st)});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam25(V self, V *args) {
  V v_x_24114 = args[0];
  V v_id_242 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_hd_24112 = heff_dup(heff_env(self)[2]);
  V v_k_24113 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_24115 = heff_get(heff_dup(v_x_24114), LBL_target);
  V v_c_24136;
  switch (heff_tag_of(v_t_24115)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    heff_drop(v_t_24115);
    v_c_24136 = (g_heff_2elsp_2ereply_24s975_24s1203(v_id_242, NTAG(TAG_JNull)));
    break;
  }
  case TAG_Just: {
    V v_t_24116 = heff_field(v_t_24115, 0);
    heff_take(v_t_24115, 1ULL);
    V v_t_24130 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam26, 1, 1, (V[]){v_p_243}), heff_get(v_t_24116, LBL_occurrences)));
    V v_c_24131 = (g_heff_2elsp_2elocations_24s988_24s1214(heff_get(heff_dup(v_x_24114), LBL_st), v_t_24130));
    v_c_24136 = heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam27, 2, 2, (V[]){v_c_24131, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24115);
  }
  return heff_tail(v_c_24136, 2, (V[]){v_hd_24112, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam29, 1, 2, (V[]){v_k_24113, v_x_24114})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam24(V self, V *args) {
  V v_hd_24112 = args[0];
  V v_k_24113 = args[1];
  V v_c_24111 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_p_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_24111, 2, (V[]){heff_dup(v_hd_24112), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam25, 1, 4, (V[]){v_id_242, v_p_243, v_hd_24112, v_k_24113})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam31(V self, V *args) {
  V v_x_24142 = args[0];
  V v_id_242 = heff_dup(heff_env(self)[0]);
  V v_hd_24140 = heff_dup(heff_env(self)[1]);
  V v_k_24141 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_24143 = (g_heff_2elsp_2eprepared_24s990_24s1216(v_id_242, v_x_24142));
  return heff_tail(v_t_24143, 2, (V[]){v_hd_24140, v_k_24141});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam30(V self, V *args) {
  V v_hd_24140 = args[0];
  V v_k_24141 = args[1];
  V v_c_24139 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_24139, 2, (V[]){heff_dup(v_hd_24140), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam31, 1, 3, (V[]){v_id_242, v_hd_24140, v_k_24141})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam33(V self, V *args) {
  V v_x_24148 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_id_242 = heff_dup(heff_env(self)[1]);
  V v_hd_24146 = heff_dup(heff_env(self)[2]);
  V v_k_24147 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_24149 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str21), NTAG(TAG_Nil)});
  V v_it_24150 = ({ V a_0 = v_t_24149; V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop(v_t_24149); r_; });
  V v_x2_24158;
  switch (heff_tag_of(v_it_24150)) {
  case TAG_Nothing: {
    heff_drop(v_it_24150);
    v_x2_24158 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24151 = heff_field(v_it_24150, 0);
    V v_ru_24it_24150_24Just = heff_take_reuse(v_it_24150, 1ULL);
    switch (heff_tag_of(v_it1_24151)) {
    case TAG_JNull: {
      heff_drop(v_it1_24151);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_24151, 0ULL);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_24151, 0ULL);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_24151, 0ULL);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24155 = heff_field(v_it1_24151, 0);
      heff_take(v_it1_24151, 1ULL);
      v_x2_24158 = heff_tag_at(v_ru_24it_24150_24Just, TAG_Just, 1, (V[]){v_s_24155});
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_24151, 0ULL);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_24151, 0ULL);
      heff_drop(v_ru_24it_24150_24Just);
      v_x2_24158 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24151);
    }
    break;
  }
  default: heff_nomatch(v_it_24150);
  }
  V v_t_24160;
  switch (heff_tag_of(v_x2_24158)) {
  case TAG_Nothing: {
    heff_drop(v_x2_24158);
    v_t_24160 = ((V)&g_heff_2elsp_2erequest_24s974_24s1162_24s1202_str22);
    break;
  }
  case TAG_Just: {
    V v_x_24159 = heff_field(v_x2_24158, 0);
    heff_take(v_x2_24158, 1ULL);
    v_t_24160 = v_x_24159;
    break;
  }
  default: heff_nomatch(v_x2_24158);
  }
  V v_t_24161 = (g_heff_2elsp_2erenamed_24s991_24s1171_24s1217(v_id_242, v_t_24160, v_x_24148));
  return heff_tail(v_t_24161, 2, (V[]){v_hd_24146, v_k_24147});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam32(V self, V *args) {
  V v_hd_24146 = args[0];
  V v_k_24147 = args[1];
  V v_c_24145 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_id_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_24145, 2, (V[]){heff_dup(v_hd_24146), heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam33, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24146, v_k_24147})});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam35(V self, V *args) {
  V v_x_24166 = args[0];
  V v_k_24165 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_24166);
  return heff_tail(v_k_24165, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam34(V self, V *args) {
  V v_hd_24164 = args[0];
  V v_k_24165 = args[1];
  V v_c_24163 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_24163, 2, (V[]){v_hd_24164, heff_clo(g_heff_2elsp_2erequest_24s974_24s1162_24s1202_lam35, 1, 2, (V[]){v_k_24165, v_st_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 104, 117, 116, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 104, 117, 116, 32, 100, 111, 119, 110}};
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam0(V self, V *args);
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam2(V self, V *args);
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam1(V self, V *args);
Clo g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_entry, 2, 0};

V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193(V v_st_240, V v_msg_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V a_0 = v_t_242; V a_1 = heff_dup(v_msg_241); V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_it_243);
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop(v_it1_244);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_248 = heff_field(v_it1_244, 0);
      heff_take(v_it1_244, 1ULL);
      v_t_2411 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_s_248});
      break;
    }
    case TAG_JArray: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take(v_it1_244, 0ULL);
      heff_drop(v_ru_24it_243_24Just);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    heff_drop(v_t_2411);
    return heff_clo(g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse(v_t_2411, 1ULL);
    V v_t_2426;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop(v_ru_24t_2411_24Just);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2420 = heff_dup(heff_field(v_msg_241, 0));
      V v_t_2421 = ({ V a_0 = v_fs_2420; V r_ = (g_prelude_2efind_24s834(a_0)); heff_drop(v_fs_2420); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24t_2411_24Just);
        heff_drop(v_t_2421);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2422 = heff_field(v_t_2421, 0);
        heff_take(v_t_2421, 1ULL);
        V v_t_2425;
        switch (heff_tag_of(v_p_2422)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_p_2422, 1);
          heff_take(v_p_2422, 2ULL);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_p_2422);
        }
        v_t_2426 = heff_tag_at(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2425});
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      heff_drop(v_t_2426);
      V v_x2_2438;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        heff_drop(v_msg_241);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take(v_msg_241, 0ULL);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take(v_msg_241, 0ULL);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take(v_msg_241, 0ULL);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_take(v_msg_241, 0ULL);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take(v_msg_241, 0ULL);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        V v_fs_2432 = heff_field(v_msg_241, 0);
        V v_ru_24msg_241_24JObject = heff_take_reuse(v_msg_241, 1ULL);
        V v_t_2433 = ({ V a_0 = v_fs_2432; V r_ = (g_prelude_2efind_24s835(a_0)); heff_drop(v_fs_2432); r_; });
        switch (heff_tag_of(v_t_2433)) {
        case TAG_Nothing: {
          heff_drop(v_ru_24msg_241_24JObject);
          heff_drop(v_t_2433);
          v_x2_2438 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_2434 = heff_field(v_t_2433, 0);
          heff_take(v_t_2433, 1ULL);
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take(v_p_2434, 2ULL);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_x2_2438 = heff_tag_at(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_t_2437});
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2438);
        v_t_2440 = NTAG(TAG_JNull);
        break;
      }
      case TAG_Just: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        heff_take(v_x2_2438, 1ULL);
        v_t_2440 = v_x_2439;
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return (g_heff_2elsp_2enotification_24s965_24s1154_24s1194(v_st_240, v_m_2414, v_t_2440));
    }
    case TAG_Just: {
      V v_id_2441 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse(v_t_2426, 1ULL);
      V v_t_2442 = heff_get(heff_dup(v_st_240), LBL_shutdown);
      V v_t_2444;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        heff_drop(v_t_2442);
        V v_t_2443 = heff_strEq(heff_dup(v_m_2414), ((V)&g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str1));
        switch (heff_tag_of(v_t_2443)) {
        case TAG_True: {
          heff_drop(v_t_2443);
          v_t_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2443);
          v_t_2444 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2442);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      switch (heff_tag_of(v_t_2444)) {
      case TAG_True: {
        heff_drop(v_msg_241);
        heff_drop(v_m_2414);
        heff_drop(v_ru_24t_2426_24Just);
        heff_drop(v_t_2444);
        V v_c_2445 = (g_heff_2elsp_2ereplyError_24s973_24s1201(v_id_2441, MK_INT(-32600LL), ((V)&g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_str2)));
        return heff_clo(g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam1, 2, 2, (V[]){v_c_2445, v_st_240});
      }
      case TAG_False: {
        heff_drop(v_t_2444);
        V v_x2_2460;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          heff_drop(v_msg_241);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take(v_msg_241, 0ULL);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take(v_msg_241, 0ULL);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take(v_msg_241, 0ULL);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_take(v_msg_241, 0ULL);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_take(v_msg_241, 0ULL);
          heff_drop(v_ru_24t_2426_24Just);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2454 = heff_field(v_msg_241, 0);
          heff_take(v_msg_241, 1ULL);
          V v_t_2455 = ({ V a_0 = v_fs_2454; V r_ = (g_prelude_2efind_24s835(a_0)); heff_drop(v_fs_2454); r_; });
          switch (heff_tag_of(v_t_2455)) {
          case TAG_Nothing: {
            heff_drop(v_ru_24t_2426_24Just);
            heff_drop(v_t_2455);
            v_x2_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_p_2456 = heff_field(v_t_2455, 0);
            heff_take(v_t_2455, 1ULL);
            V v_t_2459;
            switch (heff_tag_of(v_p_2456)) {
            case TAG_MkPair: {
              V v_y_2458 = heff_field(v_p_2456, 1);
              heff_take(v_p_2456, 2ULL);
              v_t_2459 = v_y_2458;
              break;
            }
            default: heff_nomatch(v_p_2456);
            }
            v_x2_2460 = heff_tag_at(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_t_2459});
            break;
          }
          default: heff_nomatch(v_t_2455);
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        V v_t_2462;
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_Nothing: {
          heff_drop(v_x2_2460);
          v_t_2462 = NTAG(TAG_JNull);
          break;
        }
        case TAG_Just: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          heff_take(v_x2_2460, 1ULL);
          v_t_2462 = v_x_2461;
          break;
        }
        default: heff_nomatch(v_x2_2460);
        }
        return (g_heff_2elsp_2erequest_24s974_24s1162_24s1202(v_st_240, v_m_2414, v_id_2441, v_t_2462));
      }
      default: return heff_nomatch(v_t_2444);
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ehandle_24s964_24s1153_24s1193(a[0], a[1]);
}
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2412);
  return heff_tail(v_k_2413, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2448);
  return heff_tail(v_k_2447, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam1(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2445, 2, (V[]){v_hd_2446, heff_clo(g_heff_2elsp_2ehandle_24s964_24s1153_24s1193_lam2, 1, 2, (V[]){v_k_2447, v_st_240})});
}
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam0(V self, V *args);
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam2(V self, V *args);
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam1(V self, V *args);
Clo g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_entry, 2, 0};

V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2echeckNow_24s972_24s1161_24s1200(v_st_240, heff_dup(v_f_244)));
    return heff_clo(g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){v_st_240});
}
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_245 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_k_248 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2410, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222_lam2, 1, 3, (V[]){v_rest_245, v_hd_247, v_k_248})});
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam0(V self, V *args); static Clo g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam0, 1, 0};
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam3(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam4(V self, V *args); static Clo g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam4, 1, 0};
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam6(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam7(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam5(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam2(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam1(V self, V *args);
Clo g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_entry, 3, 0};

V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam0_clo)})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(self);
  return v_n_243;
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(v_x_2420, v_hd_241, v_k_242));
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  heff_drop(self);
  return v_n_2421;
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam6(V self, V *args) {
  V v_q_2426 = args[0];
  V v_x_2424 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2429;
  switch (heff_tag_of(v_q_2426)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_q_2426, 1);
    heff_take(v_q_2426, 2ULL);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_q_2426);
  }
  return heff_intLe(v_t_2429, v_x_2424);
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(v_x_2433, v_hd_241, v_k_242));
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2425 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_due); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2430 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam6, 1, 1, (V[]){v_x_2424}), v_t_2425));
  V v_t_2431 = (g_prelude_2emap_24s5(v_t_2430));
  V v_c_2432 = ({ V a_0 = v_st_240; V a_1 = v_t_2431; V r_ = (g_heff_2elsp_2echeckDue_24s996_24s1174_24s1222(a_0, a_1)); heff_drop(v_t_2431); r_; });
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam7, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Message: {
    V v_msg_2418 = heff_field(v_x_2417, 0);
    heff_take(v_x_2417, 1ULL);
    V v_c_2419 = (g_heff_2elsp_2ehandle_24s964_24s1153_24s1193(v_st_240, v_msg_2418));
    return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam3, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Timeout: {
    heff_drop(v_x_2417);
    V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam4_clo)})});
    V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2422}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2423, heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam5, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
  }
  case TAG_Closed: {
    heff_drop(v_x_2417);
    heff_drop(v_st_240);
    V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2434}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2435, v_k_242});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_due); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = (g_prelude_2emap_24s6(v_t_247));
  V v_t_2415;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_x_246);
    heff_drop(v_t_248);
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_249 = heff_field(v_t_248, 0);
    V v_ds_2410 = heff_field(v_t_248, 1);
    heff_take(v_t_248, 3ULL);
    V v_t_2411 = ({ V a_0 = v_d_249; V a_1 = v_ds_2410; V r_ = (g_prelude_2efoldl_24s550(a_0, a_1)); heff_drop(v_ds_2410); r_; });
    V v_b_2412 = heff_intSub(v_t_2411, v_x_246);
    V v_t_2413 = heff_intLe(MK_INT(0LL), heff_dup(v_b_2412));
    V v_t_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_t_2413);
      v_t_2414 = v_b_2412;
      break;
    }
    case TAG_False: {
      heff_drop(v_b_2412);
      heff_drop(v_t_2413);
      v_t_2414 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    v_t_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_2414});
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_c_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2erpc_2eawait_24s963_24s1192(a_0)); heff_drop(v_t_2415); r_; });
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191_lam2, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam0(V self, V *args); static Clo g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam0, 1, 0};
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam1(V self, V *args);
Clo g_heff_2elsp_2eserve_24s961_24s1151_24s1190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserve_24s961_24s1151_24s1190_entry, 3, 0};

V g_heff_2elsp_2eserve_24s961_24s1151_24s1190(V v_h0_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_AbsPath, 2, (V[]){heff_get(heff_dup(v_h0_240), LBL_lib), ((V)&g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam0_clo)});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam1, 1, 3, (V[]){v_h0_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eserve_24s961_24s1151_24s1190(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam0(V self, V *args) {
  V v_a_243 = args[0];
  heff_drop(self);
  return v_a_243;
}
V g_heff_2elsp_2eserve_24s961_24s1151_24s1190_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h0_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = heff_rec(3, shape_166_183_312, (V[]){v_x_246, heff_get(heff_dup(v_h0_240), LBL_mod), heff_get(v_h0_240, LBL_style)});
  V v_t_248 = heff_rec(7, shape_64_38_69_247_358_291_166, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_247});
  return (g_heff_2elsp_2eserveFrom_24s962_24s1152_24s1191(v_t_248, v_hd_241, v_k_242));
}