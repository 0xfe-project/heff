// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_defines 1776893014
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_hmap 9701563
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_lib__mod__style[] = {LBL_lib, LBL_mod, LBL_style};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eplus_24s1682480088x1491420330_get(void);
V g_heff_2edriver_2efixitiesGo(V, V);
V g_heff_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixitiesGo_clo;
V g_heff_2edriver_2etraceless(V);
V g_heff_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2edriver_2etraceless_clo;
V g_heff_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2eformat_2echeck(V, V);
V g_heff_2eformat_2echeck_entry(V self, V *a);
extern Clo g_heff_2eformat_2echeck_clo;
V g_heff_2eimport_2eimportsGo(V, V, V);
V g_heff_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsGo_clo;
V g_heff_2ejson_2eat(V, V);
V g_heff_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2ejson_2eat_clo;
V g_heff_2ejson_2estringify(V);
V g_heff_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2ejson_2estringify_clo;
V g_heff_2eload_2eloadProgramWith_24s1828132383x744561138(V, V, V);
V g_heff_2eload_2eloadProgramWith_24s1828132383x744561138_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadProgramWith_24s1828132383x744561138_clo;
V g_heff_2eload_2epathsFor_24s382934904x1572524859(V, V);
V g_heff_2eload_2epathsFor_24s382934904x1572524859_entry(V self, V *a);
extern Clo g_heff_2eload_2epathsFor_24s382934904x1572524859_clo;
V g_heff_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2echanged_clo;
V g_heff_2elsp_2echangesOf_24s1237264701x531281792(V, V, V);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_entry(V self, V *a);
extern Clo g_heff_2elsp_2echangesOf_24s1237264701x531281792_clo;
V g_heff_2elsp_2echeck_24s447642999x1873703689(V, V);
V g_heff_2elsp_2echeck_24s447642999x1873703689_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeck_24s447642999x1873703689_clo;
V g_heff_2elsp_2echeckAll_24s417884660x239518827(V, V);
V g_heff_2elsp_2echeckAll_24s417884660x239518827_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeckAll_24s417884660x239518827_clo;
V g_heff_2elsp_2echeckDue_24s217346529x82598444(V, V);
V g_heff_2elsp_2echeckDue_24s217346529x82598444_entry(V self, V *a);
extern Clo g_heff_2elsp_2echeckDue_24s217346529x82598444_clo;
V g_heff_2elsp_2echildJson(V, V);
V g_heff_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2echildJson_clo;
V g_heff_2elsp_2eclosed(V, V);
V g_heff_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2eclosed_clo;
V g_heff_2elsp_2edependentsOf(V, V);
V g_heff_2elsp_2edependentsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2edependentsOf_clo;
V g_heff_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2edocPath_24s133079231x401204893(V);
V g_heff_2elsp_2edocPath_24s133079231x401204893_entry(V self, V *a);
extern Clo g_heff_2elsp_2edocPath_24s133079231x401204893_clo;
V g_heff_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185(V, V, V);
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_entry(V self, V *a);
extern Clo g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_clo;
V g_heff_2elsp_2eelabProject_24s511942051x460406311(V, V, V, V, V, V);
V g_heff_2elsp_2eelabProject_24s511942051x460406311_entry(V self, V *a);
extern Clo g_heff_2elsp_2eelabProject_24s511942051x460406311_clo;
V g_heff_2elsp_2eformatted_24s1337690268x1684540053(V, V, V);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_entry(V self, V *a);
extern Clo g_heff_2elsp_2eformatted_24s1337690268x1684540053_clo;
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537(V, V, V, V);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_entry(V self, V *a);
extern Clo g_heff_2elsp_2eformattedIn_24s1483613779x861159537_clo;
V g_heff_2elsp_2ehandle_24s574943937x1766520211(V, V);
V g_heff_2elsp_2ehandle_24s574943937x1766520211_entry(V self, V *a);
extern Clo g_heff_2elsp_2ehandle_24s574943937x1766520211_clo;
V g_heff_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2ekeptOf(V);
V g_heff_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elastChange(V);
V g_heff_2elsp_2elastChange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elastChange_clo;
V g_heff_2elsp_2eloadAll_24s1742300915x648307049(V, V, V);
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_entry(V self, V *a);
extern Clo g_heff_2elsp_2eloadAll_24s1742300915x648307049_clo;
V g_heff_2elsp_2eloadError(V, V);
V g_heff_2elsp_2eloadError_entry(V self, V *a);
extern Clo g_heff_2elsp_2eloadError_clo;
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417(V, V);
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_entry(V self, V *a);
extern Clo g_heff_2elsp_2elocationOf_24s1283476421x1140385417_clo;
V g_heff_2elsp_2elocations_24s577879234x1794888942(V, V);
V g_heff_2elsp_2elocations_24s577879234x1794888942_entry(V self, V *a);
extern Clo g_heff_2elsp_2elocations_24s577879234x1794888942_clo;
V g_heff_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elowerGo_clo;
V g_heff_2elsp_2enotification_24s1809009350x1217072135(V, V, V);
V g_heff_2elsp_2enotification_24s1809009350x1217072135_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotification_24s1809009350x1217072135_clo;
V g_heff_2elsp_2enotified_24s1317056913x1433573017(V, V, V);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotified_24s1317056913x1433573017_clo;
V g_heff_2elsp_2enotify_24s2066566305x1387019196(V, V);
V g_heff_2elsp_2enotify_24s2066566305x1387019196_entry(V self, V *a);
extern Clo g_heff_2elsp_2enotify_24s2066566305x1387019196_clo;
V g_heff_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2enubPaths(V);
V g_heff_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubPaths_clo;
V g_heff_2elsp_2enubRoots(V);
V g_heff_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubRoots_clo;
V g_heff_2elsp_2enubSources(V);
V g_heff_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2enubSources_clo;
V g_heff_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2eposition(V, V);
V g_heff_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2eposition_clo;
V g_heff_2elsp_2eprepared_24s2087070313x466462102(V, V);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprepared_24s2087070313x466462102_clo;
V g_heff_2elsp_2eproject_24s545014642x2143879243(V, V);
V g_heff_2elsp_2eproject_24s545014642x2143879243_entry(V self, V *a);
extern Clo g_heff_2elsp_2eproject_24s545014642x2143879243_clo;
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762(V, V, V, V, V);
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_clo;
V g_heff_2elsp_2eprojects_24s1224286600x2087827045(V, V);
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_entry(V self, V *a);
extern Clo g_heff_2elsp_2eprojects_24s1224286600x2087827045_clo;
V g_heff_2elsp_2erange(V, V);
V g_heff_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2erange_clo;
V g_heff_2elsp_2eregistration_get(void);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457(V, V, V);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenameChecked_24s302972845x403386457_clo;
V g_heff_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2erenamed_24s901799183x2053671681(V, V, V);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamed_24s901799183x2053671681_clo;
V g_heff_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2erenamedText(V, V);
V g_heff_2elsp_2erenamedText_entry(V self, V *a);
extern Clo g_heff_2elsp_2erenamedText_clo;
V g_heff_2elsp_2ereply_24s1469169503x1913753224(V, V);
V g_heff_2elsp_2ereply_24s1469169503x1913753224_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereply_24s1469169503x1913753224_clo;
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297(V, V, V);
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereplyError_24s1722239765x1825266297_clo;
V g_heff_2elsp_2erequest_24s453191689x1199998842(V, V, V, V);
V g_heff_2elsp_2erequest_24s453191689x1199998842_entry(V self, V *a);
extern Clo g_heff_2elsp_2erequest_24s453191689x1199998842_clo;
V g_heff_2elsp_2erootsOf_24s535930516x390676296(V, V);
V g_heff_2elsp_2erootsOf_24s535930516x390676296_entry(V self, V *a);
extern Clo g_heff_2elsp_2erootsOf_24s535930516x390676296_clo;
V g_heff_2elsp_2eserve_24s1076151099x109167290(V, V, V);
V g_heff_2elsp_2eserve_24s1076151099x109167290_entry(V self, V *a);
extern Clo g_heff_2elsp_2eserve_24s1076151099x109167290_clo;
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618(V, V, V);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_entry(V self, V *a);
extern Clo g_heff_2elsp_2eserveFrom_24s971709170x1335763618_clo;
V g_heff_2elsp_2eshiftOf(V, V, V);
V g_heff_2elsp_2eshiftOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2eshiftOf_clo;
V g_heff_2elsp_2esymbolJson_24s317767108x209947191(V, V, V);
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_entry(V self, V *a);
extern Clo g_heff_2elsp_2esymbolJson_24s317767108x209947191_clo;
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847(V, V, V);
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_entry(V self, V *a);
extern Clo g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_clo;
V g_heff_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2etargetIn_clo;
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959(V, V);
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_entry(V self, V *a);
extern Clo g_heff_2elsp_2ewithProgram_24s1295466243x875227959_clo;
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(V, V);
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_entry(V self, V *a);
extern Clo g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_clo;
V g_heff_2elsp_2ezeroSpan_get(void);
V g_heff_2equery_2ecompletionsAt(V, V);
V g_heff_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2equery_2ecompletionsAt_clo;
V g_heff_2equery_2edefinitionAt(V, V);
V g_heff_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2equery_2edefinitionAt_clo;
V g_heff_2equery_2eoccurrences(V, V, V);
V g_heff_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2equery_2eoccurrences_clo;
V g_heff_2equery_2erenameRefused(V, V, V);
V g_heff_2equery_2erenameRefused_entry(V self, V *a);
extern Clo g_heff_2equery_2erenameRefused_clo;
V g_heff_2equery_2esymbols(V);
V g_heff_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2equery_2esymbols_clo;
V g_heff_2equery_2etargetAt(V, V);
V g_heff_2equery_2etargetAt_entry(V self, V *a);
extern Clo g_heff_2equery_2etargetAt_clo;
V g_heff_2equery_2etypeAt(V, V);
V g_heff_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2equery_2etypeAt_clo;
V g_heff_2erender_2elineColGo(V, V, V, V);
V g_heff_2erender_2elineColGo_entry(V self, V *a);
extern Clo g_heff_2erender_2elineColGo_clo;
V g_heff_2esession_2ecachedProgram_24s595918180x507103762(V);
V g_heff_2esession_2ecachedProgram_24s595918180x507103762_entry(V self, V *a);
extern Clo g_heff_2esession_2ecachedProgram_24s595918180x507103762_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2edrop(V, V);
V g_prelude_2edrop_entry(V self, V *a);
extern Clo g_prelude_2edrop_clo;
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efilter_24s1056866665x1882138159(V);
V g_prelude_2efilter_24s1056866665x1882138159_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1056866665x1882138159_clo;
V g_prelude_2efind(V, V);
V g_prelude_2efind_entry(V self, V *a);
extern Clo g_prelude_2efind_clo;
V g_prelude_2efind_24s1996057548x665004299(V, V);
V g_prelude_2efind_24s1996057548x665004299_entry(V self, V *a);
extern Clo g_prelude_2efind_24s1996057548x665004299_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1163606919x177582362(V, V);
V g_prelude_2efoldl_24s1163606919x177582362_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1163606919x177582362_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s656731303x133259214(V, V, V, V);
V g_prelude_2efoldl_24s656731303x133259214_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s656731303x133259214_clo;
V g_prelude_2efoldl_24s919661041x794023661(V, V);
V g_prelude_2efoldl_24s919661041x794023661_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s919661041x794023661_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1375608508x1745238686(V);
V g_prelude_2emap_24s1375608508x1745238686_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1375608508x1745238686_clo;
V g_prelude_2emap_24s1581021428x1223114127(V);
V g_prelude_2emap_24s1581021428x1223114127_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1581021428x1223114127_clo;
V g_prelude_2emap_24s531459667x996402587(V);
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a);
extern Clo g_prelude_2emap_24s531459667x996402587_clo;
V g_prelude_2emap_24s697897431x2046530597(V);
V g_prelude_2emap_24s697897431x2046530597_entry(V self, V *a);
extern Clo g_prelude_2emap_24s697897431x2046530597_clo;
V g_prelude_2emap_24s816432673x804125000(V);
V g_prelude_2emap_24s816432673x804125000_entry(V self, V *a);
extern Clo g_prelude_2emap_24s816432673x804125000_clo;

static V g_heff_2elsp_2ejtrue_val;
static int g_heff_2elsp_2ejtrue_st;
static V g_heff_2elsp_2ejtrue_init(void) {
  return heff_tag(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2ejtrue_get(void) {
  if (g_heff_2elsp_2ejtrue_st == 2) return g_heff_2elsp_2ejtrue_val;
  if (g_heff_2elsp_2ejtrue_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ejtrue_st = 1;
  g_heff_2elsp_2ejtrue_val = heff_tr(g_heff_2elsp_2ejtrue_init());
  g_heff_2elsp_2ejtrue_st = 2;
  return g_heff_2elsp_2ejtrue_val;
}

static V g_heff_2elsp_2ejfalse_val;
static int g_heff_2elsp_2ejfalse_st;
static V g_heff_2elsp_2ejfalse_init(void) {
  return heff_tag(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2ejfalse_get(void) {
  if (g_heff_2elsp_2ejfalse_st == 2) return g_heff_2elsp_2ejfalse_val;
  if (g_heff_2elsp_2ejfalse_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ejfalse_st = 1;
  g_heff_2elsp_2ejfalse_val = heff_tr(g_heff_2elsp_2ejfalse_init());
  g_heff_2elsp_2ejfalse_st = 2;
  return g_heff_2elsp_2ejfalse_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eoffsetGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eoffsetGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  V v_t_245 = heff_intLe(heff_dup(v_line_241), heff_dup(v_l_244));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_t_246 = heff_intLe(MK_INT(0LL), heff_dup(v_ch_242));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_t_247 = v_ch_242;
      break;
    }
    case TAG_False: {
      heff_drop(v_ch_242);
      v_t_247 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_a_248 = heff_intAdd(heff_dup(v_i_243), v_t_247);
    V v_x2_249 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2eoffsetGo_str0), heff_dup(v_src_240), v_i_243));
    V v_b_2411;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      v_b_2411 = heff_strLength(v_src_240);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      heff_drop(v_src_240);
      v_b_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2412 = heff_intLe(heff_dup(v_a_248), heff_dup(v_b_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_b_2411);
      return v_a_248;
    }
    case TAG_False: {
      heff_drop(v_a_248);
      return v_b_2411;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_False: {
    V v_t_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2eoffsetGo_str1), heff_dup(v_src_240), v_i_243));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      return heff_strLength(v_src_240);
    }
    case TAG_Just: {
      V v_e_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_e_2414, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eoffsetGo(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2eposition_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {99, 104, 97, 114, 97, 99, 116, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eposition_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 110, 101}};
Clo g_heff_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_a_242 = heff_strLength(heff_dup(v_src_240));
  V v_t_243 = heff_intLe(heff_dup(v_a_242), heff_dup(v_i_241));
  V v_b_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_b_244 = v_a_242;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_242);
    v_b_244 = heff_dup(v_i_241);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_b_244));
  V v_i_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_i_246 = v_b_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_244);
    v_i_246 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = (g_heff_2erender_2elineColGo(heff_dup(v_src_240), v_i_246, MK_INT(0LL), MK_INT(0LL)));
  V v_t_248 = heff_tag(TAG_JInt, 1, (V[]){heff_get(v_t_247, LBL_line)});
  V v_a_249 = heff_strLength(heff_dup(v_src_240));
  V v_t_2410 = heff_intLe(heff_dup(v_a_249), heff_dup(v_i_241));
  V v_b_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_i_241);
    v_b_2411 = v_a_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_249);
    v_b_2411 = v_i_241;
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_intLe(MK_INT(0LL), heff_dup(v_b_2411));
  V v_i_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    v_i_2413 = v_b_2411;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_2411);
    v_i_2413 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = (g_heff_2erender_2elineColGo(v_src_240, v_i_2413, MK_INT(0LL), MK_INT(0LL)));
  V v_t_2415 = heff_tag(TAG_JInt, 1, (V[]){heff_get(v_t_2414, LBL_col)});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eposition_str0), v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eposition_str1), v_t_248}), v_t_2416});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2417});
}
V g_heff_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eposition(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erange_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 97, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2erange_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 110, 100}};
Clo g_heff_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erange_str0), (g_heff_2elsp_2eposition(heff_dup(v_src_240), heff_get(heff_dup(v_sp_241), LBL_start)))});
  V v_a_243 = heff_get(heff_dup(v_sp_241), LBL_start);
  V v_b_244 = heff_get(v_sp_241, LBL_end);
  V v_t_245 = heff_intLe(heff_dup(v_a_243), heff_dup(v_b_244));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_a_243);
    v_t_246 = v_b_244;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_244);
    v_t_246 = v_a_243;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erange_str1), (g_heff_2elsp_2eposition(v_src_240, v_t_246))});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_248})});
}
V g_heff_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erange(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eoffsetIn_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eoffsetIn_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2eoffsetIn_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {99, 104, 97, 114, 97, 99, 116, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eoffsetIn_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {112, 111, 115, 105, 116, 105, 111, 110}};
Clo g_heff_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2412;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_x2_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_246 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      v_x2_2412 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_i_246});
      break;
    }
    case TAG_JFloat: {
      V v_x_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      V v_t_248 = heff_floatFloor(v_x_247);
      v_x2_2412 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_t_248});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  V v_line_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_line_2414 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_line_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
  V v_it_2416 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2eoffsetIn_str3), v_t_2415}); V a_1 = v_params_241; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425;
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nothing: {
    v_x2_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2417 = heff_field(v_it_2416, 0);
    V v_ru_24it_2416_24Just = heff_take_reuse_n(v_it_2416, 1ULL, 1);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_2419 = heff_field(v_it1_2417, 0);
      heff_take_n(v_it1_2417, 1ULL, 1);
      v_x2_2425 = heff_tag_at(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_i_2419});
      break;
    }
    case TAG_JFloat: {
      V v_x_2420 = heff_field(v_it1_2417, 0);
      heff_take_n(v_it1_2417, 1ULL, 1);
      V v_t_2421 = heff_floatFloor(v_x_2420);
      v_x2_2425 = heff_tag_at(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_t_2421});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2417);
    }
    break;
  }
  default: heff_nomatch(v_it_2416);
  }
  V v_ch_2427;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nothing: {
    v_ch_2427 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 1);
    v_ch_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  return (g_heff_2elsp_2eoffsetGo(v_src_240, v_line_2414, v_ch_2427, MK_INT(0LL), MK_INT(0LL)));
}
V g_heff_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eoffsetIn(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ediagnostic_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ediagnostic_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 101, 118, 101, 114, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ediagnostic_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 111, 117, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ediagnostic_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {87}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ediagnostic_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {48, 48, 48, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ediagnostic_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 111, 100, 101}};
Clo g_heff_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str0), (g_heff_2elsp_2erange(v_src_240, heff_get(heff_dup(v_d_241), LBL_span)))});
  V v_t_243 = heff_get(heff_dup(v_d_241), LBL_severity);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str1), heff_tag(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str2), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ediagnostic_str3)})});
  V v_t_247 = heff_get(heff_dup(v_d_241), LBL_note);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_get(heff_dup(v_d_241), LBL_msg);
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_get(heff_dup(v_d_241), LBL_msg), heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str4), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str5), heff_tag(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_intEq(heff_get(heff_dup(v_d_241), LBL_code), MK_INT(0LL));
  V v_t_2423;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_d_241);
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    V v_t_2414 = heff_get(heff_dup(v_d_241), LBL_severity);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_SError: {
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2415 = ((V)&g_heff_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2416 = heff_intShow(heff_get(heff_dup(v_d_241), LBL_code));
    V v_t_2417 = heff_intShow(heff_get(heff_dup(v_d_241), LBL_code));
    V v_t_2418 = heff_strLength(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str9), v_t_2417));
    V v_t_2419 = heff_intShow(heff_get(v_d_241, LBL_code));
    V v_t_2420 = heff_strLength(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str10), v_t_2419));
    V v_t_2421 = heff_strSlice(heff_strAppend(((V)&g_heff_2elsp_2ediagnostic_str11), v_t_2416), heff_intSub(v_t_2418, MK_INT(4LL)), v_t_2420);
    V v_t_2422 = heff_tag(TAG_JString, 1, (V[]){heff_strAppend(v_t_2415, v_t_2421)});
    v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ediagnostic_str12), v_t_2422}), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  return heff_tag(TAG_JObject, 1, (V[]){(g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2412}), v_t_2423))});
}
V g_heff_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ediagnostic(a[0], a[1]);
}

static V g_heff_2elsp_2ezeroSpan_val;
static int g_heff_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2ezeroSpan_init(void) {
  return heff_rec(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2ezeroSpan_get(void) {
  if (g_heff_2elsp_2ezeroSpan_st == 2) return g_heff_2elsp_2ezeroSpan_val;
  if (g_heff_2elsp_2ezeroSpan_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ezeroSpan_st = 1;
  g_heff_2elsp_2ezeroSpan_val = heff_tr(g_heff_2elsp_2ezeroSpan_init());
  g_heff_2elsp_2ezeroSpan_st = 2;
  return g_heff_2elsp_2ezeroSpan_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eloadError_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eloadError_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2elsp_2eloadError_lam0(V self, V *args);
Clo g_heff_2elsp_2eloadError_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadError_entry, 2, 0};

V g_heff_2elsp_2eloadError(V v_imports_240, V v_e_241) {
top: ;
  V v_t_246 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2eloadError_lam0, 1, 1, (V[]){heff_dup(v_e_241)}), v_imports_240));
  V v_sp_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_sp_248 = heff_dup(g_heff_2elsp_2ezeroSpan_get());
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_sp_248 = heff_get(v_i_247, LBL_span);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_241, v_sp_248, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2eloadError_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eloadError(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2eloadError_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_strAppend(((V)&g_heff_2elsp_2eloadError_str0), heff_strAppend(heff_get(v_i_242, LBL_name), ((V)&g_heff_2elsp_2eloadError_str1)));
  V v_x3_244 = (g_prelude_2eindexFrom(v_t_243, v_e_241, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ebrokenImport_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ebrokenImport_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ebrokenImport_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 111, 100, 117, 108, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ebrokenImport_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2ebrokenImport_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {41, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 101, 108, 97, 98, 111, 114, 97, 116, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ebrokenImport_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 101, 114, 114, 111, 114}};
V g_heff_2elsp_2ebrokenImport_lam0(V self, V *args);
V g_heff_2elsp_2ebrokenImport_lam1(V self, V *args);
Clo g_heff_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_prelude_2efilter_24s1056866665x1882138159(heff_get(heff_dup(v_c_241), LBL_diags)));
  V v_x1_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_247 = (g_prelude_2eany(heff_clo(g_heff_2elsp_2ebrokenImport_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_249 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2ebrokenImport_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    V v_sp_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      v_sp_2411 = heff_dup(g_heff_2elsp_2ezeroSpan_get());
      break;
    }
    case TAG_Just: {
      V v_i_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      v_sp_2411 = heff_get(v_i_2410, LBL_span);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_xs_2412 = (g_prelude_2efilter_24s1056866665x1882138159(heff_get(heff_dup(v_c_241), LBL_diags)));
    V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_xs_2414 = (g_prelude_2efilter_24s1056866665x1882138159(heff_get(heff_dup(v_c_241), LBL_diags)));
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    V v_t_2416 = heff_intEq(v_t_2415, MK_INT(1LL));
    V v_t_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_t_2417 = ((V)&g_heff_2elsp_2ebrokenImport_str0);
      break;
    }
    case TAG_False: {
      v_t_2417 = ((V)&g_heff_2elsp_2ebrokenImport_str1);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_msg_2418 = heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str2), heff_strAppend(heff_get(heff_dup(v_c_241), LBL_module), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str3), heff_strAppend(heff_get(v_c_241, LBL_path), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str4), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2elsp_2ebrokenImport_str5), v_t_2417)))))));
    V v_t_2419 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2418, v_sp_2411, NTAG(TAG_Nothing)});
    return heff_tag(TAG_Just, 1, (V[]){v_t_2419});
  }
  case TAG_False: {
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2ebrokenImport(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2ebrokenImport_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_i_246, LBL_name), heff_get(v_c_241, LBL_module));
}
V g_heff_2elsp_2ebrokenImport_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_i_248, LBL_name), heff_get(v_c_241, LBL_module));
}
Clo g_heff_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2elsp_2ecatMaybesL(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ecatMaybesL(a[0]);
}
V g_heff_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get(v_x_244, LBL_diags);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2410 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_program_241));
  V v_xs_2411 = (g_prelude_2edrop(MK_INT(1LL), v_t_2410));
  V v_t_2412 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2411));
  V v_t_2415 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2412));
  V v_t_2416 = (g_heff_2elsp_2ecatMaybesL(v_t_2415));
  V v_t_2417 = (g_prelude_2econcatList(v_t_249, v_t_2416));
  return (g_prelude_2econcatList(v_t_246, v_t_2417));
}
V g_heff_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get(v_t_248, LBL_imports); V a_1 = v_e_247; V r_ = (g_heff_2elsp_2eloadError(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2413 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get(v_t_2414, LBL_imports); V a_1 = v_c_2413; V r_ = (g_heff_2elsp_2ebrokenImport(b_0, a_1)); heff_drop(b_0); r_; });
}
Clo g_heff_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = (g_prelude_2edrop(MK_INT(1LL), v_t_244));
    V v_t_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_prelude_2emap_24s1375608508x1745238686(v_t_246));
    V v_t_248 = (g_heff_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2econcatList(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ekeptOf(a[0]);
}
V g_heff_2elsp_2edependentsOf_lam1(V self, V *args);
V g_heff_2elsp_2edependentsOf_lam0(V self, V *args);
Clo g_heff_2elsp_2edependentsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edependentsOf_entry, 2, 0};

V g_heff_2elsp_2edependentsOf(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(v_st_240, LBL_checked); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2edependentsOf_lam0, 1, 1, (V[]){v_f_241}), v_t_242));
  return (g_prelude_2emap_24s1581021428x1223114127(v_t_2412));
}
V g_heff_2elsp_2edependentsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edependentsOf(a[0], a[1]);
}
V g_heff_2elsp_2edependentsOf_lam1(V self, V *args) {
  V v_c_2411 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_c_2411, LBL_path), v_f_241);
}
V g_heff_2elsp_2edependentsOf_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_x1_247 = heff_strEq(v_t_246, heff_dup(v_f_241));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    heff_drop(v_p_243);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_t_2410;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    return ({ V a_0 = heff_clo(g_heff_2elsp_2edependentsOf_lam1, 1, 1, (V[]){v_f_241}); V b_1 = heff_get(v_t_2410, LBL_program); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2elsp_2enubPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubPaths_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2elsp_2enubPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2enubPaths_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2enubSources_lam0(V self, V *args);
Clo g_heff_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubSources_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_ss_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_241, (g_heff_2elsp_2enubSources(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubSources(a[0]);
}
V g_heff_2elsp_2enubSources_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(heff_get(v_t_243, LBL_path), heff_get(v_s_241, LBL_path));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ecapabilities_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 104, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2ecapabilities_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {105, 110, 99, 108, 117, 100, 101, 84, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2ecapabilities_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {111, 112, 101, 110, 67, 108, 111, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2elsp_2ecapabilities_str4 = {{0x80000000u, K_STR, 0}, 16, 16, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 83, 121, 110, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ecapabilities_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2elsp_2ecapabilities_str6 = {{0x80000000u, K_STR, 0}, 17, 17, {116, 114, 105, 103, 103, 101, 114, 67, 104, 97, 114, 97, 99, 116, 101, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str7 = {{0x80000000u, K_STR, 0}, 18, 18, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2elsp_2ecapabilities_str8 = {{0x80000000u, K_STR, 0}, 15, 15, {112, 114, 101, 112, 97, 114, 101, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2ecapabilities_str9 = {{0x80000000u, K_STR, 0}, 14, 14, {114, 101, 110, 97, 109, 101, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2ecapabilities_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {119, 111, 114, 107, 115, 112, 97, 99, 101, 83, 121, 109, 98, 111, 108, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2ecapabilities_str11 = {{0x80000000u, K_STR, 0}, 22, 22, {100, 111, 99, 117, 109, 101, 110, 116, 83, 121, 109, 98, 111, 108, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {114, 101, 102, 101, 114, 101, 110, 99, 101, 115, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2elsp_2ecapabilities_str13 = {{0x80000000u, K_STR, 0}, 26, 26, {100, 111, 99, 117, 109, 101, 110, 116, 70, 111, 114, 109, 97, 116, 116, 105, 110, 103, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2ecapabilities_str14 = {{0x80000000u, K_STR, 0}, 18, 18, {100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2ecapabilities_str15 = {{0x80000000u, K_STR, 0}, 13, 13, {104, 111, 118, 101, 114, 80, 114, 111, 118, 105, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str16 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ecapabilities_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2ecapabilities_str18 = {{0x80000000u, K_STR, 0}, 10, 10, {115, 101, 114, 118, 101, 114, 73, 110, 102, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2ecapabilities_str19 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 112, 97, 98, 105, 108, 105, 116, 105, 101, 115}};

static V g_heff_2elsp_2ecapabilities_val;
static int g_heff_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str0), heff_tag(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str2), heff_tag(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str4), heff_tag(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str6), heff_tag(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str7), heff_tag(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str9), heff_tag(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str10), heff_dup(g_heff_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str11), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2412});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str12), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str13), heff_dup(g_heff_2elsp_2ejtrue_get())}), heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2414})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2415});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2ejtrue_get())}), v_t_2416});
  V v_t_2418 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_t_2417})});
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str16), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ecapabilities_str17)})});
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str18), heff_tag(TAG_JObject, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ecapabilities_str19), v_t_2418}), v_t_2422});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2ecapabilities_get(void) {
  if (g_heff_2elsp_2ecapabilities_st == 2) return g_heff_2elsp_2ecapabilities_val;
  if (g_heff_2elsp_2ecapabilities_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ecapabilities_st = 1;
  g_heff_2elsp_2ecapabilities_val = heff_tr(g_heff_2elsp_2ecapabilities_init());
  g_heff_2elsp_2ecapabilities_st = 2;
  return g_heff_2elsp_2ecapabilities_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ehoverOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {109, 97, 114, 107, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {96, 96, 96, 104, 101, 102, 102, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ehoverOf_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {10, 96, 96, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ehoverOf_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehoverOf_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 111, 110, 116, 101, 110, 116, 115}};
Clo g_heff_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_a_240), LBL_program)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 1ULL, 2);
    V v_t_245 = (g_heff_2elsp_2eoffsetIn(heff_get(v_a_240, LBL_text), v_p_241));
    V v_t_246 = (g_heff_2equery_2etypeAt(v_x_243, v_t_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_242_24Cons, 2);
      return NTAG(TAG_JNull);
    }
    case TAG_Just: {
      V v_t_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_tag_at(v_ru_24x1_242_24Cons, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ehoverOf_str1)})});
      V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2ehoverOf_str2), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2ehoverOf_str3)));
      V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str4), heff_tag_at(v_ru_24t_246_24Just, TAG_JString, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      V v_t_2412 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2411})});
      V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ehoverOf_str5), v_t_2412}), NTAG(TAG_Nil)});
      return heff_tag(TAG_JObject, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ehoverOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2echildJson_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2echildJson_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 101, 108, 101, 99, 116, 105, 111, 110, 82, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2echildJson_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2echildJson_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
Clo g_heff_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_m_241), LBL_name)});
  V v_t_243 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_m_241), LBL_kind)});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str0), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_get(heff_dup(v_m_241), LBL_span)))});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str1), (g_heff_2elsp_2erange(v_src_240, heff_get(v_m_241, LBL_span)))});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str2), v_t_243}), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echildJson_str3), v_t_242}), v_t_247});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_248});
}
V g_heff_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echildJson(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2edocSymbol_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2edocSymbol_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {115, 101, 108, 101, 99, 116, 105, 111, 110, 82, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2edocSymbol_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 104, 105, 108, 100, 114, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2edocSymbol_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2edocSymbol_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
V g_heff_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_t_242 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_y_241), LBL_name)});
  V v_t_243 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_y_241), LBL_kind)});
  V v_a_244 = heff_get(heff_get(heff_dup(v_y_241), LBL_span), LBL_end);
  V v_b_245 = heff_get(heff_get(heff_dup(v_y_241), LBL_selection), LBL_end);
  V v_t_246 = heff_intLe(heff_dup(v_a_244), heff_dup(v_b_245));
  V v_e_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_a_244);
    v_e_247 = v_b_245;
    break;
  }
  case TAG_False: {
    heff_drop(v_b_245);
    v_e_247 = v_a_244;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_248 = heff_get(heff_get(heff_dup(v_y_241), LBL_span), LBL_start);
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str0), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_rec(2, shape_start__end, (V[]){v_t_248, v_e_247})))});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str1), (g_heff_2elsp_2erange(heff_dup(v_src_240), heff_get(heff_dup(v_y_241), LBL_selection)))});
  V v_t_2412 = heff_tag(TAG_JArray, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), heff_get(v_y_241, LBL_children)))});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str2), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str3), v_t_243}), v_t_2414});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2edocSymbol_str4), v_t_242}), v_t_2415});
  return heff_tag(TAG_JObject, 1, (V[]){v_t_2416});
}
V g_heff_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2echildJson(v_src_240, v_m_2411));
}
Clo g_heff_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_False: {
    V v_t_244 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(90LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        V v_t_246 = heff_intAdd(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL));
        v_t_247 = heff_strFromCharCode(v_t_246);
        break;
      }
      case TAG_False: {
        v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_False: {
      v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_247);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elowerGo(a[0], a[1], a[2]);
}
V g_heff_2elsp_2etargetIn_lam0(V self, V *args);
V g_heff_2elsp_2etargetIn_lam1(V self, V *args);
Clo g_heff_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  V v_t_246 = (g_prelude_2efind(heff_clo(g_heff_2elsp_2etargetIn_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), v_program_244));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_d_242);
    heff_drop(v_p_243);
    heff_drop(v_program_244);
    return heff_rec(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_c_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_248 = heff_strEq(heff_get(heff_dup(v_c_247), LBL_source), heff_get(heff_dup(v_d_242), LBL_text));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2etargetIn_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), heff_dup(v_program_244)));
      V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_c_247, NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2econcatList(v_t_2411, v_t_2412));
      V v_t_2414 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_d_242), LBL_text), heff_dup(v_p_243)));
      V v_t_2415 = (g_heff_2equery_2etargetAt(v_t_2413, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_f_241);
        heff_drop(v_d_242);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        return heff_rec(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
      case TAG_Just: {
        V v_t_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 1);
        V v_off_2417 = (g_heff_2elsp_2eoffsetIn(heff_get(v_d_242, LBL_text), v_p_243));
        V v_occurrences_2418 = (g_heff_2equery_2eoccurrences(v_program_244, heff_get(heff_dup(v_t_2416), LBL_target), heff_get(heff_dup(v_t_2416), LBL_name)));
        V v_t_2419 = heff_rec(4, shape_path__target__name__occurrences, (V[]){v_f_241, heff_get(heff_dup(v_t_2416), LBL_target), heff_get(v_t_2416, LBL_name), v_occurrences_2418});
        V v_target_2420 = heff_tag_at(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2419});
        return heff_rec(3, shape_st__off__target, (V[]){v_st_240, v_off_2417, v_target_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      heff_drop(v_f_241);
      heff_drop(v_d_242);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop(v_c_247);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return heff_rec(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2etargetIn_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_c_245, LBL_path), v_f_241);
}
V g_heff_2elsp_2etargetIn_lam1(V self, V *args) {
  V v_c2_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_strEq(heff_get(v_c2_249, LBL_path), v_f_241);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erenamedText_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2erenamedText_lam0(V self, V *args);
Clo g_heff_2elsp_2erenamedText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamedText_entry, 2, 0};

V g_heff_2elsp_2erenamedText(V v_new_240, V v_os_241) {
top: ;
  V v_z_244;
  switch (heff_tag_of(v_os_241)) {
  case TAG_Nil: {
    v_z_244 = ((V)&g_heff_2elsp_2erenamedText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_os_241, 0));
    v_z_244 = heff_get(v_x_242, LBL_source);
    break;
  }
  default: heff_nomatch(v_os_241);
  }
  V v_t_245 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_os_241));
  return ({ V a_0 = heff_clo(g_heff_2elsp_2erenamedText_lam0, 2, 1, (V[]){v_new_240}); V a_1 = v_z_244; V a_2 = v_t_245; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2elsp_2erenamedText_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamedText(a[0], a[1]);
}
V g_heff_2elsp_2erenamedText_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_new_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get(heff_get(heff_dup(v_x_247), LBL_span), LBL_start);
  V v_t_249 = heff_get(heff_get(v_x_247, LBL_span), LBL_end);
  V v_t_2410 = heff_strSlice(heff_dup(v_acc_246), v_t_249, heff_strLength(heff_dup(v_acc_246)));
  return heff_strAppend(heff_strSlice(v_acc_246, MK_INT(0LL), v_t_248), heff_strAppend(v_new_240, v_t_2410));
}
V g_heff_2elsp_2enubCheckedPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubCheckedPaths_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_cs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_241, (g_heff_2elsp_2enubCheckedPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubCheckedPaths(a[0]);
}
V g_heff_2elsp_2enubCheckedPaths_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(heff_get(v_d_243, LBL_path), heff_get(v_c_241, LBL_path));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2eshiftOf_lam0(V self, V *args);
Clo g_heff_2elsp_2eshiftOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eshiftOf_entry, 3, 0};

V g_heff_2elsp_2eshiftOf(V v_t_240, V v_new_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strLength(heff_get(heff_dup(v_t_240), LBL_name));
  V v_t_244 = heff_intSub(heff_strLength(v_new_241), v_t_243);
  V v_xs_248 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2eshiftOf_lam0, 1, 2, (V[]){heff_dup(v_t_240), v_b_242}), heff_get(v_t_240, LBL_occurrences)));
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
  return heff_intMul(v_t_244, v_t_249);
}
V g_heff_2elsp_2eshiftOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eshiftOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eshiftOf_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_strEq(heff_get(heff_dup(v_o_245), LBL_path), heff_get(v_t_240, LBL_path));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_t_247 = heff_get(heff_get(v_o_245, LBL_span), LBL_start);
    return heff_intLt(v_t_247, heff_get(v_b_242, LBL_start));
  }
  case TAG_False: {
    heff_drop(v_o_245);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_local);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_member);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_key);
      V v_t_245 = heff_get(heff_get(heff_dup(v_t_240), LBL_target), LBL_key);
      V v_t_246 = heff_strLength(heff_get(v_t_240, LBL_name));
      V v_t_247 = heff_intSub(heff_strLength(v_t_245), v_t_246);
      V v_t_248 = heff_strAppend(heff_strSlice(v_t_244, MK_INT(0LL), v_t_247), v_new_241);
      return heff_rec(3, shape_key__member__local, (V[]){v_t_248, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_t_2410 = heff_get(heff_get(v_t_240, LBL_target), LBL_key);
      return heff_rec(3, shape_key__member__local, (V[]){v_t_2410, heff_tag(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Just: {
    V v_b_2411 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_2412 = (g_heff_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2411)));
    V v_s_2413 = heff_intAdd(heff_get(heff_dup(v_b_2411), LBL_start), v_t_2412);
    V v_t_2414 = (g_heff_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2411)));
    V v_t_2415 = heff_intAdd(heff_get(v_b_2411, LBL_start), v_t_2414);
    V v_e_2416 = heff_intAdd(v_t_2415, heff_strLength(v_new_241));
    V v_b_2417 = heff_rec(2, shape_start__end, (V[]){v_s_2413, v_e_2416});
    V v_t_2418 = heff_get(heff_get(v_t_240, LBL_target), LBL_key);
    return heff_rec(3, shape_key__member__local, (V[]){v_t_2418, NTAG(TAG_Nothing), heff_tag(TAG_Just, 1, (V[]){v_b_2417})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamedTarget(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erenameVerdict_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 101, 110, 97, 109, 105, 110, 103, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2erenameVerdict_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {96, 32, 116, 111, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2erenameVerdict_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {96, 32, 119, 111, 117, 108, 100, 32, 109, 97, 107, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2erenameVerdict_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 109, 111, 114, 101, 32, 101, 114, 114, 111, 114, 40, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erenameVerdict_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2elsp_2erenameVerdict_str5 = {{0x80000000u, K_STR, 0}, 60, 60, {96, 32, 105, 115, 32, 97, 108, 114, 101, 97, 100, 121, 32, 97, 32, 110, 97, 109, 101, 32, 115, 111, 109, 101, 32, 111, 102, 32, 116, 104, 101, 115, 101, 32, 111, 99, 99, 117, 114, 114, 101, 110, 99, 101, 115, 32, 119, 111, 117, 108, 100, 32, 114, 101, 102, 101, 114, 32, 116, 111}};
Clo g_heff_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_246 = heff_intLt(heff_dup(v_errorsBefore_243), heff_dup(v_errorsAfter_244));
  V v_t_2415;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str0), heff_strAppend(heff_get(v_t_241, LBL_name), heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str1), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str2), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2erenameVerdict_str3)))))));
    v_t_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_248});
    break;
  }
  case TAG_False: {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_249 = (g_heff_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2410 = (g_heff_2equery_2eoccurrences(v_after_245, v_t_249, heff_dup(v_new_242)));
    V v_a_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    V v_b_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(v_t_241, LBL_occurrences); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2413 = heff_intEq(v_a_2411, v_b_2412);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_new_242);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_False: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2erenameVerdict_str5)));
      v_t_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_before_240, LBL_st), v_t_2415});
}
V g_heff_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_c_243), LBL_path)}));
    V v_t_246 = (g_prelude_2eany(v_t_245, v_changed_240));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_mods_241});
      return heff_tag(TAG_Cons, 2, (V[]){heff_get(v_c_243, LBL_path), (g_heff_2elsp_2eaffectedGo(v_changed_240, v_t_247, v_rest_244))});
    }
    case TAG_False: {
      V v_t_2410 = ({ V a_0 = heff_clo(g_heff_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V b_1 = heff_get(heff_dup(v_c_243), LBL_deps); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_mods_241});
        return heff_tag(TAG_Cons, 2, (V[]){heff_get(v_c_243, LBL_path), (g_heff_2elsp_2eaffectedGo(v_changed_240, v_t_2411, v_rest_244))});
      }
      case TAG_False: {
        heff_drop(v_c_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eaffectedGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_d_248}));
  return ({ V a_0 = v_t_249; V a_1 = v_mods_241; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2enubRoots_lam0(V self, V *args);
Clo g_heff_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2enubRoots_lam0, 1, 1, (V[]){heff_dup(v_r_241)}), v_rs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_r_241, (g_heff_2elsp_2enubRoots(v_t_2411))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enubRoots(a[0]);
}
V g_heff_2elsp_2enubRoots_lam0(V self, V *args) {
  V v_q_243 = args[0];
  V v_r_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_q_243, 0);
    heff_take_n(v_q_243, 1ULL, 2);
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_t_249;
  switch (heff_tag_of(v_r_241)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_r_241, 0);
    heff_take_n(v_r_241, 1ULL, 2);
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_r_241);
  }
  V v_x1_2410 = heff_strEq(v_t_246, v_t_249);
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eregistration_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2eregistration_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2eregistration_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2eregistration_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 45, 119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2elsp_2eregistration_str5 = {{0x80000000u, K_STR, 0}, 25, 25, {99, 108, 105, 101, 110, 116, 47, 114, 101, 103, 105, 115, 116, 101, 114, 67, 97, 112, 97, 98, 105, 108, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2eregistration_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2eregistration_str7 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 45, 119, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2eregistration_str9 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2eregistration_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {103, 108, 111, 98, 80, 97, 116, 116, 101, 114, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eregistration_str11 = {{0x80000000u, K_STR, 0}, 7, 7, {42, 42, 47, 42, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2eregistration_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {119, 97, 116, 99, 104, 101, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2elsp_2eregistration_str13 = {{0x80000000u, K_STR, 0}, 15, 15, {114, 101, 103, 105, 115, 116, 101, 114, 79, 112, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2eregistration_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {114, 101, 103, 105, 115, 116, 114, 97, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2eregistration_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};

static V g_heff_2elsp_2eregistration_val;
static int g_heff_2elsp_2eregistration_st;
static V g_heff_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str2), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str4), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str6), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str8), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str10), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str12), heff_tag(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str13), heff_tag(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str14), heff_tag(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eregistration_str15), heff_tag(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2eregistration_get(void) {
  if (g_heff_2elsp_2eregistration_st == 2) return g_heff_2elsp_2eregistration_val;
  if (g_heff_2elsp_2eregistration_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2eregistration_st = 1;
  g_heff_2elsp_2eregistration_val = heff_tr(g_heff_2elsp_2eregistration_init());
  g_heff_2elsp_2eregistration_st = 2;
  return g_heff_2elsp_2eregistration_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2elsp_2elastChange_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {99, 111, 110, 116, 101, 110, 116, 67, 104, 97, 110, 103, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2elastChange_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 120, 116}};
Clo g_heff_2elsp_2elastChange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elastChange_entry, 1, 0};

V g_heff_2elsp_2elastChange(V v_p_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elastChange_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V a_0 = v_t_241; V a_1 = v_p_240; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_241, 2); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_it1_243)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      V v_xs_248 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      v_t_2410 = heff_tag_at(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_xs_248});
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_243);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_cs_2411 = heff_field(v_t_2410, 0);
      V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
      V v_x1_2412 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_cs_2411));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24t_2410_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        V v_ru_24x1_2412_24Cons = heff_take_reuse_n(v_x1_2412, 1ULL, 2);
        V v_t_2415 = heff_tag_at(v_ru_24x1_2412_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elastChange_str1), NTAG(TAG_Nil)});
        V v_it_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_2413; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_2415, 2); r_; });
        switch (heff_tag_of(v_it_2416)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_2410_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_it1_2417 = heff_field(v_it_2416, 0);
          heff_take_n(v_it_2416, 1ULL, 1);
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            V v_s_2421 = heff_field(v_it1_2417, 0);
            heff_take_n(v_it1_2417, 1ULL, 1);
            return heff_tag_at(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){v_s_2421});
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2417);
          }
        }
        default: return heff_nomatch(v_it_2416);
        }
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2elastChange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elastChange(a[0]);
}
Clo g_heff_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  V v_t_243 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_text_242);
    return v_st_240;
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_rec(2, shape_uri__text, (V[]){heff_get(v_d_244, LBL_uri), v_text_242});
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(v_f_241, v_t_245, heff_get(heff_dup(v_st_240), LBL_docs)));
    return heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){v_d_246, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echanged(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_due); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_243 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
  V v_d_244 = ({ V a_0 = v_f_241; V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
  V v_s_245 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){v_d_244, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  V v_s_246 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_s_245), LBL_docs), v_c_243, heff_get(heff_dup(v_s_245), LBL_due), heff_get(heff_dup(v_s_245), LBL_project), heff_get(heff_dup(v_s_245), LBL_watch), heff_get(heff_dup(v_s_245), LBL_shutdown), heff_get(v_s_245, LBL_lib)});
  return heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_s_246), LBL_docs), heff_get(heff_dup(v_s_246), LBL_checked), v_t_242, heff_get(heff_dup(v_s_246), LBL_project), heff_get(heff_dup(v_s_246), LBL_watch), heff_get(heff_dup(v_s_246), LBL_shutdown), heff_get(v_s_246, LBL_lib)});
}
V g_heff_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eclosed(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2edocPath_24s133079231x401204893_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2edocPath_24s133079231x401204893_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam0(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s133079231x401204893_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s133079231x401204893_lam0, 2, 0};
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam1(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s133079231x401204893_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s133079231x401204893_lam1, 2, 0};
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam3(V self, V *args); static Clo g_heff_2elsp_2edocPath_24s133079231x401204893_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s133079231x401204893_lam3, 1, 0};
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam2(V self, V *args);
Clo g_heff_2elsp_2edocPath_24s133079231x401204893_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2edocPath_24s133079231x401204893_entry, 1, 0};

V g_heff_2elsp_2edocPath_24s133079231x401204893(V v_p_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2edocPath_24s133079231x401204893_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2edocPath_24s133079231x401204893_str1), v_t_241}); V a_1 = v_p_240; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2elsp_2edocPath_24s133079231x401204893_lam0_clo);
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_it1_245)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_249 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      v_t_2412 = heff_tag_at(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_s_249});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_245);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2elsp_2edocPath_24s133079231x401204893_lam1_clo);
    }
    case TAG_Just: {
      V v_u_2415 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      return heff_clo(g_heff_2elsp_2edocPath_24s133079231x401204893_lam2, 2, 1, (V[]){v_u_2415});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2edocPath_24s133079231x401204893_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2edocPath_24s133079231x401204893(a[0]);
}
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam3(V self, V *args) {
  V v_p_2418 = args[0];
  return v_p_2418;
}
V g_heff_2elsp_2edocPath_24s133079231x401204893_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_u_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_UriPath, 2, (V[]){v_u_2415, ((V)&g_heff_2elsp_2edocPath_24s133079231x401204893_lam3_clo)})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2416, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2enotify_24s2066566305x1387019196_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotify_24s2066566305x1387019196_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2enotify_24s2066566305x1387019196_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2enotify_24s2066566305x1387019196_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};
V g_heff_2elsp_2enotify_24s2066566305x1387019196_lam1(V self, V *args);
V g_heff_2elsp_2enotify_24s2066566305x1387019196_lam0(V self, V *args);
Clo g_heff_2elsp_2enotify_24s2066566305x1387019196_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotify_24s2066566305x1387019196_entry, 2, 0};

V g_heff_2elsp_2enotify_24s2066566305x1387019196(V v_method_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s2066566305x1387019196_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2enotify_24s2066566305x1387019196_str1)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s2066566305x1387019196_str2), heff_tag(TAG_JString, 1, (V[]){v_method_240})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotify_24s2066566305x1387019196_str3), v_params_241}), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_244})});
  V v_t_246 = ({ V b_0 = heff_tag(TAG_JObject, 1, (V[]){v_t_245}); V r_ = (g_heff_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_a_247 = heff_tag(TAG_Send, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_a_247})});
  V v_p_249 = heff_tag(TAG_InR, 1, (V[]){v_t_248});
  return heff_clo(g_heff_2elsp_2enotify_24s2066566305x1387019196_lam0, 2, 1, (V[]){v_p_249});
}
V g_heff_2elsp_2enotify_24s2066566305x1387019196_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotify_24s2066566305x1387019196(a[0], a[1]);
}
V g_heff_2elsp_2enotify_24s2066566305x1387019196_lam1(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2410), heff_get(v_hd_2410, LBL_ret)});
}
V g_heff_2elsp_2enotify_24s2066566305x1387019196_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1682480088x1491420330_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2enotify_24s2066566305x1387019196_lam1, 1, 1, (V[]){heff_dup(v_hd_2410)}), v_p_249}));
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2echeck_24s447642999x1873703689_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {100, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2echeck_24s447642999x1873703689_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2echeck_24s447642999x1873703689_str2 = {{0x80000000u, K_STR, 0}, 31, 31, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 117, 98, 108, 105, 115, 104, 68, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam0(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam3(V self, V *args); static Clo g_heff_2elsp_2echeck_24s447642999x1873703689_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeck_24s447642999x1873703689_lam3, 1, 0};
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam2(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam4(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam1(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam8(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam10(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam11(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam9(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam7(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam6(V self, V *args);
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam5(V self, V *args);
Clo g_heff_2elsp_2echeck_24s447642999x1873703689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeck_24s447642999x1873703689_entry, 2, 0};

V g_heff_2elsp_2echeck_24s447642999x1873703689(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_f_241); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    return heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_c_2419 = (g_heff_2eload_2eloadProgramWith_24s1828132383x744561138(heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam1, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_241)));
    return heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam5, 2, 4, (V[]){v_c_2419, v_d_245, v_f_241, v_st_240});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echeck_24s447642999x1873703689(a[0], a[1]);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam3(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_p_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_p_246, ((V)&g_heff_2elsp_2echeck_24s447642999x1873703689_lam3_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V v_t_2418 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_d_2415, LBL_text)});
  V f_ = v_k_2417;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V a_0 = heff_dup(v_p_246); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    return heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam2, 2, 1, (V[]){v_p_246});
  }
  case TAG_Just: {
    V v_d_2415 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_p_246);
    return heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam4, 2, 1, (V[]){v_d_2415});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam8(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam10(V self, V *args) {
  V v_x_2431 = args[0];
  V v_d_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2ediagnostic(heff_get(v_d_245, LBL_text), v_x_2431));
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_rec(2, shape_text__program, (V[]){heff_get(v_d_245, LBL_text), v_x_2429});
  V v_c_2440 = (g_map_2einsert_24s1341440536x470972936(v_f_241, v_t_2439, heff_get(heff_dup(v_st_240), LBL_checked)));
  V v_x_2441 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), v_c_2440, heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  V f_ = v_k_2421;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_hd_2420 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2elsp_2ediagsOf(heff_get(heff_dup(v_d_245), LBL_text), heff_dup(v_x_2429), heff_get(v_x_2422, LBL_errors)));
  V v_ds_2432 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam10, 1, 1, (V[]){heff_dup(v_d_245)}), v_t_2430));
  V v_t_2433 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_d_245), LBL_uri)});
  V v_t_2434 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echeck_24s447642999x1873703689_str0), heff_tag(TAG_JArray, 1, (V[]){v_ds_2432})});
  V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
  V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echeck_24s447642999x1873703689_str1), v_t_2433}), v_t_2435});
  V v_c_2437 = (g_heff_2elsp_2enotify_24s2066566305x1387019196(((V)&g_heff_2elsp_2echeck_24s447642999x1873703689_str2), heff_tag(TAG_JObject, 1, (V[]){v_t_2436})));
  return heff_tail(v_c_2437, 2, (V[]){v_hd_2420, heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam11, 1, 5, (V[]){v_d_245, v_x_2429, v_f_241, v_st_240, v_k_2421})});
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_d_245 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2425 = (g_heff_2elsp_2ekeptOf(v_x_2424));
  V v_c_2428 = heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam8, 2, 1, (V[]){v_x_2425});
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_2420), heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam9, 1, 6, (V[]){v_d_245, v_x_2422, v_hd_2420, v_f_241, v_st_240, v_k_2421})});
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_d_245 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2423 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2422)));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2420), heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam7, 1, 6, (V[]){v_hd_2420, v_d_245, v_x_2422, v_f_241, v_st_240, v_k_2421})});
}
V g_heff_2elsp_2echeck_24s447642999x1873703689_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_d_245 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo(g_heff_2elsp_2echeck_24s447642999x1873703689_lam6, 1, 5, (V[]){v_hd_2420, v_d_245, v_f_241, v_st_240, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam0(V self, V *args);
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam2(V self, V *args);
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam1(V self, V *args);
Clo g_heff_2elsp_2echeckAll_24s417884660x239518827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeckAll_24s417884660x239518827_entry, 2, 0};

V g_heff_2elsp_2echeckAll_24s417884660x239518827(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2echeckAll_24s417884660x239518827_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_st_240, heff_dup(v_f_244)));
    return heff_clo(g_heff_2elsp_2echeckAll_24s417884660x239518827_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2echeckAll_24s417884660x239518827_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2echeckAll_24s417884660x239518827(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2echeckAll_24s417884660x239518827(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2410, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2elsp_2echeckAll_24s417884660x239518827_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2elsp_2echeckAll_24s417884660x239518827_lam2, 1, 3, (V[]){v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 120, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {105, 110, 105, 116, 105, 97, 108, 105, 122, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str2 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str3 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 79, 112, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str8 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str10 = {{0x80000000u, K_STR, 0}, 22, 22, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str11 = {{0x80000000u, K_STR, 0}, 20, 20, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 83, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str12 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 105, 100, 67, 108, 111, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str13 = {{0x80000000u, K_STR, 0}, 11, 11, {100, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotified_24s1317056913x1433573017_str15 = {{0x80000000u, K_STR, 0}, 31, 31, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 117, 98, 108, 105, 115, 104, 68, 105, 97, 103, 110, 111, 115, 116, 105, 99, 115}};
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam3(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam2(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam4(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam5(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam6(V self, V *args); static Clo g_heff_2elsp_2enotified_24s1317056913x1433573017_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s1317056913x1433573017_lam6, 1, 0};
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam7(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam8(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam9(V self, V *args); static Clo g_heff_2elsp_2enotified_24s1317056913x1433573017_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s1317056913x1433573017_lam9, 2, 0};
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam10(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam1(V self, V *args);
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam0(V self, V *args);
Clo g_heff_2elsp_2enotified_24s1317056913x1433573017_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotified_24s1317056913x1433573017_entry, 3, 0};

V g_heff_2elsp_2enotified_24s1317056913x1433573017(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2edocPath_24s133079231x401204893(heff_dup(v_p_242)));
  return heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam0, 2, 4, (V[]){v_c_243, v_m_241, v_st_240, v_p_242});
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotified_24s1317056913x1433573017(a[0], a[1], a[2]);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam3(V self, V *args) {
  V v_c_2421 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_2419), heff_get(v_hd_2419, LBL_ret)});
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_p_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1682480088x1491420330_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam3, 1, 1, (V[]){heff_dup(v_hd_2419)}), v_p_2418}));
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2419), LBL_malg), 1, (V[]){v_t_2422}));
  V f_ = heff_get(v_hd_2419, LBL_bind);
  args[0] = v_t_2423;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_st_2457 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2462 = (g_heff_2elsp_2edependentsOf(v_st_2457, v_f_2430));
  V v_t_2463 = ({ V a_0 = v_x_2461; V a_1 = v_t_2462; V r_ = (g_heff_2elsp_2echeckAll_24s417884660x239518827(a_0, a_1)); heff_drop(v_t_2462); r_; });
  return heff_tail(v_t_2463, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam6(V self, V *args) {
  V v_n_2467 = args[0];
  return v_n_2467;
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam7(V self, V *args) {
  V v_x_2471 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_text_2466 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2472 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2430), heff_intAdd(v_x_2471, MK_INT(200LL)), heff_get(heff_dup(v_st_240), LBL_due)));
  V v_s_2473 = (g_heff_2elsp_2echanged(v_st_240, v_f_2430, v_text_2466));
  V v_x_2474 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_s_2473), LBL_docs), heff_get(heff_dup(v_s_2473), LBL_checked), v_t_2472, heff_get(heff_dup(v_s_2473), LBL_project), heff_get(heff_dup(v_s_2473), LBL_watch), heff_get(heff_dup(v_s_2473), LBL_shutdown), heff_get(v_s_2473, LBL_lib)});
  V f_ = v_k_245;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam8(V self, V *args) {
  V v_x_2479 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2480 = (g_heff_2elsp_2edependentsOf(v_st_240, v_f_2430));
  V v_t_2481 = ({ V a_0 = v_x_2479; V a_1 = v_t_2480; V r_ = (g_heff_2elsp_2echeckAll_24s417884660x239518827(a_0, a_1)); heff_drop(v_t_2480); r_; });
  return heff_tail(v_t_2481, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam9(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  heff_drop(v_hd_2484);
  V f_ = v_k_2485;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam10(V self, V *args) {
  V v_x_2492 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2492);
  V v_x_2493 = (g_heff_2elsp_2eclosed(v_st_240, v_f_2430));
  V f_ = v_k_245;
  args[0] = v_x_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str0));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_248 = heff_get(v_st_240, LBL_shutdown);
    V v_code_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_code_249 = MK_INT(0LL);
      break;
    }
    case TAG_False: {
      v_code_249 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Quit, 1, (V[]){v_code_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2412, v_k_245});
  }
  case TAG_False: {
    V v_t_2413 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str1));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2414 = heff_get(heff_dup(v_st_240), LBL_watch);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        V v_t_2415 = ({ V b_0 = heff_dup(g_heff_2elsp_2eregistration_get()); V r_ = (g_heff_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_a_2416 = heff_tag(TAG_Send, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
        V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_a_2416})});
        V v_p_2418 = heff_tag(TAG_InR, 1, (V[]){v_t_2417});
        V v_c_2424 = heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam2, 2, 1, (V[]){v_p_2418});
        return heff_tail(v_c_2424, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam4, 1, 2, (V[]){v_k_245, v_st_240})});
      }
      case TAG_False: {
        heff_drop(v_hd_244);
        V f_ = v_k_245;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_False: {
      V v_t_2426 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str2));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_True: {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2427 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_docs); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2428 = (g_prelude_2emap_24s1581021428x1223114127(v_t_2427));
        V v_t_2429 = ({ V a_0 = v_st_240; V a_1 = v_t_2428; V r_ = (g_heff_2elsp_2echeckAll_24s417884660x239518827(a_0, a_1)); heff_drop(v_t_2428); r_; });
        return heff_tail(v_t_2429, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_False: {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_m_241);
          heff_drop(v_hd_244);
          heff_drop(v_p_242);
          V f_ = v_k_245;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2430 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          V v_t_2431 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str3));
          switch (heff_tag_of(v_t_2431)) {
          case TAG_True: {
            heff_drop(v_m_241);
            V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str4), NTAG(TAG_Nil)});
            V v_it_2433 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str5), v_t_2432}); V a_1 = heff_dup(v_p_242); V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2441;
            switch (heff_tag_of(v_it_2433)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              v_x2_2441 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2434 = heff_field(v_it_2433, 0);
              heff_take_n(v_it_2433, 1ULL, 1);
              switch (heff_tag_of(v_it1_2434)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2434, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2434, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2434, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2438 = heff_field(v_it1_2434, 0);
                heff_take_n(v_it1_2434, 1ULL, 1);
                v_x2_2441 = heff_tag_at(v_ru_24x_246_24Just, TAG_Just, 1, (V[]){v_s_2438});
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2434, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2434, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2441 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2434);
              }
              break;
            }
            default: heff_nomatch(v_it_2433);
            }
            V v_uri_2443;
            switch (heff_tag_of(v_x2_2441)) {
            case TAG_Nothing: {
              v_uri_2443 = ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str6);
              break;
            }
            case TAG_Just: {
              V v_x_2442 = heff_field(v_x2_2441, 0);
              heff_take_n(v_x2_2441, 1ULL, 1);
              v_uri_2443 = v_x_2442;
              break;
            }
            default: heff_nomatch(v_x2_2441);
            }
            V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str7), NTAG(TAG_Nil)});
            V v_it_2445 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str8), v_t_2444}); V a_1 = v_p_242; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2453;
            switch (heff_tag_of(v_it_2445)) {
            case TAG_Nothing: {
              v_x2_2453 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2446 = heff_field(v_it_2445, 0);
              V v_ru_24it_2445_24Just = heff_take_reuse_n(v_it_2445, 1ULL, 1);
              switch (heff_tag_of(v_it1_2446)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2446, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2446, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2446, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2450 = heff_field(v_it1_2446, 0);
                heff_take_n(v_it1_2446, 1ULL, 1);
                v_x2_2453 = heff_tag_at(v_ru_24it_2445_24Just, TAG_Just, 1, (V[]){v_s_2450});
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2446, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2446, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2445_24Just, 1);
                v_x2_2453 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2446);
              }
              break;
            }
            default: heff_nomatch(v_it_2445);
            }
            V v_text_2455;
            switch (heff_tag_of(v_x2_2453)) {
            case TAG_Nothing: {
              v_text_2455 = ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str9);
              break;
            }
            case TAG_Just: {
              V v_x_2454 = heff_field(v_x2_2453, 0);
              heff_take_n(v_x2_2453, 1ULL, 1);
              v_text_2455 = v_x_2454;
              break;
            }
            default: heff_nomatch(v_x2_2453);
            }
            V v_d_2456 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2430), heff_rec(2, shape_uri__text, (V[]){v_uri_2443, v_text_2455}), heff_get(heff_dup(v_st_240), LBL_docs)));
            V v_st_2457 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){v_d_2456, heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
            V v_t_2458 = ({ V a_0 = heff_dup(v_f_2430); V b_1 = heff_get(heff_dup(v_st_2457), LBL_due); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
            V v_t_2459 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_2457), LBL_docs), heff_get(heff_dup(v_st_2457), LBL_checked), v_t_2458, heff_get(heff_dup(v_st_2457), LBL_project), heff_get(heff_dup(v_st_2457), LBL_watch), heff_get(heff_dup(v_st_2457), LBL_shutdown), heff_get(heff_dup(v_st_2457), LBL_lib)});
            V v_c_2460 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_t_2459, heff_dup(v_f_2430)));
            return heff_tail(v_c_2460, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam5, 1, 4, (V[]){v_st_2457, v_f_2430, v_hd_244, v_k_245})});
          }
          case TAG_False: {
            V v_t_2464 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str10));
            switch (heff_tag_of(v_t_2464)) {
            case TAG_True: {
              heff_drop(v_m_241);
              V v_t_2465 = (g_heff_2elsp_2elastChange(v_p_242));
              switch (heff_tag_of(v_t_2465)) {
              case TAG_Nothing: {
                heff_drop(v_hd_244);
                heff_drop(v_f_2430);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                V f_ = v_k_245;
                args[0] = v_st_240;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_2466 = heff_field(v_t_2465, 0);
                V v_ru_24t_2465_24Just = heff_take_reuse_n(v_t_2465, 1ULL, 1);
                V v_t_2468 = heff_tag_at(v_ru_24x_246_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_lam6_clo)})});
                V v_t_2469 = heff_tag_at(v_ru_24t_2465_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2468})});
                V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2469}));
                return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2470, heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam7, 1, 4, (V[]){v_f_2430, v_st_240, v_text_2466, v_k_245})});
              }
              default: return heff_nomatch(v_t_2465);
              }
            }
            case TAG_False: {
              heff_drop(v_p_242);
              V v_t_2475 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str11));
              switch (heff_tag_of(v_t_2475)) {
              case TAG_True: {
                heff_drop(v_m_241);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                V v_t_2476 = ({ V a_0 = heff_dup(v_f_2430); V b_1 = heff_get(heff_dup(v_st_240), LBL_due); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
                V v_t_2477 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), v_t_2476, heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(heff_dup(v_st_240), LBL_lib)});
                V v_c_2478 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_t_2477, heff_dup(v_f_2430)));
                return heff_tail(v_c_2478, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam8, 1, 4, (V[]){v_st_240, v_f_2430, v_hd_244, v_k_245})});
              }
              case TAG_False: {
                V v_t_2482 = heff_strEq(v_m_241, ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str12));
                switch (heff_tag_of(v_t_2482)) {
                case TAG_True: {
                  V v_t_2483 = ({ V a_0 = heff_dup(v_f_2430); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
                  V v_c_2491;
                  switch (heff_tag_of(v_t_2483)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x_246_24Just, 1);
                    v_c_2491 = ((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_lam9_clo);
                    break;
                  }
                  case TAG_Just: {
                    V v_d_2486 = heff_field(v_t_2483, 0);
                    V v_ru_24t_2483_24Just = heff_take_reuse_n(v_t_2483, 1ULL, 1);
                    V v_t_2487 = heff_tag_at(v_ru_24x_246_24Just, TAG_JString, 1, (V[]){heff_get(v_d_2486, LBL_uri)});
                    V v_t_2488 = heff_tag_at(v_ru_24t_2483_24Just, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
                    V v_t_2489 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str13), v_t_2488}), NTAG(TAG_Nil)});
                    V v_t_2490 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str14), v_t_2487}), v_t_2489});
                    v_c_2491 = (g_heff_2elsp_2enotify_24s2066566305x1387019196(((V)&g_heff_2elsp_2enotified_24s1317056913x1433573017_str15), heff_tag(TAG_JObject, 1, (V[]){v_t_2490})));
                    break;
                  }
                  default: heff_nomatch(v_t_2483);
                  }
                  return heff_tail(v_c_2491, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam10, 1, 3, (V[]){v_st_240, v_f_2430, v_k_245})});
                }
                case TAG_False: {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2430);
                  heff_drop_cell(v_ru_24x_246_24Just, 1);
                  V f_ = v_k_245;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
                default: return heff_nomatch(v_t_2482);
                }
              }
              default: return heff_nomatch(v_t_2475);
              }
            }
            default: return heff_nomatch(v_t_2464);
            }
          }
          default: return heff_nomatch(v_t_2431);
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
      default: return heff_nomatch(v_t_2426);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2enotified_24s1317056913x1433573017_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2elsp_2enotified_24s1317056913x1433573017_lam1, 1, 5, (V[]){v_m_241, v_st_240, v_hd_244, v_k_245, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2enotification_24s1809009350x1217072135_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2elsp_2enotification_24s1809009350x1217072135_str1 = {{0x80000000u, K_STR, 0}, 31, 31, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
Clo g_heff_2elsp_2enotification_24s1809009350x1217072135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2enotification_24s1809009350x1217072135_entry, 3, 0};

V g_heff_2elsp_2enotification_24s1809009350x1217072135(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_m_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2elsp_2enotification_24s1809009350x1217072135_str0));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_245 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
    break;
  }
  case TAG_False: {
    V v_t_244 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2enotification_24s1809009350x1217072135_str1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
      break;
    }
    case TAG_False: {
      v_t_245 = v_st_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  HEFF_LAST return g_heff_2elsp_2enotified_24s1317056913x1433573017(v_t_245, v_m_241, v_p_242);
}
V g_heff_2elsp_2enotification_24s1809009350x1217072135_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2enotification_24s1809009350x1217072135(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam1(V self, V *args);
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam0(V self, V *args);
Clo g_heff_2elsp_2ereplyError_24s1722239765x1825266297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereplyError_24s1722239765x1825266297_entry, 3, 0};

V g_heff_2elsp_2ereplyError_24s1722239765x1825266297(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str1)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str2), heff_tag(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str3), heff_tag(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereplyError_24s1722239765x1825266297_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_a_2412})});
  V v_p_2414 = heff_tag(TAG_InR, 1, (V[]){v_t_2413});
  return heff_clo(g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam0, 2, 1, (V[]){v_p_2414});
}
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ereplyError_24s1722239765x1825266297(a[0], a[1], a[2]);
}
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam1(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2415), heff_get(v_hd_2415, LBL_ret)});
}
V g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_p_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1682480088x1491420330_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2ereplyError_24s1722239765x1825266297_lam1, 1, 1, (V[]){heff_dup(v_hd_2415)}), v_p_2414}));
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2ereply_24s1469169503x1913753224_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {106, 115, 111, 110, 114, 112, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2ereply_24s1469169503x1913753224_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {50, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ereply_24s1469169503x1913753224_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 101, 115, 117, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ereply_24s1469169503x1913753224_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
V g_heff_2elsp_2ereply_24s1469169503x1913753224_lam1(V self, V *args);
V g_heff_2elsp_2ereply_24s1469169503x1913753224_lam0(V self, V *args);
Clo g_heff_2elsp_2ereply_24s1469169503x1913753224_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereply_24s1469169503x1913753224_entry, 2, 0};

V g_heff_2elsp_2ereply_24s1469169503x1913753224(V v_id_240, V v_result_241) {
top: ;
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s1469169503x1913753224_str0), heff_tag(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2ereply_24s1469169503x1913753224_str1)})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s1469169503x1913753224_str2), v_result_241}), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2ereply_24s1469169503x1913753224_str3), v_id_240}), v_t_243});
  V v_t_245 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop_tag(v_t_245, 1); r_; });
  V v_a_247 = heff_tag(TAG_Send, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_a_247})});
  V v_p_249 = heff_tag(TAG_InR, 1, (V[]){v_t_248});
  return heff_clo(g_heff_2elsp_2ereply_24s1469169503x1913753224_lam0, 2, 1, (V[]){v_p_249});
}
V g_heff_2elsp_2ereply_24s1469169503x1913753224_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ereply_24s1469169503x1913753224(a[0], a[1]);
}
V g_heff_2elsp_2ereply_24s1469169503x1913753224_lam1(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2410), heff_get(v_hd_2410, LBL_ret)});
}
V g_heff_2elsp_2ereply_24s1469169503x1913753224_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1682480088x1491420330_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2ereply_24s1469169503x1913753224_lam1, 1, 1, (V[]){heff_dup(v_hd_2410)}), v_p_249}));
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ewithProgram_24s1295466243x875227959_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2ewithProgram_24s1295466243x875227959_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam2(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam3(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam1(V self, V *args);
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam0(V self, V *args);
Clo g_heff_2elsp_2ewithProgram_24s1295466243x875227959_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ewithProgram_24s1295466243x875227959_entry, 2, 0};

V g_heff_2elsp_2ewithProgram_24s1295466243x875227959(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2edocPath_24s133079231x401204893(v_p_241));
  return heff_clo(g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ewithProgram_24s1295466243x875227959(a[0], a[1]);
}
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2414 = heff_get(v_d_2410, LBL_text);
  V v_t_2415 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_x_2413), LBL_checked); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x_2418 = heff_rec(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_strEq(heff_get(heff_dup(v_c_2416), LBL_text), heff_dup(v_text_2414));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_x_2418 = heff_rec(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, heff_get(v_c_2416, LBL_program)});
      break;
    }
    case TAG_False: {
      heff_drop(v_c_2416);
      v_x_2418 = heff_rec(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_k_244;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2428 = heff_get(v_d_2410, LBL_text);
  V v_t_2429 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_x_2427), LBL_checked); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    v_x_2432 = heff_rec(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    V v_t_2431 = heff_strEq(heff_get(heff_dup(v_c_2430), LBL_text), heff_dup(v_text_2428));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      v_x_2432 = heff_rec(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, heff_get(v_c_2430, LBL_program)});
      break;
    }
    case TAG_False: {
      heff_drop(v_c_2430);
      v_x_2432 = heff_rec(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V f_ = v_k_244;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2ewithProgram_24s1295466243x875227959_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2ewithProgram_24s1295466243x875227959_str1), NTAG(TAG_Nil)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2411 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        V v_c_2412 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_st_240, heff_dup(v_f_247)));
        return heff_tail(v_c_2412, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam2, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244})});
      }
      case TAG_Just: {
        V v_c_2419 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        V v_t_2420 = heff_strEq(heff_get(v_c_2419, LBL_text), heff_get(heff_dup(v_d_2410), LBL_text));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_hd_243);
          V v_text_2421 = heff_get(v_d_2410, LBL_text);
          V v_t_2422 = ({ V a_0 = v_f_247; V b_1 = heff_get(heff_dup(v_st_240), LBL_checked); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          V v_x_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            v_x_2425 = heff_rec(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            break;
          }
          case TAG_Just: {
            V v_c_2423 = heff_field(v_t_2422, 0);
            heff_take_n(v_t_2422, 1ULL, 1);
            V v_t_2424 = heff_strEq(heff_get(heff_dup(v_c_2423), LBL_text), heff_dup(v_text_2421));
            switch (heff_tag_of(v_t_2424)) {
            case TAG_True: {
              v_x_2425 = heff_rec(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, heff_get(v_c_2423, LBL_program)});
              break;
            }
            case TAG_False: {
              heff_drop(v_c_2423);
              v_x_2425 = heff_rec(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
              break;
            }
            default: heff_nomatch(v_t_2424);
            }
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V f_ = v_k_244;
          args[0] = v_x_2425;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_False: {
          V v_c_2426 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_st_240, heff_dup(v_f_247)));
          return heff_tail(v_c_2426, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam3, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244})});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2elsp_2ewithProgram_24s1295466243x875227959_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam0(V self, V *args); static Clo g_heff_2elsp_2erootsOf_24s535930516x390676296_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erootsOf_24s535930516x390676296_lam0, 2, 0};
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam3(V self, V *args);
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam2(V self, V *args);
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam1(V self, V *args);
Clo g_heff_2elsp_2erootsOf_24s535930516x390676296_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erootsOf_24s535930516x390676296_entry, 2, 0};

V g_heff_2elsp_2erootsOf_24s535930516x390676296(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2erootsOf_24s535930516x390676296_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2eload_2epathsFor_24s382934904x1572524859(heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_244)));
    return heff_clo(g_heff_2elsp_2erootsOf_24s535930516x390676296_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erootsOf_24s535930516x390676296(a[0], a[1]);
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_x_249, LBL_root), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2erootsOf_24s535930516x390676296(v_st_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2elsp_2erootsOf_24s535930516x390676296_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248})});
}
V g_heff_2elsp_2erootsOf_24s535930516x390676296_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2elsp_2erootsOf_24s535930516x390676296_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam0(V self, V *args); static Clo g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam0, 2, 0};
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam3(V self, V *args);
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam2(V self, V *args);
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam1(V self, V *args);
Clo g_heff_2elsp_2eloadAll_24s1742300915x648307049_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eloadAll_24s1742300915x648307049_entry, 3, 0};

V g_heff_2elsp_2eloadAll_24s1742300915x648307049(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2eload_2eloadProgramWith_24s1828132383x744561138(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo(g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eloadAll_24s1742300915x648307049(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2econcatList(heff_get(v_x_2410, LBL_sources), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2eloadAll_24s1742300915x648307049(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam3, 1, 2, (V[]){v_x_2410, v_k_249})});
}
V g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2elsp_2eloadAll_24s1742300915x648307049_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam0(V self, V *args); static Clo g_heff_2elsp_2eelabProject_24s511942051x460406311_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eelabProject_24s511942051x460406311_lam0, 1, 0};
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam2(V self, V *args);
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam1(V self, V *args);
Clo g_heff_2elsp_2eelabProject_24s511942051x460406311_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eelabProject_24s511942051x460406311_entry, 6, 0};

V g_heff_2elsp_2eelabProject_24s511942051x460406311(V v_read_240, V v_lib_241, V v_root_242, V v_f_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProjectFiles, 2, (V[]){v_root_242, ((V)&g_heff_2elsp_2eelabProject_24s511942051x460406311_lam0_clo)})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2elsp_2eelabProject_24s511942051x460406311_lam1, 1, 5, (V[]){v_f_243, v_read_240, v_lib_241, v_hd_244, v_k_245})});
}
V g_heff_2elsp_2eelabProject_24s511942051x460406311_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eelabProject_24s511942051x460406311(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam0(V self, V *args) {
  V v_fs_246 = args[0];
  return v_fs_246;
}
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sources_2416 = (g_heff_2elsp_2enubSources(v_x_2415));
  V v_x_2417 = (g_prelude_2efoldl_24s919661041x794023661(NTAG(TAG_Nil), v_sources_2416));
  V f_ = v_k_245;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eelabProject_24s511942051x460406311_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_f_243, NTAG(TAG_Nil)});
  V v_files_2412 = (g_prelude_2econcatList(v_x_2410, v_t_2411));
  V v_t_2413 = (g_heff_2elsp_2enubPaths(v_files_2412));
  V v_c_2414 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_t_2413; V r_ = (g_heff_2elsp_2eloadAll_24s1742300915x648307049(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  return heff_tail(v_c_2414, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eelabProject_24s511942051x460406311_lam2, 1, 1, (V[]){v_k_245})});
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam2(V self, V *args); static Clo g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam2, 1, 0};
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam1(V self, V *args);
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam3(V self, V *args);
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam0(V self, V *args);
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam4(V self, V *args);
Clo g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_entry, 5, 0};

V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2elsp_2eelabProject_24s511942051x460406311(heff_clo(g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam0, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_root_241), v_f_242, v_hd_243, heff_clo(g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam4, 1, 3, (V[]){v_root_241, v_st_240, v_k_244})));
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eprojectAnew_24s777366106x1275701762(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam2(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_p_245, ((V)&g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam2_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2413;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_d_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V v_t_2417 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_d_2414, LBL_text)});
  V f_ = v_k_2416;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = heff_dup(v_p_245); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return heff_clo(g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam1, 2, 1, (V[]){v_p_245});
  }
  case TAG_Just: {
    V v_d_2414 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop(v_p_245);
    return heff_clo(g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam3, 2, 1, (V[]){v_d_2414});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2eprojectAnew_24s777366106x1275701762_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_root__program, (V[]){v_root_241, heff_dup(v_x_2418)})});
  V v_t_2420 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), v_t_2419, heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  V f_ = v_k_244;
  args[0] = heff_rec(2, shape_st__program, (V[]){v_t_2420, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eproject_24s545014642x2143879243_lam1(V self, V *args);
V g_heff_2elsp_2eproject_24s545014642x2143879243_lam0(V self, V *args);
Clo g_heff_2elsp_2eproject_24s545014642x2143879243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eproject_24s545014642x2143879243_entry, 2, 0};

V g_heff_2elsp_2eproject_24s545014642x2143879243(V v_st_240, V v_f_241) {
top: ;
  V v_c_242 = (g_heff_2eload_2epathsFor_24s382934904x1572524859(heff_get(heff_dup(v_st_240), LBL_lib), heff_dup(v_f_241)));
  return heff_clo(g_heff_2elsp_2eproject_24s545014642x2143879243_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_f_241});
}
V g_heff_2elsp_2eproject_24s545014642x2143879243_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eproject_24s545014642x2143879243(a[0], a[1]);
}
V g_heff_2elsp_2eproject_24s545014642x2143879243_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_get(heff_dup(v_st_240), LBL_project);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2eprojectAnew_24s777366106x1275701762(v_st_240, heff_get(v_x_245, LBL_root), v_f_241, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_pr_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = heff_strEq(heff_get(heff_dup(v_pr_247), LBL_root), heff_get(heff_dup(v_x_245), LBL_root));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_x_245);
      heff_drop(v_f_241);
      heff_drop(v_hd_243);
      V v_t_249 = heff_rec(2, shape_st__program, (V[]){v_st_240, heff_get(v_pr_247, LBL_program)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_pr_247);
      return (g_heff_2elsp_2eprojectAnew_24s777366106x1275701762(v_st_240, heff_get(v_x_245, LBL_root), v_f_241, v_hd_243, v_k_244));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2eproject_24s545014642x2143879243_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2elsp_2eproject_24s545014642x2143879243_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam0(V self, V *args);
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam3(V self, V *args);
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam2(V self, V *args);
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam1(V self, V *args);
Clo g_heff_2elsp_2eprojects_24s1224286600x2087827045_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprojects_24s1224286600x2087827045_entry, 2, 0};

V g_heff_2elsp_2eprojects_24s1224286600x2087827045(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2eproject_24s545014642x2143879243(v_st_240, heff_dup(v_f_248)));
      return heff_clo(g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2eprojects_24s1224286600x2087827045(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2415 = (g_prelude_2econcatList(heff_get(v_x_2412, LBL_program), heff_get(heff_dup(v_x_2414), LBL_program)));
  V v_x_2416 = heff_rec(2, shape_st__program, (V[]){heff_get(v_x_2414, LBL_st), v_program_2415});
  V f_ = v_k_2411;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2413 = ({ V a_0 = heff_get(heff_dup(v_x_2412), LBL_st); V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2eprojects_24s1224286600x2087827045(a_0, a_1)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2413, 2, (V[]){v_hd_2410, heff_clo(g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam3, 1, 2, (V[]){v_x_2412, v_k_2411})});
}
V g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo(g_heff_2elsp_2eprojects_24s1224286600x2087827045_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {108, 111, 99, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 111, 110, 116, 97, 105, 110, 101, 114, 78, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2esymbolJson_24s317767108x209947191_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam1(V self, V *args); static Clo g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam1, 1, 0};
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam0(V self, V *args);
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam2(V self, V *args);
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam4(V self, V *args);
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam3(V self, V *args);
Clo g_heff_2elsp_2esymbolJson_24s317767108x209947191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolJson_24s317767108x209947191_entry, 3, 0};

V g_heff_2elsp_2esymbolJson_24s317767108x209947191(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_p_243 = heff_get(heff_dup(v_c_241), LBL_path);
  V v_t_244 = ({ V a_0 = heff_dup(v_p_243); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2414;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_c_2414 = heff_clo(g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam0, 2, 1, (V[]){v_p_243});
    break;
  }
  case TAG_Just: {
    V v_d_2411 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_p_243);
    v_c_2414 = heff_clo(g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam2, 2, 1, (V[]){v_d_2411});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo(g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam3, 2, 3, (V[]){v_c_2414, v_y_242, v_c_241});
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2esymbolJson_24s317767108x209947191(a[0], a[1], a[2]);
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam1(V self, V *args) {
  V v_u_247 = args[0];
  return v_u_247;
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_PathUri, 2, (V[]){v_p_243, ((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam1_clo)})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(v_hd_245, LBL_bind);
  args[0] = v_t_2410;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_get(v_d_2411, LBL_uri);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_y_242 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_y_242), LBL_name)});
  V v_t_2419 = heff_tag(TAG_JInt, 1, (V[]){heff_get(heff_dup(v_y_242), LBL_kind)});
  V v_t_2420 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_c_241), LBL_module)});
  V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str0), heff_tag(TAG_JString, 1, (V[]){v_x_2417})});
  V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str1), (g_heff_2elsp_2erange(heff_get(v_c_241, LBL_source), heff_get(v_y_242, LBL_selection)))});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
  V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str2), v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str3), v_t_2420}), v_t_2425});
  V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str4), v_t_2419}), v_t_2426});
  V v_t_2428 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2esymbolJson_24s317767108x209947191_str5), v_t_2418}), v_t_2427});
  V v_x_2429 = heff_tag(TAG_JObject, 1, (V[]){v_t_2428});
  V f_ = v_k_2416;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo(g_heff_2elsp_2esymbolJson_24s317767108x209947191_lam4, 1, 3, (V[]){v_y_242, v_c_241, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam0(V self, V *args); static Clo g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam0, 2, 0};
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam3(V self, V *args);
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam2(V self, V *args);
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam1(V self, V *args);
Clo g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_entry, 3, 0};

V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2esymbolJson_24s317767108x209947191(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo(g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eeachSymbol_24s677904211x1723238185(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2eeachSymbol_24s677904211x1723238185(v_st_240, v_c_241, v_rest_246));
  return heff_tail(v_c_2411, 2, (V[]){v_hd_248, heff_clo(g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam3, 1, 2, (V[]){v_k_249, v_x_2410})});
}
V g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2elsp_2eeachSymbol_24s677904211x1723238185_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam0(V self, V *args); static Clo g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam0, 2, 0};
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam1(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam4(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam3(V self, V *args);
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam2(V self, V *args);
Clo g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_entry, 3, 0};

V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_query_241);
    return ((V)&g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2413 = (g_heff_2elsp_2eeachSymbol_24s677904211x1723238185(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2412));
    return heff_clo(g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam2, 2, 4, (V[]){v_c_2413, v_st_240, v_query_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2esymbolsJson_24s422344982x1461684847(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_249 = (g_heff_2elsp_2elowerGo(heff_get(v_y_248, LBL_name), MK_INT(0LL), ((V)&g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_str0)));
  V v_x3_2410 = (g_prelude_2eindexFrom(v_query_241, v_s_249, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419 = (g_prelude_2econcatList(v_x_2416, v_x_2418));
  V f_ = v_k_2415;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2esymbolsJson_24s422344982x1461684847(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo(g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam4, 1, 2, (V[]){v_x_2416, v_k_2415})});
}
V g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_query_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2elsp_2esymbolsJson_24s422344982x1461684847_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam2(V self, V *args);
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam1(V self, V *args);
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam0(V self, V *args);
Clo g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_entry, 2, 0};

V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2edocPath_24s133079231x401204893(heff_dup(v_p_241)));
  return heff_clo(g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(a[0], a[1]);
}
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_247 = heff_env(self)[0];
  V v_d_2410 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2413 = (g_heff_2elsp_2etargetIn(heff_get(heff_dup(v_x_2412), LBL_st), v_f_247, v_d_2410, v_p_241, heff_get(v_x_2412, LBL_program)));
  V f_ = v_k_244;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    heff_drop(v_p_241);
    V v_t_246 = heff_rec(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = ({ V a_0 = heff_dup(v_f_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_p_241);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_c_2411 = (g_heff_2elsp_2eproject_24s545014642x2143879243(v_st_240, heff_dup(v_f_247)));
      return heff_tail(v_c_2411, 2, (V[]){v_hd_243, heff_clo(g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam2, 1, 4, (V[]){v_f_247, v_d_2410, v_p_241, v_k_244})});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2elsp_2ewithTarget_24s1622852202x1773157302_lam1, 1, 4, (V[]){v_st_240, v_k_244, v_hd_243, v_p_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2elocationOf_24s1283476421x1140385417_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2elocationOf_24s1283476421x1140385417_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam1(V self, V *args); static Clo g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam1, 1, 0};
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam0(V self, V *args);
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam2(V self, V *args);
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam4(V self, V *args);
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam3(V self, V *args);
Clo g_heff_2elsp_2elocationOf_24s1283476421x1140385417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocationOf_24s1283476421x1140385417_entry, 2, 0};

V g_heff_2elsp_2elocationOf_24s1283476421x1140385417(V v_st_240, V v_o_241) {
top: ;
  V v_p_242 = heff_get(heff_dup(v_o_241), LBL_path);
  V v_t_243 = ({ V a_0 = heff_dup(v_p_242); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2413;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_c_2413 = heff_clo(g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam0, 2, 1, (V[]){v_p_242});
    break;
  }
  case TAG_Just: {
    V v_d_2410 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_p_242);
    v_c_2413 = heff_clo(g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam2, 2, 1, (V[]){v_d_2410});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_clo(g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam3, 2, 2, (V[]){v_c_2413, v_o_241});
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elocationOf_24s1283476421x1140385417(a[0], a[1]);
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam1(V self, V *args) {
  V v_u_246 = args[0];
  return v_u_246;
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_p_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_PathUri, 2, (V[]){v_p_242, ((V)&g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam1_clo)})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  V f_ = heff_get(v_hd_244, LBL_bind);
  args[0] = v_t_249;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_get(v_d_2410, LBL_uri);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_o_241 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elocationOf_24s1283476421x1140385417_str0), heff_tag(TAG_JString, 1, (V[]){v_x_2416})});
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elocationOf_24s1283476421x1140385417_str1), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_241), LBL_source), heff_get(v_o_241, LBL_span)))});
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_x_2420 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2417, v_t_2419})});
  V f_ = v_k_2415;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo(g_heff_2elsp_2elocationOf_24s1283476421x1140385417_lam4, 1, 2, (V[]){v_o_241, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam0(V self, V *args); static Clo g_heff_2elsp_2elocations_24s577879234x1794888942_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocations_24s577879234x1794888942_lam0, 2, 0};
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam3(V self, V *args);
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam2(V self, V *args);
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam1(V self, V *args);
Clo g_heff_2elsp_2elocations_24s577879234x1794888942_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elocations_24s577879234x1794888942_entry, 2, 0};

V g_heff_2elsp_2elocations_24s577879234x1794888942(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elocations_24s577879234x1794888942_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2elsp_2elocationOf_24s1283476421x1140385417(heff_dup(v_st_240), v_o_244));
    return heff_clo(g_heff_2elsp_2elocations_24s577879234x1794888942_lam1, 2, 3, (V[]){v_c_246, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elocations_24s577879234x1794888942(a[0], a[1]);
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2elsp_2elocations_24s577879234x1794888942(v_st_240, v_rest_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2elsp_2elocations_24s577879234x1794888942_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2elsp_2elocations_24s577879234x1794888942_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2elsp_2elocations_24s577879234x1794888942_lam2, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2eprepared_24s2087070313x466462102_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2eprepared_24s2087070313x466462102_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {96, 32, 105, 115, 32, 110, 111, 116, 32, 119, 114, 105, 116, 116, 101, 110, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2eprepared_24s2087070313x466462102_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2elsp_2eprepared_24s2087070313x466462102_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {112, 108, 97, 99, 101, 104, 111, 108, 100, 101, 114}};
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam1(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam0(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam2(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam4(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam3(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam6(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam5(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam8(V self, V *args);
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam7(V self, V *args);
Clo g_heff_2elsp_2eprepared_24s2087070313x466462102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eprepared_24s2087070313x466462102_entry, 2, 0};

V g_heff_2elsp_2eprepared_24s2087070313x466462102(V v_id_240, V v_tg_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_tg_241), LBL_target);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_c_243 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_240, NTAG(TAG_JNull)));
    return heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam0, 2, 2, (V[]){v_c_243, v_tg_241});
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_248 = (g_heff_2equery_2erenameRefused(heff_get(heff_dup(v_t_247), LBL_target), heff_get(heff_dup(v_t_247), LBL_name), heff_get(heff_dup(v_t_247), LBL_name)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_off_249 = heff_get(heff_dup(v_tg_241), LBL_off);
      V v_t_2415 = ({ V a_0 = heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam2, 1, 2, (V[]){heff_dup(v_t_247), v_off_249}); V b_1 = heff_get(heff_dup(v_t_247), LBL_occurrences); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_242_24Just, 1);
        V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2eprepared_24s2087070313x466462102_str0), heff_strAppend(heff_get(v_t_247, LBL_name), ((V)&g_heff_2elsp_2eprepared_24s2087070313x466462102_str1)));
        V v_c_2417 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_240, MK_INT(-32803LL), v_t_2416));
        return heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam3, 2, 2, (V[]){v_c_2417, v_tg_241});
      }
      case TAG_Just: {
        V v_o_2421 = heff_field(v_t_2415, 0);
        V v_ru_24t_2415_24Just = heff_take_reuse_n(v_t_2415, 1ULL, 1);
        V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eprepared_24s2087070313x466462102_str2), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_2421), LBL_source), heff_get(v_o_2421, LBL_span)))});
        V v_t_2423 = heff_tag_at(v_ru_24t_242_24Just, TAG_JString, 1, (V[]){heff_get(v_t_247, LBL_name)});
        V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eprepared_24s2087070313x466462102_str3), v_t_2423}), NTAG(TAG_Nil)});
        V v_t_2425 = heff_tag_at(v_ru_24t_2415_24Just, TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2422, v_t_2424})});
        V v_c_2426 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_240, v_t_2425));
        return heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam5, 2, 2, (V[]){v_c_2426, v_tg_241});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_Just: {
      V v_why_2430 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_t_247);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      V v_c_2431 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_240, MK_INT(-32803LL), v_why_2430));
      return heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam7, 2, 2, (V[]){v_c_2431, v_tg_241});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eprepared_24s2087070313x466462102(a[0], a[1]);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_246);
  V f_ = v_k_245;
  args[0] = heff_get(v_tg_241, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam1, 1, 2, (V[]){v_k_245, v_tg_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam2(V self, V *args) {
  V v_o_2410 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_off_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_strEq(heff_get(heff_dup(v_o_2410), LBL_path), heff_get(v_t_247, LBL_path));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    V v_t_2412 = heff_get(heff_get(heff_dup(v_o_2410), LBL_span), LBL_start);
    V v_t_2413 = heff_intLe(v_t_2412, heff_dup(v_off_249));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V v_t_2414 = heff_get(heff_get(v_o_2410, LBL_span), LBL_end);
      return heff_intLe(v_off_249, v_t_2414);
    }
    case TAG_False: {
      heff_drop(v_o_2410);
      heff_drop(v_off_249);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_False: {
    heff_drop(v_o_2410);
    heff_drop(v_off_249);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_k_2419;
  args[0] = heff_get(v_tg_241, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam4, 1, 2, (V[]){v_k_2419, v_tg_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_k_2428;
  args[0] = heff_get(v_tg_241, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam5(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam6, 1, 2, (V[]){v_k_2428, v_tg_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2433 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V f_ = v_k_2433;
  args[0] = heff_get(v_tg_241, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eprepared_24s2087070313x466462102_lam7(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2431;
  args[0] = v_hd_2432;
  args[1] = heff_clo(g_heff_2elsp_2eprepared_24s2087070313x466462102_lam8, 1, 2, (V[]){v_k_2433, v_tg_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam3(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam2(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam4(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam8(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam7(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam9(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam10(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam12(V self, V *args); static Clo g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam12, 1, 0};
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam11(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam13(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam14(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam6(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam16(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam15(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam18(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam19(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam17(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam5(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam1(V self, V *args);
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam0(V self, V *args);
Clo g_heff_2elsp_2erenameChecked_24s302972845x403386457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenameChecked_24s302972845x403386457_entry, 3, 0};

V g_heff_2elsp_2erenameChecked_24s302972845x403386457(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2eproject_24s545014642x2143879243(heff_dup(v_st_240), heff_get(heff_dup(v_t_241), LBL_path)));
  return heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam0, 2, 4, (V[]){v_c_243, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenameChecked_24s302972845x403386457(a[0], a[1], a[2]);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam3(V self, V *args) {
  V v_o_2411 = args[0];
  V v_p_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_o_2411, LBL_path), v_p_2410);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_os_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2412 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam3, 1, 1, (V[]){heff_dup(v_p_2410)}), v_os_247));
  return heff_rec(2, shape_path__occurrences, (V[]){v_p_2410, v_os_2412});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam8(V self, V *args) {
  V v_o_2426 = args[0];
  V v_p_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_o_2426, LBL_path), v_p_2425);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam7(V self, V *args) {
  V v_p_2425 = args[0];
  V v_os_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2427 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam8, 1, 1, (V[]){heff_dup(v_p_2425)}), v_os_2422));
  return heff_rec(2, shape_path__occurrences, (V[]){v_p_2425, v_os_2427});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam9(V self, V *args) {
  V v_b_2429 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_b_2429), LBL_path), (g_heff_2elsp_2erenamedText(v_new_242, heff_get(v_b_2429, LBL_occurrences)))});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam10(V self, V *args) {
  V v_q_2431 = args[0];
  V v_p_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434;
  switch (heff_tag_of(v_q_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_q_2431, 0);
    heff_take_n(v_q_2431, 1ULL, 2);
    v_t_2434 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_q_2431);
  }
  return heff_strEq(v_t_2434, v_p_2421);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam12(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam11(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_p_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_p_2421, ((V)&g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam12_clo)})});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2442}));
  V f_ = heff_get(v_hd_2437, LBL_bind);
  args[0] = v_t_2443;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam13(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_d_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2445);
  V v_t_2447 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_d_2444, LBL_text)});
  V f_ = v_k_2446;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam14(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_txt_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = heff_tag(TAG_Just, 1, (V[]){v_txt_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam6(V self, V *args) {
  V v_p_2421 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2422 = heff_get(v_t_241, LBL_occurrences);
  V v_t_2423 = (g_prelude_2emap_24s816432673x804125000(heff_dup(v_os_2422)));
  V v_t_2424 = (g_heff_2elsp_2enubPaths(v_t_2423));
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam7, 1, 1, (V[]){v_os_2422}), v_t_2424));
  V v_texts_2430 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam9, 1, 1, (V[]){v_new_242}), v_t_2428));
  V v_t_2435 = ({ V a_0 = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam10, 1, 1, (V[]){heff_dup(v_p_2421)}); V a_1 = v_texts_2430; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_texts_2430); r_; });
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Nothing: {
    V v_t_2436 = ({ V a_0 = heff_dup(v_p_2421); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nothing: {
      return heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam11, 2, 1, (V[]){v_p_2421});
    }
    case TAG_Just: {
      V v_d_2444 = heff_field(v_t_2436, 0);
      heff_take_n(v_t_2436, 1ULL, 1);
      heff_drop(v_p_2421);
      return heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam13, 2, 1, (V[]){v_d_2444});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_Just: {
    V v_q_2448 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 1);
    heff_drop(v_p_2421);
    heff_drop(v_st_240);
    V v_txt_2451;
    switch (heff_tag_of(v_q_2448)) {
    case TAG_MkPair: {
      V v_y_2450 = heff_field(v_q_2448, 1);
      heff_take_n(v_q_2448, 2ULL, 2);
      v_txt_2451 = v_y_2450;
      break;
    }
    default: heff_nomatch(v_q_2448);
    }
    return heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam14, 2, 1, (V[]){v_txt_2451});
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam16(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sources_2458 = (g_heff_2elsp_2enubSources(v_x_2457));
  V v_x_2459 = (g_prelude_2efoldl_24s919661041x794023661(NTAG(TAG_Nil), v_sources_2458));
  V f_ = v_k_2456;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam15(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_c_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2454;
  args[0] = v_hd_2455;
  args[1] = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam16, 1, 1, (V[]){v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam18(V self, V *args) {
  V v_c_2462 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_2462, LBL_path)}));
  return ({ V a_0 = v_t_2463; V a_1 = v_x_2419; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_x_2419); r_; });
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam19(V self, V *args) {
  V v_c_2467 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_2467, LBL_path)}));
  return ({ V a_0 = v_t_2468; V a_1 = v_x_2419; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_x_2419); r_; });
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam17(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_program_2464 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam18, 1, 1, (V[]){heff_dup(v_x_2419)}), heff_get(heff_dup(v_x_246), LBL_program)));
  V v_t_2465 = (g_heff_2elsp_2enubCheckedPaths(v_program_2464));
  V v_t_2466 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2465; V r_ = (g_prelude_2efoldl_24s656731303x133259214(a_0, a_1, a_2, a_3)); heff_drop(v_t_2465); r_; });
  V v_program_2469 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam19, 1, 1, (V[]){v_x_2419}), heff_dup(v_x_2461)));
  V v_t_2470 = (g_heff_2elsp_2enubCheckedPaths(v_program_2469));
  V v_t_2471 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2470; V r_ = (g_prelude_2efoldl_24s656731303x133259214(a_0, a_1, a_2, a_3)); heff_drop(v_t_2470); r_; });
  V v_x_2472 = (g_heff_2elsp_2erenameVerdict(v_x_246, v_t_241, v_new_242, v_t_2466, v_t_2471, v_x_2461));
  V f_ = v_k_245;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = (g_heff_2elsp_2enubPaths(heff_dup(v_x_2419)));
  V v_c_2454 = ({ V a_0 = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam6, 1, 3, (V[]){heff_dup(v_t_241), heff_dup(v_new_242), heff_dup(v_st_240)}); V a_1 = heff_get(v_st_240, LBL_lib); V a_2 = v_t_2420; V r_ = (g_heff_2elsp_2eloadAll_24s1742300915x648307049(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  V v_c_2460 = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam15, 2, 1, (V[]){v_c_2454});
  return heff_tail(v_c_2460, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam17, 1, 5, (V[]){v_x_2419, v_x_246, v_t_241, v_new_242, v_k_245})});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_247 = heff_get(heff_dup(v_t_241), LBL_occurrences);
  V v_t_248 = (g_prelude_2emap_24s816432673x804125000(heff_dup(v_os_247)));
  V v_t_249 = (g_heff_2elsp_2enubPaths(v_t_248));
  V v_t_2413 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam2, 1, 1, (V[]){v_os_247}), v_t_249));
  V v_t_2414 = (g_prelude_2emap_24s816432673x804125000(v_t_2413));
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V a_2 = heff_get(heff_dup(v_x_246), LBL_program); V r_ = (g_heff_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_c_2418 = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam4, 2, 1, (V[]){v_x_2415});
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam5, 1, 6, (V[]){v_t_241, v_new_242, v_st_240, v_hd_244, v_x_246, v_k_245})});
}
V g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2elsp_2erenameChecked_24s302972845x403386457_lam1, 1, 5, (V[]){v_t_241, v_hd_244, v_new_242, v_st_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2echangesOf_24s1237264701x531281792_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2echangesOf_24s1237264701x531281792_str1 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 84, 101, 120, 116}};
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam0(V self, V *args); static Clo g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam0, 2, 0};
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam2(V self, V *args); static Clo g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam2, 1, 0};
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam1(V self, V *args);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam3(V self, V *args);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam7(V self, V *args);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam6(V self, V *args);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam5(V self, V *args);
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam4(V self, V *args);
Clo g_heff_2elsp_2echangesOf_24s1237264701x531281792_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echangesOf_24s1237264701x531281792_entry, 3, 0};

V g_heff_2elsp_2echangesOf_24s1237264701x531281792(V v_st_240, V v_new_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_new_241);
    return ((V)&g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_p_247 = heff_get(heff_dup(v_b_245), LBL_path);
    V v_t_248 = ({ V a_0 = heff_dup(v_p_247); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_c_2418;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_c_2418 = heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam1, 2, 1, (V[]){v_p_247});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_p_247);
      v_c_2418 = heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam3, 2, 1, (V[]){v_d_2415});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam4, 2, 5, (V[]){v_c_2418, v_st_240, v_new_241, v_rest_246, v_b_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2echangesOf_24s1237264701x531281792(a[0], a[1], a[2]);
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  return v_u_2411;
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_p_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_PathUri, 2, (V[]){v_p_247, ((V)&g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam2_clo)})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_249, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_get(v_d_2415, LBL_uri);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam7(V self, V *args) {
  V v_o_2424 = args[0];
  V v_new_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echangesOf_24s1237264701x531281792_str0), (g_heff_2elsp_2erange(heff_get(heff_dup(v_o_2424), LBL_source), heff_get(v_o_2424, LBL_span)))});
  V v_t_2426 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2echangesOf_24s1237264701x531281792_str1), heff_tag(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  return heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_tag(TAG_JArray, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam7, 1, 1, (V[]){v_new_241}), heff_get(v_b_245, LBL_occurrences)))});
  V v_x_2429 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2421, v_t_2428}), v_x_2423});
  V f_ = v_k_2420;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_k_2420 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2422 = (g_heff_2elsp_2echangesOf_24s1237264701x531281792(v_st_240, heff_dup(v_new_241), v_rest_246));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2419, heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam6, 1, 4, (V[]){v_new_241, v_b_245, v_x_2421, v_k_2420})});
}
V g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_new_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo(g_heff_2elsp_2echangesOf_24s1237264701x531281792_lam5, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_hd_2419, v_b_245, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erenamed_24s901799183x2053671681_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 104, 97, 110, 103, 101, 115}};
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam1(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam0(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam5(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam4(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam7(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam6(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam8(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam3(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam2(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam10(V self, V *args);
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam9(V self, V *args);
Clo g_heff_2elsp_2erenamed_24s901799183x2053671681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erenamed_24s901799183x2053671681_entry, 3, 0};

V g_heff_2elsp_2erenamed_24s901799183x2053671681(V v_id_240, V v_new_241, V v_tg_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_tg_242), LBL_target);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_c_244 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_240, NTAG(TAG_JNull)));
    return heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam0, 2, 2, (V[]){v_c_244, v_tg_242});
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_249 = (g_heff_2equery_2erenameRefused(heff_get(heff_dup(v_t_248), LBL_target), heff_get(heff_dup(v_t_248), LBL_name), heff_dup(v_new_241)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      V v_c_2410 = (g_heff_2elsp_2erenameChecked_24s302972845x403386457(heff_get(v_tg_242, LBL_st), heff_dup(v_t_248), heff_dup(v_new_241)));
      return heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam2, 2, 4, (V[]){v_c_2410, v_t_248, v_new_241, v_id_240});
    }
    case TAG_Just: {
      V v_why_2442 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      heff_drop(v_new_241);
      heff_drop(v_t_248);
      V v_c_2443 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_240, MK_INT(-32803LL), v_why_2442));
      return heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam9, 2, 2, (V[]){v_c_2443, v_tg_242});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erenamed_24s901799183x2053671681(a[0], a[1], a[2]);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_247);
  V f_ = v_k_246;
  args[0] = heff_get(v_tg_242, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam1, 1, 2, (V[]){v_k_246, v_tg_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam5(V self, V *args) {
  V v_o_2424 = args[0];
  V v_p_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_o_2424, LBL_path), v_p_2423);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam4(V self, V *args) {
  V v_p_2423 = args[0];
  V v_os_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2425 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam5, 1, 1, (V[]){heff_dup(v_p_2423)}), v_os_2420));
  return heff_rec(2, shape_path__occurrences, (V[]){v_p_2423, v_os_2425});
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_x_2435;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 2);
    v_x_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_2412;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erenamed_24s901799183x2053671681_str0), heff_tag(TAG_JObject, 1, (V[]){v_x_2428})});
  V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_c_2431 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_240, heff_tag(TAG_JObject, 1, (V[]){v_t_2430})));
  return heff_tail(v_c_2431, 2, (V[]){v_hd_2411, heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam7, 1, 2, (V[]){v_x_2413, v_k_2412})});
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V v_x_2441;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 2);
    v_x_2441 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_2412;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_248 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_dup(heff_field(v_x_2413, 1));
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    V v_t_2419;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_os_2420 = heff_get(v_t_248, LBL_occurrences);
    V v_t_2421 = (g_prelude_2emap_24s816432673x804125000(heff_dup(v_os_2420)));
    V v_t_2422 = (g_heff_2elsp_2enubPaths(v_t_2421));
    V v_t_2426 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam4, 1, 1, (V[]){v_os_2420}), v_t_2422));
    V v_c_2427 = (g_heff_2elsp_2echangesOf_24s1237264701x531281792(v_t_2419, v_new_241, v_t_2426));
    return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam6, 1, 4, (V[]){v_id_240, v_hd_2411, v_x_2413, v_k_2412})});
  }
  case TAG_Just: {
    V v_why_2436 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    heff_drop(v_t_248);
    heff_drop(v_new_241);
    V v_c_2437 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_240, MK_INT(-32803LL), v_why_2436));
    return heff_tail(v_c_2437, 2, (V[]){v_hd_2411, heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam8, 1, 2, (V[]){v_x_2413, v_k_2412})});
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  V v_new_241 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam3, 1, 5, (V[]){v_t_248, v_new_241, v_hd_2411, v_id_240, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam10(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2445 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V f_ = v_k_2445;
  args[0] = heff_get(v_tg_242, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erenamed_24s901799183x2053671681_lam9(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo(g_heff_2elsp_2erenamed_24s901799183x2053671681_lam10, 1, 2, (V[]){v_k_2445, v_tg_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str1 = {{0x80000000u, K_STR, 0}, 21, 21, {104, 101, 102, 102, 58, 32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str3 = {{0x80000000u, K_STR, 0}, 18, 18, {119, 105, 110, 100, 111, 119, 47, 115, 104, 111, 119, 77, 101, 115, 115, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 84, 101, 120, 116}};
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam2(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam1(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam0(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam4(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam3(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam6(V self, V *args);
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam5(V self, V *args);
Clo g_heff_2elsp_2eformattedIn_24s1483613779x861159537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eformattedIn_24s1483613779x861159537_entry, 4, 0};

V g_heff_2elsp_2eformattedIn_24s1483613779x861159537(V v_st_240, V v_id_241, V v_d_242, V v_fix_243) {
top: ;
  V v_src_244 = heff_get(heff_dup(v_d_242), LBL_text);
  V v_t_245 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_244)));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_why_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Left = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_src_244);
    v_t_248 = heff_tag_at(v_ru_24t_245_24Left, TAG_Left, 1, (V[]){v_why_246});
    break;
  }
  case TAG_Right: {
    V v_out_247 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_248 = (g_heff_2eformat_2echeck(v_src_244, v_out_247));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
    heff_drop(v_d_242);
    V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str0), heff_tag_at(v_ru_24t_248_24Left, TAG_JInt, 1, (V[]){MK_INT(2LL)})});
    V v_t_2411 = heff_tag(TAG_JString, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str1), v_why_249)});
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str2), v_t_2411}), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412})});
    V v_c_2414 = (g_heff_2elsp_2enotify_24s2066566305x1387019196(((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str3), v_t_2413));
    return heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam0, 2, 3, (V[]){v_c_2414, v_id_241, v_st_240});
  }
  case TAG_Right: {
    V v_t_2421 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2422 = heff_strEq(heff_dup(v_t_2421), heff_get(heff_dup(v_d_242), LBL_text));
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop(v_d_242);
      heff_drop(v_t_2421);
      V v_t_2423 = heff_tag_at(v_ru_24t_248_24Right, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_c_2424 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_241, v_t_2423));
      return heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam3, 2, 2, (V[]){v_c_2424, v_st_240});
    }
    case TAG_False: {
      V v_t_2428 = heff_strLength(heff_get(heff_dup(v_d_242), LBL_text));
      V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str4), (g_heff_2elsp_2erange(heff_get(v_d_242, LBL_text), heff_rec(2, shape_start__end, (V[]){MK_INT(0LL), v_t_2428})))});
      V v_t_2430 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2eformattedIn_24s1483613779x861159537_str5), heff_tag_at(v_ru_24t_248_24Right, TAG_JString, 1, (V[]){v_t_2421})});
      V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      V v_t_2432 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_t_2431})});
      V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      V v_c_2434 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_241, heff_tag(TAG_JArray, 1, (V[]){v_t_2433})));
      return heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam5, 2, 2, (V[]){v_c_2434, v_st_240});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eformattedIn_24s1483613779x861159537(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_k_2416;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
  V v_c_2419 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_241, v_t_2418));
  return heff_tail(v_c_2419, 2, (V[]){v_hd_2415, heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam2, 1, 2, (V[]){v_k_2416, v_st_240})});
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam1, 1, 4, (V[]){v_id_241, v_hd_2415, v_k_2416, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_k_2426;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam4, 1, 2, (V[]){v_k_2426, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V f_ = v_k_2436;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo(g_heff_2elsp_2eformattedIn_24s1483613779x861159537_lam6, 1, 2, (V[]){v_k_2436, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam2(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam3(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam6(V self, V *args); static Clo g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam6, 1, 0};
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam5(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam7(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam4(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam8(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam1(V self, V *args);
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam0(V self, V *args);
Clo g_heff_2elsp_2eformatted_24s1337690268x1684540053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eformatted_24s1337690268x1684540053_entry, 3, 0};

V g_heff_2elsp_2eformatted_24s1337690268x1684540053(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2edocPath_24s133079231x401204893(v_p_242));
  return heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam0, 2, 3, (V[]){v_c_243, v_id_241, v_st_240});
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eformatted_24s1337690268x1684540053(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam6(V self, V *args) {
  V v_t_2420 = args[0];
  return v_t_2420;
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_q_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_q_2416, ((V)&g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam6_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam7(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_d_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V v_t_2428 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_d_2425, LBL_text)});
  V f_ = v_k_2427;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam4(V self, V *args) {
  V v_q_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = ({ V a_0 = heff_dup(v_q_2416); V b_1 = heff_get(v_st_240, LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    return heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam5, 2, 1, (V[]){v_q_2416});
  }
  case TAG_Just: {
    V v_d_2425 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    heff_drop(v_q_2416);
    return heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam7, 2, 1, (V[]){v_d_2425});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2415 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = (g_heff_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get(v_x_2430, LBL_sources)));
  V v_t_2432 = (g_heff_2elsp_2eformattedIn_24s1483613779x861159537(v_st_240, v_id_241, v_d_2415, v_t_2431));
  return heff_tail(v_t_2432, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_c_248 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_241, v_t_247));
    return heff_tail(v_c_248, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam2, 1, 2, (V[]){v_k_245, v_st_240})});
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2411 = ({ V a_0 = heff_dup(v_f_2410); V b_1 = heff_get(heff_dup(v_st_240), LBL_docs); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop(v_f_2410);
      V v_t_2412 = heff_tag_at(v_ru_24x_246_24Just, TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_c_2413 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_241, v_t_2412));
      return heff_tail(v_c_2413, 2, (V[]){v_hd_244, heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam3, 1, 2, (V[]){v_k_245, v_st_240})});
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x_246_24Just, 1);
      V v_c_2429 = (g_heff_2eload_2eloadProgramWith_24s1828132383x744561138(heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam4, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get(heff_dup(v_st_240), LBL_lib), v_f_2410));
      return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam8, 1, 5, (V[]){v_st_240, v_id_241, v_d_2415, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2elsp_2eformatted_24s1337690268x1684540053_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {105, 110, 105, 116, 105, 97, 108, 105, 122, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {100, 121, 110, 97, 109, 105, 99, 82, 101, 103, 105, 115, 116, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {119, 111, 114, 107, 115, 112, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str3 = {{0x80000000u, K_STR, 0}, 21, 21, {100, 105, 100, 67, 104, 97, 110, 103, 101, 87, 97, 116, 99, 104, 101, 100, 70, 105, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 112, 97, 98, 105, 108, 105, 116, 105, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 104, 117, 116, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 104, 111, 118, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str7 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {117, 114, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {114, 97, 110, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str11 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 100, 111, 99, 117, 109, 101, 110, 116, 83, 121, 109, 98, 111, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {119, 111, 114, 107, 115, 112, 97, 99, 101, 47, 115, 121, 109, 98, 111, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {113, 117, 101, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str16 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 114, 101, 102, 101, 114, 101, 110, 99, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str17 = {{0x80000000u, K_STR, 0}, 18, 18, {105, 110, 99, 108, 117, 100, 101, 68, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str18 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 116, 101, 120, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str19 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 112, 114, 101, 112, 97, 114, 101, 82, 101, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str20 = {{0x80000000u, K_STR, 0}, 19, 19, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 114, 101, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str21 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 101, 119, 78, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str23 = {{0x80000000u, K_STR, 0}, 23, 23, {116, 101, 120, 116, 68, 111, 99, 117, 109, 101, 110, 116, 47, 102, 111, 114, 109, 97, 116, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2elsp_2erequest_24s453191689x1199998842_str24 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 109, 101, 116, 104, 111, 100, 32}};
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam1(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam0(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam3(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam2(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam6(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam5(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam4(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam10(V self, V *args); static Clo g_heff_2elsp_2erequest_24s453191689x1199998842_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erequest_24s453191689x1199998842_lam10, 1, 0};
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam9(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam11(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam13(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam12(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam14(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam8(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam7(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam17(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam16(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam15(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam20(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam21(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam19(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam18(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam26(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam25(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam24(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam23(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam22(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam29(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam31(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam30(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam32(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam28(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam27(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam34(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam33(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam36(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam35(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam38(V self, V *args);
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam37(V self, V *args);
Clo g_heff_2elsp_2erequest_24s453191689x1199998842_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erequest_24s453191689x1199998842_entry, 4, 0};

V g_heff_2elsp_2erequest_24s453191689x1199998842(V v_st_240, V v_m_241, V v_id_242, V v_p_243) {
top: ;
  V v_t_244 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_m_241);
    V v_c_245 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, heff_dup(g_heff_2elsp_2ecapabilities_get())));
    return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam0, 2, 3, (V[]){v_c_245, v_p_243, v_st_240});
  }
  case TAG_False: {
    V v_t_2423 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str5));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_c_2424 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, NTAG(TAG_JNull)));
      return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam2, 2, 2, (V[]){v_c_2424, v_st_240});
    }
    case TAG_False: {
      V v_t_2429 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str6));
      switch (heff_tag_of(v_t_2429)) {
      case TAG_True: {
        heff_drop(v_m_241);
        V v_c_2430 = (g_heff_2elsp_2ewithProgram_24s1295466243x875227959(v_st_240, heff_dup(v_p_243)));
        return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam4, 2, 3, (V[]){v_c_2430, v_p_243, v_id_242});
      }
      case TAG_False: {
        V v_t_2437 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str7));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          heff_drop(v_m_241);
          V v_c_2438 = (g_heff_2elsp_2ewithProgram_24s1295466243x875227959(v_st_240, heff_dup(v_p_243)));
          return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam7, 2, 3, (V[]){v_c_2438, v_p_243, v_id_242});
        }
        case TAG_False: {
          V v_t_2468 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str10));
          switch (heff_tag_of(v_t_2468)) {
          case TAG_True: {
            heff_drop(v_m_241);
            V v_c_2469 = (g_heff_2elsp_2ewithProgram_24s1295466243x875227959(v_st_240, heff_dup(v_p_243)));
            return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam15, 2, 3, (V[]){v_c_2469, v_p_243, v_id_242});
          }
          case TAG_False: {
            V v_t_2481 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str11));
            switch (heff_tag_of(v_t_2481)) {
            case TAG_True: {
              heff_drop(v_m_241);
              V v_c_2482 = (g_heff_2elsp_2ewithProgram_24s1295466243x875227959(v_st_240, v_p_243));
              return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam18, 2, 2, (V[]){v_c_2482, v_id_242});
            }
            case TAG_False: {
              V v_t_2494 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str12));
              switch (heff_tag_of(v_t_2494)) {
              case TAG_True: {
                heff_drop(v_m_241);
                V v_t_2495 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_docs); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
                V v_t_2496 = (g_prelude_2emap_24s1581021428x1223114127(v_t_2495));
                V v_c_2497 = (g_heff_2elsp_2erootsOf_24s535930516x390676296(heff_dup(v_st_240), v_t_2496));
                return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam22, 2, 4, (V[]){v_c_2497, v_st_240, v_p_243, v_id_242});
              }
              case TAG_False: {
                V v_t_24122 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str16));
                switch (heff_tag_of(v_t_24122)) {
                case TAG_True: {
                  heff_drop(v_m_241);
                  V v_c_24123 = (g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(v_st_240, heff_dup(v_p_243)));
                  return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam27, 2, 3, (V[]){v_c_24123, v_id_242, v_p_243});
                }
                case TAG_False: {
                  V v_t_24150 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str19));
                  switch (heff_tag_of(v_t_24150)) {
                  case TAG_True: {
                    heff_drop(v_m_241);
                    V v_c_24151 = (g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(v_st_240, v_p_243));
                    return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam33, 2, 2, (V[]){v_c_24151, v_id_242});
                  }
                  case TAG_False: {
                    V v_t_24156 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str20));
                    switch (heff_tag_of(v_t_24156)) {
                    case TAG_True: {
                      heff_drop(v_m_241);
                      V v_c_24157 = (g_heff_2elsp_2ewithTarget_24s1622852202x1773157302(v_st_240, heff_dup(v_p_243)));
                      return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam35, 2, 3, (V[]){v_c_24157, v_p_243, v_id_242});
                    }
                    case TAG_False: {
                      V v_t_24174 = heff_strEq(heff_dup(v_m_241), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str23));
                      switch (heff_tag_of(v_t_24174)) {
                      case TAG_True: {
                        heff_drop(v_m_241);
                        return (g_heff_2elsp_2eformatted_24s1337690268x1684540053(v_st_240, v_id_242, v_p_243));
                      }
                      case TAG_False: {
                        heff_drop(v_p_243);
                        V v_c_24175 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str24), v_m_241)));
                        return heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam37, 2, 2, (V[]){v_c_24175, v_st_240});
                      }
                      default: return heff_nomatch(v_t_24174);
                      }
                    }
                    default: return heff_nomatch(v_t_24156);
                    }
                  }
                  default: return heff_nomatch(v_t_24150);
                  }
                }
                default: return heff_nomatch(v_t_24122);
                }
              }
              default: return heff_nomatch(v_t_2494);
              }
            }
            default: return heff_nomatch(v_t_2481);
            }
          }
          default: return heff_nomatch(v_t_2468);
          }
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2429);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erequest_24s453191689x1199998842(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_248);
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str1), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str3), v_t_249})});
  V v_it_2411 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str4), v_t_2410}); V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2419;
  switch (heff_tag_of(v_it_2411)) {
  case TAG_Nothing: {
    v_x2_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2412 = heff_field(v_it_2411, 0);
    V v_ru_24it_2411_24Just = heff_take_reuse_n(v_it_2411, 1ULL, 1);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_2413 = heff_field(v_it1_2412, 0);
      heff_take_n(v_it1_2412, 1ULL, 1);
      v_x2_2419 = heff_tag_at(v_ru_24it_2411_24Just, TAG_Just, 1, (V[]){v_b_2413});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2411_24Just, 1);
      v_x2_2419 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2412);
    }
    break;
  }
  default: heff_nomatch(v_it_2411);
  }
  V v_w_2421;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    v_w_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    v_w_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V v_x_2422 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), v_w_2421, heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(v_st_240, LBL_lib)});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam1, 1, 3, (V[]){v_p_243, v_st_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), heff_get(heff_dup(v_st_240), LBL_due), heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), NTAG(TAG_True), heff_get(v_st_240, LBL_lib)});
  V f_ = v_k_2426;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam3, 1, 2, (V[]){v_st_240, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2432 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_2432;
  args[0] = heff_get(v_x_2433, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2431 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2434 = (g_heff_2elsp_2ehoverOf(heff_dup(v_x_2433), v_p_243));
  V v_c_2435 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, v_t_2434));
  return heff_tail(v_c_2435, 2, (V[]){v_hd_2431, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam6, 1, 2, (V[]){v_k_2432, v_x_2433})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam5, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2431, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam10(V self, V *args) {
  V v_u_2450 = args[0];
  return v_u_2450;
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam9(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_p_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_PathUri, 2, (V[]){v_p_2445, ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_lam10_clo)})});
  V v_t_2452 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2448), LBL_malg), 1, (V[]){v_t_2452}));
  V f_ = heff_get(v_hd_2448, LBL_bind);
  args[0] = v_t_2453;
  args[1] = v_k2_2449;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam11(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_d_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = heff_get(v_d_2454, LBL_uri);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam13(V self, V *args) {
  V v_x_2460 = args[0];
  V v_d_2444 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2458 = heff_env(self)[2];
  V v_k_2459 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2461 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str8), heff_tag(TAG_JString, 1, (V[]){v_x_2460})});
  V v_t_2462 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str9), (g_heff_2elsp_2erange(heff_get(heff_dup(v_d_2444), LBL_source), heff_get(v_d_2444, LBL_span)))});
  V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
  V v_t_2464 = heff_tag(TAG_JObject, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2461, v_t_2463})});
  V v_t_2465 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, v_t_2464));
  return heff_tail(v_t_2465, 2, (V[]){v_hd_2458, v_k_2459});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam12(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_d_2444 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam13, 1, 4, (V[]){v_d_2444, v_id_242, v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam14(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_x_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2467);
  V f_ = v_k_2440;
  args[0] = heff_get(v_x_2441, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2439 = heff_env(self)[2];
  V v_k_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_x_2441), LBL_text), v_p_243));
  V v_t_2443 = (g_heff_2equery_2edefinitionAt(heff_get(heff_dup(v_x_2441), LBL_program), v_t_2442));
  V v_c_2466;
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    v_c_2466 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, NTAG(TAG_JNull)));
    break;
  }
  case TAG_Just: {
    V v_d_2444 = heff_field(v_t_2443, 0);
    heff_take_n(v_t_2443, 1ULL, 1);
    V v_p_2445 = heff_get(heff_dup(v_d_2444), LBL_path);
    V v_t_2446 = heff_get(heff_get(heff_dup(v_x_2441), LBL_st), LBL_docs);
    V v_t_2447 = ({ V a_0 = heff_dup(v_p_2445); V a_1 = v_t_2446; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_c_2457;
    switch (heff_tag_of(v_t_2447)) {
    case TAG_Nothing: {
      v_c_2457 = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam9, 2, 1, (V[]){v_p_2445});
      break;
    }
    case TAG_Just: {
      V v_d_2454 = heff_field(v_t_2447, 0);
      heff_take_n(v_t_2447, 1ULL, 1);
      heff_drop(v_p_2445);
      v_c_2457 = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam11, 2, 1, (V[]){v_d_2454});
      break;
    }
    default: heff_nomatch(v_t_2447);
    }
    v_c_2466 = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam12, 2, 3, (V[]){v_c_2457, v_d_2444, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_2443);
  }
  return heff_tail(v_c_2466, 2, (V[]){v_hd_2439, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam14, 1, 2, (V[]){v_k_2440, v_x_2441})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam7(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2438;
  args[0] = heff_dup(v_hd_2439);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam8, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2439, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam17(V self, V *args) {
  V v_x_2480 = args[0];
  V v_k_2471 = heff_env(self)[0];
  V v_x_2472 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2480);
  V f_ = v_k_2471;
  args[0] = heff_get(v_x_2472, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam16(V self, V *args) {
  V v_x_2472 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2470 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2473 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_x_2472), LBL_program)));
  V v_t_2478;
  switch (heff_tag_of(v_x1_2473)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    v_t_2478 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2474 = heff_field(v_x1_2473, 0);
    heff_take_n(v_x1_2473, 1ULL, 2);
    V v_t_2476 = (g_heff_2elsp_2eoffsetIn(heff_get(heff_dup(v_x_2472), LBL_text), v_p_243));
    V v_t_2477 = (g_heff_2equery_2ecompletionsAt(v_x_2474, v_t_2476));
    v_t_2478 = (g_prelude_2emap_24s697897431x2046530597(v_t_2477));
    break;
  }
  default: heff_nomatch(v_x1_2473);
  }
  V v_c_2479 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_t_2478})));
  return heff_tail(v_c_2479, 2, (V[]){v_hd_2470, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam17, 1, 2, (V[]){v_k_2471, v_x_2472})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam15(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2469;
  args[0] = heff_dup(v_hd_2470);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam16, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2470, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam20(V self, V *args) {
  V v_y_2490 = args[0];
  V v_x_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2edocSymbol(heff_get(v_x_2485, LBL_text), v_y_2490));
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam21(V self, V *args) {
  V v_x_2493 = args[0];
  V v_k_2484 = heff_env(self)[0];
  V v_x_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2493);
  V f_ = v_k_2484;
  args[0] = heff_get(v_x_2485, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam19(V self, V *args) {
  V v_x_2485 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_2483 = heff_env(self)[1];
  V v_k_2484 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2486 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_x_2485), LBL_program)));
  V v_t_2491;
  switch (heff_tag_of(v_x1_2486)) {
  case TAG_Nil: {
    v_t_2491 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2487 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 2);
    V v_t_2489 = (g_heff_2equery_2esymbols(v_x_2487));
    v_t_2491 = (g_prelude_2emap(heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam20, 1, 1, (V[]){heff_dup(v_x_2485)}), v_t_2489));
    break;
  }
  default: heff_nomatch(v_x1_2486);
  }
  V v_c_2492 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_t_2491})));
  return heff_tail(v_c_2492, 2, (V[]){v_hd_2483, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam21, 1, 2, (V[]){v_k_2484, v_x_2485})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam18(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_c_2482 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2482;
  args[0] = heff_dup(v_hd_2483);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam19, 1, 3, (V[]){v_id_242, v_hd_2483, v_k_2484});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam26(V self, V *args) {
  V v_x_24121 = args[0];
  V v_k_2499 = heff_env(self)[0];
  V v_x_24103 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24121);
  V f_ = v_k_2499;
  args[0] = heff_get(v_x_24103, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam25(V self, V *args) {
  V v_x_24119 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_2498 = heff_env(self)[1];
  V v_k_2499 = heff_env(self)[2];
  V v_x_24103 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24120 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_x_24119})));
  return heff_tail(v_c_24120, 2, (V[]){v_hd_2498, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam26, 1, 2, (V[]){v_k_2499, v_x_24103})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam24(V self, V *args) {
  V v_x_24103 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_hd_2498 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_k_2499 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24104 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str13), NTAG(TAG_Nil)});
  V v_it_24105 = ({ V a_0 = v_t_24104; V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24104, 2); r_; });
  V v_x2_24113;
  switch (heff_tag_of(v_it_24105)) {
  case TAG_Nothing: {
    v_x2_24113 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24106 = heff_field(v_it_24105, 0);
    V v_ru_24it_24105_24Just = heff_take_reuse_n(v_it_24105, 1ULL, 1);
    switch (heff_tag_of(v_it1_24106)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24106, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24106, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24106, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24110 = heff_field(v_it1_24106, 0);
      heff_take_n(v_it1_24106, 1ULL, 1);
      v_x2_24113 = heff_tag_at(v_ru_24it_24105_24Just, TAG_Just, 1, (V[]){v_s_24110});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24106, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24106, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24105_24Just, 1);
      v_x2_24113 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24106);
    }
    break;
  }
  default: heff_nomatch(v_it_24105);
  }
  V v_s_24115;
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_Nothing: {
    v_s_24115 = ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str14);
    break;
  }
  case TAG_Just: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    heff_take_n(v_x2_24113, 1ULL, 1);
    v_s_24115 = v_x_24114;
    break;
  }
  default: heff_nomatch(v_x2_24113);
  }
  V v_t_24116 = (g_heff_2elsp_2elowerGo(v_s_24115, MK_INT(0LL), ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str15)));
  V v_t_24117 = (g_heff_2elsp_2enubCheckedPaths(heff_get(heff_dup(v_x_24103), LBL_program)));
  V v_c_24118 = ({ V a_0 = heff_get(heff_dup(v_x_24103), LBL_st); V a_1 = v_t_24116; V a_2 = v_t_24117; V r_ = (g_heff_2elsp_2esymbolsJson_24s422344982x1461684847(a_0, a_1, a_2)); heff_drop(v_t_24117); r_; });
  return heff_tail(v_c_24118, 2, (V[]){heff_dup(v_hd_2498), heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam25, 1, 4, (V[]){v_id_242, v_hd_2498, v_k_2499, v_x_24103})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam23(V self, V *args) {
  V v_x_24100 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_2498 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_k_2499 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24101 = (g_heff_2elsp_2enubRoots(v_x_24100));
  V v_c_24102 = ({ V a_0 = v_st_240; V a_1 = v_t_24101; V r_ = (g_heff_2elsp_2eprojects_24s1224286600x2087827045(a_0, a_1)); heff_drop(v_t_24101); r_; });
  return heff_tail(v_c_24102, 2, (V[]){heff_dup(v_hd_2498), heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam24, 1, 4, (V[]){v_p_243, v_hd_2498, v_id_242, v_k_2499})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam22(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  V v_c_2497 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2497;
  args[0] = heff_dup(v_hd_2498);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam23, 1, 5, (V[]){v_st_240, v_hd_2498, v_p_243, v_id_242, v_k_2499});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam29(V self, V *args) {
  V v_o_24129 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24130 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str17), NTAG(TAG_Nil)});
  V v_it_24131 = ({ V b_0 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str18), v_t_24130}); V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_24139;
  switch (heff_tag_of(v_it_24131)) {
  case TAG_Nothing: {
    v_x2_24139 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24132 = heff_field(v_it_24131, 0);
    V v_ru_24it_24131_24Just = heff_take_reuse_n(v_it_24131, 1ULL, 1);
    switch (heff_tag_of(v_it1_24132)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_24133 = heff_field(v_it1_24132, 0);
      heff_take_n(v_it1_24132, 1ULL, 1);
      v_x2_24139 = heff_tag_at(v_ru_24it_24131_24Just, TAG_Just, 1, (V[]){v_b_24133});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24132, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24132, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_24132, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24132, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24132, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24131_24Just, 1);
      v_x2_24139 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24132);
    }
    break;
  }
  default: heff_nomatch(v_it_24131);
  }
  switch (heff_tag_of(v_x2_24139)) {
  case TAG_Nothing: {
    heff_drop(v_o_24129);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_x_24140 = heff_field(v_x2_24139, 0);
    heff_take_n(v_x2_24139, 1ULL, 1);
    switch (heff_tag_of(v_x_24140)) {
    case TAG_True: {
      heff_drop(v_o_24129);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_24141 = heff_get(v_o_24129, LBL_defines);
      switch (heff_tag_of(v_t_24141)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_24141);
      }
    }
    default: return heff_nomatch(v_x_24140);
    }
  }
  default: return heff_nomatch(v_x2_24139);
  }
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam31(V self, V *args) {
  V v_x_24146 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24144 = heff_env(self)[1];
  V v_k_24145 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24147 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, heff_tag(TAG_JArray, 1, (V[]){v_x_24146})));
  return heff_tail(v_t_24147, 2, (V[]){v_hd_24144, v_k_24145});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam30(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24143;
  args[0] = heff_dup(v_hd_24144);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam31, 1, 3, (V[]){v_id_242, v_hd_24144, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam32(V self, V *args) {
  V v_x_24149 = args[0];
  V v_k_24125 = heff_env(self)[0];
  V v_x_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24149);
  V f_ = v_k_24125;
  args[0] = heff_get(v_x_24126, LBL_st);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam28(V self, V *args) {
  V v_x_24126 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_hd_24124 = heff_env(self)[2];
  V v_k_24125 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24127 = heff_get(heff_dup(v_x_24126), LBL_target);
  V v_c_24148;
  switch (heff_tag_of(v_t_24127)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    v_c_24148 = (g_heff_2elsp_2ereply_24s1469169503x1913753224(v_id_242, NTAG(TAG_JNull)));
    break;
  }
  case TAG_Just: {
    V v_t_24128 = heff_field(v_t_24127, 0);
    heff_take_n(v_t_24127, 1ULL, 1);
    V v_t_24142 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam29, 1, 1, (V[]){v_p_243}), heff_get(v_t_24128, LBL_occurrences)));
    V v_c_24143 = (g_heff_2elsp_2elocations_24s577879234x1794888942(heff_get(heff_dup(v_x_24126), LBL_st), v_t_24142));
    v_c_24148 = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam30, 2, 2, (V[]){v_c_24143, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24127);
  }
  return heff_tail(v_c_24148, 2, (V[]){v_hd_24124, heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam32, 1, 2, (V[]){v_k_24125, v_x_24126})});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam27(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam28, 1, 4, (V[]){v_id_242, v_p_243, v_hd_24124, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam34(V self, V *args) {
  V v_x_24154 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24152 = heff_env(self)[1];
  V v_k_24153 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24155 = (g_heff_2elsp_2eprepared_24s2087070313x466462102(v_id_242, v_x_24154));
  return heff_tail(v_t_24155, 2, (V[]){v_hd_24152, v_k_24153});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam33(V self, V *args) {
  V v_hd_24152 = args[0];
  V v_k_24153 = args[1];
  V v_c_24151 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24151;
  args[0] = heff_dup(v_hd_24152);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam34, 1, 3, (V[]){v_id_242, v_hd_24152, v_k_24153});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam36(V self, V *args) {
  V v_x_24160 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24158 = heff_env(self)[2];
  V v_k_24159 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24161 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str21), NTAG(TAG_Nil)});
  V v_it_24162 = ({ V a_0 = v_t_24161; V a_1 = v_p_243; V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24161, 2); r_; });
  V v_x2_24170;
  switch (heff_tag_of(v_it_24162)) {
  case TAG_Nothing: {
    v_x2_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24163 = heff_field(v_it_24162, 0);
    V v_ru_24it_24162_24Just = heff_take_reuse_n(v_it_24162, 1ULL, 1);
    switch (heff_tag_of(v_it1_24163)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24167 = heff_field(v_it1_24163, 0);
      heff_take_n(v_it1_24163, 1ULL, 1);
      v_x2_24170 = heff_tag_at(v_ru_24it_24162_24Just, TAG_Just, 1, (V[]){v_s_24167});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24162_24Just, 1);
      v_x2_24170 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24163);
    }
    break;
  }
  default: heff_nomatch(v_it_24162);
  }
  V v_t_24172;
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_Nothing: {
    v_t_24172 = ((V)&g_heff_2elsp_2erequest_24s453191689x1199998842_str22);
    break;
  }
  case TAG_Just: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    heff_take_n(v_x2_24170, 1ULL, 1);
    v_t_24172 = v_x_24171;
    break;
  }
  default: heff_nomatch(v_x2_24170);
  }
  V v_t_24173 = (g_heff_2elsp_2erenamed_24s901799183x2053671681(v_id_242, v_t_24172, v_x_24160));
  return heff_tail(v_t_24173, 2, (V[]){v_hd_24158, v_k_24159});
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam35(V self, V *args) {
  V v_hd_24158 = args[0];
  V v_k_24159 = args[1];
  V v_c_24157 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24157;
  args[0] = heff_dup(v_hd_24158);
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam36, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24158, v_k_24159});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam38(V self, V *args) {
  V v_x_24178 = args[0];
  V v_k_24177 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24178);
  V f_ = v_k_24177;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2erequest_24s453191689x1199998842_lam37(V self, V *args) {
  V v_hd_24176 = args[0];
  V v_k_24177 = args[1];
  V v_c_24175 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24175;
  args[0] = v_hd_24176;
  args[1] = heff_clo(g_heff_2elsp_2erequest_24s453191689x1199998842_lam38, 1, 2, (V[]){v_k_24177, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {109, 101, 116, 104, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 104, 117, 116, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 104, 117, 116, 32, 100, 111, 119, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2elsp_2ehandle_24s574943937x1766520211_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 97, 114, 97, 109, 115}};
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam0(V self, V *args);
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam2(V self, V *args);
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam1(V self, V *args);
Clo g_heff_2elsp_2ehandle_24s574943937x1766520211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ehandle_24s574943937x1766520211_entry, 2, 0};

V g_heff_2elsp_2ehandle_24s574943937x1766520211(V v_st_240, V v_msg_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V a_0 = v_t_242; V a_1 = heff_dup(v_msg_241); V r_ = (g_heff_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_242, 2); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_248 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      v_t_2411 = heff_tag_at(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_s_248});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    return heff_clo(g_heff_2elsp_2ehandle_24s574943937x1766520211_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2420 = heff_dup(heff_field(v_msg_241, 0));
      V v_t_2421 = ({ V a_0 = ((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str1); V a_1 = v_fs_2420; V r_ = (g_prelude_2efind_24s1996057548x665004299(a_0, a_1)); heff_drop(v_fs_2420); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_2411_24Just, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_p_2422)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_p_2422, 1);
          heff_take_n(v_p_2422, 2ULL, 2);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_p_2422);
        }
        v_t_2426 = heff_tag_at(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2425});
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_x2_2438;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        V v_fs_2432 = heff_field(v_msg_241, 0);
        V v_ru_24msg_241_24JObject = heff_take_reuse_n(v_msg_241, 1ULL, 1);
        V v_t_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str2); V a_1 = v_fs_2432; V r_ = (g_prelude_2efind_24s1996057548x665004299(a_0, a_1)); heff_drop(v_fs_2432); r_; });
        switch (heff_tag_of(v_t_2433)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24msg_241_24JObject, 1);
          v_x2_2438 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_2434 = heff_field(v_t_2433, 0);
          heff_take_n(v_t_2433, 1ULL, 1);
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take_n(v_p_2434, 2ULL, 2);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_x2_2438 = heff_tag_at(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_t_2437});
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nothing: {
        v_t_2440 = NTAG(TAG_JNull);
        break;
      }
      case TAG_Just: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        heff_take_n(v_x2_2438, 1ULL, 1);
        v_t_2440 = v_x_2439;
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return (g_heff_2elsp_2enotification_24s1809009350x1217072135(v_st_240, v_m_2414, v_t_2440));
    }
    case TAG_Just: {
      V v_id_2441 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      V v_t_2442 = heff_get(heff_dup(v_st_240), LBL_shutdown);
      V v_t_2444;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        V v_t_2443 = heff_strEq(heff_dup(v_m_2414), ((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str3));
        switch (heff_tag_of(v_t_2443)) {
        case TAG_True: {
          v_t_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2444 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        break;
      }
      case TAG_False: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      switch (heff_tag_of(v_t_2444)) {
      case TAG_True: {
        heff_drop(v_msg_241);
        heff_drop(v_m_2414);
        heff_drop_cell(v_ru_24t_2426_24Just, 1);
        V v_c_2445 = (g_heff_2elsp_2ereplyError_24s1722239765x1825266297(v_id_2441, MK_INT(-32600LL), ((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str4)));
        return heff_clo(g_heff_2elsp_2ehandle_24s574943937x1766520211_lam1, 2, 2, (V[]){v_c_2445, v_st_240});
      }
      case TAG_False: {
        V v_x2_2460;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2454 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          V v_t_2455 = ({ V a_0 = ((V)&g_heff_2elsp_2ehandle_24s574943937x1766520211_str5); V a_1 = v_fs_2454; V r_ = (g_prelude_2efind_24s1996057548x665004299(a_0, a_1)); heff_drop(v_fs_2454); r_; });
          switch (heff_tag_of(v_t_2455)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24t_2426_24Just, 1);
            v_x2_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_p_2456 = heff_field(v_t_2455, 0);
            heff_take_n(v_t_2455, 1ULL, 1);
            V v_t_2459;
            switch (heff_tag_of(v_p_2456)) {
            case TAG_MkPair: {
              V v_y_2458 = heff_field(v_p_2456, 1);
              heff_take_n(v_p_2456, 2ULL, 2);
              v_t_2459 = v_y_2458;
              break;
            }
            default: heff_nomatch(v_p_2456);
            }
            v_x2_2460 = heff_tag_at(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_t_2459});
            break;
          }
          default: heff_nomatch(v_t_2455);
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        V v_t_2462;
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_Nothing: {
          v_t_2462 = NTAG(TAG_JNull);
          break;
        }
        case TAG_Just: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          heff_take_n(v_x2_2460, 1ULL, 1);
          v_t_2462 = v_x_2461;
          break;
        }
        default: heff_nomatch(v_x2_2460);
        }
        return (g_heff_2elsp_2erequest_24s453191689x1199998842(v_st_240, v_m_2414, v_id_2441, v_t_2462));
      }
      default: return heff_nomatch(v_t_2444);
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2ehandle_24s574943937x1766520211_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2ehandle_24s574943937x1766520211(a[0], a[1]);
}
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_2447;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2ehandle_24s574943937x1766520211_lam1(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo(g_heff_2elsp_2ehandle_24s574943937x1766520211_lam2, 1, 2, (V[]){v_k_2447, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam0(V self, V *args);
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam2(V self, V *args);
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam1(V self, V *args);
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam4(V self, V *args);
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam3(V self, V *args);
Clo g_heff_2elsp_2echeckDue_24s217346529x82598444_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2echeckDue_24s217346529x82598444_entry, 2, 0};

V g_heff_2elsp_2echeckDue_24s217346529x82598444(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2elsp_2echeckDue_24s217346529x82598444_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = ({ V a_0 = heff_dup(v_f_244); V b_1 = heff_get(heff_dup(v_st_240), LBL_due); V r_ = (g_map_2edelete_24s805420727x38051515(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_247 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_get(heff_dup(v_st_240), LBL_docs), heff_get(heff_dup(v_st_240), LBL_checked), v_t_246, heff_get(heff_dup(v_st_240), LBL_project), heff_get(heff_dup(v_st_240), LBL_watch), heff_get(heff_dup(v_st_240), LBL_shutdown), heff_get(heff_dup(v_st_240), LBL_lib)});
    V v_c_248 = (g_heff_2elsp_2echeck_24s447642999x1873703689(v_t_247, heff_dup(v_f_244)));
    V v_c_2414 = heff_clo(g_heff_2elsp_2echeckDue_24s217346529x82598444_lam1, 2, 3, (V[]){v_c_248, v_st_240, heff_dup(v_f_244)});
    return heff_clo(g_heff_2elsp_2echeckDue_24s217346529x82598444_lam3, 2, 2, (V[]){v_c_2414, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2echeckDue_24s217346529x82598444(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = (g_heff_2elsp_2edependentsOf(v_st_240, v_f_244));
  V v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_t_2412; V r_ = (g_heff_2elsp_2echeckAll_24s417884660x239518827(a_0, a_1)); heff_drop(v_t_2412); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_249, v_k_2410});
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2elsp_2echeckDue_24s217346529x82598444_lam2, 1, 4, (V[]){v_st_240, v_f_244, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = ({ V a_0 = v_x_2417; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2echeckDue_24s217346529x82598444(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2418, 2, (V[]){v_hd_2415, v_k_2416});
}
V g_heff_2elsp_2echeckDue_24s217346529x82598444_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2elsp_2echeckDue_24s217346529x82598444_lam4, 1, 3, (V[]){v_rest_245, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam0(V self, V *args); static Clo g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam0, 1, 0};
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam2(V self, V *args); static Clo g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam2, 1, 0};
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam4(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam3(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam6(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam7(V self, V *args); static Clo g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam7, 1, 0};
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam9(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam10(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam8(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam5(V self, V *args);
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam1(V self, V *args);
Clo g_heff_2elsp_2eserveFrom_24s971709170x1335763618_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserveFrom_24s971709170x1335763618_entry, 3, 0};

V g_heff_2elsp_2eserveFrom_24s971709170x1335763618(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eserveFrom_24s971709170x1335763618(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  return v_x_2419;
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam4(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2423), heff_get(v_hd_2423, LBL_ret)});
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_p_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1682480088x1491420330_get()), LBL_hmap), 2, (V[]){heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam4, 1, 1, (V[]){heff_dup(v_hd_2423)}), v_p_2422}));
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2eserveFrom_24s971709170x1335763618(v_x_2432, v_hd_241, v_k_242));
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam7(V self, V *args) {
  V v_n_2433 = args[0];
  return v_n_2433;
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam9(V self, V *args) {
  V v_q_2439 = args[0];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442;
  switch (heff_tag_of(v_q_2439)) {
  case TAG_MkPair: {
    V v_y_2441 = heff_field(v_q_2439, 1);
    heff_take_n(v_q_2439, 2ULL, 2);
    v_t_2442 = v_y_2441;
    break;
  }
  default: heff_nomatch(v_q_2439);
  }
  return heff_intLe(v_t_2442, v_x_2437);
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam10(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2eserveFrom_24s971709170x1335763618(v_x_2446, v_hd_241, v_k_242));
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2438 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_due); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2443 = (g_prelude_2efilter(heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam9, 1, 1, (V[]){v_x_2437}), v_t_2438));
  V v_t_2444 = (g_prelude_2emap_24s1581021428x1223114127(v_t_2443));
  V v_c_2445 = ({ V a_0 = v_st_240; V a_1 = v_t_2444; V r_ = (g_heff_2elsp_2echeckDue_24s217346529x82598444(a_0, a_1)); heff_drop(v_t_2444); r_; });
  return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam10, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Message: {
    V v_msg_2430 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    V v_c_2431 = (g_heff_2elsp_2ehandle_24s574943937x1766520211(v_st_240, v_msg_2430));
    return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam6, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Timeout: {
    V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam7_clo)})});
    V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2436, heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam8, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
  }
  case TAG_Closed: {
    heff_drop(v_st_240);
    V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2449, v_k_242});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = ({ V b_0 = heff_get(heff_dup(v_st_240), LBL_due); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249 = (g_prelude_2emap_24s531459667x996402587(v_t_248));
  V v_ms_2416;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    heff_drop(v_x_247);
    v_ms_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_2410 = heff_field(v_t_249, 0);
    V v_ds_2411 = heff_field(v_t_249, 1);
    heff_take_n(v_t_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_d_2410; V a_1 = v_ds_2411; V r_ = (g_prelude_2efoldl_24s1163606919x177582362(a_0, a_1)); heff_drop(v_ds_2411); r_; });
    V v_b_2413 = heff_intSub(v_t_2412, v_x_247);
    V v_t_2414 = heff_intLe(MK_INT(0LL), heff_dup(v_b_2413));
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      v_t_2415 = v_b_2413;
      break;
    }
    case TAG_False: {
      heff_drop(v_b_2413);
      v_t_2415 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    v_ms_2416 = heff_tag(TAG_Just, 1, (V[]){v_t_2415});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2418;
  switch (heff_tag_of(v_ms_2416)) {
  case TAG_Nothing: {
    v_t_2418 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_ms_2416, 0);
    heff_take_n(v_ms_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_ms_2416);
  }
  V v_a_2420 = heff_tag(TAG_Await, 2, (V[]){v_t_2418, ((V)&g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam2_clo)});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_a_2420})});
  V v_p_2422 = heff_tag(TAG_InR, 1, (V[]){v_t_2421});
  V v_c_2428 = heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam3, 2, 1, (V[]){v_p_2422});
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2elsp_2eserveFrom_24s971709170x1335763618_lam5, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserve_24s1076151099x109167290_lam0(V self, V *args); static Clo g_heff_2elsp_2eserve_24s1076151099x109167290_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserve_24s1076151099x109167290_lam0, 1, 0};
V g_heff_2elsp_2eserve_24s1076151099x109167290_lam1(V self, V *args);
Clo g_heff_2elsp_2eserve_24s1076151099x109167290_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2eserve_24s1076151099x109167290_entry, 3, 0};

V g_heff_2elsp_2eserve_24s1076151099x109167290(V v_h0_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_AbsPath, 2, (V[]){heff_get(heff_dup(v_h0_240), LBL_lib), ((V)&g_heff_2elsp_2eserve_24s1076151099x109167290_lam0_clo)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2elsp_2eserve_24s1076151099x109167290_lam1, 1, 3, (V[]){v_h0_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2eserve_24s1076151099x109167290_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2eserve_24s1076151099x109167290(a[0], a[1], a[2]);
}
V g_heff_2elsp_2eserve_24s1076151099x109167290_lam0(V self, V *args) {
  V v_a_243 = args[0];
  return v_a_243;
}
V g_heff_2elsp_2eserve_24s1076151099x109167290_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_h0_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_rec(3, shape_lib__mod__style, (V[]){v_x_247, heff_get(heff_dup(v_h0_240), LBL_mod), heff_get(v_h0_240, LBL_style)});
  V v_t_249 = heff_rec(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_248});
  return (g_heff_2elsp_2eserveFrom_24s971709170x1335763618(v_t_249, v_hd_241, v_k_242));
}