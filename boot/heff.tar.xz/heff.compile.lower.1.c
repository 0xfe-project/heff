// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_KnownCell 38933
#define TAG_Left 13886
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_RepV 61860
#define TAG_Right 62770
#define LBL_after 294093302
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_cells 295903083
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_entry 298026124
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lazy 9809979
#define LBL_lent 9813446
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_owned 307523263
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_pieces 958716528
#define LBL_refs 9991943
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_supply 1056026650
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_type_5f 312202367
#define LBL_units 312791945
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_wrapper 1827365593
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_defs__facts__errors[] = {LBL_defs, LBL_facts, LBL_errors};
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_sigs__flat[] = {LBL_sigs, LBL_flat};
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
HeffT11 g_heff_2ecompile_2efacts_2efactsOf_24cpr(V);
HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eerasedPieces(V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_clo;
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V, V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo;
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(V, V);
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_clo;
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_clo;
HeffT3 g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2ejsDef(V, V);
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ejsDef_clo;
V g_heff_2ecompile_2elower_2epieceStep(V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2eredoErased(V, V, V, V);
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eredoErased_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V, V, V);
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo;
HeffT3 g_heff_2ecompile_2elower_2eshared_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitOut_clo;
HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2erefcount_2efunPlain(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunPlain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunPlain_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erepr_2easWord(V, V);
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erunes_2edefOf(V);
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2edefOf_clo;
V g_heff_2ecompile_2eshake_2eappendK(V, V);
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2eappendK_clo;
V g_heff_2ecompile_2eshake_2ereachBy(V, V, V);
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachBy_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2etested_2efixStmts(V, V);
V g_heff_2ecompile_2etested_2efixStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etested_2efixStmts_clo;
V g_heff_2ecompile_2etested_2enothingKnown_get(void);
V g_list_2eany_24s1266267134x726671983(V, V);
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a);
extern Clo g_list_2eany_24s1266267134x726671983_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1061624263x1097104198(V, V);
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061624263x1097104198_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1522661722x1369236455(V, V);
V g_list_2efoldl_24s1522661722x1369236455_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1522661722x1369236455_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s345718350x1678852400(V, V);
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s345718350x1678852400_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s598828199x820230131(V, V);
V g_list_2efoldl_24s598828199x820230131_entry(V self, V *a);
extern Clo g_list_2efoldl_24s598828199x820230131_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2elower_2ejsDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ejsDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2ejsDef(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_b0_242 = heff_field(v_x2_241, 0);
    V v_n_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_d_244 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), heff_dup(v_b0_242)});
    heff_drop_rec(v_d_244, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b0_242));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_243}));
    V v_x1_2422;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_t_249 = ({ V rv_2 = v_x_247; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_m_2410 = (g_heff_2ecompile_2erunes_2edefOf(v_t_249));
      V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_248}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_n_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        V v_t_2414 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        HeffT4 v_t_2415 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2414, v_x_2412, v_n_2413));
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          V v_field_2419 = v_t_2415.f[3];
          V v_x_2420 = heff_tag_n(TAG_MkDef, 3, (V[]){v_field_2416, v_field_2417, v_field_2418});
          V v_y_2421 = v_field_2419;
          heff_drop(v_y_2421);
          v_x1_2422 = v_x_2420;
        }
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_MkDef: {
      V v_key_2423 = heff_field(v_x1_2422, 0);
      V v_name_2424 = heff_field(v_x1_2422, 1);
      V v_b_2425 = heff_field(v_x1_2422, 2);
      V v_ru_24x1_2422_24MkDef = heff_take_reuse_n(v_x1_2422, 7ULL, 3);
      V v_t_2433;
      switch (heff_tag_of(v_b_2425)) {
      case TAG_DefFun: {
        V v_xs_2426 = heff_field(v_b_2425, 0);
        V v_x12_2427 = heff_field(v_b_2425, 1);
        heff_take_n(v_b_2425, 3ULL, 2);
        switch (heff_tag_of(v_x12_2427)) {
        case TAG_MkBlock: {
          V v_t_2428 = heff_field(v_x12_2427, 0);
          V v_ru_24x12_2427_24MkBlock = heff_take_reuse_n(v_x12_2427, 1ULL, 1);
          V v_t_2429 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_t_2428));
          v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_DefFun, 2, (V[]){v_xs_2426, heff_tag_at_n(v_ru_24x12_2427_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2429})});
          break;
        }
        default: heff_nomatch(v_x12_2427);
        }
        break;
      }
      case TAG_DefVal: {
        V v_x11_2430 = heff_field(v_b_2425, 0);
        V v_ru_24b_2425_24DefVal = heff_take_reuse_n(v_b_2425, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_MkBlock: {
          V v_t_2431 = heff_field(v_x11_2430, 0);
          V v_ru_24x11_2430_24MkBlock = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
          V v_t_2432 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_t_2431));
          v_t_2433 = heff_tag_at_n(v_ru_24b_2425_24DefVal, TAG_DefVal, 1, (V[]){heff_tag_at_n(v_ru_24x11_2430_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2432})});
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        break;
      }
      default: heff_nomatch(v_b_2425);
      }
      return heff_tag_at_n(v_ru_24x1_2422_24MkDef, TAG_MkDef, 3, (V[]){v_key_2423, v_name_2424, v_t_2433});
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ejsDef(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(V v_roots_240, V v_errors_241, V v_f_242) {
top: ;
  V v_supply_243 = heff_take_field(v_f_242, 1);
  V v_defs_244 = heff_get_n(v_f_242, 0, 2);
  V v_supply_245 = v_supply_243;
  V v_defs_246 = v_defs_244;
  V v_t_247 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_246));
  V v_reached_248 = ({ V a_0 = v_t_247; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_kept_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr_lam0, 1, 1, (V[]){v_reached_248}), v_defs_246));
  V v_errors_2415 = v_errors_241;
  HeffT3 v_t_2416 = (g_heff_2ecompile_2elower_2eshared_24cpr(v_roots_240, v_supply_245, v_kept_2414));
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2419 = v_t_2416.f[2];
    heff_drop(v_t_2416.f[1]);
    V v_ts_2420 = v_field_2419;
    HeffT11 v_t_2421 = (g_heff_2ecompile_2efacts_2efactsOf_24cpr(v_field_2417));
    V v_f_2433;
    {
      V v_field_2422 = v_t_2421.f[0];
      V v_field_2423 = v_t_2421.f[1];
      V v_field_2424 = v_t_2421.f[2];
      V v_field_2425 = v_t_2421.f[3];
      V v_field_2426 = v_t_2421.f[4];
      V v_field_2427 = v_t_2421.f[5];
      V v_field_2428 = v_t_2421.f[6];
      V v_field_2429 = v_t_2421.f[7];
      V v_field_2431 = v_t_2421.f[9];
      V v_field_2432 = v_t_2421.f[10];
      heff_drop(v_t_2421.f[8]);
      v_f_2433 = heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_field_2422, v_field_2423, v_field_2424, v_field_2425, v_field_2426, v_field_2427, v_field_2428, v_field_2429, v_ts_2420, v_field_2431, v_field_2432});
    }
    return ((HeffT3){{v_field_2417, v_f_2433, v_errors_2415}});
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_reached_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_reached_248; V b_1 = heff_get_n(v_d_249, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_248); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_entry, 3, 0};

V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(V v_roots_240, V v_errors_241, V v_f_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(v_roots_240, v_errors_241, v_f_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    return heff_rec_n(3, shape_defs__facts__errors, (V[]){v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry, 2, 0};

V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(V v_roots_240, V v_er_241) {
top: ;
  V v_supply_242 = heff_take_field(v_er_241, 2);
  V v_defs_243 = heff_take_field(v_er_241, 0);
  V v_errors_244 = heff_get_n(v_er_241, 1, 3);
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_243));
  V v_defs_246 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24s650566757x317183241(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_246));
  V v_reached_248 = ({ V a_0 = v_t_247; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_lam0, 1, 1, (V[]){v_reached_248}), v_defs_246));
  V v_si_2415 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(v_supply_242, v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_240), v_si_2415));
  return (g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(v_roots_240, v_errors_244, v_t_2416));
}
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_reached_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_reached_248; V b_1 = heff_get_n(v_d_249, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_248); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2elower_2ercOf_str0, 0, "");
V g_heff_2ecompile_2elower_2ercOf_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2ercOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2elower_2ercOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ercOf_entry, 2, 0};

V g_heff_2ecompile_2elower_2ercOf(V v_facts_240, V v_md_241) {
top: ;
  V v_facts_242 = heff_dup(v_facts_240);
  V v_arity_243 = heff_take_field(v_facts_242, 0);
  V v_bounce_244 = heff_take_field(v_facts_242, 1);
  V v_lent_245 = heff_take_field(v_facts_242, 3);
  V v_workers_246 = heff_take_field(v_facts_242, 4);
  V v_flat_247 = heff_take_field(v_facts_242, 5);
  V v_sure_248 = heff_take_field(v_facts_242, 6);
  V v_sureRecs_249 = heff_take_field(v_facts_242, 7);
  V v_tokens_2410 = heff_get_n(v_facts_242, 10, 11);
  V v_sg_2411 = heff_rec_n(2, shape_sigs__flat, (V[]){heff_take_field(v_facts_240, 4), heff_take_field(v_facts_240, 5)});
  V v_t_2415;
  switch (heff_tag_of(v_md_241)) {
  case TAG_MkDef: {
    V v_k_2412 = heff_dup(heff_field(v_md_241, 0));
    v_t_2415 = v_k_2412;
    break;
  }
  default: heff_nomatch(v_md_241);
  }
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_facts_240, 9, 11); V a_1 = v_t_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2415); r_; });
  V v_is_2420;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2418;
      v_is_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2418);
      v_is_2420 = NTAG(TAG_Nil);
    }
  }
  V v_d_2421 = heff_dup(v_md_241);
  V v_evs_2444;
  switch (heff_tag_of(v_is_2420)) {
  case TAG_Nil: {
    v_evs_2444 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_2411, v_d_2421));
    break;
  }
  case TAG_Cons: {
    V v_is_2424 = v_is_2420;
    V v_d_2425 = heff_dup(v_d_2421);
    V v_t_2441;
    switch (heff_tag_of(v_d_2425)) {
    case TAG_MkDef: {
      V v_d3_2428 = heff_field(v_d_2425, 2);
      heff_take_n(v_d_2425, 4ULL, 3);
      switch (heff_tag_of(v_d3_2428)) {
      case TAG_DefFun: {
        V v_xs_2429 = heff_field(v_d3_2428, 0);
        heff_take_n(v_d3_2428, 1ULL, 2);
        V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2429));
        V v_t_2432 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2431, MK_INT(1LL))));
        V v_t_2433 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_2429, v_t_2432));
        v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ercOf_lam0, 2, 1, (V[]){v_is_2424}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
        break;
      }
      case TAG_DefVal: {
        heff_take_n(v_d3_2428, 0ULL, 1);
        heff_drop(v_is_2424);
        v_t_2441 = heff_dup(g_std_2eordmap_2eempty_get());
        break;
      }
      default: heff_nomatch(v_d3_2428);
      }
      break;
    }
    default: heff_nomatch(v_d_2425);
    }
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2easWord_clo), 1, (V[]){v_t_2441}));
    V v_t_2443 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_2411, v_d_2421));
    v_evs_2444 = (g_list_2emap(v_t_2442, v_t_2443));
    break;
  }
  default: heff_nomatch(v_is_2420);
  }
  V v_pins_2445 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2444));
  V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2444));
  V v_evs_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2elower_2ercOf_lam1, 2, 1, (V[]){v_pins_2445}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
  V v_parent_2451 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2450));
  V v_t_2452 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2451, v_evs_2450));
  V v_reprs_2453 = ({ V a_0 = v_parent_2451; V a_1 = v_t_2452; V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V a_3 = v_evs_2450; V r_ = (g_list_2efoldl_24s1674844076x2137676876(a_0, a_1, a_2, a_3)); heff_drop(v_evs_2450); r_; });
  V v_x3_2454 = v_md_241;
  V v_d_2490;
  switch (heff_tag_of(v_x3_2454)) {
  case TAG_MkDef: {
    V v_key_2455 = heff_field(v_x3_2454, 0);
    V v_x33_2457 = heff_field(v_x3_2454, 2);
    V v_ru_24x3_2454_24MkDef = heff_take_reuse_n(v_x3_2454, 5ULL, 3);
    switch (heff_tag_of(v_x33_2457)) {
    case TAG_DefFun: {
      V v_xs_2458 = heff_field(v_x33_2457, 0);
      V v_x332_2459 = heff_field(v_x33_2457, 1);
      V v_ru_24x33_2457_24DefFun = heff_take_reuse_n(v_x33_2457, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_2454_24MkDef, 3);
      switch (heff_tag_of(v_x332_2459)) {
      case TAG_MkBlock: {
        V v_t_2460 = heff_field(v_x332_2459, 0);
        V v_ru_24x332_2459_24MkBlock = heff_take_reuse_n(v_x332_2459, 1ULL, 1);
        V v_ce_2461 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), v_reprs_2453, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        V v_key_2462 = v_key_2455;
        V v_xs_2463 = v_xs_2458;
        V v_b_2464 = v_t_2460;
        V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_ce_2461, 15)), 1, 2);
        HeffT2 v_t_2466 = ({ V a_0 = v_t_2465; V a_1 = v_key_2462; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2465); r_; });
        {
          V v_field_2468 = v_t_2466.f[1];
          int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
          if ((v_tag_2467 == ((int64_t)0ULL))) {
            V v_n_2469 = v_field_2468;
            switch (heff_tag_of(v_xs_2463)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24x33_2457_24DefFun, 2);
              heff_drop_cell(v_ru_24x332_2459_24MkBlock, 1);
              heff_drop(v_n_2469);
              v_d_2490 = (g_heff_2ecompile_2erefcount_2efunPlain(v_ce_2461, v_key_2462, NTAG(TAG_Nil), v_b_2464));
              break;
            }
            case TAG_Cons: {
              V v_tok_2470 = heff_field(v_xs_2463, 0);
              V v_xs_2471 = heff_field(v_xs_2463, 1);
              heff_take_n(v_xs_2463, 3ULL, 2);
              V v_t_2472 = (g_heff_2ecompile_2erefcount_2ewithKnown(heff_dup(v_tok_2470), heff_tag_at_n(v_ru_24x332_2459_24MkBlock, TAG_KnownCell, 1, (V[]){heff_dup(v_n_2469)}), v_ce_2461));
              HeffT2 v_t_2473 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_tok_2470), heff_rec_n(2, shape_n__tag, (V[]){v_n_2469, ((V)&g_heff_2ecompile_2elower_2ercOf_str0)}), v_b_2464));
              V v_t_2478;
              {
                V v_field_2474 = v_t_2473.f[0];
                V v_field_2475 = v_t_2473.f[1];
                V v_x_2476 = v_field_2474;
                heff_drop(v_x_2476);
                V v_y_2477 = v_field_2475;
                v_t_2478 = v_y_2477;
              }
              v_d_2490 = (g_heff_2ecompile_2erefcount_2efunPlain(v_t_2472, v_key_2462, heff_tag_at_n(v_ru_24x33_2457_24DefFun, TAG_Cons, 2, (V[]){v_tok_2470, v_xs_2471}), v_t_2478));
              break;
            }
            default: heff_nomatch(v_xs_2463);
            }
          } else {
            heff_drop_cell(v_ru_24x33_2457_24DefFun, 2);
            heff_drop_cell(v_ru_24x332_2459_24MkBlock, 1);
            heff_drop(v_field_2468);
            v_d_2490 = (g_heff_2ecompile_2erefcount_2efunPlain(v_ce_2461, v_key_2462, v_xs_2463, v_b_2464));
          }
        }
        break;
      }
      default: heff_nomatch(v_x332_2459);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x331_2479 = heff_field(v_x33_2457, 0);
      heff_take_n(v_x33_2457, 1ULL, 1);
      switch (heff_tag_of(v_x331_2479)) {
      case TAG_MkBlock: {
        V v_t_2480 = heff_field(v_x331_2479, 0);
        heff_take_n(v_x331_2479, 1ULL, 1);
        V v_ce_2481 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), v_reprs_2453, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        V v_key_2482 = v_key_2455;
        V v_t_2483 = v_t_2480;
        V v_t_2484 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2483, NTAG(TAG_Nil)));
        V v_t_2485 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2484));
        V v_t_2486 = ({ V a_0 = heff_dup(v_ce_2481); V a_1 = v_t_2485; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_2485); r_; });
        V v_t_2487 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), MK_INT(0LL), v_t_2486));
        V v_ce_2488 = (g_heff_2ecompile_2erefcount_2ewithPath(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2487));
        V v_t_2489 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_2488, v_t_2483));
        v_d_2490 = heff_tag_at_n(v_ru_24x3_2454_24MkDef, TAG_DVal, 3, (V[]){v_key_2482, v_t_2489, heff_get_n(v_ce_2481, 10, 17)});
        break;
      }
      default: heff_nomatch(v_x331_2479);
      }
      break;
    }
    default: heff_nomatch(v_x33_2457);
    }
    break;
  }
  default: heff_nomatch(v_x3_2454);
  }
  V v_x1_24100;
  switch (heff_tag_of(v_d_2490)) {
  case TAG_DFun: {
    V v_f_2491 = heff_field(v_d_2490, 0);
    V v_ru_24d_2490_24DFun = heff_take_reuse_n(v_d_2490, 1ULL, 1);
    V v_t_2492 = (g_list_2efoldl_24s598828199x820230131(NTAG(TAG_False), heff_rfield(v_f_2491, 4)));
    V v_t_2496;
    if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
      heff_drop(v_t_2492);
      V v_t_2493 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_2491, 1)));
      V v_t_2494 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2493, MK_INT(1LL))));
      V v_t_2495 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_f_2491, 1)), v_t_2494));
      v_t_2496 = (g_list_2efoldl_24s1061624263x1097104198(v_f_2491, v_t_2495));
    } else {
      heff_drop(v_t_2492);
      v_t_2496 = v_f_2491;
    }
    v_x1_24100 = heff_tag_at_n(v_ru_24d_2490_24DFun, TAG_DFun, 1, (V[]){v_t_2496});
    break;
  }
  case TAG_DVal: {
    v_x1_24100 = v_d_2490;
    break;
  }
  default: heff_nomatch(v_d_2490);
  }
  V v_d_24109;
  switch (heff_tag_of(v_x1_24100)) {
  case TAG_DFun: {
    V v_f_24101 = heff_field(v_x1_24100, 0);
    V v_ru_24x1_24100_24DFun = heff_take_reuse_n(v_x1_24100, 1ULL, 1);
    V v_t_24102 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), heff_take_field(v_f_24101, 3)));
    V v_t_24103 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), heff_take_field(v_f_24101, 4)));
    V v_t_24104 = ({ V rv_3 = v_t_24102; V rv_4 = v_t_24103; V rr_ = heff_rec_reuse_nf(v_f_24101, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    v_d_24109 = heff_tag_at_n(v_ru_24x1_24100_24DFun, TAG_DFun, 1, (V[]){v_t_24104});
    break;
  }
  case TAG_DVal: {
    V v_k_24105 = heff_field(v_x1_24100, 0);
    V v_ss_24106 = heff_field(v_x1_24100, 1);
    V v_rs_24107 = heff_field(v_x1_24100, 2);
    V v_ru_24x1_24100_24DVal = heff_take_reuse_n(v_x1_24100, 7ULL, 3);
    V v_t_24108 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), v_ss_24106));
    v_d_24109 = heff_tag_at_n(v_ru_24x1_24100_24DVal, TAG_DVal, 3, (V[]){v_k_24105, v_t_24108, v_rs_24107});
    break;
  }
  default: heff_nomatch(v_x1_24100);
  }
  V v_x1_24120;
  switch (heff_tag_of(v_d_24109)) {
  case TAG_DFun: {
    V v_f_24110 = heff_field(v_d_24109, 0);
    V v_ru_24d_24109_24DFun = heff_take_reuse_n(v_d_24109, 1ULL, 1);
    V v_ags_24111 = (g_list_2efoldl_24s2015232937x23400545(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_24110, 4))));
    V v_t_24116;
    switch (heff_tag_of(v_ags_24111)) {
    case TAG_Nil: {
      v_t_24116 = v_f_24110;
      break;
    }
    case TAG_Cons: {
      V v_t_24114 = (g_list_2efoldl_24s345718350x1678852400(NTAG(TAG_False), heff_rfield(v_f_24110, 4)));
      if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
        heff_drop_tag(v_ags_24111, 2);
        heff_drop(v_t_24114);
        v_t_24116 = v_f_24110;
      } else {
        heff_drop(v_t_24114);
        V v_t_24115 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_24110, 4))));
        v_t_24116 = (g_heff_2ecompile_2ebounds_2eboundsWith(v_f_24110, v_t_24115, v_ags_24111));
      }
      break;
    }
    default: heff_nomatch(v_ags_24111);
    }
    v_x1_24120 = heff_tag_at_n(v_ru_24d_24109_24DFun, TAG_DFun, 1, (V[]){v_t_24116});
    break;
  }
  case TAG_DVal: {
    v_x1_24120 = v_d_24109;
    break;
  }
  default: heff_nomatch(v_d_24109);
  }
  switch (heff_tag_of(v_x1_24120)) {
  case TAG_DFun: {
    V v_f_24121 = heff_field(v_x1_24120, 0);
    V v_ru_24x1_24120_24DFun = heff_take_reuse_n(v_x1_24120, 1ULL, 1);
    V v_t_24122 = (g_list_2emap_24s1478286876x830244177(heff_take_field(v_f_24121, 3)));
    V v_t_24123 = (g_list_2emap_24s1478286876x830244177(heff_take_field(v_f_24121, 4)));
    V v_t_24124 = ({ V rv_3 = v_t_24122; V rv_4 = v_t_24123; V rr_ = heff_rec_reuse_nf(v_f_24121, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_at_n(v_ru_24x1_24120_24DFun, TAG_DFun, 1, (V[]){v_t_24124});
  }
  case TAG_DVal: {
    V v_x_24125 = heff_field(v_x1_24120, 0);
    V v_ss_24126 = heff_field(v_x1_24120, 1);
    V v_rs_24127 = heff_field(v_x1_24120, 2);
    V v_ru_24x1_24120_24DVal = heff_take_reuse_n(v_x1_24120, 7ULL, 3);
    V v_t_24128 = (g_list_2emap_24s1478286876x830244177(v_ss_24126));
    return heff_tag_at_n(v_ru_24x1_24120_24DVal, TAG_DVal, 3, (V[]){v_x_24125, v_t_24128, v_rs_24127});
  }
  default: return heff_nomatch(v_x1_24120);
  }
}
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ercOf(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2ercOf_lam0(V self, V *args) {
  V v_m_2434 = args[0];
  V v_p_2435 = args[1];
  V v_is_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = ({ V a_0 = v_p_2435; V a_1 = v_is_2424; V r_ = (g_list_2eany_24s1266267134x726671983(a_0, a_1)); heff_drop(v_is_2424); r_; });
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    V v_t_2439;
    switch (heff_tag_of(v_p_2435)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_p_2435, 0);
      heff_take_n(v_p_2435, 1ULL, 2);
      v_t_2439 = v_x_2437;
      break;
    }
    default: heff_nomatch(v_p_2435);
    }
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2434, v_t_2439, NTAG(TAG_MkUnit)));
  } else {
    heff_drop(v_p_2435);
    heff_drop(v_t_2436);
    return v_m_2434;
  }
}
V g_heff_2ecompile_2elower_2ercOf_lam1(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_pins_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = v_pins_2445; V a_1 = v_x_2448; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2445); r_; });
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
Clo g_heff_2ecompile_2elower_2erevOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_entry, 2, 0};

V g_heff_2ecompile_2elower_2erevOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2erevOnto(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eerasedPieces_str0, 2, ": ");
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedPieces_entry, 3, 0};

V g_heff_2ecompile_2elower_2eerasedPieces(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_244 = heff_strAppend(heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2elower_2eerasedPieces_str0)), v_err_243);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_241, 1)});
    return ({ V rv_1 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_241, 5ULL, 3, shape_pieces__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Right: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_body_247 = heff_field(v_x31_246, 0);
      V v_n_248 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_247)}), v_body_247));
      V v_t_2414;
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_b_2412 = v_field_2410;
        V v_acc_2413 = v_field_2411;
        v_t_2414 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2413, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), v_b_2412})));
      }
      V v_t_2418 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_241, 0), heff_clo_n(g_heff_2ecompile_2elower_2eerasedPieces_lam0, 1, 1, (V[]){v_k_240}), v_t_2414));
      return ({ V rv_0 = v_t_2418; V rv_2 = v_n_248; V rr_ = heff_rec_reuse_nf(v_acc_241, 2ULL, 3, shape_pieces__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedPieces(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args) {
  V v_d_2415 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_2415, 2))));
  V v_t_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_240, heff_dup(heff_rfield(v_d_2415, 0)), heff_dup(heff_rfield(v_d_2415, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_d_2415}), v_t_2417});
}
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_str1, 0, "");
V g_heff_2ecompile_2elower_2epieceStep_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2epieceStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epieceStep_entry, 5, 0};

V g_heff_2ecompile_2elower_2epieceStep(V v_g_240, V v_vers_241, V v_ks_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_246, 3))));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop_rec(v_ks_242, 2);
      heff_drop(v_k_245);
      heff_drop_rec(v_e_246, 4);
      heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
      heff_drop(v_t_247);
      return v_acc_243;
    } else {
      heff_drop(v_t_247);
      HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_ks_242, 0, 2); V a_1 = v_k_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_it1_2411 = v_field_2410;
          switch (heff_tag_of(v_it1_2411)) {
          case TAG_MkPair: {
            V v_v_2412 = heff_field(v_it1_2411, 0);
            V v_us_2413 = heff_field(v_it1_2411, 1);
            heff_take_n(v_it1_2411, 3ULL, 2);
            V v_t_2427;
            if (heff_strEq_c_lent(v_v_2412, ((V)&g_heff_2ecompile_2elower_2epieceStep_str0), 2)) {
              heff_drop(v_v_2412);
              v_t_2427 = NTAG(TAG_False);
            } else {
              HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_241, v_k_245));
              V v_t_2430;
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x_2417 = v_field_2416;
                  v_t_2430 = v_x_2417;
                } else {
                  heff_drop(v_field_2416);
                  v_t_2430 = ((V)&g_heff_2ecompile_2elower_2epieceStep_str1);
                }
              }
              v_t_2427 = heff_strEq(v_v_2412, v_t_2430);
            }
            switch (heff_tag_of(v_t_2427)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
              V v_t_2423 = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(heff_take_field(v_acc_243, 0), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_lam0, 1, 3, (V[]){v_k_245, v_g_240, v_e_246}), v_us_2413));
              return ({ V rv_0 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_pieces__errors__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            }
            case TAG_False: {
              heff_drop(v_us_2413);
              V v_t_2424 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(heff_rfield(v_acc_243, 2))));
              return (g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_244_24MkPair, v_k_245, v_acc_243, v_t_2424));
            }
            default: return heff_nomatch(v_t_2427);
            }
          }
          default: return heff_nomatch(v_it1_2411);
          }
        } else {
          heff_drop(v_field_2410);
          V v_t_2425 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(heff_rfield(v_acc_243, 2))));
          return (g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_244_24MkPair, v_k_245, v_acc_243, v_t_2425));
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2epieceStep(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2epieceStep_lam1(V self, V *args) {
  V v_n_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_e_246 = heff_env(self)[2];
  V v_def_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(v_n_2421)));
  return ({ V a_0 = v_k_245; V b_1 = heff_get_n(v_def_2419, 0, 7); V a_2 = v_n_2421; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2elower_2eredoErased(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_t_2422); r_; });
}
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_e_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_def_2419 = heff_take_field(v_u_2418, 0);
  V v_refs_2420 = heff_get_n(v_u_2418, 1, 2);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(v_k_245), heff_dup(heff_rfield(v_def_2419, 0)), heff_dup(heff_rfield(v_def_2419, 1)), heff_tag_n(TAG_Kept, 2, (V[]){heff_dup(v_def_2419), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_lam1, 1, 4, (V[]){v_g_240, v_k_245, v_e_246, v_def_2419})}), v_refs_2420});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str1, 1, "-");
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eunitVers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitVers_entry, 2, 0};

V g_heff_2ecompile_2elower_2eunitVers(V v_vers_240, V v_ps_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2elower_2eunitVers_lam0, 2, 1, (V[]){heff_dup(v_vers_240)}), heff_dup(g_std_2eordmap_2eempty_get()), v_ps_241));
}
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitVers(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_owner_244 = heff_take_field(v_p_243, 0);
  V v_key_245 = heff_get_n(v_p_243, 1, 5);
  HeffT2 v_t_246 = ({ V a_0 = v_vers_240; V a_1 = v_owner_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_vers_240); heff_drop(v_owner_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_v_249 = v_field_248;
      if (heff_strEq_c_lent(v_v_249, ((V)&g_heff_2ecompile_2elower_2eunitVers_str0), 2)) {
        heff_drop(v_key_245);
        heff_drop(v_v_249);
        return v_m_242;
      } else {
        HeffT2 v_t_2410 = ({ V a_0 = v_v_249; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); HeffT2 r_ = (g_heff_2ecompile_2eirtext_2ebytesH_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_v_249); r_; });
        V v_t_2419;
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_a_2413 = v_field_2411;
          V v_b_2414 = v_field_2412;
          V v_x3_2415 = (g_heff_2ecompile_2eirtext_2ebytesH(v_key_245, MK_INT(0LL), v_a_2413, v_b_2414));
          switch (heff_tag_of(v_x3_2415)) {
          case TAG_MkPair: {
            V v_a_2416 = heff_field(v_x3_2415, 0);
            V v_b_2417 = heff_field(v_x3_2415, 1);
            heff_take_n(v_x3_2415, 3ULL, 2);
            V v_t_2418 = heff_strAppend(heff_intShow(v_a_2416), ((V)&g_heff_2ecompile_2elower_2eunitVers_str1));
            v_t_2419 = heff_strAppend(v_t_2418, heff_intShow(v_b_2417));
            break;
          }
          default: heff_nomatch(v_x3_2415);
          }
        }
        return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, v_key_245, v_t_2419));
      }
    } else {
      heff_drop(v_key_245);
      heff_drop(v_field_248);
      return v_m_242;
    }
  }
}
Clo g_heff_2ecompile_2elower_2eunitOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitOut_entry, 3, 0};

V g_heff_2ecompile_2elower_2eunitOut(V v_sg_240, V v_dm_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2elower_2eunitOut_24cpr(v_sg_240, v_dm_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitOut(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ereachedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ereachedPieces_entry, 1, 0};

V g_heff_2ecompile_2elower_2ereachedPieces(V v_ps_240) {
top: ;
  V v_refs_241 = (g_list_2efoldl_24s1522661722x1369236455(heff_dup(g_std_2eordmap_2eempty_get()), v_ps_240));
  HeffT2 v_t_242 = ({ V b_0 = heff_dup(g_std_2eordmap_2eempty_get()); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_r_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_refs_241);
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      v_r_2413 = heff_dup(g_std_2eordmap_2eempty_get());
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_MkUnit)));
      HeffT2 v_t_247 = ({ V a_0 = v_refs_241; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2411;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_t_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_t_2411 = NTAG(TAG_Nil);
        }
      }
      V v_t_2412 = (g_heff_2ecompile_2eshake_2eappendK(v_t_2411, NTAG(TAG_Nil)));
      v_r_2413 = ({ V a_0 = v_refs_241; V a_1 = v_t_246; V a_2 = v_t_2412; V r_ = (g_heff_2ecompile_2eshake_2ereachBy(a_0, a_1, a_2)); heff_drop(v_refs_241); r_; });
    }
    return (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2elower_2ereachedPieces_lam0, 1, 1, (V[]){v_r_2413}), v_ps_240));
  }
}
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ereachedPieces(a[0]);
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_r_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_r_2413; V b_1 = heff_get_n(v_p_2414, 1, 5); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_r_2413); heff_drop(b_1); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2416 == ((int64_t)0ULL)) && ({ V v_x_2418 = heff_dup(v_field_2417); int c_ = 1; heff_drop(v_x_2418); c_; })));
    heff_drop(v_field_2417);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry, 3, 0};

V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V v_acc_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_acc_240});
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_acc_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(a[0], a[1], a[2]);
}