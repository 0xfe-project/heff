// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_FtOther 63706
#define TAG_Kept 49931
#define TAG_Leaf 13717
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_NoCustody 24110
#define TAG_NoShape 40346
#define TAG_OfRecords 55355
#define TAG_OfTags 60669
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_Plus 9189
#define TAG_Reading 19214
#define TAG_Right 62770
#define TAG_Tip 31527
#define LBL_after 294093302
#define LBL_arity 294440695
#define LBL_b 316
#define LBL_bad 306815
#define LBL_bodies 563425515
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_byMember 2056687451
#define LBL_cells 295903083
#define LBL_consumers 1203455020
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_defs 9574869
#define LBL_entry 298026124
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_found 298980252
#define LBL_fresh 299054408
#define LBL_given 299725719
#define LBL_group 299987609
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_index 301704428
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_left 9813198
#define LBL_lent 9813446
#define LBL_made 9839068
#define LBL_members 1180739419
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_outer 307469461
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_pieces 958716528
#define LBL_producers 572620898
#define LBL_refs 9991943
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_sigs 10025609
#define LBL_simplified 1686448252
#define LBL_sums 10037327
#define LBL_supply 1056026650
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_tokens 1078955205
#define LBL_tracks 1081425843
#define LBL_tuples 1084651734
#define LBL_type_5f 312202367
#define LBL_units 312791945
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_works 314677148
#define LBL_wrapper 1827365593
#define LBL_xs 10594
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens, LBL_hashes};
static uint32_t shape_bad__given[] = {LBL_bad, LBL_given};
static uint32_t shape_bodies__after__supply[] = {LBL_bodies, LBL_after, LBL_supply};
static uint32_t shape_byMember__supply[] = {LBL_byMember, LBL_supply};
static uint32_t shape_defs__facts__errors__works[] = {LBL_defs, LBL_facts, LBL_errors, LBL_works};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_defs__supply__tuples[] = {LBL_defs, LBL_supply, LBL_tuples};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_sigs__flat[] = {LBL_sigs, LBL_flat};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
static uint32_t shape_tracks__sigs__lent__sums__fresh[] = {LBL_tracks, LBL_sigs, LBL_lent, LBL_sums, LBL_fresh};
static uint32_t shape_xs__b[] = {LBL_xs, LBL_b};
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2ebounds_2elabelled(V, V);
V g_heff_2ecompile_2ebounds_2elabelled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elabelled_clo;
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2erounds_24rec1_get(void);
V g_heff_2ecompile_2ecallarity_2esatGo(V, V);
V g_heff_2ecompile_2ecallarity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esatGo_clo;
V g_heff_2ecompile_2ecaptures_2ecapStmts(V, V);
V g_heff_2ecompile_2ecaptures_2ecapStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapStmts_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
V g_heff_2ecompile_2ecycles_2estartWalk_get(void);
V g_heff_2ecompile_2ecycles_2estrong(V, V, V);
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2estrong_clo;
V g_heff_2ecompile_2edefun_2edefOut(V, V);
V g_heff_2ecompile_2edefun_2edefOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2edefOut_clo;
V g_heff_2ecompile_2edefun_2eusesW(V, V, V);
V g_heff_2ecompile_2edefun_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eusesW_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
HeffT12 g_heff_2ecompile_2efacts_2efactsOf_24cpr(V);
V g_heff_2ecompile_2efacts_2ewithSureRecs(V, V);
V g_heff_2ecompile_2efacts_2ewithSureRecs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2ewithSureRecs_clo;
V g_heff_2ecompile_2efuel_2enumbered(V, V, V);
V g_heff_2ecompile_2efuel_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2enumbered_clo;
V g_heff_2ecompile_2efuse_2esites(V, V);
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esites_clo;
HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2elower_2ecKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecKept_clo;
HeffT3 g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(V, V, V, V);
V g_heff_2ecompile_2elower_2ecLowered(V, V, V, V, V);
V g_heff_2ecompile_2elower_2ecLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecLowered_clo;
V g_heff_2ecompile_2elower_2ecLowered_24rec0_get(void);
V g_heff_2ecompile_2elower_2eentryCps(V, V, V);
V g_heff_2ecompile_2elower_2eentryCps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryCps_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584(V, V, V, V, V);
V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_clo;
V g_heff_2ecompile_2elower_2eentryReading(V, V, V);
V g_heff_2ecompile_2elower_2eentryReading_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryReading_clo;
V g_heff_2ecompile_2elower_2eerasedPieces(V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_clo;
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2(V, V, V, V);
V g_heff_2ecompile_2elower_2eerasedPieces_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedPieces_24tok2_clo;
V g_heff_2ecompile_2elower_2eerasedWith(V, V, V);
V g_heff_2ecompile_2elower_2eerasedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_clo;
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
HeffT2 g_heff_2ecompile_2elower_2efusedOf_24cpr(V, V);
V g_heff_2ecompile_2elower_2efusedWith(V, V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_clo;
V g_heff_2ecompile_2elower_2ehandedOn(V, V);
V g_heff_2ecompile_2elower_2ehandedOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ehandedOn_clo;
V g_heff_2ecompile_2elower_2ejsDef(V, V);
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ejsDef_clo;
V g_heff_2ecompile_2elower_2eleafCount(V);
V g_heff_2ecompile_2elower_2eleafCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eleafCount_clo;
V g_heff_2ecompile_2elower_2epieceStep(V, V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_clo;
V g_heff_2ecompile_2elower_2eplusCount(V);
V g_heff_2ecompile_2elower_2eplusCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eplusCount_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2eredoErased(V, V, V, V);
V g_heff_2ecompile_2elower_2eredoErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eredoErased_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V, V, V);
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo;
V g_heff_2ecompile_2elower_2eshapeSaid(V);
V g_heff_2ecompile_2elower_2eshapeSaid_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshapeSaid_clo;
V g_heff_2ecompile_2elower_2eshared(V, V, V, V);
V g_heff_2ecompile_2elower_2eshared_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshared_clo;
V g_heff_2ecompile_2elower_2eshared_24rec0_get(void);
V g_heff_2ecompile_2elower_2eshared_24rec1_get(void);
V g_heff_2ecompile_2elower_2eshared_24rec2_get(void);
V g_heff_2ecompile_2elower_2esharedLowered(V, V);
V g_heff_2ecompile_2elower_2esharedLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2esharedLowered_clo;
HeffT4 g_heff_2ecompile_2elower_2esharedLowered_24cpr(V, V);
V g_heff_2ecompile_2elower_2eunitOut(V, V, V);
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitOut_clo;
HeffT2 g_heff_2ecompile_2elower_2eunitOut_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
V g_heff_2ecompile_2eonce_2einlined(V, V, V);
V g_heff_2ecompile_2eonce_2einlined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2einlined_clo;
V g_heff_2ecompile_2eonce_2eusesW(V, V, V);
V g_heff_2ecompile_2eonce_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eonce_2eusesW_clo;
V g_heff_2ecompile_2eowned_2eloops(V, V);
V g_heff_2ecompile_2eowned_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eloops_clo;
HeffT4 g_heff_2ecompile_2erefcount_2ercDef_24cpr(V, V, V);
V g_heff_2ecompile_2erepr_2easWord(V, V);
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erunes_2edefOf(V);
V g_heff_2ecompile_2erunes_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2edefOf_clo;
V g_heff_2ecompile_2eshake_2eappendK(V, V);
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2eappendK_clo;
V g_heff_2ecompile_2eshake_2ereachBy(V, V, V);
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachBy_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get(void);
V g_heff_2ecompile_2estatics_2estaticDef(V);
V g_heff_2ecompile_2estatics_2estaticDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2estaticDef_clo;
V g_heff_2ecompile_2etested_2efixStmts(V, V);
V g_heff_2ecompile_2etested_2efixStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etested_2efixStmts_clo;
V g_heff_2ecompile_2etested_2enothingKnown_get(void);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1266267134x726671983(V, V);
V g_list_2eany_24s1266267134x726671983_entry(V self, V *a);
extern Clo g_list_2eany_24s1266267134x726671983_clo;
HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1770886889x1685770680(V, V);
V g_list_2efoldl_24f1770886889x1685770680_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1770886889x1685770680_clo;
V g_list_2efoldl_24s1007625675x912768453(V, V, V);
V g_list_2efoldl_24s1007625675x912768453_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1007625675x912768453_clo;
V g_list_2efoldl_24s1061624263x1097104198(V, V);
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061624263x1097104198_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1164298390x2131771765(V, V);
V g_list_2efoldl_24s1164298390x2131771765_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1164298390x2131771765_clo;
V g_list_2efoldl_24s1165300915x1297435540(V, V);
V g_list_2efoldl_24s1165300915x1297435540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1165300915x1297435540_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1522661722x1369236455(V, V);
V g_list_2efoldl_24s1522661722x1369236455_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1522661722x1369236455_clo;
V g_list_2efoldl_24s1530765264x1072548396(V, V);
V g_list_2efoldl_24s1530765264x1072548396_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530765264x1072548396_clo;
V g_list_2efoldl_24s1585276774x1803507436(V, V, V, V, V);
V g_list_2efoldl_24s1585276774x1803507436_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1585276774x1803507436_clo;
V g_list_2efoldl_24s1603368658x2028032749(V, V, V);
V g_list_2efoldl_24s1603368658x2028032749_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1603368658x2028032749_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s1738438673x24732785(V, V);
V g_list_2efoldl_24s1738438673x24732785_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1738438673x24732785_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s1780126197x1319226274(V, V);
V g_list_2efoldl_24s1780126197x1319226274_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1780126197x1319226274_clo;
V g_list_2efoldl_24s1977498258x1405492921(V, V, V, V);
V g_list_2efoldl_24s1977498258x1405492921_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1977498258x1405492921_clo;
V g_list_2efoldl_24s2004150897x784001505(V, V);
V g_list_2efoldl_24s2004150897x784001505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2004150897x784001505_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s2098410461x866205771(V, V, V);
V g_list_2efoldl_24s2098410461x866205771_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2098410461x866205771_clo;
V g_list_2efoldl_24s2104458007x128868622(V, V);
V g_list_2efoldl_24s2104458007x128868622_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2104458007x128868622_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s2147120392x1124384541(V, V, V);
V g_list_2efoldl_24s2147120392x1124384541_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2147120392x1124384541_clo;
V g_list_2efoldl_24s243940296x1179168444(V, V);
V g_list_2efoldl_24s243940296x1179168444_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243940296x1179168444_clo;
V g_list_2efoldl_24s271650647x1598714891(V, V);
V g_list_2efoldl_24s271650647x1598714891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s271650647x1598714891_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s291344770x1790586136(V, V);
V g_list_2efoldl_24s291344770x1790586136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s291344770x1790586136_clo;
V g_list_2efoldl_24s327126808x177501924(V, V);
V g_list_2efoldl_24s327126808x177501924_entry(V self, V *a);
extern Clo g_list_2efoldl_24s327126808x177501924_clo;
V g_list_2efoldl_24s42602063x979600769(V, V);
V g_list_2efoldl_24s42602063x979600769_entry(V self, V *a);
extern Clo g_list_2efoldl_24s42602063x979600769_clo;
V g_list_2efoldl_24s441088199x272212076(V, V);
V g_list_2efoldl_24s441088199x272212076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s441088199x272212076_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s53729099x990735293(V, V);
V g_list_2efoldl_24s53729099x990735293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s53729099x990735293_clo;
V g_list_2efoldl_24s599926777x1799261815(V, V, V, V, V, V);
V g_list_2efoldl_24s599926777x1799261815_entry(V self, V *a);
extern Clo g_list_2efoldl_24s599926777x1799261815_clo;
V g_list_2efoldl_24s630841978x1026694071(V, V);
V g_list_2efoldl_24s630841978x1026694071_entry(V self, V *a);
extern Clo g_list_2efoldl_24s630841978x1026694071_clo;
V g_list_2efoldl_24s637780307x9274583(V, V);
V g_list_2efoldl_24s637780307x9274583_entry(V self, V *a);
extern Clo g_list_2efoldl_24s637780307x9274583_clo;
V g_list_2efoldl_24s644510009x1719377493(V, V);
V g_list_2efoldl_24s644510009x1719377493_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644510009x1719377493_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s757249601x485610223(V, V, V, V, V, V);
V g_list_2efoldl_24s757249601x485610223_entry(V self, V *a);
extern Clo g_list_2efoldl_24s757249601x485610223_clo;
V g_list_2efoldl_24s834720034x128429698(V, V);
V g_list_2efoldl_24s834720034x128429698_entry(V self, V *a);
extern Clo g_list_2efoldl_24s834720034x128429698_clo;
V g_list_2efoldl_24s88009013x1334911863(V, V);
V g_list_2efoldl_24s88009013x1334911863_entry(V self, V *a);
extern Clo g_list_2efoldl_24s88009013x1334911863_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1223034477x943356724(V);
V g_list_2ekeepIf_24s1223034477x943356724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1223034477x943356724_clo;
V g_list_2ekeepIf_24s1405544077x1281126723(V, V);
V g_list_2ekeepIf_24s1405544077x1281126723_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1405544077x1281126723_clo;
V g_list_2ekeepIf_24s1911725233x106069160(V, V, V, V);
V g_list_2ekeepIf_24s1911725233x106069160_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1911725233x106069160_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2ekeepIf_24s614579978x208602650(V, V);
V g_list_2ekeepIf_24s614579978x208602650_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s614579978x208602650_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s136093287x730789464(V, V, V, V);
V g_list_2emap_24s136093287x730789464_entry(V self, V *a);
extern Clo g_list_2emap_24s136093287x730789464_clo;
V g_list_2emap_24s136093287x730789464_24tok2(V, V, V, V, V);
V g_list_2emap_24s136093287x730789464_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s136093287x730789464_24tok2_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1460603830x671758883_24tok1(V, V, V);
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24tok1_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1915587473x866090925(V, V);
V g_list_2emap_24s1915587473x866090925_entry(V self, V *a);
extern Clo g_list_2emap_24s1915587473x866090925_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24s72189608x1424346484(V, V, V, V);
V g_list_2emap_24s72189608x1424346484_entry(V self, V *a);
extern Clo g_list_2emap_24s72189608x1424346484_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24cpr(V, V);
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
HeffT2 g_prelude_2etraverse_24s199930607x121965669_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s322261189x1827875354_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s514944727x707829312_24cpr(V, V);
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
HeffT2 g_prelude_2etraverse_24s993801089x502291790_24cpr(V, V);
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;

static V g_heff_2ecompile_2elower_2eshared_24rec1_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2eshared_24rec1_st;
static V g_heff_2ecompile_2elower_2eshared_24rec1_init(void) {
  return heff_rec_n(2, shape_bad__given, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2elower_2eshared_24rec1_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2eshared_24rec1_st)) return g_heff_2ecompile_2elower_2eshared_24rec1_val;
  return heff_global(&g_heff_2ecompile_2elower_2eshared_24rec1_val, &g_heff_2ecompile_2elower_2eshared_24rec1_st, g_heff_2ecompile_2elower_2eshared_24rec1_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_str2, 6, "Enter$");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_str3, 6, "Enter$");
HEFF_LIT(g_heff_2ecompile_2elower_2eshared_str4, 4, "$cpr");
V g_heff_2ecompile_2elower_2eshared_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam5(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam8(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam7(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam9(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam10(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam11(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam13(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam12(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam14(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam16(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam17(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam15(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam18(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam19(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam20(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam21(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam22(V self, V *args);
V g_heff_2ecompile_2elower_2eshared_lam23(V self, V *args);
Clo g_heff_2ecompile_2elower_2eshared_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eshared_entry, 4, 0};

V g_heff_2ecompile_2elower_2eshared(V v_fuel_240, V v_roots_241, V v_supply_242, V v_kept_243) {
top: ;
  V v_fuel_244 = v_fuel_240;
  V v_roots_245 = v_roots_241;
  V v_n_246 = v_supply_242;
  V v_defs_247 = v_kept_243;
  V v_bodies_248 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_247));
  V v_bodies_249 = heff_dup(v_bodies_248);
  V v_defs_2410 = heff_dup(v_defs_247);
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2410)));
  V v_m_2412 = (g_list_2efoldl_24s441088199x272212076(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2411));
  V v_t_2413 = ({ V a_0 = v_m_2412; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2412); r_; });
  V v_t_2414 = (g_list_2efoldl_24f1770886889x1685770680(NTAG(TAG_Nil), v_t_2413));
  V v_t_2466 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam0, 2, 1, (V[]){heff_dup(v_bodies_249)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2414; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2414); r_; });
  V v_gs_2467 = (g_list_2ekeepIf_24s614579978x208602650(v_bodies_249, v_t_2466));
  V v_c_2468 = (g_list_2efoldl_24s1603368658x2028032749(v_bodies_249, heff_dup(g_heff_2ecompile_2elower_2eshared_24rec0_get()), v_gs_2467));
  V v_t_2471;
  switch (heff_tag_of(v_gs_2467)) {
  case TAG_Nil: {
    heff_drop(v_defs_2410);
    v_t_2471 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_2471 = v_defs_2410;
    break;
  }
  default: heff_nomatch(v_gs_2467);
  }
  V v_u_2477 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam9, 2, 1, (V[]){v_c_2468}); V a_1 = heff_dup(g_heff_2ecompile_2elower_2eshared_24rec1_get()); V a_2 = v_t_2471; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2471); r_; });
  V v_bad_2478 = heff_take_field(v_u_2477, 0);
  V v_given_2479 = heff_get_n(v_u_2477, 1, 2);
  V v_t_2480 = ({ V a_0 = v_bodies_249; V a_1 = v_bad_2478; V a_2 = v_given_2479; V a_3 = v_gs_2467; V r_ = (g_list_2emap_24s72189608x1424346484(a_0, a_1, a_2, a_3)); heff_drop(v_bodies_249); heff_drop(v_bad_2478); heff_drop(v_given_2479); r_; });
  V v_gs_2481 = (g_list_2ekeepIf_24s1405544077x1281126723(MK_INT(0LL), v_t_2480));
  V v_x1_2493;
  switch (heff_tag_of(v_gs_2481)) {
  case TAG_Nil: {
    heff_drop(v_bodies_248);
    v_x1_2493 = heff_tag_n(TAG_MkPair, 2, (V[]){v_defs_247, v_n_246});
    break;
  }
  case TAG_Cons: {
    V v_d_2484 = (g_list_2efoldl_24s1780126197x1319226274(heff_rec_n(3, shape_bodies__after__supply, (V[]){v_bodies_248, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_n_246)}), v_gs_2481));
    V v_t_2485 = (g_std_2eordmap_2esize(heff_rfield(v_d_2484, 1)));
    if (heff_intEq_c(v_t_2485, MK_INT(0LL))) {
      heff_drop_rec(v_d_2484, 3);
      v_x1_2493 = heff_tag_n(TAG_MkPair, 2, (V[]){v_defs_247, v_n_246});
    } else {
      heff_drop(v_n_246);
      V v_f_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2edefOut_clo), 1, (V[]){heff_dup(v_d_2484)}));
      V v_xs_2487 = v_defs_247;
      V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2487));
      V v_t_2492 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam10, 2, 1, (V[]){v_f_2486}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2488; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2488); r_; });
      v_x1_2493 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2492, heff_get_n(v_d_2484, 2, 3)});
    }
    break;
  }
  default: heff_nomatch(v_gs_2481);
  }
  V v_c_2496;
  switch (heff_tag_of(v_x1_2493)) {
  case TAG_MkPair: {
    V v_defs_2494 = heff_field(v_x1_2493, 0);
    V v_n_2495 = heff_field(v_x1_2493, 1);
    heff_take_n(v_x1_2493, 3ULL, 2);
    v_c_2496 = heff_tr(g_heff_2ecompile_2ecallarity_2erounds(MK_INT(3LL), heff_dup(g_heff_2ecompile_2ecallarity_2erounds_24rec1_get()), v_defs_2494, v_n_2495));
    break;
  }
  default: heff_nomatch(v_x1_2493);
  }
  V v_ar_2497 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_c_2496, 0)));
  V v_c_2498 = v_c_2496;
  V v_supply_2499 = heff_take_field(v_c_2498, 1);
  V v_defs_24100 = heff_take_field(v_c_2498, 0);
  V v_supply_24101 = v_supply_2499;
  V v_defs_24104 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam11, 1, 1, (V[]){v_ar_2497}), v_defs_24100));
  HeffT2 v_t_24105 = (g_prelude_2etraverse_24s514944727x707829312_24cpr(v_defs_24104, v_supply_24101));
  {
    V v_field_24106 = v_t_24105.f[0];
    V v_field_24107 = v_t_24105.f[1];
    V v_defs_24108 = v_field_24106;
    V v_n_24109 = v_field_24107;
    HeffT2 v_t_24110 = (g_prelude_2etraverse_24s1882351740x242225671_24cpr(v_defs_24108, v_n_24109));
    V v_t_24117;
    {
      V v_field_24111 = v_t_24110.f[0];
      V v_field_24112 = v_t_24110.f[1];
      V v_dss_24113 = v_field_24111;
      V v_n_24114 = v_field_24112;
      V v_t_24115 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24113));
      V v_t_24116 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24115; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24115); r_; });
      v_t_24117 = ({ V rv_0 = v_t_24116; V rv_1 = v_n_24114; V rr_ = heff_rec_reuse_nf(v_c_2498, 0ULL, 2, shape_defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    V v_supply_24118 = heff_take_field(v_t_24117, 1);
    V v_defs_24119 = heff_take_field(v_t_24117, 0);
    V v_n_24120 = v_supply_24118;
    V v_defs_24121 = v_defs_24119;
    V v_funs_24122 = (g_list_2efoldl_24s291344770x1790586136(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24121));
    V v_t_24123 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24121));
    V v_x1_24124 = (g_list_2efoldl_24s1007625675x912768453(MK_INT(1LL), heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get())}), heff_dup(v_defs_24121)));
    V v_t_24127;
    switch (heff_tag_of(v_x1_24124)) {
    case TAG_MkPair: {
      V v_y_24126 = heff_field(v_x1_24124, 1);
      heff_take_n(v_x1_24124, 2ULL, 2);
      v_t_24127 = v_y_24126;
      break;
    }
    default: heff_nomatch(v_x1_24124);
    }
    V v_funs_24128 = v_funs_24122;
    V v_defs_24129 = heff_dup(v_defs_24121);
    V v_calls_24188 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam12, 2, 1, (V[]){v_funs_24128}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_24129; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_24129); r_; });
    V v_defs_24189 = heff_dup(v_defs_24121);
    V v_w_24200 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam14, 2, 1, (V[]){v_calls_24188}); V a_1 = heff_dup(g_heff_2ecompile_2ecycles_2estartWalk_get()); V a_2 = v_defs_24189; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_24189); r_; });
    V v_t_24201 = (g_list_2ekeepIf_24s1911725233x106069160(MK_INT(1LL), MK_INT(0LL), MK_INT(2LL), heff_get_n(v_w_24200, 5, 6)));
    V v_cs_24202 = ({ V a_0 = v_t_24123; V a_1 = v_t_24127; V a_2 = heff_rec_n(2, shape_byMember__supply, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_n_24120)}); V a_3 = v_t_24201; V r_ = (g_list_2efoldl_24s1977498258x1405492921(a_0, a_1, a_2, a_3)); heff_drop(v_t_24123); heff_drop(v_t_24127); heff_drop(v_t_24201); r_; });
    V v_t_24203 = (g_std_2eordmap_2esize(heff_rfield(v_cs_24202, 0)));
    V v_x1_24259;
    if (heff_intEq_c(v_t_24203, MK_INT(0LL))) {
      heff_drop_rec(v_cs_24202, 2);
      v_x1_24259 = heff_tag_n(TAG_MkPair, 2, (V[]){v_defs_24121, v_n_24120});
    } else {
      heff_drop(v_n_24120);
      V v_defs_24204 = v_defs_24121;
      V v_cs_24205 = v_cs_24202;
      V v_byMember_24206 = heff_take_field(v_cs_24205, 0);
      V v_supply_24207 = heff_get_n(v_cs_24205, 1, 2);
      V v_xs_24257 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam15, 2, 1, (V[]){v_byMember_24206}); V a_1 = NTAG(TAG_Nil); V a_2 = v_defs_24204; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_24204); r_; });
      V v_t_24258 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24257));
      v_x1_24259 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24258, v_supply_24207});
    }
    V v_t_24262;
    switch (heff_tag_of(v_x1_24259)) {
    case TAG_MkPair: {
      V v_defs_24260 = heff_field(v_x1_24259, 0);
      V v_n_24261 = heff_field(v_x1_24259, 1);
      heff_take_n(v_x1_24259, 3ULL, 2);
      v_t_24262 = ({ V rv_0 = v_defs_24260; V rv_1 = v_n_24261; V rr_ = heff_rec_reuse_nf(v_t_24117, 0ULL, 2, shape_defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      break;
    }
    default: heff_nomatch(v_x1_24259);
    }
    V v_supply_24263 = heff_take_field(v_t_24262, 1);
    V v_defs_24264 = heff_take_field(v_t_24262, 0);
    V v_supply_24265 = v_supply_24263;
    HeffT2 v_t_24266 = (g_prelude_2etraverse_24s1442653311x1678194035_24cpr(v_defs_24264, v_supply_24265));
    {
      V v_field_24267 = v_t_24266.f[0];
      V v_field_24268 = v_t_24266.f[1];
      V v_fs_24269 = v_field_24267;
      V v_n_24270 = v_field_24268;
      HeffT2 v_t_24271 = (g_prelude_2etraverse_24s379292819x1163591097_24cpr(v_fs_24269, v_n_24270));
      V v_t_24278;
      {
        V v_field_24272 = v_t_24271.f[0];
        V v_field_24273 = v_t_24271.f[1];
        V v_dss_24274 = v_field_24272;
        V v_n_24275 = v_field_24273;
        V v_t_24276 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24274));
        V v_ds_24277 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24276; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24276); r_; });
        v_t_24278 = ({ V rv_0 = v_ds_24277; V rv_1 = v_n_24275; V rr_ = heff_rec_reuse_nf(v_t_24262, 0ULL, 2, shape_defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      V v_supply_24279 = heff_take_field(v_t_24278, 1);
      V v_defs_24280 = heff_take_field(v_t_24278, 0);
      V v_supply_24281 = v_supply_24279;
      HeffT2 v_t_24282 = (g_prelude_2etraverse_24s322261189x1827875354_24cpr(v_defs_24280, v_supply_24281));
      {
        V v_field_24283 = v_t_24282.f[0];
        V v_field_24284 = v_t_24282.f[1];
        V v_fs_24285 = v_field_24283;
        V v_n_24286 = v_field_24284;
        V v_kind_24287 = NTAG(TAG_OfTags);
        V v_fs_24288 = heff_dup(v_fs_24285);
        HeffT2 v_t_24289 = (g_prelude_2etraverse_24s993801089x502291790_24cpr(v_fs_24285, v_n_24286));
        V v_x1_24299;
        {
          V v_field_24290 = v_t_24289.f[0];
          V v_field_24291 = v_t_24289.f[1];
          V v_dss_24292 = v_field_24290;
          V v_n_24293 = v_field_24291;
          V v_t_24294 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24292));
          V v_ds_24295 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24294; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24294); r_; });
          V v_t_24298;
          switch (heff_tag_of(v_kind_24287)) {
          case TAG_OfRecords: {
            heff_drop(v_fs_24288);
            v_t_24298 = v_ds_24295;
            break;
          }
          case TAG_OfTags: {
            V v_m_24296 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_fs_24288; V r_ = (g_list_2efoldl_24s53729099x990735293(a_0, a_1)); heff_drop(v_fs_24288); r_; });
            V v_t_24297 = (g_std_2eordmap_2esize(v_m_24296));
            if (heff_intEq_c(v_t_24297, MK_INT(0LL))) {
              heff_drop(v_m_24296);
              v_t_24298 = v_ds_24295;
            } else {
              v_t_24298 = (g_list_2emap_24s1915587473x866090925(v_m_24296, v_ds_24295));
            }
            break;
          }
          default: heff_nomatch(v_kind_24287);
          }
          v_x1_24299 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24298, v_n_24293});
        }
        V v_t_24302;
        switch (heff_tag_of(v_x1_24299)) {
        case TAG_MkPair: {
          V v_defs_24300 = heff_field(v_x1_24299, 0);
          V v_n_24301 = heff_field(v_x1_24299, 1);
          heff_take_n(v_x1_24299, 3ULL, 2);
          v_t_24302 = ({ V rv_0 = v_defs_24300; V rv_1 = v_n_24301; V rr_ = heff_rec_reuse_nf(v_t_24278, 0ULL, 2, shape_defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_x1_24299);
        }
        V v_supply_24303 = heff_take_field(v_t_24302, 1);
        V v_defs_24304 = heff_get_n(v_t_24302, 0, 2);
        V v_x1_24305 = v_fuel_244;
        V v_roots_24306 = v_roots_245;
        V v_supply_24307 = v_supply_24303;
        V v_defs_24308 = v_defs_24304;
        V v_supply_24309 = v_supply_24307;
        V v_defs_24310 = heff_dup(v_defs_24308);
        V v_defs_24311 = heff_dup(v_defs_24308);
        V v_m_24312 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_defs_24308; V r_ = (g_list_2efoldl_24s327126808x177501924(a_0, a_1)); heff_drop(v_defs_24308); r_; });
        V v_t_24313 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m_24312));
        V v_m_24314 = (g_heff_2ecompile_2ecpr_2ekeptGo(v_m_24312, v_t_24313));
        V v_t_24315 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_m_24314, NTAG(TAG_Nil)));
        V v_parent_24316 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24315; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_24315); r_; });
        V v_t_24317 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_m_24314, NTAG(TAG_Nil)));
        V v_parent_24318 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24317; V r_ = (g_list_2efoldl_24s271650647x1598714891(a_0, a_1)); heff_drop(v_t_24317); r_; });
        V v_m_24319 = heff_dup(v_m_24314);
        V v_t_24320 = ({ V a_0 = v_m_24319; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_24319); r_; });
        V v_shapes_24337 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam18, 2, 1, (V[]){v_parent_24318}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24320; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24320); r_; });
        V v_t_24338 = ({ V a_0 = v_shapes_24337; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_shapes_24337); r_; });
        V v_ls_24339 = (g_list_2efoldl_24s1165300915x1297435540(heff_dup(g_std_2eordmap_2eempty_get()), v_t_24338));
        V v_m_24340 = v_m_24314;
        V v_t_24341 = ({ V a_0 = v_m_24340; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_24340); r_; });
        V v_k_24356 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam19, 2, 2, (V[]){v_parent_24316, v_ls_24339}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_24341; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24341); r_; });
        V v_t_24357 = (g_list_2emap_24s45270243x110012769(v_defs_24311));
        V v_t_24358 = (g_heff_2ecompile_2ecpr_2esitesW(v_k_24356, NTAG(TAG_Nil), v_t_24357));
        V v_groups_24359 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_24358; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_t_24358); r_; });
        V v_t_24360 = ({ V a_0 = v_k_24356; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_k_24356); r_; });
        V v_ps_24369 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam20, 1, 1, (V[]){v_groups_24359}); V a_1 = v_t_24360; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        V v_k_24370 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24369; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24369); r_; });
        V v_t_24371 = (g_std_2eordmap_2esize(v_k_24370));
        V v_c_24383;
        if (heff_intEq_c(v_t_24371, MK_INT(0LL))) {
          heff_drop(v_k_24370);
          v_c_24383 = heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_defs_24310, v_supply_24309, heff_dup(g_std_2eordmap_2eempty_get())});
        } else {
          V v_t_24374 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam21, 1, 1, (V[]){heff_dup(v_k_24370)}), v_defs_24310));
          V v_t_24375 = heff_tr(heff_call(v_t_24374, 1, (V[]){v_supply_24309}));
          switch (heff_tag_of(v_t_24375)) {
          case TAG_MkPair: {
            V v_dss_24376 = heff_field(v_t_24375, 0);
            V v_n_24377 = heff_field(v_t_24375, 1);
            heff_take_n(v_t_24375, 3ULL, 2);
            V v_t_24378 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_24376));
            V v_t_24379 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24378; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24378); r_; });
            V v_t_24380 = ({ V a_0 = v_k_24370; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_k_24370); r_; });
            V v_ps_24381 = (g_list_2emap_24s273193875x235978955(((V)&g_heff_2ecompile_2elower_2eshared_str4), MK_INT(1LL), MK_INT(0LL), v_t_24380));
            V v_t_24382 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24381; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24381); r_; });
            v_c_24383 = heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_t_24379, v_n_24377, v_t_24382});
            break;
          }
          default: heff_nomatch(v_t_24375);
          }
        }
        V v_t_24384 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(g_heff_2ecompile_2elower_2eshared_24rec2_get())});
        V v_t_24385 = (g_list_2efoldl_24s834720034x128429698(v_t_24384, heff_take_field(v_c_24383, 0)));
        V v_t_24390;
        switch (heff_tag_of(v_t_24385)) {
        case TAG_MkPair: {
          V v_acc_24386 = heff_field(v_t_24385, 0);
          heff_take_n(v_t_24385, 1ULL, 2);
          V v_xs_24388 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_24386));
          V v_t_24389 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24388));
          v_t_24390 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24389; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24389); r_; });
          break;
        }
        default: heff_nomatch(v_t_24385);
        }
        V v_c_24391 = ({ V rv_0 = v_t_24390; V rr_ = heff_rec_reuse_nf(v_c_24383, 6ULL, 3, shape_defs__supply__tuples, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_defs_24392 = heff_take_field(v_c_24391, 0);
        V v_t_24393 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24392));
        V v_reached_24394 = ({ V a_0 = v_t_24393; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_roots_24306; V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_24393); r_; });
        V v_t_24400 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam22, 1, 1, (V[]){v_reached_24394}); V a_1 = v_defs_24392; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        V v_c_24401 = ({ V rv_0 = v_t_24400; V rr_ = heff_rec_reuse_nf(v_c_24391, 6ULL, 3, shape_defs__supply__tuples, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        if ((heff_dup(v_x1_24305) == NTAG(TAG_True))) {
          heff_drop(v_x1_24305);
          V v_defs_24402 = heff_take_field(v_c_24401, 0);
          V v_refs_24403 = (g_list_2efoldl_24s1164298390x2131771765(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_24402));
          V v_defs_24404 = heff_dup(v_defs_24402);
          V v_w_24411 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam23, 2, 1, (V[]){v_refs_24403}); V a_1 = heff_dup(g_heff_2ecompile_2ecycles_2estartWalk_get()); V a_2 = v_defs_24404; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_24404); r_; });
          V v_t_24412 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_w_24411, 5, 6); V r_ = (g_heff_2ecompile_2efuel_2enumbered(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          HeffT2 v_t_24413 = (g_prelude_2etraverse_24s199930607x121965669_24cpr(v_t_24412, v_defs_24402, heff_take_field(v_c_24401, 1)));
          {
            V v_field_24414 = v_t_24413.f[0];
            V v_field_24415 = v_t_24413.f[1];
            V v_defs_24416 = v_field_24414;
            V v_n_24417 = v_field_24415;
            return ({ V rv_0 = v_defs_24416; V rv_1 = v_n_24417; V rr_ = heff_rec_reuse_nf(v_c_24401, 4ULL, 3, shape_defs__supply__tuples, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
        } else {
          heff_drop(v_x1_24305);
          return v_c_24401;
        }
      }
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eshared(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2eshared_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_set_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2431 = ({ V a_0 = v_set_2419; V a_1 = v_x_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_set_2419); heff_drop(v_x_2430); r_; });
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2432 == ((int64_t)0ULL)) && ({ V v_x_2434 = heff_dup(v_field_2433); int c_ = 1; heff_drop(v_x_2434); c_; })));
    heff_drop(v_field_2433);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_b_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2442 = ({ V a_0 = v_b_2438; V a_1 = v_x_2441; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_b_2438); heff_drop(v_x_2441); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2443 == ((int64_t)0ULL)) && ({ V v_x_2445 = heff_dup(v_field_2444); int c_ = 1; heff_drop(v_x_2445); c_; })));
    heff_drop(v_field_2444);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam3(V self, V *args) {
  V v_b_2438 = args[0];
  V v_n_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = ({ V a_0 = v_n_2437; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_n_2437); r_; });
  V v_t_2440 = (g_list_2emap_24s1415906091x1371825187(v_t_2439));
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam4, 1, 1, (V[]){v_b_2438}); V a_1 = v_t_2440; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2440); r_; });
}
V g_heff_2ecompile_2elower_2eshared_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_c_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2452 = ({ V a_0 = v_c_2448; V a_1 = v_x_2451; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_c_2448); heff_drop(v_x_2451); r_; });
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2453 == ((int64_t)0ULL)) && ({ V v_x_2455 = heff_dup(v_field_2454); int c_ = 1; heff_drop(v_x_2455); c_; })));
    heff_drop(v_field_2454);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam5(V self, V *args) {
  V v_c_2448 = args[0];
  V v_n_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = v_n_2437; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_n_2437); r_; });
  V v_t_2450 = (g_list_2emap_24s1415906091x1371825187(v_t_2449));
  V v_x1_2456 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam6, 1, 1, (V[]){v_c_2448}); V a_1 = v_t_2450; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2450); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2456) == NTAG(TAG_True)));
  heff_drop(v_x1_2456);
  return v_ret_24bool;
}
V g_heff_2ecompile_2elower_2eshared_lam1(V self, V *args) {
  V v_cs_2420 = args[0];
  V v_k_2421 = args[1];
  V v_bodies_2417 = heff_env(self)[0];
  V v_set_2419 = heff_env(self)[1];
  V v_cs_2422 = v_cs_2420;
  heff_clo_take(self, 2);
  HeffT2 v_t_2423 = ({ V a_0 = v_bodies_2417; V a_1 = v_k_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_2417); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    V v_t_2427;
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2425;
      v_t_2427 = v_x_2426;
    } else {
      heff_drop(v_field_2425);
      v_t_2427 = NTAG(TAG_EAbandon);
    }
    V v_t_2428 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_2427));
    V v_t_2429 = (g_heff_2ecompile_2eir_2enubI(v_t_2428));
    V v_t_2435 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam2, 1, 1, (V[]){v_set_2419}); V a_1 = v_t_2429; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_xs_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_2421, v_t_2435});
    V v_n_2437 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2436; V r_ = (g_list_2efoldl_24s278088687x1269971185(a_0, a_1)); heff_drop_tag(v_xs_2436, 2); r_; });
    V v_t_2446 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam3, 1, 1, (V[]){heff_dup(v_n_2437)}); V a_1 = heff_dup(v_cs_2422); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2447 = ({ V a_0 = heff_dup(v_n_2437); V a_1 = v_t_2446; V r_ = (g_list_2efoldl_24s2104458007x128868622(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_t_2457 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam5, 1, 1, (V[]){v_n_2437}); V a_1 = v_cs_2422; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2457});
  }
}
V g_heff_2ecompile_2elower_2eshared_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_c_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2461 = ({ V a_0 = v_c_2459; V a_1 = v_x_2460; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_c_2459); heff_drop(v_x_2460); r_; });
  {
    V v_field_2463 = v_t_2461.f[1];
    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2462 == ((int64_t)0ULL)) && ({ V v_x_2464 = heff_dup(v_field_2463); int c_ = 1; heff_drop(v_x_2464); c_; })));
    heff_drop(v_field_2463);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam7(V self, V *args) {
  V v_c_2459 = args[0];
  V v_ks_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam8, 1, 1, (V[]){v_c_2459}); V a_1 = v_ks_2418; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2ecompile_2elower_2eshared_lam0(V self, V *args) {
  V v_acc_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bodies_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bodies_2417 = v_bodies_249;
  V v_ks_2418 = v_x_2416;
  V v_set_2419 = (g_list_2efoldl_24s278088687x1269971185(heff_dup(g_std_2eordmap_2eempty_get()), v_ks_2418));
  V v_t_2458 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam1, 2, 2, (V[]){v_bodies_2417, v_set_2419}); V a_1 = NTAG(TAG_Nil); V a_2 = v_ks_2418; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam7, 1, 1, (V[]){v_ks_2418}), v_t_2458));
  return (g_prelude_2e_2b_2b(v_t_2465, v_acc_2415));
}
V g_heff_2ecompile_2elower_2eshared_lam9(V self, V *args) {
  V v_u_2472 = args[0];
  V v_d_2473 = args[1];
  V v_c_2468 = heff_env(self)[0];
  V v_key_2474 = heff_take_field(v_d_2473, 0);
  V v_body_2475 = heff_get_n(v_d_2473, 2, 3);
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_body_2475, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_2468; V a_1 = v_key_2474; V a_2 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2476, v_u_2472}); V r_ = (g_heff_2ecompile_2edefun_2eusesW(a_0, a_1, a_2)); heff_drop(v_c_2468); heff_drop(v_key_2474); r_; });
}
V g_heff_2ecompile_2elower_2eshared_lam10(V self, V *args) {
  V v_acc_2489 = args[0];
  V v_x_2490 = args[1];
  V v_f_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_tr(heff_call(v_f_2486, 1, (V[]){v_x_2490}));
  return (g_prelude_2e_2b_2b(v_t_2491, v_acc_2489));
}
V g_heff_2ecompile_2elower_2eshared_lam11(V self, V *args) {
  V v_d_24102 = args[0];
  V v_ar_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24103 = (g_heff_2ecompile_2ecallarity_2esatGo(v_ar_2497, heff_take_field(v_d_24102, 2)));
  return ({ V rv_2 = v_t_24103; V rr_ = heff_rec_reuse_nf(v_d_24102, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2eshared_lam13(V self, V *args) {
  V v_g_24182 = args[0];
  V v_funs_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24183 = ({ V a_0 = v_funs_24128; V a_1 = v_g_24182; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_funs_24128); heff_drop(v_g_24182); r_; });
  {
    V v_field_24185 = v_t_24183.f[1];
    int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24184 == ((int64_t)0ULL)) && ({ V v_x_24186 = heff_dup(v_field_24185); int c_ = 1; heff_drop(v_x_24186); c_; })));
    heff_drop(v_field_24185);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam12(V self, V *args) {
  V v_m_24130 = args[0];
  V v_d_24131 = args[1];
  V v_funs_24128 = heff_env(self)[0];
  V v_key_24132 = heff_take_field(v_d_24131, 0);
  V v_body_24133 = heff_get_n(v_d_24131, 2, 3);
  HeffT2 v_t_24134 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_funs_24128, v_key_24132));
  {
    V v_field_24136 = v_t_24134.f[1];
    int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
    if ((v_tag_24135 == ((int64_t)0ULL))) {
      V v_x_24137 = v_field_24136;
      heff_drop(v_x_24137);
      V v_e_24138 = v_body_24133;
      V v_t_24178;
      switch (heff_tag_of(v_e_24138)) {
      case TAG_EVar: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EGlobal: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ELam: {
        V v_b_24142 = heff_field(v_e_24138, 1);
        heff_take_n(v_e_24138, 2ULL, 2);
        v_t_24178 = v_b_24142;
        break;
      }
      case TAG_EApp: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ELet: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ERecord: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EProj: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ETag: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EMatch: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EPrim: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EPrimCall: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ECall: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EInt: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EFloat: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EStr: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EBytes: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EFixed: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EFloat32: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EAbandon: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EBool: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_ESet: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EValues: {
        v_t_24178 = v_e_24138;
        break;
      }
      case TAG_EFix: {
        v_t_24178 = v_e_24138;
        break;
      }
      default: heff_nomatch(v_e_24138);
      }
      V v_xs_24179 = ({ V a_0 = v_t_24178; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2ewaysOnto(a_0, a_1)); heff_drop(v_t_24178); r_; });
      V v_t_24180 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24179));
      V v_t_24181 = (g_list_2efoldl_24s630841978x1026694071(NTAG(TAG_Nil), v_t_24180));
      heff_clo_take(self, 1);
      V v_t_24187 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam13, 1, 1, (V[]){v_funs_24128}); V a_1 = v_t_24181; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_m_24130; V a_1 = v_key_24132; V a_2 = v_t_24187; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_24132); heff_drop(v_t_24187); r_; });
    } else {
      heff_drop(self);
      heff_drop(v_key_24132);
      heff_drop(v_body_24133);
      heff_drop(v_field_24136);
      return v_m_24130;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_lam14(V self, V *args) {
  V v_w_24190 = args[0];
  V v_d_24191 = args[1];
  V v_calls_24188 = heff_env(self)[0];
  HeffT2 v_t_24192 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_calls_24188, heff_rfield(v_d_24191, 0)));
  {
    V v_field_24194 = v_t_24192.f[1];
    int64_t v_tag_24193 = ((int64_t)v_t_24192.f[0]);
    if ((v_tag_24193 == ((int64_t)0ULL))) {
      V v_x_24195 = v_field_24194;
      heff_drop(v_x_24195);
      HeffT2 v_t_24196 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w_24190, 1), heff_rfield(v_d_24191, 0)));
      {
        V v_field_24198 = v_t_24196.f[1];
        int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
        if ((v_tag_24197 == ((int64_t)0ULL))) {
          heff_drop_rec(v_d_24191, 3);
          heff_drop(self);
          V v_x_24199 = v_field_24198;
          heff_drop(v_x_24199);
          return v_w_24190;
        } else {
          heff_drop(v_field_24198);
          heff_clo_take(self, 1);
          return ({ V a_0 = v_calls_24188; V a_1 = v_w_24190; V a_2 = heff_get_n(v_d_24191, 0, 3); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_calls_24188); r_; });
        }
      }
    } else {
      heff_drop_rec(v_d_24191, 3);
      heff_drop(self);
      heff_drop(v_field_24194);
      return v_w_24190;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_lam16(V self, V *args) {
  V v_acc_24233 = args[0];
  V v_x_24234 = args[1];
  V v_g_24230 = heff_env(self)[0];
  V v_args_24231 = heff_env(self)[1];
  V v_at_24229 = heff_env(self)[2];
  V v_key_24235 = heff_take_field(v_x_24234, 0);
  V v_params_24236 = heff_get_n(v_x_24234, 2, 4);
  V v_t_24238;
  heff_clo_take(self, 3);
  if (heff_strEq_c_lent(v_key_24235, v_g_24230, 2)) {
    heff_drop(v_key_24235);
    heff_drop(v_params_24236);
    v_t_24238 = v_args_24231;
  } else {
    heff_drop(v_args_24231);
    switch (heff_tag_of(v_at_24229)) {
    case TAG_Nothing: {
      heff_drop(v_key_24235);
      v_t_24238 = (g_list_2emap_24s1460603830x671758883(((V)&g_heff_2ecompile_2elower_2eshared_str0), v_params_24236));
      break;
    }
    case TAG_Just: {
      V v_x_24237 = heff_field(v_at_24229, 0);
      V v_ru_24at_24229_24Just = heff_take_reuse_n(v_at_24229, 1ULL, 1);
      if (!heff_strEq_c_lent(v_x_24237, v_key_24235, 0)) {
        heff_drop(v_key_24235);
        heff_drop(v_x_24237);
        v_t_24238 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24at_24229_24Just, v_params_24236));
      } else {
        heff_drop(v_key_24235);
        heff_drop(v_x_24237);
        v_t_24238 = (g_list_2emap_24s1460603830x671758883_24tok1(v_ru_24at_24229_24Just, ((V)&g_heff_2ecompile_2elower_2eshared_str1), v_params_24236));
      }
      break;
    }
    default: heff_nomatch(v_at_24229);
    }
  }
  return (g_prelude_2e_2b_2b(v_t_24238, v_acc_24233));
}
V g_heff_2ecompile_2elower_2eshared_lam17(V self, V *args) {
  V v_m_24246 = args[0];
  V v_c_24243 = heff_env(self)[0];
  V v_key_24247 = heff_take_field(v_m_24246, 0);
  V v_body_24248 = heff_get_n(v_m_24246, 3, 4);
  heff_clo_take(self, 1);
  V v_t_24249 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(v_c_24243, heff_dup(v_key_24247), v_body_24248));
  return heff_tag_n(TAG_MkArm, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eshared_str3), v_key_24247), NTAG(TAG_Nil), v_t_24249});
}
V g_heff_2ecompile_2elower_2eshared_lam15(V self, V *args) {
  V v_acc_24208 = args[0];
  V v_d_24209 = args[1];
  V v_byMember_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24210 = ({ V a_0 = v_byMember_24206; V a_1 = heff_rfield(v_d_24209, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byMember_24206); r_; });
  {
    V v_field_24212 = v_t_24210.f[1];
    int64_t v_tag_24211 = ((int64_t)v_t_24210.f[0]);
    if ((v_tag_24211 == ((int64_t)0ULL))) {
      V v_c_24213 = v_field_24212;
      V v_t_24214 = heff_dup(heff_rfield(v_c_24213, 2));
      switch (heff_tag_of(v_t_24214)) {
      case TAG_Nil: {
        heff_drop_rec(v_c_24213, 3);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_d_24209, v_acc_24208});
      }
      case TAG_Cons: {
        V v_x_24215 = heff_field(v_t_24214, 0);
        V v_ru_24t_24214_24Cons = heff_take_reuse_n(v_t_24214, 1ULL, 2);
        V v_c_24217 = v_c_24213;
        V v_acc_24218 = v_acc_24208;
        V v_d_24219 = heff_dup(v_d_24209);
        V v_first_24220 = v_x_24215;
        HeffT2 v_t_24221 = (g_list_2efind_24s775449825x1158002128_24cpr(v_d_24219, heff_rfield(v_c_24217, 2)));
        {
          V v_field_24223 = v_t_24221.f[1];
          int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
          V v_m_24225;
          if ((v_tag_24222 == ((int64_t)0ULL))) {
            V v_x_24224 = v_field_24223;
            v_m_24225 = v_x_24224;
          } else {
            heff_drop(v_field_24223);
            v_m_24225 = heff_dup(v_first_24220);
          }
          V v_key_24226 = heff_take_field(v_m_24225, 0);
          V v_outer_24227 = heff_get_n(v_m_24225, 1, 4);
          V v_c_24228 = heff_dup(v_c_24217);
          V v_at_24229 = NTAG(TAG_Nothing);
          V v_g_24230 = v_key_24226;
          V v_args_24231 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_outer_24227)));
          V v_t_24232 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_24228, 2, 3)));
          V v_t_24239 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam16, 2, 3, (V[]){heff_dup(v_g_24230), v_args_24231, v_at_24229}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24232; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24232); r_; });
          V v_t_24240 = heff_tag_n(TAG_ETag, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eshared_str2), v_g_24230), NTAG(TAG_Nil), NTAG(TAG_Nil)});
          V v_t_24241 = heff_tag_n(TAG_ECall, 2, (V[]){heff_dup(heff_rfield(v_c_24217, 0)), heff_tag_at_n(v_ru_24t_24214_24Cons, TAG_Cons, 2, (V[]){v_t_24240, v_t_24239})});
          V v_body_24242 = heff_tag_n(TAG_ELam, 2, (V[]){v_outer_24227, v_t_24241});
          V v_t_24255;
          if (heff_strEq_c(heff_get_n(v_first_24220, 0, 4), heff_dup(heff_rfield(v_d_24219, 0)))) {
            V v_c_24243 = v_c_24217;
            V v_t_24244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_24243, 2))));
            V v_t_24245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24244; V r_ = (g_list_2efoldl_24s2023159590x14712440(a_0, a_1)); heff_drop(v_t_24244); r_; });
            V v_t_24250 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2eshared_lam17, 1, 1, (V[]){heff_dup(v_c_24243)}), heff_dup(heff_rfield(v_c_24243, 2))));
            V v_t_24251 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_24243, 1)), v_t_24245});
            V v_t_24252 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_c_24243, 1)});
            V v_body_24253 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_24251, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24252, v_t_24250})});
            V v_t_24254 = ({ V rv_0 = heff_dup(heff_rfield(v_c_24243, 0)); V rv_1 = heff_get_n(v_c_24243, 0, 3); V rv_2 = v_body_24253; V rr_ = heff_rec_reuse_nf(v_d_24209, 0ULL, 3, shape_key__name__body, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
            v_t_24255 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24254, v_acc_24218});
          } else {
            heff_drop_rec(v_d_24209, 3);
            heff_drop_rec(v_c_24217, 3);
            v_t_24255 = v_acc_24218;
          }
          V v_t_24256 = ({ V rv_2 = v_body_24242; V rr_ = heff_rec_reuse_nf(v_d_24219, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24256, v_t_24255});
        }
      }
      default: return heff_nomatch(v_t_24214);
      }
    } else {
      heff_drop(v_field_24212);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_d_24209, v_acc_24208});
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_lam18(V self, V *args) {
  V v_acc_24321 = args[0];
  V v_p_24322 = args[1];
  V v_parent_24318 = heff_env(self)[0];
  V v_x_24325;
  switch (heff_tag_of(v_p_24322)) {
  case TAG_MkPair: {
    V v_x_24323 = heff_dup(heff_field(v_p_24322, 0));
    v_x_24325 = v_x_24323;
    break;
  }
  default: heff_nomatch(v_p_24322);
  }
  V v_t_24326 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_24318, v_x_24325));
  heff_clo_take(self, 1);
  V v_root_24327 = ({ V a_0 = v_parent_24318; V a_1 = v_x_24325; V a_2 = v_t_24326; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_24318); r_; });
  HeffT2 v_t_24328 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_acc_24321, v_root_24327));
  {
    V v_field_24330 = v_t_24328.f[1];
    int64_t v_tag_24329 = ((int64_t)v_t_24328.f[0]);
    V v_t_24332;
    if ((v_tag_24329 == ((int64_t)0ULL))) {
      V v_x_24331 = v_field_24330;
      v_t_24332 = v_x_24331;
    } else {
      heff_drop(v_field_24330);
      v_t_24332 = NTAG(TAG_NoShape);
    }
    V v_t_24335;
    switch (heff_tag_of(v_p_24322)) {
    case TAG_MkPair: {
      V v_y_24334 = heff_field(v_p_24322, 1);
      heff_take_n(v_p_24322, 2ULL, 2);
      v_t_24335 = v_y_24334;
      break;
    }
    default: heff_nomatch(v_p_24322);
    }
    V v_t_24336 = (g_list_2efoldl_24s1766906699x9526323(v_t_24332, v_t_24335));
    return ({ V a_0 = v_acc_24321; V a_1 = v_root_24327; V a_2 = v_t_24336; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_root_24327); heff_drop(v_t_24336); r_; });
  }
}
V g_heff_2ecompile_2elower_2eshared_lam19(V self, V *args) {
  V v_acc_24342 = args[0];
  V v_p_24343 = args[1];
  V v_parent_24316 = heff_env(self)[0];
  V v_ls_24339 = heff_env(self)[1];
  V v_x_24346;
  switch (heff_tag_of(v_p_24343)) {
  case TAG_MkPair: {
    V v_x_24344 = heff_dup(heff_field(v_p_24343, 0));
    v_x_24346 = v_x_24344;
    break;
  }
  default: heff_nomatch(v_p_24343);
  }
  V v_t_24347 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_24316, v_x_24346));
  heff_clo_take(self, 2);
  V v_t_24348 = ({ V a_0 = v_parent_24316; V a_1 = v_x_24346; V a_2 = v_t_24347; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_24316); r_; });
  HeffT2 v_t_24349 = ({ V a_0 = v_ls_24339; V a_1 = v_t_24348; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ls_24339); heff_drop(v_t_24348); r_; });
  {
    V v_field_24351 = v_t_24349.f[1];
    int64_t v_tag_24350 = ((int64_t)v_t_24349.f[0]);
    if ((v_tag_24350 == ((int64_t)0ULL))) {
      V v_lay_24352 = v_field_24351;
      V v_t_24355;
      switch (heff_tag_of(v_p_24343)) {
      case TAG_MkPair: {
        V v_x_24353 = heff_field(v_p_24343, 0);
        heff_take_n(v_p_24343, 1ULL, 2);
        v_t_24355 = v_x_24353;
        break;
      }
      default: heff_nomatch(v_p_24343);
      }
      return ({ V a_0 = v_acc_24342; V a_1 = v_t_24355; V a_2 = v_lay_24352; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_24355); heff_drop(v_lay_24352); r_; });
    } else {
      heff_drop(v_p_24343);
      heff_drop(v_field_24351);
      return v_acc_24342;
    }
  }
}
V g_heff_2ecompile_2elower_2eshared_lam20(V self, V *args) {
  V v_p_24361 = args[0];
  V v_groups_24359 = heff_env(self)[0];
  V v_t_24364;
  switch (heff_tag_of(v_p_24361)) {
  case TAG_MkPair: {
    V v_y_24363 = heff_field(v_p_24361, 1);
    heff_take_n(v_p_24361, 2ULL, 2);
    v_t_24364 = v_y_24363;
    break;
  }
  default: heff_nomatch(v_p_24361);
  }
  heff_clo_take(self, 1);
  HeffT2 v_t_24365 = ({ V a_0 = v_groups_24359; V b_1 = heff_get_n(v_t_24364, 6, 7); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_groups_24359); heff_drop(b_1); r_; });
  {
    V v_field_24367 = v_t_24365.f[1];
    int64_t v_tag_24366 = ((int64_t)v_t_24365.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24366 == ((int64_t)0ULL)) && ({ V v_x_24368 = heff_dup(v_field_24367); int c_ = 1; heff_drop(v_x_24368); c_; })));
    heff_drop(v_field_24367);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam21(V self, V *args) {
  V v_d_24372 = args[0];
  V v_k_24370 = heff_env(self)[0];
  V v_t_24373 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_k_24370, heff_rfield(v_d_24372, 0)));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_24370; V a_1 = v_d_24372; V a_2 = v_t_24373; V r_ = (g_heff_2ecompile_2ecpr_2edefWith(a_0, a_1, a_2)); heff_drop(v_k_24370); heff_drop(v_t_24373); r_; });
}
V g_heff_2ecompile_2elower_2eshared_lam22(V self, V *args) {
  V v_d_24395 = args[0];
  V v_reached_24394 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24396 = ({ V a_0 = v_reached_24394; V b_1 = heff_get_n(v_d_24395, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_24394); heff_drop(b_1); r_; });
  {
    V v_field_24398 = v_t_24396.f[1];
    int64_t v_tag_24397 = ((int64_t)v_t_24396.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24397 == ((int64_t)0ULL)) && ({ V v_x_24399 = heff_dup(v_field_24398); int c_ = 1; heff_drop(v_x_24399); c_; })));
    heff_drop(v_field_24398);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eshared_lam23(V self, V *args) {
  V v_w_24405 = args[0];
  V v_d_24406 = args[1];
  V v_refs_24403 = heff_env(self)[0];
  HeffT2 v_t_24407 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w_24405, 1), heff_rfield(v_d_24406, 0)));
  {
    V v_field_24409 = v_t_24407.f[1];
    int64_t v_tag_24408 = ((int64_t)v_t_24407.f[0]);
    if ((v_tag_24408 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_24406, 3);
      heff_drop(self);
      V v_x_24410 = v_field_24409;
      heff_drop(v_x_24410);
      return v_w_24405;
    } else {
      heff_drop(v_field_24409);
      heff_clo_take(self, 1);
      return ({ V a_0 = v_refs_24403; V a_1 = v_w_24405; V a_2 = heff_get_n(v_d_24406, 0, 3); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_refs_24403); r_; });
    }
  }
}
Clo g_heff_2ecompile_2elower_2esharedLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2esharedLowered_entry, 2, 0};

V g_heff_2ecompile_2elower_2esharedLowered(V v_errors_240, V v_t_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2ecompile_2elower_2esharedLowered_24cpr(v_errors_240, v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_defs__facts__errors__works, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2elower_2esharedLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2esharedLowered(a[0], a[1]);
}
Clo g_heff_2ecompile_2elower_2ejsDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ejsDef_entry, 2, 0};

V g_heff_2ecompile_2elower_2ejsDef(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_b0_242 = heff_field(v_x2_241, 0);
    V v_n_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_d_244 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), heff_dup(v_b0_242)});
    heff_drop_rec(v_d_244, 3);
    V v_t_245 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_b0_242));
    V v_a_246 = heff_tr(heff_call(v_t_245, 1, (V[]){v_n_243}));
    V v_x1_2422;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_246, 0);
      V v_a_248 = heff_field(v_a_246, 1);
      heff_take_n(v_a_246, 3ULL, 2);
      V v_t_249 = ({ V rv_2 = v_a_247; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2410 = (g_heff_2ecompile_2erunes_2edefOf(v_t_249));
      V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_a_248}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_n_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        V v_t_2414 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        HeffT4 v_t_2415 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2414, v_x_2412, v_n_2413));
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          V v_field_2419 = v_t_2415.f[3];
          V v_x_2420 = heff_tag_n(TAG_MkDef, 3, (V[]){v_field_2416, v_field_2417, v_field_2418});
          V v_y_2421 = v_field_2419;
          heff_drop(v_y_2421);
          v_x1_2422 = v_x_2420;
        }
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_MkDef: {
      V v_key_2423 = heff_field(v_x1_2422, 0);
      V v_name_2424 = heff_field(v_x1_2422, 1);
      V v_b_2425 = heff_field(v_x1_2422, 2);
      V v_ru_24x1_2422_24MkDef = heff_take_reuse_n(v_x1_2422, 7ULL, 3);
      V v_t_2433;
      switch (heff_tag_of(v_b_2425)) {
      case TAG_DefFun: {
        V v_xs_2426 = heff_field(v_b_2425, 0);
        V v_x12_2427 = heff_field(v_b_2425, 1);
        heff_take_n(v_b_2425, 3ULL, 2);
        switch (heff_tag_of(v_x12_2427)) {
        case TAG_MkBlock: {
          V v_t_2428 = heff_field(v_x12_2427, 0);
          V v_ru_24x12_2427_24MkBlock = heff_take_reuse_n(v_x12_2427, 1ULL, 1);
          V v_t_2429 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_t_2428));
          v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_DefFun, 2, (V[]){v_xs_2426, heff_tag_at_n(v_ru_24x12_2427_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2429})});
          break;
        }
        default: heff_nomatch(v_x12_2427);
        }
        break;
      }
      case TAG_DefVal: {
        V v_x11_2430 = heff_field(v_b_2425, 0);
        V v_ru_24b_2425_24DefVal = heff_take_reuse_n(v_b_2425, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_MkBlock: {
          V v_t_2431 = heff_field(v_x11_2430, 0);
          V v_ru_24x11_2430_24MkBlock = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
          V v_t_2432 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_t_2431));
          v_t_2433 = heff_tag_at_n(v_ru_24b_2425_24DefVal, TAG_DefVal, 1, (V[]){heff_tag_at_n(v_ru_24x11_2430_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2432})});
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        break;
      }
      default: heff_nomatch(v_b_2425);
      }
      return heff_tag_re_n(v_ru_24x1_2422_24MkDef, TAG_MkDef, 3, 3ULL, (V[]){v_key_2423, v_name_2424, v_t_2433});
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ejsDef(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam4(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam6(V self, V *args);
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam5(V self, V *args);

HeffT2 g_heff_2ecompile_2elower_2efusedOf_24cpr(V v_roots_240, V v_si_241) {
top: ;
  V v_defs_242 = heff_take_field(v_si_241, 0);
  V v_supply_243 = heff_get_n(v_si_241, 1, 4);
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_242));
  V v_defs_245 = (g_list_2efoldl_24s2147120392x1124384541(MK_INT(0LL), NTAG(TAG_Nil), v_t_244));
  V v_t_246 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_245));
  V v_reached_247 = ({ V a_0 = v_t_246; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_240); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_defs_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam0, 1, 1, (V[]){v_reached_247}); V a_1 = v_defs_245; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_roots_2414 = v_roots_240;
  V v_defs_2415 = heff_dup(v_defs_2413);
  V v_small_2467 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam1, 2, 1, (V[]){v_roots_2414}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2415; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2471 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam2, 2, 1, (V[]){heff_dup(v_small_2467)}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2415; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_2415); r_; });
  V v_t_2472 = ({ V a_0 = v_small_2467; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_small_2467); r_; });
  V v_cs_2473 = ({ V a_0 = v_t_2471; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2472; V r_ = (g_list_2efoldl_24s2098410461x866205771(a_0, a_1, a_2)); heff_drop(v_t_2471); heff_drop(v_t_2472); r_; });
  V v_defs_2474 = v_defs_2413;
  V v_cs_2475 = heff_dup(v_cs_2473);
  V v_t_2476 = ({ V a_0 = v_cs_2473; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_cs_2473); r_; });
  V v_x3_2477 = (g_list_2efoldl_24s637780307x9274583(heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_supply_243}), v_t_2476));
  V v_x1_2489;
  switch (heff_tag_of(v_x3_2477)) {
  case TAG_MkPair: {
    V v_fresh_2478 = heff_field(v_x3_2477, 0);
    V v_n_2479 = heff_field(v_x3_2477, 1);
    V v_ru_24x3_2477_24MkPair = heff_take_reuse_n(v_x3_2477, 3ULL, 2);
    V v_t_2485 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam3, 1, 1, (V[]){v_cs_2475}); V a_1 = v_defs_2474; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2488 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam4, 1, 1, (V[]){v_fresh_2478}), v_t_2485));
    v_x1_2489 = heff_tag_re_n(v_ru_24x3_2477_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2488, v_n_2479});
    break;
  }
  default: heff_nomatch(v_x3_2477);
  }
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_defs_2490 = heff_field(v_x1_2489, 0);
    V v_n_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    V v_supply_2492 = v_n_2491;
    V v_defs_2493 = v_defs_2490;
    V v_sg_2494 = (g_list_2efoldl_24s890299851x180637966(heff_dup(g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get()), v_defs_2493));
    V v_t_24102 = (g_prelude_2etraverse_24s545943161x1483966866(heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam5, 1, 1, (V[]){v_sg_2494}), heff_dup(v_defs_2493)));
    V v_t_24103 = (g_list_2efoldl_24s1530765264x1072548396(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2493));
    V v_t_24104 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_defs_2493; V r_ = (g_list_2efoldl_24s42602063x979600769(a_0, a_1)); heff_drop(v_defs_2493); r_; });
    V v_t_24105 = heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_2492, v_t_24103, v_t_24104, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), MK_INT(2000LL)});
    V v_x2_24106 = heff_tr(heff_call(v_t_24102, 1, (V[]){v_t_24105}));
    switch (heff_tag_of(v_x2_24106)) {
    case TAG_MkPair: {
      V v_ds_24107 = heff_field(v_x2_24106, 0);
      V v_s_24108 = heff_field(v_x2_24106, 1);
      heff_take_n(v_x2_24106, 3ULL, 2);
      V v_fresh_24109 = heff_take_field(v_s_24108, 4);
      V v_supply_24110 = heff_get_n(v_s_24108, 0, 6);
      V v_t_24111 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fresh_24109));
      V v_t_24112 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_2489_24MkPair, v_ds_24107, v_t_24111));
      V v_f_24113 = v_supply_24110;
      return ((HeffT2){{v_t_24112, v_f_24113}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24106)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2489)}});
  }
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_reached_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_reached_247; V b_1 = heff_get_n(v_d_248, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_247); heff_drop(b_1); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam1(V self, V *args) {
  V v_m_2416 = args[0];
  V v_d_2417 = args[1];
  V v_roots_2414 = heff_env(self)[0];
  V v_key_2418 = heff_take_field(v_d_2417, 0);
  V v_body_2419 = heff_get_n(v_d_2417, 2, 3);
  heff_clo_take(self, 1);
  V v_roots_2420 = v_roots_2414;
  V v_g_2421 = heff_dup(v_key_2418);
  V v_e_2422 = v_body_2419;
  V v_x3_2465;
  switch (heff_tag_of(v_e_2422)) {
  case TAG_EVar: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    V v_xs_2425 = heff_field(v_e_2422, 0);
    V v_b_2426 = heff_field(v_e_2422, 1);
    V v_ru_24e_2422_24ELam = heff_take_reuse_n(v_e_2422, 3ULL, 2);
    V v_t_2427 = heff_tag_at_n(v_ru_24e_2422_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_2426), NTAG(TAG_Nil)});
    V v_x_2428 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(75LL), MK_INT(0LL), v_t_2427));
    if (!heff_intLt_c_lent(MK_INT(75LL), v_x_2428, 1)) {
      heff_drop(v_x_2428);
      V v_x1_2429 = ({ V a_0 = v_g_2421; V a_1 = v_roots_2420; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_g_2421); heff_drop(v_roots_2420); r_; });
      if (!(heff_dup(v_x1_2429) == NTAG(TAG_True))) {
        heff_drop(v_x1_2429);
        v_x3_2465 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_xs__b, (V[]){v_xs_2425, v_b_2426})});
      } else {
        heff_drop(v_xs_2425);
        heff_drop(v_b_2426);
        heff_drop(v_x1_2429);
        v_x3_2465 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_roots_2420);
      heff_drop(v_g_2421);
      heff_drop(v_xs_2425);
      heff_drop(v_b_2426);
      heff_drop(v_x_2428);
      v_x3_2465 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_e_2422, 0ULL, 3);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_e_2422, 0ULL, 4);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_e_2422, 0ULL, 3);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_e_2422, 0ULL, 3);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_e_2422, 0ULL, 1);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_e_2422, 0ULL, 2);
    heff_drop(v_roots_2420);
    heff_drop(v_g_2421);
    v_x3_2465 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_2422);
  }
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_Nothing: {
    heff_drop(v_key_2418);
    return v_m_2416;
  }
  case TAG_Just: {
    V v_c_2466 = heff_field(v_x3_2465, 0);
    heff_take_n(v_x3_2465, 1ULL, 1);
    return ({ V a_0 = v_m_2416; V a_1 = v_key_2418; V a_2 = v_c_2466; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_2418); heff_drop(v_c_2466); r_; });
  }
  default: return heff_nomatch(v_x3_2465);
  }
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam2(V self, V *args) {
  V v_m_2468 = args[0];
  V v_d_2469 = args[1];
  V v_small_2467 = heff_env(self)[0];
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_2469, 2, 3), NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return ({ V a_0 = v_small_2467; V a_1 = v_m_2468; V a_2 = v_t_2470; V r_ = (g_heff_2ecompile_2eonce_2eusesW(a_0, a_1, a_2)); heff_drop(v_small_2467); r_; });
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam3(V self, V *args) {
  V v_d_2480 = args[0];
  V v_cs_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V a_0 = v_cs_2475; V b_1 = heff_get_n(v_d_2480, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_cs_2475); heff_drop(b_1); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2482 == ((int64_t)0ULL)) ? ({ V v_x_2484 = heff_dup(v_field_2483); int c_ = 0; heff_drop(v_x_2484); c_; }) : 1));
    heff_drop(v_field_2483);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam4(V self, V *args) {
  V v_d_2486 = args[0];
  V v_fresh_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_body_2487 = ({ V a_0 = v_fresh_2478; V a_1 = NTAG(TAG_Nil); V a_2 = heff_take_field(v_d_2486, 2); V r_ = (g_heff_2ecompile_2eonce_2einlined(a_0, a_1, a_2)); heff_drop(v_fresh_2478); r_; });
  return ({ V rv_2 = v_body_2487; V rr_ = heff_rec_reuse_nf(v_d_2486, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam6(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_d_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_t_24101 = ({ V rv_2 = v_x_2499; V rr_ = heff_rec_reuse_nf(v_d_2495, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24101, v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2elower_2efusedOf_24cpr_lam5(V self, V *args) {
  V v_d_2495 = args[0];
  V v_sg_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2496 = (g_heff_2ecompile_2efuse_2esites(v_sg_2494, heff_dup(heff_rfield(v_d_2495, 2))));
  return heff_clo_n(g_heff_2ecompile_2elower_2efusedOf_24cpr_lam6, 1, 2, (V[]){v_m_2496, v_d_2495});
}
V g_heff_2ecompile_2elower_2efusedWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2efusedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2efusedWith_entry, 4, 0};

V g_heff_2ecompile_2elower_2efusedWith(V v_rest_240, V v_roots_241, V v_errors_242, V v_f_243) {
top: ;
  V v_defs_244 = heff_take_field(v_f_243, 0);
  V v_supply_245 = heff_get_n(v_f_243, 1, 2);
  V v_defs_246 = v_defs_244;
  V v_t_247 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_246));
  V v_reached_248 = ({ V a_0 = v_t_247; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_241); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2414 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2efusedWith_lam0, 1, 1, (V[]){v_reached_248}); V a_1 = v_defs_246; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_rest_240, 4, (V[]){v_roots_241, v_supply_245, v_t_2414, v_errors_242});
}
V g_heff_2ecompile_2elower_2efusedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2efusedWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2elower_2efusedWith_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_reached_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_reached_248; V b_1 = heff_get_n(v_d_249, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_248); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2eerasedWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedWith_entry, 3, 0};

V g_heff_2ecompile_2elower_2eerasedWith(V v_rest_240, V v_roots_241, V v_er_242) {
top: ;
  V v_defs_243 = heff_take_field(v_er_242, 0);
  V v_supply_244 = heff_take_field(v_er_242, 2);
  V v_errors_245 = heff_get_n(v_er_242, 1, 3);
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_243));
  V v_defs_247 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl_24s650566757x317183241(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_247));
  V v_defs_249 = (g_list_2efoldl_24s644510009x1719377493(NTAG(TAG_Nil), v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_249));
  V v_reached_2411 = ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_241); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_t_2417 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eerasedWith_lam0, 1, 1, (V[]){v_reached_2411}); V a_1 = v_defs_249; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_si_2418 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(v_supply_244, v_t_2417));
  V v_t_2419 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_241), v_si_2418));
  return (g_heff_2ecompile_2elower_2efusedWith(v_rest_240, v_roots_241, v_errors_245, v_t_2419));
}
V g_heff_2ecompile_2elower_2eerasedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eerasedWith_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_reached_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = ({ V a_0 = v_reached_2411; V b_1 = heff_get_n(v_d_2412, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_2411); heff_drop(b_1); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2416 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2416); c_; })));
    heff_drop(v_field_2415);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2elower_2eplusCount_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eplusCount_entry, 1, 0};

V g_heff_2ecompile_2elower_2eplusCount(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    return MK_INT(0LL);
  }
  case TAG_Plus: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_b_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2ecompile_2elower_2eplusCount(v_a_242));
    V v_t_245 = (g_heff_2ecompile_2elower_2eplusCount(v_b_243));
    return heff_intAdd(heff_intAdd(MK_INT(1LL), v_t_244), v_t_245);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2eplusCount_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2eplusCount(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2elower_2eleafCount_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eleafCount_entry, 1, 0};

V g_heff_2ecompile_2elower_2eleafCount(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    return MK_INT(1LL);
  }
  case TAG_Plus: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_b_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2ecompile_2elower_2eleafCount(v_a_242));
    V v_t_245 = (g_heff_2ecompile_2elower_2eleafCount(v_b_243));
    return heff_intAdd(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2eleafCount_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2eleafCount(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2ehandedOn_str0, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2ehandedOn_str1, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2ehandedOn_str2, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2ehandedOn_str3, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2ehandedOn_str4, 13, "run$perform$0");
Clo g_heff_2ecompile_2elower_2ehandedOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ehandedOn_entry, 2, 0};

V g_heff_2ecompile_2elower_2ehandedOn(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_242 = heff_intShow(heff_intAdd_lent(v_n_241, MK_INT(6LL), 2));
    V v_t_243 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2ehandedOn_str0), v_t_242)});
    V v_t_244 = heff_intShow(heff_intAdd(v_n_241, MK_INT(7LL)));
    V v_t_245 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2ehandedOn_str1), v_t_244)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_Perform), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  }
  case TAG_Just: {
    V v_w_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_248 = heff_intShow(heff_intAdd_lent(v_n_241, MK_INT(6LL), 2));
    V v_p_249 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2ehandedOn_str2), v_t_248)});
    V v_t_2410 = heff_intShow(heff_intAdd(v_n_241, MK_INT(7LL)));
    V v_k_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2ehandedOn_str3), v_t_2410)});
    switch (heff_tag_of(v_w_247)) {
    case TAG_Leaf: {
      V v_ru_24w_247_24Leaf = heff_take_reuse_n(v_w_247, 0ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_2411, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_tag_at_n(v_ru_24w_247_24Leaf, TAG_PerformAt, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_p_249, v_t_2413})});
    }
    case TAG_Plus: {
      V v_ru_24w_247_24Plus = heff_take_reuse_n(v_w_247, 0ULL, 2);
      V v_t_2416 = heff_tag_at_n(v_ru_24w_247_24Plus, TAG_Cons, 2, (V[]){v_k_2411, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){((V)&g_heff_2ecompile_2elower_2ehandedOn_str4)}), heff_tag_n(TAG_Cons, 2, (V[]){v_p_249, v_t_2416})});
    }
    default: return heff_nomatch(v_w_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2ehandedOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ehandedOn(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eshapeSaid_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2elower_2eshapeSaid_str1, 3, " + ");
HEFF_LIT(g_heff_2ecompile_2elower_2eshapeSaid_str2, 1, ")");
Clo g_heff_2ecompile_2elower_2eshapeSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eshapeSaid_entry, 1, 0};

V g_heff_2ecompile_2elower_2eshapeSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_k_241);
  }
  case TAG_Plus: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_b_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2ecompile_2elower_2eshapeSaid(v_a_242));
    V v_t_245 = (g_heff_2ecompile_2elower_2eshapeSaid(v_b_243));
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2elower_2eshapeSaid_str0), v_t_244), ((V)&g_heff_2ecompile_2elower_2eshapeSaid_str1));
    return heff_strAppend(heff_strAppend(v_t_246, v_t_245), ((V)&g_heff_2ecompile_2elower_2eshapeSaid_str2));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2eshapeSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2elower_2eshapeSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str0, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str1, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str2, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str3, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str4, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str5, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str6, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str7, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str8, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str9, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str10, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str11, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str12, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str13, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str14, 4, "malg");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str15, 4, "bind");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str16, 3, "ret");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str17, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str18, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str19, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str20, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str21, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryCps_str22, 6, "MkUnit");
Clo g_heff_2ecompile_2elower_2eentryCps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryCps_entry, 3, 0};

V g_heff_2ecompile_2elower_2eentryCps(V v_w_240, V v_key_241, V v_n_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2elower_2ehandedOn(v_w_240, heff_dup(v_n_242)));
  V v_t_244 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(0LL), 2));
  V v_t_245 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(1LL), 2));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str0), v_t_245), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str1), v_t_244), v_t_246});
  V v_t_248 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(1LL), 2));
  V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str2), v_t_248)});
  V v_t_2410 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(0LL), 2));
  V v_t_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str3), v_t_2410)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_247, heff_tag_n(TAG_EApp, 2, (V[]){v_t_249, v_t_2412})});
  V v_t_2414 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(2LL), 2));
  V v_t_2415 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(3LL), 2));
  V v_t_2416 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(4LL), 2));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str4), v_t_2416), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str5), v_t_2415), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str6), v_t_2414), v_t_2418});
  V v_t_2420 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(2LL), 2));
  V v_t_2421 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str7), v_t_2420)});
  V v_t_2422 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(5LL), 2));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str8), v_t_2422), NTAG(TAG_Nil)});
  V v_t_2424 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(3LL), 2));
  V v_t_2425 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str9), v_t_2424)});
  V v_t_2426 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(5LL), 2));
  V v_t_2427 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str10), v_t_2426)});
  V v_t_2428 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(4LL), 2));
  V v_t_2429 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str11), v_t_2428)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2423, v_t_2431}), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2419, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2421, v_t_2432})});
  V v_t_2434 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(6LL), 2));
  V v_t_2435 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(7LL), 2));
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str12), v_t_2435), NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str13), v_t_2434), v_t_2436});
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryCps_str14), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2437, v_t_243})});
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryCps_str15), v_t_2433}), v_t_2439});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryCps_str16), v_t_2413}), v_t_2440});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), NTAG(TAG_Nil)});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2442});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2443});
  V v_t_2445 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(8LL), 2));
  V v_t_2446 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(9LL), 2));
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str17), v_t_2446), NTAG(TAG_Nil)});
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str18), v_t_2445), v_t_2447});
  V v_t_2449 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(9LL), 2));
  V v_t_2450 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str19), v_t_2449)});
  V v_t_2451 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(8LL), 2));
  V v_t_2452 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str20), v_t_2451)});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
  V v_t_2454 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2448, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2450, v_t_2453})});
  V v_t_2455 = heff_intShow(heff_intAdd(v_n_242, MK_INT(10LL)));
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryCps_str21), v_t_2455), NTAG(TAG_Nil)});
  V v_t_2457 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2elower_2eentryCps_str22), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2456, v_t_2457}), NTAG(TAG_Nil)});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2441, v_t_2444}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_t_2458})});
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_241}), v_t_2459});
}
V g_heff_2ecompile_2elower_2eentryCps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryCps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str0, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str1, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str2, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str3, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str4, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str5, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str6, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str7, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str8, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str9, 2, "m$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str10, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str11, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str12, 2, "f$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str13, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str14, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str15, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str16, 4, "bind");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str17, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str18, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str19, 2, "p$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str20, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str21, 3, "in$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str22, 4, "due$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str23, 4, "malg");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str24, 3, "ret");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str25, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str26, 2, "c$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str27, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str28, 2, "k$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str29, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str30, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str31, 2, "x$");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryReading_str32, 6, "MkUnit");
Clo g_heff_2ecompile_2elower_2eentryReading_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryReading_entry, 3, 0};

V g_heff_2ecompile_2elower_2eentryReading(V v_w_240, V v_key_241, V v_n_242) {
top: ;
  V v_w_243 = v_w_240;
  V v_n_244 = heff_dup(v_n_242);
  V v_t_245 = (g_heff_2ecompile_2elower_2ehandedOn(v_w_243, heff_dup(v_n_244)));
  V v_t_246 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(0LL), 2));
  V v_t_247 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(13LL), 2));
  V v_t_248 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(1LL), 2));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str0), v_t_248), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str1), v_t_247), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str2), v_t_246), v_t_2410});
  V v_t_2412 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(1LL), 2));
  V v_t_2413 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str3), v_t_2412)});
  V v_t_2414 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(0LL), 2));
  V v_t_2415 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str4), v_t_2414)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2411, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2413, v_t_2416})});
  V v_t_2418 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(2LL), 2));
  V v_t_2419 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(3LL), 2));
  V v_t_2420 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(14LL), 2));
  V v_t_2421 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(4LL), 2));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str5), v_t_2421), NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str6), v_t_2420), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str7), v_t_2419), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str8), v_t_2418), v_t_2424});
  V v_t_2426 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(2LL), 2));
  V v_t_2427 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str9), v_t_2426)});
  V v_t_2428 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(14LL), 2));
  V v_t_2429 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str10), v_t_2428)});
  V v_t_2430 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(5LL), 2));
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str11), v_t_2430), NTAG(TAG_Nil)});
  V v_t_2432 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(3LL), 2));
  V v_t_2433 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str12), v_t_2432)});
  V v_t_2434 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(5LL), 2));
  V v_t_2435 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str13), v_t_2434)});
  V v_t_2436 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(14LL), 2));
  V v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str14), v_t_2436)});
  V v_t_2438 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(4LL), 2));
  V v_t_2439 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str15), v_t_2438)});
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2431, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2433, v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryReading_str16), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2425, v_t_2444})});
  V v_t_2446 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(6LL), 2));
  V v_t_2447 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(12LL), 2));
  V v_t_2448 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(7LL), 2));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str17), v_t_2448), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str18), v_t_2447), v_t_2449});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str19), v_t_2446), v_t_2450});
  V v_t_2452 = heff_intShow(heff_intAdd_lent(v_n_244, MK_INT(6LL), 2));
  V v_t_2453 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_CustodianDue), NTAG(TAG_Nil)});
  V v_t_2454 = heff_intShow(heff_intAdd_lent(v_n_244, MK_INT(11LL), 2));
  V v_t_2455 = heff_intShow(heff_intAdd(v_n_244, MK_INT(12LL)));
  V v_t_2456 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str20), v_t_2455)});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
  V v_t_2458 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_CustodyIn), v_t_2457});
  V v_t_2459 = heff_tag_n(TAG_ELet, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str21), v_t_2454), v_t_2458, v_t_245});
  V v_t_2460 = heff_tag_n(TAG_ELet, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str22), v_t_2452), v_t_2453, v_t_2459});
  V v_t_2461 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryReading_str23), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2451, v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2elower_2eentryReading_str24), v_t_2417}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), NTAG(TAG_Nil)});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2464});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtOther), v_t_2465});
  V v_t_2467 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(8LL), 2));
  V v_t_2468 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(15LL), 2));
  V v_t_2469 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(9LL), 2));
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str25), v_t_2469), NTAG(TAG_Nil)});
  V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str26), v_t_2468), v_t_2470});
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str27), v_t_2467), v_t_2471});
  V v_t_2473 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(9LL), 2));
  V v_t_2474 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str28), v_t_2473)});
  V v_t_2475 = heff_intShow(heff_intAdd_lent(v_n_242, MK_INT(8LL), 2));
  V v_t_2476 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str29), v_t_2475)});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
  V v_t_2478 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2472, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2474, v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2elower_2eentryReading_str30), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2480 = heff_intShow(heff_intAdd(v_n_242, MK_INT(10LL)));
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2elower_2eentryReading_str31), v_t_2480), NTAG(TAG_Nil)});
  V v_t_2482 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2elower_2eentryReading_str32), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2481, v_t_2482}), NTAG(TAG_Nil)});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2463, v_t_2466}), v_t_2484});
  return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_241}), v_t_2485});
}
V g_heff_2ecompile_2elower_2eentryReading_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eentryReading(a[0], a[1], a[2]);
}

static V g_heff_2ecompile_2elower_2ecLowered_24rec0_val;
static HEFF_ONCE g_heff_2ecompile_2elower_2ecLowered_24rec0_st;
static V g_heff_2ecompile_2elower_2ecLowered_24rec0_init(void) {
  return heff_rec_n(5, shape_tracks__sigs__lent__sums__fresh, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2elower_2ecLowered_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2elower_2ecLowered_24rec0_st)) return g_heff_2ecompile_2elower_2ecLowered_24rec0_val;
  return heff_global(&g_heff_2ecompile_2elower_2ecLowered_24rec0_val, &g_heff_2ecompile_2elower_2ecLowered_24rec0_st, g_heff_2ecompile_2elower_2ecLowered_24rec0_init);
}
HEFF_LIT(g_heff_2ecompile_2elower_2ecLowered_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2elower_2ecLowered_str1, 1, "-");
V g_heff_2ecompile_2elower_2ecLowered_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2ecLowered_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2ecLowered_lam2(V self, V *args);
V g_heff_2ecompile_2elower_2ecLowered_lam3(V self, V *args);
Clo g_heff_2ecompile_2elower_2ecLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ecLowered_entry, 5, 0};

V g_heff_2ecompile_2elower_2ecLowered(V v_errors_240, V v_tuples_241, V v_tk_242, V v_works_243, V v_r_244) {
top: ;
  V v_defs_245 = heff_take_field(v_r_244, 0);
  V v_words_246 = heff_get_n(v_r_244, 1, 2);
  V v_defs_247 = heff_dup(v_defs_245);
  V v_m_248 = (g_list_2efoldl_24s1738438673x24732785(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_245)));
  V v_t_249 = ({ V a_0 = v_m_248; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_248); r_; });
  V v_ps_2410 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_249));
  V v_t_2411 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2410; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2410); r_; });
  V v_fl_2412 = (g_list_2efoldl_24s2004150897x784001505(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_245)));
  V v_m_2413 = (g_list_2efoldl_24s243940296x1179168444(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_245)));
  V v_t_2414 = ({ V a_0 = v_m_2413; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2413); r_; });
  V v_ps_2415 = (g_list_2ekeepIf_24s1223034477x943356724(v_t_2414));
  V v_su_2416 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2415; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2415); r_; });
  V v_ws_2417 = v_words_246;
  V v_tk_2418 = heff_dup(v_tk_242);
  V v_hs_2419 = (g_list_2efoldl_24s757249601x485610223(MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL), ((V)&g_heff_2ecompile_2elower_2ecLowered_str0), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_defs_245)));
  HeffT12 v_t_2420 = ({ V a_0 = v_defs_245; HeffT12 r_ = (g_heff_2ecompile_2efacts_2efactsOf_24cpr(a_0)); heff_drop(v_defs_245); r_; });
  {
    V v_field_2421 = v_t_2420.f[0];
    V v_field_2422 = v_t_2420.f[1];
    V v_field_2423 = v_t_2420.f[2];
    V v_field_2424 = v_t_2420.f[3];
    V v_field_2425 = v_t_2420.f[4];
    V v_field_2426 = v_t_2420.f[5];
    V v_field_2427 = v_t_2420.f[6];
    V v_field_2428 = v_t_2420.f[7];
    V v_field_2429 = v_t_2420.f[8];
    V v_field_2430 = v_t_2420.f[9];
    V v_field_2431 = v_t_2420.f[10];
    heff_drop(v_t_2420.f[11]);
    V v_f_2433 = heff_rec_n(12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, (V[]){v_field_2421, v_field_2422, v_field_2423, v_field_2424, v_field_2425, v_field_2426, v_field_2427, v_field_2428, v_field_2429, v_field_2430, v_field_2431, v_hs_2419});
    V v_f_2434 = ({ V rv_10 = v_tk_2418; V rr_ = heff_rec_reuse_nf(v_f_2433, 3071ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 13631487u, 0u); heff_rfield(rr_, 10) = rv_10; rr_; });
    V v_f_2435 = ({ V rv_8 = v_tuples_241; V rr_ = heff_rec_reuse_nf(v_f_2434, 3839ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 16580607u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_f_2436 = ({ V rv_9 = v_ws_2417; V rr_ = heff_rec_reuse_nf(v_f_2435, 3583ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 15990783u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
    V v_t_2437 = ({ V rv_5 = v_fl_2412; V rv_6 = v_su_2416; V rr_ = heff_rec_reuse_nf(v_f_2436, 3999ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 16761855u, 0u); heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    V v_facts_2438 = (g_heff_2ecompile_2efacts_2ewithSureRecs(v_t_2411, v_t_2437));
    V v_errors_2439 = v_errors_240;
    V v_tk_2440 = v_tk_242;
    V v_defs_2441 = heff_dup(v_defs_247);
    V v_facts_2442 = heff_dup(v_facts_2438);
    V v_kept_2443 = v_works_243;
    V v_facts_2444 = v_facts_2438;
    V v_defs_2445 = v_defs_247;
    V v_facts_2446 = heff_dup(v_facts_2444);
    V v_xs_2447 = ({ V b_0 = heff_get_n(v_facts_2446, 5, 12); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2447));
    V v_items_2449 = (g_list_2efoldl_24s1585276774x1803507436(MK_INT(1LL), MK_INT(0LL), MK_INT(1LL), NTAG(TAG_Nil), v_t_2448));
    HeffT2 v_t_2450 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2449));
    {
      V v_field_2451 = v_t_2450.f[0];
      V v_field_2452 = v_t_2450.f[1];
      V v_a_2453 = v_field_2451;
      V v_b_2454 = v_field_2452;
      V v_t_2455 = heff_strAppend(heff_intShow(v_a_2453), ((V)&g_heff_2ecompile_2elower_2ecLowered_str1));
      V v_t_2456 = heff_strAppend(v_t_2455, heff_intShow(v_b_2454));
      V v_t_2457 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2445));
      V v_byKey_2458 = (g_list_2efoldl_24s88009013x1334911863(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2445));
      V v_defs_2459 = heff_dup(v_defs_2445);
      V v_refs_2472 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecLowered_lam0, 2, 1, (V[]){v_byKey_2458}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_defs_2459; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_2459); r_; });
      V v_defs_2473 = v_defs_2445;
      V v_w_2480 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecLowered_lam2, 2, 1, (V[]){v_refs_2472}); V a_1 = heff_dup(g_heff_2ecompile_2ecycles_2estartWalk_get()); V a_2 = v_defs_2473; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_2473); r_; });
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_w_2480, 5, 6)));
      V v_w_2482 = ({ V a_0 = v_kept_2443; V a_1 = v_facts_2444; V a_2 = v_t_2456; V a_3 = v_t_2457; V a_4 = heff_dup(g_heff_2ecompile_2elower_2ecLowered_24rec0_get()); V a_5 = v_t_2481; V r_ = (g_list_2efoldl_24s599926777x1799261815(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_2443); heff_drop(v_facts_2444); heff_drop(v_t_2456); heff_drop(v_t_2457); r_; });
      V v_sigs_2483 = heff_take_field(v_w_2482, 1);
      V v_lent_2484 = heff_take_field(v_w_2482, 2);
      V v_fresh_2485 = heff_get_n(v_w_2482, 4, 5);
      V v_ws_2486 = v_sigs_2483;
      V v_tk_2487 = v_tk_2440;
      V v_bor_2488 = v_lent_2484;
      V v_t_2489 = ({ V a_0 = v_bor_2488; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_bor_2488); r_; });
      V v_ps_24105 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2elower_2ecLowered_lam3, 1, 1, (V[]){v_tk_2487}), v_t_2489));
      V v_lent_24106 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24105; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_24105); r_; });
      V v_f_24107 = ({ V rv_3 = v_lent_24106; V rr_ = heff_rec_reuse_nf(v_facts_2442, 4087ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 16777023u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_24108 = ({ V rv_4 = v_ws_2486; V rr_ = heff_rec_reuse_nf(v_f_24107, 4079ULL, 12, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens__hashes, 16776447u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_rec_n(4, shape_defs__facts__errors__works, (V[]){v_defs_2441, v_t_24108, v_errors_2439, v_fresh_2485});
    }
  }
}
V g_heff_2ecompile_2elower_2ecLowered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ecLowered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2elower_2ecLowered_lam1(V self, V *args) {
  V v_g_2466 = args[0];
  V v_byKey_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2467 = ({ V a_0 = v_byKey_2458; V a_1 = v_g_2466; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_byKey_2458); heff_drop(v_g_2466); r_; });
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2468 == ((int64_t)0ULL)) && ({ V v_x_2470 = heff_dup(v_field_2469); int c_ = 1; heff_drop(v_x_2470); c_; })));
    heff_drop(v_field_2469);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2elower_2ecLowered_lam0(V self, V *args) {
  V v_m_2460 = args[0];
  V v_d_2461 = args[1];
  V v_byKey_2458 = heff_env(self)[0];
  V v_body_2462 = heff_take_field(v_d_2461, 2);
  V v_key_2463 = heff_get_n(v_d_2461, 0, 3);
  V v_t_2464 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_2462));
  V v_t_2465 = (g_heff_2ecompile_2eir_2enubI(v_t_2464));
  heff_clo_take(self, 1);
  V v_t_2471 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ecLowered_lam1, 1, 1, (V[]){v_byKey_2458}); V a_1 = v_t_2465; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  return ({ V a_0 = v_m_2460; V a_1 = v_key_2463; V a_2 = v_t_2471; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_2463); heff_drop(v_t_2471); r_; });
}
V g_heff_2ecompile_2elower_2ecLowered_lam2(V self, V *args) {
  V v_w_2474 = args[0];
  V v_d_2475 = args[1];
  V v_refs_2472 = heff_env(self)[0];
  HeffT2 v_t_2476 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w_2474, 1), heff_rfield(v_d_2475, 0)));
  {
    V v_field_2478 = v_t_2476.f[1];
    int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
    if ((v_tag_2477 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_2475, 3);
      heff_drop(self);
      V v_x_2479 = v_field_2478;
      heff_drop(v_x_2479);
      return v_w_2474;
    } else {
      heff_drop(v_field_2478);
      heff_clo_take(self, 1);
      return ({ V a_0 = v_refs_2472; V a_1 = v_w_2474; V a_2 = heff_get_n(v_d_2475, 0, 3); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_refs_2472); r_; });
    }
  }
}
V g_heff_2ecompile_2elower_2ecLowered_lam3(V self, V *args) {
  V v_p_2490 = args[0];
  V v_tk_2487 = heff_env(self)[0];
  V v_t_2493;
  switch (heff_tag_of(v_p_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_dup(heff_field(v_p_2490, 0));
    v_t_2493 = v_x_2491;
    break;
  }
  default: heff_nomatch(v_p_2490);
  }
  heff_clo_take(self, 1);
  HeffT2 v_t_2494 = ({ V b_0 = heff_get_n(v_tk_2487, 1, 2); V a_1 = v_t_2493; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2493); r_; });
  {
    V v_field_2496 = v_t_2494.f[1];
    int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
    if ((v_tag_2495 == ((int64_t)0ULL))) {
      V v_x_2497 = v_field_2496;
      heff_drop(v_x_2497);
      V v_t_24100;
      switch (heff_tag_of(v_p_2490)) {
      case TAG_MkPair: {
        V v_x_2498 = heff_dup(heff_field(v_p_2490, 0));
        v_t_24100 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_p_2490);
      }
      V v_t_24103;
      switch (heff_tag_of(v_p_2490)) {
      case TAG_MkPair: {
        V v_y_24102 = heff_field(v_p_2490, 1);
        heff_take_n(v_p_2490, 2ULL, 2);
        v_t_24103 = v_y_24102;
        break;
      }
      default: heff_nomatch(v_p_2490);
      }
      V v_t_24104 = (g_list_2ekeepIf_24s512765522x2052101617(MK_INT(0LL), v_t_24103));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24100, v_t_24104});
    } else {
      heff_drop(v_field_2496);
      return v_p_2490;
    }
  }
}
V g_heff_2ecompile_2elower_2ercOf_lam0(V self, V *args);
V g_heff_2ecompile_2elower_2ercOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2elower_2ercOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ercOf_entry, 2, 0};

V g_heff_2ecompile_2elower_2ercOf(V v_facts_240, V v_md_241) {
top: ;
  V v_bor_242 = heff_dup(heff_rfield(v_facts_240, 3));
  V v_sg_243 = heff_rec_n(2, shape_sigs__flat, (V[]){heff_dup(heff_rfield(v_facts_240, 4)), heff_dup(heff_rfield(v_facts_240, 5))});
  V v_t_247;
  switch (heff_tag_of(v_md_241)) {
  case TAG_MkDef: {
    V v_k_244 = heff_dup(heff_field(v_md_241, 0));
    v_t_247 = v_k_244;
    break;
  }
  default: heff_nomatch(v_md_241);
  }
  HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_facts_240, 9); V a_1 = v_t_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_is_2412;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_is_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_is_2412 = NTAG(TAG_Nil);
    }
    V v_d_2413 = heff_dup(v_md_241);
    V v_evs_2436;
    switch (heff_tag_of(v_is_2412)) {
    case TAG_Nil: {
      v_evs_2436 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_243, v_d_2413));
      break;
    }
    case TAG_Cons: {
      V v_is_2416 = v_is_2412;
      V v_d_2417 = heff_dup(v_d_2413);
      V v_t_2433;
      switch (heff_tag_of(v_d_2417)) {
      case TAG_MkDef: {
        V v_d3_2420 = heff_field(v_d_2417, 2);
        heff_take_n(v_d_2417, 4ULL, 3);
        switch (heff_tag_of(v_d3_2420)) {
        case TAG_DefFun: {
          V v_xs_2421 = heff_field(v_d3_2420, 0);
          heff_take_n(v_d3_2420, 1ULL, 2);
          V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2421));
          V v_t_2424 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2423, MK_INT(1LL))));
          V v_t_2425 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_2421, v_t_2424));
          v_t_2433 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ercOf_lam0, 2, 1, (V[]){v_is_2416}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2425; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2425); r_; });
          break;
        }
        case TAG_DefVal: {
          heff_take_n(v_d3_2420, 0ULL, 1);
          heff_drop(v_is_2416);
          v_t_2433 = heff_dup(g_std_2eordmap_2eempty_get());
          break;
        }
        default: heff_nomatch(v_d3_2420);
        }
        break;
      }
      default: heff_nomatch(v_d_2417);
      }
      V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2easWord_clo), 1, (V[]){v_t_2433}));
      V v_t_2435 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_243, v_d_2413));
      v_evs_2436 = (g_list_2emap(v_t_2434, v_t_2435));
      break;
    }
    default: heff_nomatch(v_is_2412);
    }
    V v_pins_2437 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2436));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2436));
    V v_evs_2442 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ercOf_lam1, 2, 1, (V[]){v_pins_2437}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2438; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2438); r_; });
    V v_parent_2443 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2442));
    V v_t_2444 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2443, v_evs_2442));
    V v_t_2445 = ({ V a_0 = v_parent_2443; V a_1 = v_t_2444; V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V a_3 = v_evs_2442; V r_ = (g_list_2efoldl_24s1674844076x2137676876(a_0, a_1, a_2, a_3)); heff_drop(v_parent_2443); heff_drop(v_t_2444); heff_drop(v_evs_2442); r_; });
    HeffT4 v_t_2446 = (g_heff_2ecompile_2erefcount_2ercDef_24cpr(v_facts_240, v_t_2445, v_md_241));
    {
      V v_field_2448 = v_t_2446.f[1];
      V v_field_2449 = v_t_2446.f[2];
      V v_field_2450 = v_t_2446.f[3];
      int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
      V v_d_2459;
      if ((v_tag_2447 == ((int64_t)0ULL))) {
        heff_drop(v_field_2449);
        heff_drop(v_field_2450);
        V v_f_2451 = v_field_2448;
        V v_t_2452 = (g_heff_2ecompile_2ecaptures_2ecapStmts(heff_dup(v_bor_242), heff_take_field(v_f_2451, 3)));
        V v_t_2453 = (g_heff_2ecompile_2ecaptures_2ecapStmts(v_bor_242, heff_take_field(v_f_2451, 4)));
        V v_t_2454 = ({ V rv_3 = v_t_2452; V rv_4 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_f_2451, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        v_d_2459 = heff_tag_n(TAG_DFun, 1, (V[]){v_t_2454});
      } else {
        V v_key_2455 = v_field_2448;
        V v_ss_2456 = v_field_2449;
        V v_reprs_2457 = v_field_2450;
        V v_t_2458 = (g_heff_2ecompile_2ecaptures_2ecapStmts(v_bor_242, v_ss_2456));
        v_d_2459 = heff_tag_n(TAG_DVal, 3, (V[]){v_key_2455, v_t_2458, v_reprs_2457});
      }
      V v_x1_2469;
      switch (heff_tag_of(v_d_2459)) {
      case TAG_DFun: {
        V v_f_2460 = heff_field(v_d_2459, 0);
        V v_ru_24d_2459_24DFun = heff_take_reuse_n(v_d_2459, 1ULL, 1);
        V v_t_2461 = (g_heff_2ecompile_2eowned_2eloops(NTAG(TAG_False), heff_rfield(v_f_2460, 4)));
        V v_t_2465;
        if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
          heff_drop(v_t_2461);
          V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_2460, 1)));
          V v_t_2463 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2462, MK_INT(1LL))));
          V v_t_2464 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(heff_rfield(v_f_2460, 1)), v_t_2463));
          v_t_2465 = (g_list_2efoldl_24s1061624263x1097104198(v_f_2460, v_t_2464));
        } else {
          heff_drop(v_t_2461);
          v_t_2465 = v_f_2460;
        }
        v_x1_2469 = heff_tag_at_n(v_ru_24d_2459_24DFun, TAG_DFun, 1, (V[]){v_t_2465});
        break;
      }
      case TAG_DVal: {
        v_x1_2469 = v_d_2459;
        break;
      }
      default: heff_nomatch(v_d_2459);
      }
      V v_d_2478;
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_DFun: {
        V v_f_2470 = heff_field(v_x1_2469, 0);
        V v_ru_24x1_2469_24DFun = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
        V v_t_2471 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), heff_take_field(v_f_2470, 3)));
        V v_t_2472 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), heff_take_field(v_f_2470, 4)));
        V v_t_2473 = ({ V rv_3 = v_t_2471; V rv_4 = v_t_2472; V rr_ = heff_rec_reuse_nf(v_f_2470, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        v_d_2478 = heff_tag_at_n(v_ru_24x1_2469_24DFun, TAG_DFun, 1, (V[]){v_t_2473});
        break;
      }
      case TAG_DVal: {
        V v_k_2474 = heff_field(v_x1_2469, 0);
        V v_ss_2475 = heff_field(v_x1_2469, 1);
        V v_rs_2476 = heff_field(v_x1_2469, 2);
        V v_ru_24x1_2469_24DVal = heff_take_reuse_n(v_x1_2469, 7ULL, 3);
        V v_t_2477 = (g_heff_2ecompile_2etested_2efixStmts(heff_dup(g_heff_2ecompile_2etested_2enothingKnown_get()), v_ss_2475));
        v_d_2478 = heff_tag_re_n(v_ru_24x1_2469_24DVal, TAG_DVal, 3, 5ULL, (V[]){v_k_2474, v_t_2477, v_rs_2476});
        break;
      }
      default: heff_nomatch(v_x1_2469);
      }
      V v_x1_2489;
      switch (heff_tag_of(v_d_2478)) {
      case TAG_DFun: {
        V v_f_2479 = heff_field(v_d_2478, 0);
        V v_ru_24d_2478_24DFun = heff_take_reuse_n(v_d_2478, 1ULL, 1);
        V v_ags_2480 = (g_list_2efoldl_24s2015232937x23400545(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_2479, 4))));
        V v_t_2485;
        switch (heff_tag_of(v_ags_2480)) {
        case TAG_Nil: {
          v_t_2485 = v_f_2479;
          break;
        }
        case TAG_Cons: {
          V v_t_2483 = (g_heff_2ecompile_2ebounds_2elabelled(NTAG(TAG_False), heff_rfield(v_f_2479, 4)));
          if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
            heff_drop_tag(v_ags_2480, 2);
            heff_drop(v_t_2483);
            v_t_2485 = v_f_2479;
          } else {
            heff_drop(v_t_2483);
            V v_t_2484 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_2479, 4))));
            v_t_2485 = (g_heff_2ecompile_2ebounds_2eboundsWith(v_f_2479, v_t_2484, v_ags_2480));
          }
          break;
        }
        default: heff_nomatch(v_ags_2480);
        }
        v_x1_2489 = heff_tag_at_n(v_ru_24d_2478_24DFun, TAG_DFun, 1, (V[]){v_t_2485});
        break;
      }
      case TAG_DVal: {
        v_x1_2489 = v_d_2478;
        break;
      }
      default: heff_nomatch(v_d_2478);
      }
      V v_t_2498;
      switch (heff_tag_of(v_x1_2489)) {
      case TAG_DFun: {
        V v_f_2490 = heff_field(v_x1_2489, 0);
        V v_ru_24x1_2489_24DFun = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
        V v_t_2491 = (g_list_2emap_24s1478286876x830244177(heff_take_field(v_f_2490, 3)));
        V v_t_2492 = (g_list_2emap_24s1478286876x830244177(heff_take_field(v_f_2490, 4)));
        V v_t_2493 = ({ V rv_3 = v_t_2491; V rv_4 = v_t_2492; V rr_ = heff_rec_reuse_nf(v_f_2490, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        v_t_2498 = heff_tag_at_n(v_ru_24x1_2489_24DFun, TAG_DFun, 1, (V[]){v_t_2493});
        break;
      }
      case TAG_DVal: {
        V v_x_2494 = heff_field(v_x1_2489, 0);
        V v_ss_2495 = heff_field(v_x1_2489, 1);
        V v_rs_2496 = heff_field(v_x1_2489, 2);
        V v_ru_24x1_2489_24DVal = heff_take_reuse_n(v_x1_2489, 7ULL, 3);
        V v_t_2497 = (g_list_2emap_24s1478286876x830244177(v_ss_2495));
        v_t_2498 = heff_tag_re_n(v_ru_24x1_2489_24DVal, TAG_DVal, 3, 5ULL, (V[]){v_x_2494, v_t_2497, v_rs_2496});
        break;
      }
      default: heff_nomatch(v_x1_2489);
      }
      return (g_heff_2ecompile_2estatics_2estaticDef(v_t_2498));
    }
  }
}
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ercOf(a[0], a[1]);
}
V g_heff_2ecompile_2elower_2ercOf_lam0(V self, V *args) {
  V v_m_2426 = args[0];
  V v_p_2427 = args[1];
  V v_is_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = ({ V a_0 = v_p_2427; V a_1 = v_is_2416; V r_ = (g_list_2eany_24s1266267134x726671983(a_0, a_1)); heff_drop(v_is_2416); r_; });
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_t_2428);
    V v_t_2431;
    switch (heff_tag_of(v_p_2427)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_p_2427, 0);
      heff_take_n(v_p_2427, 1ULL, 2);
      v_t_2431 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_p_2427);
    }
    return ({ V a_0 = v_m_2426; V a_1 = v_t_2431; V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
  } else {
    heff_drop(v_p_2427);
    heff_drop(v_t_2428);
    return v_m_2426;
  }
}
V g_heff_2ecompile_2elower_2ercOf_lam1(V self, V *args) {
  V v_acc_2439 = args[0];
  V v_x_2440 = args[1];
  V v_pins_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = ({ V a_0 = v_pins_2437; V a_1 = v_x_2440; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2437); r_; });
  return (g_prelude_2e_2b_2b(v_t_2441, v_acc_2439));
}
Clo g_heff_2ecompile_2elower_2erevOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_entry, 2, 0};

V g_heff_2ecompile_2elower_2erevOnto(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2erevOnto(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2elower_2eerasedPieces_str0, 2, ": ");
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eerasedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eerasedPieces_entry, 3, 0};

V g_heff_2ecompile_2elower_2eerasedPieces(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_244 = heff_strAppend(heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2elower_2eerasedPieces_str0)), v_err_243);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_take_field(v_acc_241, 1)});
    return ({ V rv_1 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_241, 5ULL, 3, shape_pieces__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Right: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_body_247 = heff_field(v_x31_246, 0);
      V v_n_248 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(MK_INT(0LL), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), heff_dup(v_body_247)}), v_body_247));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_b_2412 = v_field_2410;
        V v_acc_2413 = v_field_2411;
        V v_defs_2414 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_acc_2413, 0, 2), heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_k_240), heff_dup(v_k_240), v_b_2412})));
        V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2414));
        V v_t_2416 = (g_list_2efoldl_24s644510009x1719377493(NTAG(TAG_Nil), v_t_2415));
        V v_t_2420 = ({ V a_0 = heff_take_field(v_acc_241, 0); V b_1 = heff_clo_n(g_heff_2ecompile_2elower_2eerasedPieces_lam0, 1, 1, (V[]){v_k_240}); V a_2 = v_t_2416; V r_ = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        return ({ V rv_0 = v_t_2420; V rv_2 = v_n_248; V rr_ = heff_rec_reuse_nf(v_acc_241, 2ULL, 3, shape_pieces__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2elower_2eerasedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2eerasedPieces(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2elower_2eerasedPieces_lam0(V self, V *args) {
  V v_d_2417 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_2418 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_2417, 2))));
  V v_t_2419 = (g_heff_2ecompile_2eir_2enubI(v_t_2418));
  heff_clo_take(self, 1);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){v_k_240, heff_dup(heff_rfield(v_d_2417, 0)), heff_dup(heff_rfield(v_d_2417, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_d_2417}), v_t_2419});
}
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2epieceStep_str1, 0, "");
V g_heff_2ecompile_2elower_2epieceStep_lam1(V self, V *args);
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2epieceStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2epieceStep_entry, 5, 0};

V g_heff_2ecompile_2elower_2epieceStep(V v_g_240, V v_vers_241, V v_ks_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_246, 3))));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop_rec(v_ks_242, 3);
      heff_drop(v_k_245);
      heff_drop_rec(v_e_246, 4);
      heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
      heff_drop(v_t_247);
      return v_acc_243;
    } else {
      heff_drop(v_t_247);
      HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_ks_242, 0, 3); V a_1 = v_k_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_it1_2411 = v_field_2410;
          switch (heff_tag_of(v_it1_2411)) {
          case TAG_MkPair: {
            V v_v_2412 = heff_field(v_it1_2411, 0);
            V v_us_2413 = heff_field(v_it1_2411, 1);
            heff_take_n(v_it1_2411, 3ULL, 2);
            V v_t_2427;
            if (heff_strEq_c_lent(v_v_2412, ((V)&g_heff_2ecompile_2elower_2epieceStep_str0), 2)) {
              heff_drop(v_v_2412);
              v_t_2427 = NTAG(TAG_False);
            } else {
              HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_241, v_k_245));
              V v_t_2430;
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x_2417 = v_field_2416;
                  v_t_2430 = v_x_2417;
                } else {
                  heff_drop(v_field_2416);
                  v_t_2430 = ((V)&g_heff_2ecompile_2elower_2epieceStep_str1);
                }
              }
              v_t_2427 = heff_strEq(v_v_2412, v_t_2430);
            }
            switch (heff_tag_of(v_t_2427)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24x5_244_24MkPair, 2);
              V v_t_2423 = ({ V a_0 = heff_take_field(v_acc_243, 0); V b_1 = heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_lam0, 1, 3, (V[]){v_k_245, v_g_240, v_e_246}); V a_2 = v_us_2413; V r_ = (g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(a_0, b_1, a_2)); heff_drop(b_1); r_; });
              return ({ V rv_0 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_pieces__errors__supply, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            }
            case TAG_False: {
              heff_drop(v_us_2413);
              V v_t_2424 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(heff_rfield(v_acc_243, 2))));
              return (g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_244_24MkPair, v_k_245, v_acc_243, v_t_2424));
            }
            default: return heff_nomatch(v_t_2427);
            }
          }
          default: return heff_nomatch(v_it1_2411);
          }
        } else {
          heff_drop(v_field_2410);
          V v_t_2425 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(heff_rfield(v_acc_243, 2))));
          return (g_heff_2ecompile_2elower_2eerasedPieces_24tok2(v_ru_24x5_244_24MkPair, v_k_245, v_acc_243, v_t_2425));
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2elower_2epieceStep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2epieceStep(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2epieceStep_lam1(V self, V *args) {
  V v_n_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_e_246 = heff_env(self)[2];
  V v_def_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_240, heff_dup(v_k_245), v_e_246, heff_dup(v_n_2421)));
  return ({ V a_0 = v_k_245; V b_1 = heff_get_n(v_def_2419, 0, 7); V a_2 = v_n_2421; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2elower_2eredoErased(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_t_2422); r_; });
}
V g_heff_2ecompile_2elower_2epieceStep_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_e_246 = heff_env(self)[2];
  V v_def_2419 = heff_take_field(v_u_2418, 0);
  V v_refs_2420 = heff_get_n(v_u_2418, 1, 2);
  heff_clo_take(self, 3);
  return heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(v_k_245), heff_dup(heff_rfield(v_def_2419, 0)), heff_dup(heff_rfield(v_def_2419, 1)), heff_tag_n(TAG_Kept, 2, (V[]){heff_dup(v_def_2419), heff_clo_n(g_heff_2ecompile_2elower_2epieceStep_lam1, 1, 4, (V[]){v_g_240, v_k_245, v_e_246, v_def_2419})}), v_refs_2420});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eunitVers_str1, 1, "-");
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2eunitVers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitVers_entry, 2, 0};

V g_heff_2ecompile_2elower_2eunitVers(V v_vers_240, V v_ps_241) {
top: ;
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2eunitVers_lam0, 2, 1, (V[]){heff_dup(v_vers_240)}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ps_241; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitVers(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2eunitVers_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_vers_240 = heff_env(self)[0];
  V v_owner_244 = heff_take_field(v_p_243, 0);
  V v_key_245 = heff_get_n(v_p_243, 1, 5);
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V a_0 = v_vers_240; V a_1 = v_owner_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_vers_240); heff_drop(v_owner_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_v_249 = v_field_248;
      if (heff_strEq_c_lent(v_v_249, ((V)&g_heff_2ecompile_2elower_2eunitVers_str0), 2)) {
        heff_drop(v_key_245);
        heff_drop(v_v_249);
        return v_m_242;
      } else {
        HeffT2 v_t_2410 = ({ V a_0 = v_v_249; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); HeffT2 r_ = (g_heff_2ecompile_2eirtext_2ebytesH_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_v_249); r_; });
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_a_2413 = v_field_2411;
          V v_b_2414 = v_field_2412;
          V v_x3_2415 = (g_heff_2ecompile_2eirtext_2ebytesH(v_key_245, MK_INT(0LL), v_a_2413, v_b_2414));
          V v_t_2416 = v_x3_2415;
          V v_t_2420;
          switch (heff_tag_of(v_t_2416)) {
          case TAG_MkPair: {
            V v_a_2417 = heff_field(v_t_2416, 0);
            V v_b_2418 = heff_field(v_t_2416, 1);
            heff_take_n(v_t_2416, 3ULL, 2);
            V v_t_2419 = heff_strAppend(heff_intShow(v_a_2417), ((V)&g_heff_2ecompile_2elower_2eunitVers_str1));
            v_t_2420 = heff_strAppend(v_t_2419, heff_intShow(v_b_2418));
            break;
          }
          default: heff_nomatch(v_t_2416);
          }
          return ({ V a_0 = v_m_242; V a_1 = v_key_245; V a_2 = v_t_2420; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_245); heff_drop(v_t_2420); r_; });
        }
      }
    } else {
      heff_drop(v_key_245);
      heff_drop(v_field_248);
      return v_m_242;
    }
  }
}
Clo g_heff_2ecompile_2elower_2eunitOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eunitOut_entry, 3, 0};

V g_heff_2ecompile_2elower_2eunitOut(V v_sg_240, V v_dm_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2elower_2eunitOut_24cpr(v_sg_240, v_dm_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2elower_2eunitOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2eunitOut(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args);
Clo g_heff_2ecompile_2elower_2ereachedPieces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2ereachedPieces_entry, 1, 0};

V g_heff_2ecompile_2elower_2ereachedPieces(V v_ps_240) {
top: ;
  V v_refs_241 = (g_list_2efoldl_24s1522661722x1369236455(heff_dup(g_std_2eordmap_2eempty_get()), v_ps_240));
  HeffT2 v_t_242 = ({ V b_0 = heff_dup(g_std_2eordmap_2eempty_get()); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_r_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_refs_241);
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      v_r_2413 = heff_dup(g_std_2eordmap_2eempty_get());
    } else {
      heff_drop(v_field_244);
      V v_t_246 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      HeffT2 v_t_247 = ({ V a_0 = v_refs_241; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2411;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_t_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_t_2411 = NTAG(TAG_Nil);
        }
        V v_t_2412 = (g_heff_2ecompile_2eshake_2eappendK(v_t_2411, NTAG(TAG_Nil)));
        v_r_2413 = ({ V a_0 = v_refs_241; V a_1 = v_t_246; V a_2 = v_t_2412; V r_ = (g_heff_2ecompile_2eshake_2ereachBy(a_0, a_1, a_2)); heff_drop(v_refs_241); r_; });
      }
    }
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2elower_2ereachedPieces_lam0, 1, 1, (V[]){v_r_2413}); V a_1 = v_ps_240; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  }
}
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2elower_2ereachedPieces(a[0]);
}
V g_heff_2ecompile_2elower_2ereachedPieces_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_r_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_r_2413; V b_1 = heff_get_n(v_p_2414, 1, 5); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_r_2413); heff_drop(b_1); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2416 == ((int64_t)0ULL)) && ({ V v_x_2418 = heff_dup(v_field_2417); int c_ = 1; heff_drop(v_x_2418); c_; })));
    heff_drop(v_field_2417);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str3, 1, ".");

HeffT3 g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(V v_lit_240, V v_fuel_241, V v_works_242, V v_sk_243) {
top: ;
  V v_simplified_244 = heff_take_field(v_sk_243, 0);
  V v_errors_245 = heff_take_field(v_sk_243, 1);
  V v_groups_246 = heff_take_field(v_sk_243, 2);
  V v_copies_247 = heff_get_n(v_sk_243, 3, 4);
  V v_t_249;
  if ((heff_dup(v_fuel_241) == NTAG(TAG_True))) {
    v_t_249 = NTAG(TAG_Nil);
  } else {
    V v_t_248 = (g_heff_2eelab_2eeffect_2eleaves(v_lit_240));
    v_t_249 = (g_list_2emap_24s89148281x951607804(((V)&g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str0), MK_INT(0LL), ((V)&g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str1), MK_INT(0LL), ((V)&g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str2), ((V)&g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr_str3), v_t_248));
  }
  V v_si_2410 = v_simplified_244;
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2ecKept_clo), 3, (V[]){v_fuel_241, v_t_249, v_works_242}));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_2413 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2412, v_si_2410));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tr(g_heff_2ecompile_2elower_2efusedWith(v_t_2411, v_t_2414, v_errors_245, v_t_2413));
  V v_f_2416 = v_groups_246;
  V v_f_2417 = v_copies_247;
  return ((HeffT3){{v_t_2415, v_f_2416, v_f_2417}});
}
HEFF_LIT(g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_str1, 0, "");
Clo g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_entry, 5, 0};

V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584(V v_due_240, V v_w_241, V v_vers_242, V v_key_243, V v_n_244) {
top: ;
  HeffT2 v_t_245 = ({ V b_0 = heff_dup(g_std_2eordmap_2eempty_get()); V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_248 = v_field_247;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_MkPair: {
        V v_v_249 = heff_field(v_it1_248, 0);
        V v_us_2410 = heff_field(v_it1_248, 1);
        V v_ru_24it1_248_24MkPair = heff_take_reuse_n(v_it1_248, 3ULL, 2);
        V v_t_2424;
        if (heff_strEq_c_lent(v_v_249, ((V)&g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_str0), 2)) {
          heff_drop(v_v_249);
          v_t_2424 = NTAG(TAG_False);
        } else {
          HeffT2 v_t_2411 = ({ V a_0 = v_vers_242; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          V v_t_2427;
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x_2414 = v_field_2413;
              v_t_2427 = v_x_2414;
            } else {
              heff_drop(v_field_2413);
              v_t_2427 = ((V)&g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_str1);
            }
          }
          v_t_2424 = heff_strEq(v_v_249, v_t_2427);
        }
        switch (heff_tag_of(v_t_2424)) {
        case TAG_True: {
          heff_drop(v_n_244);
          HEFF_LAST return g_list_2emap_24s136093287x730789464_24tok2(v_ru_24it1_248_24MkPair, v_due_240, v_w_241, v_key_243, v_us_2410);
        }
        case TAG_False: {
          heff_drop(v_us_2410);
          V v_body_2415;
          switch (heff_tag_of(v_due_240)) {
          case TAG_NoCustody: {
            v_body_2415 = (g_heff_2ecompile_2elower_2eentryCps(v_w_241, v_key_243, v_n_244));
            break;
          }
          case TAG_Reading: {
            v_body_2415 = (g_heff_2ecompile_2elower_2eentryReading(v_w_241, v_key_243, v_n_244));
            break;
          }
          default: heff_nomatch(v_due_240);
          }
          V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_body_2415)));
          V v_t_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
          V v_t_2418 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_2415})});
          return heff_tag_at_n(v_ru_24it1_248_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2418, v_t_2417}), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_t_2424);
        }
      }
      default: return heff_nomatch(v_it1_248);
      }
    } else {
      heff_drop(v_field_247);
      V v_body_2419;
      switch (heff_tag_of(v_due_240)) {
      case TAG_NoCustody: {
        v_body_2419 = (g_heff_2ecompile_2elower_2eentryCps(v_w_241, v_key_243, v_n_244));
        break;
      }
      case TAG_Reading: {
        v_body_2419 = (g_heff_2ecompile_2elower_2eentryReading(v_w_241, v_key_243, v_n_244));
        break;
      }
      default: heff_nomatch(v_due_240);
      }
      V v_t_2420 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_body_2419)));
      V v_t_2421 = (g_heff_2ecompile_2eir_2enubI(v_t_2420));
      V v_t_2422 = heff_tag_n(TAG_Fresh, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_body_2419})});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2422, v_t_2421}), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry, 3, 0};

V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(V v_acc_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_acc_240});
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_acc_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2elower_2erevOnto_24f1922153946x696963623(a[0], a1, a[2]); heff_drop(a1); return r;
}