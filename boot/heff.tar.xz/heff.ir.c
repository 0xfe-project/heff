// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eir_2ebaseGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2ebaseGo_entry, 2, 0};

V g_heff_2eir_2ebaseGo(V v_x_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return v_x_240;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241)), MK_INT(36LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_t_243);
      return heff_strSlice(v_x_240, MK_INT(0LL), v_i_241);
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eir_2ebaseGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2ebaseGo(a[0], a[1]);
}
Clo g_heff_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2eappendI_entry, 2, 0};

V g_heff_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eir_2eappendI(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2eappendI(a[0], a[1]);
}
V g_heff_2eir_2enubI_lam0(V self, V *args);
Clo g_heff_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2enubI_entry, 1, 0};

V g_heff_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2eir_2enubI_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eir_2enubI(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2enubI(a[0]);
}
V g_heff_2eir_2enubI_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eir_2efreshBindOne_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2eir_2efreshBindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2efreshBindOne_entry, 2, 0};

V g_heff_2eir_2efreshBindOne(V v_acc_240, V v_x_241) {
top: ;
  V v_base_242 = (g_heff_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_n_243 = heff_get(heff_dup(v_acc_240), LBL_n);
  V v_x_27_244 = heff_strAppend(v_base_242, heff_strAppend(((V)&g_heff_2eir_2efreshBindOne_str0), heff_intShow(heff_dup(v_n_243))));
  V v_t_245 = (g_map_2einsert_24s7(v_x_241, heff_dup(v_x_27_244), heff_get(heff_dup(v_acc_240), LBL_m)));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_x_27_244, heff_get(v_acc_240, LBL_xs)});
  return heff_rec(3, shape_175_189_362, (V[]){v_t_245, heff_intAdd(v_n_243, MK_INT(1LL)), v_t_246});
}
V g_heff_2eir_2efreshBindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2efreshBindOne(a[0], a[1]);
}
Clo g_heff_2eir_2efreshMany_24s531_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2efreshMany_24s531_entry, 3, 0};

V g_heff_2eir_2efreshMany_24s531(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_x4_242);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse(v_x4_242, 3ULL);
    V v_t_245 = (g_heff_2eir_2efreshGo_24s530(heff_dup(v_m_240), v_n_241, v_e_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_e_27_246 = heff_field(v_t_245, 0);
      V v_n1_247 = heff_field(v_t_245, 1);
      heff_take(v_t_245, 3ULL);
      V v_x2_248 = (g_heff_2eir_2efreshMany_24s531(v_m_240, v_n1_247, v_rest_244));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_es_249 = heff_field(v_x2_248, 0);
        V v_n_2410 = heff_field(v_x2_248, 1);
        heff_take(v_x2_248, 3ULL);
        return heff_tag_at(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_e_27_246, v_es_249}), v_n_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eir_2efreshMany_24s531_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2efreshMany_24s531(a[0], a[1], a[2]);
}
Clo g_heff_2eir_2efreshFields_24s532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2efreshFields_24s532_entry, 3, 0};

V g_heff_2eir_2efreshFields_24s532(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_x4_242);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse(v_x4_242, 3ULL);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x41_243, 0);
      V v_e_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse(v_x41_243, 3ULL);
      V v_t_247 = (g_heff_2eir_2efreshGo_24s530(heff_dup(v_m_240), v_n_241, v_e_246));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_e_27_248 = heff_field(v_t_247, 0);
        V v_n1_249 = heff_field(v_t_247, 1);
        heff_take(v_t_247, 3ULL);
        V v_x2_2410 = (g_heff_2eir_2efreshFields_24s532(v_m_240, v_n1_249, v_rest_244));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_MkPair: {
          V v_fs_2411 = heff_field(v_x2_2410, 0);
          V v_n_2412 = heff_field(v_x2_2410, 1);
          heff_take(v_x2_2410, 3ULL);
          V v_t_2413 = heff_tag_at(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_e_27_248}), v_fs_2411});
          return heff_tag_at(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eir_2efreshFields_24s532_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2efreshFields_24s532(a[0], a[1], a[2]);
}
Clo g_heff_2eir_2efreshArms_24s533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2efreshArms_24s533_entry, 3, 0};

V g_heff_2eir_2efreshArms_24s533(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_x4_242);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse(v_x4_242, 3ULL);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkArm: {
      V v_tag_245 = heff_field(v_x41_243, 0);
      V v_vars_246 = heff_field(v_x41_243, 1);
      V v_body_247 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24MkArm = heff_take_reuse(v_x41_243, 7ULL);
      V v_t_248 = heff_rec(3, shape_175_189_362, (V[]){heff_dup(v_m_240), v_n_241, NTAG(TAG_Nil)});
      V v_v_249 = ({ V a_0 = v_t_248; V a_1 = v_vars_246; V r_ = (g_prelude_2efoldl_24s529(a_0, a_1)); heff_drop(v_vars_246); r_; });
      V v_t_2410 = (g_heff_2eir_2efreshGo_24s530(heff_get(heff_dup(v_v_249), LBL_m), heff_get(heff_dup(v_v_249), LBL_n), v_body_247));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_b_27_2411 = heff_field(v_t_2410, 0);
        V v_n1_2412 = heff_field(v_t_2410, 1);
        heff_take(v_t_2410, 3ULL);
        V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_v_249, LBL_xs)));
        V v_a_2414 = heff_tag_at(v_ru_24x41_243_24MkArm, TAG_MkArm, 3, (V[]){v_tag_245, v_t_2413, v_b_27_2411});
        V v_x2_2415 = (g_heff_2eir_2efreshArms_24s533(v_m_240, v_n1_2412, v_rest_244));
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_MkPair: {
          V v_as_2416 = heff_field(v_x2_2415, 0);
          V v_n_2417 = heff_field(v_x2_2415, 1);
          heff_take(v_x2_2415, 3ULL);
          return heff_tag_at(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_a_2414, v_as_2416}), v_n_2417});
        }
        default: return heff_nomatch(v_x2_2415);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eir_2efreshArms_24s533_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2efreshArms_24s533(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eir_2efreshGo_24s530_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2eir_2efreshGo_24s530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2efreshGo_24s530_entry, 3, 0};

V g_heff_2eir_2efreshGo_24s530(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse(v_e_242, 1ULL);
    V v_t_244 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      v_t_246 = v_x_243;
      break;
    }
    case TAG_Just: {
      V v_y_245 = heff_field(v_t_244, 0);
      heff_take(v_t_244, 1ULL);
      heff_drop(v_x_243);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_t_246}), v_n_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2410 = heff_rec(3, shape_175_189_362, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s529(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2412 = (g_heff_2eir_2efreshGo_24s530(heff_get(heff_dup(v_v_2411), LBL_m), heff_get(heff_dup(v_v_2411), LBL_n), v_b_249));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_27_2413 = heff_field(v_t_2412, 0);
      V v_n_27_2414 = heff_field(v_t_2412, 1);
      heff_take(v_t_2412, 3ULL);
      V v_t_2415 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_v_2411, LBL_xs)));
      return heff_tag_at(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2415, v_b_27_2413}), v_n_27_2414});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_EApp: {
    V v_f_2416 = heff_field(v_e_242, 0);
    V v_as_2417 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2418 = (g_heff_2eir_2efreshGo_24s530(heff_dup(v_m_240), v_n_241, v_f_2416));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_MkPair: {
      V v_f_27_2419 = heff_field(v_t_2418, 0);
      V v_n1_2420 = heff_field(v_t_2418, 1);
      heff_take(v_t_2418, 3ULL);
      V v_t_2421 = (g_heff_2eir_2efreshMany_24s531(v_m_240, v_n1_2420, v_as_2417));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_MkPair: {
        V v_as_27_2422 = heff_field(v_t_2421, 0);
        V v_n2_2423 = heff_field(v_t_2421, 1);
        heff_take(v_t_2421, 3ULL);
        return heff_tag_at(v_ru_24e_242_24EApp, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_27_2419, v_as_27_2422}), v_n2_2423});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_ELet: {
    V v_x_2424 = heff_field(v_e_242, 0);
    V v_a_2425 = heff_field(v_e_242, 1);
    V v_b_2426 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse(v_e_242, 7ULL);
    V v_t_2427 = (g_heff_2eir_2efreshGo_24s530(heff_dup(v_m_240), v_n_241, v_a_2425));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_a_27_2428 = heff_field(v_t_2427, 0);
      V v_n1_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse(v_t_2427, 3ULL);
      V v_base_2430 = (g_heff_2eir_2ebaseGo(heff_dup(v_x_2424), MK_INT(0LL)));
      V v_x_27_2431 = heff_strAppend(v_base_2430, heff_strAppend(((V)&g_heff_2eir_2efreshGo_24s530_str0), heff_intShow(heff_dup(v_n1_2429))));
      V v_m_2432 = (g_map_2einsert_24s7(v_x_2424, heff_dup(v_x_27_2431), v_m_240));
      V v_t_2433 = (g_heff_2eir_2efreshGo_24s530(v_m_2432, heff_intAdd(v_n1_2429, MK_INT(1LL)), v_b_2426));
      switch (heff_tag_of(v_t_2433)) {
      case TAG_MkPair: {
        V v_b_27_2434 = heff_field(v_t_2433, 0);
        V v_n3_2435 = heff_field(v_t_2433, 1);
        heff_take(v_t_2433, 3ULL);
        return heff_tag_at(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2431, v_a_27_2428, v_b_27_2434}), v_n3_2435});
      }
      default: return heff_nomatch(v_t_2433);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse(v_e_242, 1ULL);
    V v_t_2437 = (g_heff_2eir_2efreshFields_24s532(v_m_240, v_n_241, v_fs_2436));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_MkPair: {
      V v_fs_27_2438 = heff_field(v_t_2437, 0);
      V v_n1_2439 = heff_field(v_t_2437, 1);
      V v_ru_24t_2437_24MkPair = heff_take_reuse(v_t_2437, 3ULL);
      return heff_tag_at(v_ru_24t_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs_27_2438}), v_n1_2439});
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  case TAG_EProj: {
    V v_e2_2440 = heff_field(v_e_242, 0);
    V v_l_2441 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2442 = (g_heff_2eir_2efreshGo_24s530(v_m_240, v_n_241, v_e2_2440));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_MkPair: {
      V v_e_27_2443 = heff_field(v_t_2442, 0);
      V v_n1_2444 = heff_field(v_t_2442, 1);
      heff_take(v_t_2442, 3ULL);
      return heff_tag_at(v_ru_24e_242_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_27_2443, v_l_2441}), v_n1_2444});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_e_242, 0);
    V v_as_2446 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2447 = (g_heff_2eir_2efreshMany_24s531(v_m_240, v_n_241, v_as_2446));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_as_27_2448 = heff_field(v_t_2447, 0);
      V v_n1_2449 = heff_field(v_t_2447, 1);
      heff_take(v_t_2447, 3ULL);
      return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2445, v_as_27_2448}), v_n1_2449});
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EMatch: {
    V v_s_2450 = heff_field(v_e_242, 0);
    V v_arms_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2452 = (g_heff_2eir_2efreshGo_24s530(heff_dup(v_m_240), v_n_241, v_s_2450));
    switch (heff_tag_of(v_t_2452)) {
    case TAG_MkPair: {
      V v_s_27_2453 = heff_field(v_t_2452, 0);
      V v_n1_2454 = heff_field(v_t_2452, 1);
      heff_take(v_t_2452, 3ULL);
      V v_t_2455 = (g_heff_2eir_2efreshArms_24s533(v_m_240, v_n1_2454, v_arms_2451));
      switch (heff_tag_of(v_t_2455)) {
      case TAG_MkPair: {
        V v_arms_27_2456 = heff_field(v_t_2455, 0);
        V v_n2_2457 = heff_field(v_t_2455, 1);
        heff_take(v_t_2455, 3ULL);
        return heff_tag_at(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_2453, v_arms_27_2456}), v_n2_2457});
      }
      default: return heff_nomatch(v_t_2455);
      }
    }
    default: return heff_nomatch(v_t_2452);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EPrimCall: {
    V v_p_2459 = heff_field(v_e_242, 0);
    V v_as_2460 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2461 = (g_heff_2eir_2efreshMany_24s531(v_m_240, v_n_241, v_as_2460));
    switch (heff_tag_of(v_t_2461)) {
    case TAG_MkPair: {
      V v_as_27_2462 = heff_field(v_t_2461, 0);
      V v_n1_2463 = heff_field(v_t_2461, 1);
      heff_take(v_t_2461, 3ULL);
      return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2459, v_as_27_2462}), v_n1_2463});
    }
    default: return heff_nomatch(v_t_2461);
    }
  }
  case TAG_ECall: {
    V v_g_2464 = heff_field(v_e_242, 0);
    V v_as_2465 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2466 = (g_heff_2eir_2efreshMany_24s531(v_m_240, v_n_241, v_as_2465));
    switch (heff_tag_of(v_t_2466)) {
    case TAG_MkPair: {
      V v_as_27_2467 = heff_field(v_t_2466, 0);
      V v_n1_2468 = heff_field(v_t_2466, 1);
      heff_take(v_t_2466, 3ULL);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_2464, v_as_27_2467}), v_n1_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eir_2efreshGo_24s530_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2efreshGo_24s530(a[0], a[1], a[2]);
}
V g_heff_2eir_2esubstGo_lam0(V self, V *args);
V g_heff_2eir_2esubstGo_lam1(V self, V *args);
V g_heff_2eir_2esubstGo_lam2(V self, V *args);
V g_heff_2eir_2esubstGo_lam3(V self, V *args);
V g_heff_2eir_2esubstGo_lam4(V self, V *args);
V g_heff_2eir_2esubstGo_lam5(V self, V *args);
Clo g_heff_2eir_2esubstGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2esubstGo_entry, 2, 0};

V g_heff_2eir_2esubstGo(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse(v_e_241, 1ULL);
    V v_t_243 = (g_map_2elookup_24s8(heff_dup(v_x_242), v_m_240));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      return heff_tag_at(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
    }
    case TAG_Just: {
      V v_e2_244 = heff_field(v_t_243, 0);
      heff_take(v_t_243, 1ULL);
      heff_drop(v_x_242);
      heff_drop(v_ru_24e_241_24EVar);
      return v_e2_244;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse(v_e_241, 3ULL);
    return heff_tag_at(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2eir_2esubstGo(v_m_240, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_241, 0);
    V v_as_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2410 = (g_heff_2eir_2esubstGo(v_m_240, v_f_248));
    return heff_tag_at(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, (g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_249))});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_e_241, 0);
    V v_a_2413 = heff_field(v_e_241, 1);
    V v_b_2414 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse(v_e_241, 7ULL);
    V v_t_2415 = (g_heff_2eir_2esubstGo(v_m_240, v_a_2413));
    return heff_tag_at(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2412, v_t_2415, (g_heff_2eir_2esubstGo(v_m_240, v_b_2414))});
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse(v_e_241, 1ULL);
    return heff_tag_at(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2416))});
  }
  case TAG_EProj: {
    V v_e2_2420 = heff_field(v_e_241, 0);
    V v_l_2421 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EProj = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2422 = (g_heff_2eir_2esubstGo(v_m_240, v_e2_2420));
    return heff_tag_at(v_ru_24e_241_24EProj, TAG_EProj, 2, (V[]){v_t_2422, v_l_2421});
  }
  case TAG_ETag: {
    V v_t_2423 = heff_field(v_e_241, 0);
    V v_as_2424 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse(v_e_241, 3ULL);
    return heff_tag_at(v_ru_24e_241_24ETag, TAG_ETag, 2, (V[]){v_t_2423, (g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2424))});
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_e_241, 0);
    V v_arms_2427 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2428 = (g_heff_2eir_2esubstGo(v_m_240, v_s_2426));
    return heff_tag_at(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2428, (g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2427))});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_2434 = heff_field(v_e_241, 0);
    V v_as_2435 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse(v_e_241, 3ULL);
    return heff_tag_at(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2434, (g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2435))});
  }
  case TAG_ECall: {
    V v_g_2437 = heff_field(v_e_241, 0);
    V v_as_2438 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse(v_e_241, 3ULL);
    return heff_tag_at(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_2437, (g_prelude_2emap(heff_clo(g_heff_2eir_2esubstGo_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2438))});
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eir_2esubstGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2esubstGo(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eir_2esubstGo_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2411; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2eir_2esubstGo_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_p_2417, 0);
    V v_e2_2419 = heff_field(v_p_2417, 1);
    V v_ru_24p_2417_24MkPair = heff_take_reuse(v_p_2417, 3ULL);
    return heff_tag_at(v_ru_24p_2417_24MkPair, TAG_MkPair, 2, (V[]){v_l_2418, ({ V a_0 = v_m_240; V a_1 = v_e2_2419; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; })});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_heff_2eir_2esubstGo_lam2(V self, V *args) {
  V v_a_2425 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2425; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2eir_2esubstGo_lam3(V self, V *args) {
  V v_a_2429 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_t_2430 = heff_field(v_a_2429, 0);
    V v_vs_2431 = heff_field(v_a_2429, 1);
    V v_b_2432 = heff_field(v_a_2429, 2);
    V v_ru_24a_2429_24MkArm = heff_take_reuse(v_a_2429, 7ULL);
    return heff_tag_at(v_ru_24a_2429_24MkArm, TAG_MkArm, 3, (V[]){v_t_2430, v_vs_2431, ({ V a_0 = v_m_240; V a_1 = v_b_2432; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; })});
  }
  default: return heff_nomatch(v_a_2429);
  }
}
V g_heff_2eir_2esubstGo_lam4(V self, V *args) {
  V v_a_2436 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2436; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2eir_2esubstGo_lam5(V self, V *args) {
  V v_a_2439 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2439; V r_ = (g_heff_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2epushArms_entry, 2, 0};

V g_heff_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take(v_a_242, 4ULL);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_heff_2eir_2epushArms(v_as_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2epushFields_entry, 2, 0};

V g_heff_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take(v_p_242, 2ULL);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eir_2epushFields(v_fs_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2eir_2ecountW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2ecountW_entry, 3, 0};

V g_heff_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_x3_242);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take(v_x31_243, 1ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V v_t_246 = heff_strEq(v_y_245, heff_dup(v_x_240));
      V v_t_247;
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_t_246);
        v_t_247 = heff_intAdd(v_n_241, MK_INT(1LL));
        break;
      }
      case TAG_False: {
        heff_drop(v_t_246);
        v_t_247 = v_n_241;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V t_0 = v_x_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 2ULL);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2410, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x31_243, 0);
      V v_as_2412 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 3ULL);
      V v_t_2413 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2411, (g_heff_2eir_2eappendI(v_as_2412, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2413;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x31_243, 1);
      V v_b_2416 = heff_field(v_x31_243, 2);
      heff_take(v_x31_243, 6ULL);
      V v_t_2417 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag(TAG_Cons, 2, (V[]){v_b_2416, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2417;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x31_243, 0);
      heff_take(v_x31_243, 1ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V v_t_2419 = (g_heff_2eir_2epushFields(v_fs_2418, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2419;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take(v_x31_243, 1ULL);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2423 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 2ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V v_t_2424 = (g_heff_2eir_2eappendI(v_as_2423, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2424;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2425 = heff_field(v_x31_243, 0);
      V v_arms_2426 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 3ULL);
      V v_t_2427 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2425, (g_heff_2eir_2epushArms(v_arms_2426, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2427;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2430 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 2ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V v_t_2431 = (g_heff_2eir_2eappendI(v_as_2430, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2431;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2433 = heff_field(v_x31_243, 1);
      heff_take(v_x31_243, 2ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V v_t_2434 = (g_heff_2eir_2eappendI(v_as_2433, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2434;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop(v_x31_243);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take(v_x31_243, 0ULL);
      heff_drop(v_ru_24x3_242_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eir_2ecountW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2ecountW(a[0], a[1], a[2]);
}
Clo g_heff_2eir_2elamW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2elamW_entry, 2, 0};

V g_heff_2eir_2elamW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      V v_t_248 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_a_249 = (g_heff_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_248));
      V v_t_2410 = heff_intLt(MK_INT(0LL), v_a_249);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_2410);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x21_242, 0);
      V v_as_2412 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_2413 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2411, (g_heff_2eir_2eappendI(v_as_2412, v_rest_243))});
      V t_0 = v_x_240;
      V t_1 = v_t_2413;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x21_242, 1);
      V v_b_2416 = heff_field(v_x21_242, 2);
      heff_take(v_x21_242, 6ULL);
      V v_t_2417 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag(TAG_Cons, 2, (V[]){v_b_2416, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2417;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x21_242, 0);
      heff_take(v_x21_242, 1ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2419 = (g_heff_2eir_2epushFields(v_fs_2418, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2419;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x21_242, 0);
      heff_take(v_x21_242, 1ULL);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2423 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2424 = (g_heff_2eir_2eappendI(v_as_2423, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2424;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2425 = heff_field(v_x21_242, 0);
      V v_arms_2426 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_2427 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2425, (g_heff_2eir_2epushArms(v_arms_2426, v_rest_243))});
      V t_0 = v_x_240;
      V t_1 = v_t_2427;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2430 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2431 = (g_heff_2eir_2eappendI(v_as_2430, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2431;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2433 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2434 = (g_heff_2eir_2eappendI(v_as_2433, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2434;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop(v_x21_242);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eir_2elamW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2elamW(a[0], a[1]);
}
Clo g_heff_2eir_2esizeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2esizeW_entry, 2, 0};

V g_heff_2eir_2esizeW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return v_n_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_2410 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, (g_heff_2eir_2eappendI(v_as_249, v_rest_243))});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2410;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take(v_x21_242, 6ULL);
      V v_t_2414 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2414;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take(v_x21_242, 1ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2416 = (g_heff_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2416;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2417 = heff_field(v_x21_242, 0);
      heff_take(v_x21_242, 1ULL);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2420 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2421 = (g_heff_2eir_2eappendI(v_as_2420, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2421;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2422 = heff_field(v_x21_242, 0);
      V v_arms_2423 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 3ULL);
      V v_t_2424 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2422, (g_heff_2eir_2epushArms(v_arms_2423, v_rest_243))});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2424;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2427 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2428 = (g_heff_2eir_2eappendI(v_as_2427, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2428;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2430 = heff_field(v_x21_242, 1);
      heff_take(v_x21_242, 2ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_2431 = (g_heff_2eir_2eappendI(v_as_2430, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2431;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop(v_x21_242);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take(v_x21_242, 0ULL);
      heff_drop(v_ru_24x2_241_24Cons);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eir_2esizeW_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2esizeW(a[0], a[1]);
}
Clo g_heff_2eir_2esizeB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2esizeB_entry, 3, 0};

V g_heff_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    heff_drop(v_x3_242);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = heff_intLt(heff_dup(v_lim_240), heff_dup(v_n_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_lim_240);
      heff_drop(v_e_243);
      heff_drop(v_rest_244);
      heff_drop(v_ru_24x3_242_24Cons);
      heff_drop(v_t_245);
      return v_n_241;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EVar: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EGlobal: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELam: {
        V v_b_249 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 2ULL);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_2410 = heff_field(v_e_243, 0);
        V v_as_2411 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 3ULL);
        V v_t_2412 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, (g_heff_2eir_2eappendI(v_as_2411, v_rest_244))});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2412;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        V v_a_2414 = heff_field(v_e_243, 1);
        V v_b_2415 = heff_field(v_e_243, 2);
        heff_take(v_e_243, 6ULL);
        V v_t_2416 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2416;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_e_243, 0);
        heff_take(v_e_243, 1ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V v_t_2418 = (g_heff_2eir_2epushFields(v_fs_2417, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2418;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        V v_e2_2419 = heff_field(v_e_243, 0);
        heff_take(v_e_243, 1ULL);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2419, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        V v_as_2422 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 2ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V v_t_2423 = (g_heff_2eir_2eappendI(v_as_2422, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2423;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        V v_sc_2424 = heff_field(v_e_243, 0);
        V v_arms_2425 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 3ULL);
        V v_t_2426 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2424, (g_heff_2eir_2epushArms(v_arms_2425, v_rest_244))});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2426;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrim: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_as_2429 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 2ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V v_t_2430 = (g_heff_2eir_2eappendI(v_as_2429, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2430;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_as_2432 = heff_field(v_e_243, 1);
        heff_take(v_e_243, 2ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V v_t_2433 = (g_heff_2eir_2eappendI(v_as_2432, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2433;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EInt: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EStr: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EAbandon: {
        heff_drop(v_e_243);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFix: {
        heff_take(v_e_243, 0ULL);
        heff_drop(v_ru_24x3_242_24Cons);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e_243);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eir_2esizeB_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2esizeB(a[0], a[1], a[2]);
}
Clo g_heff_2eir_2econcatMapI_24s534_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2econcatMapI_24s534_entry, 1, 0};

V g_heff_2eir_2econcatMapI_24s534(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eir_2eglobalsGo(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eir_2econcatMapI_24s534(v_xs_242));
    return (g_heff_2eir_2eappendI(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eir_2econcatMapI_24s534_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2econcatMapI_24s534(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eir_2econcatMapI_24s535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2econcatMapI_24s535_entry, 1, 0};

V g_heff_2eir_2econcatMapI_24s535(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_e2_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2eir_2eglobalsGo(heff_dup(v_e2_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eir_2econcatMapI_24s535(v_xs_242));
    return (g_heff_2eir_2eappendI(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eir_2econcatMapI_24s535_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2econcatMapI_24s535(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eir_2econcatMapI_24s536_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2econcatMapI_24s536_entry, 1, 0};

V g_heff_2eir_2econcatMapI_24s536(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_b_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = (g_heff_2eir_2eglobalsGo(v_t_246));
    V v_t_248 = (g_heff_2eir_2econcatMapI_24s536(v_xs_242));
    return (g_heff_2eir_2eappendI(v_t_247, v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eir_2econcatMapI_24s536_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2econcatMapI_24s536(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2eir_2eglobalsGo(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_e_240, 0);
    heff_take(v_e_240, 1ULL);
    return heff_tag(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_e_240, 1);
    heff_take(v_e_240, 2ULL);
    V t_0 = v_b_244;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_as_246 = heff_field(v_e_240, 1);
    heff_take(v_e_240, 3ULL);
    V v_t_247 = (g_heff_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_as_246; V r_ = (g_heff_2eir_2econcatMapI_24s534(a_0)); heff_drop(v_as_246); r_; });
    return (g_heff_2eir_2eappendI(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_e_240, 1);
    V v_b_2411 = heff_field(v_e_240, 2);
    heff_take(v_e_240, 6ULL);
    V v_t_2412 = (g_heff_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_e_240, 0);
    heff_take(v_e_240, 1ULL);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2eir_2econcatMapI_24s535(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2415 = heff_field(v_e_240, 0);
    heff_take(v_e_240, 1ULL);
    V t_0 = v_e2_2415;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2418 = heff_field(v_e_240, 1);
    heff_take(v_e_240, 2ULL);
    return ({ V a_0 = v_as_2418; V r_ = (g_heff_2eir_2econcatMapI_24s534(a_0)); heff_drop(v_as_2418); r_; });
  }
  case TAG_EMatch: {
    V v_s_2419 = heff_field(v_e_240, 0);
    V v_arms_2420 = heff_field(v_e_240, 1);
    heff_take(v_e_240, 3ULL);
    V v_t_2421 = (g_heff_2eir_2eglobalsGo(v_s_2419));
    V v_t_2422 = ({ V a_0 = v_arms_2420; V r_ = (g_heff_2eir_2econcatMapI_24s536(a_0)); heff_drop(v_arms_2420); r_; });
    return (g_heff_2eir_2eappendI(v_t_2421, v_t_2422));
  }
  case TAG_EPrim: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2425 = heff_field(v_e_240, 1);
    heff_take(v_e_240, 2ULL);
    return ({ V a_0 = v_as_2425; V r_ = (g_heff_2eir_2econcatMapI_24s534(a_0)); heff_drop(v_as_2425); r_; });
  }
  case TAG_ECall: {
    V v_g_2426 = heff_field(v_e_240, 0);
    V v_as_2427 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ECall = heff_take_reuse(v_e_240, 3ULL);
    return heff_tag_at(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){v_g_2426, ({ V a_0 = v_as_2427; V r_ = (g_heff_2eir_2econcatMapI_24s534(a_0)); heff_drop(v_as_2427); r_; })});
  }
  case TAG_EInt: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_e_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2eglobalsGo(a[0]);
}
Clo g_heff_2eir_2eallI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2eallI_entry, 1, 0};

V g_heff_2eir_2eallI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_b_241)) {
    case TAG_True: {
      V t_0 = v_bs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eir_2eallI_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2eallI(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2eisValue_entry, 1, 0};

V g_heff_2eir_2eisValue(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_e_240, 0);
    V v_t_2411 = (g_prelude_2emap_24s537(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2411; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2411); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2415 = heff_field(v_e_240, 1);
    V v_t_2416 = (g_prelude_2emap_24s538(heff_dup(v_as_2415)));
    return ({ V a_0 = v_t_2416; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2416); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eir_2eisValue(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eir_2espine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eir_2espine_entry, 1, 0};

V g_heff_2eir_2espine(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_as_246 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse(v_e_240, 3ULL);
    V v_x2_247 = (g_heff_2eir_2espine(v_f_245));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_h_248 = heff_field(v_x2_247, 0);
      V v_bs_249 = heff_field(v_x2_247, 1);
      heff_take(v_x2_247, 3ULL);
      return heff_tag_at(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){v_h_248, (g_heff_2eir_2eappendI(v_bs_249, v_as_246))});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_ELet: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eir_2espine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eir_2espine(a[0]);
}