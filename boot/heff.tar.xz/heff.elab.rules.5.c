// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CUndelay 45232
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_RestoreDelayed 1107
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_ctx 308385
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_witness 1587180415
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_witness__instantiated__state[] = {LBL_witness, LBL_instantiated, LBL_state};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_array_2eempty_get(void);
V g_co_2ebind_24s1601686549x58384075(V, V, V, V);
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a);
extern Clo g_co_2ebind_24s1601686549x58384075_clo;
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ememoed_2especializeM(V, V, V);
V g_heff_2eelab_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2especializeM_clo;
V g_heff_2eelab_2ememoed_2esumM(V);
V g_heff_2eelab_2ememoed_2esumM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2esumM_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2eforcedRb(V);
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eforcedRb_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eapartForced(V, V, V);
V g_heff_2eelab_2erules_2eapartForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartForced_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eboundGo(V, V, V);
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_clo;
V g_heff_2eelab_2erules_2eboundGo_24dps(V, V, V, V);
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
V g_heff_2eelab_2erules_2echeckFixed(V, V, V, V);
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFixed_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edefaultChk(V, V, V);
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultChk_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edescribes(V);
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribes_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2efixEnv(V, V, V);
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efixEnv_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstantiate(V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enamesFor_24dps(V, V);
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo;
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
V g_heff_2eelab_2erules_2enotGiven(V, V, V);
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotGiven_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2erecChk(V, V);
V g_heff_2eelab_2erules_2erecChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecChk_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etraverseE(V, V);
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etraverseE_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s12178679x44040905_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1966236437x1225976932(V, V);
V g_list_2efilter_24s1966236437x1225976932_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_clo;
V g_list_2efoldl_24f1128388138x103163567(V, V, V, V);
V g_list_2efoldl_24f1128388138x103163567_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1128388138x103163567_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2eelab_2erules_2eanyIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eanyIdxGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eanyIdxGo(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_i_240);
      heff_drop(v_f_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_f_241;
      V t_2 = v_xs_244;
      v_i_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eanyIdxGo(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enamesFor_24dps_str0, 1, "x");
Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2enamesFor_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_243 = heff_intShow(heff_intSub(heff_dup(v_n_240), MK_INT(1LL)));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_24dps_str0), v_t_243), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_cell_244;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamesFor_24dps(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etyStrZ_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_lam0, 1, 0};
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrZ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_entry, 4, 0};

V g_heff_2eelab_2erules_2etyStrZ(V v_e_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etyStrZ_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_246}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam1, 1, 3, (V[]){v_e_240, v_t_241, v_k_243})});
}
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrZ(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2etyStrZ_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get_n(v_c_244, 3, 8);
}
V g_heff_2eelab_2erules_2etyStrZ_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2414 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2413)));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_x2_2417 = ({ V a_0 = v_t_2416; V a_1 = v_x_2413; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2416); r_; });
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nothing: {
    return v_d_2414;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    heff_drop(v_d_2414);
    return v_x_2418;
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2eelab_2erules_2etyStrZ_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_249, v_t_241));
  V v_t_2411 = ({ V a_0 = v_x_248; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_248); r_; });
  V v_t_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 2), 1, (V[]){v_t_2410}));
  V v_t_2419 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_lam2, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2420 = heff_tr(heff_call(heff_get_n(v_t_2419, 1, 2), 1, (V[]){v_t_2412}));
  V v_t_2421 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  V v_x_2422 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2421; V a_3 = v_t_2420; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); r_; });
  V f_ = v_k_243;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ekeepRecovered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ekeepRecovered_entry, 5, 0};

V g_heff_2eelab_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam0, 1, 1, (V[]){v_kept_240})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam1, 1, 4, (V[]){v_hd_243, v_saved_241, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ekeepRecovered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_kept_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_kept_240, heff_take_field(v_c_245, 1)});
  return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_245, 253ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args) {
  V v_c_2415 = args[0];
  V v_saved_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_5 = heff_get_n(v_saved_241, 5, 8); V rr_ = heff_rec_reuse_nf(v_c_2415, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_RestoreDelayed, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2425}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2426;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_waiting_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam5, 1, 3, (V[]){v_waiting_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_saved_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam3, 1, 1, (V[]){v_saved_241})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam4, 1, 3, (V[]){v_hd_243, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_saved_241 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam2, 1, 4, (V[]){v_saved_241, v_hd_243, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2egoalShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egoalShown_entry, 3, 0};

V g_heff_2eelab_2erules_2egoalShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_241));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_t_243, 1, 2), 2, (V[]){v_t_244, v_goal_242}));
  V v_t_2412 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2egoalShown_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2413 = heff_tr(heff_call(heff_get_n(v_t_2412, 1, 2), 1, (V[]){v_t_245}));
  V v_t_2414 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2414; V a_3 = v_t_2413; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
}
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2egoalShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2egoalShown_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_x2_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_246; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_249); r_; });
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    return v_d_247;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    heff_drop(v_d_247);
    return v_x_2411;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einstGlobal_str0, 12, "declared by ");
HEFF_LIT(g_heff_2eelab_2erules_2einstGlobal_str1, 12, "declared by ");
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstGlobal_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einstGlobal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstGlobal_entry, 2, 0};

V g_heff_2eelab_2erules_2einstGlobal(V v_e_240, V v_i_241) {
top: ;
  V v_g_242 = heff_dup(heff_rfield(v_e_240, 1));
  V v_k_243 = heff_dup(heff_rfield(v_i_241, 0));
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_243), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(v_k_243, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_240, 6);
      heff_drop_rec(v_i_241, 2);
      heff_drop_rec(v_g_242, 7);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_k2_246 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_k2_246; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_e_240, 6);
        heff_drop_rec(v_i_241, 2);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ge_248 = heff_field(v_t_247, 0);
        V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
        V v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2einstGlobal_str0), heff_dup(heff_rfield(v_i_241, 1)));
        V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_SGlobal, 1, (V[]){heff_dup(heff_rfield(v_i_241, 0))});
        V v_t_2418 = heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstGlobal_lam0, 1, 2, (V[]){v_i_241, v_e_240}), v_t_249, NTAG(TAG_True), heff_take_field(v_ge_248, 3), v_t_2410, heff_get_n(v_ge_248, 2, 4)});
        return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2418});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_e_2419 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    heff_drop_rec(v_g_242, 7);
    heff_drop(v_k_243);
    V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2erules_2einstGlobal_str1), heff_dup(heff_rfield(v_i_241, 1)));
    V v_t_2421 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_dup(heff_rfield(v_i_241, 0))});
    V v_t_2429 = heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstGlobal_lam1, 1, 2, (V[]){v_i_241, v_e_240}), v_t_2420, NTAG(TAG_True), heff_take_field(v_e_2419, 3), v_t_2421, heff_get_n(v_e_2419, 2, 4)});
    return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2429});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstGlobal(a[0], a[1]);
}
V g_heff_2eelab_2erules_2einstGlobal_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  V v_x_2412 = heff_get_n(v_i_241, 0, 2);
  V v_d_2413 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2412)));
  V v_t_2414 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_x2_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_2412; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nothing: {
    return v_d_2413;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    heff_drop(v_d_2413);
    return v_x_2417;
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2eelab_2erules_2einstGlobal_lam1(V self, V *args) {
  V v_u_2422 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_x_2423 = heff_get_n(v_i_241, 0, 2);
  V v_d_2424 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2423)));
  V v_t_2425 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_2425); r_; });
  V v_x2_2427 = ({ V a_0 = v_t_2426; V a_1 = v_x_2423; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2426); r_; });
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nothing: {
    return v_d_2424;
  }
  case TAG_Just: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    heff_take_n(v_x2_2427, 1ULL, 1);
    heff_drop(v_d_2424);
    return v_x_2428;
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam0, 1, 0};
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam2, 1, 0};
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2efits_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_lam7, 1, 0};
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efits_entry, 6, 0};

V g_heff_2eelab_2erules_2efits(V v_e_240, V v_sp_241, V v_goal_242, V v_w_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2efits_lam1, 1, 6, (V[]){v_w_243, v_goal_242, v_k_245, v_hd_244, v_e_240, v_sp_241})});
}
V g_heff_2eelab_2erules_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  return heff_get_n(v_c_246, 3, 8);
}
V g_heff_2eelab_2erules_2efits_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  return v_c_2415;
}
V g_heff_2eelab_2erules_2efits_lam5(V self, V *args) {
  V v_p_2423 = args[0];
  V v_p_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2422, 0), heff_get_n(v_c_2422, 1, 4)});
  V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_get_n(v_e_240, 1, 6), v_t_2425, v_goal_242, heff_get_n(v_x_2421, 1, 3)}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2426, v_p_2423, v_p_2424));
}
V g_heff_2eelab_2erules_2efits_lam7(V self, V *args) {
  V v_c_2430 = args[0];
  return v_c_2430;
}
V g_heff_2eelab_2erules_2efits_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_r_2427 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_k_2429 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2438);
  V v_t_2441;
  switch (heff_tag_of(v_r_2427)) {
  case TAG_Left: {
    heff_take_n(v_r_2427, 0ULL, 1);
    heff_drop_rec(v_w_243, 6);
    heff_drop_rec(v_x_2421, 3);
    heff_drop(v_x_2434);
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_ru_24r_2427_24Right = heff_take_reuse_n(v_r_2427, 0ULL, 1);
    v_t_2441 = heff_tag_at_n(v_ru_24r_2427_24Right, TAG_Just, 1, (V[]){heff_rec_n(3, shape_witness__instantiated__state, (V[]){v_w_243, v_x_2421, v_x_2434})});
    break;
  }
  default: heff_nomatch(v_r_2427);
  }
  V f_ = v_k_2429;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efits_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_r_2427 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_k_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2435 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})}));
  V f_ = heff_get_n(v_hd_2428, 1, 3);
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam9, 1, 5, (V[]){v_r_2427, v_w_243, v_x_2421, v_x_2434, v_k_2429});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam6(V self, V *args) {
  V v_r_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_x_2419 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam7_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2428, 2)), 1, (V[]){v_t_2432}));
  V f_ = heff_dup(heff_rfield(v_hd_2428, 1));
  args[0] = v_t_2433;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam8, 1, 6, (V[]){v_x_2419, v_hd_2428, v_r_2427, v_w_243, v_x_2421, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efits_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2422 = heff_dup(heff_rfield(v_e_240, 0));
  return (g_co_2ebind_24s1601686549x58384075(heff_clo_n(g_heff_2eelab_2erules_2efits_lam5, 2, 4, (V[]){v_c_2422, v_e_240, v_goal_242, heff_dup(v_x_2421)}), heff_clo_n(g_heff_2eelab_2erules_2efits_lam6, 3, 3, (V[]){v_x_2419, v_w_243, v_x_2421}), v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2efits_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_243 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_goal_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420 = (g_heff_2eelab_2erules_2einstantiate(heff_dup(v_e_240), v_sp_241, heff_dup(v_w_243)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam4, 1, 6, (V[]){v_e_240, v_goal_242, v_x_2419, v_w_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_243 = heff_env(self)[0];
  V v_goal_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = heff_dup(heff_rfield(v_w_243, 2));
  V v_t_2414;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    V v_conclusion_2412 = (g_heff_2eelab_2erules_2econclusionOf(MK_INT(0LL), heff_dup(heff_rfield(v_w_243, 3))));
    V v_t_2413 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2410, heff_dup(v_goal_242)));
    v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = v_t_2413; V a_2 = v_conclusion_2412; V r_ = (g_heff_2eelab_2erules_2eapartForced(a_0, a_1, a_2)); heff_drop(v_x_2410); heff_drop(v_t_2413); heff_drop(v_conclusion_2412); r_; });
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_t_2411);
    v_t_2414 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop_rec(v_w_243, 6);
    heff_drop(v_goal_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_t_2414);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2414);
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efits_lam2_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efits_lam3, 1, 6, (V[]){v_e_240, v_sp_241, v_w_243, v_hd_244, v_goal_242, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eeachSubgoal_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeachSubgoal_lam0, 2, 0};
V g_heff_2eelab_2erules_2eeachSubgoal_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eeachSubgoal_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eeachSubgoal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeachSubgoal_entry, 2, 0};

V g_heff_2eelab_2erules_2eeachSubgoal(V v_find_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_find_240);
    return ((V)&g_heff_2eelab_2erules_2eeachSubgoal_lam0_clo);
  }
  case TAG_Cons: {
    V v_sg_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_find_240), 1, (V[]){heff_dup(v_sg_244)}));
    return heff_clo_n(g_heff_2eelab_2erules_2eeachSubgoal_lam1, 2, 3, (V[]){v_c_246, v_find_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eeachSubgoal(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_find_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_249);
  V v_t_2410 = ({ V a_0 = v_find_240; V a_1 = v_rest_245; V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_find_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eeachSubgoal_lam2, 1, 4, (V[]){v_find_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str1, 21, "  [ready at the call]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str2, 23, "  [waits for implicits]");
HEFF_LIT(g_heff_2eelab_2erules_2einsertInstance_str3, 7, "wanted ");
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2einsertInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_lam1, 1, 0};
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertInstance_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertInstance(V v_e_240, V v_sp_241, V v_goal_242, V v_name_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_246; V a_1 = v_t_247; V a_2 = heff_dup(v_goal_242); V a_3 = v_name_243; V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_244); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam0, 1, 5, (V[]){v_hd_244, v_sp_241, v_e_240, v_goal_242, v_k_245}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
}
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertInstance(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertInstance_lam1(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2erules_2einsertInstance_lam3(V self, V *args) {
  V v_u_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2414);
  V v_t_2415 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)));
  V v_t_2416 = ({ V a_0 = v_x_2413; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2413); r_; });
  V v_t_2417 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2417, v_goal_242}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str1);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2418, 0ULL, 2);
    v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertInstance_str2);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2einsertInstance_str3), heff_strAppend(v_t_2415, v_t_2421));
}
V g_heff_2eelab_2erules_2einsertInstance_lam5(V self, V *args) {
  V v_b_2425 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_take_field(v_x_248, 0);
  V v_t_2462;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2426, 0ULL, 3);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2451 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 3);
    v_t_2462 = v_k_2451;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2426, 0ULL, 2);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2426, 0ULL, 1);
    v_t_2462 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return (g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2462, heff_get_n(v_x_248, 1, 2), v_goal_242, v_b_2425, heff_dup(v_hd_244), heff_get_n(v_hd_244, 0, 3)));
}
V g_heff_2eelab_2erules_2einsertInstance_lam7(V self, V *args) {
  V v_u_2467 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_248, 1, 2)});
}
V g_heff_2eelab_2erules_2einsertInstance_lam6(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2468 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam7, 1, 1, (V[]){heff_dup(v_x_248)}); V rr_ = heff_rec_reuse_nf(v_x_248, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2einsertInstance_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2424);
  V v_t_2463 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam5, 1, 5, (V[]){heff_dup(v_x_248), v_e_240, v_sp_241, v_goal_242, heff_dup(v_hd_244)}), NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2464}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2465;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam6, 1, 2, (V[]){v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2einsertInstance_str0), heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam3, 1, 3, (V[]){heff_dup(v_e_240), v_x_2413, heff_dup(v_goal_242)})}), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam4, 1, 6, (V[]){v_sp_241, v_x_248, v_e_240, v_goal_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2einsertInstance_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2einsertInstance_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertInstance_lam2, 1, 6, (V[]){v_sp_241, v_e_240, v_goal_242, v_hd_244, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str0, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str4, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str5, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str6, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str7, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str8, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str9, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str10, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str11, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntro_str12, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2efunctionIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntro_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntro(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntro(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntro_lam4(V self, V *args) {
  V v_u_2428 = args[0];
  V v_v_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_v_2423;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam7(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2444 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2446 = heff_take_field(v_e_243, 2);
  V v_t_2449;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_ForNominative: {
    v_t_2449 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2446, 0ULL, 2);
    v_t_2449 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2452 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2451, heff_dup(v_x_2411)));
  V v_x_2454 = (g_heff_2eelab_2ememoed_2elam(v_t_2449, heff_get_n(v_e_243, 1, 6), v_t_2450, heff_rec_n(2, shape_stx__val, (V[]){v_t_2452, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2445})));
  V f_ = v_k_2444;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam3(V self, V *args) {
  V v_v_2423 = args[0];
  V v_scope_27_2424 = args[1];
  V v_cod_2420 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2430;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2426 = heff_field(v_cod_2420, 1);
    V v_body_2427 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2430 = heff_tr(heff_call(v_body_2427, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2426, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam4, 1, 1, (V[]){heff_dup(v_v_2423)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2429 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    v_x1_2430 = v_body_2429;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2434;
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nom: {
    V v_x_2431 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_a_2434 = v_x_2431;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2430, 0ULL, 1);
    v_a_2434 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2433 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_a_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x1_2430);
  }
  V v_c_2442;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2435 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2436 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2423);
      v_t_2439 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2437 = heff_field(v_t_2436, 0);
      V v_sp_2438 = heff_field(v_t_2436, 1);
      V v_ru_24t_2436_24ForDescriptive = heff_take_reuse_n(v_t_2436, 3ULL, 2);
      v_t_2439 = heff_tag_at_n(v_ru_24t_2436_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2437, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2438, v_v_2423})});
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    V v_t_2440 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2441 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2424, heff_dup(heff_rfield(v_e_243, 1)), v_t_2439, v_t_2440, heff_dup(heff_rfield(v_e_243, 4)), heff_dup(heff_rfield(v_e_243, 5))});
    v_c_2442 = heff_tr(heff_call(v_f_2435, 2, (V[]){v_t_2441, v_a_2434}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam5, 2, 4, (V[]){v_c_2442, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam9(V self, V *args) {
  V v_u_2467 = args[0];
  V v_v_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return v_v_2461;
}
V g_heff_2eelab_2erules_2efunctionIntro_lam12(V self, V *args) {
  V v_u_24103 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24103);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam11(V self, V *args) {
  V v_x_2490 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_cod_2420 = heff_env(self)[2];
  V v_k_2489 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2491 = heff_take_field(v_e_243, 2);
  V v_t_2494;
  switch (heff_tag_of(v_t_2491)) {
  case TAG_ForNominative: {
    v_t_2494 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2491, 0ULL, 2);
    v_t_2494 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2491);
  }
  V v_t_2495 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2496 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2497 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2496, heff_dup(v_x_2411)));
  V v_t_24102;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_n_2498 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 3);
    v_t_24102 = v_n_2498;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2420, 0ULL, 1);
    v_t_24102 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str3);
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_x_24104 = (g_heff_2eelab_2ememoed_2elam(v_t_2494, heff_get_n(v_e_243, 1, 6), v_t_2495, heff_rec_n(2, shape_stx__val, (V[]){v_t_2497, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam12, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24102, v_x_2490})));
  V f_ = v_k_2489;
  args[0] = v_x_24104;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam10(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2487;
  args[0] = v_hd_2488;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam11, 1, 4, (V[]){v_e_243, v_x_2411, v_cod_2420, v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntro_lam8(V self, V *args) {
  V v_v_2461 = args[0];
  V v_scope_27_2462 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_cod_2420 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_implicit_2421 = heff_env(self)[5];
  V v_dom_2419 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2463 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_body_242; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_body_242); r_; });
  V v_x1_2469;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2465 = heff_dup(heff_field(v_cod_2420, 1));
    V v_body_2466 = heff_dup(heff_field(v_cod_2420, 2));
    v_x1_2469 = heff_tr(heff_call(v_body_2466, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2465, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam9, 1, 1, (V[]){heff_dup(v_v_2461)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2468 = heff_dup(heff_field(v_cod_2420, 0));
    v_x1_2469 = v_body_2468;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2473;
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_Nom: {
    V v_x_2470 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    v_a_2473 = v_x_2470;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2469, 0ULL, 1);
    v_a_2473 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2472 = heff_field(v_x1_2469, 0);
    heff_take_n(v_x1_2469, 1ULL, 1);
    v_a_2473 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x1_2469);
  }
  V v_c_2487;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_MkChk: {
    V v_f_2474 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    V v_t_2475 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2478;
    switch (heff_tag_of(v_t_2475)) {
    case TAG_ForNominative: {
      v_t_2478 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2476 = heff_field(v_t_2475, 0);
      V v_sp_2477 = heff_field(v_t_2475, 1);
      V v_ru_24t_2475_24ForDescriptive = heff_take_reuse_n(v_t_2475, 3ULL, 2);
      v_t_2478 = heff_tag_at_n(v_ru_24t_2475_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2476, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2477, heff_dup(v_v_2461)})});
      break;
    }
    default: heff_nomatch(v_t_2475);
    }
    V v_t_2479 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2485;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      heff_drop(v_v_2461);
      heff_drop(v_dom_2419);
      v_t_2485 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2461);
      heff_drop(v_dom_2419);
      v_t_2485 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2484;
      switch (heff_tag_of(v_cod_2420)) {
      case TAG_MkClo: {
        V v_n_2480 = heff_dup(heff_field(v_cod_2420, 0));
        v_t_2484 = v_n_2480;
        break;
      }
      case TAG_CloConst: {
        v_t_2484 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str2);
        break;
      }
      default: heff_nomatch(v_cod_2420);
      }
      v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2484, v_dom_2419, v_v_2461}), heff_dup(heff_rfield(v_e_243, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    V v_t_2486 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2462, heff_dup(heff_rfield(v_e_243, 1)), v_t_2478, v_t_2479, heff_dup(heff_rfield(v_e_243, 4)), v_t_2485});
    v_c_2487 = heff_tr(heff_call(v_f_2474, 2, (V[]){v_t_2486, v_a_2473}));
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam10, 2, 4, (V[]){v_c_2487, v_e_243, v_x_2411, v_cod_2420});
}
V g_heff_2eelab_2erules_2efunctionIntro_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2417;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_implicit_2421);
      heff_drop(v_t_2422);
      V v_t_2455 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_dom_2419, heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam3, 2, 5, (V[]){v_cod_2420, v_body_242, v_e_243, v_x_2411, v_x_241})));
      V f_ = v_t_2455;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2422);
      V v_t_2460;
      switch (heff_tag_of(v_cod_2420)) {
      case TAG_MkClo: {
        V v_n_2456 = heff_dup(heff_field(v_cod_2420, 0));
        v_t_2460 = v_n_2456;
        break;
      }
      case TAG_CloConst: {
        v_t_2460 = ((V)&g_heff_2eelab_2erules_2efunctionIntro_str1);
        break;
      }
      default: heff_nomatch(v_cod_2420);
      }
      V v_t_24105 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2460, heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam8, 2, 8, (V[]){v_sp_240, v_x_241, v_body_242, v_cod_2420, v_e_243, v_implicit_2421, v_dom_2419, v_x_2411})));
      V f_ = v_t_24105;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24111}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24112;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24114 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24115 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24116}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24117;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24120}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24121;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24124}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24125;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
    V v_t_24129 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24128}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24129;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24131 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24132}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24133;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24136 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24137}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24138;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24140 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24141 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24142}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24143;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntro_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24145 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24146}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24147;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntro_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntro_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFields_entry, 5, 0};

V g_heff_2eelab_2erules_2echeckFields(V v_e_240, V v_v_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_z_243);
    V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tail(v_z_244, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x31_246, 0);
      V v_g_249 = heff_field(v_x31_246, 1);
      V v_c_2410 = heff_dup(heff_rfield(v_e_240, 0));
      V v_x1_2411 = (g_heff_2eelab_2evalue_2eproj(heff_dup(v_v_241), heff_dup(v_y_248)));
      V v_a_2415;
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nom: {
        V v_x_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        v_a_2415 = v_x_2412;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2411, 0ULL, 1);
        v_a_2415 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2414 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        v_a_2415 = v_x_2414;
        break;
      }
      default: heff_nomatch(v_x1_2411);
      }
      V v_t_2416 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2410, 0), heff_get_n(v_c_2410, 1, 4)});
      V v_t_2417 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), heff_dup(heff_rfield(v_e_240, 1)), v_t_2416, v_a_2415, heff_dup(v_g_249)));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2417, heff_dup(v_z_243), heff_clo_n(g_heff_2eelab_2erules_2echeckFields_lam0, 1, 5, (V[]){v_z_244, v_e_240, v_v_241, heff_dup(v_rest_247), v_z_243})));
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2echeckFields(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2echeckFields_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_rest_247);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2419});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2418, 0ULL, 1);
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_rest_247; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_247); r_; });
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2especializedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especializedGo_entry, 12, 0};

V g_heff_2eelab_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249, V v_p_2410, V v_p_2411) {
top: ;
  switch (heff_tag_of(v_sp_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpApp: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpProj: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpSpec: {
    V v_sq_2416 = heff_field(v_sp_244, 0);
    V v_x_2417 = heff_field(v_sp_244, 1);
    V v_f_2418 = heff_field(v_sp_244, 2);
    V v_c_2419 = heff_dup(heff_rfield(v_e_240, 0));
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam0, 2, 8, (V[]){v_c_2419, heff_dup(v_e_240), heff_dup(v_h_243), heff_dup(v_sq_2416), heff_dup(v_u_245), heff_dup(v_described_246), heff_dup(v_el_247), heff_dup(v_a_27_242)}), heff_dup(v_p_2410), heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam1, 1, 14, (V[]){heff_dup(v_x_2417), heff_dup(v_f_2418), v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, heff_dup(v_sq_2416), v_u_245, v_described_246, v_el_247, v_err_249, v_p_2410, v_p_2411})));
  }
  default: return heff_nomatch(v_sp_244);
  }
}
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2especializedGo(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args) {
  V v_p_2420 = args[0];
  V v_p_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_h_243 = heff_env(self)[2];
  V v_sq_2416 = heff_env(self)[3];
  V v_u_245 = heff_env(self)[4];
  V v_described_246 = heff_env(self)[5];
  V v_el_247 = heff_env(self)[6];
  V v_a_27_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2422 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2419, 0), heff_get_n(v_c_2419, 1, 4)});
  V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_get_n(v_e_240, 1, 6), v_t_2422, heff_tag_n(TAG_VDecode, 5, (V[]){v_h_243, v_sq_2416, v_u_245, v_described_246, v_el_247}), v_a_27_242}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2423, v_p_2420, v_p_2421));
}
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_f_2418 = heff_env(self)[1];
  V v_fields_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_a_27_242 = heff_env(self)[5];
  V v_h_243 = heff_env(self)[6];
  V v_sq_2416 = heff_env(self)[7];
  V v_u_245 = heff_env(self)[8];
  V v_described_246 = heff_env(self)[9];
  V v_el_247 = heff_env(self)[10];
  V v_err_249 = heff_env(self)[11];
  V v_p_2410 = heff_env(self)[12];
  V v_p_2411 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_a_27_242; V a_3 = v_h_243; V a_4 = v_sq_2416; V a_5 = v_u_245; V a_6 = v_described_246; V a_7 = v_el_247; V a_8 = v_t_2426; V a_9 = v_err_249; V a_10 = v_p_2410; V a_11 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2especializedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_sq_2416); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_sq_2416);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_err_249);
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_t_2428; V a_3 = v_p_2410; V a_4 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_t_2428, 2); r_; });
  }
  default: return heff_nomatch(v_x_2424);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_str0, 46, "can only use rec when checking at a small type");
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_str1, 97, "the definition would need itself while it is being computed: put the recursive use under a lambda");
V g_heff_2eelab_2erules_2erecChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2erecChk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_lam5, 1, 0};
V g_heff_2eelab_2erules_2erecChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_entry, 2, 0};

V g_heff_2eelab_2erules_2erecChk(V v_sp_240, V v_c_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam0, 2, 2, (V[]){v_sp_240, v_c_241})});
}
V g_heff_2eelab_2erules_2erecChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecChk(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2410}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  args[0] = v_t_2411;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(331LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam5(V self, V *args) {
  V v_u_2429 = args[0];
  heff_drop(v_u_2429);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2erecChk_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tag_n(TAG_SRec, 1, (V[]){heff_get_n(v_x_2427, 0, 2)});
  V f_ = v_k_2426;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2428, ((V)&g_heff_2eelab_2erules_2erecChk_lam5_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecChk_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam4, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2eelab_2evalue_2elevelOf(v_a_243));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Small: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Large: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_TopL: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    heff_drop(v_t_245);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam1, 2, 1, (V[]){v_sp_240});
  } else {
    heff_drop(v_t_245);
    if (heff_intEq_c(heff_dup(heff_rfield(v_e_242, 3)), MK_INT(0LL))) {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_a_243);
      heff_drop(v_c_241);
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam2, 2, 1, (V[]){v_sp_240});
    } else {
      heff_drop(v_sp_240);
      V v_sd_2419 = heff_take_field(v_e_242, 0);
      V v_c_2424;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkChk: {
        V v_f_2420 = heff_field(v_c_241, 0);
        V v_ru_24c_241_24MkChk = heff_take_reuse_n(v_c_241, 1ULL, 1);
        V v_t_2421 = heff_tag_at_n(v_ru_24c_241_24MkChk, TAG_CUndelay, 1, (V[]){heff_dup(heff_rfield(v_sd_2419, 3))});
        V v_t_2422 = ({ V rv_3 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_sd_2419, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        v_c_2424 = heff_tr(heff_call(v_f_2420, 2, (V[]){v_t_2423, v_a_243}));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_lam3, 2, 1, (V[]){v_c_2424});
    }
  }
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimInt_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimInt_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimInt_st;
static V g_heff_2eelab_2erules_2eprimInt_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimInt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimInt_st)) return g_heff_2eelab_2erules_2eprimInt_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimInt_val, &g_heff_2eelab_2erules_2eprimInt_st, g_heff_2eelab_2erules_2eprimInt_init);
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str9, 4, " to ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str10, 19, ", whose values are ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_str11, 21, " is out of range for ");
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eintAtFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_entry, 5, 0};

V g_heff_2eelab_2erules_2eintAtFixed(V v_sp_240, V v_w_241, V v_i_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_w_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_intShow(heff_dup(v_i_242)), heff_box_f64(heff_from_int_f64(v_i_242))));
    return heff_tail(v_t_246, 2, (V[]){v_z_243, v_z_244});
  } else {
    heff_drop(v_t_245);
    V v_t_247 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
    V v_t_2410 = heff_bool((heff_intLe_c(heff_dup(v_t_247), heff_dup(v_i_242)) && ({ V v_t_249 = (g_heff_2eelab_2efixed_2efixedMax(v_w_241)); int c_ = heff_intLe_c(heff_dup(v_i_242), heff_dup(v_t_249)); heff_drop(v_t_249); c_; })));
    heff_drop(v_t_247);
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop_rec(v_z_243, 3);
      heff_drop(v_t_2410);
      V v_t_2412 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_241, v_i_242}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_lam0_clo)});
      return heff_tail(v_z_244, 1, (V[]){v_t_2412});
    } else {
      heff_drop(v_t_2410);
      V v_t_2413;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str0);
        break;
      }
      case TAG_I16: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str1);
        break;
      }
      case TAG_I32: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str2);
        break;
      }
      case TAG_I64: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str3);
        break;
      }
      case TAG_U8: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str4);
        break;
      }
      case TAG_U16: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str5);
        break;
      }
      case TAG_U32: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str6);
        break;
      }
      case TAG_U64: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str7);
        break;
      }
      case TAG_F32: {
        v_t_2413 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_str8);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_t_2414 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
      V v_t_2415 = ({ V a_0 = v_w_241; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_241); r_; });
      V v_t_2416 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str9), heff_intShow(v_t_2415));
      V v_t_2417 = heff_strAppend(heff_intShow(v_t_2414), v_t_2416);
      V v_why_2418 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str10), v_t_2417));
      V v_t_2419 = heff_strAppend(heff_intShow(v_i_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_str11), v_why_2418));
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2419, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_2422}));
      return heff_tail(heff_get_n(v_z_243, 1, 3), 2, (V[]){v_t_2423, v_z_244});
    }
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eintAtFixed_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitChk_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitChk_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitChk(V v_sp_240, V v_lit_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam0, 4, 2, (V[]){v_sp_240, v_lit_241})});
}
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitChk(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitChk_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_t1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop(v_t_2432);
    V v_c_2433 = (g_heff_2eelab_2erules_2enumLitWait(MK_INT(1LL), heff_dup(v_sp_240), v_lit_241));
    return ({ V a_0 = v_e_242; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitChk_str0); V a_3 = v_c_2433; V a_4 = heff_dup(v_x_2410); V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2433); r_; });
  } else {
    heff_drop(v_t_2432);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_240, v_e_242, v_x_2410, v_lit_241, v_hd_244, v_k_245));
  }
}
V g_heff_2eelab_2erules_2enumLitChk_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_lam2, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultAt(V v_e_240, V v_i_241, V v_ty_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_i_241);
    heff_drop_rec(v_ty_242, 2);
    return ((V)&g_heff_2eelab_2erules_2edefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(heff_get_n(v_ty_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2411;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nom: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_a_2411 = v_x_248;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_247, 0ULL, 1);
      v_a_2411 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2410 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      v_a_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2412 = ({ V a_0 = heff_take_field(v_d_246, 1); V a_1 = v_i_241; V b_2 = heff_get_n(v_d_246, 0, 2); V r_ = (g_heff_2eelab_2erules_2edefaultChk(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_t_2412); r_; });
    V v_c_2415;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_MkChk: {
      V v_f_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_240, v_a_2411}));
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam1, 2, 1, (V[]){v_c_2415});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaultAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2418, 0, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam2, 1, 1, (V[]){v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erecordName_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordName_entry, 7, 0};

V g_heff_2eelab_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VDecode: {
    V v_a1_248 = heff_field(v_a_241, 0);
    switch (heff_tag_of(v_a1_248)) {
    case TAG_HLocal: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HGlobal: {
      V v_k_2414 = heff_field(v_a1_248, 0);
      V v_t_2415 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
      if (heff_intEq_c(v_t_2415, heff_strLength_lent(v_x_242, 0))) {
        V v_t_2418 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam0, 1, 2, (V[]){v_e_240, v_ty_244})});
        V v_t_2419 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
        V v_t_2420 = heff_tr(heff_call(heff_take_field(v_p_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
        return heff_tail(heff_get_n(v_p_245, 1, 3), 2, (V[]){v_t_2420, v_p_246});
      } else {
        V v_t_2421 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
        V v_t_2422 = heff_intAdd(heff_strLength_lent(v_x_242, 0), MK_INT(1LL));
        if (heff_intEq_c(v_t_2421, v_t_2422)) {
          V v_t_2425 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2414)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam1, 1, 2, (V[]){v_e_240, v_ty_244})});
          V v_t_2426 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
          V v_t_2427 = heff_tr(heff_call(heff_take_field(v_p_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
          return heff_tail(heff_get_n(v_p_245, 1, 3), 2, (V[]){v_t_2427, v_p_246});
        } else {
          heff_drop(v_e_240);
          heff_drop(v_x_242);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_ty_244);
          heff_drop_rec(v_p_245, 3);
          return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
        }
      }
    }
    case TAG_HMeta: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HError: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop_rec(v_p_245, 3);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_a1_248);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop_rec(v_p_245, 3);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordName(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2417);
  return (g_heff_2eelab_2erules_2etyStr(v_e_240, v_ty_244));
}
V g_heff_2eelab_2erules_2erecordName_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2424);
  return (g_heff_2eelab_2erules_2etyStr(v_e_240, v_ty_244));
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erebottom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erebottom_entry, 2, 0};

V g_heff_2eelab_2erules_2erebottom(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LNil: {
    heff_drop(v_v_240);
    return NTAG(TAG_LNil);
  }
  case TAG_LSnoc: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LNil: {
      heff_drop(v_x_243);
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam0, 1, 1, (V[]){v_v_240})});
    }
    case TAG_LSnoc: {
      V v_t_247 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_247, v_x_243});
    }
    case TAG_LChunkSnoc: {
      V v_t_2410 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_2410, v_x_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_LChunkSnoc: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_xs_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LChunkSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_LNil: {
      if (heff_intEq_c(heff_arrayLength_lent(v_xs_2412, 0), MK_INT(1LL))) {
        heff_drop(v_xs_2412);
        heff_drop_cell(v_ru_24x2_241_24LChunkSnoc, 2);
        return heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam1, 1, 1, (V[]){v_v_240})});
      } else {
        heff_drop(v_v_240);
        return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){NTAG(TAG_LNil), v_xs_2412});
      }
    }
    case TAG_LSnoc: {
      V v_t_2417 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2417, v_xs_2412});
    }
    case TAG_LChunkSnoc: {
      V v_t_2420 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2420, v_xs_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erebottom(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_v_240;
}
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return v_v_240;
}
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str0, 16, ", but got value ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckFixed_str1, 15, "expected value ");
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckFixed_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_lam0, 2, 0};
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args);
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckFixed_entry, 4, 0};

V g_heff_2eelab_2erules_2echeckFixed(V v_e_240, V v_sp_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    return ((V)&g_heff_2eelab_2erules_2echeckFixed_lam0_clo);
  }
  case TAG_Just: {
    V v_expected_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_c_247 = heff_dup(heff_rfield(v_e_240, 0));
    V v_t_248 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_247, 0), heff_get_n(v_c_247, 1, 4)});
    V v_t_249 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), heff_dup(heff_rfield(v_e_240, 1)), v_t_248, heff_dup(v_v_242), heff_dup(v_expected_246)));
    return heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam1, 2, 5, (V[]){v_t_249, v_e_240, v_expected_246, v_v_242, v_sp_241});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2echeckFixed(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2echeckFixed_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2echeckFixed_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_expected_246 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_c_2414 = heff_dup(heff_rfield(v_e_240, 0));
    V v_t_2415 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2414, 0), heff_get_n(v_c_2414, 1, 4)});
    V v_t_2416 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(heff_rfield(v_e_240, 1)), v_t_2415, v_expected_246));
    V v_c_2417 = heff_take_field(v_e_240, 0);
    V v_t_2418 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2417, 0), heff_get_n(v_c_2417, 1, 4)});
    V v_t_2419 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(heff_rfield(v_e_240, 1)), v_t_2418, v_v_242));
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str0), v_t_2419));
    V v_msg_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckFixed_str1), v_t_2420);
    V v_note_2422 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2413; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2413); r_; });
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2421, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2422})});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_2410, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_2410, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_expected_246);
    heff_drop(v_v_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_2410, 3);
    V f_ = v_k_2411;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eelab_2erules_2echeckFixed_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_expected_246 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2emeta_2eliftU(v_t_249, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2erules_2echeckFixed_lam2, 1, 6, (V[]){v_e_240, v_expected_246, v_v_242, v_sp_241, v_hd_2410, v_k_2411})));
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_24acc_entry, 2, 0};

V g_heff_2eelab_2erules_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2erules_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2eelab_2erules_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str0, 21, "missing record field ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str1, 6, " got: ");
HEFF_LIT(g_heff_2eelab_2erules_2enotGiven_str2, 22, "expected record field ");
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enotGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotGiven_entry, 3, 0};

V g_heff_2eelab_2erules_2enotGiven(V v_it_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_note_243 = (g_heff_2eelab_2erules_2efieldsNote(heff_dup(v_it_240)));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam0, 2, 3, (V[]){v_x_241, v_it_240, v_note_243});
  }
  case TAG_Cons: {
    V v_fs_2410 = heff_field(v_x3_242, 0);
    V v_note_2412 = (g_heff_2eelab_2erules_2efieldsNote(v_it_240));
    return heff_clo_n(g_heff_2eelab_2erules_2enotGiven_lam1, 2, 3, (V[]){heff_dup(v_fs_2410), v_x_241, v_note_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2enotGiven_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enotGiven(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enotGiven_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_it_240 = heff_env(self)[1];
  V v_note_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str0), v_x_241), heff_get_n(v_it_240, 0, 5), heff_tag_n(TAG_Just, 1, (V[]){v_note_243})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_248}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  args[0] = v_t_249;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enotGiven_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_fs_2410 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_note_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str1), heff_take_field(v_fs_2410, 0));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotGiven_str2), heff_strAppend(v_x_241, v_t_2415));
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), v_t_2416, heff_get_n(v_fs_2410, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2412})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str0, 15, " is given twice");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str1, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str2, 16, " is out of order");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str3, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str4, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str5, 14, "no such field ");
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eleftOver_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_lam0, 2, 0};
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eleftOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_entry, 3, 0};

V g_heff_2eelab_2erules_2eleftOver(V v_e_240, V v_it_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_it_241, 5);
    return ((V)&g_heff_2eelab_2erules_2eleftOver_lam0_clo);
  }
  case TAG_Cons: {
    V v_fs_245 = heff_field(v_x3_242, 0);
    V v_x_247 = (g_list_2efoldl_24f1128388138x103163567(MK_INT(1LL), MK_INT(0LL), heff_dup(v_fs_245), heff_rfield(v_it_241, 4)));
    if (heff_intLt_c(MK_INT(1LL), v_x_247)) {
      heff_drop(v_e_240);
      V v_note_249 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
      return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam1, 2, 2, (V[]){heff_dup(v_fs_245), v_note_249});
    } else {
      V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_fs_245, 0))}));
      V v_t_2418 = (g_list_2eany(v_t_2417, heff_rfield(v_it_241, 2)));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_e_240);
        heff_drop(v_t_2418);
        V v_note_2419 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam2, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2419});
      } else {
        heff_drop(v_t_2418);
        V v_t_2427 = (g_heff_2eelab_2erules_2etyStr(v_e_240, heff_dup(heff_rfield(v_it_241, 1))));
        V v_t_2428 = heff_strAppend(heff_dup(heff_rfield(v_fs_245, 0)), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str4), v_t_2427));
        V v_msg_2429 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str5), v_t_2428);
        V v_note_2430 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam3, 2, 3, (V[]){v_msg_2429, heff_dup(v_fs_245), v_note_2430});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eleftOver(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_strAppend(heff_take_field(v_fs_245, 0), ((V)&g_heff_2eelab_2erules_2eleftOver_str0));
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str1), v_t_2412), heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_249})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_2410, 2), 1, (V[]){v_t_2415}));
  V f_ = heff_get_n(v_hd_2410, 1, 3);
  args[0] = v_t_2416;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_strAppend(heff_take_field(v_fs_245, 0), ((V)&g_heff_2eelab_2erules_2eleftOver_str2));
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str3), v_t_2422), heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2419})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_2420, 2), 1, (V[]){v_t_2425}));
  V f_ = heff_get_n(v_hd_2420, 1, 3);
  args[0] = v_t_2426;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_msg_2429 = heff_env(self)[0];
  V v_fs_245 = heff_env(self)[1];
  V v_note_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2429, heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2430})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2431, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2431, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2enamedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedFrom_entry, 3, 0};

V g_heff_2eelab_2erules_2enamedFrom(V v_x1_240, V v_i_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = heff_dup(heff_rfield(v_m_243, 3));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_242));
      V v_t_247 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_246));
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_m_243, 2)), 0, 2);
      V v_t_249 = heff_tr(heff_call(heff_get_n(v_t_247, 0, 3), 2, (V[]){MK_INT(0LL), v_t_248}));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_i_241);
        heff_drop(v_j_242);
        heff_drop(v_t_249);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_249);
        V t_0 = v_rest_244;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        v_x1_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        goto top;
      }
    } else {
      heff_drop(v_t_245);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enamedFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eboundGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eboundGo(V v_all_240, V v_x2_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_all_240);
    heff_drop(v_j_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_245 = (g_list_2edrop(heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)), heff_dup(v_all_240)));
    V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)); V a_2 = heff_dup(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2erules_2eboundGo_24dps(v_all_240, v_rest_244, heff_intAdd(v_j_242, MK_INT(1LL)), heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eboundGo(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_24dps_entry, 4, 0};

V g_heff_2eelab_2erules_2eboundGo_24dps(V v_all_240, V v_x2_241, V v_j_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_all_240);
    heff_drop(v_j_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_246 = (g_list_2edrop(heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)), heff_dup(v_all_240)));
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)); V a_2 = heff_dup(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_all_240;
    V t_1 = v_rest_245;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_cell_248;
    v_all_240 = t_0;
    v_x2_241 = t_1;
    v_j_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eboundGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2erules_2edescribes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribes_entry, 1, 0};

V g_heff_2eelab_2erules_2edescribes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_SU: {
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      return NTAG(TAG_False);
    }
    case TAG_SFunction: {
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2edescribes(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str0, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str1, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str2, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str3, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str4, 14, "the type of `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str5, 79, "` depends on the fields before it, and what this record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str6, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str7, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str8, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str9, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str10, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str11, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str12, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str13, 45, "the record's shape is not in hand here for `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str14, 84, "`: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam17(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_entry, 3, 0};

V g_heff_2eelab_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam0, 1, 3, (V[]){heff_dup(v_projectee_241), v_sp_240, v_x_242})});
}
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordElim(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_a0_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2418, 3, 8); V a_1 = v_a0_2417; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2425);
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2428}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2429;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2434) == NTAG(TAG_True))) {
    heff_drop(v_x_2434);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2434);
    V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2437}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2438;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args) {
  V v_x_2470 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fieldTy_2469 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2470);
  V v_t_2471 = (g_heff_2eelab_2ememoed_2eprojAt(v_eprojectee_2416, v_x_242, heff_dup(v_fieldTy_2469)));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2471, v_fieldTy_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args) {
  V v_x_2473 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_fieldTy_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2473);
  V v_t_2474 = (g_heff_2eelab_2ememoed_2eproj(v_eprojectee_2416, v_x_242));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2474, v_fieldTy_2472});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2476) == NTAG(TAG_True))) {
    heff_drop(v_x_2476);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2476);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2479}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2480;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2481) == NTAG(TAG_True))) {
    heff_drop(v_x_2481);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2481);
    V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2484}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2485;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2486) == NTAG(TAG_True))) {
    heff_drop(v_x_2486);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2486);
    V v_t_2487 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2489}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2490;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args) {
  V v_x_2491 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2491) == NTAG(TAG_True))) {
    heff_drop(v_x_2491);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2491);
    V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2494}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2495;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2496) == NTAG(TAG_True))) {
    heff_drop(v_x_2496);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2496);
    V v_t_2497 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2499}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24100;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args) {
  V v_x_24102 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24102) == NTAG(TAG_True))) {
    heff_drop(v_x_24102);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24102);
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24105}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24106;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args) {
  V v_x_24108 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24108) == NTAG(TAG_True))) {
    heff_drop(v_x_24108);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24108);
    V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24111}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24112;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam17(V self, V *args) {
  V v_x_24113 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24113) == NTAG(TAG_True))) {
    heff_drop(v_x_24113);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24113);
    V v_t_24114 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str13), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str14)));
    V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_24114, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24117}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24118;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_eprojectee_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2422)));
  switch (heff_tag_of(v_t_2423)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam6, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2423, 0ULL, 4);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam7, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeRecord: {
    V v_capture_2440 = heff_field(v_t_2423, 1);
    V v_fieldTypes_2441 = heff_field(v_t_2423, 2);
    heff_take_n(v_t_2423, 6ULL, 3);
    V v_x3_2442 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2441, 1)));
    V v_t_2444;
    switch (heff_tag_of(v_x3_2442)) {
    case TAG_Nothing: {
      v_t_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2442, 0ULL, 1);
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x3_2442);
    }
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop_rec(v_eprojectee_2416, 2);
      heff_drop(v_capture_2440);
      heff_drop_rec(v_fieldTypes_2441, 3);
      heff_drop(v_t_2444);
      V v_t_2445 = (g_heff_2eelab_2erules_2etyStr(v_e_243, v_x_2422));
      V v_t_2446 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str2), v_t_2445));
      V v_msg_2447 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str3), v_t_2446);
      V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2447, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2450}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2451;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2444);
      V v_x1_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_eprojectee_2416, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_v_2456;
      switch (heff_tag_of(v_x1_2452)) {
      case TAG_Nom: {
        V v_x_2453 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        v_v_2456 = v_x_2453;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2452, 0ULL, 1);
        v_v_2456 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2455 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        v_v_2456 = v_x_2455;
        break;
      }
      default: heff_nomatch(v_x1_2452);
      }
      V v_t_2457 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_2456));
      V v_t_2458 = (g_heff_2eelab_2evalue_2eprojTyWith(heff_dup(v_x_2422), v_t_2457, heff_dup(v_x_242)));
      switch (heff_tag_of(v_t_2458)) {
      case TAG_Nothing: {
        V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
        V v_t_2460 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2441, 1)));
        V v_t_2462;
        switch (heff_tag_of(v_t_2460)) {
        case TAG_Nothing: {
          v_t_2462 = heff_abandon();
          break;
        }
        case TAG_Just: {
          V v_i_2461 = heff_field(v_t_2460, 0);
          heff_take_n(v_t_2460, 1ULL, 1);
          v_t_2462 = v_i_2461;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
        V v_t_2463 = (g_heff_2eelab_2erules_2efieldTyAt(v_t_2459, v_capture_2440, v_fieldTypes_2441, v_t_2462, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_t_2463)) {
        case TAG_Nothing: {
          heff_drop(v_x_2422);
          heff_drop_rec(v_e_243, 6);
          heff_drop_rec(v_eprojectee_2416, 2);
          V v_t_2464 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str4), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str5)));
          V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2464, v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
          V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
          V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2467}));
          V f_ = heff_get_n(v_hd_246, 1, 3);
          heff_room[0] = v_t_2468;
          heff_room[1] = v_k_247;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Just: {
          V v_fieldTy_2469 = heff_field(v_t_2463, 0);
          heff_take_n(v_t_2463, 1ULL, 1);
          return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2469); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam8, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_fieldTy_2469, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
        }
        default: return heff_nomatch(v_t_2463);
        }
      }
      case TAG_Just: {
        V v_fieldTy_2472 = heff_field(v_t_2458, 0);
        heff_take_n(v_t_2458, 1ULL, 1);
        heff_drop(v_capture_2440);
        heff_drop_rec(v_fieldTypes_2441, 3);
        return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2472); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam9, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_k_247, v_fieldTy_2472}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
      }
      default: return heff_nomatch(v_t_2458);
      }
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam10, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam11, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam12, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeString: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam13, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam14, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam15, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam16, 1, 3, (V[]){v_hd_246, v_k_247, v_sp_240})));
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_243, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam17, 1, 4, (V[]){v_hd_246, v_k_247, v_x_242, v_sp_240})));
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_eprojectee_2416 = heff_field(v_x_2415, 0);
    V v_a0_2417 = heff_field(v_x_2415, 1);
    heff_take_n(v_x_2415, 3ULL, 2);
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam4, 1, 1, (V[]){v_a0_2417})})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2420}));
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam5, 1, 6, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243, v_eprojectee_2416});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_x_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 2ULL, 2);
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_243), heff_dup(v_sp_240), v_t_2411, v_t_2414, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam3, 1, 5, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243})));
}
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam2, 1, 5, (V[]){v_e_243, v_sp_240, v_hd_246, v_k_247, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_projectee_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_projectee_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_projectee_241, 0);
    heff_take_n(v_projectee_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_projectee_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam1, 2, 4, (V[]){v_c_245, v_e_243, v_sp_240, v_x_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str0, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str1, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str2, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str3, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str4, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str5, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str6, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str7, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str8, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str9, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str10, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str11, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str12, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str13, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str14, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str15, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str16, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str17, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str18, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str19, 27, "can only specialize neutral");
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordSpec_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_x_242, heff_dup(v_c_243)})});
}
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordSpec(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args) {
  V v_x_2480 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2especializeM(v_g_2410, v_x_242, v_x_2480));
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2481, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_c_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x_249, 0);
    V v_a_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_x1_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_2410, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2413;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      v_t_2416 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_VNeu: {
      V v_desc_2421 = heff_field(v_t_2416, 4);
      heff_take_n(v_t_2416, 16ULL, 5);
      V v_it_2422 = heff_tr(heff_call(v_desc_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_it_2422)) {
      case TAG_Nothing: {
        heff_drop(v_x_242);
        heff_drop_rec(v_e_244, 6);
        heff_drop(v_c_243);
        heff_drop_rec(v_g_2410, 2);
        heff_drop(v_a_2411);
        V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str0), v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_2426;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_it1_2427 = heff_field(v_it_2422, 0);
        V v_ru_24it_2422_24Just = heff_take_reuse_n(v_it_2422, 1ULL, 1);
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_VNeu: {
          heff_take_n(v_it1_2427, 0ULL, 5);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str1), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2434 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2435}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_2436;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCode: {
          V v_it11_2437 = heff_field(v_it1_2427, 0);
          V v_ru_24it1_2427_24VCode = heff_take_reuse_n(v_it1_2427, 1ULL, 1);
          switch (heff_tag_of(v_it11_2437)) {
          case TAG_VU: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str2), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
            V v_t_2441 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
            V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2441}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2442;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VDecode: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str3), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2449 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
            V v_t_2450 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2450}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2451;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFunction: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str4), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2458 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
            V v_t_2459 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2459}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2460;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VRecord: {
            V v_capture_2462 = heff_field(v_it11_2437, 1);
            V v_fieldTypes_2463 = heff_field(v_it11_2437, 2);
            heff_take_n(v_it11_2437, 6ULL, 4);
            V v_x3_2465 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2463, 1)));
            V v_t_2467;
            switch (heff_tag_of(v_x3_2465)) {
            case TAG_Nothing: {
              v_t_2467 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_x3_2465, 0ULL, 1);
              v_t_2467 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x3_2465);
            }
            if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
              heff_drop(v_sp_240);
              heff_drop_cell(v_ru_24it1_2427_24VCode, 1);
              heff_drop(v_t_2467);
              V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
              V v_t_2469 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2463, 0)));
              V v_t_2470 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2463, 2)));
              V v_t_2471 = (g_heff_2eutil_2edict_2ezipKV(v_t_2469, v_t_2470));
              V v_xs_2472 = (g_heff_2eelab_2evalue_2egoER_24s12178679x44040905(heff_dup(v_capture_2462), heff_tag_at_n(v_ru_24it_2422_24Just, TAG_HLocal, 1, (V[]){v_t_2468}), NTAG(TAG_SpId), NTAG(TAG_Nothing), v_t_2471, NTAG(TAG_Nil)));
              V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2472));
              V v_t_2474 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_2463, 0)), heff_dup(heff_rfield(v_fieldTypes_2463, 1)), heff_arrayFromList(v_t_2473)});
              V v_t_2475 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2462, v_fieldTypes_2463, heff_dup(v_x_242), v_t_2474));
              switch (heff_tag_of(v_t_2475)) {
              case TAG_MkField: {
                V v_fty_2476 = heff_field(v_t_2475, 0);
                heff_take_n(v_t_2475, 1ULL, 2);
                V v_c_2479;
                switch (heff_tag_of(v_c_243)) {
                case TAG_MkChk: {
                  V v_f_2478 = heff_field(v_c_243, 0);
                  heff_take_n(v_c_243, 1ULL, 1);
                  v_c_2479 = heff_tr(heff_call(v_f_2478, 2, (V[]){v_e_244, v_fty_2476}));
                  break;
                }
                default: heff_nomatch(v_c_243);
                }
                V f_ = v_c_2479;
                heff_room[0] = v_hd_247;
                heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam3, 1, 4, (V[]){v_g_2410, v_x_242, v_k_248, v_a_2411});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
              default: return heff_nomatch(v_t_2475);
              }
            } else {
              heff_drop_rec(v_e_244, 6);
              heff_drop(v_c_243);
              heff_drop_rec(v_g_2410, 2);
              heff_drop(v_a_2411);
              heff_drop(v_capture_2462);
              heff_drop_rec(v_fieldTypes_2463, 3);
              heff_drop(v_t_2467);
              V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordSpec_str5), v_x_242), v_sp_240, NTAG(TAG_Nothing)});
              V v_t_2483 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
              V v_t_2484 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
              V v_t_2485 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2484}));
              V f_ = heff_get_n(v_hd_247, 1, 3);
              heff_room[0] = v_t_2485;
              heff_room[1] = v_k_248;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          }
          case TAG_VSum: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2487 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str6), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2488 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2487})});
            V v_t_2489 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
            V v_t_2490 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2489}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2490;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimInt: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str7), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2492 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
            V v_t_2493 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
            V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2493}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2494;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimFloat: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str8), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2496 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
            V v_t_2497 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
            V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2497}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2498;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimString: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str9), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24100 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
            V v_t_24101 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
            V v_t_24102 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24101}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24102;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimRune: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str10), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24104 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
            V v_t_24105 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
            V v_t_24106 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24105}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24106;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimArray: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str11), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24109 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
            V v_t_24110 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
            V v_t_24111 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24110}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24111;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFixed: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str12), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24114 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
            V v_t_24115 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
            V v_t_24116 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24115}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24116;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          default: return heff_nomatch(v_it11_2437);
          }
        }
        case TAG_VLam: {
          heff_take_n(v_it1_2427, 0ULL, 2);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24119 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str13), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24120 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24119})});
          V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
          V v_t_24122 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24121}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24122;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCons: {
          V v_ru_24it1_2427_24VCons = heff_take_reuse_n(v_it1_2427, 0ULL, 1);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str14), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24125 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24124})});
          V v_t_24126 = heff_tag_at_n(v_ru_24it1_2427_24VCons, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
          V v_t_24127 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24126}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24127;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str15), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24129 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
          V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
          V v_t_24131 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24130}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24131;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_it1_2427);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_VCode: {
      V v_ru_24t_2416_24VCode = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str16), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24134 = heff_tag_at_n(v_ru_24t_2416_24VCode, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24135}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24136;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VLam: {
      heff_take_n(v_t_2416, 0ULL, 2);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str17), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
      V v_t_24142 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24141}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24142;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VCons: {
      V v_ru_24t_2416_24VCons = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str18), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24145 = heff_tag_at_n(v_ru_24t_2416_24VCons, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24144})});
      V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
      V v_t_24147 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24146}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24147;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VOpaque: {
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str19), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24149 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24148})});
      V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
      V v_t_24151 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24150}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24151;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_c_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam2, 1, 6, (V[]){v_sp_240, v_hd_247, v_k_248, v_x_242, v_e_244, v_c_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_x_242, v_e_244, v_c_243});
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2esumFormation(V v_vs_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam0, 1, 1, (V[]){v_vs_240})});
}
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation(a[0]);
}
V g_heff_2eelab_2erules_2esumFormation_lam2(V self, V *args) {
  V v_t_248 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sd_249 = heff_take_field(v_e_241, 0);
  switch (heff_tag_of(v_t_248)) {
  case TAG_MkSmallTyp: {
    V v_f_2410 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24MkSmallTyp = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24t_248_24MkSmallTyp, TAG_CUndelay, 1, (V[]){heff_dup(heff_rfield(v_sd_249, 3))});
    V v_t_2412 = ({ V rv_3 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_sd_249, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 58ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4044u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    V f_ = v_f_2410;
    args[0] = v_t_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, heff_arrayFromList(v_x_2417)});
  V f_ = v_k_2416;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam4, 1, 2, (V[]){v_k_246, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam1(V self, V *args) {
  V v_p_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_k_246 = heff_field(v_p_245, 0);
    V v_ts_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    V v_c_2414 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam2, 1, 1, (V[]){v_e_241}), heff_arrayToList(v_ts_247)));
    return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam3, 2, 2, (V[]){v_c_2414, v_k_246});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_heff_2eelab_2erules_2esumFormation_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2422)));
  V v_t_2424 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2422));
  V v_t_2425 = (g_list_2emap_24s1173914895x100384474(v_x_2422));
  V v_t_2426 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2423), v_t_2424, heff_arrayFromList(v_t_2425)});
  V v_x_2427 = (g_heff_2eelab_2ememoed_2esumM(v_t_2426));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam6, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_vs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = heff_arrayToList(heff_take_field(v_vs_240, 0));
  V v_t_243 = heff_arrayToList(heff_get_n(v_vs_240, 2, 3));
  V v_t_244 = (g_heff_2eutil_2edict_2ezipKV(v_t_242, v_t_243));
  V v_c_2419 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam1, 1, 1, (V[]){v_e_241}), v_t_244));
  return heff_clo_n(g_heff_2eelab_2erules_2esumFormation_lam5, 2, 1, (V[]){v_c_2419});
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2elocalDef_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_lam7, 1, 0};
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elocalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_entry, 4, 0};

V g_heff_2eelab_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam0, 2, 4, (V[]){heff_dup(v_typ_241), v_x_240, heff_dup(v_body_242), heff_dup(v_rest_243)})});
}
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2elocalDef(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_scope_27_2432 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2431);
  switch (heff_tag_of(v_rest_243)) {
  case TAG_MkChk: {
    V v_f_2433 = heff_field(v_rest_243, 0);
    heff_take_n(v_rest_243, 1ULL, 1);
    V v_t_2434 = ({ V rv_0 = v_scope_27_2432; V rr_ = heff_rec_reuse_nf(v_e_244, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2433;
    args[0] = v_t_2434;
    args[1] = v_b_245;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_rest_243);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args) {
  V v_u_2444 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_245});
}
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args) {
  V v_u_2451 = args[0];
  heff_drop(v_u_2451);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_take_field(v_e_244, 2);
  V v_t_2440;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_ForNominative: {
    v_t_2440 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2440 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2442, MK_INT(1LL)), heff_dup(v_b_245)));
  V v_cod_2445 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2443, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam6, 1, 1, (V[]){v_b_245})})});
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2447 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_244, 1)), v_t_2446, heff_dup(v_x_2411), v_cod_2445));
  V v_t_2448 = (g_heff_2eelab_2ememoed_2elam(v_t_2440, heff_get_n(v_e_244, 1, 6), v_t_2441, v_t_2447, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_x_2436})));
  V v_t_2449 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_get_n(v_x_2425, 0, 2)});
  V v_t_2450 = heff_tag_n(TAG_SFix, 2, (V[]){heff_get_n(v_x_2411, 0, 2), v_t_2449});
  V v_x_2452 = (g_heff_2eelab_2ememoed_2eapp(v_t_2448, heff_rec_n(2, shape_stx__val, (V[]){v_t_2450, ((V)&g_heff_2eelab_2erules_2elocalDef_lam7_clo)})));
  V f_ = v_k_2410;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_c_2435 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2430, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam4, 2, 3, (V[]){v_rest_243, heff_dup(v_e_244), heff_dup(v_b_245)})));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam5, 1, 6, (V[]){v_e_244, v_b_245, v_x_240, v_x_2411, v_x_2425, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_e_2417 = (g_heff_2eelab_2erules_2efixEnv(heff_dup(v_e_244), heff_dup(v_x_240), v_t_2416));
  V v_x1_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_a_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2424;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2423 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2424 = heff_tr(heff_call(v_f_2423, 2, (V[]){v_e_2417, v_a_2422}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam3, 1, 7, (V[]){v_x_2411, v_x_240, v_e_244, v_rest_243, v_b_245, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam2, 1, 7, (V[]){v_e_244, v_x_240, v_body_242, v_hd_249, v_rest_243, v_b_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_typ_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_248;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_246 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    V v_t_247 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_244, 0)), heff_dup(heff_rfield(v_e_244, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_244, 3)), heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_248 = heff_tr(heff_call(v_f_246, 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_x_240, v_body_242, v_rest_243, v_b_245});
}
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str0, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str1, 13, " is set twice");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str2, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2egivenTwice_str3, 13, " is set twice");
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args);
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2egivenTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egivenTwice_entry, 2, 0};

V g_heff_2eelab_2erules_2egivenTwice(V v_fs_240, V v_x_241) {
top: ;
  V v_t_242 = (g_list_2efilter_24s1966236437x1225976932(heff_dup(v_x_241), v_fs_240));
  V v_t_243 = (g_list_2edrop(MK_INT(1LL), v_t_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam0, 2, 1, (V[]){v_x_241});
  }
  case TAG_Cons: {
    V v_f_2411 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    return heff_clo_n(g_heff_2eelab_2erules_2egivenTwice_lam1, 2, 2, (V[]){v_x_241, v_f_2411});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2egivenTwice(a[0], a[1]);
}
V g_heff_2eelab_2erules_2egivenTwice_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k2_245 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str0), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2egivenTwice_str1)));
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_246, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_249}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  args[0] = v_t_2410;
  args[1] = v_k2_245;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2egivenTwice_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_f_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2erules_2egivenTwice_str2), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2egivenTwice_str3)));
  V v_t_2424;
  switch (heff_tag_of(v_f_2411)) {
  case TAG_UpdateTo: {
    V v_sp_2418 = heff_field(v_f_2411, 2);
    heff_take_n(v_f_2411, 4ULL, 4);
    v_t_2424 = v_sp_2418;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2422 = heff_field(v_f_2411, 2);
    heff_take_n(v_f_2411, 4ULL, 4);
    v_t_2424 = v_sp_2422;
    break;
  }
  default: heff_nomatch(v_f_2411);
  }
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_t_2415, v_t_2424, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2428;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str0, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str1, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str3, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2enoSuchSetting_str4, 15, "the fields are ");
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_lam0, 2, 0};
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enoSuchSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoSuchSetting_entry, 4, 0};

V g_heff_2eelab_2erules_2enoSuchSetting(V v_e_240, V v_a_241, V v_keys_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    return ((V)&g_heff_2eelab_2erules_2enoSuchSetting_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_t_2416;
    switch (heff_tag_of(v_f_246)) {
    case TAG_UpdateTo: {
      V v_x_248 = heff_field(v_f_246, 0);
      v_t_2416 = heff_dup(v_x_248);
      break;
    }
    case TAG_UpdateIn: {
      V v_x_2412 = heff_field(v_f_246, 0);
      v_t_2416 = heff_dup(v_x_2412);
      break;
    }
    default: heff_nomatch(v_f_246);
    }
    V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_2416}));
    V v_t_2418 = (g_list_2eany(v_t_2417, v_keys_242));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      V t_0 = v_e_240;
      V t_1 = v_a_241;
      V t_2 = v_keys_242;
      V t_3 = v_rest_247;
      v_e_240 = t_0;
      v_a_241 = t_1;
      v_keys_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2418);
      V v_t_2427;
      switch (heff_tag_of(v_f_246)) {
      case TAG_UpdateTo: {
        V v_x_2419 = heff_field(v_f_246, 0);
        v_t_2427 = heff_dup(v_x_2419);
        break;
      }
      case TAG_UpdateIn: {
        V v_x_2423 = heff_field(v_f_246, 0);
        v_t_2427 = heff_dup(v_x_2423);
        break;
      }
      default: heff_nomatch(v_f_246);
      }
      V v_t_2428 = (g_heff_2eelab_2erules_2etyStr(v_e_240, v_a_241));
      V v_t_2429 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str0), v_t_2428));
      V v_msg_2430 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str1), v_t_2429);
      V v_t_2433;
      switch (heff_tag_of(v_keys_242)) {
      case TAG_Nil: {
        v_t_2433 = ((V)&g_heff_2eelab_2erules_2enoSuchSetting_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2431 = heff_field(v_keys_242, 0);
        V v_xs_2432 = heff_field(v_keys_242, 1);
        v_t_2433 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str3), heff_dup(v_x_2431), v_xs_2432));
        break;
      }
      default: heff_nomatch(v_keys_242);
      }
      V v_note_2434 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enoSuchSetting_str4), v_t_2433);
      return heff_clo_n(g_heff_2eelab_2erules_2enoSuchSetting_lam1, 2, 3, (V[]){heff_dup(v_f_246), v_msg_2430, v_note_2434});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2enoSuchSetting(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enoSuchSetting_lam1(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k2_2436 = args[1];
  V v_f_246 = heff_env(self)[0];
  V v_msg_2430 = heff_env(self)[1];
  V v_note_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2445;
  switch (heff_tag_of(v_f_246)) {
  case TAG_UpdateTo: {
    V v_sp_2439 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2445 = v_sp_2439;
    break;
  }
  case TAG_UpdateIn: {
    V v_sp_2443 = heff_field(v_f_246, 2);
    heff_take_n(v_f_246, 4ULL, 4);
    v_t_2445 = v_sp_2443;
    break;
  }
  default: heff_nomatch(v_f_246);
  }
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2430, v_t_2445, heff_tag_n(TAG_Just, 1, (V[]){v_note_2434})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_2435, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2435, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2436;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str0, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str1, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str2, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str3, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str4, 4, "int8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str5, 5, "int16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str6, 5, "int32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str7, 5, "int64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str8, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str9, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str10, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str11, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str12, 7, "float32");
HEFF_LIT(g_heff_2eelab_2erules_2elitEq_str13, 2, "Eq");
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitEq_entry, 5, 0};

V g_heff_2eelab_2erules_2elitEq(V v_sp_240, V v_x_241, V v_xsp_242, V v_eq_243, V v_lit_244) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam0, 1, 5, (V[]){v_xsp_242, v_x_241, v_eq_243, v_sp_240, heff_dup(v_lit_244)})});
}
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elitEq(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elitEq_lam3(V self, V *args) {
  V v_c_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2414 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 2ULL, 2);
    v_t_2415 = v_y_2414;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_t_2415; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elitEq_lam5(V self, V *args) {
  V v_e2_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2435);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitEq_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_eq_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_xsp_242 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2419));
  V v_t_2433;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2420, 0ULL, 1);
    v_t_2433 = v_eq_243;
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2420, 0ULL, 4);
    v_t_2433 = v_eq_243;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2420, 0ULL, 3);
    v_t_2433 = v_eq_243;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2420, 0ULL, 1);
    v_t_2433 = v_eq_243;
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_eq_243);
    v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str0);
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_eq_243);
    v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str1);
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_eq_243);
    v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str2);
    break;
  }
  case TAG_LikeRune: {
    heff_drop(v_eq_243);
    v_t_2433 = ((V)&g_heff_2eelab_2erules_2elitEq_str3);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2420, 0ULL, 1);
    v_t_2433 = v_eq_243;
    break;
  }
  case TAG_LikeFixed: {
    V v_w_2431 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    heff_drop(v_eq_243);
    V v_t_2432;
    switch (heff_tag_of(v_w_2431)) {
    case TAG_I8: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str4);
      break;
    }
    case TAG_I16: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str5);
      break;
    }
    case TAG_I32: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str6);
      break;
    }
    case TAG_I64: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str7);
      break;
    }
    case TAG_U8: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str8);
      break;
    }
    case TAG_U16: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str9);
      break;
    }
    case TAG_U32: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str10);
      break;
    }
    case TAG_U64: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str11);
      break;
    }
    case TAG_F32: {
      v_t_2432 = ((V)&g_heff_2eelab_2erules_2elitEq_str12);
      break;
    }
    default: heff_nomatch(v_w_2431);
    }
    v_t_2433 = heff_strAppend(v_t_2432, ((V)&g_heff_2eelab_2erules_2elitEq_str13));
    break;
  }
  case TAG_NoRules: {
    v_t_2433 = v_eq_243;
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_callee_2434 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), v_t_2433));
  V v_t_2438 = ({ V a_0 = v_xsp_242; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam5, 3, 1, (V[]){v_x_2411})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2439 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_240); V a_2 = v_callee_2434; V a_3 = v_t_2438; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_callee_2434); heff_drop(v_t_2438); r_; });
  V v_t_2440 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_240; V a_2 = v_t_2439; V a_3 = v_lit_244; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2439); heff_drop(v_lit_244); r_; });
  switch (heff_tag_of(v_t_2440)) {
  case TAG_MkSyn: {
    V v_f_2441 = heff_field(v_t_2440, 0);
    heff_take_n(v_t_2440, 1ULL, 1);
    V f_ = v_f_2441;
    heff_room[0] = v_e_245;
    heff_room[1] = v_hd_249;
    heff_room[2] = v_k_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_t_2440);
  }
}
V g_heff_2eelab_2erules_2elitEq_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam3, 1, 1, (V[]){heff_dup(v_x_2411)})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam4, 1, 8, (V[]){v_eq_243, v_sp_240, v_xsp_242, v_x_2411, v_lit_244, v_e_245, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elitEq_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_eq_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_xsp_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam2, 1, 7, (V[]){v_hd_249, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitEq_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_xsp_242 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(heff_dup(v_xsp_242), v_x_241));
  V v_c_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkSyn: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_c_248 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_dup(v_e_245)}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elitEq_lam1, 2, 6, (V[]){v_c_248, v_eq_243, v_sp_240, v_xsp_242, v_lit_244, v_e_245});
}