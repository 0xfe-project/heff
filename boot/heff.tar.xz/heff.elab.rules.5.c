// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_De 8978
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_RestoreDelayed 1107
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_array_2eempty_get(void);
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ememoed_2especializeM(V, V, V);
V g_heff_2eelab_2ememoed_2especializeM_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2especializeM_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eboundGo_24dps(V, V, V, V);
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edefaultChk(V, V, V);
V g_heff_2eelab_2erules_2edefaultChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultChk_clo;
V g_heff_2eelab_2erules_2edescribes(V);
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribes_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efixEnv(V, V, V);
V g_heff_2eelab_2erules_2efixEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efixEnv_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enamesFor_24dps(V, V);
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo;
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
HeffT2 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f603879485x1484249893(V, V, V, V);
V g_list_2efoldl_24f603879485x1484249893_entry(V self, V *a);
extern Clo g_list_2efoldl_24f603879485x1484249893_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2enamesFor_24dps_str0, 1, "x");
Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2enamesFor_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_242 = heff_intShow(heff_intSub(heff_dup(v_n_240), MK_INT(1LL)));
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_24dps_str0), v_t_242), heff_hole()});
    V v_u_244 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_cell_243;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamesFor_24dps(a[0], a[1]);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ekeepRecovered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ekeepRecovered_entry, 5, 0};

V g_heff_2eelab_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_bind_245 = heff_take_field(v_hd_243, 1);
  V v_malg_246 = heff_get_n(v_hd_243, 2, 3);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam0, 1, 1, (V[]){v_kept_240})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2417}));
  return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam1, 1, 5, (V[]){v_malg_246, v_bind_245, v_saved_241, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ekeepRecovered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_kept_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_infos_248 = heff_take_field(v_c_247, 0);
  V v_recovered_249 = heff_take_field(v_c_247, 1);
  V v_poisoned_2410 = heff_take_field(v_c_247, 2);
  V v_metas_2411 = heff_take_field(v_c_247, 3);
  V v_nextMeta_2412 = heff_take_field(v_c_247, 4);
  V v_postponed_2413 = heff_take_field(v_c_247, 5);
  V v_trace_2414 = heff_take_field(v_c_247, 6);
  V v_selfKey_2415 = heff_get_n(v_c_247, 7, 8);
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_248, heff_tag_n(TAG_Cons, 2, (V[]){v_kept_240, v_recovered_249}), v_poisoned_2410, v_metas_2411, v_nextMeta_2412, v_postponed_2413, v_trace_2414, v_selfKey_2415});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args) {
  V v_c_2424 = args[0];
  V v_saved_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_infos_2425 = heff_take_field(v_c_2424, 0);
  V v_recovered_2426 = heff_take_field(v_c_2424, 1);
  V v_poisoned_2427 = heff_take_field(v_c_2424, 2);
  V v_metas_2428 = heff_take_field(v_c_2424, 3);
  V v_nextMeta_2429 = heff_take_field(v_c_2424, 4);
  V v_trace_2430 = heff_take_field(v_c_2424, 6);
  V v_selfKey_2431 = heff_get_n(v_c_2424, 7, 8);
  return ({ V rv_0 = v_infos_2425; V rv_1 = v_recovered_2426; V rv_2 = v_poisoned_2427; V rv_3 = v_metas_2428; V rv_4 = v_nextMeta_2429; V rv_6 = v_trace_2430; V rv_7 = v_selfKey_2431; V rr_ = heff_rec_reuse_nf(v_saved_241, 32ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 3072u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_malg_246 = heff_env(self)[1];
  V v_bind_245 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_RestoreDelayed, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2441}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2442;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2435, NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(v_bind_245);
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam5, 1, 4, (V[]){v_waiting_242, v_malg_246, v_bind_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_saved_241 = heff_env(self)[0];
  V v_malg_246 = heff_env(self)[1];
  V v_bind_245 = heff_env(self)[2];
  V v_waiting_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam3, 1, 1, (V[]){v_saved_241})})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2433}));
  V f_ = heff_dup(v_bind_245);
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam4, 1, 4, (V[]){v_malg_246, v_bind_245, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_saved_241 = heff_env(self)[2];
  V v_waiting_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  V f_ = heff_dup(v_bind_245);
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam2, 1, 5, (V[]){v_saved_241, v_malg_246, v_bind_245, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eeachSubgoal_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeachSubgoal_lam0, 2, 0};
V g_heff_2eelab_2erules_2eeachSubgoal_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eeachSubgoal_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eeachSubgoal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeachSubgoal_entry, 2, 0};

V g_heff_2eelab_2erules_2eeachSubgoal(V v_find_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_find_240);
    return ((V)&g_heff_2eelab_2erules_2eeachSubgoal_lam0_clo);
  }
  case TAG_Cons: {
    V v_sg_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_find_240), 1, (V[]){heff_dup(v_sg_244)}));
    return heff_clo_n(g_heff_2eelab_2erules_2eeachSubgoal_lam1, 2, 3, (V[]){v_c_246, v_find_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eeachSubgoal(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_find_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_249);
  V v_t_2410 = ({ V a_0 = v_find_240; V a_1 = v_rest_245; V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_find_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eeachSubgoal_lam2, 1, 4, (V[]){v_find_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2especializedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especializedGo_entry, 12, 0};

V g_heff_2eelab_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249, V v_p_2410, V v_p_2411) {
top: ;
  switch (heff_tag_of(v_sp_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpApp: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpProj: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpSpec: {
    V v_sq_2416 = heff_field(v_sp_244, 0);
    V v_x_2417 = heff_field(v_sp_244, 1);
    V v_f_2418 = heff_field(v_sp_244, 2);
    V v_c_2419 = heff_dup(heff_rfield(v_e_240, 0));
    V v_len_2420 = heff_take_field(v_c_2419, 0);
    V v_names_2421 = heff_get_n(v_c_2419, 1, 4);
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam0, 2, 9, (V[]){heff_dup(v_e_240), v_len_2420, v_names_2421, heff_dup(v_h_243), heff_dup(v_sq_2416), heff_dup(v_u_245), heff_dup(v_described_246), heff_dup(v_el_247), heff_dup(v_a_27_242)}), heff_dup(v_p_2410), heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam1, 1, 14, (V[]){heff_dup(v_x_2417), heff_dup(v_f_2418), v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, heff_dup(v_sq_2416), v_u_245, v_described_246, v_el_247, v_err_249, v_p_2410, v_p_2411})));
  }
  default: return heff_nomatch(v_sp_244);
  }
}
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2especializedGo(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args) {
  V v_p_2422 = args[0];
  V v_p_2423 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_len_2420 = heff_env(self)[1];
  V v_names_2421 = heff_env(self)[2];
  V v_h_243 = heff_env(self)[3];
  V v_sq_2416 = heff_env(self)[4];
  V v_u_245 = heff_env(self)[5];
  V v_described_246 = heff_env(self)[6];
  V v_el_247 = heff_env(self)[7];
  V v_a_27_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){heff_get_n(v_e_240, 1, 6), heff_rec_n(2, shape_len__names, (V[]){v_len_2420, v_names_2421}), heff_tag_n(TAG_VDecode, 5, (V[]){v_h_243, v_sq_2416, v_u_245, v_described_246, v_el_247}), v_a_27_242}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2424, v_p_2422, v_p_2423));
}
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_f_2418 = heff_env(self)[1];
  V v_fields_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_a_27_242 = heff_env(self)[5];
  V v_h_243 = heff_env(self)[6];
  V v_sq_2416 = heff_env(self)[7];
  V v_u_245 = heff_env(self)[8];
  V v_described_246 = heff_env(self)[9];
  V v_el_247 = heff_env(self)[10];
  V v_err_249 = heff_env(self)[11];
  V v_p_2410 = heff_env(self)[12];
  V v_p_2411 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_a_27_242; V a_3 = v_h_243; V a_4 = v_sq_2416; V a_5 = v_u_245; V a_6 = v_described_246; V a_7 = v_el_247; V a_8 = v_t_2427; V a_9 = v_err_249; V a_10 = v_p_2410; V a_11 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2especializedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_sq_2416); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2425, 0ULL, 1);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_sq_2416);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_err_249);
    V v_t_2429 = heff_tr(heff_call(v_v_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_t_2429; V a_2 = v_t_2430; V a_3 = v_p_2410; V a_4 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_t_2430, 2); r_; });
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2eelab_2erules_2evarGo_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2erules_2evarGo_24cpr(V v_x_240, V v_names_241, V v_x3_242, V v_locals_243, V v_n_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CEmpty: {
    heff_drop(v_names_241);
    heff_drop(v_locals_243);
    heff_drop(v_n_244);
    heff_drop(v_i_245);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope)}});
  }
  case TAG_CBind: {
    V v_c_27_246 = heff_field(v_x3_242, 0);
    V v_x32_247 = heff_field(v_x3_242, 1);
    V v_a_248 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x32_247)) {
    case TAG_BDelayedBy: {
      V v_k_249 = heff_field(v_x32_247, 0);
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_locals_243);
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope)}});
      }
      case TAG_Cons: {
        V v_x_27_2410 = heff_field(v_names_241, 0);
        V v_xs_2411 = heff_field(v_names_241, 1);
        V v_ru_24names_241_24Cons = heff_take_reuse_n(v_names_241, 3ULL, 2);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope)}});
        }
        case TAG_LSnoc: {
          V v_vs_2412 = heff_field(v_locals_243, 0);
          V v_v_2413 = heff_field(v_locals_243, 1);
          heff_take_n(v_locals_243, 3ULL, 2);
          if (heff_strEq_c_lent(v_x_240, v_x_27_2410, 2)) {
            heff_drop(v_xs_2411);
            heff_drop(v_vs_2412);
            if (heff_intLe_c_lent(v_k_249, v_n_244, 2)) {
              V v_t_2416 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_i_245}), heff_clo_n(g_heff_2eelab_2erules_2evarGo_24cpr_lam0, 1, 1, (V[]){v_v_2413})});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24names_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2416, heff_dup(v_a_248)})}});
            } else {
              heff_drop(v_i_245);
              heff_drop_cell(v_ru_24names_241_24Cons, 2);
              heff_drop(v_v_2413);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Delayed2)}});
            }
          } else {
            heff_drop_cell(v_ru_24names_241_24Cons, 2);
            heff_drop(v_v_2413);
            V t_0 = v_x_240;
            V t_1 = v_xs_2411;
            V t_2 = v_c_27_246;
            V t_3 = v_vs_2412;
            V t_4 = v_n_244;
            V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
            v_x_240 = t_0;
            v_names_241 = t_1;
            v_x3_242 = t_2;
            v_locals_243 = t_3;
            v_n_244 = t_4;
            v_i_245 = t_5;
            goto top;
          }
        }
        case TAG_LChunkSnoc: {
          heff_take_n(v_locals_243, 0ULL, 2);
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          heff_drop(v_x_27_2410);
          heff_drop(v_xs_2411);
          heff_drop_cell(v_ru_24names_241_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_locals_243)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_names_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x32_247)}});
    }
  }
  case TAG_CUndelay: {
    V v_c_27_2419 = heff_field(v_x3_242, 0);
    V t_0 = v_x_240;
    V t_1 = v_names_241;
    V t_2 = v_c_27_2419;
    V t_3 = v_locals_243;
    V t_4 = heff_intAdd(v_n_244, MK_INT(1LL));
    V t_5 = v_i_245;
    v_x_240 = t_0;
    v_names_241 = t_1;
    v_x3_242 = t_2;
    v_locals_243 = t_3;
    v_n_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2eelab_2erules_2evarGo_24cpr_lam0(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(v_v_2413, 1, (V[]){v_u_2414}));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimInt_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimInt_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimInt_st;
static V g_heff_2eelab_2erules_2eprimInt_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimInt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimInt_st)) return g_heff_2eelab_2erules_2eprimInt_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimInt_val, &g_heff_2eelab_2erules_2eprimInt_st, g_heff_2eelab_2erules_2eprimInt_init);
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_lam0, 2, 0};
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultAt(V v_e_240, V v_i_241, V v_ty_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_i_241);
    heff_drop_rec(v_ty_242, 2);
    return ((V)&g_heff_2eelab_2erules_2edefaultAt_lam0_clo);
  }
  case TAG_Just: {
    V v_d_246 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_span_247 = heff_take_field(v_d_246, 1);
    V v_chk_248 = heff_get_n(v_d_246, 0, 2);
    V v_x1_249 = heff_tr(heff_call(heff_get_n(v_ty_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_x_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_a_2413 = v_x_2410;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_249, 0ULL, 1);
      v_a_2413 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2412 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_a_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    V v_t_2414 = ({ V a_0 = v_span_247; V a_1 = v_i_241; V a_2 = v_chk_248; V r_ = (g_heff_2eelab_2erules_2edefaultChk(a_0, a_1, a_2)); heff_drop(v_chk_248); r_; });
    HeffT1 v_t_2415 = ({ V a_0 = v_t_2414; HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(a_0)); heff_drop(v_t_2414); r_; });
    V v_c_2418;
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_f_2417 = v_field_2416;
      v_c_2418 = heff_tr(heff_call(v_f_2417, 2, (V[]){v_e_240, v_a_2413}));
    }
    return heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam1, 2, 1, (V[]){v_c_2418});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaultAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2421, 0, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam2, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordName_entry, 7, 0};

V g_heff_2eelab_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246) {
top: ;
  V v_bind_247 = heff_take_field(v_p_245, 1);
  V v_malg_248 = heff_get_n(v_p_245, 2, 3);
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VDecode: {
    V v_a1_2410 = heff_field(v_a_241, 0);
    switch (heff_tag_of(v_a1_2410)) {
    case TAG_HLocal: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_bind_247);
      heff_drop(v_malg_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HGlobal: {
      V v_k_2416 = heff_field(v_a1_2410, 0);
      V v_t_2417 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
      if ((heff_intEq_c(heff_dup(v_t_2417), heff_strLength_lent(v_x_242, 0)) || heff_intEq_c(heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0))), heff_intAdd(heff_strLength_lent(v_x_242, 0), MK_INT(1LL))))) {
        heff_drop(v_t_2417);
        V v_t_2419 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2416)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam0, 1, 2, (V[]){v_e_240, v_ty_244})});
        V v_t_2420 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
        V v_t_2421 = heff_tr(heff_call(v_malg_248, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
        return heff_tail(v_bind_247, 2, (V[]){v_t_2421, v_p_246});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_x_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_ty_244);
        heff_drop(v_bind_247);
        heff_drop(v_malg_248);
        heff_drop(v_t_2417);
        return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
      }
    }
    case TAG_HMeta: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_bind_247);
      heff_drop(v_malg_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HError: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_bind_247);
      heff_drop(v_malg_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_a1_2410);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_bind_247);
    heff_drop(v_malg_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordName(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args) {
  V v_mc_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_240; V a_1 = v_mc_2418; V a_2 = v_ty_244; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2418); r_; });
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erebottom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erebottom_entry, 2, 0};

V g_heff_2eelab_2erules_2erebottom(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LNil: {
    heff_drop(v_v_240);
    return NTAG(TAG_LNil);
  }
  case TAG_LSnoc: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LNil: {
      heff_drop(v_x_243);
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam0, 1, 1, (V[]){v_v_240})});
    }
    case TAG_LSnoc: {
      V v_t_247 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_247, v_x_243});
    }
    case TAG_LChunkSnoc: {
      V v_t_2410 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){v_t_2410, v_x_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_LChunkSnoc: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_xs_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LChunkSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_LNil: {
      if ((heff_unbox_word(heff_arrayLength_lent(v_xs_2412, 0)) == ((int64_t)1ULL))) {
        heff_drop(v_xs_2412);
        heff_drop_cell(v_ru_24x2_241_24LChunkSnoc, 2);
        return heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam1, 1, 1, (V[]){v_v_240})});
      } else {
        heff_drop(v_v_240);
        return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){NTAG(TAG_LNil), v_xs_2412});
      }
    }
    case TAG_LSnoc: {
      V v_t_2416 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2416, v_xs_2412});
    }
    case TAG_LChunkSnoc: {
      V v_t_2419 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_at_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, (V[]){v_t_2419, v_xs_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erebottom(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_v_240;
}
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_v_240;
}
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str0, 15, " is given twice");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str1, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str2, 16, " is out of order");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str3, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str4, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str5, 14, "no such field ");
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eleftOver_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_lam0, 2, 0};
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eleftOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_entry, 3, 0};

V g_heff_2eelab_2erules_2eleftOver(V v_e_240, V v_it_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_it_241, 5);
    return ((V)&g_heff_2eelab_2erules_2eleftOver_lam0_clo);
  }
  case TAG_Cons: {
    V v_fs_245 = heff_field(v_x3_242, 0);
    V v_x_247 = (g_list_2efoldl_24f603879485x1484249893(MK_INT(1LL), MK_INT(0LL), heff_dup(v_fs_245), heff_rfield(v_it_241, 4)));
    if (heff_intLt_c(MK_INT(1LL), v_x_247)) {
      heff_drop(v_e_240);
      V v_note_248 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
      return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam1, 2, 2, (V[]){heff_dup(v_fs_245), v_note_248});
    } else {
      V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_fs_245, 0))}));
      V v_t_2419 = (g_list_2eany(v_t_2418, heff_rfield(v_it_241, 2)));
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_e_240);
        heff_drop(v_t_2419);
        V v_note_2420 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam2, 2, 2, (V[]){heff_dup(v_fs_245), v_note_2420});
      } else {
        heff_drop(v_t_2419);
        V v_t_2430 = (g_heff_2eelab_2erules_2etyStr(v_e_240, heff_dup(heff_rfield(v_it_241, 1))));
        V v_t_2431 = heff_strAppend(heff_dup(heff_rfield(v_fs_245, 0)), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str4), v_t_2430));
        V v_msg_2432 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str5), v_t_2431);
        V v_note_2433 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        return heff_clo_n(g_heff_2eelab_2erules_2eleftOver_lam3, 2, 3, (V[]){v_msg_2432, heff_dup(v_fs_245), v_note_2433});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eleftOver(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eleftOver_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2413 = heff_strAppend(heff_take_field(v_fs_245, 0), ((V)&g_heff_2eelab_2erules_2eleftOver_str0));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str1), v_t_2413), heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_248})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2416}));
  V f_ = v_bind_2411;
  args[0] = v_t_2417;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_fs_245 = heff_env(self)[0];
  V v_note_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2423 = heff_take_field(v_hd_2421, 1);
  V v_malg_2424 = heff_get_n(v_hd_2421, 2, 3);
  V v_t_2425 = heff_strAppend(heff_take_field(v_fs_245, 0), ((V)&g_heff_2eelab_2erules_2eleftOver_str2));
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str3), v_t_2425), heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2420})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2424, 1, (V[]){v_t_2428}));
  V f_ = v_bind_2423;
  args[0] = v_t_2429;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eleftOver_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_msg_2432 = heff_env(self)[0];
  V v_fs_245 = heff_env(self)[1];
  V v_note_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2436 = heff_take_field(v_hd_2434, 1);
  V v_malg_2437 = heff_get_n(v_hd_2434, 2, 3);
  V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2432, heff_get_n(v_fs_245, 2, 4), heff_tag_n(TAG_Just, 1, (V[]){v_note_2433})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(v_malg_2437, 1, (V[]){v_t_2440}));
  V f_ = v_bind_2436;
  args[0] = v_t_2441;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2enamedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedFrom_entry, 3, 0};

V g_heff_2eelab_2erules_2enamedFrom(V v_x1_240, V v_i_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_dflt_245 = heff_dup(heff_rfield(v_m_243, 3));
    V v_el_246 = heff_dup(heff_rfield(v_m_243, 2));
    if ((heff_dup(v_dflt_245) == NTAG(TAG_True))) {
      heff_drop(v_dflt_245);
      V v_t_247 = heff_intSub(heff_intSub(heff_dup(v_i_241), MK_INT(1LL)), heff_dup(v_j_242));
      V v_t_248 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_247));
      V v_t_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 3), 2, (V[]){MK_INT(0LL), heff_get_n(v_el_246, 0, 2)}));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_i_241);
        heff_drop(v_j_242);
        heff_drop(v_t_249);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_249);
        V t_0 = v_rest_244;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        v_x1_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        goto top;
      }
    } else {
      heff_drop(v_dflt_245);
      heff_drop_rec(v_el_246, 2);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enamedFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_24dps_entry, 4, 0};

V g_heff_2eelab_2erules_2eboundGo_24dps(V v_all_240, V v_x2_241, V v_j_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_j_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_246 = (g_list_2edrop(heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)), v_all_240));
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = heff_intAdd(heff_dup(v_j_242), MK_INT(1LL)); V a_2 = heff_dup(v_j_242); V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_all_240;
    V t_1 = v_rest_245;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_cell_248;
    v_all_240 = t_0;
    v_x2_241 = t_1;
    v_j_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eboundGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2edescribes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribes_entry, 1, 0};

V g_heff_2eelab_2erules_2edescribes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_SU: {
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      return NTAG(TAG_False);
    }
    case TAG_SFunction: {
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2edescribes(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str0, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str1, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str3, 79, "` depends on the fields before it, and what this record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str4, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str5, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str6, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str7, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str8, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str9, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str10, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str11, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str12, 59, "tried to project from a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str13, 45, "the record's shape is not in hand here for `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str14, 84, "`: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam7, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam8, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam9, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam11, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam12, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam13, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam17(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam17, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam18(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam18, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam19(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam19, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam21(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam21, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam22(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam22, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam23(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam23, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam20(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam25(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam25, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam26(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam26, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam27(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam27, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam24(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam29(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam29, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam30(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam30, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam31(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam31, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam28(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam33(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam33, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam34(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam34, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam35(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam35, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam32(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam37(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam37, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam38(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam38, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam39(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam39, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam36(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam41(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam41, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam42(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam42, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam43(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam43, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam40(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam45(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam45, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam46(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam46, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam47(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam47, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam44(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_entry, 3, 0};

V g_heff_2eelab_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam0, 1, 3, (V[]){heff_dup(v_projectee_241), v_sp_240, v_x_242})});
}
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordElim(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_a0_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2418, 3, 8); V a_1 = v_a0_2417; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args) {
  V v_u_2426 = args[0];
  heff_drop(v_u_2426);
  V v_t_2427 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2427});
}
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  heff_drop(v_x_2429);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  heff_drop(v_x_2430);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2428 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam7_clo)});
    V v_t_2431 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam8_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam9_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2431});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2425);
    V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2434}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args) {
  V v_u_2441 = args[0];
  heff_drop(v_u_2441);
  V v_t_2442 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2442});
}
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args) {
  V v_x_2444 = args[0];
  heff_drop(v_x_2444);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args) {
  V v_x_2445 = args[0];
  heff_drop(v_x_2445);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2440) == NTAG(TAG_True))) {
    heff_drop(v_x_2440);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2443 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam11_clo)});
    V v_t_2446 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam12_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam13_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_t_2446});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2440);
    V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2449}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2450;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam14(V self, V *args) {
  V v_x_2468 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_fieldTy_2467 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2468);
  V v_t_2469 = (g_heff_2eelab_2ememoed_2eproj(v_eprojectee_2416, v_x_242));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_fieldTy_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam15(V self, V *args) {
  V v_x_2480 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fieldTy_2479 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2480);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2eprojAt(v_eprojectee_2416, v_x_242, heff_dup(v_fieldTy_2479)));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2481, v_fieldTy_2479});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam17(V self, V *args) {
  V v_u_2496 = args[0];
  heff_drop(v_u_2496);
  V v_t_2497 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2497});
}
V g_heff_2eelab_2erules_2erecordElim_lam18(V self, V *args) {
  V v_x_2499 = args[0];
  heff_drop(v_x_2499);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam19(V self, V *args) {
  V v_x_24100 = args[0];
  heff_drop(v_x_24100);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam16(V self, V *args) {
  V v_x_2495 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2495) == NTAG(TAG_True))) {
    heff_drop(v_x_2495);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2498 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam17_clo)});
    V v_t_24101 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam18_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam19_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2498, v_t_24101});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2495);
    V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24104}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24105;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam21(V self, V *args) {
  V v_u_24107 = args[0];
  heff_drop(v_u_24107);
  V v_t_24108 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24108});
}
V g_heff_2eelab_2erules_2erecordElim_lam22(V self, V *args) {
  V v_x_24110 = args[0];
  heff_drop(v_x_24110);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam23(V self, V *args) {
  V v_x_24111 = args[0];
  heff_drop(v_x_24111);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam20(V self, V *args) {
  V v_x_24106 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24106) == NTAG(TAG_True))) {
    heff_drop(v_x_24106);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24109 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam21_clo)});
    V v_t_24112 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam22_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam23_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24109, v_t_24112});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24106);
    V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24115}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24116;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam25(V self, V *args) {
  V v_u_24118 = args[0];
  heff_drop(v_u_24118);
  V v_t_24119 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24119});
}
V g_heff_2eelab_2erules_2erecordElim_lam26(V self, V *args) {
  V v_x_24121 = args[0];
  heff_drop(v_x_24121);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam27(V self, V *args) {
  V v_x_24122 = args[0];
  heff_drop(v_x_24122);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam24(V self, V *args) {
  V v_x_24117 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24117) == NTAG(TAG_True))) {
    heff_drop(v_x_24117);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24120 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam25_clo)});
    V v_t_24123 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam26_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam27_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24120, v_t_24123});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24117);
    V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24126}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24127;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam29(V self, V *args) {
  V v_u_24129 = args[0];
  heff_drop(v_u_24129);
  V v_t_24130 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24130});
}
V g_heff_2eelab_2erules_2erecordElim_lam30(V self, V *args) {
  V v_x_24132 = args[0];
  heff_drop(v_x_24132);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam31(V self, V *args) {
  V v_x_24133 = args[0];
  heff_drop(v_x_24133);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam28(V self, V *args) {
  V v_x_24128 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24128) == NTAG(TAG_True))) {
    heff_drop(v_x_24128);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24131 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam29_clo)});
    V v_t_24134 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam30_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam31_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24131, v_t_24134});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24128);
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24137}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24138;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam33(V self, V *args) {
  V v_u_24140 = args[0];
  heff_drop(v_u_24140);
  V v_t_24141 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24141});
}
V g_heff_2eelab_2erules_2erecordElim_lam34(V self, V *args) {
  V v_x_24143 = args[0];
  heff_drop(v_x_24143);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam35(V self, V *args) {
  V v_x_24144 = args[0];
  heff_drop(v_x_24144);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam32(V self, V *args) {
  V v_x_24139 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24139) == NTAG(TAG_True))) {
    heff_drop(v_x_24139);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24142 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam33_clo)});
    V v_t_24145 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam34_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam35_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24142, v_t_24145});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24139);
    V v_t_24146 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24147 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24148}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24149;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam37(V self, V *args) {
  V v_u_24152 = args[0];
  heff_drop(v_u_24152);
  V v_t_24153 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24153});
}
V g_heff_2eelab_2erules_2erecordElim_lam38(V self, V *args) {
  V v_x_24155 = args[0];
  heff_drop(v_x_24155);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam39(V self, V *args) {
  V v_x_24156 = args[0];
  heff_drop(v_x_24156);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam36(V self, V *args) {
  V v_x_24151 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24151) == NTAG(TAG_True))) {
    heff_drop(v_x_24151);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24154 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam37_clo)});
    V v_t_24157 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam38_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam39_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24154, v_t_24157});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24151);
    V v_t_24158 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24159 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
    V v_t_24161 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24160}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24161;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam41(V self, V *args) {
  V v_u_24164 = args[0];
  heff_drop(v_u_24164);
  V v_t_24165 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24165});
}
V g_heff_2eelab_2erules_2erecordElim_lam42(V self, V *args) {
  V v_x_24167 = args[0];
  heff_drop(v_x_24167);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam43(V self, V *args) {
  V v_x_24168 = args[0];
  heff_drop(v_x_24168);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam40(V self, V *args) {
  V v_x_24163 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24163) == NTAG(TAG_True))) {
    heff_drop(v_x_24163);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24166 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam41_clo)});
    V v_t_24169 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam42_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam43_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24166, v_t_24169});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24163);
    V v_t_24170 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24171 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24170})});
    V v_t_24172 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24171})});
    V v_t_24173 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24172}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24173;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam45(V self, V *args) {
  V v_u_24175 = args[0];
  heff_drop(v_u_24175);
  V v_t_24176 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24176});
}
V g_heff_2eelab_2erules_2erecordElim_lam46(V self, V *args) {
  V v_x_24178 = args[0];
  heff_drop(v_x_24178);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam47(V self, V *args) {
  V v_x_24179 = args[0];
  heff_drop(v_x_24179);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam44(V self, V *args) {
  V v_x_24174 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24174) == NTAG(TAG_True))) {
    heff_drop(v_x_24174);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24177 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2erecordElim_lam45_clo)});
    V v_t_24180 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam46_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam47_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24177, v_t_24180});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24174);
    V v_t_24181 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str13), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str14)));
    V v_t_24182 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_24181, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24183 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24182})});
    V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
    V v_t_24185 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24184}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24185;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_eprojectee_2416 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2422)));
  switch (heff_tag_of(v_t_2423)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam6, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2423, 0ULL, 4);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam10, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRecord: {
    V v_capture_2452 = heff_field(v_t_2423, 1);
    V v_fieldTypes_2453 = heff_field(v_t_2423, 2);
    heff_take_n(v_t_2423, 6ULL, 3);
    HeffT2 v_t_2454 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_fieldTypes_2453, 1), v_x_242));
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2456;
        heff_drop(v_x_2457);
        V v_x1_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_eprojectee_2416, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_v_2462;
        switch (heff_tag_of(v_x1_2458)) {
        case TAG_Nom: {
          V v_x_2459 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          v_v_2462 = v_x_2459;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2458, 0ULL, 1);
          v_v_2462 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2461 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          v_v_2462 = v_x_2461;
          break;
        }
        default: heff_nomatch(v_x1_2458);
        }
        V v_t_2463 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_2462));
        HeffT2 v_t_2464 = ({ V a_0 = heff_dup(v_x_2422); V a_1 = v_t_2463; V a_2 = v_x_242; HeffT2 r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
        {
          V v_field_2466 = v_t_2464.f[1];
          int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
          if ((v_tag_2465 == ((int64_t)0ULL))) {
            heff_drop(v_capture_2452);
            heff_drop_rec(v_fieldTypes_2453, 3);
            V v_fieldTy_2467 = v_field_2466;
            return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2467); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam14, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_k_247, v_fieldTy_2467}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
          } else {
            heff_drop(v_field_2466);
            V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
            HeffT2 v_t_2471 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fieldTypes_2453, 1), v_x_242));
            V v_t_2475;
            {
              V v_field_2473 = v_t_2471.f[1];
              int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
              if ((v_tag_2472 == ((int64_t)0ULL))) {
                V v_i_2474 = v_field_2473;
                v_t_2475 = v_i_2474;
              } else {
                heff_drop(v_field_2473);
                v_t_2475 = heff_abandon();
              }
            }
            HeffT2 v_t_2476 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_t_2470, v_capture_2452, v_fieldTypes_2453, v_t_2475, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
            {
              V v_field_2478 = v_t_2476.f[1];
              int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
              if ((v_tag_2477 == ((int64_t)0ULL))) {
                V v_fieldTy_2479 = v_field_2478;
                return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2479); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam15, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_fieldTy_2479, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
              } else {
                heff_drop(v_x_2422);
                heff_drop_rec(v_eprojectee_2416, 2);
                heff_drop_rec(v_e_243, 6);
                heff_drop(v_field_2478);
                V v_t_2482 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str2), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2erecordElim_str3)));
                V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2482, v_sp_240, NTAG(TAG_Nothing)});
                V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2483})});
                V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
                V v_t_2486 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2485}));
                V f_ = heff_get_n(v_hd_246, 1, 3);
                heff_room[0] = v_t_2486;
                heff_room[1] = v_k_247;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          }
        }
      } else {
        heff_drop_rec(v_eprojectee_2416, 2);
        heff_drop(v_capture_2452);
        heff_drop_rec(v_fieldTypes_2453, 3);
        heff_drop(v_field_2456);
        V v_t_2487 = (g_heff_2eelab_2erules_2etyStr(v_e_243, v_x_2422));
        V v_t_2488 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str4), v_t_2487));
        V v_msg_2489 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str5), v_t_2488);
        V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2489, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
        V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
        V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2492}));
        V f_ = heff_get_n(v_hd_246, 1, 3);
        heff_room[0] = v_t_2493;
        heff_room[1] = v_k_247;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam16, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam20, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam24, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeString: {
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam28, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam32, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam36, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam40, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_NoRules: {
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 6);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam44, 1, 4, (V[]){v_k_247, v_x_242, v_sp_240, v_hd_246})));
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_eprojectee_2416 = heff_field(v_x_2415, 0);
    V v_a0_2417 = heff_field(v_x_2415, 1);
    heff_take_n(v_x_2415, 3ULL, 2);
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam4, 1, 1, (V[]){v_a0_2417})})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2420}));
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam5, 1, 6, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_eprojectee_2416, v_e_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_x_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 2ULL, 2);
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_243), heff_dup(v_sp_240), v_t_2411, v_t_2414, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam3, 1, 5, (V[]){v_hd_246, v_k_247, v_sp_240, v_x_242, v_e_243})));
}
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam2, 1, 5, (V[]){v_e_243, v_sp_240, v_hd_246, v_k_247, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_projectee_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245;
  switch (heff_tag_of(v_projectee_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_projectee_241, 0);
    heff_take_n(v_projectee_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_projectee_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam1, 2, 4, (V[]){v_c_245, v_e_243, v_sp_240, v_x_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str0, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str1, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str2, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str3, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str4, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str5, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str6, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str7, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str8, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str9, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str10, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str11, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str12, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str13, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str14, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str15, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str16, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str17, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str18, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str19, 27, "can only specialize neutral");
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordSpec_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_x_242, heff_dup(v_c_243)})});
}
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordSpec(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args) {
  V v_x_2482 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2483 = (g_heff_2eelab_2ememoed_2especializeM(v_g_2410, v_x_242, v_x_2482));
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2483, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_c_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x_249, 0);
    V v_a_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_x1_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_2410, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2413;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      v_t_2416 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_VNeu: {
      V v_desc_2421 = heff_field(v_t_2416, 4);
      heff_take_n(v_t_2416, 16ULL, 5);
      V v_it_2422 = heff_tr(heff_call(v_desc_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_it_2422)) {
      case TAG_Nothing: {
        heff_drop(v_x_242);
        heff_drop_rec(v_e_244, 6);
        heff_drop(v_c_243);
        heff_drop_rec(v_g_2410, 2);
        heff_drop(v_a_2411);
        V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str0), v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_2426;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_it1_2427 = heff_field(v_it_2422, 0);
        V v_ru_24it_2422_24Just = heff_take_reuse_n(v_it_2422, 1ULL, 1);
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_VNeu: {
          heff_take_n(v_it1_2427, 0ULL, 5);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str1), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2434 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2435}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_2436;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCode: {
          V v_it11_2437 = heff_field(v_it1_2427, 0);
          V v_ru_24it1_2427_24VCode = heff_take_reuse_n(v_it1_2427, 1ULL, 1);
          switch (heff_tag_of(v_it11_2437)) {
          case TAG_VU: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str2), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
            V v_t_2441 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
            V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2441}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2442;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VDecode: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str3), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2449 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
            V v_t_2450 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2450}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2451;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFunction: {
            heff_take_n(v_it11_2437, 0ULL, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str4), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2459 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
            V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2460}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2461;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VRecord: {
            V v_capture_2463 = heff_field(v_it11_2437, 1);
            V v_fieldTypes_2464 = heff_field(v_it11_2437, 2);
            heff_take_n(v_it11_2437, 6ULL, 4);
            HeffT2 v_t_2466 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_fieldTypes_2464, 1), v_x_242));
            {
              V v_field_2468 = v_t_2466.f[1];
              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
              if ((v_tag_2467 == ((int64_t)0ULL))) {
                heff_drop(v_sp_240);
                heff_drop_cell(v_ru_24it1_2427_24VCode, 1);
                V v_x_2469 = v_field_2468;
                heff_drop(v_x_2469);
                V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
                V v_t_2471 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2464, 0)));
                V v_t_2472 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2464, 2)));
                V v_t_2473 = (g_heff_2eutil_2edict_2ezipKV(v_t_2471, v_t_2472));
                V v_xs_2474 = (g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(heff_dup(v_capture_2463), heff_tag_at_n(v_ru_24it_2422_24Just, TAG_HLocal, 1, (V[]){v_t_2470}), NTAG(TAG_SpId), NTAG(TAG_Nothing), v_t_2473, NTAG(TAG_Nil)));
                V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2474));
                V v_t_2476 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_2464, 0)), heff_dup(heff_rfield(v_fieldTypes_2464, 1)), heff_arrayFromList(v_t_2475)});
                V v_t_2477 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2463, v_fieldTypes_2464, v_x_242, v_t_2476));
                switch (heff_tag_of(v_t_2477)) {
                case TAG_MkField: {
                  V v_fty_2478 = heff_field(v_t_2477, 0);
                  heff_take_n(v_t_2477, 1ULL, 2);
                  V v_c_2481;
                  switch (heff_tag_of(v_c_243)) {
                  case TAG_MkChk: {
                    V v_f_2480 = heff_field(v_c_243, 0);
                    heff_take_n(v_c_243, 1ULL, 1);
                    v_c_2481 = heff_tr(heff_call(v_f_2480, 2, (V[]){v_e_244, v_fty_2478}));
                    break;
                  }
                  default: heff_nomatch(v_c_243);
                  }
                  V f_ = v_c_2481;
                  heff_room[0] = v_hd_247;
                  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam3, 1, 4, (V[]){v_g_2410, v_x_242, v_k_248, v_a_2411});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                }
                default: return heff_nomatch(v_t_2477);
                }
              } else {
                heff_drop_rec(v_e_244, 6);
                heff_drop(v_c_243);
                heff_drop_rec(v_g_2410, 2);
                heff_drop(v_a_2411);
                heff_drop(v_capture_2463);
                heff_drop_rec(v_fieldTypes_2464, 3);
                heff_drop(v_field_2468);
                V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordSpec_str5), v_x_242), v_sp_240, NTAG(TAG_Nothing)});
                V v_t_2485 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
                V v_t_2486 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
                V v_t_2487 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2486}));
                V f_ = heff_get_n(v_hd_247, 1, 3);
                heff_room[0] = v_t_2487;
                heff_room[1] = v_k_248;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          }
          case TAG_VSum: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2489 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str6), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2490 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2489})});
            V v_t_2491 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
            V v_t_2492 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2491}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2492;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimInt: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str7), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2494 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2493})});
            V v_t_2495 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
            V v_t_2496 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2495}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2496;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimFloat: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2497 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str8), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2498 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
            V v_t_2499 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
            V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2499}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24100;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimString: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24101 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str9), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24102 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24101})});
            V v_t_24103 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
            V v_t_24104 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24103}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24104;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimRune: {
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str10), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24106 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24105})});
            V v_t_24107 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
            V v_t_24108 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24107}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24108;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimArray: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str11), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24111 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24110})});
            V v_t_24112 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
            V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24112}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24113;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFixed: {
            heff_take_n(v_it11_2437, 0ULL, 1);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 6);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str12), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24116 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
            V v_t_24117 = heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
            V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24117}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24118;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          default: return heff_nomatch(v_it11_2437);
          }
        }
        case TAG_VLam: {
          heff_take_n(v_it1_2427, 0ULL, 2);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str13), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24122 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
          V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
          V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24123}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24124;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCons: {
          V v_ru_24it1_2427_24VCons = heff_take_reuse_n(v_it1_2427, 0ULL, 1);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str14), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24127 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
          V v_t_24128 = heff_tag_at_n(v_ru_24it1_2427_24VCons, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
          V v_t_24129 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24128}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24129;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 6);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str15), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24131 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24130})});
          V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
          V v_t_24133 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24132}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24133;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_it1_2427);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_VCode: {
      V v_ru_24t_2416_24VCode = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str16), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24136 = heff_tag_at_n(v_ru_24t_2416_24VCode, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
      V v_t_24138 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24137}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24138;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VLam: {
      heff_take_n(v_t_2416, 0ULL, 2);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24141 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str17), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24142 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24141})});
      V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
      V v_t_24144 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24143}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24144;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VCons: {
      V v_ru_24t_2416_24VCons = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24146 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str18), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24147 = heff_tag_at_n(v_ru_24t_2416_24VCons, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24146})});
      V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
      V v_t_24149 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24148}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24149;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VOpaque: {
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 6);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str19), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24151 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24150})});
      V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
      V v_t_24153 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24152}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24153;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_c_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam2, 1, 6, (V[]){v_sp_240, v_hd_247, v_k_248, v_x_242, v_e_244, v_c_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_x_242, v_e_244, v_c_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2esealedOf_24cpr_str0, 4, "(..)");

HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VDecode: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_described_246 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 9ULL, 5);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_HLocal: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_g_240, 6); V b_1 = heff_strAppend(v_k_249, ((V)&g_heff_2eelab_2erules_2esealedOf_24cpr_str0)); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop_rec(v_g_240, 8);
          heff_drop(v_described_246);
          V v_m_2413 = v_field_2412;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_m_2413}});
        } else {
          heff_drop(v_field_2412);
          V v_t_2414 = heff_tr(heff_call(v_described_246, 1, (V[]){NTAG(TAG_MkUnit)}));
          switch (heff_tag_of(v_t_2414)) {
          case TAG_Nothing: {
            heff_drop_rec(v_g_240, 8);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_t_2415 = heff_field(v_t_2414, 0);
            heff_take_n(v_t_2414, 1ULL, 1);
            V t_0 = v_g_240;
            V t_1 = v_t_2415;
            v_g_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
          }
        }
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HError: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_243)}});
    }
  }
  case TAG_VFunction: {
    heff_take_n(v_x2_241, 0ULL, 6);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRecord: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimInt: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimFloat: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimString: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimRune: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2elocalDef_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_lam7, 1, 0};
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elocalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_entry, 4, 0};

V g_heff_2eelab_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam0, 2, 4, (V[]){heff_dup(v_typ_241), v_x_240, heff_dup(v_body_242), heff_dup(v_rest_243)})});
}
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2elocalDef(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args) {
  V v_v_2431 = args[0];
  V v_scope_27_2432 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2431);
  switch (heff_tag_of(v_rest_243)) {
  case TAG_MkChk: {
    V v_f_2433 = heff_field(v_rest_243, 0);
    heff_take_n(v_rest_243, 1ULL, 1);
    V v_t_2434 = ({ V rv_0 = v_scope_27_2432; V rr_ = heff_rec_reuse_nf(v_e_244, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2433;
    args[0] = v_t_2434;
    args[1] = v_b_245;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_rest_243);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args) {
  V v_u_2444 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_245});
}
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args) {
  V v_u_2451 = args[0];
  heff_drop(v_u_2451);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_take_field(v_e_244, 2);
  V v_t_2440;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_ForNominative: {
    v_t_2440 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2440 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2442, MK_INT(1LL)), heff_dup(v_b_245)));
  V v_cod_2445 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2443, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam6, 1, 1, (V[]){v_b_245})})});
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2447 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_244, 1)), v_t_2446, heff_dup(v_x_2411), v_cod_2445));
  V v_t_2448 = (g_heff_2eelab_2ememoed_2elam(v_t_2440, heff_get_n(v_e_244, 1, 6), v_t_2441, v_t_2447, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), v_x_2436})));
  V v_t_2449 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_get_n(v_x_2425, 0, 2)});
  V v_t_2450 = heff_tag_n(TAG_SFix, 2, (V[]){heff_get_n(v_x_2411, 0, 2), v_t_2449});
  V v_x_2452 = (g_heff_2eelab_2ememoed_2eapp(v_t_2448, heff_rec_n(2, shape_stx__val, (V[]){v_t_2450, ((V)&g_heff_2eelab_2erules_2elocalDef_lam7_clo)})));
  V f_ = v_k_2410;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_c_2435 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2430, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam4, 2, 3, (V[]){v_rest_243, heff_dup(v_e_244), heff_dup(v_b_245)})));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam5, 1, 6, (V[]){v_e_244, v_b_245, v_x_240, v_x_2411, v_x_2425, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_e_2417 = (g_heff_2eelab_2erules_2efixEnv(heff_dup(v_e_244), heff_dup(v_x_240), v_t_2416));
  V v_x1_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_a_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_a_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2424;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2423 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2424 = heff_tr(heff_call(v_f_2423, 2, (V[]){v_e_2417, v_a_2422}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam3, 1, 7, (V[]){v_x_2411, v_x_240, v_e_244, v_rest_243, v_b_245, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam2, 1, 7, (V[]){v_e_244, v_x_240, v_body_242, v_hd_249, v_rest_243, v_b_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_typ_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_248;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_246 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    V v_t_247 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_244, 0)), heff_dup(heff_rfield(v_e_244, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_244, 3)), heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_248 = heff_tr(heff_call(v_f_246, 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_x_240, v_body_242, v_rest_243, v_b_245});
}