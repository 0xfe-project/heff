// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkChain 10459
#define TAG_MkDAlts 45152
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_ops 319788
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__text[] = {LBL_imports, LBL_text};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2echain(V);
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V, V);
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2etoks_2eattach(V, V, V);
V g_heff_2esyntax_2efmt_2etoks_2eattach_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etoks_2eattach_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1221903513x233153387(V);
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s422923909x1655406376(V);
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s650596433x61515523(V, V);
V g_std_2edoc_2econcatWith_24s650596433x61515523_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s650596433x61515523_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static int g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return heff_strFromCharCode(MK_INT(1LL));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (g_heff_2esyntax_2efmt_2elayout_2eblankMark_st == 2) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  if (g_heff_2esyntax_2efmt_2elayout_2eblankMark_st == 1) heff_fail("defined by itself");
  g_heff_2esyntax_2efmt_2elayout_2eblankMark_st = 1;
  g_heff_2esyntax_2efmt_2elayout_2eblankMark_val = heff_tr(g_heff_2esyntax_2efmt_2elayout_2eblankMark_init());
  g_heff_2esyntax_2efmt_2elayout_2eblankMark_st = 2;
  return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
}

static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
static int g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init(void) {
  return heff_strFromCharCode(MK_INT(2LL));
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void) {
  if (g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st == 2) return g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
  if (g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st == 1) heff_fail("defined by itself");
  g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st = 1;
  g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val = heff_tr(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init());
  g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st = 2;
  return g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_e_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_e_241))) {
    V v_t_243 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(32LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      V v_t_245 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
      if (heff_intEq_c(v_t_245, MK_INT(9LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_e_241 = t_1;
        goto top;
      } else {
        V v_t_247 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
        if (heff_intEq_c(v_t_247, MK_INT(13LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_e_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          return v_e_241;
        }
      }
    }
  } else {
    heff_drop(v_s_240);
    return v_e_241;
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0, 0, (0));

static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
static int g_heff_2esyntax_2efmt_2elayout_2eblankLine_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_241;
  if (heff_strEq_c(heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0))) {
    v_t_241 = NTAG(TAG_None);
  } else {
    v_t_241 = heff_tag_n(TAG_Text, 1, (V[]){heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get())});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_241, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void) {
  if (g_heff_2esyntax_2efmt_2elayout_2eblankLine_st == 2) return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
  if (g_heff_2esyntax_2efmt_2elayout_2eblankLine_st == 1) heff_fail("defined by itself");
  g_heff_2esyntax_2efmt_2elayout_2eblankLine_st = 1;
  g_heff_2esyntax_2efmt_2elayout_2eblankLine_val = heff_tr(g_heff_2esyntax_2efmt_2elayout_2eblankLine_init());
  g_heff_2esyntax_2efmt_2elayout_2eblankLine_st = 2;
  return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3, 1, (32));
Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V v_env_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_get_n(v_t_241, 7, 9); V b_1 = heff_get_n(v_env_240, 3, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_c_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_x2_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0), v_c_243, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_s_247 = ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_s_247 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_s_247), ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2))) {
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      heff_drop(v_s_247);
      v_t_249 = NTAG(TAG_None);
    } else {
      v_t_249 = heff_tag_at_n(v_ru_24t_242_24Just, TAG_Text, 1, (V[]){v_s_247});
    }
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_dup(g_std_2edoc_2ehardline_get())));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3)}), v_t_2410);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailOf(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_245;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_245 = NTAG(TAG_Nil);
  } else {
    V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_x1_245 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_x1_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
  }
  V v_t_2414;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_2411;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2411 = NTAG(TAG_Nil);
    } else {
      V v_x2_249 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
    }
    V v_ds_2412 = (g_list_2emap_24s1221903513x233153387(v_t_2411));
    V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2412; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x2_2415 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 2)));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_ds_2418 = (g_list_2emap_24s422923909x1655406376(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2418); r_; });
  V v_s_2420 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2422;
  if (heff_strEq_c(heff_dup(v_s_2420), ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0))) {
    heff_drop(v_s_2420);
    v_t_2422 = NTAG(TAG_None);
  } else {
    v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2420});
  }
  V v_t_2424;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2424 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2424));
  V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2425));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2426);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_x2_247 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0), heff_dup(heff_rfield(v_c_242, 0)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_s_2410 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_s_2410 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2412;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2))) {
      heff_drop(v_s_2410);
      v_t_2412 = NTAG(TAG_None);
    } else {
      v_t_2412 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2410});
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2415);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitem_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243) {
top: ;
  V v_x2_244 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_x1_2410;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    v_x1_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    v_x1_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_x1_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x1_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2410, 0ULL, 2);
    v_x1_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_True: {
    v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_False: {
    V v_t_2414 = heff_dup(heff_rfield(v_first_241, 8));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2416 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_get_n(v_first_241, 7, 9), heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 6))});
  V v_t_2417 = heff_tr(heff_apply(v_body_243, 1, (V[]){v_t_2416}));
  V v_t_2419;
  if (heff_intEq_c(heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_last2_242, 9);
    v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_last2_242));
  }
  V v_d_2420 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2419));
  V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2415, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2420})));
  return (g_std_2edoc_2e_3c_3e(v_t_247, v_t_2421));
}
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eitem(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2462 = heff_field(v_e_240, 3);
    V t_0 = v_body_2462;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, (61));
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2427 = heff_field(v_e_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2427, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esameOp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241) {
top: ;
  switch (heff_tag_of(v_other_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_op_240, 9);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_other1_242 = heff_field(v_other_241, 0);
    switch (heff_tag_of(v_other1_242)) {
    case TAG_Atom: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      V v_op2_2448 = heff_field(v_other1_242, 0);
      return heff_strEq(heff_dup(heff_rfield(v_op2_2448, 1)), heff_get_n(v_op_240, 1, 9));
    }
    case TAG_Ann: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ESBind: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_other1_242);
    }
  }
  default: return heff_nomatch(v_other_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2esameOp(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2echain_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2echain(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EParen: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Named: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Tup: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Braces: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_InstB: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFDefault: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Sum: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECon: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EField: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_App: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Op: {
    V v_a_2440 = heff_field(v_e_240, 0);
    V v_op_2441 = heff_field(v_e_240, 1);
    V v_b_2442 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x4_2443 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_dup(v_b_2442)));
    switch (heff_tag_of(v_x4_2443)) {
    case TAG_MkChain: {
      V v_bf_2444 = heff_field(v_x4_2443, 0);
      V v_rest_2445 = heff_field(v_x4_2443, 1);
      V v_ru_24x4_2443_24MkChain = heff_take_reuse_n(v_x4_2443, 3ULL, 2);
      V v_t_2446 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2441), v_rest_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_True: {
        heff_drop(v_b_2442);
        V v_t_2447 = heff_tag_at_n(v_ru_24x4_2443_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2441, v_bf_2444}), v_rest_2445});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2440, v_t_2447});
      }
      case TAG_False: {
        heff_drop(v_bf_2444);
        heff_drop(v_rest_2445);
        V v_t_2448 = heff_tag_at_n(v_ru_24x4_2443_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2441, v_b_2442}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2440, v_t_2448});
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_x4_2443);
    }
  }
  case TAG_Ops: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_OpRhs: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Ann: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BVar: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BImp: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BAnn: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Lam: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Case: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAlt: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_If: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Do: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ESBind: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2echain(a[0]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, (45, 62));
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2447 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2447, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, (32));
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2411 = heff_tr(heff_apply(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      v_t_2412 = v_commas_243;
      break;
    }
    case TAG_False: {
      v_t_2412 = (g_list_2edrop(MK_INT(1LL), v_commas_243));
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str1, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str2, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str3, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str4, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str5, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epP_str6, 1, (32));
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_ds_247 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_args_243)));
    V v_t_248 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_247; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_247); r_; });
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_244, v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_249));
  }
  case TAG_PParen: {
    V v_o_2410 = heff_field(v_x2_241, 0);
    V v_p_2411 = heff_field(v_x2_241, 1);
    V v_c_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2410)));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2411));
    V v_t_2415 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2412)));
    V v_t_2416 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2415));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2416);
  }
  case TAG_PList: {
    V v_o_2417 = heff_field(v_x2_241, 0);
    V v_ps_2418 = heff_field(v_x2_241, 1);
    V v_commas_2419 = heff_field(v_x2_241, 2);
    V v_c_2420 = heff_field(v_x2_241, 3);
    V v_t_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2417)));
    V v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2418, heff_dup(v_commas_2419), NTAG(TAG_True)));
    V v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2420)));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2423, v_t_2424));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2421, v_t_2425);
  }
  case TAG_POp: {
    V v_l_2426 = heff_field(v_x2_241, 0);
    V v_op_2427 = heff_field(v_x2_241, 1);
    V v_r_2428 = heff_field(v_x2_241, 2);
    V v_a_2429 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2426));
    V v_a_2430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2427)));
    V v_b_2431 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_r_2428));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str1)}), v_b_2431));
    V v_b_2433 = (g_std_2edoc_2e_3c_3e(v_a_2430, v_t_2432));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str2)}), v_b_2433));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2434);
  }
  case TAG_PRec: {
    V v_o_2435 = heff_field(v_x2_241, 0);
    V v_fs_2436 = heff_field(v_x2_241, 1);
    V v_commas_2437 = heff_field(v_x2_241, 2);
    V v_c_2438 = heff_field(v_x2_241, 3);
    V v_a_2439 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2435)));
    V v_a_2441 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2436, heff_dup(v_commas_2437), NTAG(TAG_True)));
    V v_b_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2438)));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str3)}), v_b_2442));
    V v_b_2444 = (g_std_2edoc_2e_3c_3e(v_a_2441, v_t_2443));
    V v_t_2445 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str4)}), v_b_2444));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2439, v_t_2445);
  }
  case TAG_PField: {
    V v_x_2446 = heff_field(v_x2_241, 0);
    V v_eq_2447 = heff_field(v_x2_241, 1);
    V v_p_2448 = heff_field(v_x2_241, 2);
    V v_a_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2446)));
    V v_a_2450 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2447)));
    V v_b_2451 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2448));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str5)}), v_b_2451));
    V v_b_2453 = (g_std_2edoc_2e_3c_3e(v_a_2450, v_t_2452));
    V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str6)}), v_b_2453));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2454);
  }
  case TAG_PAs: {
    V v_x_2455 = heff_field(v_x2_241, 0);
    V v_at_2456 = heff_field(v_x2_241, 1);
    V v_p_2457 = heff_field(v_x2_241, 2);
    V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2455)));
    V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2456)));
    V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2457));
    V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2459, v_t_2460));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2461);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2epP(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2422 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2422; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2422); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2440 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2440; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2440); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_r_242)) {
    case TAG_Atom: {
      heff_take_n(v_r_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EParen: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Named: {
      heff_take_n(v_r_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Tup: {
      heff_take_n(v_r_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Braces: {
      heff_take_n(v_r_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_InstB: {
      heff_take_n(v_r_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFSet: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFDefault: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Sum: {
      heff_take_n(v_r_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECon: {
      heff_take_n(v_r_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EField: {
      heff_take_n(v_r_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_App: {
      heff_take_n(v_r_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Op: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Ops: {
      heff_take_n(v_r_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRhs: {
      V v_op_2448 = heff_field(v_r_242, 0);
      heff_take_n(v_r_242, 1ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0, 1, 1, (V[]){heff_dup(v_op_2448)}), heff_rfield(v_f_240, 0)));
      switch (heff_tag_of(v_t_2452)) {
      case TAG_Nothing: {
        heff_drop_rec(v_f_240, 2);
        heff_drop(v_rs_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_rec(v_op_2448, 9);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ru_24t_2452_24Just = heff_take_reuse_n(v_t_2452, 0ULL, 1);
        V v_x2_2454 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(v_f_240, v_rs_243));
        switch (heff_tag_of(v_x2_2454)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2448, 9);
          heff_drop_cell(v_ru_24t_2452_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_ops_2455 = heff_field(v_x2_2454, 0);
          heff_take_n(v_x2_2454, 1ULL, 1);
          V v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2448, 1, 9), v_ops_2455});
          return heff_tag_at_n(v_ru_24t_2452_24Just, TAG_Just, 1, (V[]){v_t_2456});
        }
        default: return heff_nomatch(v_x2_2454);
        }
      }
      default: return heff_nomatch(v_t_2452);
      }
    }
    case TAG_Ann: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BVar: {
      heff_take_n(v_r_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BImp: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BAnn: {
      heff_take_n(v_r_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Lam: {
      heff_take_n(v_r_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Case: {
      heff_take_n(v_r_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAlt: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_If: {
      heff_take_n(v_r_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Do: {
      heff_take_n(v_r_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESBind: {
      heff_take_n(v_r_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_r_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_r_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eopsOf(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args) {
  V v_g_2450 = args[0];
  V v_op_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_op_2448, 1, 9)}));
  return ({ V a_0 = v_t_2451; V b_1 = heff_get_n(v_g_2450, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2447 = heff_field(v_r_242, 0);
    V v_t_2449 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2447, 1))));
    switch (heff_tag_of(v_t_2449)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2449, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2449, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2449);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2413;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        v_t_2412 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        heff_drop_rec(v_t_246, 9);
        v_t_2412 = heff_get_n(v_x_2410, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 2, (V[]){v_e_2416, v_x_243});
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2413;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        v_t_2412 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        heff_drop_rec(v_t_246, 9);
        v_t_2412 = heff_get_n(v_x_2410, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 2, (V[]){v_e_2416, v_x_243});
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, (32));
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam81_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static int g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam16_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam17_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam18_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam74_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam75_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam76_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam77_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam78_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam81_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam82_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (g_heff_2esyntax_2efmt_2elayout_2elay_st == 2) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  if (g_heff_2esyntax_2efmt_2elayout_2elay_st == 1) heff_fail("defined by itself");
  g_heff_2esyntax_2efmt_2elayout_2elay_st = 1;
  g_heff_2esyntax_2efmt_2elayout_2elay_val = heff_tr(g_heff_2esyntax_2efmt_2elayout_2elay_init());
  g_heff_2esyntax_2efmt_2elayout_2elay_st = 2;
  return g_heff_2esyntax_2efmt_2elayout_2elay_val;
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c(heff_dup(v_i_2411), MK_INT(0LL))) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_d_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2456 = heff_intSub(v_k_2454, v_i_2455);
  if (heff_intEq_c(heff_dup(v_i_2456), MK_INT(0LL))) {
    heff_drop(v_i_2456);
    return v_d_2453;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2456, v_d_2453});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2454 = args[0];
  V v_d_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2454, v_d_2453})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_comma_2471 = args[0];
  V v_f_2472 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2471));
  V v_d_2474 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2472}));
  V v_b_2475 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2474});
  V v_t_2476 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), v_b_2475));
  V v_t_2477 = (g_std_2edoc_2e_3c_3e(v_a_2473, v_t_2476));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2477));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_i_2485 = args[0];
  V v_k_2484 = heff_env(self)[0];
  V v_d_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2486 = heff_intSub(v_k_2484, v_i_2485);
  if (heff_intEq_c(heff_dup(v_i_2486), MK_INT(0LL))) {
    heff_drop(v_i_2486);
    return v_d_2483;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2486, v_d_2483});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_k_2484 = args[0];
  V v_d_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 2, (V[]){v_k_2484, v_d_2483})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_bar_24135 = args[0];
  V v_a_24136 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24137 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24135));
  V v_b_24138 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24136}));
  V v_t_24139 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), v_b_24138));
  V v_t_24140 = (g_std_2edoc_2e_3c_3e(v_a_24137, v_t_24139));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24140));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_i_24148 = args[0];
  V v_k_24147 = heff_env(self)[0];
  V v_d_24146 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24149 = heff_intSub(v_k_24147, v_i_24148);
  if (heff_intEq_c(heff_dup(v_i_24149), MK_INT(0LL))) {
    heff_drop(v_i_24149);
    return v_d_24146;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24149, v_d_24146});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_k_24147 = args[0];
  V v_d_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 2, (V[]){v_k_24147, v_d_24146})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_a_24156 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24157 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24156}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_t_24157));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_r_24173 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24171 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24174 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24171, v_r_24173}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24174));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24288 = args[0];
  V v_k_24287 = heff_env(self)[0];
  V v_d_24286 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24289 = heff_intSub(v_k_24287, v_i_24288);
  if (heff_intEq_c(heff_dup(v_i_24289), MK_INT(0LL))) {
    heff_drop(v_i_24289);
    return v_d_24286;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24289, v_d_24286});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24287 = args[0];
  V v_d_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24287, v_d_24286})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_b_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_b_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_ds_2446 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2431, v_more_2436));
      V v_t_2447 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2446; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2446); r_; });
      V v_t_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2449 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2448));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2447, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2451));
      V v_d_2453 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2452));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2453})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Braces: {
    V v_o_2458 = heff_field(v_e0_241, 0);
    V v_fs_2459 = heff_field(v_e0_241, 1);
    V v_commas_2460 = heff_field(v_e0_241, 2);
    V v_c_2461 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2459)) {
    case TAG_Nil: {
      heff_drop(v_commas_2460);
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    }
    case TAG_Cons: {
      V v_f1_2464 = heff_field(v_fs_2459, 0);
      V v_more_2465 = heff_field(v_fs_2459, 1);
      V v_ru_24fs_2459_24Cons = heff_take_reuse_n(v_fs_2459, 3ULL, 2);
      V v_a_2466 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_d_2467 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2464}));
      V v_b_2468 = heff_tag_at_n(v_ru_24fs_2459_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2467});
      V v_t_2469 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), v_b_2468));
      V v_t_2470 = (g_std_2edoc_2e_3c_3e(v_a_2466, v_t_2469));
      V v_ds_2478 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2460, v_more_2465));
      V v_t_2479 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2478; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2478); r_; });
      V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2480));
      V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2479, v_t_2481));
      V v_d_2483 = (g_std_2edoc_2e_3c_3e(v_t_2470, v_t_2482));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 1, 1, (V[]){v_d_2483})})));
    }
    default: return heff_nomatch(v_fs_2459);
    }
  }
  case TAG_InstB: {
    V v_o_2488 = heff_field(v_e0_241, 0);
    V v_o2_2489 = heff_field(v_e0_241, 1);
    V v_d_2490 = heff_field(v_e0_241, 2);
    V v_c1_2491 = heff_field(v_e0_241, 3);
    V v_c_2492 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2493 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2488));
    V v_t_2494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_2489));
    V v_t_2495 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_2490}));
    V v_t_2496 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_2491));
    V v_t_2497 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2492));
    V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2496, v_t_2497));
    V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2498));
    V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2494, v_t_2499));
    return (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_24100));
  }
  case TAG_EFSet: {
    V v_x_24101 = heff_field(v_e0_241, 0);
    V v_eq_24102 = heff_field(v_e0_241, 1);
    V v_e_24103 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24101));
    V v_b_24105 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24102));
    V v_t_24106 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24105));
    V v_t_24107 = (g_std_2edoc_2e_3c_3e(v_a_24104, v_t_24106));
    V v_t_24108 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24103}));
    return (g_std_2edoc_2e_3c_3e(v_t_24107, v_t_24108));
  }
  case TAG_EFDefault: {
    V v_d_24109 = heff_field(v_e0_241, 0);
    V v_eq_24110 = heff_field(v_e0_241, 1);
    V v_e_24111 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24112 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24109}));
    V v_b_24113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24110));
    V v_t_24114 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_b_24113));
    V v_t_24115 = (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24114));
    V v_t_24116 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24111}));
    return (g_std_2edoc_2e_3c_3e(v_t_24115, v_t_24116));
  }
  case TAG_Sum: {
    V v_kw_24117 = heff_field(v_e0_241, 0);
    V v_o_24118 = heff_field(v_e0_241, 1);
    V v_alts_24119 = heff_field(v_e0_241, 2);
    V v_bars_24120 = heff_field(v_e0_241, 3);
    V v_c_24121 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24119)) {
    case TAG_Nil: {
      heff_drop(v_bars_24120);
      V v_a_24122 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24117));
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24118));
      V v_b_24124 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24121));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_b_24124));
      V v_b_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_t_24127 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), v_b_24126));
      return (g_std_2edoc_2e_3c_3e(v_a_24122, v_t_24127));
    }
    case TAG_Cons: {
      V v_a1_24128 = heff_field(v_alts_24119, 0);
      V v_more_24129 = heff_field(v_alts_24119, 1);
      heff_take_n(v_alts_24119, 3ULL, 2);
      V v_a_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24117));
      V v_a_24131 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24118));
      V v_b_24132 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24128}));
      V v_t_24133 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), v_b_24132));
      V v_t_24134 = (g_std_2edoc_2e_3c_3e(v_a_24131, v_t_24133));
      V v_ds_24141 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 2, 1, (V[]){heff_dup(v_env_240)}), v_bars_24120, v_more_24129));
      V v_a_24142 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24141; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24141); r_; });
      V v_b_24143 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24121));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24143));
      V v_t_24145 = (g_std_2edoc_2e_3c_3e(v_a_24142, v_t_24144));
      V v_d_24146 = (g_std_2edoc_2e_3c_3e(v_t_24134, v_t_24145));
      V v_b_24151 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 1, 1, (V[]){v_d_24146})})));
      V v_t_24152 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24151));
      return (g_std_2edoc_2e_3c_3e(v_a_24130, v_t_24152));
    }
    default: return heff_nomatch(v_alts_24119);
    }
  }
  case TAG_ECon: {
    V v_c_24153 = heff_field(v_e0_241, 0);
    V v_args_24154 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24155 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24153));
    V v_ds_24158 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 1, (V[]){v_env_240}), v_args_24154));
    V v_t_24159 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24158; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24158); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24155, v_t_24159));
  }
  case TAG_EField: {
    V v_e_24160 = heff_field(v_e0_241, 0);
    V v_f_24161 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24162 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24160}));
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24161));
    return (g_std_2edoc_2e_3c_3e(v_t_24162, v_t_24163));
  }
  case TAG_App: {
    V v_h_24164 = heff_field(v_e0_241, 0);
    V v_args_24165 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6)), 3, (V[]){v_env_240, v_h_24164, v_args_24165});
  }
  case TAG_Op: {
    V v_a_24166 = heff_field(v_e0_241, 0);
    V v_op_24167 = heff_field(v_e0_241, 1);
    V v_b_24168 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    V v_t_24169 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24166, v_op_24167, v_b_24168})));
    switch (heff_tag_of(v_t_24169)) {
    case TAG_MkChain: {
      V v_first_24170 = heff_field(v_t_24169, 0);
      V v_rest_24171 = heff_field(v_t_24169, 1);
      heff_take_n(v_t_24169, 3ULL, 2);
      V v_t_24172 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24171), v_first_24170}));
      V v_ds_24175 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24171)}), v_rest_24171));
      V v_t_24176 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24175; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24175); r_; });
      V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_t_24172, v_t_24176));
      return (g_std_2edoc_2egroup(v_t_24177));
    }
    default: return heff_nomatch(v_t_24169);
    }
  }
  case TAG_Ops: {
    V v_a_24178 = heff_field(v_e0_241, 0);
    V v_rest_24179 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){v_env_240, v_a_24178, v_rest_24179});
  }
  case TAG_OpRhs: {
    V v_op_24180 = heff_field(v_e0_241, 0);
    V v_e_24181 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24182 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24180));
    V v_b_24183 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24181}));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24183));
    return (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
  }
  case TAG_Ann: {
    V v_e_24185 = heff_field(v_e0_241, 0);
    V v_cc_24186 = heff_field(v_e0_241, 1);
    V v_ty_24187 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24188 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24185}));
    V v_b_24189 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24186));
    V v_t_24190 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_b_24189));
    V v_t_24191 = (g_std_2edoc_2e_3c_3e(v_a_24188, v_t_24190));
    V v_t_24192 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24187}));
    V v_d_24193 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24192));
    V v_t_24194 = (g_std_2edoc_2e_3c_3e(v_t_24191, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24193})));
    return (g_std_2edoc_2egroup(v_t_24194));
  }
  case TAG_BVar: {
    V v_t_24195 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24195));
  }
  case TAG_BImp: {
    V v_o_24196 = heff_field(v_e0_241, 0);
    V v_x_24197 = heff_field(v_e0_241, 1);
    V v_c_24198 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24199 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24196));
    V v_t_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24197));
    V v_t_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24198));
    V v_t_24202 = (g_std_2edoc_2e_3c_3e(v_t_24200, v_t_24201));
    return (g_std_2edoc_2e_3c_3e(v_t_24199, v_t_24202));
  }
  case TAG_BAnn: {
    V v_o_24203 = heff_field(v_e0_241, 0);
    V v_x_24204 = heff_field(v_e0_241, 1);
    V v_cc_24205 = heff_field(v_e0_241, 2);
    V v_ty_24206 = heff_field(v_e0_241, 3);
    V v_c_24207 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24208 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24203));
    V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24204));
    V v_a_24210 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24205));
    V v_b_24211 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24206}));
    V v_t_24212 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24211));
    V v_b_24213 = (g_std_2edoc_2e_3c_3e(v_a_24210, v_t_24212));
    V v_t_24214 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24213));
    V v_t_24215 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24214));
    V v_t_24216 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24207));
    V v_t_24217 = (g_std_2edoc_2e_3c_3e(v_t_24215, v_t_24216));
    return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24217));
  }
  case TAG_Lam: {
    V v_bs_24218 = heff_field(v_e0_241, 0);
    V v_binders_24219 = heff_field(v_e0_241, 1);
    V v_arrow_24220 = heff_field(v_e0_241, 2);
    V v_body_24221 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24222 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24218));
    V v_t_24223 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24224 = (g_list_2emap(v_t_24223, v_binders_24219));
    V v_a_24225 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19); V a_1 = v_t_24224; V r_ = (g_std_2edoc_2econcatWith_24s650596433x61515523(a_0, a_1)); heff_drop(v_t_24224); r_; });
    V v_b_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24220));
    V v_t_24227 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24226));
    V v_t_24228 = (g_std_2edoc_2e_3c_3e(v_a_24225, v_t_24227));
    V v_t_24229 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24221));
    V v_t_24233;
    switch (heff_tag_of(v_t_24229)) {
    case TAG_True: {
      V v_t_24230 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24221}));
      v_t_24233 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24230));
      break;
    }
    case TAG_False: {
      V v_t_24231 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24221}));
      V v_d_24232 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24231));
      v_t_24233 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24232})));
      break;
    }
    default: heff_nomatch(v_t_24229);
    }
    V v_t_24234 = (g_std_2edoc_2e_3c_3e(v_t_24228, v_t_24233));
    return (g_std_2edoc_2e_3c_3e(v_t_24222, v_t_24234));
  }
  case TAG_Case: {
    V v_kw_24235 = heff_field(v_e0_241, 0);
    V v_scrut_24236 = heff_field(v_e0_241, 1);
    V v_of2_24237 = heff_field(v_e0_241, 2);
    V v_alts_24238 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24239 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24235));
    V v_a_24240 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24236}));
    V v_b_24241 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24237));
    V v_t_24242 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24241));
    V v_b_24243 = (g_std_2edoc_2e_3c_3e(v_a_24240, v_t_24242));
    V v_t_24244 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24243));
    V v_t_24245 = (g_std_2edoc_2e_3c_3e(v_a_24239, v_t_24244));
    V v_t_24246 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24238; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(a_0, a_1, a_2)); heff_drop(v_alts_24238); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24245, v_t_24246));
  }
  case TAG_EAlt: {
    V v_p_24247 = heff_field(v_e0_241, 0);
    V v_arrow_24248 = heff_field(v_e0_241, 1);
    V v_body_24249 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24250 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24247; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24247); r_; });
    V v_b_24251 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24248));
    V v_t_24252 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24251));
    V v_t_24253 = (g_std_2edoc_2e_3c_3e(v_a_24250, v_t_24252));
    V v_t_24254 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24249}));
    return (g_std_2edoc_2e_3c_3e(v_t_24253, v_t_24254));
  }
  case TAG_If: {
    V v_kw_24255 = heff_field(v_e0_241, 0);
    V v_c_24256 = heff_field(v_e0_241, 1);
    V v_th_24257 = heff_field(v_e0_241, 2);
    V v_a_24258 = heff_field(v_e0_241, 3);
    V v_el_24259 = heff_field(v_e0_241, 4);
    V v_b_24260 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24261 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24255, v_c_24256, v_th_24257, v_a_24258}));
    V v_t_24262 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24259, v_b_24260}));
    V v_t_24263 = (g_std_2edoc_2e_3c_3e(v_t_24261, v_t_24262));
    return (g_std_2edoc_2egroup(v_t_24263));
  }
  case TAG_Do: {
    V v_kw_24264 = heff_field(v_e0_241, 0);
    V v_stmts_24265 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24264));
    V v_t_24267 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24265; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(a_0, a_1, a_2)); heff_drop(v_stmts_24265); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24266, v_t_24267));
  }
  case TAG_ESBind: {
    V v_x_24268 = heff_field(v_e0_241, 0);
    V v_arrow_24269 = heff_field(v_e0_241, 1);
    V v_e_24270 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24271 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24268));
    V v_b_24272 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24269));
    V v_t_24273 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_b_24272));
    V v_t_24274 = (g_std_2edoc_2e_3c_3e(v_a_24271, v_t_24273));
    V v_t_24275 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24270}));
    return (g_std_2edoc_2e_3c_3e(v_t_24274, v_t_24275));
  }
  case TAG_ELet: {
    V v_kw_24276 = heff_field(v_e0_241, 0);
    V v_p_24277 = heff_field(v_e0_241, 1);
    V v_ann_24278 = heff_field(v_e0_241, 2);
    V v_eq_24279 = heff_field(v_e0_241, 3);
    V v_e_24280 = heff_field(v_e0_241, 4);
    V v_body_24281 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24281)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24276, v_p_24277, v_ann_24278, v_eq_24279, v_e_24280});
    }
    case TAG_Just: {
      V v_it1_24282 = heff_field(v_body_24281, 0);
      V v_ru_24body_24281_24Just = heff_take_reuse_n(v_body_24281, 1ULL, 1);
      switch (heff_tag_of(v_it1_24282)) {
      case TAG_MkPair: {
        V v_i_24283 = heff_field(v_it1_24282, 0);
        V v_b_24284 = heff_field(v_it1_24282, 1);
        heff_take_n(v_it1_24282, 3ULL, 2);
        V v_t_24285 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24276, v_p_24277, v_ann_24278, v_eq_24279, v_e_24280, v_i_24283, v_b_24284}));
        V v_d_24286 = (g_std_2edoc_2egroup(v_t_24285));
        return heff_tag_at_n(v_ru_24body_24281_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24286})});
      }
      default: return heff_nomatch(v_it1_24282);
      }
    }
    default: return heff_nomatch(v_body_24281);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_env_24291 = args[0];
  V v_e_24292 = args[1];
  V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24292));
  switch (heff_tag_of(v_t_24293)) {
  case TAG_True: {
    V v_t_24294 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24291, v_e_24292}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26)}), v_t_24294));
  }
  case TAG_False: {
    V v_t_24295 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24291, v_e_24292}));
    V v_t_24296 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24295));
    return (g_std_2edoc_2egroup(v_t_24296));
  }
  default: return heff_nomatch(v_t_24293);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_env_24297 = args[0];
  V v_kw_24298 = args[1];
  V v_p_24299 = args[2];
  V v_ann_24300 = args[3];
  V v_eq_24301 = args[4];
  V v_e_24302 = args[5];
  V v_a_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24297), v_kw_24298));
  V v_b_24304 = ({ V a_0 = heff_dup(v_env_24297); V a_1 = v_p_24299; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24299); r_; });
  V v_t_24305 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24304));
  V v_t_24306 = (g_std_2edoc_2e_3c_3e(v_a_24303, v_t_24305));
  V v_a_24314;
  switch (heff_tag_of(v_ann_24300)) {
  case TAG_Nothing: {
    v_a_24314 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24307 = heff_field(v_ann_24300, 0);
    V v_ru_24ann_24300_24Just = heff_take_reuse_n(v_ann_24300, 1ULL, 1);
    switch (heff_tag_of(v_it1_24307)) {
    case TAG_MkPair: {
      V v_cc_24308 = heff_field(v_it1_24307, 0);
      V v_ty_24309 = heff_field(v_it1_24307, 1);
      heff_take_n(v_it1_24307, 3ULL, 2);
      V v_a_24310 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24297), v_cc_24308));
      V v_b_24311 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24297), v_ty_24309}));
      V v_t_24312 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24300_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_b_24311));
      V v_t_24313 = (g_std_2edoc_2e_3c_3e(v_a_24310, v_t_24312));
      v_a_24314 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_t_24313));
      break;
    }
    default: heff_nomatch(v_it1_24307);
    }
    break;
  }
  default: heff_nomatch(v_ann_24300);
  }
  V v_b_24315 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24297), v_eq_24301));
  V v_t_24316 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_b_24315));
  V v_t_24317 = (g_std_2edoc_2e_3c_3e(v_a_24314, v_t_24316));
  V v_t_24318 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24297, v_e_24302}));
  V v_t_24319 = (g_std_2edoc_2e_3c_3e(v_t_24317, v_t_24318));
  return (g_std_2edoc_2e_3c_3e(v_t_24306, v_t_24319));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_env_24320 = args[0];
  V v_kw_24321 = args[1];
  V v_p_24322 = args[2];
  V v_ann_24323 = args[3];
  V v_eq_24324 = args[4];
  V v_e_24325 = args[5];
  V v_i_24326 = args[6];
  V v_b_24327 = args[7];
  V v_d_24328 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24320), v_kw_24321, v_p_24322, v_ann_24323, v_eq_24324, v_e_24325}));
  V v_a_24329 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24320), v_i_24326));
  V v_b_24419;
  switch (heff_tag_of(v_b_24327)) {
  case TAG_Atom: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_EParen: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Named: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Tup: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Braces: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_InstB: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_EFSet: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Sum: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_ECon: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_EField: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_App: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Op: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Ops: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Ann: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_BVar: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_BImp: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_BAnn: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Lam: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Case: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_EAlt: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_If: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_Do: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_ESBind: {
    v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24410 = heff_dup(heff_field(v_b_24327, 0));
    V v_p2_24411 = heff_dup(heff_field(v_b_24327, 1));
    V v_ann2_24412 = heff_dup(heff_field(v_b_24327, 2));
    V v_eq2_24413 = heff_dup(heff_field(v_b_24327, 3));
    V v_e2_24414 = heff_dup(heff_field(v_b_24327, 4));
    V v_it6_24415 = heff_dup(heff_field(v_b_24327, 5));
    switch (heff_tag_of(v_it6_24415)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24410);
      heff_drop(v_p2_24411);
      heff_drop(v_ann2_24412);
      heff_drop(v_eq2_24413);
      heff_drop(v_e2_24414);
      v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24320, v_b_24327}));
      break;
    }
    case TAG_Just: {
      V v_it61_24416 = heff_field(v_it6_24415, 0);
      heff_take_n(v_it6_24415, 1ULL, 1);
      heff_drop_tag(v_b_24327, 6);
      switch (heff_tag_of(v_it61_24416)) {
      case TAG_MkPair: {
        V v_i2_24417 = heff_field(v_it61_24416, 0);
        V v_b2_24418 = heff_field(v_it61_24416, 1);
        heff_take_n(v_it61_24416, 3ULL, 2);
        v_b_24419 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24320, v_kw2_24410, v_p2_24411, v_ann2_24412, v_eq2_24413, v_e2_24414, v_i2_24417, v_b2_24418}));
        break;
      }
      default: heff_nomatch(v_it61_24416);
      }
      break;
    }
    default: heff_nomatch(v_it6_24415);
    }
    break;
  }
  default: heff_nomatch(v_b_24327);
  }
  V v_t_24420 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24419));
  V v_t_24421 = (g_std_2edoc_2e_3c_3e(v_a_24329, v_t_24420));
  V v_t_24422 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24421));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24328}), v_t_24422));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_env_24423 = args[0];
  V v_kw_24424 = args[1];
  V v_c_24425 = args[2];
  V v_th_24426 = args[3];
  V v_a_24427 = args[4];
  V v_a_24428 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24423), v_kw_24424));
  V v_b_24429 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24423), v_c_24425}));
  V v_t_24430 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24429));
  V v_t_24431 = (g_std_2edoc_2e_3c_3e(v_a_24428, v_t_24430));
  V v_a_24432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24423), v_th_24426));
  V v_d_24433 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24423, v_a_24427}));
  V v_b_24434 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24433});
  V v_t_24435 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24434));
  V v_t_24436 = (g_std_2edoc_2e_3c_3e(v_a_24432, v_t_24435));
  V v_d_24437 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24436));
  V v_t_24438 = (g_std_2edoc_2e_3c_3e(v_t_24431, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24437})));
  return (g_std_2edoc_2egroup(v_t_24438));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24439 = args[0];
  V v_el_24440 = args[1];
  V v_b_24441 = args[2];
  switch (heff_tag_of(v_b_24441)) {
  case TAG_Atom: {
    V v_a_24443 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24444 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24445 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24444});
    V v_t_24446 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_b_24445));
    V v_t_24447 = (g_std_2edoc_2e_3c_3e(v_a_24443, v_t_24446));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24447));
  }
  case TAG_EParen: {
    V v_a_24451 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24452 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24452});
    V v_t_24454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24453));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(v_a_24451, v_t_24454));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24455));
  }
  case TAG_Named: {
    V v_a_24461 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24462 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24463 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24462});
    V v_t_24464 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_b_24463));
    V v_t_24465 = (g_std_2edoc_2e_3c_3e(v_a_24461, v_t_24464));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24465));
  }
  case TAG_Tup: {
    V v_a_24470 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24471 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24472 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24471});
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24472));
    V v_t_24474 = (g_std_2edoc_2e_3c_3e(v_a_24470, v_t_24473));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24474));
  }
  case TAG_Braces: {
    V v_a_24479 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24480 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24481 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24480});
    V v_t_24482 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24481));
    V v_t_24483 = (g_std_2edoc_2e_3c_3e(v_a_24479, v_t_24482));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24483));
  }
  case TAG_InstB: {
    V v_a_24489 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24490 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24491 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24490});
    V v_t_24492 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24491));
    V v_t_24493 = (g_std_2edoc_2e_3c_3e(v_a_24489, v_t_24492));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24493));
  }
  case TAG_EFSet: {
    V v_a_24497 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24498 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24499 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24498});
    V v_t_24500 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24499));
    V v_t_24501 = (g_std_2edoc_2e_3c_3e(v_a_24497, v_t_24500));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24501));
  }
  case TAG_EFDefault: {
    V v_a_24505 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24506 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24507 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24506});
    V v_t_24508 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24507));
    V v_t_24509 = (g_std_2edoc_2e_3c_3e(v_a_24505, v_t_24508));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24509));
  }
  case TAG_Sum: {
    V v_a_24515 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24516 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24517 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24516});
    V v_t_24518 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_b_24517));
    V v_t_24519 = (g_std_2edoc_2e_3c_3e(v_a_24515, v_t_24518));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24519));
  }
  case TAG_ECon: {
    V v_a_24522 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24523 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24524 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24523});
    V v_t_24525 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24524));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(v_a_24522, v_t_24525));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24526));
  }
  case TAG_EField: {
    V v_a_24529 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24530 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24531 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24530});
    V v_t_24532 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_b_24531));
    V v_t_24533 = (g_std_2edoc_2e_3c_3e(v_a_24529, v_t_24532));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24533));
  }
  case TAG_App: {
    V v_a_24536 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24537 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24538 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24537});
    V v_t_24539 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_b_24538));
    V v_t_24540 = (g_std_2edoc_2e_3c_3e(v_a_24536, v_t_24539));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24540));
  }
  case TAG_Op: {
    V v_a_24544 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24545 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24546 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24545});
    V v_t_24547 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_b_24546));
    V v_t_24548 = (g_std_2edoc_2e_3c_3e(v_a_24544, v_t_24547));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24548));
  }
  case TAG_Ops: {
    V v_a_24551 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24552 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24553 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24552});
    V v_t_24554 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), v_b_24553));
    V v_t_24555 = (g_std_2edoc_2e_3c_3e(v_a_24551, v_t_24554));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24555));
  }
  case TAG_OpRhs: {
    V v_a_24558 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24559 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24560 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24559});
    V v_t_24561 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24560));
    V v_t_24562 = (g_std_2edoc_2e_3c_3e(v_a_24558, v_t_24561));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24562));
  }
  case TAG_Ann: {
    V v_a_24566 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24567 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24568 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24567});
    V v_t_24569 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24568));
    V v_t_24570 = (g_std_2edoc_2e_3c_3e(v_a_24566, v_t_24569));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24570));
  }
  case TAG_BVar: {
    V v_a_24572 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24573 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24574 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24573});
    V v_t_24575 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_b_24574));
    V v_t_24576 = (g_std_2edoc_2e_3c_3e(v_a_24572, v_t_24575));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24576));
  }
  case TAG_BImp: {
    V v_a_24580 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24581 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24582 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24581});
    V v_t_24583 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24582));
    V v_t_24584 = (g_std_2edoc_2e_3c_3e(v_a_24580, v_t_24583));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24584));
  }
  case TAG_BAnn: {
    V v_a_24590 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24591 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24592 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24591});
    V v_t_24593 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_b_24592));
    V v_t_24594 = (g_std_2edoc_2e_3c_3e(v_a_24590, v_t_24593));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24594));
  }
  case TAG_Lam: {
    V v_a_24599 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24600 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24601 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24600});
    V v_t_24602 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24601));
    V v_t_24603 = (g_std_2edoc_2e_3c_3e(v_a_24599, v_t_24602));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24603));
  }
  case TAG_Case: {
    V v_a_24608 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24609 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24610 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24609});
    V v_t_24611 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_b_24610));
    V v_t_24612 = (g_std_2edoc_2e_3c_3e(v_a_24608, v_t_24611));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24612));
  }
  case TAG_EAlt: {
    V v_a_24616 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24617 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24618 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24617});
    V v_t_24619 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_b_24618));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(v_a_24616, v_t_24619));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24620));
  }
  case TAG_If: {
    V v_kw_24621 = heff_field(v_b_24441, 0);
    V v_c_24622 = heff_field(v_b_24441, 1);
    V v_th_24623 = heff_field(v_b_24441, 2);
    V v_a_24624 = heff_field(v_b_24441, 3);
    V v_el2_24625 = heff_field(v_b_24441, 4);
    V v_b2_24626 = heff_field(v_b_24441, 5);
    heff_take_n(v_b_24441, 63ULL, 6);
    V v_a_24627 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_b_24628 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24439), v_kw_24621, v_c_24622, v_th_24623, v_a_24624}));
    V v_t_24629 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_b_24628));
    V v_t_24630 = (g_std_2edoc_2e_3c_3e(v_a_24627, v_t_24629));
    V v_t_24631 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24439, v_el2_24625, v_b2_24626}));
    V v_t_24632 = (g_std_2edoc_2e_3c_3e(v_t_24630, v_t_24631));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24632));
  }
  case TAG_Do: {
    V v_a_24635 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24636 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24637 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24636});
    V v_t_24638 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_b_24637));
    V v_t_24639 = (g_std_2edoc_2e_3c_3e(v_a_24635, v_t_24638));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24639));
  }
  case TAG_ESBind: {
    V v_a_24643 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24644 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24645 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24644});
    V v_t_24646 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24645));
    V v_t_24647 = (g_std_2edoc_2e_3c_3e(v_a_24643, v_t_24646));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24647));
  }
  case TAG_ELet: {
    V v_a_24654 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24439), v_el_24440));
    V v_d_24655 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24439, v_b_24441}));
    V v_b_24656 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24655});
    V v_t_24657 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_b_24656));
    V v_t_24658 = (g_std_2edoc_2e_3c_3e(v_a_24654, v_t_24657));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24658));
  }
  default: return heff_nomatch(v_b_24441);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_a_24673 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24674 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24673}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24674));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_a_24682 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24683 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24682}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24683));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_a_24692 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24693 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24692}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24693));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_a_24705 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24706 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24705}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24706));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24717 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24718 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24717}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24718));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24726 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24727 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24726}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24727));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24737 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24738 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24737}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24738));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24746 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24747 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24746}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24747));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24757 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24758 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24757}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24758));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24766 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24767 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24766}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24767));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24778 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24779 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24778}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24779));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24787 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24788 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24787}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24788));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24797 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24798 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24797}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24798));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_24806 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24807 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24806}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24807));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_24816 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24817 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24816}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24817));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_24825 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24826 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24825}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24826));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_24837 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24838 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24837}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24838));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_24846 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24847 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24846}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24847));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_24855 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24856 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24855}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24856));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_24864 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24865 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24864}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24865));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_24873 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24874 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24873}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24874));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_24882 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24883 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24882}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24883));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_24891 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24892 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24891}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24892));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_24900 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24901 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24900}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24901));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_24910 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24911 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24910}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24911));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_24919 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24920 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24919}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24920));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_24928 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24929 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24928}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24929));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_24937 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24938 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24937}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24938));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_24946 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24947 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24946}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24947));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_24955 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24956 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24955}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24956));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_24965 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24966 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24965}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24966));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_24974 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24975 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24974}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24975));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_24982 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24983 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24982}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24983));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_24991 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24992 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_24991}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24992));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241001 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241002 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241001}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241002));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241010 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241011 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241010}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241011));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241022 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241023 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241022}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241023));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241031 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241032 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241031}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241032));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241042 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241043 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241042}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241043));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241051 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241052 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241051}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241052));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241062 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241063 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241062}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241063));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241071 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241072 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241071}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241072));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241081 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241082 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241081}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241082));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241090 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241091 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241090}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241091));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241103 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241104 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241103}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241104));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241112 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241113 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241112}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241113));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241121 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241122 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241121}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241122));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241130 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241131 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241130}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241131));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241140 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241141 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241140}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241141));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241149 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241150 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241149}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241150));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241162 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241163 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241162}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241163));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241171 = args[0];
  V v_env_24659 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241172 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_a_241171}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241172));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24659 = args[0];
  V v_h_24660 = args[1];
  V v_args_24661 = args[2];
  V v_x1_24662 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24661)));
  V v_t_24666;
  switch (heff_tag_of(v_x1_24662)) {
  case TAG_Nil: {
    v_t_24666 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24663 = heff_field(v_x1_24662, 0);
    V v_rev_24664 = heff_field(v_x1_24662, 1);
    V v_ru_24x1_24662_24Cons = heff_take_reuse_n(v_x1_24662, 3ULL, 2);
    V v_t_24665 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24664));
    v_t_24666 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_24662_24Cons, TAG_MkPair, 2, (V[]){v_t_24665, v_x_24663})});
    break;
  }
  default: heff_nomatch(v_x1_24662);
  }
  switch (heff_tag_of(v_t_24666)) {
  case TAG_Nothing: {
    heff_drop(v_args_24661);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24659;
    args[1] = v_h_24660;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_24667 = heff_field(v_t_24666, 0);
    V v_ru_24t_24666_24Just = heff_take_reuse_n(v_t_24666, 1ULL, 1);
    switch (heff_tag_of(v_pr_24667)) {
    case TAG_MkPair: {
      V v_init2_24668 = heff_field(v_pr_24667, 0);
      V v_lastA_24669 = heff_field(v_pr_24667, 1);
      V v_ru_24pr_24667_24MkPair = heff_take_reuse_n(v_pr_24667, 3ULL, 2);
      switch (heff_tag_of(v_lastA_24669)) {
      case TAG_Atom: {
        V v_t_24671 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24671)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24672 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24675 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24676 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24675; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24675); r_; });
          V v_t_24677 = (g_std_2edoc_2e_3c_3e(v_t_24672, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24676})));
          V v_a_24678 = (g_std_2edoc_2egroup(v_t_24677));
          V v_b_24679 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24680 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_b_24679));
          return (g_std_2edoc_2e_3c_3e(v_a_24678, v_t_24680));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 1);
          V v_t_24681 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24684 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24685 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24684; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24684); r_; });
          V v_t_24686 = (g_std_2edoc_2e_3c_3e(v_t_24681, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24685})));
          return (g_std_2edoc_2egroup(v_t_24686));
        }
        default: return heff_nomatch(v_t_24671);
        }
      }
      case TAG_EParen: {
        V v_o_24687 = heff_field(v_lastA_24669, 0);
        V v_e_24688 = heff_field(v_lastA_24669, 1);
        V v_c_24689 = heff_field(v_lastA_24669, 2);
        heff_take_n(v_lastA_24669, 7ULL, 3);
        V v_t_24690 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24688));
        switch (heff_tag_of(v_t_24690)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24691 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24694 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24695 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24694; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24694); r_; });
          V v_t_24696 = (g_std_2edoc_2e_3c_3e(v_t_24691, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24695})));
          V v_a_24697 = (g_std_2edoc_2egroup(v_t_24696));
          V v_b_24698 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24659), v_o_24687));
          V v_t_24699 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24698));
          V v_t_24700 = (g_std_2edoc_2e_3c_3e(v_a_24697, v_t_24699));
          V v_t_24701 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_e_24688}));
          V v_t_24702 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24659, v_c_24689));
          V v_t_24703 = (g_std_2edoc_2e_3c_3e(v_t_24701, v_t_24702));
          return (g_std_2edoc_2e_3c_3e(v_t_24700, v_t_24703));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop(v_o_24687);
          heff_drop(v_e_24688);
          heff_drop(v_c_24689);
          V v_t_24704 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24707 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24708 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24707; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24707); r_; });
          V v_t_24709 = (g_std_2edoc_2e_3c_3e(v_t_24704, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24708})));
          return (g_std_2edoc_2egroup(v_t_24709));
        }
        default: return heff_nomatch(v_t_24690);
        }
      }
      case TAG_Named: {
        V v_t_24715 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24715)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24716 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24719 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24720 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24719; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24719); r_; });
          V v_t_24721 = (g_std_2edoc_2e_3c_3e(v_t_24716, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24720})));
          V v_a_24722 = (g_std_2edoc_2egroup(v_t_24721));
          V v_b_24723 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24724 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24723));
          return (g_std_2edoc_2e_3c_3e(v_a_24722, v_t_24724));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 5);
          V v_t_24725 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24728 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24729 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24728; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24728); r_; });
          V v_t_24730 = (g_std_2edoc_2e_3c_3e(v_t_24725, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24729})));
          return (g_std_2edoc_2egroup(v_t_24730));
        }
        default: return heff_nomatch(v_t_24715);
        }
      }
      case TAG_Tup: {
        V v_t_24735 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24735)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24736 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24739 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24740 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24739; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24739); r_; });
          V v_t_24741 = (g_std_2edoc_2e_3c_3e(v_t_24736, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24740})));
          V v_a_24742 = (g_std_2edoc_2egroup(v_t_24741));
          V v_b_24743 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24744 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), v_b_24743));
          return (g_std_2edoc_2e_3c_3e(v_a_24742, v_t_24744));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 4);
          V v_t_24745 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24748 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24749 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24748; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24748); r_; });
          V v_t_24750 = (g_std_2edoc_2e_3c_3e(v_t_24745, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24749})));
          return (g_std_2edoc_2egroup(v_t_24750));
        }
        default: return heff_nomatch(v_t_24735);
        }
      }
      case TAG_Braces: {
        V v_t_24755 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24755)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24756 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24759 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24760 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24759; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24759); r_; });
          V v_t_24761 = (g_std_2edoc_2e_3c_3e(v_t_24756, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24760})));
          V v_a_24762 = (g_std_2edoc_2egroup(v_t_24761));
          V v_b_24763 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24764 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), v_b_24763));
          return (g_std_2edoc_2e_3c_3e(v_a_24762, v_t_24764));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 4);
          V v_t_24765 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24768 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24769 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24768; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24768); r_; });
          V v_t_24770 = (g_std_2edoc_2e_3c_3e(v_t_24765, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24769})));
          return (g_std_2edoc_2egroup(v_t_24770));
        }
        default: return heff_nomatch(v_t_24755);
        }
      }
      case TAG_InstB: {
        V v_t_24776 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24776)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24777 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24780 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24781 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24780; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24780); r_; });
          V v_t_24782 = (g_std_2edoc_2e_3c_3e(v_t_24777, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24781})));
          V v_a_24783 = (g_std_2edoc_2egroup(v_t_24782));
          V v_b_24784 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24785 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), v_b_24784));
          return (g_std_2edoc_2e_3c_3e(v_a_24783, v_t_24785));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 5);
          V v_t_24786 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24789 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24790 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24789; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24789); r_; });
          V v_t_24791 = (g_std_2edoc_2e_3c_3e(v_t_24786, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24790})));
          return (g_std_2edoc_2egroup(v_t_24791));
        }
        default: return heff_nomatch(v_t_24776);
        }
      }
      case TAG_EFSet: {
        V v_t_24795 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24795)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24796 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24799 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24800 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24799; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24799); r_; });
          V v_t_24801 = (g_std_2edoc_2e_3c_3e(v_t_24796, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24800})));
          V v_a_24802 = (g_std_2edoc_2egroup(v_t_24801));
          V v_b_24803 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24804 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), v_b_24803));
          return (g_std_2edoc_2e_3c_3e(v_a_24802, v_t_24804));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_24805 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24808 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24809 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24808; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24808); r_; });
          V v_t_24810 = (g_std_2edoc_2e_3c_3e(v_t_24805, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24809})));
          return (g_std_2edoc_2egroup(v_t_24810));
        }
        default: return heff_nomatch(v_t_24795);
        }
      }
      case TAG_EFDefault: {
        V v_t_24814 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24814)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24815 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24818 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24819 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24818; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24818); r_; });
          V v_t_24820 = (g_std_2edoc_2e_3c_3e(v_t_24815, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24819})));
          V v_a_24821 = (g_std_2edoc_2egroup(v_t_24820));
          V v_b_24822 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24823 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_b_24822));
          return (g_std_2edoc_2e_3c_3e(v_a_24821, v_t_24823));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_24824 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24827 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24828 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24827; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24827); r_; });
          V v_t_24829 = (g_std_2edoc_2e_3c_3e(v_t_24824, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24828})));
          return (g_std_2edoc_2egroup(v_t_24829));
        }
        default: return heff_nomatch(v_t_24814);
        }
      }
      case TAG_Sum: {
        V v_t_24835 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24835)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24836 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24839 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24840 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24839; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24839); r_; });
          V v_t_24841 = (g_std_2edoc_2e_3c_3e(v_t_24836, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24840})));
          V v_a_24842 = (g_std_2edoc_2egroup(v_t_24841));
          V v_b_24843 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24844 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), v_b_24843));
          return (g_std_2edoc_2e_3c_3e(v_a_24842, v_t_24844));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 5);
          V v_t_24845 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24848 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24849 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24848; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24848); r_; });
          V v_t_24850 = (g_std_2edoc_2e_3c_3e(v_t_24845, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24849})));
          return (g_std_2edoc_2egroup(v_t_24850));
        }
        default: return heff_nomatch(v_t_24835);
        }
      }
      case TAG_ECon: {
        V v_t_24853 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24853)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24854 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24857 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24858 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24857; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24857); r_; });
          V v_t_24859 = (g_std_2edoc_2e_3c_3e(v_t_24854, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24858})));
          V v_a_24860 = (g_std_2edoc_2egroup(v_t_24859));
          V v_b_24861 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24862 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), v_b_24861));
          return (g_std_2edoc_2e_3c_3e(v_a_24860, v_t_24862));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_24863 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24866 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24867 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24866; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24866); r_; });
          V v_t_24868 = (g_std_2edoc_2e_3c_3e(v_t_24863, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24867})));
          return (g_std_2edoc_2egroup(v_t_24868));
        }
        default: return heff_nomatch(v_t_24853);
        }
      }
      case TAG_EField: {
        V v_t_24871 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24871)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24872 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24875 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24876 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24875; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24875); r_; });
          V v_t_24877 = (g_std_2edoc_2e_3c_3e(v_t_24872, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24876})));
          V v_a_24878 = (g_std_2edoc_2egroup(v_t_24877));
          V v_b_24879 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24880 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), v_b_24879));
          return (g_std_2edoc_2e_3c_3e(v_a_24878, v_t_24880));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_24881 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24884 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24885 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24884; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24884); r_; });
          V v_t_24886 = (g_std_2edoc_2e_3c_3e(v_t_24881, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24885})));
          return (g_std_2edoc_2egroup(v_t_24886));
        }
        default: return heff_nomatch(v_t_24871);
        }
      }
      case TAG_App: {
        V v_t_24889 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24889)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24890 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24893 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24894 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24893; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24893); r_; });
          V v_t_24895 = (g_std_2edoc_2e_3c_3e(v_t_24890, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24894})));
          V v_a_24896 = (g_std_2edoc_2egroup(v_t_24895));
          V v_b_24897 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24898 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24897));
          return (g_std_2edoc_2e_3c_3e(v_a_24896, v_t_24898));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_24899 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24902 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24903 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24902; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24902); r_; });
          V v_t_24904 = (g_std_2edoc_2e_3c_3e(v_t_24899, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24903})));
          return (g_std_2edoc_2egroup(v_t_24904));
        }
        default: return heff_nomatch(v_t_24889);
        }
      }
      case TAG_Op: {
        V v_t_24908 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24908)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24909 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24912 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24913 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24912; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24912); r_; });
          V v_t_24914 = (g_std_2edoc_2e_3c_3e(v_t_24909, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24913})));
          V v_a_24915 = (g_std_2edoc_2egroup(v_t_24914));
          V v_b_24916 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24917 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24916));
          return (g_std_2edoc_2e_3c_3e(v_a_24915, v_t_24917));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_24918 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24921 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24922 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24921; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24921); r_; });
          V v_t_24923 = (g_std_2edoc_2e_3c_3e(v_t_24918, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24922})));
          return (g_std_2edoc_2egroup(v_t_24923));
        }
        default: return heff_nomatch(v_t_24908);
        }
      }
      case TAG_Ops: {
        V v_t_24926 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24926)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24927 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24930 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24931 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24930; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24930); r_; });
          V v_t_24932 = (g_std_2edoc_2e_3c_3e(v_t_24927, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24931})));
          V v_a_24933 = (g_std_2edoc_2egroup(v_t_24932));
          V v_b_24934 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24935 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24934));
          return (g_std_2edoc_2e_3c_3e(v_a_24933, v_t_24935));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_24936 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24939 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24940 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24939; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24939); r_; });
          V v_t_24941 = (g_std_2edoc_2e_3c_3e(v_t_24936, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24940})));
          return (g_std_2edoc_2egroup(v_t_24941));
        }
        default: return heff_nomatch(v_t_24926);
        }
      }
      case TAG_OpRhs: {
        V v_t_24944 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24944)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24945 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24948 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24949 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24948; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24948); r_; });
          V v_t_24950 = (g_std_2edoc_2e_3c_3e(v_t_24945, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24949})));
          V v_a_24951 = (g_std_2edoc_2egroup(v_t_24950));
          V v_b_24952 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24953 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24952));
          return (g_std_2edoc_2e_3c_3e(v_a_24951, v_t_24953));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_24954 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24957 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24958 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24957; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24957); r_; });
          V v_t_24959 = (g_std_2edoc_2e_3c_3e(v_t_24954, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24958})));
          return (g_std_2edoc_2egroup(v_t_24959));
        }
        default: return heff_nomatch(v_t_24944);
        }
      }
      case TAG_Ann: {
        V v_t_24963 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24963)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24964 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24967 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24968 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24967; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24967); r_; });
          V v_t_24969 = (g_std_2edoc_2e_3c_3e(v_t_24964, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24968})));
          V v_a_24970 = (g_std_2edoc_2egroup(v_t_24969));
          V v_b_24971 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24972 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_24971));
          return (g_std_2edoc_2e_3c_3e(v_a_24970, v_t_24972));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_24973 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24976 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24977 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24976; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24976); r_; });
          V v_t_24978 = (g_std_2edoc_2e_3c_3e(v_t_24973, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24977})));
          return (g_std_2edoc_2egroup(v_t_24978));
        }
        default: return heff_nomatch(v_t_24963);
        }
      }
      case TAG_BVar: {
        V v_t_24980 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24980)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_24981 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24984 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_24985 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24984; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24984); r_; });
          V v_t_24986 = (g_std_2edoc_2e_3c_3e(v_t_24981, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24985})));
          V v_a_24987 = (g_std_2edoc_2egroup(v_t_24986));
          V v_b_24988 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_24989 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_24988));
          return (g_std_2edoc_2e_3c_3e(v_a_24987, v_t_24989));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 1);
          V v_t_24990 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_24993 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_24994 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24993; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24993); r_; });
          V v_t_24995 = (g_std_2edoc_2e_3c_3e(v_t_24990, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24994})));
          return (g_std_2edoc_2egroup(v_t_24995));
        }
        default: return heff_nomatch(v_t_24980);
        }
      }
      case TAG_BImp: {
        V v_t_24999 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_24999)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241000 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241003 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241004 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241003; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241003); r_; });
          V v_t_241005 = (g_std_2edoc_2e_3c_3e(v_t_241000, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241004})));
          V v_a_241006 = (g_std_2edoc_2egroup(v_t_241005));
          V v_b_241007 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241008 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_241007));
          return (g_std_2edoc_2e_3c_3e(v_a_241006, v_t_241008));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_241009 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241012 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241013 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241012; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241012); r_; });
          V v_t_241014 = (g_std_2edoc_2e_3c_3e(v_t_241009, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241013})));
          return (g_std_2edoc_2egroup(v_t_241014));
        }
        default: return heff_nomatch(v_t_24999);
        }
      }
      case TAG_BAnn: {
        V v_t_241020 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241020)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241021 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241024 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241025 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241024; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241024); r_; });
          V v_t_241026 = (g_std_2edoc_2e_3c_3e(v_t_241021, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241025})));
          V v_a_241027 = (g_std_2edoc_2egroup(v_t_241026));
          V v_b_241028 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241029 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241028));
          return (g_std_2edoc_2e_3c_3e(v_a_241027, v_t_241029));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 5);
          V v_t_241030 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241033 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241034 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241033; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241033); r_; });
          V v_t_241035 = (g_std_2edoc_2e_3c_3e(v_t_241030, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241034})));
          return (g_std_2edoc_2egroup(v_t_241035));
        }
        default: return heff_nomatch(v_t_241020);
        }
      }
      case TAG_Lam: {
        V v_t_241040 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241040)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241041 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241044 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241045 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241044; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241044); r_; });
          V v_t_241046 = (g_std_2edoc_2e_3c_3e(v_t_241041, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241045})));
          V v_a_241047 = (g_std_2edoc_2egroup(v_t_241046));
          V v_b_241048 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241049 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241048));
          return (g_std_2edoc_2e_3c_3e(v_a_241047, v_t_241049));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 4);
          V v_t_241050 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241053 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241054 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241053; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241053); r_; });
          V v_t_241055 = (g_std_2edoc_2e_3c_3e(v_t_241050, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241054})));
          return (g_std_2edoc_2egroup(v_t_241055));
        }
        default: return heff_nomatch(v_t_241040);
        }
      }
      case TAG_Case: {
        V v_t_241060 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241060)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241061 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241064 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241065 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241064; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241064); r_; });
          V v_t_241066 = (g_std_2edoc_2e_3c_3e(v_t_241061, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241065})));
          V v_a_241067 = (g_std_2edoc_2egroup(v_t_241066));
          V v_b_241068 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241069 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_241068));
          return (g_std_2edoc_2e_3c_3e(v_a_241067, v_t_241069));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 4);
          V v_t_241070 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241073 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241074 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241073; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241073); r_; });
          V v_t_241075 = (g_std_2edoc_2e_3c_3e(v_t_241070, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241074})));
          return (g_std_2edoc_2egroup(v_t_241075));
        }
        default: return heff_nomatch(v_t_241060);
        }
      }
      case TAG_EAlt: {
        V v_t_241079 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241079)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241080 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241083 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241084 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241083; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241083); r_; });
          V v_t_241085 = (g_std_2edoc_2e_3c_3e(v_t_241080, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241084})));
          V v_a_241086 = (g_std_2edoc_2egroup(v_t_241085));
          V v_b_241087 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241088 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_241087));
          return (g_std_2edoc_2e_3c_3e(v_a_241086, v_t_241088));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_241089 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241092 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241093 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241092; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241092); r_; });
          V v_t_241094 = (g_std_2edoc_2e_3c_3e(v_t_241089, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241093})));
          return (g_std_2edoc_2egroup(v_t_241094));
        }
        default: return heff_nomatch(v_t_241079);
        }
      }
      case TAG_If: {
        V v_t_241101 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241101)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241102 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241105 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241106 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241105; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241105); r_; });
          V v_t_241107 = (g_std_2edoc_2e_3c_3e(v_t_241102, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241106})));
          V v_a_241108 = (g_std_2edoc_2egroup(v_t_241107));
          V v_b_241109 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241110 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_241109));
          return (g_std_2edoc_2e_3c_3e(v_a_241108, v_t_241110));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 6);
          V v_t_241111 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241114 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241115 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241114; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241114); r_; });
          V v_t_241116 = (g_std_2edoc_2e_3c_3e(v_t_241111, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241115})));
          return (g_std_2edoc_2egroup(v_t_241116));
        }
        default: return heff_nomatch(v_t_241101);
        }
      }
      case TAG_Do: {
        V v_t_241119 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241119)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241120 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241123 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241124 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241123; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241123); r_; });
          V v_t_241125 = (g_std_2edoc_2e_3c_3e(v_t_241120, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241124})));
          V v_a_241126 = (g_std_2edoc_2egroup(v_t_241125));
          V v_b_241127 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241128 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241127));
          return (g_std_2edoc_2e_3c_3e(v_a_241126, v_t_241128));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 2);
          V v_t_241129 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241132 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241133 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241132; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241132); r_; });
          V v_t_241134 = (g_std_2edoc_2e_3c_3e(v_t_241129, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241133})));
          return (g_std_2edoc_2egroup(v_t_241134));
        }
        default: return heff_nomatch(v_t_241119);
        }
      }
      case TAG_ESBind: {
        V v_t_241138 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241138)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241139 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241142 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241143 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241142; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241142); r_; });
          V v_t_241144 = (g_std_2edoc_2e_3c_3e(v_t_241139, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241143})));
          V v_a_241145 = (g_std_2edoc_2egroup(v_t_241144));
          V v_b_241146 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241147 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_b_241146));
          return (g_std_2edoc_2e_3c_3e(v_a_241145, v_t_241147));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 3);
          V v_t_241148 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241151 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241152 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241151; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241151); r_; });
          V v_t_241153 = (g_std_2edoc_2e_3c_3e(v_t_241148, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241152})));
          return (g_std_2edoc_2egroup(v_t_241153));
        }
        default: return heff_nomatch(v_t_241138);
        }
      }
      case TAG_ELet: {
        V v_t_241160 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24669));
        switch (heff_tag_of(v_t_241160)) {
        case TAG_True: {
          heff_drop(v_args_24661);
          V v_t_241161 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241164 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){heff_dup(v_env_24659)}), v_init2_24668));
          V v_d_241165 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241164; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241164); r_; });
          V v_t_241166 = (g_std_2edoc_2e_3c_3e(v_t_241161, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241165})));
          V v_a_241167 = (g_std_2edoc_2egroup(v_t_241166));
          V v_b_241168 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24659, v_lastA_24669}));
          V v_t_241169 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24666_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241168));
          return (g_std_2edoc_2e_3c_3e(v_a_241167, v_t_241169));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24666_24Just, 1);
          heff_drop(v_init2_24668);
          heff_drop_tag(v_lastA_24669, 6);
          V v_t_241170 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24659), v_h_24660}));
          V v_ds_241173 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_env_24659}), v_args_24661));
          V v_d_241174 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241173; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241173); r_; });
          V v_t_241175 = (g_std_2edoc_2e_3c_3e(v_t_241170, heff_tag_at_n(v_ru_24pr_24667_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241174})));
          return (g_std_2edoc_2egroup(v_t_241175));
        }
        default: return heff_nomatch(v_t_241160);
        }
      }
      default: return heff_nomatch(v_lastA_24669);
      }
    }
    default: return heff_nomatch(v_pr_24667);
    }
  }
  default: return heff_nomatch(v_t_24666);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_env_241176 = args[0];
  V v_rest_241177 = args[1];
  V v_e_241178 = args[2];
  switch (heff_tag_of(v_e_241178)) {
  case TAG_Atom: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_241192 = heff_field(v_e_241178, 0);
    V v_fs_241193 = heff_field(v_e_241178, 1);
    V v_commas_241194 = heff_field(v_e_241178, 2);
    V v_c_241195 = heff_field(v_e_241178, 3);
    heff_take_n(v_e_241178, 15ULL, 4);
    switch (heff_tag_of(v_fs_241193)) {
    case TAG_Nil: {
      heff_drop(v_rest_241177);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_241176;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241192, v_fs_241193, v_commas_241194, v_c_241195});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_241196 = heff_dup(heff_field(v_fs_241193, 0));
      V v_rest2_241197 = heff_dup(heff_field(v_fs_241193, 1));
      switch (heff_tag_of(v_rest2_241197)) {
      case TAG_Nil: {
        V v_t_241198 = ({ V a_0 = v_rest_241177; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241177); r_; });
        switch (heff_tag_of(v_t_241198)) {
        case TAG_True: {
          V v_x1_241199 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_241196));
          switch (heff_tag_of(v_x1_241199)) {
          case TAG_True: {
            heff_drop(v_d_241196);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_241176;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241192, v_fs_241193, v_commas_241194, v_c_241195});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          case TAG_False: {
            switch (heff_tag_of(v_commas_241194)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_241193, 2);
              V v_t_241200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241176), v_o_241192));
              V v_t_241201 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241176), v_d_241196}));
              V v_t_241202 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241176, v_c_241195));
              V v_t_241203 = (g_std_2edoc_2e_3c_3e(v_t_241201, v_t_241202));
              return (g_std_2edoc_2e_3c_3e(v_t_241200, v_t_241203));
            }
            case TAG_Cons: {
              heff_drop(v_d_241196);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_241176;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241192, v_fs_241193, v_commas_241194, v_c_241195});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_241194);
            }
          }
          default: return heff_nomatch(v_x1_241199);
          }
        }
        case TAG_False: {
          heff_drop(v_d_241196);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_241176;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241192, v_fs_241193, v_commas_241194, v_c_241195});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_t_241198);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_241197, 0ULL, 2);
        heff_drop(v_rest_241177);
        heff_drop(v_d_241196);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241176;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241192, v_fs_241193, v_commas_241194, v_c_241195});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_241197);
      }
    }
    default: return heff_nomatch(v_fs_241193);
    }
  }
  case TAG_InstB: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241177);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241176;
    args[1] = v_e_241178;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_241178);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_env_241277 = args[0];
  V v_b_241278 = args[1];
  switch (heff_tag_of(v_b_241278)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_241328 = heff_field(v_b_241278, 0);
    heff_take_n(v_b_241278, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241277, v_t_241328));
  }
  case TAG_BImp: {
    V v_o_241329 = heff_field(v_b_241278, 0);
    V v_x_241330 = heff_field(v_b_241278, 1);
    V v_c_241331 = heff_field(v_b_241278, 2);
    heff_take_n(v_b_241278, 7ULL, 3);
    V v_t_241332 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_o_241329));
    V v_t_241333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_x_241330));
    V v_t_241334 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241277, v_c_241331));
    V v_t_241335 = (g_std_2edoc_2e_3c_3e(v_t_241333, v_t_241334));
    return (g_std_2edoc_2e_3c_3e(v_t_241332, v_t_241335));
  }
  case TAG_BAnn: {
    V v_o_241336 = heff_field(v_b_241278, 0);
    V v_x_241337 = heff_field(v_b_241278, 1);
    V v_cc_241338 = heff_field(v_b_241278, 2);
    V v_ty_241339 = heff_field(v_b_241278, 3);
    V v_c_241340 = heff_field(v_b_241278, 4);
    heff_take_n(v_b_241278, 31ULL, 5);
    V v_t_241341 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_o_241336));
    V v_a_241342 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_x_241337));
    V v_a_241343 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_cc_241338));
    V v_b_241344 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241277), v_ty_241339}));
    V v_t_241345 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241344));
    V v_b_241346 = (g_std_2edoc_2e_3c_3e(v_a_241343, v_t_241345));
    V v_t_241347 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241346));
    V v_t_241348 = (g_std_2edoc_2e_3c_3e(v_a_241342, v_t_241347));
    V v_t_241349 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241277, v_c_241340));
    V v_t_241350 = (g_std_2edoc_2e_3c_3e(v_t_241348, v_t_241349));
    return (g_std_2edoc_2e_3c_3e(v_t_241341, v_t_241350));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241277;
    args[1] = v_b_241278;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_241278);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_env_241379 = args[0];
  V v_rest_241380 = args[1];
  V v_r_241381 = args[2];
  switch (heff_tag_of(v_r_241381)) {
  case TAG_Atom: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241426 = heff_field(v_r_241381, 0);
    V v_e_241427 = heff_field(v_r_241381, 1);
    heff_take_n(v_r_241381, 3ULL, 2);
    V v_a_241428 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241379), v_op_241426));
    V v_b_241429 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_241379, v_rest_241380, v_e_241427}));
    V v_t_241430 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241429));
    return (g_std_2edoc_2e_3c_3e(v_a_241428, v_t_241430));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241380);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241379;
    args[1] = v_r_241381;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241381);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_env_241471 = args[0];
  V v_r_241472 = args[1];
  switch (heff_tag_of(v_r_241472)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241517 = heff_field(v_r_241472, 0);
    V v_e_241518 = heff_field(v_r_241472, 1);
    heff_take_n(v_r_241472, 3ULL, 2);
    V v_a_241519 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241471), v_op_241517));
    V v_b_241520 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241471, v_e_241518}));
    V v_t_241521 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241520));
    return (g_std_2edoc_2e_3c_3e(v_a_241519, v_t_241521));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241471;
    args[1] = v_r_241472;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241472);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_r_241572 = args[0];
  V v_env_241562 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241573 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241562, v_r_241572}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241573));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_r_241581 = args[0];
  V v_env_241562 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241582 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241562, v_r_241581}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241582));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_env_241562 = args[0];
  V v_first_241563 = args[1];
  V v_rest_241564 = args[2];
  V v_f_241565 = heff_dup(heff_rfield(v_env_241562, 6));
  V v_it_241566 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(heff_dup(v_f_241565), heff_dup(v_rest_241564)));
  V v_t_241570;
  switch (heff_tag_of(v_it_241566)) {
  case TAG_Nothing: {
    heff_drop(v_f_241565);
    v_t_241570 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_241567 = heff_field(v_it_241566, 0);
    heff_take_n(v_it_241566, 1ULL, 1);
    switch (heff_tag_of(v_it1_241567)) {
    case TAG_Nil: {
      heff_drop(v_f_241565);
      v_t_241570 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_o_241568 = heff_field(v_it1_241567, 0);
      V v_os_241569 = heff_field(v_it1_241567, 1);
      heff_take_n(v_it1_241567, 3ULL, 2);
      v_t_241570 = ({ V a_0 = v_f_241565; V a_1 = v_o_241568; V a_2 = v_os_241569; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_241569); r_; });
      break;
    }
    default: heff_nomatch(v_it1_241567);
    }
    break;
  }
  default: heff_nomatch(v_it_241566);
  }
  switch (heff_tag_of(v_t_241570)) {
  case TAG_Nothing: {
    V v_t_241571 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241562), v_first_241563}));
    V v_ds_241574 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_env_241562}), v_rest_241564));
    V v_t_241575 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241574; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241574); r_; });
    V v_t_241576 = (g_std_2edoc_2e_3c_3e(v_t_241571, v_t_241575));
    return (g_std_2edoc_2egroup(v_t_241576));
  }
  case TAG_Just: {
    V v_m_241577 = heff_field(v_t_241570, 0);
    heff_take_n(v_t_241570, 1ULL, 1);
    V v_t_241578 = heff_tr(heff_apply(((V)&g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo), 2, (V[]){heff_dup(heff_rfield(v_env_241562, 6)), heff_dup(v_m_241577)}));
    V v_t_241579 = (g_list_2eall(v_t_241578, v_rest_241564));
    switch (heff_tag_of(v_t_241579)) {
    case TAG_True: {
      heff_drop(v_m_241577);
      V v_t_241580 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241562), v_first_241563}));
      V v_ds_241583 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_env_241562}), v_rest_241564));
      V v_t_241584 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241583; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241583); r_; });
      V v_t_241585 = (g_std_2edoc_2e_3c_3e(v_t_241580, v_t_241584));
      return (g_std_2edoc_2egroup(v_t_241585));
    }
    case TAG_False: {
      V v_t_241586 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241562, v_m_241577, v_first_241563, NTAG(TAG_Nil), v_rest_241564}));
      return (g_std_2edoc_2egroup(v_t_241586));
    }
    default: return heff_nomatch(v_t_241579);
    }
  }
  default: return heff_nomatch(v_t_241570);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_env_241587 = args[0];
  V v_m_241588 = args[1];
  V v_f_241589 = args[2];
  V v_acc_241590 = args[3];
  V v_rs_241591 = args[4];
  switch (heff_tag_of(v_rs_241591)) {
  case TAG_Nil: {
    heff_drop(v_m_241588);
    V v_t_241592 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241590));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_241587;
    args[1] = v_f_241589;
    args[2] = v_t_241592;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_241593 = heff_field(v_rs_241591, 0);
    V v_rest2_241594 = heff_field(v_rs_241591, 1);
    heff_take_n(v_rs_241591, 3ULL, 2);
    switch (heff_tag_of(v_r_241593)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_241639 = heff_dup(heff_field(v_r_241593, 0));
      V v_e_241640 = heff_dup(heff_field(v_r_241593, 1));
      V v_t_241641 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_241587, 6)), heff_dup(v_m_241588), heff_dup(heff_rfield(v_op_241639, 1))));
      V v_t_241644;
      switch (heff_tag_of(v_t_241641)) {
      case TAG_Tighter: {
        v_t_241644 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_241644 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_241641, 0ULL, 1);
        v_t_241644 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_241644 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_241641, 0ULL, 1);
        v_t_241644 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_241641);
      }
      switch (heff_tag_of(v_t_241644)) {
      case TAG_True: {
        heff_drop_tag(v_r_241593, 2);
        V v_t_241645 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241590));
        V v_t_241646 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_241587), v_f_241589, v_t_241645}));
        V v_a_241647 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241587), v_op_241639));
        V v_b_241648 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241587, v_m_241588, v_e_241640, NTAG(TAG_Nil), v_rest2_241594}));
        V v_t_241649 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241648));
        V v_t_241650 = (g_std_2edoc_2e_3c_3e(v_a_241647, v_t_241649));
        V v_t_241651 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241650));
        return (g_std_2edoc_2e_3c_3e(v_t_241646, v_t_241651));
      }
      case TAG_False: {
        heff_drop_rec(v_op_241639, 9);
        heff_drop(v_e_241640);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_241587;
        args[1] = v_m_241588;
        args[2] = v_f_241589;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
        args[4] = v_rest2_241594;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_241644);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241587;
      args[1] = v_m_241588;
      args[2] = v_f_241589;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241593, v_acc_241590});
      args[4] = v_rest2_241594;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_241593);
    }
  }
  default: return heff_nomatch(v_rs_241591);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_env_241692 = args[0];
  V v_a_241693 = args[1];
  switch (heff_tag_of(v_a_241693)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_241760 = heff_field(v_a_241693, 0);
    V v_arrow_241761 = heff_field(v_a_241693, 1);
    V v_body_241762 = heff_field(v_a_241693, 2);
    heff_take_n(v_a_241693, 7ULL, 3);
    V v_a_241763 = ({ V a_0 = heff_dup(v_env_241692); V a_1 = v_p_241760; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241760); r_; });
    V v_b_241764 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241692), v_arrow_241761));
    V v_t_241765 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241764));
    V v_t_241766 = (g_std_2edoc_2e_3c_3e(v_a_241763, v_t_241765));
    V v_t_241767 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241692, v_body_241762}));
    return (g_std_2edoc_2e_3c_3e(v_t_241766, v_t_241767));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241692;
    args[1] = v_a_241693;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_241693);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_env_241785 = args[0];
  V v_s_241786 = args[1];
  switch (heff_tag_of(v_s_241786)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_241864 = heff_field(v_s_241786, 0);
    V v_arrow_241865 = heff_field(v_s_241786, 1);
    V v_e_241866 = heff_field(v_s_241786, 2);
    heff_take_n(v_s_241786, 7ULL, 3);
    V v_a_241867 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241785), v_x_241864));
    V v_b_241868 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241785), v_arrow_241865));
    V v_t_241869 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241868));
    V v_t_241870 = (g_std_2edoc_2e_3c_3e(v_a_241867, v_t_241869));
    V v_t_241871 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241785, v_e_241866}));
    return (g_std_2edoc_2e_3c_3e(v_t_241870, v_t_241871));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241785;
    args[1] = v_s_241786;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_241786);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_env_241878 = args[0];
  V v_f_241879 = args[1];
  switch (heff_tag_of(v_f_241879)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_241902 = heff_field(v_f_241879, 0);
    V v_eq_241903 = heff_field(v_f_241879, 1);
    V v_e_241904 = heff_field(v_f_241879, 2);
    heff_take_n(v_f_241879, 7ULL, 3);
    V v_a_241905 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241878), v_x_241902));
    V v_b_241906 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241878), v_eq_241903));
    V v_t_241907 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241906));
    V v_t_241908 = (g_std_2edoc_2e_3c_3e(v_a_241905, v_t_241907));
    V v_t_241909 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241878, v_e_241904}));
    return (g_std_2edoc_2e_3c_3e(v_t_241908, v_t_241909));
  }
  case TAG_EFDefault: {
    V v_d_241910 = heff_field(v_f_241879, 0);
    V v_eq_241911 = heff_field(v_f_241879, 1);
    V v_e_241912 = heff_field(v_f_241879, 2);
    heff_take_n(v_f_241879, 7ULL, 3);
    V v_a_241913 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241878), v_d_241910}));
    V v_b_241914 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241878), v_eq_241911));
    V v_t_241915 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241914));
    V v_t_241916 = (g_std_2edoc_2e_3c_3e(v_a_241913, v_t_241915));
    V v_t_241917 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241878, v_e_241912}));
    return (g_std_2edoc_2e_3c_3e(v_t_241916, v_t_241917));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_f_241879;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_241879);
  }
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2esig_str0, 1, (32));
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esig_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242) {
top: ;
  V v_a_243 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_241));
  V v_b_244 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_242}));
  V v_t_245 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2esig_str0)}), v_b_244));
  V v_d_246 = (g_std_2edoc_2e_3c_3e(v_a_243, v_t_245));
  return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam0, 1, 1, (V[]){v_d_246})});
}
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2esig(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_249 = heff_intSub(v_k_247, v_i_248);
  if (heff_intEq_c(heff_dup(v_i_249), MK_INT(0LL))) {
    heff_drop(v_i_249);
    return v_d_246;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_249, v_d_246});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_d_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam1, 1, 2, (V[]){v_k_247, v_d_246})});
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, (32));
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_alts_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_alts_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_eq_243);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_alts_244, 0);
        V v_more_247 = heff_field(v_alts_244, 1);
        heff_take_n(v_alts_244, 3ULL, 2);
        V v_a_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_243));
        V v_b_249 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_249));
        V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_a_248, v_t_2410));
        V v_ds_2418 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 1, (V[]){v_env_240}), v_bars_245, v_more_247));
        V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2418); r_; });
        V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2419));
        V v_t_2421 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2420));
        return (g_std_2edoc_2egroup(v_t_2421));
      }
      default: return heff_nomatch(v_alts_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2412 = args[0];
  V v_a_2413 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2414 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2412));
  V v_b_2415 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2413}));
  V v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2415));
  V v_t_2417 = (g_std_2edoc_2e_3c_3e(v_a_2414, v_t_2416));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2417));
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1, 1, (32));
Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_cc_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    V v_a_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_242)));
    V v_b_247 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_240), heff_dup(v_cc_243), heff_dup(v_ty_244)));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0)}), v_b_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_a_246, v_t_248));
    V v_t_2416;
    switch (heff_tag_of(v_d_245)) {
    case TAG_Nothing: {
      heff_drop(v_env_240);
      v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2410 = heff_field(v_d_245, 0);
      switch (heff_tag_of(v_x21_2410)) {
      case TAG_MkPair: {
        V v_eq_2411 = heff_field(v_x21_2410, 0);
        V v_d_2412 = heff_field(v_x21_2410, 1);
        V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2411)));
        V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_d_2412)}));
        V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
        v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1)}), v_t_2415));
        break;
      }
      default: heff_nomatch(v_x21_2410);
      }
      break;
    }
    default: heff_nomatch(v_d_245);
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_249, v_t_2416);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2etfDoc(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_x2_245 = ({ V a_0 = heff_take_field(v_t_244, 7); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x1_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_x1_247 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_x1_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2410 = heff_get_n(v_t_244, 8, 9);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      heff_drop_rec(v_t_244, 9);
      v_t_2410 = heff_get_n(v_x_248, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      v_t_2411 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_2411 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2411));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V v_env_240, V v_rhsLast_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_rhsLast_241, 9);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_kw_244 = heff_field(v_x41_243, 0);
      V v_ds_245 = heff_field(v_x41_243, 1);
      V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_rhsLast_241, 7)), heff_rfield(v_env_240, 3)));
      V v_t_248;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_rhsLast_241, 9);
        v_t_248 = heff_dup(g_std_2edoc_2ehardline_get());
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_246, 0ULL, 1);
        v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(heff_dup(v_env_240), v_rhsLast_241));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_244)));
      V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, MK_INT(0LL), v_ds_245));
      V v_d_2411 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2410));
      V v_t_2412 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2411})));
      return (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2417;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_x_246 = heff_field(v_x_243, 0);
        v_t_2410 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_x2_2411 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_2410, 7), heff_rfield(v_env_240, 1)));
      V v_x1_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_x1_2413 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_x1_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2416;
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nil: {
        v_t_2416 = heff_get_n(v_t_2410, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 2);
        heff_drop_rec(v_t_2410, 9);
        v_t_2416 = heff_get_n(v_x_2414, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        v_t_2417 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
    } else {
      v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2422;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_x_2418 = heff_field(v_x_243, 0);
      v_t_2422 = heff_dup(v_x_2418);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2425 = heff_field(v_x_243, 2);
      V v_x14_2426 = heff_field(v_x_243, 3);
      switch (heff_tag_of(v_x14_2426)) {
      case TAG_Nothing: {
        v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2425)));
        break;
      }
      case TAG_Just: {
        V v_x141_2427 = heff_field(v_x14_2426, 0);
        switch (heff_tag_of(v_x141_2427)) {
        case TAG_MkPair: {
          V v_d_2429 = heff_field(v_x141_2427, 1);
          v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2429)));
          break;
        }
        default: heff_nomatch(v_x141_2427);
        }
        break;
      }
      default: heff_nomatch(v_x14_2426);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2422, v_t_2430, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2434));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2435));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2431 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2431; V a_1 = v_x_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2etfDoc(a_0, a_1)); heff_drop(v_x_243); r_; });
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str1, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str2, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str3, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str4, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str5, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str6, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str7, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str8, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str9, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str10, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str11, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str12, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str13, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str14, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str15, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str16, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str17, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str18, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str19, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str20, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str21, 1, (32));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str22, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str23, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2epD_str24, 0, (0));
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epD_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epD(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DImport: {
    V v_t_242 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_242));
  }
  case TAG_DFixity: {
    V v_kw_243 = heff_field(v_x2_241, 0);
    V v_ts_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_243)));
    V v_ds_248 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_ts_244)));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_248; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_248); r_; });
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_245, v_t_249);
  }
  case TAG_DSig: {
    V v_n_2410 = heff_field(v_x2_241, 0);
    V v_cc_2411 = heff_field(v_x2_241, 1);
    V v_ty_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = heff_tr(heff_apply(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2414 = (g_list_2emap(v_t_2413, heff_dup(v_n_2410)));
    V v_a_2415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2414; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2414); r_; });
    V v_b_2416 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2411), heff_dup(v_ty_2412)));
    V v_t_2417 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str1)}), v_b_2416));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2415, v_t_2417);
  }
  case TAG_DEqn: {
    V v_n_2418 = heff_field(v_x2_241, 0);
    V v_pats_2419 = heff_field(v_x2_241, 1);
    V v_eq_2420 = heff_field(v_x2_241, 2);
    V v_rhs_2421 = heff_field(v_x2_241, 3);
    V v_w_2422 = heff_field(v_x2_241, 4);
    V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2424 = (g_list_2emap(v_t_2423, heff_dup(v_n_2418)));
    V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2424; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2424); r_; });
    V v_ds_2428 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_pats_2419)));
    V v_a_2429 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2428; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2428); r_; });
    V v_b_2430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2420)));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str3)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_rhsLast_2433 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2435;
    switch (heff_tag_of(v_w_2422)) {
    case TAG_Nothing: {
      heff_drop_rec(v_rhsLast_2433, 9);
      v_t_2435 = heff_dup(v_env_240);
      break;
    }
    case TAG_Just: {
      v_t_2435 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_dup(heff_rfield(v_env_240, 4)), heff_get_n(v_rhsLast_2433, 7, 9), heff_dup(heff_rfield(v_env_240, 6))});
      break;
    }
    default: heff_nomatch(v_w_2422);
    }
    V v_t_2436 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_t_2435, heff_dup(v_rhs_2421)}));
    V v_t_2437 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2438 = (g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(v_env_240, v_t_2437, v_w_2422));
    V v_t_2439 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2438));
    V v_t_2440 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2439));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2440);
  }
  case TAG_DData: {
    V v_kw_2441 = heff_field(v_x2_241, 0);
    V v_name_2442 = heff_field(v_x2_241, 1);
    V v_params_2443 = heff_field(v_x2_241, 2);
    V v_universe_2444 = heff_field(v_x2_241, 3);
    V v_alts_2445 = heff_field(v_x2_241, 4);
    V v_a_2446 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2441)));
    V v_b_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2442)));
    V v_t_2448 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str4)}), v_b_2447));
    V v_t_2449 = (g_std_2edoc_2e_3c_3e(v_a_2446, v_t_2448));
    V v_ds_2453 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2443)));
    V v_t_2454 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2453; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2453); r_; });
    V v_t_2462;
    switch (heff_tag_of(v_universe_2444)) {
    case TAG_Nothing: {
      v_t_2462 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2455 = heff_field(v_universe_2444, 0);
      switch (heff_tag_of(v_x21_2455)) {
      case TAG_MkPair: {
        V v_cc_2456 = heff_field(v_x21_2455, 0);
        V v_u_2457 = heff_field(v_x21_2455, 1);
        V v_a_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2456)));
        V v_b_2459 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), heff_dup(v_u_2457)}));
        V v_t_2460 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str6)}), v_b_2459));
        V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_a_2458, v_t_2460));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str7)}), v_t_2461));
        break;
      }
      default: heff_nomatch(v_x21_2455);
      }
      break;
    }
    default: heff_nomatch(v_universe_2444);
    }
    V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(v_env_240, heff_dup(v_alts_2445)));
    V v_t_2464 = (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    V v_t_2465 = (g_std_2edoc_2e_3c_3e(v_t_2454, v_t_2464));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2465);
  }
  case TAG_DType: {
    V v_kw_2466 = heff_field(v_x2_241, 0);
    V v_name_2467 = heff_field(v_x2_241, 1);
    V v_params_2468 = heff_field(v_x2_241, 2);
    V v_eq_2469 = heff_field(v_x2_241, 3);
    V v_body_2470 = heff_field(v_x2_241, 4);
    V v_a_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2466)));
    V v_b_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2467)));
    V v_t_2473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str8)}), v_b_2472));
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_a_2471, v_t_2473));
    V v_ds_2478 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam3, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2468)));
    V v_a_2479 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2478; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2478); r_; });
    V v_b_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2469)));
    V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str10)}), v_b_2480));
    V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_a_2479, v_t_2481));
    V v_t_2483 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_body_2470)}));
    V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_t_2482, v_t_2483));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2484);
  }
  case TAG_DTheory: {
    V v_kw_2485 = heff_field(v_x2_241, 0);
    V v_name_2486 = heff_field(v_x2_241, 1);
    V v_params_2487 = heff_field(v_x2_241, 2);
    V v_w_2488 = heff_field(v_x2_241, 3);
    V v_fields_2489 = heff_field(v_x2_241, 4);
    V v_a_2490 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2485)));
    V v_b_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2486)));
    V v_t_2492 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str11)}), v_b_2491));
    V v_t_2493 = (g_std_2edoc_2e_3c_3e(v_a_2490, v_t_2492));
    V v_ds_2497 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam4, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2487)));
    V v_a_2498 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2497; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2497); r_; });
    V v_b_2499 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_2488)));
    V v_t_24100 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str13)}), v_b_2499));
    V v_t_24101 = (g_std_2edoc_2e_3c_3e(v_a_2498, v_t_24100));
    V v_t_24102 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, MK_INT(0LL), v_fields_2489));
    V v_t_24103 = (g_std_2edoc_2e_3c_3e(v_t_24101, v_t_24102));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2493, v_t_24103);
  }
  case TAG_DPrimitive: {
    V v_kw_24104 = heff_field(v_x2_241, 0);
    V v_x_24105 = heff_field(v_x2_241, 1);
    V v_cc_24106 = heff_field(v_x2_241, 2);
    V v_ty_24107 = heff_field(v_x2_241, 3);
    V v_a_24108 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24104)));
    V v_a_24109 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_24105)));
    V v_b_24110 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_24106), heff_dup(v_ty_24107)));
    V v_t_24111 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str14)}), v_b_24110));
    V v_b_24112 = (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24111));
    V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str15)}), v_b_24112));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24108, v_t_24113);
  }
  case TAG_DTest: {
    V v_kw_24114 = heff_field(v_x2_241, 0);
    V v_x_24115 = heff_field(v_x2_241, 1);
    V v_a_24116 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24114)));
    V v_b_24117 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_x_24115)));
    V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str16)}), v_b_24117));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24116, v_t_24118);
  }
  case TAG_DWatch: {
    V v_w_24119 = heff_field(v_x2_241, 0);
    V v_e_24120 = heff_field(v_x2_241, 1);
    V v_t_24121 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_24119)));
    V v_t_24122 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24120));
    V v_b_24123 = heff_get_n(v_t_24122, 3, 9);
    V v_s_24124 = heff_strSlice(heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_w_24119, 4)), v_b_24123);
    V v_t_24125 = (g_prelude_2eskipSpaces(heff_dup(v_s_24124), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24126 = heff_intSub(heff_strLength(heff_dup(v_s_24124)), MK_INT(1LL));
    V v_t_24127 = (g_prelude_2eskipSpaces(heff_dup(v_s_24124), v_t_24126, MK_INT(-1LL)));
    V v_t_24128 = heff_strSlice(v_s_24124, v_t_24125, heff_intAdd(v_t_24127, MK_INT(1LL)));
    V v_t_24149;
    if (heff_strEq_c(v_t_24128, ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str17))) {
      V v_t_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24120));
      V v_a_24131 = heff_get_n(v_t_24130, 3, 9);
      V v_t_24132 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24120)));
      V v_b_24133 = heff_get_n(v_t_24132, 4, 9);
      V v_s_24134 = heff_strSlice(heff_get_n(v_env_240, 0, 7), v_a_24131, v_b_24133);
      V v_x2_24135 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str18), v_s_24134, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24138;
      switch (heff_tag_of(v_x2_24135)) {
      case TAG_Nil: {
        v_s_24138 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_24136 = heff_field(v_x2_24135, 0);
        V v_xs_24137 = heff_field(v_x2_24135, 1);
        heff_take_n(v_x2_24135, 3ULL, 2);
        v_s_24138 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24136; V a_2 = v_xs_24137; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24137); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24135);
      }
      V v_t_24140;
      if (heff_strEq_c(heff_dup(v_s_24138), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str20))) {
        heff_drop(v_s_24138);
        v_t_24140 = NTAG(TAG_None);
      } else {
        v_t_24140 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24138});
      }
      v_t_24149 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str21)}), v_t_24140));
    } else {
      V v_t_24141 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24120)));
      V v_b_24142 = heff_get_n(v_t_24141, 4, 9);
      V v_s_24143 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_dup(heff_rfield(v_w_24119, 4)), v_b_24142);
      V v_x2_24144 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str22), v_s_24143, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24147;
      switch (heff_tag_of(v_x2_24144)) {
      case TAG_Nil: {
        v_s_24147 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str23);
        break;
      }
      case TAG_Cons: {
        V v_x_24145 = heff_field(v_x2_24144, 0);
        V v_xs_24146 = heff_field(v_x2_24144, 1);
        heff_take_n(v_x2_24144, 3ULL, 2);
        v_s_24147 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24145; V a_2 = v_xs_24146; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24146); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24144);
      }
      if (heff_strEq_c(heff_dup(v_s_24147), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str24))) {
        heff_drop(v_s_24147);
        v_t_24149 = NTAG(TAG_None);
      } else {
        v_t_24149 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24147});
      }
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_24121, v_t_24149);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2epD(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_246));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str0)}), v_t_247));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = ({ V a_0 = v_env_240; V a_1 = v_p_2426; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_2426); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str2)}), v_t_2427));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args) {
  V v_p_2450 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2450}));
  V v_t_2452 = (g_std_2edoc_2eflatten(v_t_2451));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str5)}), v_t_2452));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args) {
  V v_p_2475 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2475}));
  V v_t_2477 = (g_std_2edoc_2eflatten(v_t_2476));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str9)}), v_t_2477));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args) {
  V v_p_2494 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_tr(heff_apply(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2494}));
  V v_t_2496 = (g_std_2edoc_2eflatten(v_t_2495));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str12)}), v_t_2496));
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str0, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str2, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_245 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str0), heff_dup(heff_rfield(v_c_242, 0)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_s_249 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2411;
    if (heff_strEq_c(heff_dup(v_s_249), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str2))) {
      heff_drop(v_s_249);
      v_t_2411 = NTAG(TAG_None);
    } else {
      v_t_2411 = heff_tag_n(TAG_Text, 1, (V[]){v_s_249});
    }
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(v_env_240, v_cs_243));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2412));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2413));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2414);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
    }
    case TAG_False: {
      V t_0 = v_cs_243;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DEqn: {
    V v_n_2410 = heff_field(v_d_240, 0);
    V v_x2_2415 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2410)));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefLast_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2edefLast_str1, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefLast_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefLast(V v_x_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_d_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    V v_t_2443;
    switch (heff_tag_of(v_e_243)) {
    case TAG_DImport: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2411 = heff_field(v_e_243, 0);
      V v_x2_2416 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str1); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      v_t_2443 = heff_strEq(v_t_2419, heff_dup(v_x_240));
      break;
    }
    case TAG_DData: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_243);
    }
    switch (heff_tag_of(v_t_2443)) {
    case TAG_True: {
      heff_drop(v_d_241);
      V t_0 = v_x_240;
      V t_1 = heff_dup(v_e_243);
      V t_2 = v_es_244;
      v_x_240 = t_0;
      v_d_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_x_240);
      return v_d_241;
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2edefLast(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_e_242)) {
    case TAG_DImport: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2410 = heff_dup(heff_field(v_e_242, 0));
      V v_x2_2415 = (g_list_2emap_24s759871588x920431471(v_n_2410));
      V v_t_2418;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      v_t_2442 = heff_strEq(v_t_2418, heff_dup(v_x_240));
      break;
    }
    case TAG_DData: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_es_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_x_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eafterDef(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2egapEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V v_s_240, V v_j_241) {
top: ;
  if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL))) {
    V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), heff_dup(v_j_241)));
    V v_a_244 = heff_intSub(v_t_243, heff_dup(v_j_241));
    if (heff_intLe_c(MK_INT(2LL), v_a_244)) {
      V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), v_j_241));
      V v_c_247 = heff_strCharCode(v_s_240, v_t_246);
      V v_x1_2411;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_247))) {
        V v_x3_249 = (g_prelude_2eindexFrom(heff_strFromCharCode(v_c_247), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          v_x1_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_249, 0ULL, 1);
          v_x1_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_249);
        }
      } else {
        heff_drop(v_c_247);
        v_x1_2411 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2411);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(heff_dup(v_s_240), v_t_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_s_240, v_t_244);
  }
  case TAG_False: {
    V v_j_245 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_j_245)), MK_INT(123LL))) {
      V v_t_247 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(v_j_245, MK_INT(1LL)));
      if (heff_intEq_c(v_t_247, MK_INT(45LL))) {
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
        V v_r_2410 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(heff_dup(v_s_240), v_t_249, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
        V t_0 = v_s_240;
        V t_1 = heff_get_n(v_r_2410, 0, 5);
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        return v_i_241;
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_245);
      return v_i_241;
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2easWritten_str0, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2easWritten_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2easWritten_str2, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2easWritten_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2easWritten(V v_env_240, V v_first_241, V v_last2_242) {
top: ;
  V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_first_241, 7), heff_rfield(v_env_240, 2)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ds_2410 = (g_list_2emap_24s422923909x1655406376(v_t_249));
  V v_t_2411 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2410; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2410); r_; });
  V v_b_2412 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_last2_242, 4, 9)));
  V v_s_2413 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_get_n(v_first_241, 3, 9), v_b_2412);
  V v_x2_2414 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str0), v_s_2413, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_s_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_s_2417 = ((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_s_2417 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2419;
  if (heff_strEq_c(heff_dup(v_s_2417), ((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str2))) {
    heff_drop(v_s_2417);
    v_t_2419 = NTAG(TAG_None);
  } else {
    v_t_2419 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2417});
  }
  V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2419));
  return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2420));
}
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2easWritten(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eskipped_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eskipped(V v_env_240, V v_above_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_above_241)) {
  case TAG_True: {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_244 = heff_take_field(v_t_243, 8);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop_rec(v_t_243, 9);
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
      V v_t_246 = heff_take_field(v_t_245, 8);
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop_rec(v_env_240, 7);
        heff_drop_rec(v_t_245, 9);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        V v_x2_247 = ({ V a_0 = heff_get_n(v_t_245, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
        V v_xs_249;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nothing: {
          v_xs_249 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_248 = heff_field(v_x2_247, 0);
          heff_take_n(v_x2_247, 1ULL, 1);
          v_xs_249 = v_x_248;
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
        V v_t_2411 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2410, NTAG(TAG_Nil)));
        return ({ V a_0 = v_t_2411; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2411); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      V v_x2_2412 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_t_243, 7, 9), heff_rfield(v_env_240, 1)));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        v_t_2414 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_x1_2415 = ({ V a_0 = v_t_2414; V r_ = (g_list_2eany_24s2118781542x1794344985(a_0)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_True: {
        V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
        V v_t_2417 = heff_take_field(v_t_2416, 8);
        switch (heff_tag_of(v_t_2417)) {
        case TAG_True: {
          heff_drop_rec(v_env_240, 7);
          heff_drop_rec(v_t_2416, 9);
          return NTAG(TAG_False);
        }
        case TAG_False: {
          V v_x2_2418 = ({ V a_0 = heff_get_n(v_t_2416, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
          V v_xs_2420;
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_Nothing: {
            v_xs_2420 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            heff_take_n(v_x2_2418, 1ULL, 1);
            v_xs_2420 = v_x_2419;
            break;
          }
          default: heff_nomatch(v_x2_2418);
          }
          V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
          V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2421, NTAG(TAG_Nil)));
          return ({ V a_0 = v_t_2422; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2422); r_; });
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      case TAG_False: {
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    V v_t_2423 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_2424 = heff_take_field(v_t_2423, 8);
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_2423, 9);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_x2_2425 = ({ V a_0 = heff_get_n(v_t_2423, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
      V v_xs_2427;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        v_xs_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        heff_take_n(v_x2_2425, 1ULL, 1);
        v_xs_2427 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
      V v_t_2429 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2428, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2429; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2429); r_; });
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_above_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2efmt_2elayout_2eskipped(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, (100, 111, 99, 116, 101, 115, 116));
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2441;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2439 = heff_dup(heff_field(v_d_244, 0));
      v_t_2441 = heff_strEq(heff_get_n(v_w_2439, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2462;
    switch (heff_tag_of(v_t_2441)) {
    case TAG_True: {
      V v_t_2442 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2443 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2445 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2442, v_t_2443, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2446 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2447 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2446, v_ds_245));
      v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2445, v_t_2447));
      break;
    }
    case TAG_False: {
      V v_t_2448 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      switch (heff_tag_of(v_t_2448)) {
      case TAG_True: {
        V v_t_2449 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2450 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2edefLast(v_t_2450, heff_dup(v_d_244), v_ds_245));
        V v_t_2452 = (g_heff_2esyntax_2ecst_2elastD(v_t_2451));
        V v_t_2453 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2449, v_t_2452));
        V v_t_2454 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2455 = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(v_t_2454, v_ds_245));
        V v_t_2456 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2455));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2453, v_t_2456));
        break;
      }
      case TAG_False: {
        V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2458 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2457, v_t_2458, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2460, v_t_2461));
        break;
      }
      default: heff_nomatch(v_t_2448);
      }
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2462));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2444 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2444; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2459 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2459; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_ls_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
    V v_t_245 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_244, MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_241);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0), (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_ls_242))});
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
      V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_249, MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(heff_dup(v_l_241), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2411, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1))) {
        heff_drop(v_l_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_241, (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_ls_242))});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines(a[0]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, (10));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, (10));
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1), v_s_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_s_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x2_2411;
  if (heff_intEq_c(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get())), MK_INT(0LL))) {
    v_x2_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
  } else {
    v_x2_2411 = (g_prelude_2esplitFrom(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), v_s_249, MK_INT(0LL), NTAG(TAG_Nil)));
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str0, 3, (101, 111, 102));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str2, 0, (0));
Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Left = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_at_240, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Left, TAG_Left, 1, (V[]){v_e_242});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Right = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_ts_245 = heff_get_n(v_at_240, 0, 2);
    V v_eof_248;
    if (heff_intLt_c(MK_INT(0LL), heff_arrayLength(heff_dup(v_ts_245)))) {
      V v_t_247 = heff_intSub(heff_arrayLength(heff_dup(v_ts_245)), MK_INT(1LL));
      v_eof_248 = heff_arrayIndex(v_ts_245, v_t_247);
    } else {
      heff_drop(v_ts_245);
      v_eof_248 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), v_ds_243));
    V v_x2_2410 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_eof_248, 7, 9), heff_rfield(v_env_244, 1)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2413 = ({ V a_0 = v_env_244; V a_1 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2413));
    return heff_tag_at_n(v_ru_24x2_241_24Right, TAG_Right, 1, (V[]){(g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2414))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtParsed(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0, 21, (116, 104, 101, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 108, 101, 120));
Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_x1_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_x1_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 2);
    heff_drop_rec(v_l_243, 3);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0)});
  }
  case TAG_False: {
    V v_t_249 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_hdr_242, 0, 2)));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_take_field(v_l_243, 0)));
    V v_t_2411 = (g_list_2esortBy_24s88152486x2058486153(v_t_2410));
    V v_at_2412 = (g_heff_2esyntax_2efmt_2etoks_2eattach(v_src_241, v_t_2411, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 0, 7);
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 1, 7);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 2, 7);
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 3, 7);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 4, 7);
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 5, 7);
    V v_at_2419 = ({ V rv_1 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_t_2413, v_t_2414, v_t_2415, v_t_2416, v_t_2417, v_t_2418, v_f_240}); V rr_ = heff_rec_reuse_n(v_at_2412, 1ULL, 2, shape_toks__env); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_2419, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2420, MK_INT(0LL)});
    V v_t_2422 = (g_heff_2esyntax_2ecst_2eprogramGo(v_t_2421, NTAG(TAG_Nil)));
    return (g_heff_2esyntax_2efmt_2elayout_2efmtParsed(v_at_2419, v_t_2422));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtLexed(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V v_f_240, V v_src_241) {
top: ;
  V v_imps_242 = (g_heff_2esyntax_2efmt_2eimports_2ereadGo(heff_dup(v_src_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1759289969x319536741(heff_dup(v_src_241), v_imps_242));
  V v_hdr_244 = heff_rec_n(2, shape_imports__text, (V[]){v_imps_242, v_t_243});
  V v_t_245 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(heff_rfield(v_hdr_244, 1)), v_t_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return (g_heff_2esyntax_2efmt_2elayout_2efmtLexed(v_f_240, v_src_241, v_hdr_244, v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(a[0], a[1]);
}