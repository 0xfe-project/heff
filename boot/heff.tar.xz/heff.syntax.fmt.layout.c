// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkChain 10459
#define TAG_MkDAlts 45152
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_ops 319788
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__text[] = {LBL_imports, LBL_text};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2ereadGo(V, V, V);
V g_heff_2esyntax_2efmt_2eimports_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2echain(V);
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V, V);
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo;
V g_heff_2esyntax_2efmt_2elex_2eblockScan(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2eblockScan_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eblockScan_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_heff_2esyntax_2efmt_2etoks_2eattach(V, V, V);
V g_heff_2esyntax_2efmt_2etoks_2eattach_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etoks_2eattach_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1221903513x233153387(V);
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s422923909x1655406376(V);
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s650596433x61515523(V, V);
V g_std_2edoc_2econcatWith_24s650596433x61515523_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s650596433x61515523_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0, 1, "\002");

static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st)) return g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2enewlineMark_val, &g_heff_2esyntax_2efmt_2elayout_2enewlineMark_st, g_heff_2esyntax_2efmt_2elayout_2enewlineMark_init);
}
Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_e_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_e_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(32LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      V v_t_245 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
      if (heff_intEq_c(v_t_245, MK_INT(9LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_e_241 = t_1;
        goto top;
      } else {
        V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
        if (heff_intEq_c(v_t_247, MK_INT(13LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_e_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          return v_e_241;
        }
      }
    }
  } else {
    heff_drop(v_s_240);
    return v_e_241;
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0, 0, "");

static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankLine_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_241;
  if (heff_strEq_c(heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankLine_str0))) {
    v_t_241 = NTAG(TAG_None);
  } else {
    v_t_241 = heff_tag_n(TAG_Text, 1, (V[]){heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get())});
  }
  return (g_std_2edoc_2e_3c_3e(v_t_241, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankLine_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankLine_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankLine_val, &g_heff_2esyntax_2efmt_2elayout_2eblankLine_st, g_heff_2esyntax_2efmt_2elayout_2eblankLine_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V v_env_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_get_n(v_t_241, 7, 9); V b_1 = heff_get_n(v_env_240, 3, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_c_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_x2_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str0), v_c_243, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_s_247 = ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_s_247 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_s_247), ((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str2))) {
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      heff_drop(v_s_247);
      v_t_249 = NTAG(TAG_None);
    } else {
      v_t_249 = heff_tag_at_n(v_ru_24t_242_24Just, TAG_Text, 1, (V[]){v_s_247});
    }
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_dup(g_std_2edoc_2ehardline_get())));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etrailOf_str3)}), v_t_2410);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_245;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_245 = NTAG(TAG_Nil);
  } else {
    V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_x1_245 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_x1_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
  }
  V v_t_2414;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_2411;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2411 = NTAG(TAG_Nil);
    } else {
      V v_x2_249 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
    }
    V v_ds_2412 = (g_list_2emap_24s1221903513x233153387(v_t_2411));
    V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2412; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x2_2415 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 2)));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_ds_2418 = (g_list_2emap_24s422923909x1655406376(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2418); r_; });
  V v_s_2420 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2422;
  if (heff_strEq_c(heff_dup(v_s_2420), ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0))) {
    heff_drop(v_s_2420);
    v_t_2422 = NTAG(TAG_None);
  } else {
    v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2420});
  }
  V v_t_2424;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2424 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2424));
  V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2425));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2426);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_x2_247 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0), heff_dup(heff_rfield(v_c_242, 0)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_s_2410 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_s_2410 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2412;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2))) {
      heff_drop(v_s_2410);
      v_t_2412 = NTAG(TAG_None);
    } else {
      v_t_2412 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2410});
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2415);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitem_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243) {
top: ;
  V v_x2_244 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_x1_2410;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    v_x1_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    v_x1_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_x1_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x1_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2410, 0ULL, 2);
    v_x1_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_True: {
    v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_False: {
    V v_t_2414 = heff_dup(heff_rfield(v_first_241, 8));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2416 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_get_n(v_first_241, 7, 9), heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 6))});
  V v_t_2417 = heff_tr(heff_call(v_body_243, 1, (V[]){v_t_2416}));
  V v_t_2419;
  if (heff_intEq_c(heff_dup(heff_rfield(v_last2_242, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_last2_242, 9);
    v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_last2_242));
  }
  V v_d_2420 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2419));
  V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2415, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2420})));
  return (g_std_2edoc_2e_3c_3e(v_t_247, v_t_2421));
}
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eitem(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2462 = heff_field(v_e_240, 3);
    V t_0 = v_body_2462;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2427 = heff_field(v_e_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2427, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esameOp_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241) {
top: ;
  switch (heff_tag_of(v_other_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_op_240, 9);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_other1_242 = heff_field(v_other_241, 0);
    switch (heff_tag_of(v_other1_242)) {
    case TAG_Atom: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      V v_op2_2448 = heff_field(v_other1_242, 0);
      return heff_strEq(heff_dup(heff_rfield(v_op2_2448, 1)), heff_get_n(v_op_240, 1, 9));
    }
    case TAG_Ann: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ESBind: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_op_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_other1_242);
    }
  }
  default: return heff_nomatch(v_other_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2esameOp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2echain_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2echain(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EParen: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Named: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Tup: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Braces: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_InstB: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFDefault: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Sum: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECon: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EField: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_App: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Op: {
    V v_a_2440 = heff_field(v_e_240, 0);
    V v_op_2441 = heff_field(v_e_240, 1);
    V v_b_2442 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x4_2443 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_dup(v_b_2442)));
    switch (heff_tag_of(v_x4_2443)) {
    case TAG_MkChain: {
      V v_bf_2444 = heff_field(v_x4_2443, 0);
      V v_rest_2445 = heff_field(v_x4_2443, 1);
      V v_ru_24x4_2443_24MkChain = heff_take_reuse_n(v_x4_2443, 3ULL, 2);
      V v_t_2446 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2441), v_rest_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_True: {
        heff_drop(v_b_2442);
        V v_t_2447 = heff_tag_at_n(v_ru_24x4_2443_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2441, v_bf_2444}), v_rest_2445});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2440, v_t_2447});
      }
      case TAG_False: {
        heff_drop(v_bf_2444);
        heff_drop(v_rest_2445);
        V v_t_2448 = heff_tag_at_n(v_ru_24x4_2443_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2441, v_b_2442}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2440, v_t_2448});
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_x4_2443);
    }
  }
  case TAG_Ops: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_OpRhs: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Ann: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BVar: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BImp: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BAnn: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Lam: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Case: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAlt: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_If: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Do: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ESBind: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2echain(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2447 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2447, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      v_t_2412 = v_commas_243;
      break;
    }
    case TAG_False: {
      v_t_2412 = (g_list_2edrop(MK_INT(1LL), v_commas_243));
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epP_str6, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_ds_247 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_args_243)));
    V v_t_248 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_247; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_247); r_; });
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_244, v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_249));
  }
  case TAG_PParen: {
    V v_o_2410 = heff_field(v_x2_241, 0);
    V v_p_2411 = heff_field(v_x2_241, 1);
    V v_c_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2410)));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2411));
    V v_t_2415 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2412)));
    V v_t_2416 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2415));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2416);
  }
  case TAG_PList: {
    V v_o_2417 = heff_field(v_x2_241, 0);
    V v_ps_2418 = heff_field(v_x2_241, 1);
    V v_commas_2419 = heff_field(v_x2_241, 2);
    V v_c_2420 = heff_field(v_x2_241, 3);
    V v_t_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2417)));
    V v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2418, heff_dup(v_commas_2419), NTAG(TAG_True)));
    V v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2420)));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2423, v_t_2424));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2421, v_t_2425);
  }
  case TAG_POp: {
    V v_l_2426 = heff_field(v_x2_241, 0);
    V v_op_2427 = heff_field(v_x2_241, 1);
    V v_r_2428 = heff_field(v_x2_241, 2);
    V v_a_2429 = (g_heff_2esyntax_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2426));
    V v_a_2430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2427)));
    V v_b_2431 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_r_2428));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str1)}), v_b_2431));
    V v_b_2433 = (g_std_2edoc_2e_3c_3e(v_a_2430, v_t_2432));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str2)}), v_b_2433));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2434);
  }
  case TAG_PRec: {
    V v_o_2435 = heff_field(v_x2_241, 0);
    V v_fs_2436 = heff_field(v_x2_241, 1);
    V v_commas_2437 = heff_field(v_x2_241, 2);
    V v_c_2438 = heff_field(v_x2_241, 3);
    V v_a_2439 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2435)));
    V v_a_2441 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2436, heff_dup(v_commas_2437), NTAG(TAG_True)));
    V v_b_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2438)));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str3)}), v_b_2442));
    V v_b_2444 = (g_std_2edoc_2e_3c_3e(v_a_2441, v_t_2443));
    V v_t_2445 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str4)}), v_b_2444));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2439, v_t_2445);
  }
  case TAG_PField: {
    V v_x_2446 = heff_field(v_x2_241, 0);
    V v_eq_2447 = heff_field(v_x2_241, 1);
    V v_p_2448 = heff_field(v_x2_241, 2);
    V v_a_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2446)));
    V v_a_2450 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2447)));
    V v_b_2451 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2448));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str5)}), v_b_2451));
    V v_b_2453 = (g_std_2edoc_2e_3c_3e(v_a_2450, v_t_2452));
    V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str6)}), v_b_2453));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2454);
  }
  case TAG_PAs: {
    V v_x_2455 = heff_field(v_x2_241, 0);
    V v_at_2456 = heff_field(v_x2_241, 1);
    V v_p_2457 = heff_field(v_x2_241, 2);
    V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2455)));
    V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2456)));
    V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2epP(v_env_240, v_p_2457));
    V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2459, v_t_2460));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2461);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2422 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2422; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2422); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2440 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2440; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2440); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRhs: {
      V v_op_2448 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0, 1, 1, (V[]){heff_dup(v_op_2448)}), heff_rfield(v_f_240, 0)));
      switch (heff_tag_of(v_t_2452)) {
      case TAG_Nothing: {
        heff_drop_rec(v_f_240, 2);
        heff_drop(v_rs_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_rec(v_op_2448, 9);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ru_24t_2452_24Just = heff_take_reuse_n(v_t_2452, 0ULL, 1);
        V v_x2_2454 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(v_f_240, v_rs_243));
        switch (heff_tag_of(v_x2_2454)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2448, 9);
          heff_drop_cell(v_ru_24t_2452_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_ops_2455 = heff_field(v_x2_2454, 0);
          heff_take_n(v_x2_2454, 1ULL, 1);
          V v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2448, 1, 9), v_ops_2455});
          return heff_tag_at_n(v_ru_24t_2452_24Just, TAG_Just, 1, (V[]){v_t_2456});
        }
        default: return heff_nomatch(v_x2_2454);
        }
      }
      default: return heff_nomatch(v_t_2452);
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eopsOf(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args) {
  V v_g_2450 = args[0];
  V v_op_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_op_2448, 1, 9)}));
  return ({ V a_0 = v_t_2451; V b_1 = heff_get_n(v_g_2450, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2447 = heff_field(v_r_242, 0);
    V v_t_2449 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2447, 1))));
    switch (heff_tag_of(v_t_2449)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2449, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2449, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2449);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2413;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        v_t_2412 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        heff_drop_rec(v_t_246, 9);
        v_t_2412 = heff_get_n(v_x_2410, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2416;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2413;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        v_t_2412 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        heff_drop_rec(v_t_246, 9);
        v_t_2412 = heff_get_n(v_x_2410, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2416;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam81_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam16_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam17_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam18_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam74_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam75_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam76_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam77_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam78_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam81_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam82_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c(heff_dup(v_i_2411), MK_INT(0LL))) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_d_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2456 = heff_intSub(v_k_2454, v_i_2455);
  if (heff_intEq_c(heff_dup(v_i_2456), MK_INT(0LL))) {
    heff_drop(v_i_2456);
    return v_d_2453;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2456, v_d_2453});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2454 = args[0];
  V v_d_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2454, v_d_2453})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_comma_2470 = args[0];
  V v_f_2471 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2470));
  V v_d_2473 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2471}));
  V v_t_2474 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2473})));
  V v_t_2475 = (g_std_2edoc_2e_3c_3e(v_a_2472, v_t_2474));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2475));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_i_2483 = args[0];
  V v_k_2482 = heff_env(self)[0];
  V v_d_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2484 = heff_intSub(v_k_2482, v_i_2483);
  if (heff_intEq_c(heff_dup(v_i_2484), MK_INT(0LL))) {
    heff_drop(v_i_2484);
    return v_d_2481;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2484, v_d_2481});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_k_2482 = args[0];
  V v_d_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 2, (V[]){v_k_2482, v_d_2481})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_bar_24133 = args[0];
  V v_a_24134 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24135 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24133));
  V v_b_24136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24134}));
  V v_t_24137 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), v_b_24136));
  V v_t_24138 = (g_std_2edoc_2e_3c_3e(v_a_24135, v_t_24137));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24138));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_i_24146 = args[0];
  V v_k_24145 = heff_env(self)[0];
  V v_d_24144 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24147 = heff_intSub(v_k_24145, v_i_24146);
  if (heff_intEq_c(heff_dup(v_i_24147), MK_INT(0LL))) {
    heff_drop(v_i_24147);
    return v_d_24144;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24147, v_d_24144});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_k_24145 = args[0];
  V v_d_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 2, (V[]){v_k_24145, v_d_24144})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_a_24154 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24154}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_t_24155));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_r_24171 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24169 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24169, v_r_24171}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24172));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24286 = args[0];
  V v_k_24285 = heff_env(self)[0];
  V v_d_24284 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24287 = heff_intSub(v_k_24285, v_i_24286);
  if (heff_intEq_c(heff_dup(v_i_24287), MK_INT(0LL))) {
    heff_drop(v_i_24287);
    return v_d_24284;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24287, v_d_24284});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24285 = args[0];
  V v_d_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24285, v_d_24284})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_b_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_b_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_ds_2446 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2431, v_more_2436));
      V v_t_2447 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2446; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2446); r_; });
      V v_t_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2449 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2448));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2447, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2451));
      V v_d_2453 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2452));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2453})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Braces: {
    V v_o_2458 = heff_field(v_e0_241, 0);
    V v_fs_2459 = heff_field(v_e0_241, 1);
    V v_commas_2460 = heff_field(v_e0_241, 2);
    V v_c_2461 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2459)) {
    case TAG_Nil: {
      heff_drop(v_commas_2460);
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    }
    case TAG_Cons: {
      V v_f1_2464 = heff_field(v_fs_2459, 0);
      V v_more_2465 = heff_field(v_fs_2459, 1);
      V v_ru_24fs_2459_24Cons = heff_take_reuse_n(v_fs_2459, 3ULL, 2);
      V v_a_2466 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_d_2467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2464}));
      V v_t_2468 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2459_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2467})));
      V v_t_2469 = (g_std_2edoc_2e_3c_3e(v_a_2466, v_t_2468));
      V v_ds_2476 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2460, v_more_2465));
      V v_t_2477 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2476; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2476); r_; });
      V v_t_2478 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      V v_t_2479 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2478));
      V v_t_2480 = (g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2479));
      V v_d_2481 = (g_std_2edoc_2e_3c_3e(v_t_2469, v_t_2480));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 1, 1, (V[]){v_d_2481})})));
    }
    default: return heff_nomatch(v_fs_2459);
    }
  }
  case TAG_InstB: {
    V v_o_2486 = heff_field(v_e0_241, 0);
    V v_o2_2487 = heff_field(v_e0_241, 1);
    V v_d_2488 = heff_field(v_e0_241, 2);
    V v_c1_2489 = heff_field(v_e0_241, 3);
    V v_c_2490 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2486));
    V v_t_2492 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_2487));
    V v_t_2493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_2488}));
    V v_t_2494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_2489));
    V v_t_2495 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2490));
    V v_t_2496 = (g_std_2edoc_2e_3c_3e(v_t_2494, v_t_2495));
    V v_t_2497 = (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_2496));
    V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2492, v_t_2497));
    return (g_std_2edoc_2e_3c_3e(v_t_2491, v_t_2498));
  }
  case TAG_EFSet: {
    V v_x_2499 = heff_field(v_e0_241, 0);
    V v_eq_24100 = heff_field(v_e0_241, 1);
    V v_e_24101 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24102 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2499));
    V v_b_24103 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24100));
    V v_t_24104 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24103));
    V v_t_24105 = (g_std_2edoc_2e_3c_3e(v_a_24102, v_t_24104));
    V v_t_24106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24101}));
    return (g_std_2edoc_2e_3c_3e(v_t_24105, v_t_24106));
  }
  case TAG_EFDefault: {
    V v_d_24107 = heff_field(v_e0_241, 0);
    V v_eq_24108 = heff_field(v_e0_241, 1);
    V v_e_24109 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24107}));
    V v_b_24111 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24108));
    V v_t_24112 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_b_24111));
    V v_t_24113 = (g_std_2edoc_2e_3c_3e(v_a_24110, v_t_24112));
    V v_t_24114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24109}));
    return (g_std_2edoc_2e_3c_3e(v_t_24113, v_t_24114));
  }
  case TAG_Sum: {
    V v_kw_24115 = heff_field(v_e0_241, 0);
    V v_o_24116 = heff_field(v_e0_241, 1);
    V v_alts_24117 = heff_field(v_e0_241, 2);
    V v_bars_24118 = heff_field(v_e0_241, 3);
    V v_c_24119 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24117)) {
    case TAG_Nil: {
      heff_drop(v_bars_24118);
      V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24115));
      V v_a_24121 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24116));
      V v_b_24122 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24119));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_b_24122));
      V v_b_24124 = (g_std_2edoc_2e_3c_3e(v_a_24121, v_t_24123));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), v_b_24124));
      return (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24125));
    }
    case TAG_Cons: {
      V v_a1_24126 = heff_field(v_alts_24117, 0);
      V v_more_24127 = heff_field(v_alts_24117, 1);
      heff_take_n(v_alts_24117, 3ULL, 2);
      V v_a_24128 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24115));
      V v_a_24129 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24116));
      V v_b_24130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24126}));
      V v_t_24131 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), v_b_24130));
      V v_t_24132 = (g_std_2edoc_2e_3c_3e(v_a_24129, v_t_24131));
      V v_ds_24139 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 2, 1, (V[]){heff_dup(v_env_240)}), v_bars_24118, v_more_24127));
      V v_a_24140 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24139; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24139); r_; });
      V v_b_24141 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24119));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_a_24140, v_t_24142));
      V v_d_24144 = (g_std_2edoc_2e_3c_3e(v_t_24132, v_t_24143));
      V v_b_24149 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 1, 1, (V[]){v_d_24144})})));
      V v_t_24150 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24149));
      return (g_std_2edoc_2e_3c_3e(v_a_24128, v_t_24150));
    }
    default: return heff_nomatch(v_alts_24117);
    }
  }
  case TAG_ECon: {
    V v_c_24151 = heff_field(v_e0_241, 0);
    V v_args_24152 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24153 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24151));
    V v_ds_24156 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 1, (V[]){v_env_240}), v_args_24152));
    V v_t_24157 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24156; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24156); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24153, v_t_24157));
  }
  case TAG_EField: {
    V v_e_24158 = heff_field(v_e0_241, 0);
    V v_f_24159 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24160 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24158}));
    V v_t_24161 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24159));
    return (g_std_2edoc_2e_3c_3e(v_t_24160, v_t_24161));
  }
  case TAG_App: {
    V v_h_24162 = heff_field(v_e0_241, 0);
    V v_args_24163 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24162;
    heff_room[2] = v_args_24163;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24164 = heff_field(v_e0_241, 0);
    V v_op_24165 = heff_field(v_e0_241, 1);
    V v_b_24166 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24164, v_op_24165, v_b_24166})));
    switch (heff_tag_of(v_t_24167)) {
    case TAG_MkChain: {
      V v_first_24168 = heff_field(v_t_24167, 0);
      V v_rest_24169 = heff_field(v_t_24167, 1);
      heff_take_n(v_t_24167, 3ULL, 2);
      V v_t_24170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24169), v_first_24168}));
      V v_ds_24173 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24169)}), v_rest_24169));
      V v_t_24174 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24173; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24173); r_; });
      V v_t_24175 = (g_std_2edoc_2e_3c_3e(v_t_24170, v_t_24174));
      return (g_std_2edoc_2egroup(v_t_24175));
    }
    default: return heff_nomatch(v_t_24167);
    }
  }
  case TAG_Ops: {
    V v_a_24176 = heff_field(v_e0_241, 0);
    V v_rest_24177 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24176;
    heff_room[2] = v_rest_24177;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24178 = heff_field(v_e0_241, 0);
    V v_e_24179 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24180 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24178));
    V v_b_24181 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24179}));
    V v_t_24182 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24181));
    return (g_std_2edoc_2e_3c_3e(v_a_24180, v_t_24182));
  }
  case TAG_Ann: {
    V v_e_24183 = heff_field(v_e0_241, 0);
    V v_cc_24184 = heff_field(v_e0_241, 1);
    V v_ty_24185 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24183}));
    V v_b_24187 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24184));
    V v_t_24188 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_b_24187));
    V v_t_24189 = (g_std_2edoc_2e_3c_3e(v_a_24186, v_t_24188));
    V v_t_24190 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24185}));
    V v_d_24191 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24190));
    V v_t_24192 = (g_std_2edoc_2e_3c_3e(v_t_24189, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24191})));
    return (g_std_2edoc_2egroup(v_t_24192));
  }
  case TAG_BVar: {
    V v_t_24193 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24193));
  }
  case TAG_BImp: {
    V v_o_24194 = heff_field(v_e0_241, 0);
    V v_x_24195 = heff_field(v_e0_241, 1);
    V v_c_24196 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24197 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24194));
    V v_t_24198 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24195));
    V v_t_24199 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24196));
    V v_t_24200 = (g_std_2edoc_2e_3c_3e(v_t_24198, v_t_24199));
    return (g_std_2edoc_2e_3c_3e(v_t_24197, v_t_24200));
  }
  case TAG_BAnn: {
    V v_o_24201 = heff_field(v_e0_241, 0);
    V v_x_24202 = heff_field(v_e0_241, 1);
    V v_cc_24203 = heff_field(v_e0_241, 2);
    V v_ty_24204 = heff_field(v_e0_241, 3);
    V v_c_24205 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24206 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24201));
    V v_a_24207 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24202));
    V v_a_24208 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24203));
    V v_b_24209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24204}));
    V v_t_24210 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24209));
    V v_b_24211 = (g_std_2edoc_2e_3c_3e(v_a_24208, v_t_24210));
    V v_t_24212 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24211));
    V v_t_24213 = (g_std_2edoc_2e_3c_3e(v_a_24207, v_t_24212));
    V v_t_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24205));
    V v_t_24215 = (g_std_2edoc_2e_3c_3e(v_t_24213, v_t_24214));
    return (g_std_2edoc_2e_3c_3e(v_t_24206, v_t_24215));
  }
  case TAG_Lam: {
    V v_bs_24216 = heff_field(v_e0_241, 0);
    V v_binders_24217 = heff_field(v_e0_241, 1);
    V v_arrow_24218 = heff_field(v_e0_241, 2);
    V v_body_24219 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24220 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24216));
    V v_t_24221 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24222 = (g_list_2emap(v_t_24221, v_binders_24217));
    V v_a_24223 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19); V a_1 = v_t_24222; V r_ = (g_std_2edoc_2econcatWith_24s650596433x61515523(a_0, a_1)); heff_drop(v_t_24222); r_; });
    V v_b_24224 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24218));
    V v_t_24225 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24224));
    V v_t_24226 = (g_std_2edoc_2e_3c_3e(v_a_24223, v_t_24225));
    V v_t_24227 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24219));
    V v_t_24231;
    switch (heff_tag_of(v_t_24227)) {
    case TAG_True: {
      V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24219}));
      v_t_24231 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
      break;
    }
    case TAG_False: {
      V v_t_24229 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24219}));
      V v_d_24230 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24229));
      v_t_24231 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24230})));
      break;
    }
    default: heff_nomatch(v_t_24227);
    }
    V v_t_24232 = (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24220, v_t_24232));
  }
  case TAG_Case: {
    V v_kw_24233 = heff_field(v_e0_241, 0);
    V v_scrut_24234 = heff_field(v_e0_241, 1);
    V v_of2_24235 = heff_field(v_e0_241, 2);
    V v_alts_24236 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24237 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24233));
    V v_a_24238 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24234}));
    V v_b_24239 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24235));
    V v_t_24240 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24239));
    V v_b_24241 = (g_std_2edoc_2e_3c_3e(v_a_24238, v_t_24240));
    V v_t_24242 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24241));
    V v_t_24243 = (g_std_2edoc_2e_3c_3e(v_a_24237, v_t_24242));
    V v_t_24244 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24236; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1570132017x1805276086(a_0, a_1, a_2)); heff_drop(v_alts_24236); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24243, v_t_24244));
  }
  case TAG_EAlt: {
    V v_p_24245 = heff_field(v_e0_241, 0);
    V v_arrow_24246 = heff_field(v_e0_241, 1);
    V v_body_24247 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24248 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24245); r_; });
    V v_b_24249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24246));
    V v_t_24250 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24249));
    V v_t_24251 = (g_std_2edoc_2e_3c_3e(v_a_24248, v_t_24250));
    V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24247}));
    return (g_std_2edoc_2e_3c_3e(v_t_24251, v_t_24252));
  }
  case TAG_If: {
    V v_kw_24253 = heff_field(v_e0_241, 0);
    V v_c_24254 = heff_field(v_e0_241, 1);
    V v_th_24255 = heff_field(v_e0_241, 2);
    V v_a_24256 = heff_field(v_e0_241, 3);
    V v_el_24257 = heff_field(v_e0_241, 4);
    V v_b_24258 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24253, v_c_24254, v_th_24255, v_a_24256}));
    V v_t_24260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24257, v_b_24258}));
    V v_t_24261 = (g_std_2edoc_2e_3c_3e(v_t_24259, v_t_24260));
    return (g_std_2edoc_2egroup(v_t_24261));
  }
  case TAG_Do: {
    V v_kw_24262 = heff_field(v_e0_241, 0);
    V v_stmts_24263 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24264 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24262));
    V v_t_24265 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24263; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1070529086x1255773855(a_0, a_1, a_2)); heff_drop(v_stmts_24263); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24264, v_t_24265));
  }
  case TAG_ESBind: {
    V v_x_24266 = heff_field(v_e0_241, 0);
    V v_arrow_24267 = heff_field(v_e0_241, 1);
    V v_e_24268 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24269 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24266));
    V v_b_24270 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24267));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_b_24270));
    V v_t_24272 = (g_std_2edoc_2e_3c_3e(v_a_24269, v_t_24271));
    V v_t_24273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24268}));
    return (g_std_2edoc_2e_3c_3e(v_t_24272, v_t_24273));
  }
  case TAG_ELet: {
    V v_kw_24274 = heff_field(v_e0_241, 0);
    V v_p_24275 = heff_field(v_e0_241, 1);
    V v_ann_24276 = heff_field(v_e0_241, 2);
    V v_eq_24277 = heff_field(v_e0_241, 3);
    V v_e_24278 = heff_field(v_e0_241, 4);
    V v_body_24279 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24279)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24274, v_p_24275, v_ann_24276, v_eq_24277, v_e_24278});
    }
    case TAG_Just: {
      V v_it1_24280 = heff_field(v_body_24279, 0);
      V v_ru_24body_24279_24Just = heff_take_reuse_n(v_body_24279, 1ULL, 1);
      switch (heff_tag_of(v_it1_24280)) {
      case TAG_MkPair: {
        V v_i_24281 = heff_field(v_it1_24280, 0);
        V v_b_24282 = heff_field(v_it1_24280, 1);
        heff_take_n(v_it1_24280, 3ULL, 2);
        V v_t_24283 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24274, v_p_24275, v_ann_24276, v_eq_24277, v_e_24278, v_i_24281, v_b_24282}));
        V v_d_24284 = (g_std_2edoc_2egroup(v_t_24283));
        return heff_tag_at_n(v_ru_24body_24279_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24284})});
      }
      default: return heff_nomatch(v_it1_24280);
      }
    }
    default: return heff_nomatch(v_body_24279);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_env_24289 = args[0];
  V v_e_24290 = args[1];
  V v_t_24291 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24290));
  switch (heff_tag_of(v_t_24291)) {
  case TAG_True: {
    V v_t_24292 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24289, v_e_24290}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26)}), v_t_24292));
  }
  case TAG_False: {
    V v_t_24293 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24289, v_e_24290}));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24293));
    return (g_std_2edoc_2egroup(v_t_24294));
  }
  default: return heff_nomatch(v_t_24291);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_env_24295 = args[0];
  V v_kw_24296 = args[1];
  V v_p_24297 = args[2];
  V v_ann_24298 = args[3];
  V v_eq_24299 = args[4];
  V v_e_24300 = args[5];
  V v_a_24301 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24295), v_kw_24296));
  V v_b_24302 = ({ V a_0 = heff_dup(v_env_24295); V a_1 = v_p_24297; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24297); r_; });
  V v_t_24303 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24302));
  V v_t_24304 = (g_std_2edoc_2e_3c_3e(v_a_24301, v_t_24303));
  V v_a_24312;
  switch (heff_tag_of(v_ann_24298)) {
  case TAG_Nothing: {
    v_a_24312 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24305 = heff_field(v_ann_24298, 0);
    V v_ru_24ann_24298_24Just = heff_take_reuse_n(v_ann_24298, 1ULL, 1);
    switch (heff_tag_of(v_it1_24305)) {
    case TAG_MkPair: {
      V v_cc_24306 = heff_field(v_it1_24305, 0);
      V v_ty_24307 = heff_field(v_it1_24305, 1);
      heff_take_n(v_it1_24305, 3ULL, 2);
      V v_a_24308 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24295), v_cc_24306));
      V v_b_24309 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24295), v_ty_24307}));
      V v_t_24310 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24298_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_b_24309));
      V v_t_24311 = (g_std_2edoc_2e_3c_3e(v_a_24308, v_t_24310));
      v_a_24312 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_t_24311));
      break;
    }
    default: heff_nomatch(v_it1_24305);
    }
    break;
  }
  default: heff_nomatch(v_ann_24298);
  }
  V v_b_24313 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24295), v_eq_24299));
  V v_t_24314 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_b_24313));
  V v_t_24315 = (g_std_2edoc_2e_3c_3e(v_a_24312, v_t_24314));
  V v_t_24316 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24295, v_e_24300}));
  V v_t_24317 = (g_std_2edoc_2e_3c_3e(v_t_24315, v_t_24316));
  return (g_std_2edoc_2e_3c_3e(v_t_24304, v_t_24317));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_env_24318 = args[0];
  V v_kw_24319 = args[1];
  V v_p_24320 = args[2];
  V v_ann_24321 = args[3];
  V v_eq_24322 = args[4];
  V v_e_24323 = args[5];
  V v_i_24324 = args[6];
  V v_b_24325 = args[7];
  V v_d_24326 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24318), v_kw_24319, v_p_24320, v_ann_24321, v_eq_24322, v_e_24323}));
  V v_a_24327 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24318), v_i_24324));
  V v_b_24417;
  switch (heff_tag_of(v_b_24325)) {
  case TAG_Atom: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_EParen: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Named: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Tup: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Braces: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_InstB: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_EFSet: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Sum: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_ECon: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_EField: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_App: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Op: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Ops: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Ann: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_BVar: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_BImp: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_BAnn: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Lam: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Case: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_EAlt: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_If: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_Do: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_ESBind: {
    v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24408 = heff_dup(heff_field(v_b_24325, 0));
    V v_p2_24409 = heff_dup(heff_field(v_b_24325, 1));
    V v_ann2_24410 = heff_dup(heff_field(v_b_24325, 2));
    V v_eq2_24411 = heff_dup(heff_field(v_b_24325, 3));
    V v_e2_24412 = heff_dup(heff_field(v_b_24325, 4));
    V v_it6_24413 = heff_dup(heff_field(v_b_24325, 5));
    switch (heff_tag_of(v_it6_24413)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24408);
      heff_drop(v_p2_24409);
      heff_drop(v_ann2_24410);
      heff_drop(v_eq2_24411);
      heff_drop(v_e2_24412);
      v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24318, v_b_24325}));
      break;
    }
    case TAG_Just: {
      V v_it61_24414 = heff_field(v_it6_24413, 0);
      heff_take_n(v_it6_24413, 1ULL, 1);
      heff_drop_tag(v_b_24325, 6);
      switch (heff_tag_of(v_it61_24414)) {
      case TAG_MkPair: {
        V v_i2_24415 = heff_field(v_it61_24414, 0);
        V v_b2_24416 = heff_field(v_it61_24414, 1);
        heff_take_n(v_it61_24414, 3ULL, 2);
        v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24318, v_kw2_24408, v_p2_24409, v_ann2_24410, v_eq2_24411, v_e2_24412, v_i2_24415, v_b2_24416}));
        break;
      }
      default: heff_nomatch(v_it61_24414);
      }
      break;
    }
    default: heff_nomatch(v_it6_24413);
    }
    break;
  }
  default: heff_nomatch(v_b_24325);
  }
  V v_t_24418 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24417));
  V v_t_24419 = (g_std_2edoc_2e_3c_3e(v_a_24327, v_t_24418));
  V v_t_24420 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24419));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24326}), v_t_24420));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_env_24421 = args[0];
  V v_kw_24422 = args[1];
  V v_c_24423 = args[2];
  V v_th_24424 = args[3];
  V v_a_24425 = args[4];
  V v_a_24426 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24421), v_kw_24422));
  V v_b_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24421), v_c_24423}));
  V v_t_24428 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24427));
  V v_t_24429 = (g_std_2edoc_2e_3c_3e(v_a_24426, v_t_24428));
  V v_a_24430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24421), v_th_24424));
  V v_d_24431 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24421, v_a_24425}));
  V v_t_24432 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24431})));
  V v_t_24433 = (g_std_2edoc_2e_3c_3e(v_a_24430, v_t_24432));
  V v_d_24434 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24433));
  V v_t_24435 = (g_std_2edoc_2e_3c_3e(v_t_24429, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24434})));
  return (g_std_2edoc_2egroup(v_t_24435));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24436 = args[0];
  V v_el_24437 = args[1];
  V v_b_24438 = args[2];
  switch (heff_tag_of(v_b_24438)) {
  case TAG_Atom: {
    V v_a_24440 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24441 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24442 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24441})));
    V v_t_24443 = (g_std_2edoc_2e_3c_3e(v_a_24440, v_t_24442));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24443));
  }
  case TAG_EParen: {
    V v_a_24447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24449 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24448})));
    V v_t_24450 = (g_std_2edoc_2e_3c_3e(v_a_24447, v_t_24449));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24450));
  }
  case TAG_Named: {
    V v_a_24456 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24457})));
    V v_t_24459 = (g_std_2edoc_2e_3c_3e(v_a_24456, v_t_24458));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24459));
  }
  case TAG_Tup: {
    V v_a_24464 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24465 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24466 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24465})));
    V v_t_24467 = (g_std_2edoc_2e_3c_3e(v_a_24464, v_t_24466));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24467));
  }
  case TAG_Braces: {
    V v_a_24472 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24473 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24474 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24473})));
    V v_t_24475 = (g_std_2edoc_2e_3c_3e(v_a_24472, v_t_24474));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24475));
  }
  case TAG_InstB: {
    V v_a_24481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24483 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24482})));
    V v_t_24484 = (g_std_2edoc_2e_3c_3e(v_a_24481, v_t_24483));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24484));
  }
  case TAG_EFSet: {
    V v_a_24488 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24489 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24490 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24489})));
    V v_t_24491 = (g_std_2edoc_2e_3c_3e(v_a_24488, v_t_24490));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24491));
  }
  case TAG_EFDefault: {
    V v_a_24495 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24496 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24497 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24496})));
    V v_t_24498 = (g_std_2edoc_2e_3c_3e(v_a_24495, v_t_24497));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24498));
  }
  case TAG_Sum: {
    V v_a_24504 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24506 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24505})));
    V v_t_24507 = (g_std_2edoc_2e_3c_3e(v_a_24504, v_t_24506));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24507));
  }
  case TAG_ECon: {
    V v_a_24510 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24511 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24512 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24511})));
    V v_t_24513 = (g_std_2edoc_2e_3c_3e(v_a_24510, v_t_24512));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24513));
  }
  case TAG_EField: {
    V v_a_24516 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24517 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24518 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24517})));
    V v_t_24519 = (g_std_2edoc_2e_3c_3e(v_a_24516, v_t_24518));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24519));
  }
  case TAG_App: {
    V v_a_24522 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24523 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24524 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24523})));
    V v_t_24525 = (g_std_2edoc_2e_3c_3e(v_a_24522, v_t_24524));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24525));
  }
  case TAG_Op: {
    V v_a_24529 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24530 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24531 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24530})));
    V v_t_24532 = (g_std_2edoc_2e_3c_3e(v_a_24529, v_t_24531));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24532));
  }
  case TAG_Ops: {
    V v_a_24535 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24536 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24537 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24536})));
    V v_t_24538 = (g_std_2edoc_2e_3c_3e(v_a_24535, v_t_24537));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24538));
  }
  case TAG_OpRhs: {
    V v_a_24541 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24542 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24543 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24542})));
    V v_t_24544 = (g_std_2edoc_2e_3c_3e(v_a_24541, v_t_24543));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24544));
  }
  case TAG_Ann: {
    V v_a_24548 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24549 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24549})));
    V v_t_24551 = (g_std_2edoc_2e_3c_3e(v_a_24548, v_t_24550));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24551));
  }
  case TAG_BVar: {
    V v_a_24553 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24554 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24555 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24554})));
    V v_t_24556 = (g_std_2edoc_2e_3c_3e(v_a_24553, v_t_24555));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24556));
  }
  case TAG_BImp: {
    V v_a_24560 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24561 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24562 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24561})));
    V v_t_24563 = (g_std_2edoc_2e_3c_3e(v_a_24560, v_t_24562));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24563));
  }
  case TAG_BAnn: {
    V v_a_24569 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24570 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24571 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24570})));
    V v_t_24572 = (g_std_2edoc_2e_3c_3e(v_a_24569, v_t_24571));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24572));
  }
  case TAG_Lam: {
    V v_a_24577 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24578 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24579 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24578})));
    V v_t_24580 = (g_std_2edoc_2e_3c_3e(v_a_24577, v_t_24579));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24580));
  }
  case TAG_Case: {
    V v_a_24585 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24586 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24587 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24586})));
    V v_t_24588 = (g_std_2edoc_2e_3c_3e(v_a_24585, v_t_24587));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24588));
  }
  case TAG_EAlt: {
    V v_a_24592 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24593 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24594 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24593})));
    V v_t_24595 = (g_std_2edoc_2e_3c_3e(v_a_24592, v_t_24594));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24595));
  }
  case TAG_If: {
    V v_kw_24596 = heff_field(v_b_24438, 0);
    V v_c_24597 = heff_field(v_b_24438, 1);
    V v_th_24598 = heff_field(v_b_24438, 2);
    V v_a_24599 = heff_field(v_b_24438, 3);
    V v_el2_24600 = heff_field(v_b_24438, 4);
    V v_b2_24601 = heff_field(v_b_24438, 5);
    heff_take_n(v_b_24438, 63ULL, 6);
    V v_a_24602 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_b_24603 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24436), v_kw_24596, v_c_24597, v_th_24598, v_a_24599}));
    V v_t_24604 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_b_24603));
    V v_t_24605 = (g_std_2edoc_2e_3c_3e(v_a_24602, v_t_24604));
    V v_t_24606 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24436, v_el2_24600, v_b2_24601}));
    V v_t_24607 = (g_std_2edoc_2e_3c_3e(v_t_24605, v_t_24606));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24607));
  }
  case TAG_Do: {
    V v_a_24610 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24611 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24612 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24611})));
    V v_t_24613 = (g_std_2edoc_2e_3c_3e(v_a_24610, v_t_24612));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24613));
  }
  case TAG_ESBind: {
    V v_a_24617 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24618 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24619 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24618})));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(v_a_24617, v_t_24619));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24620));
  }
  case TAG_ELet: {
    V v_a_24627 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24436), v_el_24437));
    V v_d_24628 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24436, v_b_24438}));
    V v_t_24629 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24628})));
    V v_t_24630 = (g_std_2edoc_2e_3c_3e(v_a_24627, v_t_24629));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24630));
  }
  default: return heff_nomatch(v_b_24438);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_a_24645 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24646 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24645}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24646));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_a_24654 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24655 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24654}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24655));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_a_24664 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24665 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24664}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24665));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_a_24677 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24677}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24678));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24689 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24690 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24689}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24690));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24698 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24699 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24698}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24699));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24709 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24710 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24709}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24710));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24718 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24719 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24718}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24719));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24729 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24730 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24729}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24730));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24738 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24739 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24738}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24739));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24750 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24751 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24750}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24751));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24759 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24760 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24759}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24760));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24769 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24770 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24769}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24770));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_24778 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24779 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24778}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24779));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_24788 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24789 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24788}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24789));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_24797 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24798 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24797}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24798));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_24809 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24810 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24809}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24810));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_24818 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24819 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24818}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24819));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_24827 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24828 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24827}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24828));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_24836 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24837 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24836}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24837));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_24845 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24846 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24845}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24846));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_24854 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24855 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24854}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24855));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_24863 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24864 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24863}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24864));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_24872 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24873 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24872}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24873));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_24882 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24883 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24882}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24883));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_24891 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24892 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24891}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24892));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_24900 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24901 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24900}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24901));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_24909 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24910 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24909}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24910));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_24918 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24919 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24918}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24919));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_24927 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24928 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24927}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24928));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_24937 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24938 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24937}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24938));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_24946 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24946}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24947));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_24954 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24955 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24954}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24955));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_24963 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24964 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24963}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24964));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_24973 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24973}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24974));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_24982 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24983 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24982}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24983));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_24994 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24995 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_24994}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24995));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241003 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241004 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241003}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241004));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241014 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241015 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241014}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241015));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241023 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241023}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241024));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241034 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241035 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241034}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241035));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241043 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241044 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241043}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241044));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241053 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241054 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241053}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241054));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241062 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241063 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241062}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241063));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241075 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241075}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241076));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241084 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241085 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241084}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241085));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241093 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241094 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241093}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241094));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241102 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241102}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241103));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241112 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241112}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241113));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241121 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241122 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241121}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241122));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241134 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241135 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241134}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241135));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241143 = args[0];
  V v_env_24631 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_a_241143}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241144));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24631 = args[0];
  V v_h_24632 = args[1];
  V v_args_24633 = args[2];
  V v_x1_24634 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24633)));
  V v_t_24638;
  switch (heff_tag_of(v_x1_24634)) {
  case TAG_Nil: {
    v_t_24638 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24635 = heff_field(v_x1_24634, 0);
    V v_rev_24636 = heff_field(v_x1_24634, 1);
    V v_ru_24x1_24634_24Cons = heff_take_reuse_n(v_x1_24634, 3ULL, 2);
    V v_t_24637 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24636));
    v_t_24638 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_24634_24Cons, TAG_MkPair, 2, (V[]){v_t_24637, v_x_24635})});
    break;
  }
  default: heff_nomatch(v_x1_24634);
  }
  switch (heff_tag_of(v_t_24638)) {
  case TAG_Nothing: {
    heff_drop(v_args_24633);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24631;
    args[1] = v_h_24632;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_24639 = heff_field(v_t_24638, 0);
    V v_ru_24t_24638_24Just = heff_take_reuse_n(v_t_24638, 1ULL, 1);
    switch (heff_tag_of(v_pr_24639)) {
    case TAG_MkPair: {
      V v_init2_24640 = heff_field(v_pr_24639, 0);
      V v_lastA_24641 = heff_field(v_pr_24639, 1);
      V v_ru_24pr_24639_24MkPair = heff_take_reuse_n(v_pr_24639, 3ULL, 2);
      switch (heff_tag_of(v_lastA_24641)) {
      case TAG_Atom: {
        V v_t_24643 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24643)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24644 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24647 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24648 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24647; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24647); r_; });
          V v_t_24649 = (g_std_2edoc_2e_3c_3e(v_t_24644, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24648})));
          V v_a_24650 = (g_std_2edoc_2egroup(v_t_24649));
          V v_b_24651 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24652 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_b_24651));
          return (g_std_2edoc_2e_3c_3e(v_a_24650, v_t_24652));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 1);
          V v_t_24653 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24656 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24657 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24656; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24656); r_; });
          V v_t_24658 = (g_std_2edoc_2e_3c_3e(v_t_24653, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24657})));
          return (g_std_2edoc_2egroup(v_t_24658));
        }
        default: return heff_nomatch(v_t_24643);
        }
      }
      case TAG_EParen: {
        V v_o_24659 = heff_field(v_lastA_24641, 0);
        V v_e_24660 = heff_field(v_lastA_24641, 1);
        V v_c_24661 = heff_field(v_lastA_24641, 2);
        heff_take_n(v_lastA_24641, 7ULL, 3);
        V v_t_24662 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24660));
        switch (heff_tag_of(v_t_24662)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24663 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24666 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24667 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24666; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24666); r_; });
          V v_t_24668 = (g_std_2edoc_2e_3c_3e(v_t_24663, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24667})));
          V v_a_24669 = (g_std_2edoc_2egroup(v_t_24668));
          V v_b_24670 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24631), v_o_24659));
          V v_t_24671 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24670));
          V v_t_24672 = (g_std_2edoc_2e_3c_3e(v_a_24669, v_t_24671));
          V v_t_24673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_e_24660}));
          V v_t_24674 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24631, v_c_24661));
          V v_t_24675 = (g_std_2edoc_2e_3c_3e(v_t_24673, v_t_24674));
          return (g_std_2edoc_2e_3c_3e(v_t_24672, v_t_24675));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop(v_o_24659);
          heff_drop(v_e_24660);
          heff_drop(v_c_24661);
          V v_t_24676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24679 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24680 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24679; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24679); r_; });
          V v_t_24681 = (g_std_2edoc_2e_3c_3e(v_t_24676, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24680})));
          return (g_std_2edoc_2egroup(v_t_24681));
        }
        default: return heff_nomatch(v_t_24662);
        }
      }
      case TAG_Named: {
        V v_t_24687 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24687)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24691 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24692 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24691; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24691); r_; });
          V v_t_24693 = (g_std_2edoc_2e_3c_3e(v_t_24688, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24692})));
          V v_a_24694 = (g_std_2edoc_2egroup(v_t_24693));
          V v_b_24695 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24696 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24695));
          return (g_std_2edoc_2e_3c_3e(v_a_24694, v_t_24696));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 5);
          V v_t_24697 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24700 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24701 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24700; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24700); r_; });
          V v_t_24702 = (g_std_2edoc_2e_3c_3e(v_t_24697, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24701})));
          return (g_std_2edoc_2egroup(v_t_24702));
        }
        default: return heff_nomatch(v_t_24687);
        }
      }
      case TAG_Tup: {
        V v_t_24707 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24707)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24708 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24711 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24712 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24711; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24711); r_; });
          V v_t_24713 = (g_std_2edoc_2e_3c_3e(v_t_24708, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24712})));
          V v_a_24714 = (g_std_2edoc_2egroup(v_t_24713));
          V v_b_24715 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24716 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), v_b_24715));
          return (g_std_2edoc_2e_3c_3e(v_a_24714, v_t_24716));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 4);
          V v_t_24717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24720 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24721 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24720; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24720); r_; });
          V v_t_24722 = (g_std_2edoc_2e_3c_3e(v_t_24717, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24721})));
          return (g_std_2edoc_2egroup(v_t_24722));
        }
        default: return heff_nomatch(v_t_24707);
        }
      }
      case TAG_Braces: {
        V v_t_24727 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24727)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24728 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24731 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24732 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24731; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24731); r_; });
          V v_t_24733 = (g_std_2edoc_2e_3c_3e(v_t_24728, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24732})));
          V v_a_24734 = (g_std_2edoc_2egroup(v_t_24733));
          V v_b_24735 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24736 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), v_b_24735));
          return (g_std_2edoc_2e_3c_3e(v_a_24734, v_t_24736));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 4);
          V v_t_24737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24740 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24741 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24740; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24740); r_; });
          V v_t_24742 = (g_std_2edoc_2e_3c_3e(v_t_24737, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24741})));
          return (g_std_2edoc_2egroup(v_t_24742));
        }
        default: return heff_nomatch(v_t_24727);
        }
      }
      case TAG_InstB: {
        V v_t_24748 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24748)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24752 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24753 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24752; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24752); r_; });
          V v_t_24754 = (g_std_2edoc_2e_3c_3e(v_t_24749, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24753})));
          V v_a_24755 = (g_std_2edoc_2egroup(v_t_24754));
          V v_b_24756 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24757 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), v_b_24756));
          return (g_std_2edoc_2e_3c_3e(v_a_24755, v_t_24757));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 5);
          V v_t_24758 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24761 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24762 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24761; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24761); r_; });
          V v_t_24763 = (g_std_2edoc_2e_3c_3e(v_t_24758, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24762})));
          return (g_std_2edoc_2egroup(v_t_24763));
        }
        default: return heff_nomatch(v_t_24748);
        }
      }
      case TAG_EFSet: {
        V v_t_24767 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24767)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24768 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24771 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24772 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24771; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24771); r_; });
          V v_t_24773 = (g_std_2edoc_2e_3c_3e(v_t_24768, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24772})));
          V v_a_24774 = (g_std_2edoc_2egroup(v_t_24773));
          V v_b_24775 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24776 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), v_b_24775));
          return (g_std_2edoc_2e_3c_3e(v_a_24774, v_t_24776));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_24777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24780 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24781 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24780; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24780); r_; });
          V v_t_24782 = (g_std_2edoc_2e_3c_3e(v_t_24777, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24781})));
          return (g_std_2edoc_2egroup(v_t_24782));
        }
        default: return heff_nomatch(v_t_24767);
        }
      }
      case TAG_EFDefault: {
        V v_t_24786 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24786)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24787 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24790 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24791 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24790; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24790); r_; });
          V v_t_24792 = (g_std_2edoc_2e_3c_3e(v_t_24787, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24791})));
          V v_a_24793 = (g_std_2edoc_2egroup(v_t_24792));
          V v_b_24794 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24795 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_b_24794));
          return (g_std_2edoc_2e_3c_3e(v_a_24793, v_t_24795));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_24796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24799 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24800 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24799; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24799); r_; });
          V v_t_24801 = (g_std_2edoc_2e_3c_3e(v_t_24796, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24800})));
          return (g_std_2edoc_2egroup(v_t_24801));
        }
        default: return heff_nomatch(v_t_24786);
        }
      }
      case TAG_Sum: {
        V v_t_24807 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24807)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24808 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24811 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24812 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24811; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24811); r_; });
          V v_t_24813 = (g_std_2edoc_2e_3c_3e(v_t_24808, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24812})));
          V v_a_24814 = (g_std_2edoc_2egroup(v_t_24813));
          V v_b_24815 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24816 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), v_b_24815));
          return (g_std_2edoc_2e_3c_3e(v_a_24814, v_t_24816));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 5);
          V v_t_24817 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24820 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24821 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24820; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24820); r_; });
          V v_t_24822 = (g_std_2edoc_2e_3c_3e(v_t_24817, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24821})));
          return (g_std_2edoc_2egroup(v_t_24822));
        }
        default: return heff_nomatch(v_t_24807);
        }
      }
      case TAG_ECon: {
        V v_t_24825 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24825)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24826 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24829 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24830 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24829; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24829); r_; });
          V v_t_24831 = (g_std_2edoc_2e_3c_3e(v_t_24826, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24830})));
          V v_a_24832 = (g_std_2edoc_2egroup(v_t_24831));
          V v_b_24833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24834 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), v_b_24833));
          return (g_std_2edoc_2e_3c_3e(v_a_24832, v_t_24834));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_24835 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24838 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24839 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24838; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24838); r_; });
          V v_t_24840 = (g_std_2edoc_2e_3c_3e(v_t_24835, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24839})));
          return (g_std_2edoc_2egroup(v_t_24840));
        }
        default: return heff_nomatch(v_t_24825);
        }
      }
      case TAG_EField: {
        V v_t_24843 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24843)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24847 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24848 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24847; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24847); r_; });
          V v_t_24849 = (g_std_2edoc_2e_3c_3e(v_t_24844, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24848})));
          V v_a_24850 = (g_std_2edoc_2egroup(v_t_24849));
          V v_b_24851 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24852 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), v_b_24851));
          return (g_std_2edoc_2e_3c_3e(v_a_24850, v_t_24852));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_24853 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24856 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24857 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24856; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24856); r_; });
          V v_t_24858 = (g_std_2edoc_2e_3c_3e(v_t_24853, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24857})));
          return (g_std_2edoc_2egroup(v_t_24858));
        }
        default: return heff_nomatch(v_t_24843);
        }
      }
      case TAG_App: {
        V v_t_24861 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24861)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24862 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24865 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24866 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24865; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24865); r_; });
          V v_t_24867 = (g_std_2edoc_2e_3c_3e(v_t_24862, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24866})));
          V v_a_24868 = (g_std_2edoc_2egroup(v_t_24867));
          V v_b_24869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24870 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24869));
          return (g_std_2edoc_2e_3c_3e(v_a_24868, v_t_24870));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_24871 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24874 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24875 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24874; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24874); r_; });
          V v_t_24876 = (g_std_2edoc_2e_3c_3e(v_t_24871, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24875})));
          return (g_std_2edoc_2egroup(v_t_24876));
        }
        default: return heff_nomatch(v_t_24861);
        }
      }
      case TAG_Op: {
        V v_t_24880 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24880)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24881 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24884 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24885 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24884; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24884); r_; });
          V v_t_24886 = (g_std_2edoc_2e_3c_3e(v_t_24881, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24885})));
          V v_a_24887 = (g_std_2edoc_2egroup(v_t_24886));
          V v_b_24888 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24889 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24888));
          return (g_std_2edoc_2e_3c_3e(v_a_24887, v_t_24889));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_24890 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24893 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24894 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24893; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24893); r_; });
          V v_t_24895 = (g_std_2edoc_2e_3c_3e(v_t_24890, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24894})));
          return (g_std_2edoc_2egroup(v_t_24895));
        }
        default: return heff_nomatch(v_t_24880);
        }
      }
      case TAG_Ops: {
        V v_t_24898 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24898)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24899 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24902 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24903 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24902; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24902); r_; });
          V v_t_24904 = (g_std_2edoc_2e_3c_3e(v_t_24899, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24903})));
          V v_a_24905 = (g_std_2edoc_2egroup(v_t_24904));
          V v_b_24906 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24907 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24906));
          return (g_std_2edoc_2e_3c_3e(v_a_24905, v_t_24907));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_24908 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24911 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24912 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24911; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24911); r_; });
          V v_t_24913 = (g_std_2edoc_2e_3c_3e(v_t_24908, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24912})));
          return (g_std_2edoc_2egroup(v_t_24913));
        }
        default: return heff_nomatch(v_t_24898);
        }
      }
      case TAG_OpRhs: {
        V v_t_24916 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24916)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24917 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24920 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24921 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24920; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24920); r_; });
          V v_t_24922 = (g_std_2edoc_2e_3c_3e(v_t_24917, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24921})));
          V v_a_24923 = (g_std_2edoc_2egroup(v_t_24922));
          V v_b_24924 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24925 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24924));
          return (g_std_2edoc_2e_3c_3e(v_a_24923, v_t_24925));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_24926 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24929 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24930 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24929; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24929); r_; });
          V v_t_24931 = (g_std_2edoc_2e_3c_3e(v_t_24926, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24930})));
          return (g_std_2edoc_2egroup(v_t_24931));
        }
        default: return heff_nomatch(v_t_24916);
        }
      }
      case TAG_Ann: {
        V v_t_24935 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24935)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24936 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24939 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24940 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24939; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24939); r_; });
          V v_t_24941 = (g_std_2edoc_2e_3c_3e(v_t_24936, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24940})));
          V v_a_24942 = (g_std_2edoc_2egroup(v_t_24941));
          V v_b_24943 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24944 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_24943));
          return (g_std_2edoc_2e_3c_3e(v_a_24942, v_t_24944));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_24945 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24948 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24949 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24948; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24948); r_; });
          V v_t_24950 = (g_std_2edoc_2e_3c_3e(v_t_24945, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24949})));
          return (g_std_2edoc_2egroup(v_t_24950));
        }
        default: return heff_nomatch(v_t_24935);
        }
      }
      case TAG_BVar: {
        V v_t_24952 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24952)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24953 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24956 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24957 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24956; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24956); r_; });
          V v_t_24958 = (g_std_2edoc_2e_3c_3e(v_t_24953, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24957})));
          V v_a_24959 = (g_std_2edoc_2egroup(v_t_24958));
          V v_b_24960 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24961 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_24960));
          return (g_std_2edoc_2e_3c_3e(v_a_24959, v_t_24961));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 1);
          V v_t_24962 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24965 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24966 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24965; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24965); r_; });
          V v_t_24967 = (g_std_2edoc_2e_3c_3e(v_t_24962, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24966})));
          return (g_std_2edoc_2egroup(v_t_24967));
        }
        default: return heff_nomatch(v_t_24952);
        }
      }
      case TAG_BImp: {
        V v_t_24971 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24971)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24975 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24976 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24975; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24975); r_; });
          V v_t_24977 = (g_std_2edoc_2e_3c_3e(v_t_24972, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24976})));
          V v_a_24978 = (g_std_2edoc_2egroup(v_t_24977));
          V v_b_24979 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_24980 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_24979));
          return (g_std_2edoc_2e_3c_3e(v_a_24978, v_t_24980));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_24981 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24984 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_24985 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24984; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24984); r_; });
          V v_t_24986 = (g_std_2edoc_2e_3c_3e(v_t_24981, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24985})));
          return (g_std_2edoc_2egroup(v_t_24986));
        }
        default: return heff_nomatch(v_t_24971);
        }
      }
      case TAG_BAnn: {
        V v_t_24992 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_24992)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_24993 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_24996 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_24997 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24996; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24996); r_; });
          V v_t_24998 = (g_std_2edoc_2e_3c_3e(v_t_24993, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24997})));
          V v_a_24999 = (g_std_2edoc_2egroup(v_t_24998));
          V v_b_241000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241001 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241000));
          return (g_std_2edoc_2e_3c_3e(v_a_24999, v_t_241001));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 5);
          V v_t_241002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241005 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241006 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241005; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241005); r_; });
          V v_t_241007 = (g_std_2edoc_2e_3c_3e(v_t_241002, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241006})));
          return (g_std_2edoc_2egroup(v_t_241007));
        }
        default: return heff_nomatch(v_t_24992);
        }
      }
      case TAG_Lam: {
        V v_t_241012 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241012)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241013 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241016 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241017 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241016; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241016); r_; });
          V v_t_241018 = (g_std_2edoc_2e_3c_3e(v_t_241013, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241017})));
          V v_a_241019 = (g_std_2edoc_2egroup(v_t_241018));
          V v_b_241020 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241021 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241020));
          return (g_std_2edoc_2e_3c_3e(v_a_241019, v_t_241021));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 4);
          V v_t_241022 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241025 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241026 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241025; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241025); r_; });
          V v_t_241027 = (g_std_2edoc_2e_3c_3e(v_t_241022, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241026})));
          return (g_std_2edoc_2egroup(v_t_241027));
        }
        default: return heff_nomatch(v_t_241012);
        }
      }
      case TAG_Case: {
        V v_t_241032 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241032)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241033 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241036 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241037 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241036; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241036); r_; });
          V v_t_241038 = (g_std_2edoc_2e_3c_3e(v_t_241033, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241037})));
          V v_a_241039 = (g_std_2edoc_2egroup(v_t_241038));
          V v_b_241040 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241041 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_241040));
          return (g_std_2edoc_2e_3c_3e(v_a_241039, v_t_241041));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 4);
          V v_t_241042 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241045 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241046 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241045; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241045); r_; });
          V v_t_241047 = (g_std_2edoc_2e_3c_3e(v_t_241042, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241046})));
          return (g_std_2edoc_2egroup(v_t_241047));
        }
        default: return heff_nomatch(v_t_241032);
        }
      }
      case TAG_EAlt: {
        V v_t_241051 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241051)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241052 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241055 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241056 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241055; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241055); r_; });
          V v_t_241057 = (g_std_2edoc_2e_3c_3e(v_t_241052, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241056})));
          V v_a_241058 = (g_std_2edoc_2egroup(v_t_241057));
          V v_b_241059 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241060 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_241059));
          return (g_std_2edoc_2e_3c_3e(v_a_241058, v_t_241060));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_241061 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241064 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241065 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241064; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241064); r_; });
          V v_t_241066 = (g_std_2edoc_2e_3c_3e(v_t_241061, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241065})));
          return (g_std_2edoc_2egroup(v_t_241066));
        }
        default: return heff_nomatch(v_t_241051);
        }
      }
      case TAG_If: {
        V v_t_241073 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241073)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241074 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241077 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241078 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241077; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241077); r_; });
          V v_t_241079 = (g_std_2edoc_2e_3c_3e(v_t_241074, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241078})));
          V v_a_241080 = (g_std_2edoc_2egroup(v_t_241079));
          V v_b_241081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241082 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_241081));
          return (g_std_2edoc_2e_3c_3e(v_a_241080, v_t_241082));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 6);
          V v_t_241083 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241086 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241087 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241086; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241086); r_; });
          V v_t_241088 = (g_std_2edoc_2e_3c_3e(v_t_241083, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241087})));
          return (g_std_2edoc_2egroup(v_t_241088));
        }
        default: return heff_nomatch(v_t_241073);
        }
      }
      case TAG_Do: {
        V v_t_241091 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241091)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241092 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241095 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241096 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241095; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241095); r_; });
          V v_t_241097 = (g_std_2edoc_2e_3c_3e(v_t_241092, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241096})));
          V v_a_241098 = (g_std_2edoc_2egroup(v_t_241097));
          V v_b_241099 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241100 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241099));
          return (g_std_2edoc_2e_3c_3e(v_a_241098, v_t_241100));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 2);
          V v_t_241101 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241104 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241105 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241104; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241104); r_; });
          V v_t_241106 = (g_std_2edoc_2e_3c_3e(v_t_241101, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241105})));
          return (g_std_2edoc_2egroup(v_t_241106));
        }
        default: return heff_nomatch(v_t_241091);
        }
      }
      case TAG_ESBind: {
        V v_t_241110 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241110)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241111 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241114 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241115 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241114; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241114); r_; });
          V v_t_241116 = (g_std_2edoc_2e_3c_3e(v_t_241111, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241115})));
          V v_a_241117 = (g_std_2edoc_2egroup(v_t_241116));
          V v_b_241118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241119 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_b_241118));
          return (g_std_2edoc_2e_3c_3e(v_a_241117, v_t_241119));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 3);
          V v_t_241120 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241123 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241124 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241123; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241123); r_; });
          V v_t_241125 = (g_std_2edoc_2e_3c_3e(v_t_241120, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241124})));
          return (g_std_2edoc_2egroup(v_t_241125));
        }
        default: return heff_nomatch(v_t_241110);
        }
      }
      case TAG_ELet: {
        V v_t_241132 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24641));
        switch (heff_tag_of(v_t_241132)) {
        case TAG_True: {
          heff_drop(v_args_24633);
          V v_t_241133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241136 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){heff_dup(v_env_24631)}), v_init2_24640));
          V v_d_241137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241136; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241136); r_; });
          V v_t_241138 = (g_std_2edoc_2e_3c_3e(v_t_241133, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241137})));
          V v_a_241139 = (g_std_2edoc_2egroup(v_t_241138));
          V v_b_241140 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24631, v_lastA_24641}));
          V v_t_241141 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24638_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241140));
          return (g_std_2edoc_2e_3c_3e(v_a_241139, v_t_241141));
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_24638_24Just, 1);
          heff_drop(v_init2_24640);
          heff_drop_tag(v_lastA_24641, 6);
          V v_t_241142 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24631), v_h_24632}));
          V v_ds_241145 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_env_24631}), v_args_24633));
          V v_d_241146 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241145; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241145); r_; });
          V v_t_241147 = (g_std_2edoc_2e_3c_3e(v_t_241142, heff_tag_at_n(v_ru_24pr_24639_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241146})));
          return (g_std_2edoc_2egroup(v_t_241147));
        }
        default: return heff_nomatch(v_t_241132);
        }
      }
      default: return heff_nomatch(v_lastA_24641);
      }
    }
    default: return heff_nomatch(v_pr_24639);
    }
  }
  default: return heff_nomatch(v_t_24638);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_env_241148 = args[0];
  V v_rest_241149 = args[1];
  V v_e_241150 = args[2];
  switch (heff_tag_of(v_e_241150)) {
  case TAG_Atom: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_241164 = heff_field(v_e_241150, 0);
    V v_fs_241165 = heff_field(v_e_241150, 1);
    V v_commas_241166 = heff_field(v_e_241150, 2);
    V v_c_241167 = heff_field(v_e_241150, 3);
    heff_take_n(v_e_241150, 15ULL, 4);
    switch (heff_tag_of(v_fs_241165)) {
    case TAG_Nil: {
      heff_drop(v_rest_241149);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_241148;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241164, v_fs_241165, v_commas_241166, v_c_241167});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_241168 = heff_dup(heff_field(v_fs_241165, 0));
      V v_rest2_241169 = heff_dup(heff_field(v_fs_241165, 1));
      switch (heff_tag_of(v_rest2_241169)) {
      case TAG_Nil: {
        V v_t_241170 = ({ V a_0 = v_rest_241149; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241149); r_; });
        switch (heff_tag_of(v_t_241170)) {
        case TAG_True: {
          V v_x1_241171 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_241168));
          switch (heff_tag_of(v_x1_241171)) {
          case TAG_True: {
            heff_drop(v_d_241168);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_241148;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241164, v_fs_241165, v_commas_241166, v_c_241167});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          case TAG_False: {
            switch (heff_tag_of(v_commas_241166)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_241165, 2);
              V v_t_241172 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241148), v_o_241164));
              V v_t_241173 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241148), v_d_241168}));
              V v_t_241174 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241148, v_c_241167));
              V v_t_241175 = (g_std_2edoc_2e_3c_3e(v_t_241173, v_t_241174));
              return (g_std_2edoc_2e_3c_3e(v_t_241172, v_t_241175));
            }
            case TAG_Cons: {
              heff_drop(v_d_241168);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_241148;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241164, v_fs_241165, v_commas_241166, v_c_241167});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_241166);
            }
          }
          default: return heff_nomatch(v_x1_241171);
          }
        }
        case TAG_False: {
          heff_drop(v_d_241168);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_241148;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241164, v_fs_241165, v_commas_241166, v_c_241167});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_t_241170);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_241169, 0ULL, 2);
        heff_drop(v_rest_241149);
        heff_drop(v_d_241168);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241148;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241164, v_fs_241165, v_commas_241166, v_c_241167});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_241169);
      }
    }
    default: return heff_nomatch(v_fs_241165);
    }
  }
  case TAG_InstB: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241149);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241148;
    args[1] = v_e_241150;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_241150);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_env_241249 = args[0];
  V v_b_241250 = args[1];
  switch (heff_tag_of(v_b_241250)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_241300 = heff_field(v_b_241250, 0);
    heff_take_n(v_b_241250, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241249, v_t_241300));
  }
  case TAG_BImp: {
    V v_o_241301 = heff_field(v_b_241250, 0);
    V v_x_241302 = heff_field(v_b_241250, 1);
    V v_c_241303 = heff_field(v_b_241250, 2);
    heff_take_n(v_b_241250, 7ULL, 3);
    V v_t_241304 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241249), v_o_241301));
    V v_t_241305 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241249), v_x_241302));
    V v_t_241306 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241249, v_c_241303));
    V v_t_241307 = (g_std_2edoc_2e_3c_3e(v_t_241305, v_t_241306));
    return (g_std_2edoc_2e_3c_3e(v_t_241304, v_t_241307));
  }
  case TAG_BAnn: {
    V v_o_241308 = heff_field(v_b_241250, 0);
    V v_x_241309 = heff_field(v_b_241250, 1);
    V v_cc_241310 = heff_field(v_b_241250, 2);
    V v_ty_241311 = heff_field(v_b_241250, 3);
    V v_c_241312 = heff_field(v_b_241250, 4);
    heff_take_n(v_b_241250, 31ULL, 5);
    V v_t_241313 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241249), v_o_241308));
    V v_a_241314 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241249), v_x_241309));
    V v_a_241315 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241249), v_cc_241310));
    V v_b_241316 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241249), v_ty_241311}));
    V v_t_241317 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241316));
    V v_b_241318 = (g_std_2edoc_2e_3c_3e(v_a_241315, v_t_241317));
    V v_t_241319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241318));
    V v_t_241320 = (g_std_2edoc_2e_3c_3e(v_a_241314, v_t_241319));
    V v_t_241321 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241249, v_c_241312));
    V v_t_241322 = (g_std_2edoc_2e_3c_3e(v_t_241320, v_t_241321));
    return (g_std_2edoc_2e_3c_3e(v_t_241313, v_t_241322));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241249;
    args[1] = v_b_241250;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_241250);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_env_241351 = args[0];
  V v_rest_241352 = args[1];
  V v_r_241353 = args[2];
  switch (heff_tag_of(v_r_241353)) {
  case TAG_Atom: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241398 = heff_field(v_r_241353, 0);
    V v_e_241399 = heff_field(v_r_241353, 1);
    heff_take_n(v_r_241353, 3ULL, 2);
    V v_a_241400 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241351), v_op_241398));
    V v_b_241401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_241351, v_rest_241352, v_e_241399}));
    V v_t_241402 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241401));
    return (g_std_2edoc_2e_3c_3e(v_a_241400, v_t_241402));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241352);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241351;
    args[1] = v_r_241353;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241353);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_env_241443 = args[0];
  V v_r_241444 = args[1];
  switch (heff_tag_of(v_r_241444)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241489 = heff_field(v_r_241444, 0);
    V v_e_241490 = heff_field(v_r_241444, 1);
    heff_take_n(v_r_241444, 3ULL, 2);
    V v_a_241491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241443), v_op_241489));
    V v_b_241492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241443, v_e_241490}));
    V v_t_241493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241492));
    return (g_std_2edoc_2e_3c_3e(v_a_241491, v_t_241493));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241443;
    args[1] = v_r_241444;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241444);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_r_241544 = args[0];
  V v_env_241534 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241545 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241534, v_r_241544}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241545));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_r_241553 = args[0];
  V v_env_241534 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241554 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241534, v_r_241553}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241554));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_env_241534 = args[0];
  V v_first_241535 = args[1];
  V v_rest_241536 = args[2];
  V v_f_241537 = heff_dup(heff_rfield(v_env_241534, 6));
  V v_it_241538 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(heff_dup(v_f_241537), heff_dup(v_rest_241536)));
  V v_t_241542;
  switch (heff_tag_of(v_it_241538)) {
  case TAG_Nothing: {
    heff_drop(v_f_241537);
    v_t_241542 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_241539 = heff_field(v_it_241538, 0);
    heff_take_n(v_it_241538, 1ULL, 1);
    switch (heff_tag_of(v_it1_241539)) {
    case TAG_Nil: {
      heff_drop(v_f_241537);
      v_t_241542 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_o_241540 = heff_field(v_it1_241539, 0);
      V v_os_241541 = heff_field(v_it1_241539, 1);
      heff_take_n(v_it1_241539, 3ULL, 2);
      v_t_241542 = ({ V a_0 = v_f_241537; V a_1 = v_o_241540; V a_2 = v_os_241541; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_241541); r_; });
      break;
    }
    default: heff_nomatch(v_it1_241539);
    }
    break;
  }
  default: heff_nomatch(v_it_241538);
  }
  switch (heff_tag_of(v_t_241542)) {
  case TAG_Nothing: {
    V v_t_241543 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241534), v_first_241535}));
    V v_ds_241546 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_env_241534}), v_rest_241536));
    V v_t_241547 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241546; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241546); r_; });
    V v_t_241548 = (g_std_2edoc_2e_3c_3e(v_t_241543, v_t_241547));
    return (g_std_2edoc_2egroup(v_t_241548));
  }
  case TAG_Just: {
    V v_m_241549 = heff_field(v_t_241542, 0);
    heff_take_n(v_t_241542, 1ULL, 1);
    V v_t_241550 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo), 2, (V[]){heff_dup(heff_rfield(v_env_241534, 6)), heff_dup(v_m_241549)}));
    V v_t_241551 = (g_list_2eall(v_t_241550, v_rest_241536));
    switch (heff_tag_of(v_t_241551)) {
    case TAG_True: {
      heff_drop(v_m_241549);
      V v_t_241552 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241534), v_first_241535}));
      V v_ds_241555 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_env_241534}), v_rest_241536));
      V v_t_241556 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241555; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241555); r_; });
      V v_t_241557 = (g_std_2edoc_2e_3c_3e(v_t_241552, v_t_241556));
      return (g_std_2edoc_2egroup(v_t_241557));
    }
    case TAG_False: {
      V v_t_241558 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241534, v_m_241549, v_first_241535, NTAG(TAG_Nil), v_rest_241536}));
      return (g_std_2edoc_2egroup(v_t_241558));
    }
    default: return heff_nomatch(v_t_241551);
    }
  }
  default: return heff_nomatch(v_t_241542);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_env_241559 = args[0];
  V v_m_241560 = args[1];
  V v_f_241561 = args[2];
  V v_acc_241562 = args[3];
  V v_rs_241563 = args[4];
  switch (heff_tag_of(v_rs_241563)) {
  case TAG_Nil: {
    heff_drop(v_m_241560);
    V v_t_241564 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241562));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_241559;
    args[1] = v_f_241561;
    args[2] = v_t_241564;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_241565 = heff_field(v_rs_241563, 0);
    V v_rest2_241566 = heff_field(v_rs_241563, 1);
    heff_take_n(v_rs_241563, 3ULL, 2);
    switch (heff_tag_of(v_r_241565)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_241611 = heff_dup(heff_field(v_r_241565, 0));
      V v_e_241612 = heff_dup(heff_field(v_r_241565, 1));
      V v_t_241613 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_241559, 6)), heff_dup(v_m_241560), heff_dup(heff_rfield(v_op_241611, 1))));
      V v_t_241616;
      switch (heff_tag_of(v_t_241613)) {
      case TAG_Tighter: {
        v_t_241616 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_241616 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_241613, 0ULL, 1);
        v_t_241616 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_241616 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_241613, 0ULL, 1);
        v_t_241616 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_241613);
      }
      switch (heff_tag_of(v_t_241616)) {
      case TAG_True: {
        heff_drop_tag(v_r_241565, 2);
        V v_t_241617 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241562));
        V v_t_241618 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_241559), v_f_241561, v_t_241617}));
        V v_a_241619 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241559), v_op_241611));
        V v_b_241620 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241559, v_m_241560, v_e_241612, NTAG(TAG_Nil), v_rest2_241566}));
        V v_t_241621 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241620));
        V v_t_241622 = (g_std_2edoc_2e_3c_3e(v_a_241619, v_t_241621));
        V v_t_241623 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241622));
        return (g_std_2edoc_2e_3c_3e(v_t_241618, v_t_241623));
      }
      case TAG_False: {
        heff_drop_rec(v_op_241611, 9);
        heff_drop(v_e_241612);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_241559;
        args[1] = v_m_241560;
        args[2] = v_f_241561;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
        args[4] = v_rest2_241566;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_241616);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241559;
      args[1] = v_m_241560;
      args[2] = v_f_241561;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241565, v_acc_241562});
      args[4] = v_rest2_241566;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_241565);
    }
  }
  default: return heff_nomatch(v_rs_241563);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_env_241664 = args[0];
  V v_a_241665 = args[1];
  switch (heff_tag_of(v_a_241665)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_241732 = heff_field(v_a_241665, 0);
    V v_arrow_241733 = heff_field(v_a_241665, 1);
    V v_body_241734 = heff_field(v_a_241665, 2);
    heff_take_n(v_a_241665, 7ULL, 3);
    V v_a_241735 = ({ V a_0 = heff_dup(v_env_241664); V a_1 = v_p_241732; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241732); r_; });
    V v_b_241736 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241664), v_arrow_241733));
    V v_t_241737 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241736));
    V v_t_241738 = (g_std_2edoc_2e_3c_3e(v_a_241735, v_t_241737));
    V v_t_241739 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241664, v_body_241734}));
    return (g_std_2edoc_2e_3c_3e(v_t_241738, v_t_241739));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241664;
    args[1] = v_a_241665;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_241665);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_env_241757 = args[0];
  V v_s_241758 = args[1];
  switch (heff_tag_of(v_s_241758)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_241836 = heff_field(v_s_241758, 0);
    V v_arrow_241837 = heff_field(v_s_241758, 1);
    V v_e_241838 = heff_field(v_s_241758, 2);
    heff_take_n(v_s_241758, 7ULL, 3);
    V v_a_241839 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241757), v_x_241836));
    V v_b_241840 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241757), v_arrow_241837));
    V v_t_241841 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241840));
    V v_t_241842 = (g_std_2edoc_2e_3c_3e(v_a_241839, v_t_241841));
    V v_t_241843 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241757, v_e_241838}));
    return (g_std_2edoc_2e_3c_3e(v_t_241842, v_t_241843));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241757;
    args[1] = v_s_241758;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_241758);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_env_241850 = args[0];
  V v_f_241851 = args[1];
  switch (heff_tag_of(v_f_241851)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_241874 = heff_field(v_f_241851, 0);
    V v_eq_241875 = heff_field(v_f_241851, 1);
    V v_e_241876 = heff_field(v_f_241851, 2);
    heff_take_n(v_f_241851, 7ULL, 3);
    V v_a_241877 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241850), v_x_241874));
    V v_b_241878 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241850), v_eq_241875));
    V v_t_241879 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241878));
    V v_t_241880 = (g_std_2edoc_2e_3c_3e(v_a_241877, v_t_241879));
    V v_t_241881 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241850, v_e_241876}));
    return (g_std_2edoc_2e_3c_3e(v_t_241880, v_t_241881));
  }
  case TAG_EFDefault: {
    V v_d_241882 = heff_field(v_f_241851, 0);
    V v_eq_241883 = heff_field(v_f_241851, 1);
    V v_e_241884 = heff_field(v_f_241851, 2);
    heff_take_n(v_f_241851, 7ULL, 3);
    V v_a_241885 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241850), v_d_241882}));
    V v_b_241886 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241850), v_eq_241883));
    V v_t_241887 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241886));
    V v_t_241888 = (g_std_2edoc_2e_3c_3e(v_a_241885, v_t_241887));
    V v_t_241889 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241850, v_e_241884}));
    return (g_std_2edoc_2e_3c_3e(v_t_241888, v_t_241889));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241850;
    args[1] = v_f_241851;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_241851);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2esig_str0, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2esig_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242) {
top: ;
  V v_a_243 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_241));
  V v_b_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_242}));
  V v_t_245 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2esig_str0)}), v_b_244));
  V v_d_246 = (g_std_2edoc_2e_3c_3e(v_a_243, v_t_245));
  return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam0, 1, 1, (V[]){v_d_246})});
}
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2esig(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_249 = heff_intSub(v_k_247, v_i_248);
  if (heff_intEq_c(heff_dup(v_i_249), MK_INT(0LL))) {
    heff_drop(v_i_249);
    return v_d_246;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_249, v_d_246});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2esig_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_d_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2esig_lam1, 1, 2, (V[]){v_k_247, v_d_246})});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_eq_243);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_a_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_243));
        V v_b_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_249));
        V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_a_248, v_t_2410));
        V v_ds_2418 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 1, (V[]){v_env_240}), v_bars_245, v_more_247));
        V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2418); r_; });
        V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2419));
        V v_t_2421 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2420));
        return (g_std_2edoc_2egroup(v_t_2421));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2412 = args[0];
  V v_a_2413 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2414 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2412));
  V v_b_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2413}));
  V v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2415));
  V v_t_2417 = (g_std_2edoc_2e_3c_3e(v_a_2414, v_t_2416));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2417));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_cc_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    V v_a_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_242)));
    V v_b_247 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_240), heff_dup(v_cc_243), heff_dup(v_ty_244)));
    V v_t_248 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str0)}), v_b_247));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_a_246, v_t_248));
    V v_t_2416;
    switch (heff_tag_of(v_d_245)) {
    case TAG_Nothing: {
      heff_drop(v_env_240);
      v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2410 = heff_field(v_d_245, 0);
      switch (heff_tag_of(v_x21_2410)) {
      case TAG_MkPair: {
        V v_eq_2411 = heff_field(v_x21_2410, 0);
        V v_d_2412 = heff_field(v_x21_2410, 1);
        V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2411)));
        V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_d_2412)}));
        V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
        v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etfDoc_str1)}), v_t_2415));
        break;
      }
      default: heff_nomatch(v_x21_2410);
      }
      break;
    }
    default: heff_nomatch(v_d_245);
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_249, v_t_2416);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2etfDoc(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_x2_245 = ({ V a_0 = heff_take_field(v_t_244, 7); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x1_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_x1_247 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_x1_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2410 = heff_get_n(v_t_244, 8, 9);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      heff_drop_rec(v_t_244, 9);
      v_t_2410 = heff_get_n(v_x_248, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      v_t_2411 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_2411 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2411));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(V v_env_240, V v_rhsLast_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_rhsLast_241, 9);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_kw_244 = heff_field(v_x41_243, 0);
      V v_ds_245 = heff_field(v_x41_243, 1);
      V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_rhsLast_241, 7)), heff_rfield(v_env_240, 3)));
      V v_t_248;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_rhsLast_241, 9);
        v_t_248 = heff_dup(g_std_2edoc_2ehardline_get());
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_246, 0ULL, 1);
        v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(heff_dup(v_env_240), v_rhsLast_241));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_244)));
      V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1047096705x1105341026(v_env_240, MK_INT(0LL), v_ds_245));
      V v_d_2411 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2410));
      V v_t_2412 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2411})));
      return (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2417;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_x_246 = heff_field(v_x_243, 0);
        v_t_2410 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_x2_2411 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_2410, 7), heff_rfield(v_env_240, 1)));
      V v_x1_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_x1_2413 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_x1_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2416;
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nil: {
        v_t_2416 = heff_get_n(v_t_2410, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 2);
        heff_drop_rec(v_t_2410, 9);
        v_t_2416 = heff_get_n(v_x_2414, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        v_t_2417 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
    } else {
      v_t_2417 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2422;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_x_2418 = heff_field(v_x_243, 0);
      v_t_2422 = heff_dup(v_x_2418);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2425 = heff_field(v_x_243, 2);
      V v_x14_2426 = heff_field(v_x_243, 3);
      switch (heff_tag_of(v_x14_2426)) {
      case TAG_Nothing: {
        v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2425)));
        break;
      }
      case TAG_Just: {
        V v_x141_2427 = heff_field(v_x14_2426, 0);
        switch (heff_tag_of(v_x141_2427)) {
        case TAG_MkPair: {
          V v_d_2429 = heff_field(v_x141_2427, 1);
          v_t_2430 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2429)));
          break;
        }
        default: heff_nomatch(v_x141_2427);
        }
        break;
      }
      default: heff_nomatch(v_x14_2426);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2422, v_t_2430, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2434));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2435));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2431 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2431; V a_1 = v_x_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2etfDoc(a_0, a_1)); heff_drop(v_x_243); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str18, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str22, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str23, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epD_str24, 0, "");
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epD_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2epD(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DImport: {
    V v_t_242 = heff_field(v_x2_241, 0);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_242));
  }
  case TAG_DFixity: {
    V v_kw_243 = heff_field(v_x2_241, 0);
    V v_ts_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_243)));
    V v_ds_248 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_ts_244)));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_248; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_248); r_; });
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_245, v_t_249);
  }
  case TAG_DSig: {
    V v_n_2410 = heff_field(v_x2_241, 0);
    V v_cc_2411 = heff_field(v_x2_241, 1);
    V v_ty_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2414 = (g_list_2emap(v_t_2413, heff_dup(v_n_2410)));
    V v_a_2415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2414; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2414); r_; });
    V v_b_2416 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2411), heff_dup(v_ty_2412)));
    V v_t_2417 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str1)}), v_b_2416));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_2415, v_t_2417);
  }
  case TAG_DEqn: {
    V v_n_2418 = heff_field(v_x2_241, 0);
    V v_pats_2419 = heff_field(v_x2_241, 1);
    V v_eq_2420 = heff_field(v_x2_241, 2);
    V v_rhs_2421 = heff_field(v_x2_241, 3);
    V v_w_2422 = heff_field(v_x2_241, 4);
    V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2424 = (g_list_2emap(v_t_2423, heff_dup(v_n_2418)));
    V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2424; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2424); r_; });
    V v_ds_2428 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_pats_2419)));
    V v_a_2429 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2428; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2428); r_; });
    V v_b_2430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2420)));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str3)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_rhsLast_2433 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2435;
    switch (heff_tag_of(v_w_2422)) {
    case TAG_Nothing: {
      heff_drop_rec(v_rhsLast_2433, 9);
      v_t_2435 = heff_dup(v_env_240);
      break;
    }
    case TAG_Just: {
      v_t_2435 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), heff_dup(heff_rfield(v_env_240, 3)), heff_dup(heff_rfield(v_env_240, 4)), heff_get_n(v_rhsLast_2433, 7, 9), heff_dup(heff_rfield(v_env_240, 6))});
      break;
    }
    default: heff_nomatch(v_w_2422);
    }
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_t_2435, heff_dup(v_rhs_2421)}));
    V v_t_2437 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2438 = (g_heff_2esyntax_2efmt_2elayout_2ewhereDoc_24s940033030x1402389602(v_env_240, v_t_2437, v_w_2422));
    V v_t_2439 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2438));
    V v_t_2440 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2439));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2440);
  }
  case TAG_DData: {
    V v_kw_2441 = heff_field(v_x2_241, 0);
    V v_name_2442 = heff_field(v_x2_241, 1);
    V v_params_2443 = heff_field(v_x2_241, 2);
    V v_universe_2444 = heff_field(v_x2_241, 3);
    V v_alts_2445 = heff_field(v_x2_241, 4);
    V v_a_2446 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2441)));
    V v_b_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2442)));
    V v_t_2448 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str4)}), v_b_2447));
    V v_t_2449 = (g_std_2edoc_2e_3c_3e(v_a_2446, v_t_2448));
    V v_ds_2453 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2443)));
    V v_t_2454 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2453; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2453); r_; });
    V v_t_2462;
    switch (heff_tag_of(v_universe_2444)) {
    case TAG_Nothing: {
      v_t_2462 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2455 = heff_field(v_universe_2444, 0);
      switch (heff_tag_of(v_x21_2455)) {
      case TAG_MkPair: {
        V v_cc_2456 = heff_field(v_x21_2455, 0);
        V v_u_2457 = heff_field(v_x21_2455, 1);
        V v_a_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2456)));
        V v_b_2459 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), heff_dup(v_u_2457)}));
        V v_t_2460 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str6)}), v_b_2459));
        V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_a_2458, v_t_2460));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str7)}), v_t_2461));
        break;
      }
      default: heff_nomatch(v_x21_2455);
      }
      break;
    }
    default: heff_nomatch(v_universe_2444);
    }
    V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(v_env_240, heff_dup(v_alts_2445)));
    V v_t_2464 = (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    V v_t_2465 = (g_std_2edoc_2e_3c_3e(v_t_2454, v_t_2464));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2465);
  }
  case TAG_DType: {
    V v_kw_2466 = heff_field(v_x2_241, 0);
    V v_name_2467 = heff_field(v_x2_241, 1);
    V v_params_2468 = heff_field(v_x2_241, 2);
    V v_eq_2469 = heff_field(v_x2_241, 3);
    V v_body_2470 = heff_field(v_x2_241, 4);
    V v_a_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2466)));
    V v_b_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2467)));
    V v_t_2473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str8)}), v_b_2472));
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_a_2471, v_t_2473));
    V v_ds_2478 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam3, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2468)));
    V v_a_2479 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2478; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2478); r_; });
    V v_b_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2469)));
    V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str10)}), v_b_2480));
    V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_a_2479, v_t_2481));
    V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, heff_dup(v_body_2470)}));
    V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_t_2482, v_t_2483));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2484);
  }
  case TAG_DTheory: {
    V v_kw_2485 = heff_field(v_x2_241, 0);
    V v_name_2486 = heff_field(v_x2_241, 1);
    V v_params_2487 = heff_field(v_x2_241, 2);
    V v_w_2488 = heff_field(v_x2_241, 3);
    V v_fields_2489 = heff_field(v_x2_241, 4);
    V v_a_2490 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2485)));
    V v_b_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2486)));
    V v_t_2492 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str11)}), v_b_2491));
    V v_t_2493 = (g_std_2edoc_2e_3c_3e(v_a_2490, v_t_2492));
    V v_ds_2497 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2epD_lam4, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2487)));
    V v_a_2498 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2497; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2497); r_; });
    V v_b_2499 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_2488)));
    V v_t_24100 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str13)}), v_b_2499));
    V v_t_24101 = (g_std_2edoc_2e_3c_3e(v_a_2498, v_t_24100));
    V v_t_24102 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, MK_INT(0LL), v_fields_2489));
    V v_t_24103 = (g_std_2edoc_2e_3c_3e(v_t_24101, v_t_24102));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2493, v_t_24103);
  }
  case TAG_DPrimitive: {
    V v_kw_24104 = heff_field(v_x2_241, 0);
    V v_x_24105 = heff_field(v_x2_241, 1);
    V v_cc_24106 = heff_field(v_x2_241, 2);
    V v_ty_24107 = heff_field(v_x2_241, 3);
    V v_a_24108 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24104)));
    V v_a_24109 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_24105)));
    V v_b_24110 = (g_heff_2esyntax_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_24106), heff_dup(v_ty_24107)));
    V v_t_24111 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str14)}), v_b_24110));
    V v_b_24112 = (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24111));
    V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str15)}), v_b_24112));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24108, v_t_24113);
  }
  case TAG_DTest: {
    V v_kw_24114 = heff_field(v_x2_241, 0);
    V v_x_24115 = heff_field(v_x2_241, 1);
    V v_a_24116 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24114)));
    V v_b_24117 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, heff_dup(v_x_24115)));
    V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str16)}), v_b_24117));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_a_24116, v_t_24118);
  }
  case TAG_DWatch: {
    V v_w_24119 = heff_field(v_x2_241, 0);
    V v_e_24120 = heff_field(v_x2_241, 1);
    V v_t_24121 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_24119)));
    V v_t_24122 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24120));
    V v_b_24123 = heff_get_n(v_t_24122, 3, 9);
    V v_s_24124 = heff_strSlice(heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_w_24119, 4)), v_b_24123);
    V v_t_24125 = (g_prelude_2eskipSpaces(heff_dup(v_s_24124), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24126 = heff_intSub(heff_strLength(heff_dup(v_s_24124)), MK_INT(1LL));
    V v_t_24127 = (g_prelude_2eskipSpaces(heff_dup(v_s_24124), v_t_24126, MK_INT(-1LL)));
    V v_t_24128 = heff_strSlice(v_s_24124, v_t_24125, heff_intAdd(v_t_24127, MK_INT(1LL)));
    V v_t_24147;
    if (heff_strEq_c(v_t_24128, ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str17))) {
      V v_t_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24120));
      V v_a_24131 = heff_get_n(v_t_24130, 3, 9);
      V v_t_24132 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24120)));
      V v_t_24133 = heff_strSlice(heff_get_n(v_env_240, 0, 7), v_a_24131, heff_get_n(v_t_24132, 4, 9));
      V v_x2_24134 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str18), v_t_24133, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24137;
      switch (heff_tag_of(v_x2_24134)) {
      case TAG_Nil: {
        v_s_24137 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_24135 = heff_field(v_x2_24134, 0);
        V v_xs_24136 = heff_field(v_x2_24134, 1);
        heff_take_n(v_x2_24134, 3ULL, 2);
        v_s_24137 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24135; V a_2 = v_xs_24136; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24136); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24134);
      }
      V v_t_24139;
      if (heff_strEq_c(heff_dup(v_s_24137), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str20))) {
        heff_drop(v_s_24137);
        v_t_24139 = NTAG(TAG_None);
      } else {
        v_t_24139 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24137});
      }
      v_t_24147 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str21)}), v_t_24139));
    } else {
      V v_t_24140 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_e_24120)));
      V v_t_24141 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_dup(heff_rfield(v_w_24119, 4)), heff_get_n(v_t_24140, 4, 9));
      V v_x2_24142 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str22), v_t_24141, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_s_24145;
      switch (heff_tag_of(v_x2_24142)) {
      case TAG_Nil: {
        v_s_24145 = ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str23);
        break;
      }
      case TAG_Cons: {
        V v_x_24143 = heff_field(v_x2_24142, 0);
        V v_xs_24144 = heff_field(v_x2_24142, 1);
        heff_take_n(v_x2_24142, 3ULL, 2);
        v_s_24145 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24143; V a_2 = v_xs_24144; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24144); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24142);
      }
      if (heff_strEq_c(heff_dup(v_s_24145), ((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str24))) {
        heff_drop(v_s_24145);
        v_t_24147 = NTAG(TAG_None);
      } else {
        v_t_24147 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24145});
      }
    }
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_24121, v_t_24147);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2epD(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_246));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str0)}), v_t_247));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = ({ V a_0 = v_env_240; V a_1 = v_p_2426; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_2426); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str2)}), v_t_2427));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam2(V self, V *args) {
  V v_p_2450 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2450}));
  V v_t_2452 = (g_std_2edoc_2eflatten(v_t_2451));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str5)}), v_t_2452));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam3(V self, V *args) {
  V v_p_2475 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2475}));
  V v_t_2477 = (g_std_2edoc_2eflatten(v_t_2476));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str9)}), v_t_2477));
}
V g_heff_2esyntax_2efmt_2elayout_2epD_lam4(V self, V *args) {
  V v_p_2494 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_p_2494}));
  V v_t_2496 = (g_std_2edoc_2eflatten(v_t_2495));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epD_str12)}), v_t_2496));
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      v_t_245 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str0), heff_dup(heff_rfield(v_c_242, 0)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_s_249 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2411;
    if (heff_strEq_c(heff_dup(v_s_249), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_str2))) {
      heff_drop(v_s_249);
      v_t_2411 = NTAG(TAG_None);
    } else {
      v_t_2411 = heff_tag_n(TAG_Text, 1, (V[]){v_s_249});
    }
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(v_env_240, v_cs_243));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2412));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2413));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2414);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
    }
    case TAG_False: {
      V t_0 = v_cs_243;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DEqn: {
    V v_n_2410 = heff_field(v_d_240, 0);
    V v_x2_2415 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2410)));
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    }
    default: return heff_nomatch(v_x2_2415);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefLast_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefLast_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefLast(V v_x_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_d_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_es_244 = heff_field(v_x3_242, 1);
    V v_t_2443;
    switch (heff_tag_of(v_e_243)) {
    case TAG_DImport: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2411 = heff_field(v_e_243, 0);
      V v_x2_2416 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefLast_str1); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      v_t_2443 = heff_strEq(v_t_2419, heff_dup(v_x_240));
      break;
    }
    case TAG_DData: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_243);
    }
    switch (heff_tag_of(v_t_2443)) {
    case TAG_True: {
      heff_drop(v_d_241);
      V t_0 = v_x_240;
      V t_1 = heff_dup(v_e_243);
      V t_2 = v_es_244;
      v_x_240 = t_0;
      v_d_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_x_240);
      return v_d_241;
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edefLast(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_e_242)) {
    case TAG_DImport: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      V v_n_2410 = heff_dup(heff_field(v_e_242, 0));
      V v_x2_2415 = (g_list_2emap_24s759871588x920431471(v_n_2410));
      V v_t_2418;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eafterDef_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      v_t_2442 = heff_strEq(v_t_2418, heff_dup(v_x_240));
      break;
    }
    case TAG_DData: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_es_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_x_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_242, v_es_243});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eafterDef(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL))) {
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_s_240);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2egapEnd(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V v_s_240, V v_j_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_241)), MK_INT(45LL))) {
    V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), heff_dup(v_j_241)));
    V v_a_244 = heff_intSub(v_t_243, heff_dup(v_j_241));
    if (heff_intLe_c(MK_INT(2LL), v_a_244)) {
      V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(heff_dup(v_s_240), v_j_241));
      V v_c_247 = heff_strByteAt(v_s_240, v_t_246);
      V v_x1_2411;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_247))) {
        V v_x3_249 = (g_prelude_2eindexFrom(heff_strFromByte(v_c_247), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          v_x1_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_249, 0ULL, 1);
          v_x1_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_249);
        }
      } else {
        heff_drop(v_c_247);
        v_x1_2411 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2411);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_j_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
  V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(heff_dup(v_s_240), v_t_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_s_240, v_t_244);
  }
  case TAG_False: {
    V v_j_245 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), heff_dup(v_i_241)));
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_j_245)), MK_INT(123LL))) {
      V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_j_245, MK_INT(1LL)));
      if (heff_intEq_c(v_t_247, MK_INT(45LL))) {
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(heff_dup(v_s_240), v_i_241));
        V v_r_2410 = (g_heff_2esyntax_2efmt_2elex_2eblockScan(heff_dup(v_s_240), v_t_249, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
        V t_0 = v_s_240;
        V t_1 = heff_get_n(v_r_2410, 0, 5);
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        return v_i_241;
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_j_245);
      return v_i_241;
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2easWritten_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2easWritten_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2easWritten_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2easWritten_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2easWritten(V v_env_240, V v_first_241, V v_last2_242) {
top: ;
  V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_first_241, 7)), heff_rfield(v_env_240, 1)));
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_first_241, 7), heff_rfield(v_env_240, 2)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ds_2410 = (g_list_2emap_24s422923909x1655406376(v_t_249));
  V v_t_2411 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2410; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2410); r_; });
  V v_b_2412 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_last2_242, 4, 9)));
  V v_t_2413 = heff_strSlice(heff_get_n(v_env_240, 0, 7), heff_get_n(v_first_241, 3, 9), v_b_2412);
  V v_x2_2414 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str0), v_t_2413, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_s_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_s_2417 = ((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_s_2417 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2419;
  if (heff_strEq_c(heff_dup(v_s_2417), ((V)&g_heff_2esyntax_2efmt_2elayout_2easWritten_str2))) {
    heff_drop(v_s_2417);
    v_t_2419 = NTAG(TAG_None);
  } else {
    v_t_2419 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2417});
  }
  V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2419));
  return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2420));
}
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2easWritten(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eskipped_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eskipped(V v_env_240, V v_above_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_above_241)) {
  case TAG_True: {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_244 = heff_take_field(v_t_243, 8);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop_rec(v_t_243, 9);
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
      V v_t_246 = heff_take_field(v_t_245, 8);
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop_rec(v_env_240, 7);
        heff_drop_rec(v_t_245, 9);
        return NTAG(TAG_False);
      }
      case TAG_False: {
        V v_x2_247 = ({ V a_0 = heff_get_n(v_t_245, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
        V v_xs_249;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nothing: {
          v_xs_249 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_248 = heff_field(v_x2_247, 0);
          heff_take_n(v_x2_247, 1ULL, 1);
          v_xs_249 = v_x_248;
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
        V v_t_2411 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2410, NTAG(TAG_Nil)));
        return ({ V a_0 = v_t_2411; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2411); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      V v_x2_2412 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_t_243, 7, 9), heff_rfield(v_env_240, 1)));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        v_t_2414 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_x1_2415 = ({ V a_0 = v_t_2414; V r_ = (g_list_2eany_24s2118781542x1794344985(a_0)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_True: {
        V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
        V v_t_2417 = heff_take_field(v_t_2416, 8);
        switch (heff_tag_of(v_t_2417)) {
        case TAG_True: {
          heff_drop_rec(v_env_240, 7);
          heff_drop_rec(v_t_2416, 9);
          return NTAG(TAG_False);
        }
        case TAG_False: {
          V v_x2_2418 = ({ V a_0 = heff_get_n(v_t_2416, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
          V v_xs_2420;
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_Nothing: {
            v_xs_2420 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            heff_take_n(v_x2_2418, 1ULL, 1);
            v_xs_2420 = v_x_2419;
            break;
          }
          default: heff_nomatch(v_x2_2418);
          }
          V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
          V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2421, NTAG(TAG_Nil)));
          return ({ V a_0 = v_t_2422; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2422); r_; });
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      case TAG_False: {
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    V v_t_2423 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_t_2424 = heff_take_field(v_t_2423, 8);
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_2423, 9);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_x2_2425 = ({ V a_0 = heff_get_n(v_t_2423, 7, 9); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
      V v_xs_2427;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        v_xs_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        heff_take_n(v_x2_2425, 1ULL, 1);
        v_xs_2427 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
      V v_t_2429 = (g_heff_2esyntax_2efmt_2elayout_2enearGo(v_t_2428, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2429; V r_ = (g_list_2eany_24s577543654x765608923(a_0)); heff_drop(v_t_2429); r_; });
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_above_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eskipped(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2441;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2439 = heff_dup(heff_field(v_d_244, 0));
      v_t_2441 = heff_strEq(heff_get_n(v_w_2439, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2462;
    switch (heff_tag_of(v_t_2441)) {
    case TAG_True: {
      V v_t_2442 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2443 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2445 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2442, v_t_2443, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2446 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2447 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2446, v_ds_245));
      v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2445, v_t_2447));
      break;
    }
    case TAG_False: {
      V v_t_2448 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      switch (heff_tag_of(v_t_2448)) {
      case TAG_True: {
        V v_t_2449 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2450 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2edefLast(v_t_2450, heff_dup(v_d_244), v_ds_245));
        V v_t_2452 = (g_heff_2esyntax_2ecst_2elastD(v_t_2451));
        V v_t_2453 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2449, v_t_2452));
        V v_t_2454 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2455 = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(v_t_2454, v_ds_245));
        V v_t_2456 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2455));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2453, v_t_2456));
        break;
      }
      case TAG_False: {
        V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2458 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2457, v_t_2458, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2460, v_t_2461));
        break;
      }
      default: heff_nomatch(v_t_2448);
      }
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2462));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2444 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2444; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2459 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2459; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_ls_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
    V v_t_245 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_244, MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankMark_get()))) {
      heff_drop(v_l_241);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str0), (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_ls_242))});
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
      V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_249, MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(heff_dup(v_l_241), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2411, ((V)&g_heff_2esyntax_2efmt_2elayout_2ekeptLines_str1))) {
        heff_drop(v_l_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_ls_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_241, (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_ls_242))});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ekeptLines(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1), v_s_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_s_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x2_2411;
  if (heff_intEq_c(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get())), MK_INT(0LL))) {
    v_x2_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
  } else {
    v_x2_2411 = (g_prelude_2esplitFrom(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), v_s_249, MK_INT(0LL), NTAG(TAG_Nil)));
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Left = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_at_240, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Left, TAG_Left, 1, (V[]){v_e_242});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Right = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_ts_245 = heff_get_n(v_at_240, 0, 2);
    V v_eof_248;
    if (heff_intLt_c(MK_INT(0LL), heff_arrayLength(heff_dup(v_ts_245)))) {
      V v_t_247 = heff_intSub(heff_arrayLength(heff_dup(v_ts_245)), MK_INT(1LL));
      v_eof_248 = heff_arrayIndex(v_ts_245, v_t_247);
    } else {
      heff_drop(v_ts_245);
      v_eof_248 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtParsed_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), v_ds_243));
    V v_x2_2410 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_eof_248, 7, 9), heff_rfield(v_env_244, 1)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2413 = ({ V a_0 = v_env_244; V a_1 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2413));
    return heff_tag_at_n(v_ru_24x2_241_24Right, TAG_Right, 1, (V[]){(g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2414))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtParsed(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0, 21, "the file does not lex");
Clo g_heff_2esyntax_2efmt_2elayout_2efmtLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtLexed(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_x1_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_x1_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 2);
    heff_drop_rec(v_l_243, 3);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_str0)});
  }
  case TAG_False: {
    V v_t_249 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_hdr_242, 0, 2)));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_take_field(v_l_243, 0)));
    V v_t_2411 = (g_list_2esortBy_24s88152486x2058486153(v_t_2410));
    V v_at_2412 = (g_heff_2esyntax_2efmt_2etoks_2eattach(v_src_241, v_t_2411, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 0, 7);
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 1, 7);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 2, 7);
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 3, 7);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 4, 7);
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_at_2412, 1)), 5, 7);
    V v_at_2419 = ({ V rv_1 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_t_2413, v_t_2414, v_t_2415, v_t_2416, v_t_2417, v_t_2418, v_f_240}); V rr_ = heff_rec_reuse_n(v_at_2412, 1ULL, 2, shape_toks__env); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_2419, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2420, MK_INT(0LL)});
    V v_t_2422 = (g_heff_2esyntax_2ecst_2eprogramGo(v_t_2421, NTAG(TAG_Nil)));
    return (g_heff_2esyntax_2efmt_2elayout_2efmtParsed(v_at_2419, v_t_2422));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtLexed(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V v_f_240, V v_src_241) {
top: ;
  V v_imps_242 = (g_heff_2esyntax_2efmt_2eimports_2ereadGo(heff_dup(v_src_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1759289969x319536741(heff_dup(v_src_241), v_imps_242));
  V v_hdr_244 = heff_rec_n(2, shape_imports__text, (V[]){v_imps_242, v_t_243});
  V v_t_245 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(heff_rfield(v_hdr_244, 1)), v_t_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return (g_heff_2esyntax_2efmt_2elayout_2efmtLexed(v_f_240, v_src_241, v_hdr_244, v_t_246));
}
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(a[0], a[1]);
}