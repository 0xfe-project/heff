// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
V g_heff_2ecompile_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedFor_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArg(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArg_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2eetaLets(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2ecompile_2esimplify_2eetaOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaOne_clo;
V g_heff_2ecompile_2esimplify_2efieldIn(V, V);
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldIn_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeptAsk(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknowing(V, V, V);
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknowing_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emadeOne(V, V);
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkSafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2eremember(V, V, V);
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eremember_clo;
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagLeaves(V);
V g_heff_2ecompile_2esimplify_2etagLeaves_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagLeaves_clo;
V g_heff_2ecompile_2esimplify_2etouch(V, V, V);
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etouch_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_clo;
V g_heff_2ecompile_2esimplify_2eversAll(V);
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eversAll_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall_24s1194065168x228565983(V, V);
V g_list_2eall_24s1194065168x228565983_entry(V self, V *a);
extern Clo g_list_2eall_24s1194065168x228565983_clo;
V g_list_2eany_24s1107779796x153132813(V);
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a);
extern Clo g_list_2eany_24s1107779796x153132813_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24f552047357x993882406(V, V);
V g_list_2efoldl_24f552047357x993882406_entry(V self, V *a);
extern Clo g_list_2efoldl_24f552047357x993882406_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebindArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam0, 1, 1, (V[]){v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam1, 2, 1, (V[]){v_as_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_t_2440);
    V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_p_245});
  } else {
    heff_drop(v_t_2440);
    V v_x2_2442 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_str0), v_p_245));
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_s_2444 = heff_field(v_x2_2442, 1);
      V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
      V v_t_2445 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_x_2443), v_a_243})});
      V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2443})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_s_2444});
    }
    default: return heff_nomatch(v_x2_2442);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args) {
  V v_one_2447 = args[0];
  V v_z_2448 = args[1];
  V v_as_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_clo), 1, (V[]){v_as_244}));
  V v_x2_2450 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_z_2448}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    V v_t_2460;
    switch (heff_tag_of(v_one_2447)) {
    case TAG_MkPair: {
      V v_x11_2453 = heff_field(v_one_2447, 0);
      V v_a_2454 = heff_field(v_one_2447, 1);
      heff_take_n(v_one_2447, 3ULL, 2);
      switch (heff_tag_of(v_x11_2453)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2451)) {
        case TAG_MkPair: {
          V v_bds_2455 = heff_field(v_x_2451, 0);
          V v_as_2456 = heff_field(v_x_2451, 1);
          heff_take_n(v_x_2451, 3ULL, 2);
          v_t_2460 = heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2455, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2454, v_as_2456})});
          break;
        }
        default: heff_nomatch(v_x_2451);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2457 = heff_field(v_x11_2453, 0);
        heff_take_n(v_x11_2453, 1ULL, 1);
        switch (heff_tag_of(v_x_2451)) {
        case TAG_MkPair: {
          V v_bds_2458 = heff_field(v_x_2451, 0);
          V v_as_2459 = heff_field(v_x_2451, 1);
          heff_take_n(v_x_2451, 3ULL, 2);
          v_t_2460 = heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2457, v_bds_2458}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2454, v_as_2459})});
          break;
        }
        default: heff_nomatch(v_x_2451);
        }
        break;
      }
      default: heff_nomatch(v_x11_2453);
      }
      break;
    }
    default: heff_nomatch(v_one_2447);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2460, v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
Clo g_heff_2ecompile_2esimplify_2etagLeaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagLeaves_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etagLeaves(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return MK_INT(1000000LL);
  }
  case TAG_EGlobal: {
    return MK_INT(1000000LL);
  }
  case TAG_ELam: {
    return MK_INT(1000000LL);
  }
  case TAG_EApp: {
    return MK_INT(1000000LL);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return MK_INT(1000000LL);
  }
  case TAG_EProj: {
    return MK_INT(1000000LL);
  }
  case TAG_ETag: {
    return MK_INT(1LL);
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    return (g_list_2efoldl_24f552047357x993882406(MK_INT(0LL), v_arms_2420));
  }
  case TAG_EPrim: {
    return MK_INT(1000000LL);
  }
  case TAG_EPrimCall: {
    return MK_INT(1000000LL);
  }
  case TAG_ECall: {
    return MK_INT(1000000LL);
  }
  case TAG_EInt: {
    return MK_INT(1000000LL);
  }
  case TAG_EFloat: {
    return MK_INT(1000000LL);
  }
  case TAG_EStr: {
    return MK_INT(1000000LL);
  }
  case TAG_EBytes: {
    return MK_INT(1000000LL);
  }
  case TAG_EFixed: {
    return MK_INT(1000000LL);
  }
  case TAG_EFloat32: {
    return MK_INT(1000000LL);
  }
  case TAG_EAbandon: {
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    return MK_INT(1000000LL);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2etagLeaves_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2etagLeaves(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esumTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_a_241, 0);
    V v_arms_2422 = heff_field(v_a_241, 1);
    V v_ru_24a_241_24EMatch = heff_take_reuse_n(v_a_241, 3ULL, 2);
    V v_x_2423 = ({ V b_0 = heff_tag_at_n(v_ru_24a_241_24EMatch, TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)}); V r_ = (g_heff_2ecompile_2esimplify_2etagLeaves(b_0)); heff_drop(b_0); r_; });
    V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(2LL), heff_dup(v_x_2423)) && ({ V v_t_2425 = ({ V b_0 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)}); V r_ = (g_heff_2ecompile_2esimplify_2etagLeaves(b_0)); heff_drop(b_0); r_; }); int c_ = (heff_intLt_c(heff_dup(v_t_2425), MK_INT(1000000LL)) && ({ V v_t_2427 = ({ V b_0 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)}); V r_ = (g_heff_2ecompile_2esimplify_2etagLeaves(b_0)); heff_drop(b_0); r_; }); int c_ = ({ V v_lim_2428 = heff_intDiv(MK_INT(100LL), heff_intSub(heff_dup(v_t_2427), MK_INT(1LL))); int c_ = ({ V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2430 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2428), MK_INT(0LL), heff_dup(v_t_2429))); int c_ = (heff_intLt_c(heff_dup(v_lim_2428), heff_dup(v_x_2430)) ? 0 : ({ V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2433 = (g_heff_2ecompile_2esimplify_2escrutW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2432))); int c_ = (heff_intLt_c(MK_INT(0LL), heff_dup(v_x_2433)) && ({ V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2436 = (g_heff_2ecompile_2esimplify_2escrutW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2435))); int c_ = ({ V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2438 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_2437))); int c_ = ({ V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2440 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_240), heff_dup(v_t_2439))); int c_ = ({ V v_t_2441 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2438), heff_dup(v_t_2440)}), 0, 2); int c_ = heff_intEq_c(heff_dup(v_t_2436), heff_dup(v_t_2441)); heff_drop(v_t_2441); c_; }); heff_drop(v_t_2440); c_; }); heff_drop(v_t_2439); c_; }); heff_drop(v_t_2438); c_; }); heff_drop(v_t_2437); c_; }); heff_drop(v_t_2436); c_; }); heff_drop(v_t_2435); c_; })); heff_drop(v_x_2433); c_; }); heff_drop(v_t_2432); c_; })); heff_drop(v_x_2430); c_; }); heff_drop(v_t_2429); c_; }); heff_drop(v_lim_2428); c_; }); heff_drop(v_t_2427); c_; })); heff_drop(v_t_2425); c_; })));
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    heff_drop(v_s_2421);
    heff_drop(v_arms_2422);
    heff_drop(v_x_2423);
    return v_ret_24bool;
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumTakenApart(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ewordLiteral_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ewordLiteral(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    V v_i_2426 = heff_field(v_e_240, 0);
    V v_ret_24bool = heff_bool((heff_intLt_c(heff_dup(v_i_2426), HEFF_BIG("4611686018427387904")) && heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_i_2426))));
    return v_ret_24bool;
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ewordLiteral(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eremember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eremember_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_p_241, heff_take_field(v_s_242, 6)));
    v_t_245 = ({ V rv_6 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 447ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_t_245 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
}
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eremember(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkSafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_247;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
    v_t_247 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 3), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_245);
      v_t_247 = v_s_242;
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkSafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eraise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eraise_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eraise(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_243, v_e_240));
    if (heff_intEq_c(v_t_244, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_247 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_246, v_e_240));
      V v_x2_248 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_247, v_p_241));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_s_2410 = heff_field(v_x2_248, 1);
        V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_249), v_e_240));
        V v_x_2412 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_249, v_t_2411});
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_s_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2414, v_e_240));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2417, v_e_240));
      V v_x2_2419 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2418, v_p_241));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_s_2421 = heff_field(v_x2_2419, 1);
        V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
        V v_t_2422 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2420), v_e_240));
        V v_x_2423 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2420, v_t_2422});
        return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2421});
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2424 = heff_field(v_e_240, 0);
    V v_b_2425 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2427 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2426, v_b_2425));
    if (heff_intEq_c(v_t_2427, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_xs_2424, v_b_2425}), v_p_241});
    } else {
      V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2430 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2429, v_b_2425));
      V v_x2_2431 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2430, v_p_241));
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_MkPair: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_s_2433 = heff_field(v_x2_2431, 1);
        V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
        V v_t_2434 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_2424, heff_dup(v_x_2432)));
        V v_t_2435 = (g_heff_2ecompile_2esimplify_2estripLams(v_x_2432, v_b_2425));
        V v_x_2436 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2434, v_t_2435});
        return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2433});
      }
      default: return heff_nomatch(v_x2_2431);
      }
    }
  }
  case TAG_EApp: {
    V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2440 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2439, v_e_240));
    if (heff_intEq_c(v_t_2440, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2443 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2442, v_e_240));
      V v_x2_2444 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2443, v_p_241));
      switch (heff_tag_of(v_x2_2444)) {
      case TAG_MkPair: {
        V v_x_2445 = heff_field(v_x2_2444, 0);
        V v_s_2446 = heff_field(v_x2_2444, 1);
        V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
        V v_t_2447 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2445), v_e_240));
        V v_x_2448 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2445, v_t_2447});
        return heff_tag_at_n(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, (V[]){v_x_2448, v_s_2446});
      }
      default: return heff_nomatch(v_x2_2444);
      }
    }
  }
  case TAG_ELet: {
    V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2453 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2452, v_e_240));
    if (heff_intEq_c(v_t_2453, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2456 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2455, v_e_240));
      V v_x2_2457 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2456, v_p_241));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_t_2460 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2458), v_e_240));
        V v_x_2461 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2458, v_t_2460});
        return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_x_2461, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
  }
  case TAG_ERecord: {
    V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2465 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2464, v_e_240));
    if (heff_intEq_c(v_t_2465, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2468 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2467, v_e_240));
      V v_x2_2469 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2468, v_p_241));
      switch (heff_tag_of(v_x2_2469)) {
      case TAG_MkPair: {
        V v_x_2470 = heff_field(v_x2_2469, 0);
        V v_s_2471 = heff_field(v_x2_2469, 1);
        V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
        V v_t_2472 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2470), v_e_240));
        V v_x_2473 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2470, v_t_2472});
        return heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_MkPair, 2, (V[]){v_x_2473, v_s_2471});
      }
      default: return heff_nomatch(v_x2_2469);
      }
    }
  }
  case TAG_EProj: {
    V v_t_2478 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2479 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2478, v_e_240));
    if (heff_intEq_c(v_t_2479, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2481 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2482 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2481, v_e_240));
      V v_x2_2483 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2482, v_p_241));
      switch (heff_tag_of(v_x2_2483)) {
      case TAG_MkPair: {
        V v_x_2484 = heff_field(v_x2_2483, 0);
        V v_s_2485 = heff_field(v_x2_2483, 1);
        V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
        V v_t_2486 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2484), v_e_240));
        V v_x_2487 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2484, v_t_2486});
        return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){v_x_2487, v_s_2485});
      }
      default: return heff_nomatch(v_x2_2483);
      }
    }
  }
  case TAG_ETag: {
    V v_t_2491 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2492 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2491, v_e_240));
    if (heff_intEq_c(v_t_2492, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2494 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2495 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2494, v_e_240));
      V v_x2_2496 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2495, v_p_241));
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_s_2498 = heff_field(v_x2_2496, 1);
        V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
        V v_t_2499 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2497), v_e_240));
        V v_x_24100 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2497, v_t_2499});
        return heff_tag_at_n(v_ru_24x2_2496_24MkPair, TAG_MkPair, 2, (V[]){v_x_24100, v_s_2498});
      }
      default: return heff_nomatch(v_x2_2496);
      }
    }
  }
  case TAG_EMatch: {
    V v_t_24103 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24104 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24103, v_e_240));
    if (heff_intEq_c(v_t_24104, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24106 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24107 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24106, v_e_240));
      V v_x2_24108 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24107, v_p_241));
      switch (heff_tag_of(v_x2_24108)) {
      case TAG_MkPair: {
        V v_x_24109 = heff_field(v_x2_24108, 0);
        V v_s_24110 = heff_field(v_x2_24108, 1);
        V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
        V v_t_24111 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24109), v_e_240));
        V v_x_24112 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24109, v_t_24111});
        return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_x_24112, v_s_24110});
      }
      default: return heff_nomatch(v_x2_24108);
      }
    }
  }
  case TAG_EPrim: {
    V v_t_24114 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24115 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24114, v_e_240));
    if (heff_intEq_c(v_t_24115, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24117 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24118 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24117, v_e_240));
      V v_x2_24119 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24118, v_p_241));
      switch (heff_tag_of(v_x2_24119)) {
      case TAG_MkPair: {
        V v_x_24120 = heff_field(v_x2_24119, 0);
        V v_s_24121 = heff_field(v_x2_24119, 1);
        V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
        V v_t_24122 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24120), v_e_240));
        V v_x_24123 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24120, v_t_24122});
        return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){v_x_24123, v_s_24121});
      }
      default: return heff_nomatch(v_x2_24119);
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_24126 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24127 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24126, v_e_240));
    if (heff_intEq_c(v_t_24127, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24129 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24130 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24129, v_e_240));
      V v_x2_24131 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24130, v_p_241));
      switch (heff_tag_of(v_x2_24131)) {
      case TAG_MkPair: {
        V v_x_24132 = heff_field(v_x2_24131, 0);
        V v_s_24133 = heff_field(v_x2_24131, 1);
        V v_ru_24x2_24131_24MkPair = heff_take_reuse_n(v_x2_24131, 3ULL, 2);
        V v_t_24134 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24132), v_e_240));
        V v_x_24135 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24132, v_t_24134});
        return heff_tag_at_n(v_ru_24x2_24131_24MkPair, TAG_MkPair, 2, (V[]){v_x_24135, v_s_24133});
      }
      default: return heff_nomatch(v_x2_24131);
      }
    }
  }
  case TAG_ECall: {
    V v_t_24138 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24139 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24138, v_e_240));
    if (heff_intEq_c(v_t_24139, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24141 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24142 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24141, v_e_240));
      V v_x2_24143 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24142, v_p_241));
      switch (heff_tag_of(v_x2_24143)) {
      case TAG_MkPair: {
        V v_x_24144 = heff_field(v_x2_24143, 0);
        V v_s_24145 = heff_field(v_x2_24143, 1);
        V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
        V v_t_24146 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24144), v_e_240));
        V v_x_24147 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24144, v_t_24146});
        return heff_tag_at_n(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){v_x_24147, v_s_24145});
      }
      default: return heff_nomatch(v_x2_24143);
      }
    }
  }
  case TAG_EInt: {
    V v_t_24149 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24150 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24149, v_e_240));
    if (heff_intEq_c(v_t_24150, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24152 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24153 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24152, v_e_240));
      V v_x2_24154 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24153, v_p_241));
      switch (heff_tag_of(v_x2_24154)) {
      case TAG_MkPair: {
        V v_x_24155 = heff_field(v_x2_24154, 0);
        V v_s_24156 = heff_field(v_x2_24154, 1);
        V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
        V v_t_24157 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24155), v_e_240));
        V v_x_24158 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24155, v_t_24157});
        return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){v_x_24158, v_s_24156});
      }
      default: return heff_nomatch(v_x2_24154);
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24160 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24161 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24160, v_e_240));
    if (heff_intEq_c(v_t_24161, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24163 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24164 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24163, v_e_240));
      V v_x2_24165 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24164, v_p_241));
      switch (heff_tag_of(v_x2_24165)) {
      case TAG_MkPair: {
        V v_x_24166 = heff_field(v_x2_24165, 0);
        V v_s_24167 = heff_field(v_x2_24165, 1);
        V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
        V v_t_24168 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24166), v_e_240));
        V v_x_24169 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24166, v_t_24168});
        return heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_MkPair, 2, (V[]){v_x_24169, v_s_24167});
      }
      default: return heff_nomatch(v_x2_24165);
      }
    }
  }
  case TAG_EStr: {
    V v_t_24171 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24172 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24171, v_e_240));
    if (heff_intEq_c(v_t_24172, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24174 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24175 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24174, v_e_240));
      V v_x2_24176 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24175, v_p_241));
      switch (heff_tag_of(v_x2_24176)) {
      case TAG_MkPair: {
        V v_x_24177 = heff_field(v_x2_24176, 0);
        V v_s_24178 = heff_field(v_x2_24176, 1);
        V v_ru_24x2_24176_24MkPair = heff_take_reuse_n(v_x2_24176, 3ULL, 2);
        V v_t_24179 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24177), v_e_240));
        V v_x_24180 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24177, v_t_24179});
        return heff_tag_at_n(v_ru_24x2_24176_24MkPair, TAG_MkPair, 2, (V[]){v_x_24180, v_s_24178});
      }
      default: return heff_nomatch(v_x2_24176);
      }
    }
  }
  case TAG_EBytes: {
    V v_t_24182 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24183 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24182, v_e_240));
    if (heff_intEq_c(v_t_24183, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24185 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24186 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24185, v_e_240));
      V v_x2_24187 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24186, v_p_241));
      switch (heff_tag_of(v_x2_24187)) {
      case TAG_MkPair: {
        V v_x_24188 = heff_field(v_x2_24187, 0);
        V v_s_24189 = heff_field(v_x2_24187, 1);
        V v_ru_24x2_24187_24MkPair = heff_take_reuse_n(v_x2_24187, 3ULL, 2);
        V v_t_24190 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24188), v_e_240));
        V v_x_24191 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24188, v_t_24190});
        return heff_tag_at_n(v_ru_24x2_24187_24MkPair, TAG_MkPair, 2, (V[]){v_x_24191, v_s_24189});
      }
      default: return heff_nomatch(v_x2_24187);
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24194 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24195 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24194, v_e_240));
    if (heff_intEq_c(v_t_24195, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24197 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24198 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24197, v_e_240));
      V v_x2_24199 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24198, v_p_241));
      switch (heff_tag_of(v_x2_24199)) {
      case TAG_MkPair: {
        V v_x_24200 = heff_field(v_x2_24199, 0);
        V v_s_24201 = heff_field(v_x2_24199, 1);
        V v_ru_24x2_24199_24MkPair = heff_take_reuse_n(v_x2_24199, 3ULL, 2);
        V v_t_24202 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24200), v_e_240));
        V v_x_24203 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24200, v_t_24202});
        return heff_tag_at_n(v_ru_24x2_24199_24MkPair, TAG_MkPair, 2, (V[]){v_x_24203, v_s_24201});
      }
      default: return heff_nomatch(v_x2_24199);
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24205 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24206 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24205, v_e_240));
    if (heff_intEq_c(v_t_24206, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24208 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24209 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24208, v_e_240));
      V v_x2_24210 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24209, v_p_241));
      switch (heff_tag_of(v_x2_24210)) {
      case TAG_MkPair: {
        V v_x_24211 = heff_field(v_x2_24210, 0);
        V v_s_24212 = heff_field(v_x2_24210, 1);
        V v_ru_24x2_24210_24MkPair = heff_take_reuse_n(v_x2_24210, 3ULL, 2);
        V v_t_24213 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24211), v_e_240));
        V v_x_24214 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24211, v_t_24213});
        return heff_tag_at_n(v_ru_24x2_24210_24MkPair, TAG_MkPair, 2, (V[]){v_x_24214, v_s_24212});
      }
      default: return heff_nomatch(v_x2_24210);
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24215 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24216 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24215, v_e_240));
    if (heff_intEq_c(v_t_24216, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24218 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24219 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24218, v_e_240));
      V v_x2_24220 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24219, v_p_241));
      switch (heff_tag_of(v_x2_24220)) {
      case TAG_MkPair: {
        V v_x_24221 = heff_field(v_x2_24220, 0);
        V v_s_24222 = heff_field(v_x2_24220, 1);
        V v_ru_24x2_24220_24MkPair = heff_take_reuse_n(v_x2_24220, 3ULL, 2);
        V v_t_24223 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24221), v_e_240));
        V v_x_24224 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24221, v_t_24223});
        return heff_tag_at_n(v_ru_24x2_24220_24MkPair, TAG_MkPair, 2, (V[]){v_x_24224, v_s_24222});
      }
      default: return heff_nomatch(v_x2_24220);
      }
    }
  }
  case TAG_EFix: {
    V v_t_24227 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24228 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24227, v_e_240));
    if (heff_intEq_c(v_t_24228, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24230 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24231 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24230, v_e_240));
      V v_x2_24232 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24231, v_p_241));
      switch (heff_tag_of(v_x2_24232)) {
      case TAG_MkPair: {
        V v_x_24233 = heff_field(v_x2_24232, 0);
        V v_s_24234 = heff_field(v_x2_24232, 1);
        V v_ru_24x2_24232_24MkPair = heff_take_reuse_n(v_x2_24232, 3ULL, 2);
        V v_t_24235 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24233), v_e_240));
        V v_x_24236 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24233, v_t_24235});
        return heff_tag_at_n(v_ru_24x2_24232_24MkPair, TAG_MkPair, 2, (V[]){v_x_24236, v_s_24234});
      }
      default: return heff_nomatch(v_x2_24232);
      }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eraise(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2eversAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eversAll_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eversAll(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2eversAll_str0), 2)) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        V v_x2_245 = (g_heff_2ecompile_2esimplify_2eversAll(v_rest_242));
        switch (heff_tag_of(v_x2_245)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_vs_246 = heff_field(v_x2_245, 0);
          heff_take_n(v_x2_245, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_246})});
        }
        default: return heff_nomatch(v_x2_245);
        }
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eversAll(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAsk_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeptAsk(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_x3_244 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_h_240);
    heff_drop(v_v_241);
    heff_drop(v_t_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
  } else {
    heff_drop(v_t_246);
    V v_k_247 = heff_take_field(v_s_242, 8);
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_v_241, heff_take_field(v_k_247, 0)));
    V v_k_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_k_247, 30ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2410 = ({ V rv_8 = v_k_249; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2410});
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 2ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2413), heff_dup(v_h_240)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_h_240);
        return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2413});
      }
      case TAG_Just: {
        V v_kc_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        return ({ V a_0 = v_h_240; V a_1 = v_kc_2415; V a_2 = v_t_2416; V a_3 = v_s_2413; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAsk(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emadeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeKept_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeKept(V v_km_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_km_240, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_get_n(v_km_240, 1, 2), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop(v_x_245);
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      } else {
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeKept(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eask_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2eask(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2411 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_h_246); V a_2 = heff_dup(v_g_241); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecopyVer(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  V v_x2_2412 = (g_heff_2ecompile_2esimplify_2etouch(heff_dup(v_h_246), v_t_2411, heff_dup(v_s_248)));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 2ULL, 2);
    V v_t_2415 = heff_get_n(heff_get_n(v_s_248, 7, 9), 2, 7);
    V v_x3_2416 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x3_2416)) {
    case TAG_Nothing: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2416, 0ULL, 1);
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2416);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_marks_244);
      heff_drop_rec(v_sh_245, 3);
      heff_drop(v_h_246);
      heff_drop(v_d_247);
      heff_drop(v_t_2418);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2414});
    } else {
      heff_drop(v_t_2418);
      V v_t_2419 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2414), heff_dup(v_h_246)));
      V v_x2_2422;
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        v_x2_2422 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2414});
        break;
      }
      case TAG_Just: {
        V v_kc_2420 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
        V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2420, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2422 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_kc_2420; V a_2 = v_t_2421; V a_3 = v_s_2414; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
        break;
      }
      default: heff_nomatch(v_t_2419);
      }
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
          heff_drop(v_r_240);
          heff_drop(v_g_241);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_244);
          heff_drop_rec(v_sh_245, 3);
          heff_drop(v_h_246);
          heff_drop(v_d_247);
          heff_drop(v_x_2423);
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2424});
        } else {
          heff_drop(v_x_2423);
          V v_x2_2425 = (g_heff_2ecompile_2esimplify_2ecopy(heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_s_2424));
          switch (heff_tag_of(v_x2_2425)) {
          case TAG_MkPair: {
            V v_x_2426 = heff_field(v_x2_2425, 0);
            V v_s_2427 = heff_field(v_x2_2425, 1);
            heff_take_n(v_x2_2425, 3ULL, 2);
            V v_m_2428 = (g_heff_2ecompile_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2426));
            V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2427}));
            switch (heff_tag_of(v_x2_2429)) {
            case TAG_MkPair: {
              V v_x_2430 = heff_field(v_x2_2429, 0);
              V v_s_2431 = heff_field(v_x2_2429, 1);
              heff_take_n(v_x2_2429, 3ULL, 2);
              V v_x2_2432 = (g_heff_2ecompile_2esimplify_2eknowing(v_r_240, v_x_2430, v_s_2431));
              switch (heff_tag_of(v_x2_2432)) {
              case TAG_MkPair: {
                V v_x_2433 = heff_field(v_x2_2432, 0);
                V v_s_2434 = heff_field(v_x2_2432, 1);
                heff_take_n(v_x2_2432, 3ULL, 2);
                V v_x2_2435 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_246), heff_dup(v_x_2433), v_d_247, v_s_2434));
                switch (heff_tag_of(v_x2_2435)) {
                case TAG_MkPair: {
                  V v_s_2437 = heff_field(v_x2_2435, 1);
                  heff_take_n(v_x2_2435, 2ULL, 2);
                  V v_k_2438 = heff_take_field(v_s_2437, 8);
                  V v_t_2439 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_246), NTAG(TAG_MkUnit), heff_take_field(v_k_2438, 3)));
                  V v_k_2440 = ({ V rv_3 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_k_2438, 23ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                  V v_t_2441 = ({ V rv_8 = v_k_2440; V rr_ = heff_rec_reuse_nf(v_s_2437, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
                  V v_x2_2442 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2441});
                  switch (heff_tag_of(v_x2_2442)) {
                  case TAG_MkPair: {
                    V v_s_2444 = heff_field(v_x2_2442, 1);
                    heff_take_n(v_x2_2442, 2ULL, 2);
                    return ({ V a_0 = v_h_246; V a_1 = v_x_2433; V a_2 = v_s_2444; V r_ = (g_heff_2ecompile_2esimplify_2emarkCopySafe(a_0, a_1, a_2)); heff_drop(v_x_2433); r_; });
                  }
                  default: return heff_nomatch(v_x2_2442);
                  }
                }
                default: return heff_nomatch(v_x2_2435);
                }
              }
              default: return heff_nomatch(v_x2_2432);
              }
            }
            default: return heff_nomatch(v_x2_2429);
            }
          }
          default: return heff_nomatch(v_x2_2425);
          }
        }
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eask(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_t_2414);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_247});
  } else {
    heff_drop(v_t_2414);
    V v_k_2416 = (g_heff_2ecompile_2esimplify_2especKey(heff_dup(v_g_241), heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 1)), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_j_2417 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_str0), v_g_241, MK_INT(0LL), 5);
    V v_t_2419;
    if (heff_intLt_c(heff_dup(v_j_2417), MK_INT(0LL))) {
      heff_drop(v_j_2417);
      v_t_2419 = heff_dup(v_g_241);
    } else {
      v_t_2419 = heff_strSlice_lent(v_g_241, MK_INT(0LL), v_j_2417, 6);
    }
    V v_t_2420 = (g_heff_2ecompile_2espec_2ehashGo(v_k_2416, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    V v_t_2421 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str1), v_t_2420));
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2424 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2423; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_sh_246, v_t_2421, v_t_2424, v_s_247));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_x1_2412 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_x1_2412);
          V v_x2_2413 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x2_2413, 0);
            V v_s_2415 = heff_field(v_x2_2413, 1);
            heff_take_n(v_x2_2413, 3ULL, 2);
            return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2414, v_s_2415));
          }
          default: return heff_nomatch(v_x2_2413);
          }
        } else {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          heff_drop(v_x1_2412);
          V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_z_246});
        }
      } else {
        heff_drop(v_t_2411);
        V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2418, v_s_2419));
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_x1_248, 0ULL, 2);
      V v_x2_2422 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2423, v_s_2424));
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_x1_247);
    V v_x_2425 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V v_ms_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_ms_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), v_ms_240);
  }
  case TAG_Cons: {
    V v_m_243 = heff_dup(heff_field(v_ms_240, 0));
    V v_ms2_244 = heff_dup(heff_field(v_ms_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_ms_240);
    }
    case TAG_Cons: {
      V v_n_245 = heff_field(v_x2_241, 0);
      V v_ns_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_ms_240, 2);
      V v_t_247;
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop(v_n_245);
        v_t_247 = NTAG(TAG_True);
      } else {
        heff_drop(v_m_243);
        v_t_247 = v_n_245;
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ms2_244;
      V t_1 = v_ns_246;
      V t_2 = v_cell_248;
      v_ms_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_ms_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eetaOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaOne(V v_r_240, V v_e_241, V v_k_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ELam: {
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EApp: {
    V v_h_248 = heff_field(v_e_241, 0);
    V v_bs_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_x2_2410 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_bs_249, heff_dup(v_p_243)));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_x2_2413 = (g_heff_2ecompile_2esimplify_2efreshParams(v_k_242, v_s_2412));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_t_2418;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_MkPair: {
          V v_y_2417 = heff_dup(heff_field(v_x_2411, 1));
          v_t_2418 = v_y_2417;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2419 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2414)));
        V v_t_2420 = (g_heff_2ecompile_2esimplify_2eappendL(v_t_2418, v_t_2419));
        V v_m_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_h_248, v_t_2420}));
        V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2415}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_s_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaKept(v_p_243, v_x_2411, heff_tag_at_n(v_ru_24e_241_24EApp, TAG_ELam, 2, (V[]){v_x_2414, v_x_2423}), v_s_2424);
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ERecord: {
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EMatch: {
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ECall: {
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFixed: {
    V v_ru_24e_241_24EFixed = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFix: {
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaOne(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eetaArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArg_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eetaArg(V v_r_240, V v_st_241, V v_a_242, V v_rest_243, V v_s_244) {
top: ;
  V v_k_245 = (g_heff_2ecompile_2esimplify_2emissingOf(heff_dup(v_s_244), v_a_242));
  V v_x2_247;
  if ((heff_dup(v_st_241) == NTAG(TAG_True))) {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_k_245))) {
      v_x2_247 = (g_heff_2ecompile_2esimplify_2eetaOne(v_r_240, heff_dup(v_a_242), v_k_245, v_s_244));
    } else {
      heff_drop(v_r_240);
      heff_drop(v_k_245);
      v_x2_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_244});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_k_245);
    v_x2_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_244});
  }
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_x_2418;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_rest_2410 = heff_field(v_rest_243, 0);
        V v_as_2411 = heff_field(v_rest_243, 1);
        heff_take_n(v_rest_243, 3ULL, 2);
        v_x_2418 = heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_as_2411})});
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      break;
    }
    case TAG_Just: {
      V v_x21_2412 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      heff_drop(v_a_242);
      switch (heff_tag_of(v_x21_2412)) {
      case TAG_MkPair: {
        V v_bds_2413 = heff_field(v_x21_2412, 0);
        V v_lam1_2414 = heff_field(v_x21_2412, 1);
        heff_take_n(v_x21_2412, 3ULL, 2);
        switch (heff_tag_of(v_rest_243)) {
        case TAG_MkPair: {
          V v_rest_2415 = heff_field(v_rest_243, 0);
          V v_as_2416 = heff_field(v_rest_243, 1);
          heff_take_n(v_rest_243, 3ULL, 2);
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(v_bds_2413, v_rest_2415));
          v_x_2418 = heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_lam1_2414, v_as_2416})});
          break;
        }
        default: heff_nomatch(v_rest_243);
        }
        break;
      }
      default: heff_nomatch(v_x21_2412);
      }
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_s_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaArg(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArgs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaArgs(V v_r_240, V v_x2_241, V v_as_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam0, 1, 1, (V[]){v_as_242});
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x2_241, 0);
    V v_sts_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_as_242)) {
    case TAG_Nil: {
      heff_drop(v_r_240);
      heff_drop(v_st_245);
      heff_drop(v_sts_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam1, 1, 1, (V[]){v_as_242});
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_as_242, 0);
      V v_as2_2410 = heff_field(v_as_242, 1);
      heff_take_n(v_as_242, 3ULL, 2);
      V v_m_2411 = (g_heff_2ecompile_2esimplify_2eetaArgs(heff_dup(v_r_240), v_sts_246, v_as2_2410));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam2, 1, 4, (V[]){v_m_2411, v_a_249, v_r_240, v_st_245});
    }
    default: return heff_nomatch(v_as_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_as_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_as_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_s_243});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_as_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_as_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_st_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2eletsOut(v_a_249));
    return ({ V a_0 = v_r_240; V a_1 = v_st_245; V a_2 = v_t_2416; V a_3 = v_x_2414; V a_4 = v_s_2415; V r_ = (g_heff_2ecompile_2esimplify_2eetaLets(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_245); r_; });
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
Clo g_heff_2ecompile_2esimplify_2eetaMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaMade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaMade(V v_a_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_x1_246 = (g_heff_2ecompile_2esimplify_2eletsOut(v_a_240));
    V v_t_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkPair: {
      V v_y_248 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 2ULL, 2);
      v_t_249 = v_y_248;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_EVar: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_ELet: {
      heff_take_n(v_t_249, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_ERecord: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_EProj: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_True);
    }
    case TAG_ETag: {
      heff_take_n(v_t_249, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_EMatch: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_EPrim: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_ECall: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_EInt: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      heff_take_na(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_True);
    }
    case TAG_EFix: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EApp: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaMade(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldIn(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_244, v_l_240, 0)) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efieldIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eknownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownField_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_it_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Just = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_EVar: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELam: {
      V v_ru_24it1_245_24ELam = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EApp: {
      V v_ru_24it1_245_24EApp = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_it1_245, 0);
      V v_ru_24it1_245_24ERecord = heff_take_reuse_n(v_it1_245, 1ULL, 2);
      V v_t_2417 = ({ V a_0 = v_l_241; V a_1 = v_fs_2415; V r_ = (g_heff_2ecompile_2esimplify_2efieldIn(a_0, a_1)); heff_drop(v_fs_2415); r_; });
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24it_244_24Just, 1);
        return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
      }
      case TAG_Just: {
        V v_v_2418 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        V v_t_2419 = (g_heff_2ecompile_2eir_2eisValue(v_v_2418));
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_t_2419);
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
            V v_t_2421 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
            V v_t_2422 = ({ V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_s_242, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_x2_2423 = (g_heff_2ecompile_2esimplify_2ecopy(v_v_2418, v_t_2422));
            switch (heff_tag_of(v_x2_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_x2_2423, 0);
              V v_s_2425 = heff_field(v_x2_2423, 1);
              heff_take_n(v_x2_2423, 3ULL, 2);
              return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it_244_24Just, TAG_Just, 1, (V[]){v_x_2424}), v_s_2425});
            }
            default: return heff_nomatch(v_x2_2423);
            }
          } else {
            heff_drop_cell(v_ru_24it_244_24Just, 1);
            heff_drop(v_v_2418);
            return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
          }
        } else {
          heff_drop_cell(v_ru_24it_244_24Just, 1);
          heff_drop(v_v_2418);
          heff_drop(v_t_2419);
          return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
        }
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    case TAG_EProj: {
      heff_take_n(v_it1_245, 0ULL, 4);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ETag: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EMatch: {
      V v_ru_24it1_245_24EMatch = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_245_24EPrimCall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ECall: {
      V v_ru_24it1_245_24ECall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFixed: {
      V v_ru_24it1_245_24EFixed = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat32: {
      heff_take_na(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFix: {
      V v_ru_24it1_245_24EFix = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownField(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2eany_24s1107779796x153132813(v_arms2_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), heff_dup(v_arms_243)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms2_242));
    V v_t_249 = heff_intMul(v_t_247, heff_intSub(v_t_248, MK_INT(1LL)));
    if (heff_intLe_c(v_t_249, MK_INT(40LL))) {
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0, 1, 4, (V[]){v_r_240, v_arms_243, v_arms2_242, v_s2_241});
    } else {
      heff_drop(v_r_240);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_arms_243 = heff_env(self)[1];
  V v_arms2_242 = heff_env(self)[2];
  V v_s2_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2412 = (g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(v_r_240, v_arms_243, v_arms2_242, v_s_2411));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_s_2415});
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam1, 2, 0};
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam2, 4, 0};
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2ecompile_2esimplify_2esk_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2esk_st;
static V g_heff_2ecompile_2esimplify_2esk_init(void) {
  return heff_rec_n(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2ecompile_2esimplify_2esk_lam0_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam1_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam2_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam3_clo)});
}
V g_heff_2ecompile_2esimplify_2esk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2esk_st)) return g_heff_2ecompile_2esimplify_2esk_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2esk_val, &g_heff_2ecompile_2esimplify_2esk_st, g_heff_2ecompile_2esimplify_2esk_init);
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_as_242 = args[1];
  return (g_heff_2ecompile_2esimplify_2eapplyToF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_f_241, v_as_242));
}
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_sh_244 = args[1];
  V v_t_245 = args[2];
  V v_e_246 = args[3];
  return (g_heff_2ecompile_2esimplify_2eprojectF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_l_243, v_sh_244, v_t_245, v_e_246));
}
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_247 = args[0];
  V v_arms_248 = args[1];
  return (g_heff_2ecompile_2esimplify_2ematchF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_s_247, v_arms_248));
}
Clo g_heff_2ecompile_2esimplify_2erecordDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordDef_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_247 = v_s_242;
  } else {
    heff_drop(v_t_245);
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), heff_take_field(v_s_242, 2)));
    v_t_247 = ({ V rv_2 = v_d_246; V rr_ = heff_rec_reuse_nf(v_s_242, 507ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  V v_t_248 = (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247));
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordDef(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emadeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOne_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emadeOne(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2410 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_247, v_t_248, v_t_249});
  V v_t_2411 = ({ V rv_7 = v_p_2410; V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2411});
}
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eafresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eafresh_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eafresh(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_n_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop(v_n_243);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_p_241});
    }
    case TAG_Just: {
      V v_d_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24MkPair, 2);
      V v_t_246 = ({ V rv_0 = v_n_243; V rr_ = heff_rec_reuse_nf(v_p_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef(v_d_245, v_t_246);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eafresh(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str1, 0, "");
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeOf(V v_st_240, V v_bodies_241, V v_h_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_244 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_246));
    V v_tv_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2emadeOf_lam0, 1, 1, (V[]){v_st_240}), v_t_247));
    V v_x2_2414 = (g_map_2elookup_24s1546226666x2146984184(v_h_242, v_bodies_241));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      heff_drop(v_tv_2413);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_b_2415 = heff_field(v_x2_2414, 0);
      heff_take_n(v_x2_2414, 1ULL, 1);
      V v_t_2416 = (g_list_2eall_24s1194065168x228565983(((V)&g_heff_2ecompile_2esimplify_2emadeOf_str1), v_tv_2413));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_tv_2413})});
      } else {
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        heff_drop(v_tv_2413);
        heff_drop(v_b_2415);
        heff_drop(v_t_2416);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emadeOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args) {
  V v_h_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_get_n(heff_get_n(v_st_240, 8, 9), 0, 5);
  V v_x2_2410 = ({ V a_0 = heff_dup(v_h_248); V a_1 = v_t_249; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_248, v_t_2412});
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(a[0], a[1]);
}