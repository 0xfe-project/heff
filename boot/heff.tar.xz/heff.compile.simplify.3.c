// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
V g_heff_2ecompile_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedFor_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ecaseBudget_get(void);
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efieldIn(V, V);
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldIn_clo;
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2eintOp(V, V, V);
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eintOp_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeptAsk(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknowing(V, V, V);
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknowing_clo;
V g_heff_2ecompile_2esimplify_2eknown(V, V);
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknown_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emadeOne(V, V);
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOne_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkSafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo;
V g_heff_2ecompile_2esimplify_2emarkSafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epushArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushArm_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2eremember(V, V, V);
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eremember_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2esafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esafeAs_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especBodySize_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etouch(V, V, V);
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etouch_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2eversAll(V);
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eversAll_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall_24s455618083x1946283732(V, V);
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a);
extern Clo g_list_2eall_24s455618083x1946283732_clo;
V g_list_2eany_24s1107779796x153132813(V);
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a);
extern Clo g_list_2eany_24s1107779796x153132813_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1748401606x190338434(V, V);
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1748401606x190338434_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2ezipWith_24s237481877x1031762735(V, V, V);
V g_list_2ezipWith_24s237481877x1031762735_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s237481877x1031762735_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str11, 5, "False");
Clo g_heff_2ecompile_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str0))) {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str1))) {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str2))) {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      } else {
        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str3))) {
          heff_drop(v_p_240);
          V v_t_2411;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str4);
          } else {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str5);
          }
          V v_t_2412 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        } else {
          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str6))) {
            heff_drop(v_p_240);
            V v_t_2415;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str7);
            } else {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str8);
            }
            V v_t_2416 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
          } else {
            if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str9))) {
              V v_t_2419;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str10);
              } else {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str11);
              }
              V v_t_2420 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eintOp(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str1, 9, "strLength");
Clo g_heff_2ecompile_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2426 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str0))) {
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2426)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
    } else {
      heff_drop(v_a_2426);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2430 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str1))) {
      V v_t_2432 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2430)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
    } else {
      heff_drop(v_a_2430);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str3, 5, "False");
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2452 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp(v_p_240, v_a_2427, v_b_2452);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2462 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2489 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str0))) {
        heff_drop(v_p_240);
        V v_t_2491 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2462, v_b_2489)});
        return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2491});
      } else {
        heff_drop_cell(v_ru_24x3_242_24EStr, 1);
        if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str1))) {
          V v_t_2494;
          if (heff_strEq_c(v_a_2462, v_b_2489)) {
            v_t_2494 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str2);
          } else {
            v_t_2494 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str3);
          }
          V v_t_2495 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2494, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){v_t_2495});
        } else {
          heff_drop(v_a_2462);
          heff_drop_cell(v_ru_24x2_241_24EStr, 1);
          heff_drop(v_b_2489);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2462);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_242, v_s_244));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
      heff_drop(v_x_246);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_248));
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2410));
      V v_t_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_249, v_t_2411}), 0, 2);
      V v_t_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2412));
      return heff_tail(v_t_2413, 1, (V[]){v_s_247});
    } else {
      heff_drop(v_x_246);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2epartialApp(heff_dup(v_s_247), v_a_242));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
        heff_drop(v_t_2414);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_247);
      } else {
        heff_drop(v_t_2414);
        V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_247}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          heff_take_n(v_x2_2416, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2417}), v_s_2418});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eremember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eremember_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_p_241, heff_take_field(v_s_242, 6)));
    v_t_245 = ({ V rv_6 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 447ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_t_245 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
}
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eremember(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkSafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_247;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
    v_t_247 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    heff_drop(v_t_243);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 3), heff_rfield(v_s_242, 5), v_b_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_h_240);
      heff_drop(v_t_245);
      v_t_247 = v_s_242;
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkSafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2easkedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedFor_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkedFor(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_245 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_244));
  V v_t_248;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), v_x_245)) {
    v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  } else {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b0_241), v_t_247));
  }
  V v_t_2442;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2444;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    v_t_2444 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_2443));
  } else {
    heff_drop(v_t_2442);
    v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
  }
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2446 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_b0_241, v_t_2445));
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2448 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_d_242, v_t_2447));
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2452 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2444, v_t_2446, v_t_2448, v_t_2449, heff_intAdd(v_t_2450, MK_INT(1LL)), v_t_2451});
  V v_t_2453 = ({ V rv_7 = v_p_2452; V rr_ = heff_rec_reuse_nf(v_s_243, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2453});
}
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2easkedFor(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2eraise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eraise_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eraise(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_245 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        V v_t_249 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_247), v_e_240));
        V v_x_2410 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_ELam, 2, (V[]){v_x_247, v_t_249});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_s_248});
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2412, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2415 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2414, v_p_241));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_s_2417 = heff_field(v_x2_2415, 1);
        V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2416), v_e_240));
        V v_x_2419 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_ELam, 2, (V[]){v_x_2416, v_t_2418});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2417});
      }
      default: return heff_nomatch(v_x2_2415);
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2420 = heff_field(v_e_240, 0);
    V v_b_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_b_2421));
    if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
      return heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2420, v_b_2421}), v_p_241});
    } else {
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_b_2421));
      V v_x2_2425 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2424, v_p_241));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_s_2427 = heff_field(v_x2_2425, 1);
        V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
        V v_t_2428 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_2420, heff_dup(v_x_2426)));
        V v_t_2429 = (g_heff_2ecompile_2esimplify_2estripLams(v_x_2426, v_b_2421));
        V v_x_2430 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2428, v_t_2429});
        return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){v_x_2430, v_s_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
  }
  case TAG_EApp: {
    V v_t_2433 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2433, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2435 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2436 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2435, v_p_241));
      switch (heff_tag_of(v_x2_2436)) {
      case TAG_MkPair: {
        V v_x_2437 = heff_field(v_x2_2436, 0);
        V v_s_2438 = heff_field(v_x2_2436, 1);
        V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
        V v_t_2439 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2437), v_e_240));
        V v_x_2440 = heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_ELam, 2, (V[]){v_x_2437, v_t_2439});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2440, v_s_2438});
      }
      default: return heff_nomatch(v_x2_2436);
      }
    }
  }
  case TAG_ELet: {
    V v_t_2444 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2444, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2446 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2447 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2446, v_p_241));
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_s_2449 = heff_field(v_x2_2447, 1);
        V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
        V v_t_2450 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2448), v_e_240));
        V v_x_2451 = heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_ELam, 2, (V[]){v_x_2448, v_t_2450});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_2449});
      }
      default: return heff_nomatch(v_x2_2447);
      }
    }
  }
  case TAG_ERecord: {
    V v_t_2454 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2454, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2456 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2457 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2456, v_p_241));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_t_2460 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2458), v_e_240));
        V v_x_2461 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_ELam, 2, (V[]){v_x_2458, v_t_2460});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2461, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
  }
  case TAG_EProj: {
    V v_t_2466 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2466, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2468 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2469 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2468, v_p_241));
      switch (heff_tag_of(v_x2_2469)) {
      case TAG_MkPair: {
        V v_x_2470 = heff_field(v_x2_2469, 0);
        V v_s_2471 = heff_field(v_x2_2469, 1);
        V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
        V v_t_2472 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2470), v_e_240));
        V v_x_2473 = heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_ELam, 2, (V[]){v_x_2470, v_t_2472});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2473, v_s_2471});
      }
      default: return heff_nomatch(v_x2_2469);
      }
    }
  }
  case TAG_ETag: {
    V v_t_2476 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2476, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2478 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2479 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2478, v_p_241));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
        V v_t_2482 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2480), v_e_240));
        V v_x_2483 = heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_ELam, 2, (V[]){v_x_2480, v_t_2482});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2483, v_s_2481});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
  }
  case TAG_EMatch: {
    V v_t_2486 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2486, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2488 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2489 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2488, v_p_241));
      switch (heff_tag_of(v_x2_2489)) {
      case TAG_MkPair: {
        V v_x_2490 = heff_field(v_x2_2489, 0);
        V v_s_2491 = heff_field(v_x2_2489, 1);
        V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
        V v_t_2492 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2490), v_e_240));
        V v_x_2493 = heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_ELam, 2, (V[]){v_x_2490, v_t_2492});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2493, v_s_2491});
      }
      default: return heff_nomatch(v_x2_2489);
      }
    }
  }
  case TAG_EPrim: {
    V v_t_2495 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2495, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2497 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2498 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2497, v_p_241));
      switch (heff_tag_of(v_x2_2498)) {
      case TAG_MkPair: {
        V v_x_2499 = heff_field(v_x2_2498, 0);
        V v_s_24100 = heff_field(v_x2_2498, 1);
        V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
        V v_t_24101 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2499), v_e_240));
        V v_x_24102 = heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_ELam, 2, (V[]){v_x_2499, v_t_24101});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24102, v_s_24100});
      }
      default: return heff_nomatch(v_x2_2498);
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_24105 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24105, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24107 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24108 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24107, v_p_241));
      switch (heff_tag_of(v_x2_24108)) {
      case TAG_MkPair: {
        V v_x_24109 = heff_field(v_x2_24108, 0);
        V v_s_24110 = heff_field(v_x2_24108, 1);
        V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
        V v_t_24111 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24109), v_e_240));
        V v_x_24112 = heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_ELam, 2, (V[]){v_x_24109, v_t_24111});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24112, v_s_24110});
      }
      default: return heff_nomatch(v_x2_24108);
      }
    }
  }
  case TAG_ECall: {
    V v_t_24115 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24115, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24117 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24118 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24117, v_p_241));
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_MkPair: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        V v_s_24120 = heff_field(v_x2_24118, 1);
        V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
        V v_t_24121 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24119), v_e_240));
        V v_x_24122 = heff_tag_at_n(v_ru_24x2_24118_24MkPair, TAG_ELam, 2, (V[]){v_x_24119, v_t_24121});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24122, v_s_24120});
      }
      default: return heff_nomatch(v_x2_24118);
      }
    }
  }
  case TAG_EInt: {
    V v_t_24124 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24124, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24126 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24127 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24126, v_p_241));
      switch (heff_tag_of(v_x2_24127)) {
      case TAG_MkPair: {
        V v_x_24128 = heff_field(v_x2_24127, 0);
        V v_s_24129 = heff_field(v_x2_24127, 1);
        V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
        V v_t_24130 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24128), v_e_240));
        V v_x_24131 = heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_ELam, 2, (V[]){v_x_24128, v_t_24130});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24131, v_s_24129});
      }
      default: return heff_nomatch(v_x2_24127);
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24133 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24133, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24135 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24136 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24135, v_p_241));
      switch (heff_tag_of(v_x2_24136)) {
      case TAG_MkPair: {
        V v_x_24137 = heff_field(v_x2_24136, 0);
        V v_s_24138 = heff_field(v_x2_24136, 1);
        V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
        V v_t_24139 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24137), v_e_240));
        V v_x_24140 = heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_ELam, 2, (V[]){v_x_24137, v_t_24139});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24140, v_s_24138});
      }
      default: return heff_nomatch(v_x2_24136);
      }
    }
  }
  case TAG_EStr: {
    V v_t_24142 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24142, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24144 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24145 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24144, v_p_241));
      switch (heff_tag_of(v_x2_24145)) {
      case TAG_MkPair: {
        V v_x_24146 = heff_field(v_x2_24145, 0);
        V v_s_24147 = heff_field(v_x2_24145, 1);
        V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
        V v_t_24148 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24146), v_e_240));
        V v_x_24149 = heff_tag_at_n(v_ru_24x2_24145_24MkPair, TAG_ELam, 2, (V[]){v_x_24146, v_t_24148});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24149, v_s_24147});
      }
      default: return heff_nomatch(v_x2_24145);
      }
    }
  }
  case TAG_EBytes: {
    V v_t_24151 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24151, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24153 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24154 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24153, v_p_241));
      switch (heff_tag_of(v_x2_24154)) {
      case TAG_MkPair: {
        V v_x_24155 = heff_field(v_x2_24154, 0);
        V v_s_24156 = heff_field(v_x2_24154, 1);
        V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
        V v_t_24157 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24155), v_e_240));
        V v_x_24158 = heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_ELam, 2, (V[]){v_x_24155, v_t_24157});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24158, v_s_24156});
      }
      default: return heff_nomatch(v_x2_24154);
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24161 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24161, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24163 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24164 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24163, v_p_241));
      switch (heff_tag_of(v_x2_24164)) {
      case TAG_MkPair: {
        V v_x_24165 = heff_field(v_x2_24164, 0);
        V v_s_24166 = heff_field(v_x2_24164, 1);
        V v_ru_24x2_24164_24MkPair = heff_take_reuse_n(v_x2_24164, 3ULL, 2);
        V v_t_24167 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24165), v_e_240));
        V v_x_24168 = heff_tag_at_n(v_ru_24x2_24164_24MkPair, TAG_ELam, 2, (V[]){v_x_24165, v_t_24167});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24168, v_s_24166});
      }
      default: return heff_nomatch(v_x2_24164);
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24170 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24170, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24172 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24173 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24172, v_p_241));
      switch (heff_tag_of(v_x2_24173)) {
      case TAG_MkPair: {
        V v_x_24174 = heff_field(v_x2_24173, 0);
        V v_s_24175 = heff_field(v_x2_24173, 1);
        V v_ru_24x2_24173_24MkPair = heff_take_reuse_n(v_x2_24173, 3ULL, 2);
        V v_t_24176 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24174), v_e_240));
        V v_x_24177 = heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_ELam, 2, (V[]){v_x_24174, v_t_24176});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24177, v_s_24175});
      }
      default: return heff_nomatch(v_x2_24173);
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24178 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24178, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24180 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24181 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24180, v_p_241));
      switch (heff_tag_of(v_x2_24181)) {
      case TAG_MkPair: {
        V v_x_24182 = heff_field(v_x2_24181, 0);
        V v_s_24183 = heff_field(v_x2_24181, 1);
        V v_ru_24x2_24181_24MkPair = heff_take_reuse_n(v_x2_24181, 3ULL, 2);
        V v_t_24184 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24182), v_e_240));
        V v_x_24185 = heff_tag_at_n(v_ru_24x2_24181_24MkPair, TAG_ELam, 2, (V[]){v_x_24182, v_t_24184});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24185, v_s_24183});
      }
      default: return heff_nomatch(v_x2_24181);
      }
    }
  }
  case TAG_EFix: {
    V v_t_24188 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24188, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24190 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24191 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24190, v_p_241));
      switch (heff_tag_of(v_x2_24191)) {
      case TAG_MkPair: {
        V v_x_24192 = heff_field(v_x2_24191, 0);
        V v_s_24193 = heff_field(v_x2_24191, 1);
        V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
        V v_t_24194 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24192), v_e_240));
        V v_x_24195 = heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_ELam, 2, (V[]){v_x_24192, v_t_24194});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24195, v_s_24193});
      }
      default: return heff_nomatch(v_x2_24191);
      }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eraise(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2eversAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eversAll_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eversAll(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_v_243), ((V)&g_heff_2ecompile_2esimplify_2eversAll_str0))) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        V v_x2_245 = (g_heff_2ecompile_2esimplify_2eversAll(v_rest_242));
        switch (heff_tag_of(v_x2_245)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_vs_246 = heff_field(v_x2_245, 0);
          heff_take_n(v_x2_245, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_246})});
        }
        default: return heff_nomatch(v_x2_245);
        }
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eversAll(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2easkKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkKept(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_kc_241, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_243});
  }
  case TAG_Just: {
    V v_b_244 = heff_field(v_x3_242, 0);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2ecopy(heff_dup(v_b_244), v_p_243));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_240), v_x_246, heff_take_field(v_kc_241, 2), v_s_247));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 2ULL, 2);
        V v_x2_2411 = ({ V b_0 = heff_get_n(v_kc_241, 3, 5); V a_1 = v_h_240; V a_2 = v_s_2410; V r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_MkPair: {
          V v_s_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2413});
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2easkKept(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAsk_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeptAsk(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_x3_244 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_h_240);
    heff_drop(v_v_241);
    heff_drop(v_t_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
  } else {
    heff_drop(v_t_246);
    V v_k_247 = heff_take_field(v_s_242, 8);
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_v_241, heff_take_field(v_k_247, 0)));
    V v_k_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_k_247, 30ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2410 = ({ V rv_8 = v_k_249; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2410});
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 2ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2413), heff_dup(v_h_240)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_h_240);
        return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2413});
      }
      case TAG_Just: {
        V v_kc_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        return ({ V a_0 = v_h_240; V a_1 = v_kc_2415; V a_2 = v_t_2416; V a_3 = v_s_2413; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAsk(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eallAsked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallAsked_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallAsked(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2ekeptAsk(v_h_244, v_v_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_247);
          V t_0 = v_rest_243;
          V t_1 = v_s_248;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rest_243);
          heff_drop(v_x_247);
          return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_248});
        }
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallAsked(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emadeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeKept_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeKept(V v_km_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_km_240, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_get_n(v_km_240, 1, 2), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
        heff_drop(v_x_245);
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      } else {
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeKept(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eask_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2eask(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2411 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_h_246); V a_2 = heff_dup(v_g_241); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecopyVer(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  V v_x2_2412 = (g_heff_2ecompile_2esimplify_2etouch(heff_dup(v_h_246), v_t_2411, heff_dup(v_s_248)));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 2ULL, 2);
    V v_t_2415 = heff_get_n(heff_get_n(v_s_248, 7, 9), 2, 7);
    V v_x3_2416 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x3_2416)) {
    case TAG_Nothing: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2416, 0ULL, 1);
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2416);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_marks_244);
      heff_drop_rec(v_sh_245, 3);
      heff_drop(v_h_246);
      heff_drop(v_d_247);
      heff_drop(v_t_2418);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2414});
    } else {
      heff_drop(v_t_2418);
      V v_t_2419 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2414), heff_dup(v_h_246)));
      V v_x2_2422;
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        v_x2_2422 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2414});
        break;
      }
      case TAG_Just: {
        V v_kc_2420 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
        V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2420, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2422 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_kc_2420; V a_2 = v_t_2421; V a_3 = v_s_2414; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
        break;
      }
      default: heff_nomatch(v_t_2419);
      }
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
          heff_drop(v_r_240);
          heff_drop(v_g_241);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_244);
          heff_drop_rec(v_sh_245, 3);
          heff_drop(v_h_246);
          heff_drop(v_d_247);
          heff_drop(v_x_2423);
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2424});
        } else {
          heff_drop(v_x_2423);
          V v_x2_2425 = (g_heff_2ecompile_2esimplify_2ecopy(heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_s_2424));
          switch (heff_tag_of(v_x2_2425)) {
          case TAG_MkPair: {
            V v_x_2426 = heff_field(v_x2_2425, 0);
            V v_s_2427 = heff_field(v_x2_2425, 1);
            V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
            V v_m_2428 = (g_heff_2ecompile_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2426));
            V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2427}));
            switch (heff_tag_of(v_x2_2429)) {
            case TAG_MkPair: {
              V v_x_2430 = heff_field(v_x2_2429, 0);
              V v_s_2431 = heff_field(v_x2_2429, 1);
              heff_take_n(v_x2_2429, 3ULL, 2);
              V v_x2_2432 = (g_heff_2ecompile_2esimplify_2eknowing(v_r_240, v_x_2430, v_s_2431));
              switch (heff_tag_of(v_x2_2432)) {
              case TAG_MkPair: {
                V v_x_2433 = heff_field(v_x2_2432, 0);
                V v_s_2434 = heff_field(v_x2_2432, 1);
                heff_take_n(v_x2_2432, 3ULL, 2);
                V v_x2_2435 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_246), heff_dup(v_x_2433), v_d_247, v_s_2434));
                switch (heff_tag_of(v_x2_2435)) {
                case TAG_MkPair: {
                  V v_s_2437 = heff_field(v_x2_2435, 1);
                  heff_take_n(v_x2_2435, 2ULL, 2);
                  V v_k_2438 = heff_take_field(v_s_2437, 8);
                  V v_t_2439 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_246), NTAG(TAG_MkUnit), heff_take_field(v_k_2438, 3)));
                  V v_k_2440 = ({ V rv_3 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_k_2438, 23ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                  V v_t_2441 = ({ V rv_8 = v_k_2440; V rr_ = heff_rec_reuse_nf(v_s_2437, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
                  V v_x2_2442 = heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2441});
                  switch (heff_tag_of(v_x2_2442)) {
                  case TAG_MkPair: {
                    V v_s_2444 = heff_field(v_x2_2442, 1);
                    heff_take_n(v_x2_2442, 2ULL, 2);
                    return ({ V a_0 = v_h_246; V a_1 = v_x_2433; V a_2 = v_s_2444; V r_ = (g_heff_2ecompile_2esimplify_2emarkCopySafe(a_0, a_1, a_2)); heff_drop(v_x_2433); r_; });
                  }
                  default: return heff_nomatch(v_x2_2442);
                  }
                }
                default: return heff_nomatch(v_x2_2435);
                }
              }
              default: return heff_nomatch(v_x2_2432);
              }
            }
            default: return heff_nomatch(v_x2_2429);
            }
          }
          default: return heff_nomatch(v_x2_2425);
          }
        }
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eask(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str5, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str6, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    V v_x1_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_x1_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_x1_2412 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2415 = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
    heff_drop(v_x1_2412);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_t_2415);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_s_247});
  } else {
    heff_drop(v_t_2415);
    V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_marks_245));
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2417, heff_dup(heff_rfield(v_sh_246, 0))));
    V v_x2_2419 = (g_list_2ezipWith_24s237481877x1031762735(((V)&g_heff_2ecompile_2esimplify_2especShaped_str0), heff_dup(v_marks_245), v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_str2); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str3), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2esimplify_2especShaped_str4)));
    V v_k_2424 = heff_strAppend(heff_dup(v_g_241), v_t_2423);
    V v_x2_2425 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2esimplify_2especShaped_str5), heff_dup(v_g_241), MK_INT(0LL)));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nothing: {
      v_t_2427 = heff_dup(v_g_241);
      break;
    }
    case TAG_Just: {
      V v_i_2426 = heff_field(v_x2_2425, 0);
      heff_take_n(v_x2_2425, 1ULL, 1);
      v_t_2427 = heff_strSlice(heff_dup(v_g_241), MK_INT(0LL), v_i_2426);
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_t_2428 = (g_heff_2ecompile_2espec_2ehashGo(v_k_2424, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    V v_t_2429 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str6), v_t_2428));
    V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2432 = ({ V a_0 = v_t_2430; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2431; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_sh_246, v_t_2429, v_t_2432, v_s_247));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_x1_2412 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_x1_2412);
          V v_x2_2413 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x2_2413, 0);
            V v_s_2415 = heff_field(v_x2_2413, 1);
            heff_take_n(v_x2_2413, 3ULL, 2);
            return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2414, v_s_2415));
          }
          default: return heff_nomatch(v_x2_2413);
          }
        } else {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          heff_drop(v_x1_2412);
          V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_z_246});
        }
      } else {
        heff_drop(v_t_2411);
        V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2418, v_s_2419));
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_x1_248, 0ULL, 2);
      V v_x2_2422 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2423, v_s_2424));
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_x1_247);
    V v_x_2425 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2ecompile_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      V v_ru_24it1_247_24ERecord = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ERecord, TAG_MkPair, 2, (V[]){v_x_2423, v_s_243});
    }
    case TAG_EProj: {
      heff_take_n(v_it1_247, 0ULL, 4);
      heff_drop(v_r_240);
      V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_243});
    }
    case TAG_ETag: {
      V v_ru_24it1_247_24ETag = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2431 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ETag, TAG_MkPair, 2, (V[]){v_x_2431, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2434 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2434, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2436 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2439 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2439, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2442 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2442, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2444 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2446 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2448 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2448, v_s_243});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2450 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2450, v_s_243});
    }
    case TAG_EFixed: {
      V v_ru_24it1_247_24EFixed = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2453 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFixed, TAG_MkPair, 2, (V[]){v_x_2453, v_s_243});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2455 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2455, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2456 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2456, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2459 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2459, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldIn(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_l_240))) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efieldIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eknownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownField_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_it_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Just = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_EVar: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELam: {
      V v_ru_24it1_245_24ELam = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EApp: {
      V v_ru_24it1_245_24EApp = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_it1_245, 0);
      V v_ru_24it1_245_24ERecord = heff_take_reuse_n(v_it1_245, 1ULL, 2);
      V v_t_2417 = ({ V a_0 = v_l_241; V a_1 = v_fs_2415; V r_ = (g_heff_2ecompile_2esimplify_2efieldIn(a_0, a_1)); heff_drop(v_fs_2415); r_; });
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24it_244_24Just, 1);
        return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
      }
      case TAG_Just: {
        V v_v_2418 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        V v_t_2419 = (g_heff_2ecompile_2eir_2eisValue(v_v_2418));
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_t_2419);
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
            V v_t_2421 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
            V v_t_2422 = ({ V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_s_242, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_x2_2423 = (g_heff_2ecompile_2esimplify_2ecopy(v_v_2418, v_t_2422));
            switch (heff_tag_of(v_x2_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_x2_2423, 0);
              V v_s_2425 = heff_field(v_x2_2423, 1);
              heff_take_n(v_x2_2423, 3ULL, 2);
              return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it_244_24Just, TAG_Just, 1, (V[]){v_x_2424}), v_s_2425});
            }
            default: return heff_nomatch(v_x2_2423);
            }
          } else {
            heff_drop_cell(v_ru_24it_244_24Just, 1);
            heff_drop(v_v_2418);
            return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
          }
        } else {
          heff_drop_cell(v_ru_24it_244_24Just, 1);
          heff_drop(v_v_2418);
          heff_drop(v_t_2419);
          return heff_tag_at_n(v_ru_24it1_245_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
        }
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    case TAG_EProj: {
      heff_take_n(v_it1_245, 0ULL, 4);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ETag: {
      V v_ru_24it1_245_24ETag = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EMatch: {
      V v_ru_24it1_245_24EMatch = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_245_24EPrimCall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ECall: {
      V v_ru_24it1_245_24ECall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFixed: {
      V v_ru_24it1_245_24EFixed = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFix: {
      V v_ru_24it1_245_24EFix = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownField(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_sh_242, V v_t_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam0, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_247 = heff_dup(heff_field(v_e_244, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam1, 1, 6, (V[]){v_g_247, v_e_244, v_l_241, v_sh_242, v_t_243, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam2, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam3, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_e_244, 0);
    V v_a_2421 = heff_field(v_e_244, 1);
    V v_b_2422 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){v_l_241, v_sh_242, v_t_243, v_b_2422}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2423, v_x_2420, v_a_2421});
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_e_244, 0);
    V v_ts_2429 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    heff_drop_rec(v_r_240, 4);
    V v_t_2430 = (g_heff_2ecompile_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2428));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam5, 1, 5, (V[]){v_fs_2428, v_ts_2429, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_Just: {
      V v_v_2433 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      V v_m_2434 = (g_heff_2ecompile_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2428)));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam6, 1, 7, (V[]){v_m_2434, v_v_2433, v_fs_2428, v_ts_2429, v_l_241, v_sh_242, v_t_243});
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam7, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam8, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam9, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam10, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam11, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam12, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam13, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam14, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam15, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam16, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam17, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam18, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam19, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam20, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_246});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = (g_heff_2ecompile_2esimplify_2eknown(v_g_247, v_s_248));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2411});
    }
    case TAG_Just: {
      V v_b_2412 = heff_field(v_x_2410, 0);
      heff_take_n(v_x_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_249_24MkPair, 2);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){heff_dup(v_l_241), heff_dup(v_sh_242), heff_dup(v_t_243), v_b_2412}));
      return (g_heff_2ecompile_2esimplify_2eattempt(heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_t_2413, v_s_2411));
    }
    default: return heff_nomatch(v_x_2410);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2416});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2419 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2419});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_a_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2420, v_a_2421, v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_fs_2428 = heff_env(self)[0];
  V v_ts_2429 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2428, v_ts_2429}), v_l_241, v_sh_242, v_t_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_v_2433 = heff_env(self)[1];
  V v_fs_2428 = heff_env(self)[2];
  V v_ts_2429 = heff_env(self)[3];
  V v_l_241 = heff_env(self)[4];
  V v_sh_242 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_s_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_x_2439;
    if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
      heff_drop(v_fs_2428);
      heff_drop(v_ts_2429);
      heff_drop(v_l_241);
      heff_drop(v_sh_242);
      heff_drop(v_t_243);
      heff_drop(v_x_2437);
      heff_drop_cell(v_ru_24x2_2436_24MkPair, 2);
      v_x_2439 = v_v_2433;
    } else {
      heff_drop(v_v_2433);
      heff_drop(v_x_2437);
      v_x_2439 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_ERecord, 2, (V[]){v_fs_2428, v_ts_2429}), v_l_241, v_sh_242, v_t_243});
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2439, v_s_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2444 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2444});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2447});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2450 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2450});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2452 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2452});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2455 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2455});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2458 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2458});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2460 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2460});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2462 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2462});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2466});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2469 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2469});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2471 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2471});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2472 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2472});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args) {
  V v_s_2475 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2475});
}
Clo g_heff_2ecompile_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t2_244), heff_dup(v_t_240))) {
        heff_drop(v_t_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindArm(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2ecopy(v_t_247, v_p_243));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2444;
      switch (heff_tag_of(v_x_249)) {
      case TAG_EVar: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_249, 0ULL, 4);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2429 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2444 = v_arms_2429;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_m_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2444}));
      V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_MkPair: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_s_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2447}), v_s_2448});
      }
      default: return heff_nomatch(v_x2_2446);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2eany_24s1107779796x153132813(v_arms2_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), heff_dup(v_arms_243)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms2_242));
    V v_t_249 = heff_intMul(v_t_247, heff_intSub(v_t_248, MK_INT(1LL)));
    if (heff_intLe_c(v_t_249, heff_dup(g_heff_2ecompile_2esimplify_2ecaseBudget_get()))) {
      V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epushArm_clo), 2, (V[]){v_r_240, v_arms_243}));
      V v_m_2412 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2411, v_arms2_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0, 1, 2, (V[]){v_m_2412, v_s2_241});
    } else {
      heff_drop(v_r_240);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_s2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args) {
  V v_s_2419 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_s_2419});
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam1, 2, 0};
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam2, 4, 0};
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2ecompile_2esimplify_2esk_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2esk_st;
static V g_heff_2ecompile_2esimplify_2esk_init(void) {
  return heff_rec_n(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2ecompile_2esimplify_2esk_lam0_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam1_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam2_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam3_clo)});
}
V g_heff_2ecompile_2esimplify_2esk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2esk_st)) return g_heff_2ecompile_2esimplify_2esk_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2esk_val, &g_heff_2ecompile_2esimplify_2esk_st, g_heff_2ecompile_2esimplify_2esk_init);
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_as_242 = args[1];
  return (g_heff_2ecompile_2esimplify_2eapplyToF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_f_241, v_as_242));
}
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_sh_244 = args[1];
  V v_t_245 = args[2];
  V v_e_246 = args[3];
  return (g_heff_2ecompile_2esimplify_2eprojectF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_l_243, v_sh_244, v_t_245, v_e_246));
}
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_247 = args[0];
  V v_arms_248 = args[1];
  return (g_heff_2ecompile_2esimplify_2ematchF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_s_247, v_arms_248));
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_243));
  V v_t_247;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), v_x_244)) {
    v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
    v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
  }
  V v_t_2441;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 4);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2441 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2443;
  if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
    heff_drop(v_t_2441);
    V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    v_t_2443 = (g_map_2einsert_24s1341440536x470972936(v_key_240, NTAG(TAG_MkUnit), v_t_2442));
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_2441);
    v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
  }
  V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 3, 7);
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 4, 7);
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 5, 7);
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 6, 7);
  V v_p_2449 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_247, v_t_2443, v_t_2444, v_t_2445, v_t_2446, v_t_2447, v_t_2448});
  return ({ V rv_7 = v_p_2449; V rr_ = heff_rec_reuse_nf(v_s_242, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2erecordDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordDef_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_247 = v_s_242;
  } else {
    heff_drop(v_t_245);
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), heff_take_field(v_s_242, 2)));
    v_t_247 = ({ V rv_2 = v_d_246; V rr_ = heff_rec_reuse_nf(v_s_242, 507ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  V v_t_248 = (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247));
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordDef(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emadeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOne_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emadeOne(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2410 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_247, v_t_248, v_t_249});
  V v_t_2411 = ({ V rv_7 = v_p_2410; V rr_ = heff_rec_reuse_nf(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2411});
}
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_s_242, 8));
  V v_t_244 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_243, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_245 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_244});
  V v_x2_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_248));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_s_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24MkPair = heff_take_reuse_n(v_t_249, 2ULL, 2);
      V v_m_2412 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b0_241));
      V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2414));
        V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2415}));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          V v_x2_2420 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2418, v_s_2419));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            heff_take_n(v_x2_2420, 3ULL, 2);
            V v_k_2423 = heff_dup(heff_rfield(v_s_2422, 8));
            V v_t_2424 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
            V v_k_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_k_2423, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2422, 8)), 2, 5);
            V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_t_2426, heff_take_field(v_k_2425, 4)));
            V v_k_2428 = ({ V rv_4 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_k_2425, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V v_t_2429 = ({ V rv_8 = v_k_2428; V rr_ = heff_rec_reuse_nf(v_s_2422, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
            V v_x2_2430 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2429});
            switch (heff_tag_of(v_x2_2430)) {
            case TAG_MkPair: {
              V v_s_2432 = heff_field(v_x2_2430, 1);
              heff_take_n(v_x2_2430, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2432});
            }
            default: return heff_nomatch(v_x2_2430);
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayBody_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayBody(V v_k_240, V v_b0_241, V v_s_242) {
top: ;
  V v_x2_243 = (g_heff_2ecompile_2esimplify_2ecopy(v_b0_241, v_s_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_k_240, 0)), heff_dup(v_x_244), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
      V v_x2_249 = (g_heff_2ecompile_2esimplify_2esafeAs(heff_rfield(v_k_240, 3), heff_dup(heff_rfield(v_k_240, 0)), v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 2ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_244)));
        V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
        V v_x2_2414 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2413, v_s_2411));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_t_2417 = heff_rec_n(3, shape_key__name__body, (V[]){heff_take_field(v_k_240, 0), heff_get_n(v_k_240, 1, 7), v_x_244});
          V v_t_2418 = heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
          V v_x_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2415, v_t_2418));
          return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2416});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayBody(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eafresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eafresh_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eafresh(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_n_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop(v_n_243);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_p_241});
    }
    case TAG_Just: {
      V v_d_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24MkPair, 2);
      V v_t_246 = ({ V rv_0 = v_n_243; V rr_ = heff_rec_reuse_nf(v_p_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef(v_d_245, v_t_246);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eafresh(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str1, 0, "");
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeOf(V v_st_240, V v_bodies_241, V v_h_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_244 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_246));
    V v_tv_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2emadeOf_lam0, 1, 1, (V[]){v_st_240}), v_t_247));
    V v_x2_2414 = (g_map_2elookup_24s1546226666x2146984184(v_h_242, v_bodies_241));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      heff_drop(v_tv_2413);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_b_2415 = heff_field(v_x2_2414, 0);
      heff_take_n(v_x2_2414, 1ULL, 1);
      V v_t_2416 = (g_list_2eall_24s455618083x1946283732(((V)&g_heff_2ecompile_2esimplify_2emadeOf_str1), v_tv_2413));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_tv_2413})});
      } else {
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        heff_drop(v_tv_2413);
        heff_drop(v_b_2415);
        heff_drop(v_t_2416);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emadeOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args) {
  V v_h_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_get_n(heff_get_n(v_st_240, 8, 9), 0, 5);
  V v_x2_2410 = ({ V a_0 = heff_dup(v_h_248); V a_1 = v_t_249; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_248, v_t_2412});
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_249));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2419));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  V v_t_2413 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2412; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_h_2411);
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_bodies_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 0, 5);
    V v_x2_2416 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return ({ V a_0 = v_st_240; V a_1 = v_bodies_242; V a_2 = v_h_2411; V a_3 = v_t_2418; V a_4 = v_r_2414; V r_ = (g_heff_2ecompile_2esimplify_2ecopyWith(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bodies_242); r_; });
  }
  default: return heff_nomatch(v_t_2413);
  }
}