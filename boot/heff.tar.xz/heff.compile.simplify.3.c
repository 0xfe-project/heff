// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntShow 56864
#define TAG_MkArm 55352
#define TAG_StrLength 43075
#define LBL_all 306203
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_fuel 9649789
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_unrolled 706233391
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eallParts(V, V);
V g_heff_2ecompile_2eir_2eallParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_clo;
V g_heff_2ecompile_2esimplify_2eapartOf(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_clo;
HeffT2 g_heff_2ecompile_2esimplify_2earmWith_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ecalledFirst(V, V, V);
V g_heff_2ecompile_2esimplify_2ecalledFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecalledFirst_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eenvOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eenvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eenvOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(V, V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616_clo;
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(V, V, V, V);
V g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandlerOf(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerOf_clo;
V g_heff_2ecompile_2esimplify_2einitL(V);
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_clo;
V g_heff_2ecompile_2esimplify_2einitL_24dps(V, V);
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2elastUseW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2elastUseW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elastUseW_clo;
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_clo;
V g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_clo;
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_clo;
V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2ecompile_2esimplify_2eloopBack(V, V, V);
V g_heff_2ecompile_2esimplify_2eloopBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eloopBack_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarksOf(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarksOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarksOf_clo;
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_clo;
V g_heff_2ecompile_2esimplify_2ematchesFirst(V, V);
V g_heff_2ecompile_2esimplify_2ematchesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchesFirst_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2epastLastUse(V, V, V);
V g_heff_2ecompile_2esimplify_2epastLastUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epastLastUse_clo;
V g_heff_2ecompile_2esimplify_2eposOf_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eposOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eposOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2eprojW(V, V, V);
V g_heff_2ecompile_2esimplify_2eprojW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojW_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209_clo;
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442_clo;
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237_clo;
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_list_2eall_24s1220384081x1312205021(V);
V g_list_2eall_24s1220384081x1312205021_entry(V self, V *a);
extern Clo g_list_2eall_24s1220384081x1312205021_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1206739756x709939553(V, V, V, V);
V g_list_2eany_24s1206739756x709939553_entry(V self, V *a);
extern Clo g_list_2eany_24s1206739756x709939553_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1544308498x936697067(V, V);
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1544308498x936697067_clo;
V g_list_2efoldl_24s1913417976x1327308136(V, V, V);
V g_list_2efoldl_24s1913417976x1327308136_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1913417976x1327308136_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s183165982x1490920686(V);
V g_list_2ekeepIf_24s183165982x1490920686_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1531069132x955165792(V);
V g_list_2emap_24s1531069132x955165792_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1237512785x1947069493(V);
V g_prelude_2etraverse_24s1237512785x1947069493_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1237512785x1947069493_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattemptBy_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eattemptBy(V v_more_240, V v_orig_241, V v_m_242, V v_s_243) {
top: ;
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){heff_dup(v_s_243)}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_orig_241), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_247));
    V v_lim_249 = heff_intAdd(v_t_248, v_more_240);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), NTAG(TAG_Nil)});
    V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_249), MK_INT(0LL), v_t_2410));
    if (!heff_intLt_c_lent(v_lim_249, v_x_2411, 0)) {
      heff_drop(v_orig_241);
      heff_drop_rec(v_s_243, 10);
      heff_drop(v_lim_249);
      heff_drop(v_x_2411);
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_s_246});
    } else {
      heff_drop(v_x_245);
      heff_drop(v_lim_249);
      heff_drop(v_x_2411);
      V v_t_2412 = ({ V rv_2 = heff_take_field(v_s_243, 2); V rv_5 = heff_get_n(v_s_243, 5, 10); V rr_ = heff_rec_reuse_nf(v_s_246, 987ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1045455u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_orig_241, v_t_2412});
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattemptBy(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_b_244));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_ys_248 = v_field_246;
      V v_b_249 = v_field_247;
      V v_f_2410 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_240_24ELam, v_xs_243, v_ys_248));
      return ((HeffT2){{v_f_2410, v_b_249}});
    }
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBool: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ESet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EValues: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldPrim_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efoldPrim(V v_p_240, V v_argv_241) {
top: ;
  V v_t_2490;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    v_t_2490 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_a_242 = heff_dup(heff_field(v_argv_241, 0));
    V v_x22_243 = heff_dup(heff_field(v_argv_241, 1));
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_p_244 = heff_dup(v_p_240);
      V v_x2_245 = v_a_242;
      switch (heff_tag_of(v_p_244)) {
      case TAG_IntShow: {
        switch (heff_tag_of(v_x2_245)) {
        case TAG_EVar: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_x2_245, 0ULL, 4);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EInt: {
          V v_a_2431 = heff_field(v_x2_245, 0);
          V v_ru_24x2_245_24EInt = heff_take_reuse_n(v_x2_245, 1ULL, 1);
          V v_t_2432 = heff_tag_at_n(v_ru_24x2_245_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2431)});
          v_t_2490 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EAbandon: {
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x2_245);
        }
        break;
      }
      case TAG_StrLength: {
        switch (heff_tag_of(v_x2_245)) {
        case TAG_EVar: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_x2_245, 0ULL, 4);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EStr: {
          V v_a_2473 = heff_field(v_x2_245, 0);
          V v_ru_24x2_245_24EStr = heff_take_reuse_n(v_x2_245, 1ULL, 1);
          V v_t_2474 = heff_tag_at_n(v_ru_24x2_245_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2473)});
          v_t_2490 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2474});
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EAbandon: {
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_x2_245, 0ULL, 3);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_x2_245, 0ULL, 1);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_x2_245, 0ULL, 2);
          v_t_2490 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x2_245);
        }
        break;
      }
      default: {
        heff_drop(v_p_244);
        heff_drop(v_x2_245);
        v_t_2490 = NTAG(TAG_Nothing);
        break;
      }
      }
      break;
    }
    case TAG_Cons: {
      V v_b_2486 = heff_field(v_x22_243, 0);
      V v_x222_2487 = heff_field(v_x22_243, 1);
      heff_take_n(v_x22_243, 3ULL, 2);
      switch (heff_tag_of(v_x222_2487)) {
      case TAG_Nil: {
        v_t_2490 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_242, v_b_2486));
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x222_2487, 0ULL, 2);
        heff_drop(v_a_242);
        heff_drop(v_b_2486);
        v_t_2490 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x222_2487);
      }
      break;
    }
    default: heff_nomatch(v_x22_243);
    }
    break;
  }
  default: heff_nomatch(v_argv_241);
  }
  switch (heff_tag_of(v_t_2490)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
    }
    case TAG_Cons: {
      V v_a_2491 = heff_dup(heff_field(v_argv_241, 0));
      V v_it2_2492 = heff_dup(heff_field(v_argv_241, 1));
      switch (heff_tag_of(v_it2_2492)) {
      case TAG_Nil: {
        heff_drop(v_a_2491);
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
      }
      case TAG_Cons: {
        V v_b_2493 = heff_field(v_it2_2492, 0);
        V v_it22_2494 = heff_field(v_it2_2492, 1);
        V v_ru_24it2_2492_24Cons = heff_take_reuse_n(v_it2_2492, 3ULL, 2);
        switch (heff_tag_of(v_it22_2494)) {
        case TAG_Nil: {
          V v_t_2495 = (g_heff_2ecompile_2eir_2eisRel(v_p_240));
          if ((heff_dup(v_t_2495) == NTAG(TAG_True))) {
            heff_drop_tag(v_argv_241, 2);
            heff_drop_cell(v_ru_24it2_2492_24Cons, 2);
            heff_drop(v_t_2495);
            return heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_240, v_a_2491, v_b_2493})});
          } else {
            heff_drop(v_a_2491);
            heff_drop(v_b_2493);
            heff_drop(v_t_2495);
            return heff_tag_at_n(v_ru_24it2_2492_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2494, 0ULL, 2);
          heff_drop(v_a_2491);
          heff_drop(v_b_2493);
          return heff_tag_at_n(v_ru_24it2_2492_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
        }
        default: return heff_nomatch(v_it22_2494);
        }
      }
      default: return heff_nomatch(v_it2_2492);
      }
    }
    default: return heff_nomatch(v_argv_241);
    }
  }
  case TAG_Just: {
    V v_v_2498 = heff_field(v_t_2490, 0);
    heff_take_n(v_t_2490, 1ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_argv_241);
    return v_v_2498;
  }
  default: return heff_nomatch(v_t_2490);
  }
}
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldPrim(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2einitL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einitL_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2einitL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2einitL_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einitL(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2eapartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartOf(V v_x_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eapartOf_24cpr(v_x_240, v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eapartOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2elastUseW_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2elastUseW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elastUseW_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2elastUseW(V v_ys_240, V v_x_241, V v_seen_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seen_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      if (heff_strEq_c_lent(v_y_246, v_x_241, 0)) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_y_246);
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2elastUseW_lam0, 1, 1, (V[]){v_rest_245}); V a_1 = v_seen_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_seen_242); r_; });
      } else {
        V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_y_246)}));
        V v_t_2410 = (g_list_2eany(v_t_249, v_ys_240));
        V v_t_2411;
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_seen_242});
        } else {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_y_246);
          heff_drop(v_t_2410);
          v_t_2411 = v_seen_242;
        }
        V t_0 = v_ys_240;
        V t_1 = v_x_241;
        V t_2 = v_t_2411;
        V t_3 = v_rest_245;
        v_ys_240 = t_0;
        v_x_241 = t_1;
        v_seen_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    case TAG_EMatch: {
      V v_sc_2412 = heff_field(v_x41_244, 0);
      V v_arms_2413 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24EMatch = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      HeffT2 v_t_2414 = (g_heff_2ecompile_2esimplify_2earmWith_24cpr(v_x_241, heff_dup(v_arms_2413)));
      V v_t_2418;
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_arms_2413);
          V v_e_2417 = v_field_2416;
          v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_rest_245});
        } else {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_field_2416);
          v_t_2418 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2413, v_rest_245));
        }
      }
      V t_0 = v_ys_240;
      V t_1 = v_x_241;
      V t_2 = v_seen_242;
      V t_3 = heff_tag_at_n(v_ru_24x41_244_24EMatch, TAG_Cons, 2, (V[]){v_sc_2412, v_t_2418});
      v_ys_240 = t_0;
      v_x_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_ys_240;
      V t_1 = v_x_241;
      V t_2 = v_seen_242;
      V t_3 = v_t_2419;
      v_ys_240 = t_0;
      v_x_241 = t_1;
      v_seen_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2elastUseW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2elastUseW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2elastUseW_lam0(V self, V *args) {
  V v_z_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = v_z_247; V a_1 = MK_INT(0LL); V a_2 = v_rest_245; V r_ = (g_heff_2ecompile_2eir_2ecountW(a_0, a_1, a_2)); heff_drop(v_z_247); r_; });
  V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_t_248, MK_INT(0LL), 2));
  heff_drop(v_t_248);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebindArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2444;
    switch (heff_tag_of(v_a_243)) {
    case TAG_EVar: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_x1_2444 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_x1_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam0, 1, 2, (V[]){v_x1_2444, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam1, 2, 1, (V[]){v_argv_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args) {
  V v_p_2445 = args[0];
  V v_x1_2444 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x1_2444) == NTAG(TAG_True))) {
    heff_drop(v_x1_2444);
    V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_p_2445});
  } else {
    heff_drop(v_x1_2444);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_str0), v_p_2445));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_x_2450 = v_field_2448;
      V v_s_2451 = v_field_2449;
      V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2450), v_a_243})});
      V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2450})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_s_2451});
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args) {
  V v_one_2454 = args[0];
  V v_z_2455 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_clo), 1, (V[]){v_argv_244}));
  V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_z_2455}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2467;
    switch (heff_tag_of(v_one_2454)) {
    case TAG_MkPair: {
      V v_x11_2460 = heff_field(v_one_2454, 0);
      V v_a_2461 = heff_field(v_one_2454, 1);
      V v_ru_24one_2454_24MkPair = heff_take_reuse_n(v_one_2454, 3ULL, 2);
      switch (heff_tag_of(v_x11_2460)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2458)) {
        case TAG_MkPair: {
          V v_bds_2462 = heff_field(v_x_2458, 0);
          V v_argv_2463 = heff_field(v_x_2458, 1);
          heff_take_n(v_x_2458, 3ULL, 2);
          v_t_2467 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2462, heff_tag_at_n(v_ru_24one_2454_24MkPair, TAG_Cons, 2, (V[]){v_a_2461, v_argv_2463})});
          break;
        }
        default: heff_nomatch(v_x_2458);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2464 = heff_field(v_x11_2460, 0);
        heff_take_n(v_x11_2460, 1ULL, 1);
        switch (heff_tag_of(v_x_2458)) {
        case TAG_MkPair: {
          V v_bds_2465 = heff_field(v_x_2458, 0);
          V v_argv_2466 = heff_field(v_x_2458, 1);
          V v_ru_24x_2458_24MkPair = heff_take_reuse_n(v_x_2458, 3ULL, 2);
          v_t_2467 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24one_2454_24MkPair, TAG_Cons, 2, (V[]){v_bd_2464, v_bds_2465}), heff_tag_at_n(v_ru_24x_2458_24MkPair, TAG_Cons, 2, (V[]){v_a_2461, v_argv_2466})});
          break;
        }
        default: heff_nomatch(v_x_2458);
        }
        break;
      }
      default: heff_nomatch(v_x11_2460);
      }
      break;
    }
    default: heff_nomatch(v_one_2454);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2467, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esumTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_a_241, 0);
    V v_arms_2422 = heff_field(v_a_241, 1);
    V v_ru_24a_241_24EMatch = heff_take_reuse_n(v_a_241, 3ULL, 2);
    V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_x1_2424 = (g_list_2efoldl_24s1544308498x936697067(v_t_2423, heff_dup(v_arms_2422)));
    V v_t_2428;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_MkPair: {
      V v_ts_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 2);
      V v_x_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2425; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2425); r_; });
      v_t_2428 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2427, 1));
      heff_drop(v_x_2427);
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_x_2430 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), v_t_2429));
      if (heff_intLt_c(MK_INT(0LL), v_x_2430)) {
        V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2432 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), v_t_2431));
        V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2434 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2433));
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2436 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2435));
        V v_t_2437 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2434, v_t_2436}), 0, 2);
        if (heff_intEq_c(v_t_2432, v_t_2437)) {
          V v_lit_2438 = v_s_2421;
          V v_lit_2439 = v_arms_2422;
          V v_x_2440 = v_x_240;
          V v_b_2441 = v_b_242;
          V v_x1_2462;
          switch (heff_tag_of(v_b_2441)) {
          case TAG_EMatch: {
            V v_b1_2442 = heff_dup(heff_field(v_b_2441, 0));
            switch (heff_tag_of(v_b1_2442)) {
            case TAG_EVar: {
              V v_y_2444 = heff_field(v_b1_2442, 0);
              V v_ru_24b1_2442_24EVar = heff_take_reuse_n(v_b1_2442, 1ULL, 1);
              switch (heff_tag_of(v_b_2441)) {
              case TAG_EMatch: {
                V v_arms_2446 = heff_field(v_b_2441, 1);
                V v_ru_24b_2441_24EMatch = heff_take_reuse_n(v_b_2441, 2ULL, 2);
                if (heff_strEq_c_lent(v_x_2440, v_y_2444, 1)) {
                  heff_drop_cell(v_ru_24a_241_24EMatch, 2);
                  heff_drop(v_y_2444);
                  heff_drop_cell(v_ru_24b1_2442_24EVar, 1);
                  V v_lit_2447 = v_lit_2438;
                  heff_drop(v_lit_2447);
                  V v_lit_2448 = v_lit_2439;
                  V v_budget_2449 = MK_INT(100LL);
                  V v_arms_2450 = v_arms_2446;
                  V v_t_2451 = heff_tag_at_n(v_ru_24b_2441_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
                  V v_x1_2452 = (g_list_2efoldl_24s1544308498x936697067(v_t_2451, heff_dup(v_lit_2448)));
                  V v_t_2456;
                  switch (heff_tag_of(v_x1_2452)) {
                  case TAG_MkPair: {
                    V v_ts_2453 = heff_field(v_x1_2452, 0);
                    heff_take_n(v_x1_2452, 1ULL, 2);
                    V v_x_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2453; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2453); r_; });
                    v_t_2456 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2455, 1));
                    heff_drop(v_x_2455);
                    break;
                  }
                  default: heff_nomatch(v_x1_2452);
                  }
                  V v_x1_2460;
                  if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
                    heff_drop(v_t_2456);
                    V v_t_2457 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
                    V v_t_2458 = (g_list_2efoldl_24s1544308498x936697067(v_t_2457, v_lit_2448));
                    V v_x1_2459 = (g_list_2eany_24s1206739756x709939553(v_budget_2449, v_t_2458, heff_dup(v_arms_2450), v_arms_2450));
                    v_x1_2460 = heff_bool(!(heff_dup(v_x1_2459) == NTAG(TAG_True)));
                    heff_drop(v_x1_2459);
                  } else {
                    heff_drop(v_lit_2448);
                    heff_drop(v_budget_2449);
                    heff_drop(v_arms_2450);
                    heff_drop(v_t_2456);
                    v_x1_2460 = NTAG(TAG_False);
                  }
                  v_x1_2462 = heff_bool(!(heff_dup(v_x1_2460) == NTAG(TAG_True)));
                  heff_drop(v_x1_2460);
                } else {
                  heff_drop_cell(v_ru_24b_2441_24EMatch, 2);
                  V v_t_2461 = heff_tag_at_n(v_ru_24a_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24b1_2442_24EVar, TAG_EVar, 1, (V[]){v_y_2444}), v_arms_2446});
                  v_x1_2462 = ({ V a_0 = v_lit_2438; V a_1 = v_lit_2439; V a_2 = v_t_2461; V r_ = (g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(a_0, a_1, a_2)); heff_drop(v_lit_2438); r_; });
                }
                break;
              }
              default: heff_nomatch(v_b_2441);
              }
              break;
            }
            default: {
              heff_drop_cell(v_ru_24a_241_24EMatch, 2);
              heff_drop(v_x_2440);
              heff_drop(v_b1_2442);
              v_x1_2462 = ({ V a_0 = v_lit_2438; V a_1 = v_lit_2439; V a_2 = v_b_2441; V r_ = (g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(a_0, a_1, a_2)); heff_drop(v_lit_2438); r_; });
              break;
            }
            }
            break;
          }
          default: {
            heff_drop_cell(v_ru_24a_241_24EMatch, 2);
            heff_drop(v_x_2440);
            v_x1_2462 = ({ V a_0 = v_lit_2438; V a_1 = v_lit_2439; V a_2 = v_b_2441; V r_ = (g_heff_2ecompile_2esimplify_2efollowOver_24s1570462728x1356296616(a_0, a_1, a_2)); heff_drop(v_lit_2438); r_; });
            break;
          }
          }
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2462) == NTAG(TAG_True)));
          heff_drop(v_x1_2462);
          return v_ret_24bool;
        } else {
          heff_drop(v_x_240);
          heff_drop(v_b_242);
          heff_drop(v_s_2421);
          heff_drop(v_arms_2422);
          heff_drop_cell(v_ru_24a_241_24EMatch, 2);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_x_240);
        heff_drop(v_b_242);
        heff_drop(v_s_2421);
        heff_drop(v_arms_2422);
        heff_drop_cell(v_ru_24a_241_24EMatch, 2);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      heff_drop(v_b_242);
      heff_drop(v_s_2421);
      heff_drop(v_arms_2422);
      heff_drop_cell(v_ru_24a_241_24EMatch, 2);
      heff_drop(v_t_2428);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumTakenApart(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ematchesFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchesFirst_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ematchesFirst(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_x2_241, 2);
    V t_0 = v_x_240;
    V t_1 = v_b_2410;
    v_x_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_sc_2420 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_sc_2420)) {
    case TAG_EVar: {
      V v_y_2422 = heff_field(v_sc_2420, 0);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2422, 0));
      return v_ret_24bool;
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_sc_2420);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchesFirst_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ematchesFirst(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELam: {
    V v_xs_242 = heff_field(v_e_240, 0);
    V v_b_243 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_244, v_b_243));
    if (heff_intEq_c(v_t_245, MK_INT(0LL))) {
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_p_241}});
    } else {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_247 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_246, v_b_243));
      HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_247, v_p_241));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_s_2412 = v_field_2410;
        V v_t_2413 = (g_prelude_2e_2b_2b(v_xs_242, heff_dup(v_x_2411)));
        V v_t_2414 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(v_x_2411, v_b_243));
        V v_x_2415 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_t_2414});
        return ((HeffT2){{v_x_2415, v_s_2412}});
      }
    }
  }
  default: {
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2417 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2416, v_e_240));
    if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2419 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2418, v_e_240));
      HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2419, v_p_241));
      {
        V v_field_2421 = v_t_2420.f[0];
        V v_field_2422 = v_t_2420.f[1];
        V v_x_2423 = v_field_2421;
        V v_s_2424 = v_field_2422;
        V v_t_2425 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(heff_dup(v_x_2423), v_e_240));
        V v_x_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2423, v_t_2425});
        return ((HeffT2){{v_x_2426, v_s_2424}});
      }
    }
  }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0), 2)) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(v_rest_242));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_vs_247 = v_field_246;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_247})}});
          } else {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_v_243);
            heff_drop(v_field_246);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
  }
  case TAG_Cons: {
    V v_m_243 = heff_dup(heff_field(v_x1_240, 0));
    V v_ms_244 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
    }
    case TAG_Cons: {
      V v_n_245 = heff_field(v_x2_241, 0);
      V v_ns_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_247 = heff_bool(((heff_dup(v_m_243) == NTAG(TAG_True)) || (heff_dup(v_n_245) == NTAG(TAG_True))));
      heff_drop(v_m_243);
      heff_drop(v_n_245);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ms_244;
      V t_1 = v_ns_246;
      V t_2 = v_cell_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eenvOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eenvOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eenvOf_lam0, 2, 0};
Clo g_heff_2ecompile_2esimplify_2eenvOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eenvOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eenvOf(V v_env_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_x3_242);
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_y_243);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_dup(g_std_2eordmap_2eempty_get());
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x3_242, 0);
      V v_argv_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_env_247 = heff_dup(v_env_240);
      V v_x2_248 = v_a_245;
      V v_x2_2452;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_EVar: {
        V v_p_249 = heff_field(v_x2_248, 0);
        V v_ru_24x2_248_24EVar = heff_take_reuse_n(v_x2_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_x2_2452 = ({ V a_0 = v_ru_24x2_248_24EVar; V a_1 = v_env_247; V a_2 = v_p_249; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_env_247); heff_drop(v_p_249); r_; });
        break;
      }
      case TAG_EGlobal: {
        V v_h_2410 = heff_field(v_x2_248, 0);
        V v_ru_24x2_248_24EGlobal = heff_take_reuse_n(v_x2_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_248_24EGlobal, TAG_EGlobal, 1, (V[]){v_h_2410})});
        break;
      }
      case TAG_ELam: {
        V v_ys_2411 = heff_field(v_x2_248, 0);
        V v_b_2412 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        heff_drop(v_env_247);
        V v_t_2416 = heff_tr(g_heff_2ecompile_2eir_2eallParts(((V)&g_heff_2ecompile_2esimplify_2eenvOf_lam0_clo), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ELam, 2, (V[]){heff_dup(v_ys_2411), heff_dup(v_b_2412)})));
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          v_x2_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ELam, 2, (V[]){v_ys_2411, v_b_2412})});
        } else {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_ys_2411);
          heff_drop(v_b_2412);
          heff_drop(v_t_2416);
          v_x2_2452 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x2_248, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x2_248, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x2_248, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x2_248, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x2_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x2_248, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_env_247);
        v_x2_2452 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_m_2453 = (g_heff_2ecompile_2esimplify_2eenvOf(v_env_240, v_ys_244, v_argv_246));
      switch (heff_tag_of(v_x2_2452)) {
      case TAG_Nothing: {
        heff_drop(v_y_243);
        return v_m_2453;
      }
      case TAG_Just: {
        V v_k_2454 = heff_field(v_x2_2452, 0);
        heff_take_n(v_x2_2452, 1ULL, 1);
        HEFF_LAST return g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2453, v_y_243, v_k_2454);
      }
      default: return heff_nomatch(v_x2_2452);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eenvOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eenvOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eenvOf_lam0(V self, V *args) {
  V v_xs_2413 = args[0];
  V v_p_2414 = args[1];
  V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI(v_xs_2413, NTAG(TAG_Nil)));
  return (g_heff_2ecompile_2espec_2eclosedIn(v_t_2415, v_p_2414));
}
Clo g_heff_2ecompile_2esimplify_2eposOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eposOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eposOf_24dps(V v_x_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x3_242, 0);
    V v_argv_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2445;
    switch (heff_tag_of(v_a_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_2445 = heff_bool(heff_strEq_c_lent(v_x_240, v_y_246, 0));
      heff_drop(v_y_246);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_a_244, 0ULL, 3);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_a_244, 0ULL, 4);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_a_244, 0ULL, 3);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_a_244, 0ULL, 3);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_a_244, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_a_244, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_cell_2446 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_241), heff_hole()});
      V v_u_2447 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2446));
      heff_drop(v_u_2447);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_argv_245;
      V t_3 = v_cell_2446;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_2445);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_argv_245;
      V t_3 = v_d_243;
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eposOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eposOf_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_a_248 = heff_field(v_x1_240, 1);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_e_249));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_bds_2413 = v_field_2411;
      V v_e_2414 = v_field_2412;
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bds_2413});
      return ((HeffT2){{v_t_2415, v_e_2414}});
    }
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBool: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ESet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EValues: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(V v_g_240, V v_xs_241, V v_b_242, V v_argv_243, V v_s_244) {
top: ;
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 6, 7);
  if (((heff_dup(v_t_245) == NTAG(TAG_True)) || heff_intLe_c(MK_INT(50000LL), heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 5, 7)))) {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    heff_drop(v_t_245);
    V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_240}), v_argv_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_244});
  } else {
    heff_drop(v_t_245);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_t_249 = heff_intSub(v_t_247, v_t_248);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_249, heff_dup(v_s_244)));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_x_2413 = v_field_2411;
      V v_s_2414 = v_field_2412;
      V v_xs_2415 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), heff_dup(v_x_2413)));
      V v_t_2416 = (g_list_2emap_24s1809017761x1063871171(v_x_2413));
      V v_b_2417 = heff_tag_n(TAG_EApp, 2, (V[]){heff_dup(v_b_242), v_t_2416});
      V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
      V v_t_2425 = (g_heff_2ecompile_2esimplify_2emarksOf(v_t_2418, heff_clo_n(g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_lam0, 1, 3, (V[]){heff_dup(v_s_244), heff_dup(v_argv_243), heff_dup(v_g_240)}), heff_dup(v_g_240), heff_dup(v_xs_241), v_b_242, v_argv_243));
      V v_t_2426 = heff_get_n(heff_get_n(v_s_244, 7, 10), 0, 7);
      V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ehandlerOf_clo), 1, (V[]){v_t_2426}));
      V v_t_2428 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
      V v_t_2429 = (g_list_2edrop(v_t_2428, v_argv_243));
      V v_t_2430 = (g_list_2emap(v_t_2427, v_t_2429));
      V v_marks_2431 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2430));
      V v_t_2432 = (g_list_2eall_24s1220384081x1312205021(v_marks_2431));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_xs_2415);
        heff_drop_tag(v_b_2417, 2);
        heff_drop(v_marks_2431);
        heff_drop(v_t_2432);
        V v_x_2433 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_240}), v_argv_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_s_2414});
      } else {
        heff_drop(v_t_2432);
        return (g_heff_2ecompile_2esimplify_2especMarked_24s1773574996x1885333237(NTAG(TAG_False), v_g_240, v_xs_2415, v_b_2417, v_argv_243, v_marks_2431, v_s_2414));
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especPast_24s355360788x1292812504_lam0(V self, V *args) {
  V v_e_2419 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_argv_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 0, 7);
  V v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_e_2419; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2420); r_; });
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_e_2419);
    heff_drop_rec(v_s_244, 10);
    heff_drop(v_argv_243);
    heff_drop(v_g_240);
    heff_drop(v_t_2421);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2421);
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
    V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_argv_243; V r_ = (g_list_2eany_24s604143829x1495140576(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_argv_243); r_; });
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      V v_t_2424 = heff_get_n(heff_get_n(v_s_244, 7, 10), 0, 7);
      return ({ V a_0 = v_t_2424; V a_1 = v_g_240; V a_2 = v_e_2419; V r_ = (g_heff_2ecompile_2esimplify_2eloopBack(a_0, a_1, a_2)); heff_drop(v_t_2424); heff_drop(v_e_2419); r_; });
    } else {
      heff_drop(v_e_2419);
      heff_drop_rec(v_s_244, 10);
      heff_drop(v_g_240);
      heff_drop(v_t_2423);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760(V v_s_240, V v_arms_241, V v_argv_242, V v_z_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_242)));
  V v_t_245 = ({ V a_0 = v_t_244; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_244); r_; });
  if (((heff_dup(v_t_245) == NTAG(TAG_True)) && ({ V v_t_246 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_242))); int c_ = ({ V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_241)); int c_ = ({ V v_t_2432 = heff_intMul(heff_dup(v_t_246), heff_intSub(heff_dup(v_t_247), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2432, MK_INT(120LL), 2); heff_drop(v_t_2432); c_; }); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; }))) {
    heff_drop(v_t_245);
    V v_m_2417 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam0, 1, 1, (V[]){v_argv_242}), v_arms_241));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_243}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_240, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  } else {
    heff_drop(v_t_245);
    V v_arms_2421 = heff_dup(v_arms_241);
    V v_argv_2422 = heff_dup(v_argv_242);
    V v_t_2423 = (g_list_2emap_24s1531069132x955165792(heff_dup(v_argv_2422)));
    V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2423); r_; });
    V v_t_2431;
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      V v_t_2425 = (g_list_2eany_24s860380051x1466609135(v_argv_2422));
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_t_2425);
        V v_argv_2426 = (g_list_2ekeepIf_24s183165982x1490920686(v_argv_2422));
        V v_t_2427 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_argv_2426)));
        V v_t_2428 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2427); r_; });
        v_t_2431 = heff_bool(((heff_dup(v_t_2428) == NTAG(TAG_True)) && ({ V v_t_2429 = (g_list_2efoldl_24s1913417976x1327308136(MK_INT(0LL), MK_INT(0LL), heff_dup(v_argv_2426))); int c_ = ({ V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2421)); int c_ = ({ V v_t_2433 = heff_intMul(heff_dup(v_t_2429), heff_intSub(heff_dup(v_t_2430), MK_INT(1LL))); int c_ = heff_intLe_c_lent(v_t_2433, MK_INT(120LL), 2); heff_drop(v_t_2433); c_; }); heff_drop(v_t_2430); c_; }); heff_drop(v_t_2429); c_; })));
        heff_drop(v_arms_2421);
        heff_drop(v_argv_2426);
        heff_drop(v_t_2428);
      } else {
        heff_drop(v_arms_2421);
        heff_drop(v_argv_2422);
        heff_drop(v_t_2425);
        v_t_2431 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_arms_2421);
      heff_drop(v_argv_2422);
      heff_drop(v_t_2424);
      v_t_2431 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(v_s_240, v_arms_241, v_argv_242, v_z_243);
    } else {
      heff_drop(v_t_2431);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2efollowerPushed_24s1375107731x1851603596(v_s_240, v_arms_241, v_argv_242, v_z_243);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_vs_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_vs_2410, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkArm: {
    V v_t_249 = heff_field(v_a_248, 0);
    V v_vs_2410 = heff_field(v_a_248, 1);
    V v_b_2411 = heff_field(v_a_248, 2);
    heff_take_n(v_a_248, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(v_b_2411, v_argv_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchApplied_24s533689399x1955263760_lam1, 1, 3, (V[]){v_m_2412, v_t_249, v_vs_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
Clo g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(V v_x_240, V v_b_241, V v_x4_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_ETag: {
    V v_t_244 = heff_field(v_x4_242, 0);
    V v_es_245 = heff_field(v_x4_242, 1);
    V v_ts_246 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ETag = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_x2_247 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_es_245, v_p_243));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_241, v_s_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_s_2414 = v_field_2412;
        V v_t_2417;
        switch (heff_tag_of(v_x_248)) {
        case TAG_MkPair: {
          V v_y_2416 = heff_dup(heff_field(v_x_248, 1));
          v_t_2417 = v_y_2416;
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        V v_m_2418 = (g_prelude_2etraverse_24s1237512785x1947069493(v_t_2417));
        V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2414}));
        V v_x2_2422;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_MkPair: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          V v_s_2421 = heff_field(v_x2_2419, 1);
          heff_take_n(v_x2_2419, 3ULL, 2);
          v_x2_2422 = heff_tr(g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(v_x_240, heff_tag_at_n(v_ru_24x4_242_24ETag, TAG_ETag, 3, (V[]){v_t_244, v_x_2420, v_ts_246}), v_x_2413, v_s_2421));
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_s_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          V v_t_2427;
          switch (heff_tag_of(v_x_248)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x_248, 0);
            heff_take_n(v_x_248, 1ULL, 2);
            v_t_2427 = v_x_2425;
            break;
          }
          default: heff_nomatch(v_x_248);
          }
          V v_x_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2423; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2427); r_; });
          return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2424});
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_b_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_p_243});
  }
  default: {
    HeffT2 v_t_2429 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_241, v_p_243));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_x_2432 = v_field_2430;
      V v_s_2433 = v_field_2431;
      V v_m_2434 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x4_242));
      V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2433}));
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_MkPair: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_s_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        V v_t_2438 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(v_x_240, v_x_2436, v_x_2432));
        return heff_tail(v_t_2438, 1, (V[]){v_s_2437});
      }
      default: return heff_nomatch(v_x2_2435);
      }
    }
  }
  }
}
V g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esumPushed_24s1332744367x171076358(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(V v_x_240, V v_a_241, V v_b_242, V v_s_243) {
top: ;
  V v_x_244 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_243), heff_dup(v_a_241)));
  V v_t_2449;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    V v_t_2420 = heff_dup(heff_field(v_a_241, 0));
    if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_str0))) {
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2423));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_t_2426 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2425));
      V v_x_2427 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2424, v_t_2426}), 0, 2);
      v_t_2449 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2427, 1));
      heff_drop(v_x_2427);
    } else {
      v_t_2449 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EMatch: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2449 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_241);
  }
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    heff_drop(v_t_2449);
    V v_m_2450 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
    V v_x2_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_243}));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_MkPair: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_s_2453 = heff_field(v_x2_2451, 1);
      V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_2452}), v_s_2453});
    }
    default: return heff_nomatch(v_x2_2451);
    }
  } else {
    heff_drop(v_t_2449);
    V v_t_2454 = (g_heff_2ecompile_2esimplify_2esumTakenApart(heff_dup(v_x_240), heff_dup(v_a_241), heff_dup(v_b_242)));
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop(v_x_244);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2ecompile_2eir_2ewaysM_24s1573169724x333512686(v_x_240, v_b_242, v_a_241));
      return heff_tail(v_t_2455, 1, (V[]){v_s_243});
    } else {
      heff_drop(v_t_2454);
      HeffT2 v_t_2456 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_240), heff_dup(v_a_241), heff_dup(v_b_242)));
      {
        V v_field_2458 = v_t_2456.f[1];
        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
        if ((v_tag_2457 == ((int64_t)0ULL))) {
          heff_drop(v_x_244);
          V v_x11_2459 = v_field_2458;
          heff_drop(v_x11_2459);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2esetGiven_24s1335877526x24073442(v_x_240, v_a_241, v_b_242, v_s_243);
        } else {
          heff_drop(v_field_2458);
          V v_x_2460 = heff_dup(v_x_240);
          V v_a_2461 = heff_dup(v_a_241);
          V v_b_2462 = heff_dup(v_b_242);
          V v_t_24106;
          switch (heff_tag_of(v_a_2461)) {
          case TAG_EVar: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_a_2461, 0ULL, 3);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_a_2461, 0ULL, 4);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ETag: {
            V v_argv_2479 = heff_field(v_a_2461, 1);
            heff_take_n(v_a_2461, 2ULL, 3);
            V v_t_2481 = (g_list_2emap_24s584454411x1006678865(v_argv_2479));
            V v_x1_2482 = ({ V a_0 = v_t_2481; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2481); r_; });
            if (!(heff_dup(v_x1_2482) == NTAG(TAG_True))) {
              heff_drop(v_x1_2482);
              V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2462, NTAG(TAG_Nil)});
              V v_x_2484 = ({ V a_0 = v_x_2460; V a_1 = MK_INT(0LL); V a_2 = v_t_2483; V r_ = (g_heff_2ecompile_2esimplify_2escrutW(a_0, a_1, a_2)); heff_drop(v_x_2460); r_; });
              v_t_24106 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2484, 1));
              heff_drop(v_x_2484);
            } else {
              heff_drop(v_x_2460);
              heff_drop(v_b_2462);
              heff_drop(v_x1_2482);
              v_t_24106 = NTAG(TAG_False);
            }
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EAbandon: {
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_a_2461, 0ULL, 3);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_a_2461, 0ULL, 1);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_a_2461, 0ULL, 2);
            heff_drop(v_x_2460);
            heff_drop(v_b_2462);
            v_t_24106 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_a_2461);
          }
          if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
            heff_drop(v_x_244);
            heff_drop(v_t_24106);
            V v_m_24107 = (g_heff_2ecompile_2esimplify_2etagBound(v_a_241));
            V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_243}));
            switch (heff_tag_of(v_x2_24108)) {
            case TAG_MkPair: {
              V v_x_24109 = heff_field(v_x2_24108, 0);
              V v_s_24110 = heff_field(v_x2_24108, 1);
              V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
              V v_t_24113;
              switch (heff_tag_of(v_x_24109)) {
              case TAG_MkPair: {
                V v_y_24112 = heff_dup(heff_field(v_x_24109, 1));
                v_t_24113 = v_y_24112;
                break;
              }
              default: heff_nomatch(v_x_24109);
              }
              V v_x2_24114 = heff_tr(g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(v_x_240, v_t_24113, v_b_242, v_s_24110));
              switch (heff_tag_of(v_x2_24114)) {
              case TAG_MkPair: {
                V v_x_24115 = heff_field(v_x2_24114, 0);
                V v_s_24116 = heff_field(v_x2_24114, 1);
                heff_take_n(v_x2_24114, 3ULL, 2);
                V v_t_24119;
                switch (heff_tag_of(v_x_24109)) {
                case TAG_MkPair: {
                  V v_x_24117 = heff_field(v_x_24109, 0);
                  heff_take_n(v_x_24109, 1ULL, 2);
                  v_t_24119 = v_x_24117;
                  break;
                }
                default: heff_nomatch(v_x_24109);
                }
                V v_x_24120 = ({ V a_0 = v_t_24119; V a_1 = v_x_24115; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_24119); r_; });
                return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_x_24120, v_s_24116});
              }
              default: return heff_nomatch(v_x2_24114);
              }
            }
            default: return heff_nomatch(v_x2_24108);
            }
          } else {
            heff_drop(v_t_24106);
            V v_x_24121 = heff_dup(v_x_240);
            V v_a_24122 = heff_dup(v_a_241);
            V v_b_24123 = heff_dup(v_b_242);
            V v_t_24176;
            switch (heff_tag_of(v_a_24122)) {
            case TAG_EVar: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EGlobal: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ELam: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EApp: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ELet: {
              heff_take_n(v_a_24122, 0ULL, 3);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ERecord: {
              V v_fs_24133 = heff_field(v_a_24122, 0);
              heff_take_n(v_a_24122, 1ULL, 2);
              V v_t_24135 = (g_list_2emap_24s1044393341x1523302351(v_fs_24133));
              V v_x1_24136 = ({ V a_0 = v_t_24135; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24135); r_; });
              V v_t_24137 = heff_bool(!(heff_dup(v_x1_24136) == NTAG(TAG_True)));
              heff_drop(v_x1_24136);
              v_t_24176 = heff_bool(((heff_dup(v_t_24137) == NTAG(TAG_True)) && ({ V v_t_24138 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24123), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24139 = (g_heff_2ecompile_2eir_2ecountW(v_x_24121, MK_INT(0LL), heff_dup(v_t_24138))); int c_ = ({ V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24123), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24141 = (g_heff_2ecompile_2eir_2elamW(v_x_24121, heff_dup(v_t_24140))); int c_ = ({ V v_x_24142 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_24139), heff_dup(v_t_24141)}), 0, 2); int c_ = (heff_intLe_c_lent(MK_INT(2LL), v_x_24142, 1) && ({ V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24123), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24401 = (g_heff_2ecompile_2esimplify_2eprojW(v_x_24121, MK_INT(0LL), heff_dup(v_t_24143))); int c_ = ({ V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24123), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24145 = (g_heff_2ecompile_2eir_2ecountW(v_x_24121, MK_INT(0LL), heff_dup(v_t_24144))); int c_ = ({ V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24123), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24147 = (g_heff_2ecompile_2eir_2elamW(v_x_24121, heff_dup(v_t_24146))); int c_ = ({ V v_t_24402 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_24145), heff_dup(v_t_24147)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_24401, v_t_24402, 0); heff_drop(v_t_24402); c_; }); heff_drop(v_t_24147); c_; }); heff_drop(v_t_24146); c_; }); heff_drop(v_t_24145); c_; }); heff_drop(v_t_24144); c_; }); heff_drop(v_t_24401); c_; }); heff_drop(v_t_24143); c_; })); heff_drop(v_x_24142); c_; }); heff_drop(v_t_24141); c_; }); heff_drop(v_t_24140); c_; }); heff_drop(v_t_24139); c_; }); heff_drop(v_t_24138); c_; })));
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              heff_drop(v_t_24137);
              break;
            }
            case TAG_EProj: {
              heff_take_n(v_a_24122, 0ULL, 4);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ETag: {
              heff_take_n(v_a_24122, 0ULL, 3);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EMatch: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrim: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrimCall: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ECall: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EInt: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat: {
              heff_take_nf(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EStr: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EBytes: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EFixed: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat32: {
              heff_take_na(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EAbandon: {
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EBool: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_ESet: {
              heff_take_n(v_a_24122, 0ULL, 3);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EValues: {
              heff_take_n(v_a_24122, 0ULL, 1);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            case TAG_EFix: {
              heff_take_n(v_a_24122, 0ULL, 2);
              heff_drop(v_x_24121);
              heff_drop(v_b_24123);
              v_t_24176 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_a_24122);
            }
            if ((heff_dup(v_t_24176) == NTAG(TAG_True))) {
              heff_drop(v_x_244);
              heff_drop(v_t_24176);
              HEFF_LAST return g_heff_2ecompile_2esimplify_2erecordSplit_24s1905914641x1930589209(v_x_240, v_a_241, v_b_242, v_s_243);
            } else {
              heff_drop(v_t_24176);
              V v_t_24177 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
              V v_t_24178 = ({ V a_0 = v_t_24177; V a_1 = v_a_241; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_24177); r_; });
              if (((heff_dup(v_t_24178) == NTAG(TAG_True)) && ({ V v_t_24179 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24180 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_24179))); int c_ = ({ V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24182 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_24181))); int c_ = ({ V v_t_24403 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_24180), heff_dup(v_t_24182)}), 0, 2); int c_ = heff_intLe_c_lent(v_t_24403, MK_INT(8LL), 2); heff_drop(v_t_24403); c_; }); heff_drop(v_t_24182); c_; }); heff_drop(v_t_24181); c_; }); heff_drop(v_t_24180); c_; }); heff_drop(v_t_24179); c_; }))) {
                heff_drop(v_x_244);
                heff_drop(v_t_24178);
                V v_m_24183 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_242; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
                V v_x2_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_s_243}));
                switch (heff_tag_of(v_x2_24184)) {
                case TAG_MkPair: {
                  V v_x_24185 = heff_field(v_x2_24184, 0);
                  V v_s_24186 = heff_field(v_x2_24184, 1);
                  heff_take_n(v_x2_24184, 3ULL, 2);
                  V v_t_24187 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_24185));
                  return heff_tail(v_t_24187, 1, (V[]){v_s_24186});
                }
                default: return heff_nomatch(v_x2_24184);
                }
              } else {
                heff_drop(v_t_24178);
                V v_t_24234;
                if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
                  switch (heff_tag_of(v_a_241)) {
                  case TAG_EVar: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EGlobal: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ELam: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EApp: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ELet: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ERecord: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EProj: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ETag: {
                    V v_t_24206 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
                    V v_t_24207 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_24206));
                    V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
                    V v_t_24209 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_24208));
                    V v_t_24210 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24207, v_t_24209}), 0, 2);
                    if (heff_intEq_c(v_t_24210, MK_INT(1LL))) {
                      V v_t_24211 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
                      if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
                        heff_drop(v_t_24211);
                        v_t_24234 = NTAG(TAG_False);
                      } else {
                        heff_drop(v_t_24211);
                        V v_x1_24212 = (g_heff_2ecompile_2esimplify_2epartialIn(heff_dup(v_s_243), v_a_241));
                        if (!(heff_dup(v_x1_24212) == NTAG(TAG_True))) {
                          heff_drop(v_x1_24212);
                          v_t_24234 = (g_heff_2ecompile_2esimplify_2epastLastUse(v_x_240, heff_dup(v_a_241), heff_dup(v_b_242)));
                        } else {
                          heff_drop(v_x1_24212);
                          v_t_24234 = NTAG(TAG_False);
                        }
                      }
                    } else {
                      v_t_24234 = NTAG(TAG_False);
                    }
                    break;
                  }
                  case TAG_EMatch: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EPrim: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EPrimCall: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ECall: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EInt: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EFloat: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EStr: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EBytes: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EFixed: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EFloat32: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EAbandon: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EBool: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_ESet: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EValues: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_EFix: {
                    v_t_24234 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_241);
                  }
                } else {
                  v_t_24234 = NTAG(TAG_False);
                }
                if ((heff_dup(v_t_24234) == NTAG(TAG_True))) {
                  heff_drop(v_x_244);
                  heff_drop(v_t_24234);
                  V v_m_24235 = (g_heff_2ecompile_2esimplify_2etagBound(v_a_241));
                  V v_x2_24236 = heff_tr(heff_call(v_m_24235, 1, (V[]){v_s_243}));
                  switch (heff_tag_of(v_x2_24236)) {
                  case TAG_MkPair: {
                    V v_x_24237 = heff_field(v_x2_24236, 0);
                    V v_s_24238 = heff_field(v_x2_24236, 1);
                    V v_ru_24x2_24236_24MkPair = heff_take_reuse_n(v_x2_24236, 3ULL, 2);
                    V v_t_24241;
                    switch (heff_tag_of(v_x_24237)) {
                    case TAG_MkPair: {
                      V v_y_24240 = heff_dup(heff_field(v_x_24237, 1));
                      v_t_24241 = v_y_24240;
                      break;
                    }
                    default: heff_nomatch(v_x_24237);
                    }
                    V v_x2_24242 = heff_tr(g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(v_x_240, v_t_24241, v_b_242, v_s_24238));
                    switch (heff_tag_of(v_x2_24242)) {
                    case TAG_MkPair: {
                      V v_x_24243 = heff_field(v_x2_24242, 0);
                      V v_s_24244 = heff_field(v_x2_24242, 1);
                      heff_take_n(v_x2_24242, 3ULL, 2);
                      V v_t_24247;
                      switch (heff_tag_of(v_x_24237)) {
                      case TAG_MkPair: {
                        V v_x_24245 = heff_field(v_x_24237, 0);
                        heff_take_n(v_x_24237, 1ULL, 2);
                        v_t_24247 = v_x_24245;
                        break;
                      }
                      default: heff_nomatch(v_x_24237);
                      }
                      V v_x_24248 = ({ V a_0 = v_t_24247; V a_1 = v_x_24243; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_24247); r_; });
                      return heff_tag_at_n(v_ru_24x2_24236_24MkPair, TAG_MkPair, 2, (V[]){v_x_24248, v_s_24244});
                    }
                    default: return heff_nomatch(v_x2_24242);
                    }
                  }
                  default: return heff_nomatch(v_x2_24236);
                  }
                } else {
                  heff_drop(v_t_24234);
                  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
                    heff_drop(v_x_244);
                    V v_t_24249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
                    V v_t_24250 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_24249));
                    V v_t_24251 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
                    V v_t_24252 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_24251));
                    V v_t_24253 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24250, v_t_24252}), 0, 2);
                    return (g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(v_x_240, v_a_241, v_b_242, v_t_24253, v_s_243));
                  } else {
                    heff_drop(v_x_244);
                    V v_s_24254 = heff_dup(v_s_243);
                    V v_x2_24255 = heff_dup(v_a_241);
                    V v_t_24381;
                    switch (heff_tag_of(v_x2_24255)) {
                    case TAG_EVar: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EGlobal: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_ELam: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EApp: {
                      V v_x21_24260 = heff_field(v_x2_24255, 0);
                      V v_argv_24261 = heff_field(v_x2_24255, 1);
                      heff_take_n(v_x2_24255, 3ULL, 2);
                      switch (heff_tag_of(v_x21_24260)) {
                      case TAG_EVar: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EGlobal: {
                        V v_g_24263 = heff_field(v_x21_24260, 0);
                        heff_take_n(v_x21_24260, 1ULL, 1);
                        V v_argv_24264 = v_argv_24261;
                        V v_t_24265 = heff_get_n(heff_get_n(v_s_24254, 7, 10), 0, 7);
                        HeffT2 v_t_24266 = ({ V a_0 = v_t_24265; V a_1 = v_g_24263; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_24265); heff_drop(v_g_24263); r_; });
                        {
                          V v_field_24268 = v_t_24266.f[1];
                          int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
                          if ((v_tag_24267 == ((int64_t)0ULL))) {
                            V v_x21_24269 = v_field_24268;
                            switch (heff_tag_of(v_x21_24269)) {
                            case TAG_EVar: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EGlobal: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ELam: {
                              V v_xs_24272 = heff_field(v_x21_24269, 0);
                              heff_take_n(v_x21_24269, 1ULL, 2);
                              V v_t_24274 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_24264; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_24264); r_; });
                              V v_t_24275 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24272; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24272); r_; });
                              v_t_24381 = heff_bool(heff_intLt_c_lent(v_t_24274, v_t_24275, 0));
                              heff_drop(v_t_24274);
                              heff_drop(v_t_24275);
                              break;
                            }
                            case TAG_EApp: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ELet: {
                              heff_take_n(v_x21_24269, 0ULL, 3);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ERecord: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EProj: {
                              heff_take_n(v_x21_24269, 0ULL, 4);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ETag: {
                              heff_take_n(v_x21_24269, 0ULL, 3);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EMatch: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EPrim: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EPrimCall: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ECall: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EInt: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EFloat: {
                              heff_take_nf(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EStr: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EBytes: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EFixed: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EFloat32: {
                              heff_take_na(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EAbandon: {
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EBool: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_ESet: {
                              heff_take_n(v_x21_24269, 0ULL, 3);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EValues: {
                              heff_take_n(v_x21_24269, 0ULL, 1);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            case TAG_EFix: {
                              heff_take_n(v_x21_24269, 0ULL, 2);
                              heff_drop(v_argv_24264);
                              v_t_24381 = NTAG(TAG_False);
                              break;
                            }
                            default: heff_nomatch(v_x21_24269);
                            }
                          } else {
                            heff_drop(v_argv_24264);
                            heff_drop(v_field_24268);
                            v_t_24381 = NTAG(TAG_False);
                          }
                        }
                        break;
                      }
                      case TAG_ELam: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EApp: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_ELet: {
                        heff_take_n(v_x21_24260, 0ULL, 3);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_ERecord: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EProj: {
                        heff_take_n(v_x21_24260, 0ULL, 4);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_ETag: {
                        heff_take_n(v_x21_24260, 0ULL, 3);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EMatch: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EPrim: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EPrimCall: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_ECall: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EInt: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EFloat: {
                        heff_take_nf(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EStr: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EBytes: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EFixed: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EFloat32: {
                        heff_take_na(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EAbandon: {
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EBool: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_ESet: {
                        heff_take_n(v_x21_24260, 0ULL, 3);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EValues: {
                        heff_take_n(v_x21_24260, 0ULL, 1);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_EFix: {
                        heff_take_n(v_x21_24260, 0ULL, 2);
                        heff_drop_rec(v_s_24254, 10);
                        heff_drop(v_argv_24261);
                        v_t_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_x21_24260);
                      }
                      break;
                    }
                    case TAG_ELet: {
                      heff_take_n(v_x2_24255, 0ULL, 3);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_ERecord: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EProj: {
                      heff_take_n(v_x2_24255, 0ULL, 4);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_ETag: {
                      heff_take_n(v_x2_24255, 0ULL, 3);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EMatch: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EPrim: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EPrimCall: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_ECall: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EInt: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EFloat: {
                      heff_take_nf(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EStr: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EBytes: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EFixed: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EFloat32: {
                      heff_take_na(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EAbandon: {
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EBool: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_ESet: {
                      heff_take_n(v_x2_24255, 0ULL, 3);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EValues: {
                      heff_take_n(v_x2_24255, 0ULL, 1);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_EFix: {
                      heff_take_n(v_x2_24255, 0ULL, 2);
                      heff_drop_rec(v_s_24254, 10);
                      v_t_24381 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_x2_24255);
                    }
                    if ((heff_dup(v_t_24381) == NTAG(TAG_True))) {
                      heff_drop(v_t_24381);
                      HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit_24s1426540740x674192921(v_x_240, v_a_241, v_b_242, v_s_243);
                    } else {
                      heff_drop(v_t_24381);
                      V v_t_24382 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
                      V v_t_24383 = (g_heff_2ecompile_2esimplify_2ecalledFirst(v_t_24382, v_x_240, v_b_242));
                      if (((heff_dup(v_t_24383) == NTAG(TAG_True)) && ({ V v_t_24384 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24385 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_24384))); int c_ = ({ V v_t_24386 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24387 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_24386))); int c_ = ({ V v_t_24404 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_24385), heff_dup(v_t_24387)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_24404, MK_INT(1LL), 2); heff_drop(v_t_24404); c_; }); heff_drop(v_t_24387); c_; }); heff_drop(v_t_24386); c_; }); heff_drop(v_t_24385); c_; }); heff_drop(v_t_24384); c_; }))) {
                        heff_drop(v_t_24383);
                        V v_m_24388 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), v_x_240, v_a_241));
                        V v_t_24389 = (g_std_2eordmap_2esize(v_m_24388));
                        V v_e_24390;
                        if (heff_intEq_c(v_t_24389, MK_INT(0LL))) {
                          heff_drop(v_m_24388);
                          v_e_24390 = v_b_242;
                        } else {
                          v_e_24390 = ({ V a_0 = v_m_24388; V a_1 = v_b_242; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_24388); r_; });
                        }
                        V v_t_24391 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_24390));
                        return heff_tail(v_t_24391, 1, (V[]){v_s_243});
                      } else {
                        heff_drop(v_t_24383);
                        V v_m_24392 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
                        V v_x2_24393 = heff_tr(heff_call(v_m_24392, 1, (V[]){v_s_243}));
                        switch (heff_tag_of(v_x2_24393)) {
                        case TAG_MkPair: {
                          V v_x_24394 = heff_field(v_x2_24393, 0);
                          V v_s_24395 = heff_field(v_x2_24393, 1);
                          V v_ru_24x2_24393_24MkPair = heff_take_reuse_n(v_x2_24393, 3ULL, 2);
                          HeffT2 v_t_24396 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_240), heff_dup(v_a_241), heff_dup(v_x_24394)));
                          {
                            V v_field_24398 = v_t_24396.f[1];
                            int64_t v_tag_24397 = ((int64_t)v_t_24396.f[0]);
                            V v_t_24400;
                            if ((v_tag_24397 == ((int64_t)0ULL))) {
                              heff_drop(v_x_240);
                              heff_drop(v_a_241);
                              heff_drop(v_x_24394);
                              V v_x_24399 = v_field_24398;
                              v_t_24400 = v_x_24399;
                            } else {
                              heff_drop(v_field_24398);
                              v_t_24400 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_24394});
                            }
                            return heff_tag_at_n(v_ru_24x2_24393_24MkPair, TAG_MkPair, 2, (V[]){v_t_24400, v_s_24395});
                          }
                        }
                        default: return heff_nomatch(v_x2_24393);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_ELet: {
    V v_y_243 = heff_field(v_a_241, 0);
    V v_a1_244 = heff_field(v_a_241, 1);
    V v_a2_245 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    V v_m_246 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(v_x_240, v_a2_245, v_b_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam0, 1, 3, (V[]){v_m_246, v_y_243, v_a1_244});
  }
  case TAG_ESet: {
    V v_ys_2411 = heff_field(v_a_241, 0);
    V v_a1_2412 = heff_field(v_a_241, 1);
    V v_a2_2413 = heff_field(v_a_241, 2);
    heff_take_n(v_a_241, 7ULL, 3);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(v_x_240, v_a2_2413, v_b_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam1, 1, 3, (V[]){v_m_2414, v_ys_2411, v_a1_2412});
  }
  default: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_24s1318498825x257052447_clo), 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_243 = heff_env(self)[1];
  V v_a1_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_243, v_a1_244, v_x_249}), v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_24s2038920601x1082732652_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_ys_2411 = heff_env(self)[1];
  V v_a1_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2411, v_a1_2412, v_x_2417}), v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleCopy_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esettleCopy(V v_more_240, V v_n_241, V v_h_242, V v_b_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
  V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
  V v_m_247 = heff_tr(heff_call(heff_dup(v_more_240), 1, (V[]){v_t_246}));
  V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){heff_dup(v_s_244)}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_intLt_c_lent(MK_INT(0LL), v_n_241, 1)) {
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_244, heff_dup(v_s_2410), heff_dup(v_b_243)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(heff_dup(v_h_242), v_b_243, v_s_2410));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_s_2416 = v_field_2414;
          V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, heff_intSub(v_n_241, MK_INT(1LL)), v_h_242, v_x_2415}));
          V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_s_2420 = heff_field(v_x2_2418, 1);
            V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
            V v_t_2423;
            switch (heff_tag_of(v_x_2419)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_dup(heff_field(v_x_2419, 0));
              v_t_2423 = v_x_2421;
              break;
            }
            default: heff_nomatch(v_x_2419);
            }
            V v_t_2426;
            switch (heff_tag_of(v_x_2419)) {
            case TAG_MkPair: {
              V v_y_2425 = heff_field(v_x_2419, 1);
              heff_take_n(v_x_2419, 2ULL, 2);
              v_t_2426 = v_y_2425;
              break;
            }
            default: heff_nomatch(v_x_2419);
            }
            V v_t_2427 = (g_prelude_2e_2b_2b(v_x_249, v_t_2426));
            V v_x_2428 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_t_2427});
            return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2420});
          }
          default: return heff_nomatch(v_x2_2418);
          }
        }
      } else {
        heff_drop(v_more_240);
        heff_drop(v_n_241);
        heff_drop(v_h_242);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
      }
    } else {
      heff_drop(v_more_240);
      heff_drop(v_n_241);
      heff_drop(v_h_242);
      heff_drop(v_s_244);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleCopy(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(a[0], a[1]);
}