// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_depths 611816763
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_project 2070030684
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallJust_24cpr(V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2earmsPushable(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuiltFieldOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltFieldOf_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaLets(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_clo;
V g_heff_2ecompile_2esimplify_2eetaLets_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(V, V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_24tok1_clo;
V g_heff_2ecompile_2esimplify_2efollowOver(V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2einitL(V);
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_clo;
V g_heff_2ecompile_2esimplify_2einitL_24dps(V, V);
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_clo;
V g_heff_2ecompile_2esimplify_2especShaped_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_24tok2_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall_24s44244667x1445755514(V, V);
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a);
extern Clo g_list_2eall_24s44244667x1445755514_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s504671899x323346652_24cpr(V, V, V, V);
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;

HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_b_244));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_ys_248 = v_field_246;
      V v_b_249 = v_field_247;
      V v_f_2410 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x1_240_24ELam, v_xs_243, v_ys_248));
      return ((HeffT2){{v_f_2410, v_b_249}});
    }
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBool: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ESet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EValues: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2einitL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einitL_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2einitL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2esimplify_2einitL_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einitL(a[0]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eallJust_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eallJust_24cpr(v_rest_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_x_247 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_x_247})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebindArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam0, 1, 1, (V[]){v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam1, 2, 1, (V[]){v_argv_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2445 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2445 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
    heff_drop(v_t_2445);
    V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_p_245});
  } else {
    heff_drop(v_t_2445);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_str0), v_p_245));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_x_2450 = v_field_2448;
      V v_s_2451 = v_field_2449;
      V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2450), v_a_243})});
      V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2450})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_s_2451});
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args) {
  V v_one_2454 = args[0];
  V v_z_2455 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_clo), 1, (V[]){v_argv_244}));
  V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_z_2455}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_t_2467;
    switch (heff_tag_of(v_one_2454)) {
    case TAG_MkPair: {
      V v_x11_2460 = heff_field(v_one_2454, 0);
      V v_a_2461 = heff_field(v_one_2454, 1);
      heff_take_n(v_one_2454, 3ULL, 2);
      switch (heff_tag_of(v_x11_2460)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2458)) {
        case TAG_MkPair: {
          V v_bds_2462 = heff_field(v_x_2458, 0);
          V v_argv_2463 = heff_field(v_x_2458, 1);
          heff_take_n(v_x_2458, 3ULL, 2);
          v_t_2467 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2462, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2461, v_argv_2463})});
          break;
        }
        default: heff_nomatch(v_x_2458);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2464 = heff_field(v_x11_2460, 0);
        heff_take_n(v_x11_2460, 1ULL, 1);
        switch (heff_tag_of(v_x_2458)) {
        case TAG_MkPair: {
          V v_bds_2465 = heff_field(v_x_2458, 0);
          V v_argv_2466 = heff_field(v_x_2458, 1);
          heff_take_n(v_x_2458, 3ULL, 2);
          v_t_2467 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2464, v_bds_2465}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2461, v_argv_2466})});
          break;
        }
        default: heff_nomatch(v_x_2458);
        }
        break;
      }
      default: heff_nomatch(v_x11_2460);
      }
      break;
    }
    default: heff_nomatch(v_one_2454);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2467, v_s_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
Clo g_heff_2ecompile_2esimplify_2efollowOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowOver_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efollowOver(V v_a_240, V v_b_241) {
top: ;
  V v_x1_242 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_240)));
  V v_x_246;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_ts_243 = heff_field(v_x1_242, 0);
    V v_n_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_243); r_; });
    v_x_246 = heff_intAdd(v_t_245, v_n_244);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  if (heff_intLt_c(MK_INT(1LL), v_x_246)) {
    V v_x1_247 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_a_240));
    V v_t_2411;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_ts_248 = heff_field(v_x1_247, 0);
      V v_n_249 = heff_field(v_x1_247, 1);
      heff_take_n(v_x1_247, 3ULL, 2);
      V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_248); r_; });
      v_t_2411 = heff_intAdd(v_t_2410, v_n_249);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_lim_2412 = heff_intDiv(MK_INT(100LL), heff_intSub(v_t_2411, MK_INT(1LL)));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
    V v_x_2414 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2412), MK_INT(0LL), v_t_2413));
    V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_lim_2412, v_x_2414, 0));
    heff_drop(v_lim_2412);
    heff_drop(v_x_2414);
    return v_ret_24bool;
  } else {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2efollowOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_t_2414);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_247});
  } else {
    heff_drop(v_t_2414);
    V v_k_2416 = (g_heff_2ecompile_2esimplify_2especKey(heff_dup(v_g_241), heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 1)), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_j_2417 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_str0), v_g_241, MK_INT(0LL), 5);
    V v_t_2418;
    if (heff_intLt_c_lent(v_j_2417, MK_INT(0LL), 2)) {
      heff_drop(v_j_2417);
      v_t_2418 = heff_dup(v_g_241);
    } else {
      v_t_2418 = heff_strSlice_lent(v_g_241, MK_INT(0LL), v_j_2417, 6);
    }
    V v_t_2419 = ({ V a_0 = v_k_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_k_2416); r_; });
    V v_t_2420 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str1), v_t_2419));
    V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_t_2422 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2423 = ({ V a_0 = v_t_2421; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2422; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_sh_246, v_t_2420, v_t_2423, v_s_247));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_x1_247);
    V v_x_248 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_z_246});
  } else {
    heff_drop(v_x1_247);
    V v_x1_249 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      V v_t_2410 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2411 = (g_heff_2ecompile_2eir_2enubI(v_t_2410));
      V v_t_2412 = ({ V a_0 = v_g_241; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_x1_2413 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        if (!(heff_dup(v_x1_2413) == NTAG(TAG_True))) {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          heff_drop(v_x1_2413);
          V v_x_2414 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_z_246});
        } else {
          heff_drop(v_x1_2413);
          HeffT2 v_t_2415 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
          {
            V v_field_2416 = v_t_2415.f[0];
            V v_field_2417 = v_t_2415.f[1];
            V v_x_2418 = v_field_2416;
            V v_s_2419 = v_field_2417;
            return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2418, v_s_2419));
          }
        }
      } else {
        heff_drop(v_t_2412);
        HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          V v_x_2423 = v_field_2421;
          V v_s_2424 = v_field_2422;
          return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2423, v_s_2424));
        }
      }
    }
    case TAG_Cons: {
      V v_ru_24x1_249_24Cons = heff_take_reuse_n(v_x1_249, 0ULL, 2);
      HeffT2 v_t_2427 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
      {
        V v_field_2428 = v_t_2427.f[0];
        V v_field_2429 = v_t_2427.f[1];
        V v_x_2430 = v_field_2428;
        V v_s_2431 = v_field_2429;
        return (g_heff_2ecompile_2esimplify_2especShaped_24tok2(v_ru_24x1_249_24Cons, v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2430, v_s_2431));
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
  }
  case TAG_Cons: {
    V v_m_243 = heff_dup(heff_field(v_x1_240, 0));
    V v_ms_244 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
    }
    case TAG_Cons: {
      V v_n_245 = heff_field(v_x2_241, 0);
      V v_ns_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_247 = heff_bool(((heff_dup(v_m_243) == NTAG(TAG_True)) || (heff_dup(v_n_245) == NTAG(TAG_True))));
      heff_drop(v_m_243);
      heff_drop(v_n_245);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ms_244;
      V t_1 = v_ns_246;
      V t_2 = v_cell_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_a_248 = heff_field(v_x1_240, 1);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_e_249));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_bds_2413 = v_field_2411;
      V v_e_2414 = v_field_2412;
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bds_2413});
      return ((HeffT2){{v_t_2415, v_e_2414}});
    }
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBool: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ESet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EValues: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArgs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaArgs(V v_r_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam0, 1, 1, (V[]){v_x3_242});
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x2_241, 0);
    V v_sts_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_r_240);
      heff_drop(v_st_245);
      heff_drop(v_sts_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam1, 1, 1, (V[]){v_x3_242});
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_x3_242, 0);
      V v_argv_2410 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_m_2411 = (g_heff_2ecompile_2esimplify_2eetaArgs(heff_dup(v_r_240), v_sts_246, v_argv_2410));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam2, 1, 4, (V[]){v_m_2411, v_a_249, v_r_240, v_st_245});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_s_243});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_st_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2eletsOut(v_a_249));
    return ({ V a_0 = v_ru_24x2_2413_24MkPair; V a_1 = v_r_240; V a_2 = v_st_245; V a_3 = v_t_2416; V a_4 = v_x_2414; V a_5 = v_s_2415; V r_ = (g_heff_2ecompile_2esimplify_2eetaLets_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_245); r_; });
  }
  default: return heff_nomatch(v_x2_2413);
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(V v_l_240, V v_e_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EApp: {
    V v_e1_247 = heff_field(v_e_241, 0);
    V v_argv_248 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_247)) {
    case TAG_EVar: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EGlobal: {
      V v_g_2410 = heff_field(v_e1_247, 0);
      V v_ru_24e1_247_24EGlobal = heff_take_reuse_n(v_e1_247, 1ULL, 1);
      V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_p_242, 7)), 0, 7);
      V v_t_2412 = ({ V a_0 = v_ru_24e1_247_24EGlobal; V a_1 = v_t_2411; V a_2 = v_g_2410; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(a_0, a_1, a_2)); heff_drop(v_t_2411); heff_drop(v_g_2410); r_; });
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2412, v_p_242));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        V v_s_2417 = v_field_2415;
        V v_x_2418 = (g_heff_2ecompile_2esimplify_2ebuiltFieldOf(v_l_240, v_argv_248, v_x_2416));
        return ((HeffT2){{v_x_2418, v_s_2417}});
      }
    }
    case TAG_ELam: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_ELet: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EProj: {
      heff_take_n(v_e1_247, 0ULL, 4);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_ECall: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EStr: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EAbandon: {
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EBool: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_ESet: {
      heff_take_n(v_e1_247, 0ULL, 3);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EValues: {
      heff_take_n(v_e1_247, 0ULL, 1);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    case TAG_EFix: {
      heff_take_n(v_e1_247, 0ULL, 2);
      heff_drop(v_argv_248);
      return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
    }
    default: return ((HeffT2){{heff_nomatch(v_e1_247)}});
    }
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return ((HeffT2){{NTAG(TAG_Nothing), v_p_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecaseOfCase_str0, 5, "given");
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2esimplify_2earmsPushable(MK_INT(40LL), heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s2_241), heff_dup(v_arms2_242)}), v_arms_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0, 1, 4, (V[]){v_r_240, v_arms_243, v_arms2_242, v_s2_241});
  } else {
    heff_drop(v_r_240);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_arms_243, v_s2_241, v_arms2_242});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_arms_243 = heff_env(self)[1];
  V v_arms2_242 = heff_env(self)[2];
  V v_s2_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_246 = (g_prelude_2etraverse_24s504671899x323346652_24cpr(v_r_240, v_arms_243, v_arms2_242, v_s_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_x_249}), v_s_2410});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_arms_243 = heff_env(self)[0];
  V v_s2_241 = heff_env(self)[1];
  V v_arms2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ecaseOfCase_str0), v_s_2411));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    V v_s_2416 = v_field_2414;
    V v_t_2417 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2415)}), heff_dup(v_arms_243)});
    HeffT2 v_t_2418 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(v_x_2415, heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s2_241), heff_dup(v_arms2_242)}), v_t_2417));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_t_2422;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_arms_243);
        heff_drop(v_s2_241);
        heff_drop(v_arms2_242);
        V v_x_2421 = v_field_2420;
        v_t_2422 = v_x_2421;
      } else {
        heff_drop(v_field_2420);
        v_t_2422 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_s_2416});
    }
  }
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam1, 2, 0};
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam2, 4, 0};
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2ecompile_2esimplify_2esk_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2esk_st;
static V g_heff_2ecompile_2esimplify_2esk_init(void) {
  return heff_rec_n(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2ecompile_2esimplify_2esk_lam0_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam1_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam2_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam3_clo)});
}
V g_heff_2ecompile_2esimplify_2esk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2esk_st)) return g_heff_2ecompile_2esimplify_2esk_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2esk_val, &g_heff_2ecompile_2esimplify_2esk_st, g_heff_2ecompile_2esimplify_2esk_init);
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_argv_242 = args[1];
  return (g_heff_2ecompile_2esimplify_2eapplyToF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_f_241, v_argv_242));
}
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_sh_244 = args[1];
  V v_t_245 = args[2];
  V v_e_246 = args[3];
  return (g_heff_2ecompile_2esimplify_2eprojectF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_l_243, v_sh_244, v_t_245, v_e_246));
}
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_247 = args[0];
  V v_arms_248 = args[1];
  return (g_heff_2ecompile_2esimplify_2ematchF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_s_247, v_arms_248));
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str1, 0, "");
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeOf(V v_st_240, V v_bodies_241, V v_h_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_t_247 = v_field_246;
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
      V v_t_249 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2emap_2eempty_get()), v_t_248));
      V v_tv_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2emadeOf_lam0, 1, 1, (V[]){v_st_240}), v_t_249));
      HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_bodies_241, v_h_242));
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_b_2421 = v_field_2420;
          V v_t_2422 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str1); V a_1 = v_tv_2417; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); r_; });
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_t_2422);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2421, v_tv_2417})});
          } else {
            heff_drop(v_tv_2417);
            heff_drop(v_b_2421);
            heff_drop(v_t_2422);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_tv_2417);
          heff_drop(v_field_2420);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_st_240, 9);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2emadeOf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args) {
  V v_h_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_get_n(heff_get_n(v_st_240, 8, 9), 0, 5);
  HeffT2 v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_h_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2416;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2414);
      v_t_2416 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2410, v_t_2416});
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1(V v_tok_240, V v_p_241, V v_argv_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EPrim, 1, (V[]){v_p_241}), v_argv_242});
  }
  case TAG_Just: {
    V v_n_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    if (heff_intEq_c_lent(v_t_245, v_n_244, 1)) {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_n_244);
      return (g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(v_ru_24x3_243_24Just, v_p_241, v_argv_242));
    } else {
      V v_x_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
      if (heff_intLt_c_lent(v_n_244, v_x_246, 2)) {
        heff_drop_cell(v_tok_240, 1);
        V v_t_247 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_244), heff_dup(v_argv_242)));
        V v_t_248 = (g_heff_2ecompile_2esimplify_2efoldPrim_24tok1(v_ru_24x3_243_24Just, v_p_241, v_t_247));
        V v_t_249 = (g_heff_2ecompile_2esimplify_2edropL(v_n_244, v_argv_242));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_248, v_t_249});
      } else {
        heff_drop(v_n_244);
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EPrim, 1, (V[]){v_p_241}), v_argv_242});
      }
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN_24tok1(a[0], a[1], a[2], a[3]);
}