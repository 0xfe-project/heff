// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eafresh_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2earmsPushable(V, V, V);
V g_heff_2ecompile_2esimplify_2earmsPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmsPushable_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaArg(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArg_clo;
V g_heff_2ecompile_2esimplify_2eetaArgs(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2eetaLets(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2ecompile_2esimplify_2eetaOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaOne_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V);
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
V g_heff_2ecompile_2esimplify_2efollowOver(V, V);
V g_heff_2ecompile_2esimplify_2efollowOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efollowOver_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eknowing_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eoneItem_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especKey(V, V, V, V);
V g_heff_2ecompile_2esimplify_2especKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especKey_clo;
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esumOver(V, V, V);
V g_heff_2ecompile_2esimplify_2esumOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumOver_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagApart(V, V, V);
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagApart_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etouch_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eunOp_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall_24s1194065168x228565983(V, V);
V g_list_2eall_24s1194065168x228565983_entry(V self, V *a);
extern Clo g_list_2eall_24s1194065168x228565983_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
HeffT2 g_prelude_2etraverse_24s504671899x323346652_24cpr(V, V, V, V);
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattemptBy_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eattemptBy(V v_more_240, V v_orig_241, V v_m_242, V v_s_243) {
top: ;
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){heff_dup(v_s_243)}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_orig_241), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_247));
    V v_lim_249 = heff_intAdd(v_t_248, v_more_240);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), NTAG(TAG_Nil)});
    V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_249), MK_INT(0LL), v_t_2410));
    if (heff_intLt_c(v_lim_249, v_x_2411)) {
      heff_drop(v_x_245);
      V v_t_2413 = ({ V rv_2 = heff_take_field(v_s_243, 2); V rv_5 = heff_get_n(v_s_243, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_246, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_orig_241, v_t_2413});
    } else {
      heff_drop(v_orig_241);
      heff_drop_rec(v_s_243, 9);
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_s_246});
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattemptBy(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eflat_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2eflat_24cpr(v_b_244));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_ys_248 = v_field_246;
      V v_b_249 = v_field_247;
      V v_f_2410 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_243, v_ys_248));
      return ((HeffT2){{v_f_2410, v_b_249}});
    }
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldPrim_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efoldPrim(V v_p_240, V v_argv_241) {
top: ;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
  }
  case TAG_Cons: {
    V v_a_242 = heff_dup(heff_field(v_argv_241, 0));
    V v_x22_243 = heff_dup(heff_field(v_argv_241, 1));
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eunOp_24cpr(v_p_240, v_a_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          heff_drop(v_p_240);
          heff_drop_tag(v_argv_241, 2);
          V v_x_248 = v_field_246;
          return v_x_248;
        } else {
          heff_drop(v_field_246);
          return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
        }
      }
    }
    case TAG_Cons: {
      V v_b_249 = heff_field(v_x22_243, 0);
      V v_x222_2410 = heff_field(v_x22_243, 1);
      V v_ru_24x22_243_24Cons = heff_take_reuse_n(v_x22_243, 3ULL, 2);
      switch (heff_tag_of(v_x222_2410)) {
      case TAG_Nil: {
        HeffT2 v_t_2411 = (g_heff_2ecompile_2esimplify_2ebinOp_24cpr(v_p_240, v_a_242, v_b_249));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_p_240);
            heff_drop_tag(v_argv_241, 2);
            heff_drop_cell(v_ru_24x22_243_24Cons, 2);
            V v_x_2415 = v_field_2413;
            return v_x_2415;
          } else {
            heff_drop(v_field_2413);
            return heff_tag_at_n(v_ru_24x22_243_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x222_2410, 0ULL, 2);
        heff_drop(v_a_242);
        heff_drop(v_b_249);
        return heff_tag_at_n(v_ru_24x22_243_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
      }
      default: return heff_nomatch(v_x222_2410);
      }
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_argv_241);
  }
}
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldPrim(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindArgs_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebindArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam0, 1, 1, (V[]){v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindArgs_lam1, 2, 1, (V[]){v_argv_244}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindArgs(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EBytes: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2440 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2440 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_t_2440);
    V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_p_245});
  } else {
    heff_drop(v_t_2440);
    HeffT2 v_t_2442 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_str0), v_p_245));
    {
      V v_field_2443 = v_t_2442.f[0];
      V v_field_2444 = v_t_2442.f[1];
      V v_x_2445 = v_field_2443;
      V v_s_2446 = v_field_2444;
      V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2445), v_a_243})});
      V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2445})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_s_2446});
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindArgs_lam1(V self, V *args) {
  V v_one_2449 = args[0];
  V v_z_2450 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ebindArgs_clo), 1, (V[]){v_argv_244}));
  V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_z_2450}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_one_2449)) {
    case TAG_MkPair: {
      V v_x11_2455 = heff_field(v_one_2449, 0);
      V v_a_2456 = heff_field(v_one_2449, 1);
      heff_take_n(v_one_2449, 3ULL, 2);
      switch (heff_tag_of(v_x11_2455)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2453)) {
        case TAG_MkPair: {
          V v_bds_2457 = heff_field(v_x_2453, 0);
          V v_argv_2458 = heff_field(v_x_2453, 1);
          heff_take_n(v_x_2453, 3ULL, 2);
          v_t_2462 = heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2457, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2456, v_argv_2458})});
          break;
        }
        default: heff_nomatch(v_x_2453);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2459 = heff_field(v_x11_2455, 0);
        heff_take_n(v_x11_2455, 1ULL, 1);
        switch (heff_tag_of(v_x_2453)) {
        case TAG_MkPair: {
          V v_bds_2460 = heff_field(v_x_2453, 0);
          V v_argv_2461 = heff_field(v_x_2453, 1);
          heff_take_n(v_x_2453, 3ULL, 2);
          v_t_2462 = heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2459, v_bds_2460}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2456, v_argv_2461})});
          break;
        }
        default: heff_nomatch(v_x_2453);
        }
        break;
      }
      default: heff_nomatch(v_x11_2455);
      }
      break;
    }
    default: heff_nomatch(v_one_2449);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
Clo g_heff_2ecompile_2esimplify_2efollowOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efollowOver_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efollowOver(V v_a_240, V v_b_241) {
top: ;
  V v_x1_242 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_dup(v_a_240)));
  V v_x_246;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_ts_243 = heff_field(v_x1_242, 0);
    V v_n_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_243); r_; });
    v_x_246 = heff_intAdd(v_t_245, v_n_244);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  if (heff_intLt_c(MK_INT(1LL), v_x_246)) {
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_a_240));
    V v_t_2412;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_MkPair: {
      V v_ts_249 = heff_field(v_x1_248, 0);
      V v_n_2410 = heff_field(v_x1_248, 1);
      heff_take_n(v_x1_248, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_249; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_249); r_; });
      v_t_2412 = heff_intAdd(v_t_2411, v_n_2410);
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_lim_2413 = heff_intDiv(MK_INT(100LL), heff_intSub(v_t_2412, MK_INT(1LL)));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
    V v_x_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2413), MK_INT(0LL), v_t_2414));
    return heff_intLt(v_lim_2413, v_x_2415);
  } else {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2esimplify_2efollowOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efollowOver(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esumTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_a_241, 0);
    V v_arms_2422 = heff_field(v_a_241, 1);
    V v_ru_24a_241_24EMatch = heff_take_reuse_n(v_a_241, 3ULL, 2);
    V v_x1_2423 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_tag_at_n(v_ru_24a_241_24EMatch, TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)})));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_MkPair: {
      V v_ts_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 2);
      V v_x_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2424; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2424); r_; });
      v_t_2427 = heff_intLt(MK_INT(0LL), v_x_2426);
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    V v_ret_24bool = heff_bool(((heff_dup(v_t_2427) == NTAG(TAG_True)) && ({ V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2429 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), heff_dup(v_t_2428))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_2429, 1) && ({ V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2432 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), heff_dup(v_t_2431))); int c_ = ({ V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2434 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2433))); int c_ = ({ V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2436 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2435))); int c_ = ({ V v_t_2437 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2434), heff_dup(v_t_2436)}), 0, 2); int c_ = (heff_intEq_c_lent(v_t_2432, v_t_2437, 0) && ({ V v_x1_2439 = (g_heff_2ecompile_2esimplify_2esumOver(v_x_240, heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)}), heff_dup(v_b_242))); int c_ = !(heff_dup(v_x1_2439) == NTAG(TAG_True)); heff_drop(v_x1_2439); c_; })); heff_drop(v_t_2437); c_; }); heff_drop(v_t_2436); c_; }); heff_drop(v_t_2435); c_; }); heff_drop(v_t_2434); c_; }); heff_drop(v_t_2433); c_; }); heff_drop(v_t_2432); c_; }); heff_drop(v_t_2431); c_; })); heff_drop(v_x_2429); c_; }); heff_drop(v_t_2428); c_; })));
    heff_drop(v_b_242);
    heff_drop(v_s_2421);
    heff_drop(v_arms_2422);
    heff_drop(v_t_2427);
    return v_ret_24bool;
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esumTakenApart(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2etagApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etagApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_argv_2419 = heff_field(v_a_241, 1);
    V v_t_2421 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_argv_2419)));
    V v_x1_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2421); r_; });
    V v_ret_24bool = heff_bool(((heff_dup(v_x1_2422) == NTAG(TAG_True)) ? 0 : ({ V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_x_2424 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), heff_dup(v_t_2423))); int c_ = heff_intLt_c_lent(MK_INT(0LL), v_x_2424, 1); heff_drop(v_x_2424); c_; }); heff_drop(v_t_2423); c_; })));
    heff_drop(v_b_242);
    heff_drop(v_x1_2422);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etagApart(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ewordLiteral_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ewordLiteral(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    V v_i_2426 = heff_field(v_e_240, 0);
    V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_i_2426, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_i_2426, 1)));
    return v_ret_24bool;
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ewordLiteral(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_243, v_e_240));
    if (heff_intEq_c(v_t_244, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_247 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_246, v_e_240));
      HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_247, v_p_241));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_s_2412 = v_field_2410;
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2411), v_e_240));
        V v_x_2414 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2411, v_t_2413});
        return ((HeffT2){{v_x_2414, v_s_2412}});
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2417 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2416, v_e_240));
    if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2420 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2419, v_e_240));
      HeffT2 v_t_2421 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2420, v_p_241));
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_x_2424 = v_field_2422;
        V v_s_2425 = v_field_2423;
        V v_t_2426 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2424), v_e_240));
        V v_x_2427 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2424, v_t_2426});
        return ((HeffT2){{v_x_2427, v_s_2425}});
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2428 = heff_field(v_e_240, 0);
    V v_b_2429 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2430, v_b_2429));
    if (heff_intEq_c(v_t_2431, MK_INT(0LL))) {
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_xs_2428, v_b_2429}), v_p_241}});
    } else {
      V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2434 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2433, v_b_2429));
      HeffT2 v_t_2435 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2434, v_p_241));
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_field_2437 = v_t_2435.f[1];
        V v_x_2438 = v_field_2436;
        V v_s_2439 = v_field_2437;
        V v_t_2440 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_2428, heff_dup(v_x_2438)));
        V v_t_2441 = (g_heff_2ecompile_2esimplify_2estripLams(v_x_2438, v_b_2429));
        V v_x_2442 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2440, v_t_2441});
        return ((HeffT2){{v_x_2442, v_s_2439}});
      }
    }
  }
  case TAG_EApp: {
    V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2446 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2445, v_e_240));
    if (heff_intEq_c(v_t_2446, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2449 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2448, v_e_240));
      HeffT2 v_t_2450 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2449, v_p_241));
      {
        V v_field_2451 = v_t_2450.f[0];
        V v_field_2452 = v_t_2450.f[1];
        V v_x_2453 = v_field_2451;
        V v_s_2454 = v_field_2452;
        V v_t_2455 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2453), v_e_240));
        V v_x_2456 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2453, v_t_2455});
        return ((HeffT2){{v_x_2456, v_s_2454}});
      }
    }
  }
  case TAG_ELet: {
    V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2461 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2460, v_e_240));
    if (heff_intEq_c(v_t_2461, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2464 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2463, v_e_240));
      HeffT2 v_t_2465 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2464, v_p_241));
      {
        V v_field_2466 = v_t_2465.f[0];
        V v_field_2467 = v_t_2465.f[1];
        V v_x_2468 = v_field_2466;
        V v_s_2469 = v_field_2467;
        V v_t_2470 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2468), v_e_240));
        V v_x_2471 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2468, v_t_2470});
        return ((HeffT2){{v_x_2471, v_s_2469}});
      }
    }
  }
  case TAG_ERecord: {
    V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2475 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2474, v_e_240));
    if (heff_intEq_c(v_t_2475, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2477 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2478 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2477, v_e_240));
      HeffT2 v_t_2479 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2478, v_p_241));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_s_2483 = v_field_2481;
        V v_t_2484 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2482), v_e_240));
        V v_x_2485 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2482, v_t_2484});
        return ((HeffT2){{v_x_2485, v_s_2483}});
      }
    }
  }
  case TAG_EProj: {
    V v_t_2490 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2491 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2490, v_e_240));
    if (heff_intEq_c(v_t_2491, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2493 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2494 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2493, v_e_240));
      HeffT2 v_t_2495 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2494, v_p_241));
      {
        V v_field_2496 = v_t_2495.f[0];
        V v_field_2497 = v_t_2495.f[1];
        V v_x_2498 = v_field_2496;
        V v_s_2499 = v_field_2497;
        V v_t_24100 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2498), v_e_240));
        V v_x_24101 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2498, v_t_24100});
        return ((HeffT2){{v_x_24101, v_s_2499}});
      }
    }
  }
  case TAG_ETag: {
    V v_t_24105 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24106 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24105, v_e_240));
    if (heff_intEq_c(v_t_24106, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24108 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24109 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24108, v_e_240));
      HeffT2 v_t_24110 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24109, v_p_241));
      {
        V v_field_24111 = v_t_24110.f[0];
        V v_field_24112 = v_t_24110.f[1];
        V v_x_24113 = v_field_24111;
        V v_s_24114 = v_field_24112;
        V v_t_24115 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24113), v_e_240));
        V v_x_24116 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24113, v_t_24115});
        return ((HeffT2){{v_x_24116, v_s_24114}});
      }
    }
  }
  case TAG_EMatch: {
    V v_t_24119 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24120 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24119, v_e_240));
    if (heff_intEq_c(v_t_24120, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24122 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24123 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24122, v_e_240));
      HeffT2 v_t_24124 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24123, v_p_241));
      {
        V v_field_24125 = v_t_24124.f[0];
        V v_field_24126 = v_t_24124.f[1];
        V v_x_24127 = v_field_24125;
        V v_s_24128 = v_field_24126;
        V v_t_24129 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24127), v_e_240));
        V v_x_24130 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24127, v_t_24129});
        return ((HeffT2){{v_x_24130, v_s_24128}});
      }
    }
  }
  case TAG_EPrim: {
    V v_t_24132 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24133 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24132, v_e_240));
    if (heff_intEq_c(v_t_24133, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24135 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24136 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24135, v_e_240));
      HeffT2 v_t_24137 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24136, v_p_241));
      {
        V v_field_24138 = v_t_24137.f[0];
        V v_field_24139 = v_t_24137.f[1];
        V v_x_24140 = v_field_24138;
        V v_s_24141 = v_field_24139;
        V v_t_24142 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24140), v_e_240));
        V v_x_24143 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24140, v_t_24142});
        return ((HeffT2){{v_x_24143, v_s_24141}});
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_24146 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24147 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24146, v_e_240));
    if (heff_intEq_c(v_t_24147, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24149 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24150 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24149, v_e_240));
      HeffT2 v_t_24151 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24150, v_p_241));
      {
        V v_field_24152 = v_t_24151.f[0];
        V v_field_24153 = v_t_24151.f[1];
        V v_x_24154 = v_field_24152;
        V v_s_24155 = v_field_24153;
        V v_t_24156 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24154), v_e_240));
        V v_x_24157 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24154, v_t_24156});
        return ((HeffT2){{v_x_24157, v_s_24155}});
      }
    }
  }
  case TAG_ECall: {
    V v_t_24160 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24161 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24160, v_e_240));
    if (heff_intEq_c(v_t_24161, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24163 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24164 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24163, v_e_240));
      HeffT2 v_t_24165 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24164, v_p_241));
      {
        V v_field_24166 = v_t_24165.f[0];
        V v_field_24167 = v_t_24165.f[1];
        V v_x_24168 = v_field_24166;
        V v_s_24169 = v_field_24167;
        V v_t_24170 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24168), v_e_240));
        V v_x_24171 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24168, v_t_24170});
        return ((HeffT2){{v_x_24171, v_s_24169}});
      }
    }
  }
  case TAG_EInt: {
    V v_t_24173 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24174 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24173, v_e_240));
    if (heff_intEq_c(v_t_24174, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24176 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24177 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24176, v_e_240));
      HeffT2 v_t_24178 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24177, v_p_241));
      {
        V v_field_24179 = v_t_24178.f[0];
        V v_field_24180 = v_t_24178.f[1];
        V v_x_24181 = v_field_24179;
        V v_s_24182 = v_field_24180;
        V v_t_24183 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24181), v_e_240));
        V v_x_24184 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24181, v_t_24183});
        return ((HeffT2){{v_x_24184, v_s_24182}});
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24186 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24187 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24186, v_e_240));
    if (heff_intEq_c(v_t_24187, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24189 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24190 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24189, v_e_240));
      HeffT2 v_t_24191 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24190, v_p_241));
      {
        V v_field_24192 = v_t_24191.f[0];
        V v_field_24193 = v_t_24191.f[1];
        V v_x_24194 = v_field_24192;
        V v_s_24195 = v_field_24193;
        V v_t_24196 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24194), v_e_240));
        V v_x_24197 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24194, v_t_24196});
        return ((HeffT2){{v_x_24197, v_s_24195}});
      }
    }
  }
  case TAG_EStr: {
    V v_t_24199 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24200 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24199, v_e_240));
    if (heff_intEq_c(v_t_24200, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24202 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24203 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24202, v_e_240));
      HeffT2 v_t_24204 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24203, v_p_241));
      {
        V v_field_24205 = v_t_24204.f[0];
        V v_field_24206 = v_t_24204.f[1];
        V v_x_24207 = v_field_24205;
        V v_s_24208 = v_field_24206;
        V v_t_24209 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24207), v_e_240));
        V v_x_24210 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24207, v_t_24209});
        return ((HeffT2){{v_x_24210, v_s_24208}});
      }
    }
  }
  case TAG_EBytes: {
    V v_t_24212 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24213 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24212, v_e_240));
    if (heff_intEq_c(v_t_24213, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24215 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24216 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24215, v_e_240));
      HeffT2 v_t_24217 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24216, v_p_241));
      {
        V v_field_24218 = v_t_24217.f[0];
        V v_field_24219 = v_t_24217.f[1];
        V v_x_24220 = v_field_24218;
        V v_s_24221 = v_field_24219;
        V v_t_24222 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24220), v_e_240));
        V v_x_24223 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24220, v_t_24222});
        return ((HeffT2){{v_x_24223, v_s_24221}});
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24226 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24227 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24226, v_e_240));
    if (heff_intEq_c(v_t_24227, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24229 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24230 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24229, v_e_240));
      HeffT2 v_t_24231 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24230, v_p_241));
      {
        V v_field_24232 = v_t_24231.f[0];
        V v_field_24233 = v_t_24231.f[1];
        V v_x_24234 = v_field_24232;
        V v_s_24235 = v_field_24233;
        V v_t_24236 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24234), v_e_240));
        V v_x_24237 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24234, v_t_24236});
        return ((HeffT2){{v_x_24237, v_s_24235}});
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24239 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24240 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24239, v_e_240));
    if (heff_intEq_c(v_t_24240, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24242 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24243 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24242, v_e_240));
      HeffT2 v_t_24244 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24243, v_p_241));
      {
        V v_field_24245 = v_t_24244.f[0];
        V v_field_24246 = v_t_24244.f[1];
        V v_x_24247 = v_field_24245;
        V v_s_24248 = v_field_24246;
        V v_t_24249 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24247), v_e_240));
        V v_x_24250 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24247, v_t_24249});
        return ((HeffT2){{v_x_24250, v_s_24248}});
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24251 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24252 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24251, v_e_240));
    if (heff_intEq_c(v_t_24252, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24254 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24255 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24254, v_e_240));
      HeffT2 v_t_24256 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24255, v_p_241));
      {
        V v_field_24257 = v_t_24256.f[0];
        V v_field_24258 = v_t_24256.f[1];
        V v_x_24259 = v_field_24257;
        V v_s_24260 = v_field_24258;
        V v_t_24261 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24259), v_e_240));
        V v_x_24262 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24259, v_t_24261});
        return ((HeffT2){{v_x_24262, v_s_24260}});
      }
    }
  }
  case TAG_EFix: {
    V v_t_24265 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24266 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24265, v_e_240));
    if (heff_intEq_c(v_t_24266, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24268 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24269 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24268, v_e_240));
      HeffT2 v_t_24270 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24269, v_p_241));
      {
        V v_field_24271 = v_t_24270.f[0];
        V v_field_24272 = v_t_24270.f[1];
        V v_x_24273 = v_field_24271;
        V v_s_24274 = v_field_24272;
        V v_t_24275 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24273), v_e_240));
        V v_x_24276 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24273, v_t_24275});
        return ((HeffT2){{v_x_24276, v_s_24274}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2etouch_24cpr(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_k_243 = heff_take_field(v_s_242, 8);
  V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_k_243, 0), heff_dup(v_h_240), v_v_241));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_h_240, heff_take_field(v_k_243, 2)});
  V v_t_246 = ({ V rv_0 = v_t_244; V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_k_243, 26ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 972u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_f_247 = ({ V rv_8 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_247}});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0), 2)) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(v_rest_242));
        {
          V v_field_247 = v_t_245.f[1];
          int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
          if ((v_tag_246 == ((int64_t)0ULL))) {
            V v_vs_249 = v_field_247;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_249})}});
          } else {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_v_243);
            heff_drop(v_field_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_kc_241, 5);
    return ((HeffT2){{NTAG(TAG_False), v_p_243}});
  }
  case TAG_Just: {
    V v_b_244 = heff_field(v_x3_242, 0);
    HeffT2 v_t_245 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_dup(v_b_244), v_p_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      V v_s_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_240), v_x_248, heff_take_field(v_kc_241, 2), v_s_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        heff_drop(v_x_2413);
        V v_s_2414 = v_field_2412;
        HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_kc_241, 3, 5); V a_1 = v_h_240; V a_2 = v_s_2414; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          V v_x_2418 = v_field_2416;
          heff_drop(v_x_2418);
          V v_s_2419 = v_field_2417;
          return ((HeffT2){{NTAG(TAG_True), v_s_2419}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emadeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeKept_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeKept(V v_km_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_km_240, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_get_n(v_km_240, 1, 2), v_p_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_s_248 = v_field_246;
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_b_243, v_s_248));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_s_2413 = v_field_2411;
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_2412}), v_s_2413});
        }
      } else {
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop(v_x_247);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_248});
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeKept(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eask_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eask_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eask_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2eask(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2411 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_h_246); V a_2 = heff_dup(v_g_241); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecopyVer(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2etouch_24cpr(heff_dup(v_h_246), v_t_2411, heff_dup(v_s_248)));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    heff_drop(v_x_2415);
    V v_s_2416 = v_field_2414;
    V v_t_2417 = heff_get_n(heff_get_n(v_s_248, 7, 9), 2, 7);
    HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_h_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_g_241);
        heff_drop(v_xs_242);
        heff_drop(v_b_243);
        heff_drop(v_marks_244);
        heff_drop_rec(v_sh_245, 3);
        heff_drop(v_h_246);
        heff_drop(v_d_247);
        V v_x_2422 = v_field_2420;
        heff_drop(v_x_2422);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2416});
      } else {
        heff_drop(v_field_2420);
        return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2eask_lam0, 1, 1, (V[]){heff_dup(v_h_246)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eask_lam1, 2, 8, (V[]){v_xs_242, v_b_243, v_g_241, v_h_246, v_marks_244, v_sh_245, v_r_240, v_d_247}), v_s_2416));
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eask(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ecompile_2esimplify_2eask_lam0(V self, V *args) {
  V v_s_2423 = args[0];
  V v_h_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = (g_heff_2ecompile_2esimplify_2ekeptAt_24cpr(heff_dup(v_s_2423), v_h_246));
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_kc_2428 = v_field_2426;
      V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2428, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
      return ({ V a_0 = v_h_246; V a_1 = v_kc_2428; V a_2 = v_t_2429; V a_3 = v_s_2423; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2429); r_; });
    } else {
      heff_drop(v_h_246);
      heff_drop(v_field_2426);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2423});
    }
  }
}
V g_heff_2ecompile_2esimplify_2eask_lam1(V self, V *args) {
  V v_hit_2430 = args[0];
  V v_z_2431 = args[1];
  V v_xs_242 = heff_env(self)[0];
  V v_b_243 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_h_246 = heff_env(self)[3];
  V v_marks_244 = heff_env(self)[4];
  V v_sh_245 = heff_env(self)[5];
  V v_r_240 = heff_env(self)[6];
  V v_d_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if ((heff_dup(v_hit_2430) == NTAG(TAG_True))) {
    heff_drop(v_hit_2430);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_g_241);
    heff_drop(v_h_246);
    heff_drop(v_marks_244);
    heff_drop_rec(v_sh_245, 3);
    heff_drop(v_r_240);
    heff_drop(v_d_247);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_z_2431});
  } else {
    heff_drop(v_hit_2430);
    HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_z_2431));
    {
      V v_field_2433 = v_t_2432.f[0];
      V v_field_2434 = v_t_2432.f[1];
      V v_x_2435 = v_field_2433;
      V v_s_2436 = v_field_2434;
      V v_m_2437 = (g_heff_2ecompile_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2435));
      V v_x2_2438 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2436}));
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_MkPair: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_s_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        HeffT2 v_t_2441 = (g_heff_2ecompile_2esimplify_2eknowing_24cpr(v_r_240, v_x_2439, v_s_2440));
        {
          V v_field_2442 = v_t_2441.f[0];
          V v_field_2443 = v_t_2441.f[1];
          V v_x_2444 = v_field_2442;
          V v_s_2445 = v_field_2443;
          HeffT2 v_t_2446 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_246), heff_dup(v_x_2444), v_d_247, v_s_2445));
          {
            V v_field_2447 = v_t_2446.f[0];
            V v_field_2448 = v_t_2446.f[1];
            V v_x_2449 = v_field_2447;
            heff_drop(v_x_2449);
            V v_s_2450 = v_field_2448;
            V v_k_2451 = heff_take_field(v_s_2450, 8);
            V v_t_2452 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_k_2451, 3), heff_dup(v_h_246), NTAG(TAG_MkUnit)));
            V v_k_2453 = ({ V rv_3 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_k_2451, 23ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            V v_t_2454 = ({ V rv_8 = v_k_2453; V rr_ = heff_rec_reuse_nf(v_s_2450, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
            return ({ V a_0 = v_h_246; V a_1 = v_x_2444; V a_2 = v_t_2454; V r_ = (g_heff_2ecompile_2esimplify_2emarkCopySafe(a_0, a_1, a_2)); heff_drop(v_x_2444); r_; });
          }
        }
      }
      default: return heff_nomatch(v_x2_2438);
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str1, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_t_2414);
    V v_t_2415 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_s_247});
  } else {
    heff_drop(v_t_2414);
    V v_k_2416 = (g_heff_2ecompile_2esimplify_2especKey(heff_dup(v_g_241), heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 1)), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_j_2417 = heff_strFind_lent(((V)&g_heff_2ecompile_2esimplify_2especShaped_str0), v_g_241, MK_INT(0LL), 5);
    V v_t_2419;
    if (heff_intLt_c_lent(v_j_2417, MK_INT(0LL), 2)) {
      heff_drop(v_j_2417);
      v_t_2419 = heff_dup(v_g_241);
    } else {
      v_t_2419 = heff_strSlice_lent(v_g_241, MK_INT(0LL), v_j_2417, 6);
    }
    V v_t_2420 = ({ V a_0 = v_k_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_k_2416); r_; });
    V v_t_2421 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str1), v_t_2420));
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_t_2423 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2424 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2423; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_sh_246, v_t_2421, v_t_2424, v_s_247));
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2411 = ({ V a_0 = v_g_241; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_x1_2412 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_x1_2412);
          HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_x_2416 = v_field_2414;
            V v_s_2417 = v_field_2415;
            return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2416, v_s_2417));
          }
        } else {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          heff_drop(v_x1_2412);
          V v_x_2418 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_z_246});
        }
      } else {
        heff_drop(v_t_2411);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
        {
          V v_field_2420 = v_t_2419.f[0];
          V v_field_2421 = v_t_2419.f[1];
          V v_x_2422 = v_field_2420;
          V v_s_2423 = v_field_2421;
          return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2422, v_s_2423));
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_x1_248, 0ULL, 2);
      HeffT2 v_t_2426 = (g_heff_2ecompile_2esimplify_2eshapesOf_24cpr(heff_dup(v_marks_245), heff_dup(v_argv_244), v_z_246));
      {
        V v_field_2427 = v_t_2426.f[0];
        V v_field_2428 = v_t_2426.f[1];
        V v_x_2429 = v_field_2427;
        V v_s_2430 = v_field_2428;
        return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_argv_244, v_marks_245, v_x_2429, v_s_2430));
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop(v_x1_247);
    V v_x_2431 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_argv_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2431, v_z_246});
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
  }
  case TAG_Cons: {
    V v_m_243 = heff_dup(heff_field(v_x1_240, 0));
    V v_ms_244 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x1_240);
    }
    case TAG_Cons: {
      V v_n_245 = heff_field(v_x2_241, 0);
      V v_ns_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_247;
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop(v_n_245);
        v_t_247 = NTAG(TAG_True);
      } else {
        heff_drop(v_m_243);
        v_t_247 = v_n_245;
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_ms_244;
      V t_1 = v_ns_246;
      V t_2 = v_cell_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eetaOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaOne(V v_r_240, V v_e_241, V v_k_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ELam: {
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EApp: {
    V v_h_248 = heff_field(v_e_241, 0);
    V v_bs_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_x2_2410 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_bs_249, heff_dup(v_p_243)));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_k_242, v_s_2412));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        V v_s_2417 = v_field_2415;
        V v_t_2420;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_MkPair: {
          V v_y_2419 = heff_dup(heff_field(v_x_2411, 1));
          v_t_2420 = v_y_2419;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2421 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2416)));
        V v_t_2422 = (g_heff_2ecompile_2esimplify_2eappendL(v_t_2420, v_t_2421));
        V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_h_248, v_t_2422}));
        V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2417}));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaKept(v_p_243, v_x_2411, heff_tag_at_n(v_ru_24e_241_24EApp, TAG_ELam, 2, (V[]){v_x_2416, v_x_2425}), v_s_2426);
        }
        default: return heff_nomatch(v_x2_2424);
        }
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ERecord: {
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EMatch: {
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ECall: {
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFixed: {
    V v_ru_24e_241_24EFixed = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFix: {
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaOne(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELam: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_a_248 = heff_field(v_x1_240, 1);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_e_249));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_bds_2413 = v_field_2411;
      V v_e_2414 = v_field_2412;
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bds_2413});
      return ((HeffT2){{v_t_2415, v_e_2414}});
    }
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArg_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArg_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eetaArg(V v_r_240, V v_st_241, V v_a_242, V v_rest_243, V v_s_244) {
top: ;
  V v_k_245 = (g_heff_2ecompile_2esimplify_2emissingOf(heff_dup(v_s_244), v_a_242));
  return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArg_lam0, 1, 4, (V[]){heff_dup(v_st_241), v_k_245, v_r_240, heff_dup(v_a_242)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArg_lam1, 2, 2, (V[]){v_rest_243, v_a_242}), v_s_244));
}
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaArg(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_st_241) == NTAG(TAG_True))) {
    heff_drop(v_st_241);
    if (heff_intLt_c_lent(MK_INT(0LL), v_k_245, 1)) {
      return (g_heff_2ecompile_2esimplify_2eetaOne(v_r_240, v_a_242, v_k_245, v_p_246));
    } else {
      heff_drop(v_k_245);
      heff_drop(v_r_240);
      heff_drop(v_a_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_246});
    }
  } else {
    heff_drop(v_st_241);
    heff_drop(v_k_245);
    heff_drop(v_r_240);
    heff_drop(v_a_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_246});
  }
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_z_249 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418;
  switch (heff_tag_of(v_e_248)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_rest_243)) {
    case TAG_MkPair: {
      V v_rest_2410 = heff_field(v_rest_243, 0);
      V v_argv_2411 = heff_field(v_rest_243, 1);
      V v_ru_24rest_243_24MkPair = heff_take_reuse_n(v_rest_243, 3ULL, 2);
      v_x_2418 = heff_tag_at_n(v_ru_24rest_243_24MkPair, TAG_MkPair, 2, (V[]){v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_argv_2411})});
      break;
    }
    default: heff_nomatch(v_rest_243);
    }
    break;
  }
  case TAG_Just: {
    V v_x21_2412 = heff_field(v_e_248, 0);
    heff_take_n(v_e_248, 1ULL, 1);
    heff_drop(v_a_242);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkPair: {
      V v_bds_2413 = heff_field(v_x21_2412, 0);
      V v_lam1_2414 = heff_field(v_x21_2412, 1);
      V v_ru_24x21_2412_24MkPair = heff_take_reuse_n(v_x21_2412, 3ULL, 2);
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_rest_2415 = heff_field(v_rest_243, 0);
        V v_argv_2416 = heff_field(v_rest_243, 1);
        heff_take_n(v_rest_243, 3ULL, 2);
        V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(v_bds_2413, v_rest_2415));
        v_x_2418 = heff_tag_at_n(v_ru_24x21_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_lam1_2414, v_argv_2416})});
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_e_248);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_z_249});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArgs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaArgs(V v_r_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam0, 1, 1, (V[]){v_x3_242});
  }
  case TAG_Cons: {
    V v_st_245 = heff_field(v_x2_241, 0);
    V v_sts_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_r_240);
      heff_drop(v_st_245);
      heff_drop(v_sts_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam1, 1, 1, (V[]){v_x3_242});
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_x3_242, 0);
      V v_argv_2410 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_m_2411 = (g_heff_2ecompile_2esimplify_2eetaArgs(heff_dup(v_r_240), v_sts_246, v_argv_2410));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArgs_lam2, 1, 4, (V[]){v_m_2411, v_a_249, v_r_240, v_st_245});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_s_243});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_x3_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_x3_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_s_247});
}
V g_heff_2ecompile_2esimplify_2eetaArgs_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_st_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2eletsOut(v_a_249));
    return ({ V a_0 = v_r_240; V a_1 = v_st_245; V a_2 = v_t_2416; V a_3 = v_x_2414; V a_4 = v_s_2415; V r_ = (g_heff_2ecompile_2esimplify_2eetaLets(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_245); r_; });
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
Clo g_heff_2ecompile_2esimplify_2eetaMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaMade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaMade(V v_a_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_a_240));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      heff_drop(v_x_249);
      V v_y_2410 = v_field_248;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_EVar: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EGlobal: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_ELam: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_ELet: {
        heff_take_n(v_y_2410, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_ERecord: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EProj: {
        heff_take_n(v_y_2410, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_ETag: {
        heff_take_n(v_y_2410, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_EMatch: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EPrim: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_ECall: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EInt: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EFloat: {
        heff_take_na(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EStr: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EBytes: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EFixed: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EFloat32: {
        heff_take_na(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_EFix: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_y_2410);
      }
    }
  }
  case TAG_EApp: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaMade(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2esimplify_2earmsPushable(MK_INT(40LL), heff_tag_n(TAG_EMatch, 2, (V[]){heff_dup(v_s2_241), heff_dup(v_arms2_242)}), v_arms_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0, 1, 4, (V[]){v_r_240, v_arms_243, v_arms2_242, v_s2_241});
  } else {
    heff_drop(v_r_240);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_arms_243 = heff_env(self)[1];
  V v_arms2_242 = heff_env(self)[2];
  V v_s2_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_246 = (g_prelude_2etraverse_24s504671899x323346652_24cpr(v_r_240, v_arms_243, v_arms2_242, v_s_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_s_2410 = v_field_248;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_x_249}), v_s_2410});
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_s_2411});
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam1, 2, 0};
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam2, 4, 0};
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2ecompile_2esimplify_2esk_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2esk_st;
static V g_heff_2ecompile_2esimplify_2esk_init(void) {
  return heff_rec_n(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2ecompile_2esimplify_2esk_lam0_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam1_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam2_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam3_clo)});
}
V g_heff_2ecompile_2esimplify_2esk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2esk_st)) return g_heff_2ecompile_2esimplify_2esk_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2esk_val, &g_heff_2ecompile_2esimplify_2esk_st, g_heff_2ecompile_2esimplify_2esk_init);
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_argv_242 = args[1];
  return (g_heff_2ecompile_2esimplify_2eapplyToF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_f_241, v_argv_242));
}
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_sh_244 = args[1];
  V v_t_245 = args[2];
  V v_e_246 = args[3];
  return (g_heff_2ecompile_2esimplify_2eprojectF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_l_243, v_sh_244, v_t_245, v_e_246));
}
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_247 = args[0];
  V v_arms_248 = args[1];
  return (g_heff_2ecompile_2esimplify_2ematchF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_s_247, v_arms_248));
}
Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleCopy_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esettleCopy(V v_more_240, V v_n_241, V v_h_242, V v_b_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
  V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
  V v_m_247 = heff_tr(heff_call(heff_dup(v_more_240), 1, (V[]){v_t_246}));
  V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){heff_dup(v_s_244)}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_intLt_c_lent(MK_INT(0LL), v_n_241, 1)) {
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_244, heff_dup(v_s_2410), heff_dup(v_b_243)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(heff_dup(v_h_242), v_b_243, v_s_2410));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_s_2417 = v_field_2415;
          V v_m_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, heff_intSub(v_n_241, MK_INT(1LL)), v_h_242, v_x_2416}));
          V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2417}));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_s_2421 = heff_field(v_x2_2419, 1);
            V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
            V v_t_2424;
            switch (heff_tag_of(v_x_2420)) {
            case TAG_MkPair: {
              V v_x_2422 = heff_dup(heff_field(v_x_2420, 0));
              v_t_2424 = v_x_2422;
              break;
            }
            default: heff_nomatch(v_x_2420);
            }
            V v_t_2427;
            switch (heff_tag_of(v_x_2420)) {
            case TAG_MkPair: {
              V v_y_2426 = heff_field(v_x_2420, 1);
              heff_take_n(v_x_2420, 2ULL, 2);
              v_t_2427 = v_y_2426;
              break;
            }
            default: heff_nomatch(v_x_2420);
            }
            V v_t_2428 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_249, v_t_2427));
            V v_x_2429 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_t_2428});
            return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_s_2421});
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
      } else {
        heff_drop(v_more_240);
        heff_drop(v_n_241);
        heff_drop(v_h_242);
        heff_drop(v_t_2412);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
      }
    } else {
      heff_drop(v_more_240);
      heff_drop(v_n_241);
      heff_drop(v_h_242);
      heff_drop(v_s_244);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleCopy(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eoneItem_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_d_242, v_p_241);
  }
  case TAG_Kept: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_redo_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Kept = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_243, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
    HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ereplayed_24cpr(v_k_243, v_t_245, heff_dup(v_p_241)));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      V v_s_2410 = v_field_248;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Kept, 2);
        heff_drop(v_s_2410);
        V v_t_2411 = heff_tr(heff_call(v_redo_244, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))}));
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eafresh_24cpr(v_t_2411, v_p_241);
      }
      case TAG_Just: {
        V v_ds_2412 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        heff_drop_rec(v_p_241, 9);
        heff_drop(v_redo_244);
        V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Kept, TAG_MkPair, 2, (V[]){v_ds_2412, NTAG(TAG_Nil)});
        return ((HeffT2){{v_t_2413, v_s_2410}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x_249)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str1, 0, "");
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeOf(V v_st_240, V v_bodies_241, V v_h_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_t_248 = v_field_246;
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_248));
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2emap_2eempty_get()), v_t_249));
      V v_tv_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2emadeOf_lam0, 1, 1, (V[]){v_st_240}), v_t_2410));
      HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_bodies_241, v_h_242));
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_b_2424 = v_field_2422;
          V v_t_2425 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str1); V a_1 = v_tv_2419; V r_ = (g_list_2eall_24s1194065168x228565983(b_0, a_1)); heff_drop(b_0); r_; });
          if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
            heff_drop(v_t_2425);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2424, v_tv_2419})});
          } else {
            heff_drop(v_tv_2419);
            heff_drop(v_b_2424);
            heff_drop(v_t_2425);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_tv_2419);
          heff_drop(v_field_2422);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_st_240, 9);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2emadeOf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_get_n(heff_get_n(v_st_240, 8, 9), 0, 5);
  HeffT2 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_t_2418;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2415;
      v_t_2418 = v_x_2417;
    } else {
      heff_drop(v_field_2415);
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2411, v_t_2418});
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS_24dps(a[0], a[1]);
}