// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Large 60129
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SError 24172
#define TAG_SPrimArray 2913
#define TAG_SRec 7538
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_depth 296830685
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_lams 9809570
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_wantedBy 1134124532
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ereadback_2eforcedRb(V);
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eforcedRb_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2edescribes(V);
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribes_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2eescapeAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eescapeAt_clo;
HeffT2 g_heff_2eelab_2erules_2eescapeLevel_24cpr(V);
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2eheldIn(V, V);
V g_heff_2eelab_2erules_2eheldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldIn_clo;
V g_heff_2eelab_2erules_2eheldLocal(V, V, V);
V g_heff_2eelab_2erules_2eheldLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldLocal_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2elamSynthesised(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elamSynthesised_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elamSynthesised_clo;
V g_heff_2eelab_2erules_2emismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emismatch_clo;
V g_heff_2eelab_2erules_2eplainMismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplainMismatch_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_heff_2eelab_2erules_2etyStrIn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrIn_entry, 3, 0};

V g_heff_2eelab_2erules_2etyStrIn(V v_e_240, V v_mc_241, V v_t_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_241));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_t_243, 1, 2), 2, (V[]){v_t_244, v_t_242}));
  V v_t_2415 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrIn_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2416 = heff_tr(heff_call(heff_get_n(v_t_2415, 1, 2), 1, (V[]){v_t_245}));
  V v_t_2417 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2417; V a_3 = v_t_2416; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
}
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2etyStrIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2etyStrIn_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_248); r_; });
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_246; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_246); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_d_247);
      V v_x_2414 = v_field_2412;
      return v_x_2414;
    } else {
      heff_drop(v_field_2412);
      return v_d_247;
    }
  }
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstShown_entry, 3, 0};

V g_heff_2eelab_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_244 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_243, v_goal_242));
  V v_t_245 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_t_245, 1, 2), 1, (V[]){v_t_244}));
  V v_t_2416 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2einstShown_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2417 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 2), 1, (V[]){v_t_246}));
  V v_t_2418 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2418; V a_3 = v_t_2417; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
}
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2einstShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_249); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_247; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_247); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_d_248);
      V v_x_2415 = v_field_2413;
      return v_x_2415;
    } else {
      heff_drop(v_field_2413);
      return v_d_248;
    }
  }
}

static V g_heff_2eelab_2erules_2etopSearch_val;
static HEFF_ONCE g_heff_2eelab_2erules_2etopSearch_st;
static V g_heff_2eelab_2erules_2etopSearch_init(void) {
  return heff_rec_n(2, shape_depth__wantedBy, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2erules_2etopSearch_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2etopSearch_st)) return g_heff_2eelab_2erules_2etopSearch_val;
  return heff_global(&g_heff_2eelab_2erules_2etopSearch_val, &g_heff_2eelab_2erules_2etopSearch_st, g_heff_2eelab_2erules_2etopSearch_init);
}
V g_heff_2eelab_2erules_2elamSynthesised_lam0(V self, V *args);
V g_heff_2eelab_2erules_2elamSynthesised_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2elamSynthesised_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elamSynthesised_entry, 6, 0};

V g_heff_2eelab_2erules_2elamSynthesised(V v_e_240, V v_x_241, V v_edom_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_ebody_246 = heff_field(v_x4_243, 0);
    V v_bty_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2429;
    switch (heff_tag_of(v_bty_247)) {
    case TAG_VU: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_249 = heff_dup(heff_field(v_bty_247, 0));
      switch (heff_tag_of(v_h_249)) {
      case TAG_HLocal: {
        heff_take_n(v_h_249, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_249, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_249, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2429 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_249);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_bty_247);
    }
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_x_241);
      heff_drop(v_edom_242);
      heff_drop(v_ebody_246);
      heff_drop(v_bty_247);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      heff_drop(v_t_2429);
      return heff_tail(heff_dup(g_heff_2eelab_2erules_2eerrorOf_get()), 2, (V[]){v_z_244, v_z_245});
    } else {
      heff_drop(v_z_244);
      heff_drop(v_t_2429);
      V v_t_2430 = heff_take_field(v_e_240, 2);
      V v_t_2433;
      switch (heff_tag_of(v_t_2430)) {
      case TAG_ForNominative: {
        v_t_2433 = NTAG(TAG_N);
        break;
      }
      case TAG_ForDescriptive: {
        heff_take_n(v_t_2430, 0ULL, 2);
        v_t_2433 = NTAG(TAG_De);
        break;
      }
      default: heff_nomatch(v_t_2430);
      }
      V v_t_2434 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
      V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
      V v_t_2436 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2435, MK_INT(1LL)), heff_dup(v_bty_247)));
      V v_cod_2438 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_241), heff_rec_n(2, shape_stx__val, (V[]){v_t_2436, heff_clo_n(g_heff_2eelab_2erules_2elamSynthesised_lam0, 1, 1, (V[]){heff_dup(v_bty_247)})})});
      V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
      V v_t_2440 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_240, 1)), v_t_2439, heff_dup(v_edom_242), v_cod_2438));
      V v_t_2441 = (g_heff_2eelab_2ememoed_2elam(v_t_2433, heff_dup(heff_rfield(v_e_240, 1)), v_t_2434, v_t_2440, heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_241), v_ebody_246})));
      V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
      V v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2442, MK_INT(1LL)), heff_dup(v_bty_247)));
      V v_cod_2445 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, heff_rec_n(2, shape_stx__val, (V[]){v_t_2443, heff_clo_n(g_heff_2eelab_2erules_2elamSynthesised_lam1, 1, 1, (V[]){v_bty_247})})});
      V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
      HeffT2 v_t_2447 = (g_heff_2eelab_2ememoed_2efunctionD_24cpr(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_240, 1, 6), v_t_2446, v_edom_242, v_cod_2445));
      V v_t_2454;
      {
        V v_field_2449 = v_t_2447.f[1];
        heff_drop(v_t_2447.f[0]);
        V v_x1_2450 = heff_tr(heff_call(v_field_2449, 1, (V[]){NTAG(TAG_MkUnit)}));
        switch (heff_tag_of(v_x1_2450)) {
        case TAG_Nom: {
          V v_x_2451 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_t_2454 = v_x_2451;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2450, 0ULL, 1);
          v_t_2454 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2453 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_t_2454 = v_x_2453;
          break;
        }
        default: heff_nomatch(v_x1_2450);
        }
      }
      V v_x_2455 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2441, v_t_2454});
      return heff_tail(v_z_245, 1, (V[]){v_x_2455});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2elamSynthesised_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elamSynthesised(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2elamSynthesised_lam0(V self, V *args) {
  V v_u_2437 = args[0];
  V v_bty_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_247});
}
V g_heff_2eelab_2erules_2elamSynthesised_lam1(V self, V *args) {
  V v_u_2444 = args[0];
  V v_bty_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_247});
}
Clo g_heff_2eelab_2erules_2eheldLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eheldLocal_entry, 3, 0};

V g_heff_2eelab_2erules_2eheldLocal(V v_l_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CEmpty: {
    heff_drop(v_l_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_CBind: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_l_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_241, 0);
      V v_xs_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_248 = (g_heff_2eelab_2erules_2eheldIn(heff_dup(v_l_240), v_t_245));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_l_240);
        heff_drop(v_xs_247);
        heff_drop(v_t_248);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_246, heff_dup(v_t_245)})});
      } else {
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_248);
        V t_0 = v_l_240;
        V t_1 = v_xs_247;
        V t_2 = v_c_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_CUndelay: {
    V v_c_249 = heff_field(v_x3_242, 0);
    V t_0 = v_l_240;
    V t_1 = v_x2_241;
    V t_2 = v_c_249;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eheldLocal_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eheldLocal(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2erules_2emismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emismatch_entry, 7, 0};

V g_heff_2eelab_2erules_2emismatch(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_err_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2erules_2eescapeLevel_24cpr(v_err_244));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_l_2411 = v_field_249;
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 1, 4);
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 3, 4);
      V v_t_2414 = ({ V a_0 = heff_dup(v_l_2411); V a_1 = v_t_2412; V a_2 = v_t_2413; V r_ = (g_heff_2eelab_2erules_2eheldLocal(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
      V v_t_2415 = ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_244; V a_5 = v_l_2411; V a_6 = v_t_2414; V r_ = heff_tr(g_heff_2eelab_2erules_2eescapeAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2414); r_; });
      return heff_tail(v_t_2415, 2, (V[]){v_z_245, v_z_246});
    } else {
      heff_drop(v_field_249);
      V v_t_2416 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      HEFF_LAST return g_heff_2eelab_2erules_2eplainMismatch(v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2416, v_z_245, v_z_246);
    }
  }
}
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2emismatch(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
Clo g_heff_2eelab_2erules_2eapply_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapply_entry, 2, 0};

V g_heff_2eelab_2erules_2eapply(V v_sp_240, V v_syn_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2eapply_24cpr(v_sp_240, v_syn_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eapply(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str0, 97, "the definition would need itself while it is being computed: put the recursive use under a lambda");
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str1, 46, "can only use rec when checking at a small type");
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str2, 46, "can only use rec when checking at a small type");
V g_heff_2eelab_2erules_2erecChk_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2erecChk_24cpr_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_24cpr_lam4, 1, 0};
V g_heff_2eelab_2erules_2erecChk_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V v_sp_240, V v_c_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam0, 2, 2, (V[]){v_sp_240, v_c_241})}});
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(331LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2410}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  args[0] = v_t_2411;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam4(V self, V *args) {
  V v_u_2422 = args[0];
  heff_drop(v_u_2422);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_SRec, 1, (V[]){heff_get_n(v_x_2420, 0, 2)});
  V f_ = v_k_2419;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2421, ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam3, 1, 1, (V[]){v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2423, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2423, 1, 3);
  args[0] = v_t_2428;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam6(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2433}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2434;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2eelab_2evalue_2elevelOf(v_a_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Small: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_e_242, 3)), MK_INT(0LL))) {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_a_243);
      heff_drop(v_c_241);
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam1, 2, 1, (V[]){v_sp_240});
    } else {
      heff_drop(v_sp_240);
      V v_sd_2412 = heff_take_field(v_e_242, 0);
      V v_c_2417;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkChk: {
        V v_f_2413 = heff_field(v_c_241, 0);
        V v_ru_24c_241_24MkChk = heff_take_reuse_n(v_c_241, 1ULL, 1);
        V v_t_2414 = heff_tag_at_n(v_ru_24c_241_24MkChk, TAG_CUndelay, 1, (V[]){heff_dup(heff_rfield(v_sd_2412, 3))});
        V v_t_2415 = ({ V rv_3 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_sd_2412, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2416 = ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        v_c_2417 = heff_tr(heff_call(v_f_2413, 2, (V[]){v_t_2416, v_a_243}));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam2, 2, 1, (V[]){v_c_2417});
    }
  }
  case TAG_Large: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam5, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam6, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eprimArray_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimArray_entry, 1, 0};

V g_heff_2eelab_2erules_2eprimArray(V v_a_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam0, 1, 1, (V[]){heff_dup(v_a_240)})});
}
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eprimArray(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args) {
  V v_u_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_x1_249 = heff_tr(heff_call(heff_get_n(v_x_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2413})});
}
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_SPrimArray, 1, (V[]){heff_dup(heff_rfield(v_x_246, 0))});
  V f_ = v_k_245;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam3, 1, 1, (V[]){v_x_246})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam2, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_a_240, 0);
    heff_take_n(v_a_240, 1ULL, 1);
    v_c_243 = heff_tr(heff_call(v_f_242, 1, (V[]){v_e_241}));
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam1, 2, 1, (V[]){v_c_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str0, 13, "` to its name");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str1, 107, "` is a type written in place, and a default this record is given names it: define the type apart, and set `");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str2, 1, "`");
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam0, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam1, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2edescribedBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_entry, 2, 0};

V g_heff_2eelab_2erules_2edescribedBound(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam1_clo);
    }
    case TAG_Cons: {
      V v_b_248 = heff_field(v_x2_241, 0);
      V v_bs_249 = heff_field(v_x2_241, 1);
      if ((heff_dup(v_b_248) == NTAG(TAG_True))) {
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_m_244, 2)), 0, 2);
        V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2edescribes(a_0)); heff_drop(v_t_2410); r_; });
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          return heff_clo_n(g_heff_2eelab_2erules_2edescribedBound_lam2, 2, 1, (V[]){heff_dup(v_m_244)});
        } else {
          heff_drop(v_t_2411);
          V t_0 = v_rest_245;
          V t_1 = v_bs_249;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_rest_245;
        V t_1 = v_bs_249;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2edescribedBound(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_strAppend(heff_dup(heff_rfield(v_m_244, 0)), ((V)&g_heff_2eelab_2erules_2edescribedBound_str0));
  V v_t_2415 = heff_strAppend(heff_take_field(v_m_244, 0), heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str1), v_t_2414));
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(344LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str2), v_t_2415), heff_get_n(v_m_244, 4, 5), NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2erecordIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2erecordIntro_24cpr(v_sp_240, v_fieldSettings_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordIntro(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordTypeIntro_str0, 11, "its field `");
HEFF_LIT(g_heff_2eelab_2erules_2erecordTypeIntro_str1, 113, "` is no run-time data: a record with such a field is a theory -- declare it with `theory X where`, a field a line");
V g_heff_2eelab_2erules_2erecordTypeIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTypeIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordTypeIntro(V v_sp_240, V v_fieldTyps_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam0, 4, 2, (V[]){v_fieldTyps_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordTypeIntro(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_dup(heff_rfield(v_x_2416, 3));
  V v_t_2420;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_field_2418 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordTypeIntro_str0), heff_strAppend(v_field_2418, ((V)&g_heff_2eelab_2erules_2erecordTypeIntro_str1)));
    v_t_2420 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Just, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_t_2421 = (g_heff_2eelab_2erules_2erecordOf(heff_dup(v_e_242), v_x_2416));
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_240, v_t_2420, v_e_242, v_x_2410, v_t_2421, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_fieldTyps_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sd_2411 = heff_dup(heff_rfield(v_e_242, 0));
  V v_t_2412 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_2411, 3)});
  V v_t_2413 = ({ V rv_3 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_sd_2411, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2414 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_t_2413, heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5))});
  V v_c_2415 = (g_heff_2eelab_2erules_2eformGo(v_t_2414, MK_INT(0LL), v_fieldTyps_241));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam3, 1, 5, (V[]){v_e_242, v_sp_240, v_x_2410, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_fieldTyps_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam2, 1, 5, (V[]){v_e_242, v_fieldTyps_241, v_hd_244, v_sp_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}