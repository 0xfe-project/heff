// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Large 60129
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_depth 296830685
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_tags 10047712
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_wantedBy 1134124532
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(V, V);
V g_heff_2eelab_2eenvironment_2eruledOutAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2eruledOutAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eruledOutAt_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
HeffT2 g_heff_2eelab_2ememoed_2efunctionD_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2ereadback_2eshownForcedRb(V);
V g_heff_2eelab_2ereadback_2eshownForcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownForcedRb_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2edelayAt_24cpr(V, V, V);
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2eelimWaits(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimWaits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimWaits_clo;
V g_heff_2eelab_2erules_2eerrorOf(V, V);
V g_heff_2eelab_2erules_2eerrorOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_clo;
V g_heff_2eelab_2erules_2eerrorOf_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eerrorOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eerrorOf_24tok2_clo;
V g_heff_2eelab_2erules_2eescapeAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eescapeAt_clo;
HeffT2 g_heff_2eelab_2erules_2eescapeLevel_24cpr(V);
HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V, V);
V g_heff_2eelab_2erules_2eheldLocal(V, V, V);
V g_heff_2eelab_2erules_2eheldLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eheldLocal_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2elamSynthesised(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elamSynthesised_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elamSynthesised_clo;
V g_heff_2eelab_2erules_2emisfit_24tok1(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_24tok1_clo;
V g_heff_2eelab_2erules_2emismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emismatch_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enumbered(V, V);
V g_heff_2eelab_2erules_2enumbered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumbered_clo;
V g_heff_2eelab_2erules_2enumbered_24dps(V, V, V);
V g_heff_2eelab_2erules_2enumbered_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumbered_24dps_clo;
V g_heff_2eelab_2erules_2eplainMismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplainMismatch_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
V g_heff_2eelab_2erules_2eseeArm(V, V, V, V, V);
V g_heff_2eelab_2erules_2eseeArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eseeArm_clo;
V g_heff_2eelab_2erules_2espineHasLocal(V, V);
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2espineHasLocal_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate2(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate2_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate3(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate3_clo;
V g_heff_2eelab_2erules_2esumFormation_24map2(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map2_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2135465121x1956745568(V);
V g_list_2eany_24s2135465121x1956745568_entry(V self, V *a);
extern Clo g_list_2eany_24s2135465121x1956745568_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_heff_2eelab_2erules_2etyStrIn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrIn_entry, 3, 0};

V g_heff_2eelab_2erules_2etyStrIn(V v_e_240, V v_mc_241, V v_t_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_get_n(v_e_240, 1, 6);
  V v_t_245 = (g_heff_2eelab_2ereadback_2eshownForcedRb(v_mc_241));
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_t_245, 1, 2), 2, (V[]){heff_take_field(v_scope_243, 0), v_t_242}));
  V v_t_2414 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrIn_lam0, 1, 1, (V[]){v_globals_244})));
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 1, 2), 1, (V[]){v_t_246}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_scope_243, 1, 5); V a_3 = v_t_2415; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
}
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2etyStrIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2etyStrIn_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_globals_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = ({ V b_0 = heff_get_n(v_globals_244, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_247; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_249); heff_drop(v_x_247); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_d_248);
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      heff_drop(v_field_2412);
      return v_d_248;
    }
  }
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstShown_entry, 3, 0};

V g_heff_2eelab_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_scope_243 = heff_take_field(v_e_240, 0);
  V v_globals_244 = heff_get_n(v_e_240, 1, 6);
  V v_t_2424;
  switch (heff_tag_of(v_goal_242)) {
  case TAG_VU: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2416 = heff_dup(heff_field(v_goal_242, 5));
    v_t_2424 = v_folded_2416;
    break;
  }
  case TAG_VRecord: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_goal_242);
  }
  V v_t_2425 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_take_field(v_scope_243, 0), v_goal_242, v_t_2424));
  V v_t_2426 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_t_2427 = heff_tr(heff_call(heff_get_n(v_t_2426, 1, 2), 1, (V[]){v_t_2425}));
  V v_t_2435 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2einstShown_lam0, 1, 1, (V[]){v_globals_244})));
  V v_t_2436 = heff_tr(heff_call(heff_get_n(v_t_2435, 1, 2), 1, (V[]){v_t_2427}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_scope_243, 1, 5); V a_3 = v_t_2436; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); r_; });
}
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2einstShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args) {
  V v_x_2428 = args[0];
  V v_globals_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2429 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2428)));
  V v_t_2430 = ({ V b_0 = heff_get_n(v_globals_244, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_x_2428; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2430); heff_drop(v_x_2428); r_; });
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    if ((v_tag_2432 == ((int64_t)0ULL))) {
      heff_drop(v_d_2429);
      V v_x_2434 = v_field_2433;
      return v_x_2434;
    } else {
      heff_drop(v_field_2433);
      return v_d_2429;
    }
  }
}

static V g_heff_2eelab_2erules_2etopSearch_val;
static HEFF_ONCE g_heff_2eelab_2erules_2etopSearch_st;
static V g_heff_2eelab_2erules_2etopSearch_init(void) {
  return heff_rec_n(2, shape_depth__wantedBy, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2erules_2etopSearch_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2etopSearch_st)) return g_heff_2eelab_2erules_2etopSearch_val;
  return heff_global(&g_heff_2eelab_2erules_2etopSearch_val, &g_heff_2eelab_2erules_2etopSearch_st, g_heff_2eelab_2erules_2etopSearch_init);
}
V g_heff_2eelab_2erules_2elamSynthesised_lam0(V self, V *args);
V g_heff_2eelab_2erules_2elamSynthesised_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2elamSynthesised_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elamSynthesised_entry, 6, 0};

V g_heff_2eelab_2erules_2elamSynthesised(V v_e_240, V v_x_241, V v_edom_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  V v_elabFor_246 = heff_take_field(v_e_240, 2);
  V v_globals_247 = heff_take_field(v_e_240, 1);
  V v_scope_248 = heff_get_n(v_e_240, 0, 6);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_ebody_249 = heff_field(v_x4_243, 0);
    V v_bty_2410 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_2433;
    switch (heff_tag_of(v_bty_2410)) {
    case TAG_VU: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2412 = heff_dup(heff_field(v_bty_2410, 0));
      switch (heff_tag_of(v_h_2412)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2412, 0ULL, 1);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2412, 0ULL, 1);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2412, 0ULL, 1);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2433 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2412);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_bty_2410);
    }
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop(v_x_241);
      heff_drop(v_edom_242);
      heff_drop(v_elabFor_246);
      heff_drop(v_globals_247);
      heff_drop_rec(v_scope_248, 5);
      heff_drop(v_ebody_249);
      heff_drop(v_bty_2410);
      heff_drop(v_t_2433);
      return (g_heff_2eelab_2erules_2eerrorOf_24tok2(v_ru_24x4_243_24MkPair, v_z_244, v_z_245));
    } else {
      heff_drop(v_t_2433);
      V v_t_2436;
      switch (heff_tag_of(v_elabFor_246)) {
      case TAG_ForNominative: {
        v_t_2436 = NTAG(TAG_N);
        break;
      }
      case TAG_ForDescriptive: {
        heff_take_n(v_elabFor_246, 0ULL, 2);
        v_t_2436 = NTAG(TAG_De);
        break;
      }
      default: heff_nomatch(v_elabFor_246);
      }
      V v_t_2437 = heff_intAdd(heff_dup(heff_rfield(v_scope_248, 0)), MK_INT(1LL));
      V v_t_2438 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2437, heff_dup(v_bty_2410)));
      V v_cod_2440 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_241), heff_rec_n(2, shape_stx__val, (V[]){v_t_2438, heff_clo_n(g_heff_2eelab_2erules_2elamSynthesised_lam0, 1, 1, (V[]){heff_dup(v_bty_2410)})})});
      V v_t_2441 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(v_globals_247), heff_dup(heff_rfield(v_scope_248, 2)), heff_dup(v_edom_242), v_cod_2440));
      V v_t_2442 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(heff_dup(v_x_241), v_ebody_249, v_t_2436, heff_dup(v_globals_247), heff_dup(heff_rfield(v_scope_248, 2)), v_t_2441));
      V v_t_2443 = heff_intAdd(heff_take_field(v_scope_248, 0), MK_INT(1LL));
      V v_t_2444 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2443, heff_dup(v_bty_2410)));
      V v_cod_2446 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, heff_rec_n(2, shape_stx__val, (V[]){v_t_2444, heff_clo_n(g_heff_2eelab_2erules_2elamSynthesised_lam1, 1, 1, (V[]){v_bty_2410})})});
      HeffT2 v_t_2447 = (g_heff_2eelab_2ememoed_2efunctionD_24cpr(NTAG(TAG_Expl), NTAG(TAG_Nothing), v_globals_247, heff_get_n(v_scope_248, 2, 5), v_edom_242, v_cod_2446));
      V v_t_2454;
      {
        V v_field_2449 = v_t_2447.f[1];
        heff_drop(v_t_2447.f[0]);
        V v_x1_2450 = heff_tr(heff_call(v_field_2449, 1, (V[]){NTAG(TAG_MkUnit)}));
        switch (heff_tag_of(v_x1_2450)) {
        case TAG_Nom: {
          V v_x_2451 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_t_2454 = v_x_2451;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2450, 0ULL, 1);
          v_t_2454 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2453 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_t_2454 = v_x_2453;
          break;
        }
        default: heff_nomatch(v_x1_2450);
        }
      }
      V v_x_2455 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2442, v_t_2454});
      return heff_tail(v_z_245, 1, (V[]){v_x_2455});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2elamSynthesised_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elamSynthesised(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elamSynthesised_lam0(V self, V *args) {
  V v_u_2439 = args[0];
  V v_bty_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2439);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2410});
}
V g_heff_2eelab_2erules_2elamSynthesised_lam1(V self, V *args) {
  V v_u_2445 = args[0];
  V v_bty_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2445);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_bty_2410});
}
HEFF_LIT(g_heff_2eelab_2erules_2eheldLocal_str0, 4, "With");
HEFF_LIT(g_heff_2eelab_2erules_2eheldLocal_str1, 5, ".With");
Clo g_heff_2eelab_2erules_2eheldLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eheldLocal_entry, 3, 0};

V g_heff_2eelab_2erules_2eheldLocal(V v_l_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CEmpty: {
    heff_drop(v_l_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_CBind: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_l_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_241, 0);
      V v_xs_247 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_l_248 = heff_dup(v_l_240);
      V v_t_249 = heff_dup(v_t_245);
      V v_t_2433;
      switch (heff_tag_of(v_t_249)) {
      case TAG_VU: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2411 = heff_field(v_t_249, 0);
        V v_sp_2412 = heff_field(v_t_249, 1);
        heff_take_n(v_t_249, 3ULL, 5);
        switch (heff_tag_of(v_t1_2411)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2411, 0ULL, 1);
          heff_drop(v_l_248);
          heff_drop(v_sp_2412);
          v_t_2433 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          V v_k_2417 = heff_field(v_t1_2411, 0);
          heff_take_n(v_t1_2411, 1ULL, 1);
          if ((heff_strEq_c_lent(v_k_2417, ((V)&g_heff_2eelab_2erules_2eheldLocal_str0), 2) || ({ int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_k_2417, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2435 = heff_strSlice(heff_dup(v_k_2417), heff_box_word(v_t_2418), heff_strLength_lent(v_k_2417, 0)); int c_ = heff_strEq_c_lent(v_t_2435, ((V)&g_heff_2eelab_2erules_2eheldLocal_str1), 2); heff_drop(v_t_2435); c_; }); c_; }))) {
            heff_drop(v_k_2417);
            v_t_2433 = ({ V a_0 = v_l_248; V a_1 = v_sp_2412; V r_ = (g_heff_2eelab_2erules_2espineHasLocal(a_0, a_1)); heff_drop(v_sp_2412); r_; });
          } else {
            heff_drop(v_l_248);
            heff_drop(v_sp_2412);
            heff_drop(v_k_2417);
            v_t_2433 = NTAG(TAG_False);
          }
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2411, 0ULL, 1);
          heff_drop(v_l_248);
          heff_drop(v_sp_2412);
          v_t_2433 = NTAG(TAG_False);
          break;
        }
        case TAG_HError: {
          heff_drop(v_l_248);
          heff_drop(v_sp_2412);
          v_t_2433 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_2411);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_t_249, 0ULL, 6);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        heff_take_n(v_t_249, 0ULL, 4);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_l_248);
        v_t_2433 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop(v_l_240);
        heff_drop(v_xs_247);
        heff_drop(v_t_2433);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_246, heff_dup(v_t_245)})});
      } else {
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_2433);
        V t_0 = v_l_240;
        V t_1 = v_xs_247;
        V t_2 = v_c_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_CUndelay: {
    V v_c_2434 = heff_field(v_x3_242, 0);
    V t_0 = v_l_240;
    V t_1 = v_x2_241;
    V t_2 = v_c_2434;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eheldLocal_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eheldLocal(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2erules_2emismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emismatch_entry, 7, 0};

V g_heff_2eelab_2erules_2emismatch(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_err_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2erules_2eescapeLevel_24cpr(v_err_244));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_l_2410 = v_field_249;
      V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 1, 5);
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 3, 5);
      V v_t_2413 = ({ V a_0 = heff_dup(v_l_2410); V a_1 = v_t_2411; V a_2 = v_t_2412; V r_ = (g_heff_2eelab_2erules_2eheldLocal(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_a_242; V a_3 = v_a_27_243; V a_4 = v_err_244; V a_5 = v_l_2410; V a_6 = v_t_2413; V r_ = heff_tr(g_heff_2eelab_2erules_2eescapeAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2413); r_; });
      return heff_tail(v_t_2414, 2, (V[]){v_z_245, v_z_246});
    } else {
      heff_drop(v_field_249);
      V v_t_2415 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      HEFF_LAST return g_heff_2eelab_2erules_2eplainMismatch(v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2415, v_z_245, v_z_246);
    }
  }
}
V g_heff_2eelab_2erules_2emismatch_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2emismatch(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
Clo g_heff_2eelab_2erules_2eapply_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapply_entry, 2, 0};

V g_heff_2eelab_2erules_2eapply(V v_sp_240, V v_syn_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2eapply_24cpr(v_sp_240, v_syn_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eapply(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str0, 97, "the definition would need itself while it is being computed: put the recursive use under a lambda");
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str1, 46, "can only use rec when checking at a small type");
HEFF_LIT(g_heff_2eelab_2erules_2erecChk_24cpr_str2, 46, "can only use rec when checking at a small type");
V g_heff_2eelab_2erules_2erecChk_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2erecChk_24cpr_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecChk_24cpr_lam4, 1, 0};
V g_heff_2eelab_2erules_2erecChk_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecChk_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V v_sp_240, V v_c_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam0, 2, 2, (V[]){v_sp_240, v_c_241})}});
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_247 = heff_take_field(v_hd_245, 1);
  V v_malg_248 = heff_get_n(v_hd_245, 2, 3);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(331LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(v_malg_248, 1, (V[]){v_t_2411}));
  V f_ = v_bind_247;
  args[0] = v_t_2412;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam4(V self, V *args) {
  V v_u_2423 = args[0];
  heff_drop(v_u_2423);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_SRec, 1, (V[]){heff_get_n(v_x_2421, 0, 2)});
  V f_ = v_k_2420;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2422, ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam3, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2426 = heff_take_field(v_hd_2424, 1);
  V v_malg_2427 = heff_get_n(v_hd_2424, 2, 3);
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2427, 1, (V[]){v_t_2430}));
  V f_ = v_bind_2426;
  args[0] = v_t_2431;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam6(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2434 = heff_take_field(v_hd_2432, 1);
  V v_malg_2435 = heff_get_n(v_hd_2432, 2, 3);
  V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(320LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecChk_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_call(v_malg_2435, 1, (V[]){v_t_2438}));
  V f_ = v_bind_2434;
  args[0] = v_t_2439;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecChk_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a_243 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2eelab_2evalue_2elevelOf(v_a_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Small: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_e_242, 3)), MK_INT(0LL))) {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_a_243);
      heff_drop(v_c_241);
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam1, 2, 1, (V[]){v_sp_240});
    } else {
      heff_drop(v_sp_240);
      V v_sd_2413 = heff_take_field(v_e_242, 0);
      V v_c_2418;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkChk: {
        V v_f_2414 = heff_field(v_c_241, 0);
        V v_ru_24c_241_24MkChk = heff_take_reuse_n(v_c_241, 1ULL, 1);
        V v_t_2415 = heff_tag_at_n(v_ru_24c_241_24MkChk, TAG_CUndelay, 1, (V[]){heff_dup(heff_rfield(v_sd_2413, 3))});
        V v_t_2416 = ({ V rv_3 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_sd_2413, 23ULL, 5, shape_len__names__locals__ctx__matched, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2417 = ({ V rv_0 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        v_c_2418 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_t_2417, v_a_243}));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam2, 2, 1, (V[]){v_c_2418});
    }
  }
  case TAG_Large: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam5, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_a_243);
    heff_drop(v_c_241);
    return heff_clo_n(g_heff_2eelab_2erules_2erecChk_24cpr_lam6, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str1, 107, "` is a type written in place, and a default this record is given names it: define the type apart, and set `");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str2, 13, "` to its name");
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam0, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam1, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2edescribedBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_entry, 2, 0};

V g_heff_2eelab_2erules_2edescribedBound(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_el_246 = heff_dup(heff_rfield(v_m_244, 2));
    V v_name_247 = heff_dup(heff_rfield(v_m_244, 0));
    V v_span_248 = heff_dup(heff_rfield(v_m_244, 4));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_el_246, 2);
      heff_drop(v_name_247);
      heff_drop(v_span_248);
      return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam1_clo);
    }
    case TAG_Cons: {
      V v_b_2411 = heff_field(v_x2_241, 0);
      V v_bs_2412 = heff_field(v_x2_241, 1);
      if ((heff_dup(v_b_2411) == NTAG(TAG_True))) {
        V v_x1_2413 = heff_get_n(v_el_246, 0, 2);
        V v_t_2463;
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_SLocal: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SCode: {
          V v_x11_2416 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 1);
          switch (heff_tag_of(v_x11_2416)) {
          case TAG_SU: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SDecode: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SFunction: {
            heff_take_n(v_x11_2416, 0ULL, 5);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SRecord: {
            heff_take_n(v_x11_2416, 0ULL, 3);
            v_t_2463 = NTAG(TAG_True);
            break;
          }
          case TAG_SSum: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_True);
            break;
          }
          case TAG_SIsTy: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SPrimInt: {
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SPrimFloat: {
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SPrimString: {
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SPrimRune: {
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SPrimArray: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          case TAG_SFixed: {
            heff_take_n(v_x11_2416, 0ULL, 1);
            v_t_2463 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x11_2416);
          }
          break;
        }
        case TAG_SApp: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SCons: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_STag: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SMatch: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SSpecialize: {
          heff_take_n(v_x1_2413, 0ULL, 3);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SIs: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SOpaque: {
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SAbandon: {
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SRec: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SFix: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SImplicit: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SPrim: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SMetaApp: {
          heff_take_n(v_x1_2413, 0ULL, 3);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitInt: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitFloat: {
          heff_take_na(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitString: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitBytes: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitRune: {
          heff_take_n(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitFixed: {
          heff_take_n(v_x1_2413, 0ULL, 2);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_SLitFloat32: {
          heff_take_na(v_x1_2413, 0ULL, 1);
          v_t_2463 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x1_2413);
        }
        if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
          heff_drop(v_t_2463);
          V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str0), heff_dup(v_name_247)), ((V)&g_heff_2eelab_2erules_2edescribedBound_str1));
          V v_msg_2465 = heff_strAppend(heff_strAppend(v_t_2464, v_name_247), ((V)&g_heff_2eelab_2erules_2edescribedBound_str2));
          return heff_clo_n(g_heff_2eelab_2erules_2edescribedBound_lam2, 2, 2, (V[]){v_msg_2465, v_span_248});
        } else {
          heff_drop(v_name_247);
          heff_drop(v_span_248);
          heff_drop(v_t_2463);
          V t_0 = v_rest_245;
          V t_1 = v_bs_2412;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        heff_drop_rec(v_el_246, 2);
        heff_drop(v_name_247);
        heff_drop(v_span_248);
        V t_0 = v_rest_245;
        V t_1 = v_bs_2412;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2edescribedBound(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k2_2467 = args[1];
  V v_msg_2465 = heff_env(self)[0];
  V v_span_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2468 = heff_take_field(v_hd_2466, 1);
  V v_malg_2469 = heff_get_n(v_hd_2466, 2, 3);
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(344LL), NTAG(TAG_SError), v_msg_2465, v_span_248, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(v_malg_2469, 1, (V[]){v_t_2472}));
  V f_ = v_bind_2468;
  args[0] = v_t_2473;
  args[1] = v_k2_2467;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2erecordIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2erecordIntro_24cpr(v_sp_240, v_fieldSettings_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordIntro(a[0], a[1]);
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24generate3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate3_lam0, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24generate3_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate3_lam2, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_24generate3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate3_entry, 3, 0};

V g_heff_2eelab_2erules_2esumFormation_24generate3(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_xs_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
      V v_t_2414;
      if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_243);
        v_t_2414 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erules_2esumFormation_24generate3_lam0_clo));
      } else {
        V v_m_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
        V v_y_2412 = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24generate3_lam1, 1, 1, (V[]){v_m_246});
        V v_t_2413 = heff_arrayKeepsAs_lent(v_xs_243, v_y_2412, 0);
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_m_244);
          heff_drop(v_t_2413);
          v_t_2414 = (g_heff_2eelab_2erules_2esumFormation_24map2(MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_2412)));
        } else {
          heff_drop(v_t_2413);
          v_t_2414 = ({ V a_0 = v_xs_243; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_244, v_y_2412); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate2(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
        }
      }
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_2414);
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_xs_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
    V v_t_2414;
    if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_243);
      v_t_2414 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erules_2esumFormation_24generate3_lam2_clo));
    } else {
      V v_m_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
      V v_y_2412 = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24generate3_lam3, 1, 1, (V[]){v_m_246});
      V v_t_2413 = heff_arrayKeepsAs_lent(v_xs_243, v_y_2412, 0);
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_m_244);
        heff_drop(v_t_2413);
        v_t_2414 = (g_heff_2eelab_2erules_2esumFormation_24map2(MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_2412)));
      } else {
        heff_drop(v_t_2413);
        v_t_2414 = ({ V a_0 = v_xs_243; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_244, v_y_2412); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate2(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
      }
    }
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_2414);
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esumFormation_24generate3(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam0(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam1(V self, V *args) {
  V v_u2_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_247);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_m_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_249;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_2411;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam2(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24generate3_lam3(V self, V *args) {
  V v_u2_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_247);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_m_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_249;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_x_2411;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2erules_2eseeArm_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eseeArm_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_lam0, 2, 0};
V g_heff_2eelab_2erules_2eseeArm_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2eseeArm_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_lam1, 2, 0};
V g_heff_2eelab_2erules_2eseeArm_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eseeArm_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eseeArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eseeArm_entry, 5, 0};

V g_heff_2eelab_2erules_2eseeArm(V v_sc_240, V v_p_241, V v_xs_242, V v_what_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_sc_240, 5);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    heff_drop(v_what_243);
    return ((V)&g_heff_2eelab_2erules_2eseeArm_lam0_clo);
  }
  case TAG_Just: {
    V v_at_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_sc_240, 4)), 1, 2);
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_list_2eany_24s2135465121x1956745568(a_0)); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_sc_240, 5);
      heff_drop(v_p_241);
      heff_drop(v_xs_242);
      heff_drop(v_what_243);
      heff_drop(v_at_247);
      heff_drop(v_t_249);
      return ((V)&g_heff_2eelab_2erules_2eseeArm_lam1_clo);
    } else {
      heff_drop(v_t_249);
      V v_sc_2412 = v_sc_240;
      V v_p_2413 = v_p_241;
      V v_x3_2414 = v_xs_242;
      V v_x3_2429;
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nil: {
        heff_drop_rec(v_sc_2412, 5);
        heff_drop(v_p_2413);
        v_x3_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x3_2414, 0);
        V v_xs_2416 = heff_field(v_x3_2414, 1);
        heff_take_n(v_x3_2414, 3ULL, 2);
        V v_t_2426 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eseeArm_lam2, 1, 2, (V[]){heff_dup(v_p_2413), heff_dup(v_sc_2412)}); V a_1 = v_xs_2416; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_xs_2416); r_; });
        if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
          heff_drop(v_t_2426);
          switch (heff_tag_of(v_p_2413)) {
          case TAG_Nothing: {
            heff_drop_rec(v_sc_2412, 5);
            heff_drop(v_x_2415);
            v_x3_2429 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_p_2427 = heff_field(v_p_2413, 0);
            heff_take_n(v_p_2413, 1ULL, 1);
            V v_t_2428 = heff_get_n(heff_get_n(v_sc_2412, 4, 5), 1, 2);
            v_x3_2429 = ({ V a_0 = v_t_2428; V a_1 = v_p_2427; V a_2 = v_x_2415; V a_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2eelab_2eenvironment_2eruledOutAt(a_0, a_1, a_2, a_3)); heff_drop(v_t_2428); r_; });
            break;
          }
          default: heff_nomatch(v_p_2413);
          }
        } else {
          heff_drop_rec(v_sc_2412, 5);
          heff_drop(v_p_2413);
          heff_drop(v_x_2415);
          heff_drop(v_t_2426);
          v_x3_2429 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_x3_2414);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2eseeArm_lam3, 2, 3, (V[]){v_x3_2429, v_at_247, v_what_243});
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2erules_2eseeArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eseeArm(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eseeArm_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eseeArm_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eseeArm_lam2(V self, V *args) {
  V v_y_2417 = args[0];
  V v_p_2413 = heff_env(self)[0];
  V v_sc_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_Nothing: {
    heff_drop(v_y_2417);
    heff_drop_rec(v_sc_2412, 5);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_p_2418 = heff_field(v_p_2413, 0);
    heff_take_n(v_p_2413, 1ULL, 1);
    V v_t_2419 = heff_get_n(heff_get_n(v_sc_2412, 4, 5), 1, 2);
    HeffT2 v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_p_2418; HeffT2 r_ = (g_heff_2eelab_2eenvironment_2ematchedTagsAt_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_ys_2423 = v_field_2422;
        V v_t_2424 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_y_2417}));
        V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_ys_2423; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ys_2423); r_; });
        V v_ret_24bool = heff_bool(!(heff_dup(v_t_2425) == NTAG(TAG_True)));
        heff_drop(v_t_2425);
        return v_ret_24bool;
      } else {
        heff_drop(v_y_2417);
        heff_drop(v_field_2422);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_heff_2eelab_2erules_2eseeArm_lam4(V self, V *args) {
  V v_c_2434 = args[0];
  V v_x3_2429 = heff_env(self)[0];
  V v_at_247 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436;
  switch (heff_tag_of(v_x3_2429)) {
  case TAG_Nothing: {
    heff_drop(v_what_243);
    v_t_2436 = heff_tag_n(TAG_ArmTaken, 1, (V[]){v_at_247});
    break;
  }
  case TAG_Just: {
    V v_by_2435 = heff_field(v_x3_2429, 0);
    heff_take_n(v_x3_2429, 1ULL, 1);
    v_t_2436 = heff_tag_n(TAG_ArmRuledOut, 3, (V[]){v_at_247, v_by_2435, v_what_243});
    break;
  }
  default: heff_nomatch(v_x3_2429);
  }
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, heff_take_field(v_c_2434, 8)});
  return ({ V rv_8 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_c_2434, 255ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2erules_2eseeArm_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_malg_2433 = heff_env(self)[0];
  V v_bind_2432 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2442 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2441, NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(v_malg_2433, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})}));
  V f_ = v_bind_2432;
  heff_room[0] = v_t_2444;
  heff_room[1] = v_k_2431;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eseeArm_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x3_2429 = heff_env(self)[0];
  V v_at_247 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2432 = heff_take_field(v_hd_2430, 1);
  V v_malg_2433 = heff_get_n(v_hd_2430, 2, 3);
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eseeArm_lam4, 1, 3, (V[]){v_x3_2429, v_at_247, v_what_243})})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tr(heff_call(heff_dup(v_malg_2433), 1, (V[]){v_t_2439}));
  V f_ = heff_dup(v_bind_2432);
  args[0] = v_t_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eseeArm_lam5, 1, 3, (V[]){v_malg_2433, v_bind_2432, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumbered_entry, 2, 0};

V g_heff_2eelab_2erules_2enumbered(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erules_2enumbered_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2enumbered_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumbered(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2enumbered_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumbered_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2enumbered_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2enumbered_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumbered_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayAt_24cpr_str0, 13, "builtin.delay");
HEFF_LIT(g_heff_2eelab_2erules_2edelayAt_24cpr_str1, 1, "a");
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2edelayAt_24cpr(V v_sp_240, V v_a_241, V v_thunk_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2efindPrim_24cpr(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2edelayAt_24cpr_str0)));
  {
    V v_field_244 = v_t_243.f[0];
    return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2edelayAt_24cpr_lam0, 1, 4, (V[]){v_field_244, v_sp_240, heff_dup(v_a_241), v_thunk_242})}});
  }
}
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_thunk_242 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = v_sp_240; V a_3 = v_thunk_242; V a_4 = v_e_245; V a_5 = v_x_2416; V a_6 = v_hd_248; V a_7 = v_k_249; V r_ = (g_heff_2eelab_2erules_2eelimWaits(b_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_thunk_242 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_ecallee0_2414 = heff_field(v_x_2413, 0);
    V v_a0_2415 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_245), heff_dup(v_sp_240), v_ecallee0_2414, v_a0_2415, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2edelayAt_24cpr_lam4, 1, 5, (V[]){v_sp_240, v_thunk_242, v_e_245, v_hd_248, v_k_249})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_thunk_242 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_ecallee_2411 = heff_field(v_x_2410, 0);
    V v_a0_2412 = heff_field(v_x_2410, 1);
    heff_take_n(v_x_2410, 3ULL, 2);
    return ({ V a_0 = heff_dup(v_sp_240); V a_1 = ((V)&g_heff_2eelab_2erules_2edelayAt_24cpr_str1); V a_2 = v_a_241; V a_3 = heff_dup(v_e_245); V a_4 = v_ecallee_2411; V a_5 = v_a0_2412; V a_6 = heff_dup(v_hd_248); V a_7 = heff_clo_n(g_heff_2eelab_2erules_2edelayAt_24cpr_lam3, 1, 5, (V[]){v_e_245, v_sp_240, v_hd_248, v_thunk_242, v_k_249}); V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_a_241); r_; });
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_e_245 = heff_env(self)[3];
  V v_thunk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayAt_24cpr_lam2, 1, 6, (V[]){v_sp_240, v_a_241, v_e_245, v_hd_248, v_thunk_242, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edelayAt_24cpr_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_field_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_thunk_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_246 = v_field_244;
  V v_c_247 = heff_tr(heff_call(v_f_246, 1, (V[]){heff_dup(v_e_245)}));
  return heff_clo_n(g_heff_2eelab_2erules_2edelayAt_24cpr_lam1, 2, 5, (V[]){v_c_247, v_sp_240, v_a_241, v_e_245, v_thunk_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_24tok1_str0, 20, "the instance found, ");
HEFF_LIT(g_heff_2eelab_2erules_2emisfit_24tok1_str1, 19, ", does not fit here");
Clo g_heff_2eelab_2erules_2emisfit_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emisfit_24tok1_entry, 7, 0};

V g_heff_2eelab_2erules_2emisfit_24tok1(V v_tok_240, V v_e_241, V v_sp_242, V v_w_243, V v_err_244, V v_z_245, V v_z_246) {
top: ;
  V v_bind_247 = heff_take_field(v_z_245, 1);
  V v_malg_248 = heff_get_n(v_z_245, 2, 3);
  V v_t_249 = heff_tr(heff_call(heff_get_n(v_w_243, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_msg_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2emisfit_24tok1_str0), v_t_249), ((V)&g_heff_2eelab_2erules_2emisfit_24tok1_str1));
  V v_note_2411 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_get_n(v_e_241, 1, 6), v_err_244));
  V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_msg_2410, v_sp_242, heff_tag_n(TAG_Just, 1, (V[]){v_note_2411})});
  V v_t_2413 = heff_tag_at_n(v_tok_240, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(v_malg_248, 1, (V[]){v_t_2414}));
  return heff_tail(v_bind_247, 2, (V[]){v_t_2415, v_z_246});
}
V g_heff_2eelab_2erules_2emisfit_24tok1_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2emisfit_24tok1(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}