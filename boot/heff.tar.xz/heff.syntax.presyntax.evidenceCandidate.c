// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_start 311115900
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str0, 2, "p#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str1, 2, "p#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str2, 3, "InR");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str3, 3, "InL");
Clo g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(V v_w_240, V v_sp_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_w_240)) {
    case TAG_Nothing: {
      V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_244 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str0), v_t_243)});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_241});
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_w_240, 0);
      V v_ru_24w_240_24Just = heff_take_reuse_n(v_w_240, 1ULL, 1);
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24w_240_24Just, TAG_EVar, 1, (V[]){v_x_245}), heff_dup(v_sp_241)});
      V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_248 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str1), v_t_247)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_246, v_t_249));
    }
    default: return heff_nomatch(v_w_240);
    }
  }
  case TAG_Cons: {
    V v_b_2410 = heff_field(v_x1_242, 0);
    V v_rest_2411 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_t_2412;
    if ((heff_dup(v_b_2410) == NTAG(TAG_True))) {
      heff_drop(v_b_2410);
      v_t_2412 = ((V)&g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str2);
    } else {
      heff_drop(v_b_2410);
      v_t_2412 = ((V)&g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_str3);
    }
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_t_2412}), heff_dup(v_sp_241)});
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(v_w_240, v_sp_241, v_rest_2411));
    V v_t_2415 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_t_2415));
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eevidenceCandidate_2edown_242(a[0], a[1], a[2]);
}