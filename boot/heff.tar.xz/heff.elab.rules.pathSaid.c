// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eelab_2erules_2epathSaid_2edown_241(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo;
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str0, 1, "p");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str1, 2, " p");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str2, 4, "InR ");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str3, 4, "InL ");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str4, 1, "(");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str5, 1, ")");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str6, 1, "(");
HEFF_LIT(g_heff_2eelab_2erules_2epathSaid_2edown_241_str7, 1, ")");
Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2epathSaid_2edown_241_entry, 2, 0};

V g_heff_2eelab_2erules_2epathSaid_2edown_241(V v_w_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_w_240)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str0);
    }
    case TAG_Just: {
      V v_x_242 = heff_field(v_w_240, 0);
      return heff_strAppend(heff_dup(v_x_242), ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str1));
    }
    default: return heff_nomatch(v_w_240);
    }
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x1_241, 0);
    V v_rest_244 = heff_field(v_x1_241, 1);
    V v_t_245;
    if ((heff_dup(v_b_243) == NTAG(TAG_True))) {
      v_t_245 = ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str2);
    } else {
      v_t_245 = ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str3);
    }
    V v_t_2411;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_w_240)) {
      case TAG_Nothing: {
        v_t_2411 = (g_heff_2eelab_2erules_2epathSaid_2edown_241(v_w_240, v_rest_244));
        break;
      }
      case TAG_Just: {
        V v_t_247 = (g_heff_2eelab_2erules_2epathSaid_2edown_241(v_w_240, v_rest_244));
        v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str4), v_t_247), ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str5));
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      break;
    }
    case TAG_Cons: {
      V v_t_2410 = (g_heff_2eelab_2erules_2epathSaid_2edown_241(v_w_240, v_rest_244));
      v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str6), v_t_2410), ((V)&g_heff_2eelab_2erules_2epathSaid_2edown_241_str7));
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    return heff_strAppend(v_t_245, v_t_2411);
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2epathSaid_2edown_241(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}