// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V, V);
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdMap_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdRels(V);
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdRels_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo;
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(V, V);
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2enamesTag(V, V);
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enamesTag_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushArms_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo;
V g_heff_2ecompile_2eir_2ewaysMap(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24dps_clo;
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2ecompile_2eir_2econdMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdMap_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdMap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return NTAG(TAG_CTrue);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return NTAG(TAG_CFalse);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_y_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_244}));
    return heff_tag_at_n(v_ru_24x2_241_24CRel, TAG_CRel, 3, (V[]){v_p_242, v_t_245, v_t_246});
  }
  case TAG_CTest: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CTest = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_248 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_247}));
    return heff_tag_at_n(v_ru_24x2_241_24CTest, TAG_CTest, 1, (V[]){v_t_248});
  }
  case TAG_CNot: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_249, heff_dup(v_cell_2410), MK_INT(0LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_CIf: {
    V v_a_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_c_2414 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_a_2412));
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_b_2413));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_t_2415, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_2414, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdMap(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2econdOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_rest_241;
  }
  case TAG_CFalse: {
    return v_rest_241;
  }
  case TAG_CRel: {
    V v_x_243 = heff_field(v_x1_240, 1);
    V v_y_244 = heff_field(v_x1_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_rest_241})});
  }
  case TAG_CTest: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_rest_241});
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V t_0 = v_c_246;
    V t_1 = v_rest_241;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_c_249 = heff_field(v_x1_240, 2);
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdOnto(v_c_249, v_rest_241));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdOnto(v_b_248, v_t_2410));
    V t_0 = v_a_247;
    V t_1 = v_t_2411;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econdRels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdRels_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdRels(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_CFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_241), NTAG(TAG_Nil)});
  }
  case TAG_CTest: {
    return NTAG(TAG_Nil);
  }
  case TAG_CNot: {
    V v_c_245 = heff_field(v_x1_240, 0);
    V t_0 = v_c_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_CIf: {
    V v_a_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_c_248 = heff_field(v_x1_240, 2);
    V v_t_249 = (g_heff_2ecompile_2eir_2econdRels(v_a_246));
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdRels(v_b_247));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdRels(v_c_248));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return (g_prelude_2e_2b_2b(v_t_249, v_t_2412));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdRels(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2enamesTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enamesTag_entry, 2, 0};

V g_heff_2ecompile_2eir_2enamesTag(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      if (heff_strEq_c_lent(v_t_240, v_t2_244, 0)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2enamesTag(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2enubI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_24dps_entry, 2, 0};

V g_heff_2ecompile_2eir_2enubI_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take_n(v_a_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2eir_2epushArms_24dps(v_args_243, v_rest_241, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_fs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_248;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysMap_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysMap(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2411 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, v_a_249, heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2eir_2ewaysMap_24dps(v_f_240, v_b_2410, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_241, 0);
    V v_arms_2423 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_lam0, 1, 1, (V[]){v_f_240}), v_arms_2423));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2422, v_t_2429});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2443 = heff_field(v_e_241, 0);
    V v_a_2444 = heff_field(v_e_241, 1);
    V v_b_2445 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2446 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2443, v_a_2444, heff_hole()});
    V v_u_2447 = (g_heff_2ecompile_2eir_2ewaysMap_24dps(v_f_240, v_b_2445, heff_dup(v_cell_2446)));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  case TAG_EValues: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysMap_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_vs_2426 = heff_field(v_x2_2424, 1);
    V v_b_2427 = heff_field(v_x2_2424, 2);
    V v_ru_24x2_2424_24MkArm = heff_take_reuse_n(v_x2_2424, 7ULL, 3);
    V v_t_2428 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_f_240, v_b_2427));
    return heff_tag_at_n(v_ru_24x2_2424_24MkArm, TAG_MkArm, 3, (V[]){v_t_2425, v_vs_2426, v_t_2428});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_e_27_248 = v_field_246;
      V v_n1_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_249, v_rest_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_es_2413 = v_field_2411;
        V v_n_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_27_248, v_es_2413}), v_n_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2ecompile_2eir_2eglobalsGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_args_246; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_246); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EApp, v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    V t_0 = v_e2_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_args_2421; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x1_240, 0);
    V v_arms_2424 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(v_s_2423));
    V v_t_2426 = ({ V a_0 = v_arms_2424; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a_0)); heff_drop(v_arms_2424); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EMatch, v_t_2425, v_t_2426));
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_args_2429; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2429); r_; });
  }
  case TAG_ECall: {
    V v_g_2430 = heff_field(v_x1_240, 0);
    V v_args_2431 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2432 = ({ V a_0 = v_args_2431; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2431); r_; });
    return heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_g_2430, v_t_2432});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    V v_c_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2441 = ({ V a_0 = v_c_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2440); r_; });
    return ({ V a_0 = v_t_2441; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_t_2441); r_; });
  }
  case TAG_ESet: {
    V v_a_2443 = heff_field(v_x1_240, 1);
    V v_b_2444 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2445 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2443));
    V v_t_2446 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2444));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2445, v_t_2446));
  }
  case TAG_EValues: {
    V v_es_2447 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_es_2447; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_es_2447); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eglobalsGo(a[0]);
}

HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_args_246 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_h_2410 = v_field_248;
      V v_bs_2411 = v_field_249;
      V v_f_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_240_24EApp, v_bs_2411, v_args_246));
      return ((HeffT2){{v_h_2410, v_f_2412}});
    }
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EProj: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EStr: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EBool: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EValues: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFix: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_246)}});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eir_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eir_2econdIf(V v_x1_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_CFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_CNot: {
    V v_c_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_243;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2431;
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CRel: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CTest: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CNot: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CIf: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x1_240_24CIf, 3);
      heff_drop(v_t_2431);
      V v_t_2432 = (g_heff_2ecompile_2eir_2econdIf(v_b_245, heff_dup(v_t_241), heff_dup(v_e_242)));
      V v_t_2433 = (g_heff_2ecompile_2eir_2econdIf(v_c_246, v_t_241, v_e_242));
      V t_0 = v_a_244;
      V t_1 = v_t_2432;
      V t_2 = v_t_2433;
      v_x1_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2431);
      return heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_CIf, 3, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_a_244, v_b_245, v_c_246}), v_t_241, v_e_242});
    }
  }
  default: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CFalse: {
        return v_x1_240;
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        switch (heff_tag_of(v_x1_240)) {
        case TAG_CTrue: {
          return NTAG(TAG_CFalse);
        }
        case TAG_CFalse: {
          return NTAG(TAG_CTrue);
        }
        case TAG_CRel: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CTest: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CNot: {
          V v_c_2446 = heff_field(v_x1_240, 0);
          heff_take_n(v_x1_240, 1ULL, 1);
          return v_c_2446;
        }
        case TAG_CIf: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        default: return heff_nomatch(v_x1_240);
        }
      }
      case TAG_CFalse: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CRel: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CTest: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CNot: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CIf: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  }
}
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdIf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    HeffT3 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_t_2427 = v_field_2425;
        V v_f_2428 = v_field_2426;
        V v_t_2429 = (g_heff_2ecompile_2eir_2econdShaped(v_t_2427));
        if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
          heff_drop(v_t_2429);
          V t_0 = v_f_2428;
          v_e_240 = t_0;
          goto top;
        } else {
          heff_drop(v_f_2428);
          heff_drop(v_t_2429);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2425);
        heff_drop(v_field_2426);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2431 = heff_field(v_e_240, 0);
    V v_e2_2432 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_Nil: {
      heff_drop(v_p_2431);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2434 = heff_field(v_e2_2432, 1);
      heff_take_n(v_e2_2432, 2ULL, 2);
      switch (heff_tag_of(v_e22_2434)) {
      case TAG_Nil: {
        heff_drop(v_p_2431);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2436 = heff_field(v_e22_2434, 1);
        heff_take_n(v_e22_2434, 2ULL, 2);
        switch (heff_tag_of(v_e222_2436)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2431; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2431); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2436, 0ULL, 2);
          heff_drop(v_p_2431);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2436);
        }
      }
      default: return heff_nomatch(v_e22_2434);
      }
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdShaped(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EVar = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_a_245 = heff_strCompare_lent(v_x_244, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_245, MK_INT(0LL), 2)) {
      heff_drop(v_lit_242);
      heff_drop(v_a_245);
      return heff_tag_at_n(v_ru_24e_243_24EVar, TAG_EVar, 1, (V[]){v_x_244});
    } else {
      if (heff_intEq_c(v_a_245, MK_INT(0LL))) {
        heff_drop(v_x_244);
        return heff_tag_at_n(v_ru_24e_243_24EVar, TAG_EVar, 1, (V[]){v_lit_242});
      } else {
        heff_drop(v_lit_242);
        return heff_tag_at_n(v_ru_24e_243_24EVar, TAG_EVar, 1, (V[]){v_x_244});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_243, 0);
    V v_b_248 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_249 = heff_tag_at_n(v_ru_24e_243_24ELam, TAG_ELam, 2, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_248, heff_dup(v_cell_249), MK_INT(1LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_243, 0);
    V v_args_2412 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_f_2411));
    V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2412));
    return heff_tag_at_n(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){v_t_2413, v_t_2415});
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_e_243, 0);
    V v_a_2417 = heff_field(v_e_243, 1);
    V v_b_2418 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2419 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2417));
    V v_cell_2420 = heff_tag_at_n(v_ru_24e_243_24ELet, TAG_ELet, 3, (V[]){v_x_2416, v_t_2419, heff_hole()});
    V v_u_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2418, heff_dup(v_cell_2420), MK_INT(2LL)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_e_243, 0);
    V v_ts_2423 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_fs_2422));
    return heff_tag_at_n(v_ru_24e_243_24ERecord, TAG_ERecord, 2, (V[]){v_t_2428, v_ts_2423});
  }
  case TAG_EProj: {
    V v_e2_2429 = heff_field(v_e_243, 0);
    V v_l_2430 = heff_field(v_e_243, 1);
    V v_sh_2431 = heff_field(v_e_243, 2);
    V v_t_2432 = heff_field(v_e_243, 3);
    V v_ru_24e_243_24EProj = heff_take_reuse_n(v_e_243, 15ULL, 4);
    V v_t_2433 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_e2_2429));
    return heff_tag_at_n(v_ru_24e_243_24EProj, TAG_EProj, 4, (V[]){v_t_2433, v_l_2430, v_sh_2431, v_t_2432});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_field(v_e_243, 0);
    V v_args_2435 = heff_field(v_e_243, 1);
    V v_ts_2436 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ETag = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2435));
    return heff_tag_at_n(v_ru_24e_243_24ETag, TAG_ETag, 3, (V[]){v_t_2434, v_t_2438, v_ts_2436});
  }
  case TAG_EMatch: {
    V v_s_2439 = heff_field(v_e_243, 0);
    V v_arms_2440 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_s_2439));
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_arms_2440));
    return heff_tag_at_n(v_ru_24e_243_24EMatch, TAG_EMatch, 2, (V[]){v_t_2441, v_t_2447});
  }
  case TAG_EPrim: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EPrimCall: {
    V v_p_2449 = heff_field(v_e_243, 0);
    V v_args_2450 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2450));
    return heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2449, v_t_2452});
  }
  case TAG_ECall: {
    V v_g_2453 = heff_field(v_e_243, 0);
    V v_args_2454 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2454));
    return heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_g_2453, v_t_2456});
  }
  case TAG_EInt: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFloat: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EStr: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EBytes: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFixed: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EFloat32: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EAbandon: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  case TAG_EBool: {
    V v_c_2464 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EBool = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2466 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_c_2464));
    return heff_tag_at_n(v_ru_24e_243_24EBool, TAG_EBool, 1, (V[]){v_t_2466});
  }
  case TAG_ESet: {
    V v_xs_2467 = heff_field(v_e_243, 0);
    V v_a_2468 = heff_field(v_e_243, 1);
    V v_b_2469 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2470 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2468));
    V v_cell_2471 = heff_tag_at_n(v_ru_24e_243_24ESet, TAG_ESet, 3, (V[]){v_xs_2467, v_t_2470, heff_hole()});
    V v_u_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2469, heff_dup(v_cell_2471), MK_INT(2LL)));
    heff_drop(v_u_2472);
    return v_cell_2471;
  }
  case TAG_EValues: {
    V v_es_2473 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EValues = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2475 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_es_2473));
    return heff_tag_at_n(v_ru_24e_243_24EValues, TAG_EValues, 1, (V[]){v_t_2475});
  }
  case TAG_EFix: {
    heff_drop(v_lit_242);
    return v_e_243;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_l_2425 = heff_field(v_p_2424, 0);
    V v_e2_2426 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24MkPair = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    V v_t_2427 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2426; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_at_n(v_ru_24p_2424_24MkPair, TAG_MkPair, 2, (V[]){v_l_2425, v_t_2427});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2(V self, V *args) {
  V v_a_2437 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2437; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_a_2442, 0);
    V v_vs_2444 = heff_field(v_a_2442, 1);
    V v_b_2445 = heff_field(v_a_2442, 2);
    V v_ru_24a_2442_24MkArm = heff_take_reuse_n(v_a_2442, 7ULL, 3);
    V v_t_2446 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2445; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_at_n(v_ru_24a_2442_24MkArm, TAG_MkArm, 3, (V[]){v_t_2443, v_vs_2444, v_t_2446});
  }
  default: return heff_nomatch(v_a_2442);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4(V self, V *args) {
  V v_a_2451 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2451; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5(V self, V *args) {
  V v_a_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2455; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6(V self, V *args) {
  V v_a_2465 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2465; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7(V self, V *args) {
  V v_a_2474 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2474; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
Clo g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_t_244;
    if ((heff_dup(v_acc_241) == NTAG(TAG_True))) {
      heff_drop(v_acc_241);
      v_t_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_acc_241);
      v_t_244 = (g_heff_2ecompile_2erunes_2ereads(heff_dup(v_e_242)));
    }
    V t_0 = v_es_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2emapParts_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2emapParts_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2emapParts_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2emapParts_24tok2(V v_tok_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_EVar: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EGlobal: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_242, 0);
    V v_b_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(v_f_241, 2, (V[]){heff_dup(v_xs_245), v_b_246}));
    return heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){v_xs_245, v_t_247});
  }
  case TAG_EApp: {
    V v_g_248 = heff_field(v_x2_242, 0);
    V v_args_249 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24EApp = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){NTAG(TAG_Nil), v_g_248}));
    V v_t_2411 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2412 = (g_list_2emap_24tok2(v_ru_24x2_242_24EApp, v_t_2411, v_args_249));
    return heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){v_t_2410, v_t_2412});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_x2_242, 0);
    V v_a_2414 = heff_field(v_x2_242, 1);
    V v_b_2415 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24ELet = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2416 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){NTAG(TAG_Nil), v_a_2414}));
    V v_t_2417 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_x_2413), NTAG(TAG_Nil)});
    V v_t_2418 = heff_tr(heff_call(v_f_241, 2, (V[]){v_t_2417, v_b_2415}));
    return heff_tag_at_n(v_ru_24x2_242_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_t_2416, v_t_2418});
  }
  case TAG_ERecord: {
    V v_fs_2419 = heff_field(v_x2_242, 0);
    V v_ts_2420 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24ERecord = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2425 = (g_list_2emap_24tok2(v_ru_24x2_242_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2emapParts_24tok2_lam0, 1, 1, (V[]){v_f_241}), v_fs_2419));
    return heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){v_t_2425, v_ts_2420});
  }
  case TAG_EProj: {
    V v_e_2426 = heff_field(v_x2_242, 0);
    V v_l_2427 = heff_field(v_x2_242, 1);
    V v_sh_2428 = heff_field(v_x2_242, 2);
    V v_t_2429 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24EProj = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2430 = heff_tr(heff_call(v_f_241, 2, (V[]){NTAG(TAG_Nil), v_e_2426}));
    return heff_tag_at_n(v_ru_24x2_242_24EProj, TAG_EProj, 4, (V[]){v_t_2430, v_l_2427, v_sh_2428, v_t_2429});
  }
  case TAG_ETag: {
    V v_t_2431 = heff_field(v_x2_242, 0);
    V v_args_2432 = heff_field(v_x2_242, 1);
    V v_ts_2433 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24ETag = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2434 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2435 = (g_list_2emap(v_t_2434, v_args_2432));
    return heff_tag_at_n(v_ru_24x2_242_24ETag, TAG_ETag, 3, (V[]){v_t_2431, v_t_2435, v_ts_2433});
  }
  case TAG_EMatch: {
    V v_s_2436 = heff_field(v_x2_242, 0);
    V v_arms_2437 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24EMatch = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2438 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){NTAG(TAG_Nil), v_s_2436}));
    V v_t_2444 = (g_list_2emap_24tok2(v_ru_24x2_242_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2emapParts_24tok2_lam1, 1, 1, (V[]){v_f_241}), v_arms_2437));
    return heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_t_2438, v_t_2444});
  }
  case TAG_EPrim: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EPrimCall: {
    V v_p_2446 = heff_field(v_x2_242, 0);
    V v_args_2447 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24EPrimCall = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2448 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2449 = (g_list_2emap_24tok2(v_ru_24x2_242_24EPrimCall, v_t_2448, v_args_2447));
    return heff_tag_at_n(v_tok_240, TAG_EPrimCall, 2, (V[]){v_p_2446, v_t_2449});
  }
  case TAG_ECall: {
    V v_g_2450 = heff_field(v_x2_242, 0);
    V v_args_2451 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24ECall = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2452 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2453 = (g_list_2emap_24tok2(v_ru_24x2_242_24ECall, v_t_2452, v_args_2451));
    return heff_tag_at_n(v_tok_240, TAG_ECall, 2, (V[]){v_g_2450, v_t_2453});
  }
  case TAG_EInt: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EFloat: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EStr: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EBytes: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EFixed: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EFloat32: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EAbandon: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_f_241);
    return v_x2_242;
  }
  case TAG_EBool: {
    V v_c_2461 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24EBool = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2462 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2463 = (g_heff_2ecompile_2eir_2econdMap(v_t_2462, v_c_2461));
    return heff_tag_at_n(v_ru_24x2_242_24EBool, TAG_EBool, 1, (V[]){v_t_2463});
  }
  case TAG_ESet: {
    V v_xs_2464 = heff_field(v_x2_242, 0);
    V v_a_2465 = heff_field(v_x2_242, 1);
    V v_b_2466 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24ESet = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2467 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){NTAG(TAG_Nil), v_a_2465}));
    V v_t_2468 = heff_tr(heff_call(v_f_241, 2, (V[]){heff_dup(v_xs_2464), v_b_2466}));
    return heff_tag_at_n(v_ru_24x2_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2464, v_t_2467, v_t_2468});
  }
  case TAG_EValues: {
    V v_es_2469 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24EValues = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2470 = heff_tr(heff_call(v_f_241, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2471 = (g_list_2emap(v_t_2470, v_es_2469));
    return heff_tag_at_n(v_ru_24x2_242_24EValues, TAG_EValues, 1, (V[]){v_t_2471});
  }
  case TAG_EFix: {
    V v_x_2472 = heff_field(v_x2_242, 0);
    V v_b_2473 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24EFix = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2474 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_x_2472), NTAG(TAG_Nil)});
    V v_t_2475 = heff_tr(heff_call(v_f_241, 2, (V[]){v_t_2474, v_b_2473}));
    return heff_tag_at_n(v_ru_24x2_242_24EFix, TAG_EFix, 2, (V[]){v_x_2472, v_t_2475});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2emapParts_24tok2(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2emapParts_24tok2_lam0(V self, V *args) {
  V v_x2_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_l_2422 = heff_field(v_x2_2421, 0);
    V v_e_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_call(v_f_241, 2, (V[]){NTAG(TAG_Nil), v_e_2423}));
    return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_l_2422, v_t_2424});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2eir_2emapParts_24tok2_lam1(V self, V *args) {
  V v_x2_2439 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkArm: {
    V v_t_2440 = heff_field(v_x2_2439, 0);
    V v_vs_2441 = heff_field(v_x2_2439, 1);
    V v_b_2442 = heff_field(v_x2_2439, 2);
    V v_ru_24x2_2439_24MkArm = heff_take_reuse_n(v_x2_2439, 7ULL, 3);
    V v_t_2443 = heff_tr(heff_call(v_f_241, 2, (V[]){heff_dup(v_vs_2441), v_b_2442}));
    return heff_tag_at_n(v_ru_24x2_2439_24MkArm, TAG_MkArm, 3, (V[]){v_t_2440, v_vs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24tok2(V v_tok_240, V v_x1_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_241, 0);
    V v_fs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2eir_2epushFields_24dps(v_fs_244, v_rest_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24tok2(a[0], a[1], a[2]);
}