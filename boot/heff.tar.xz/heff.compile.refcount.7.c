// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CInPlace 16708
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DVal 23084
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_ICond 62625
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RDupE 22574
#define TAG_RField 17425
#define TAG_RFieldV 15755
#define TAG_RGetN 31178
#define TAG_RGetRaw 14078
#define TAG_RLocal 34280
#define TAG_RTag 45075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_cells 295903083
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lent 9813446
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tokens 1078955205
#define LBL_workers 1757018875
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2eagrees(V, V, V);
V g_heff_2ecompile_2erefcount_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eagrees_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_clo;
V g_heff_2ecompile_2erefcount_2earmFound_24tok3(V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmFound_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmFound_24tok3_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2ebuiltOf(V);
V g_heff_2ecompile_2erefcount_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebuiltOf_clo;
V g_heff_2ecompile_2erefcount_2ecellIn_get(void);
V g_heff_2ecompile_2erefcount_2echangedOf(V, V, V);
V g_heff_2ecompile_2erefcount_2echangedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2echangedOf_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efreeOf(V, V);
V g_heff_2ecompile_2erefcount_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeOf_clo;
V g_heff_2ecompile_2erefcount_2efunPlain(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunPlain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunPlain_clo;
V g_heff_2ecompile_2erefcount_2efunRc(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunRc_clo;
V g_heff_2ecompile_2erefcount_2efunRc_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunRc_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunRc_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efunRc_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efunRc_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efunRc_24tok2_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintW(V, V);
V g_heff_2ecompile_2erefcount_2eintW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintW_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf(V);
V g_heff_2ecompile_2erefcount_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ercDef(V, V, V);
V g_heff_2ecompile_2erefcount_2ercDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ercDef_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereusedOf(V);
V g_heff_2ecompile_2erefcount_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusedOf_clo;
V g_heff_2ecompile_2erefcount_2ereusedOf_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2ereusedOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusedOf_24tok1_clo;
V g_heff_2ecompile_2erefcount_2esameAs(V, V, V);
V g_heff_2ecompile_2erefcount_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameAs_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalRc(V, V, V);
V g_heff_2ecompile_2erefcount_2evalRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalRc_clo;
V g_heff_2ecompile_2erefcount_2evalRc_24tok3(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalRc_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalRc_24tok3_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f408128283x2136699628(V, V);
V g_list_2emap_24f408128283x2136699628_entry(V self, V *a);
extern Clo g_list_2emap_24f408128283x2136699628_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s88069640x1067514236(V);
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2erefcount_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithKnown_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithKnown(V v_x_240, V v_k_241, V v_ce_242) {
top: ;
  V v_funs_243 = heff_take_field(v_ce_242, 0);
  V v_bounce_244 = heff_take_field(v_ce_242, 1);
  V v_self_245 = heff_take_field(v_ce_242, 2);
  V v_lam_246 = heff_take_field(v_ce_242, 3);
  V v_owned_247 = heff_take_field(v_ce_242, 4);
  V v_after_248 = heff_take_field(v_ce_242, 5);
  V v_borrowed_249 = heff_take_field(v_ce_242, 6);
  V v_bor_2410 = heff_take_field(v_ce_242, 7);
  V v_known_2411 = heff_take_field(v_ce_242, 8);
  V v_takes_2412 = heff_take_field(v_ce_242, 9);
  V v_reprs_2413 = heff_take_field(v_ce_242, 10);
  V v_sigs_2414 = heff_take_field(v_ce_242, 11);
  V v_flat_2415 = heff_take_field(v_ce_242, 12);
  V v_sure_2416 = heff_take_field(v_ce_242, 13);
  V v_sureRecs_2417 = heff_take_field(v_ce_242, 14);
  V v_tokens_2418 = heff_take_field(v_ce_242, 15);
  V v_ret_2419 = heff_get_n(v_ce_242, 16, 17);
  V v_t_2420 = (g_std_2emap_2einsert_24s93785294x875597928(v_known_2411, v_x_240, v_k_241));
  return heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_funs_243, v_bounce_244, v_self_245, v_lam_246, v_owned_247, v_after_248, v_borrowed_249, v_bor_2410, v_t_2420, v_takes_2412, v_reprs_2413, v_sigs_2414, v_flat_2415, v_sure_2416, v_sureRecs_2417, v_tokens_2418, v_ret_2419});
}
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithKnown(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edropsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edropsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edropsOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2edropsOf(V v_ce_240, V v_xs_241) {
top: ;
  V v_known_242 = heff_take_field(v_ce_240, 8);
  V v_reprs_243 = heff_get_n(v_ce_240, 10, 17);
  V v_t_249 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erefcount_2edropsOf_lam0, 1, 1, (V[]){v_reprs_243}), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edropsOf_lam1, 2, 1, (V[]){v_known_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edropsOf(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_reprs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_reprs_243; V a_1 = v_x_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_reprs_243); heff_drop(v_x_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) ? ({ V v_x_248 = heff_dup(v_field_247); int c_ = 0; heff_drop(v_x_248); c_; }) : 1));
    heff_drop(v_field_247);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_known_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_known_242; V a_1 = v_x_2411; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_known_242); r_; });
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropOf(v_x_2411, v_t_2412));
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2410));
}
Clo g_heff_2ecompile_2erefcount_2eindexIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eindexIn_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eindexIn(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_l_240, v_i_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2eindexIn(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereusePrim_str0, 6, "$reuse");

static V g_heff_2ecompile_2erefcount_2ereusePrim_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2ereusePrim_st;
static V g_heff_2ecompile_2erefcount_2ereusePrim_init(void) {
  return ((V)&g_heff_2ecompile_2erefcount_2ereusePrim_str0);
}
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2ereusePrim_st)) return g_heff_2ecompile_2erefcount_2ereusePrim_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2ereusePrim_val, &g_heff_2ecompile_2erefcount_2ereusePrim_st, g_heff_2ecompile_2erefcount_2ereusePrim_init);
}
Clo g_heff_2ecompile_2erefcount_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2erefcount_2ejustsOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ejustsOf(a[0]);
}
V g_heff_2ecompile_2erefcount_2echangedOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2echangedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2echangedOf_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2echangedOf(V v_ls_240, V v_x_241, V v_fs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_245 = (g_list_2ezipWith_24s1876717925x1404326288(v_fs_242, v_t_244));
  V v_t_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2echangedOf_lam0, 1, 2, (V[]){heff_dup(v_ls_240), heff_dup(v_x_241)}), v_t_245));
  return (g_list_2emap_24s88069640x1067514236(v_t_2414));
}
V g_heff_2ecompile_2erefcount_2echangedOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2echangedOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2echangedOf_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_ls_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249;
  switch (heff_tag_of(v_p_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_p_246, 0);
    heff_take_n(v_p_246, 1ULL, 2);
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_ls_240; V a_1 = v_t_249; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom_24cpr(a_0, a_1)); heff_drop(v_ls_240); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_y_2413 = v_field_2412;
      V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_x_241, v_y_2413, 0));
      heff_drop(v_x_241);
      heff_drop(v_y_2413);
      return v_ret_24bool;
    } else {
      heff_drop(v_x_241);
      heff_drop(v_field_2412);
      return NTAG(TAG_True);
    }
  }
}
Clo g_heff_2ecompile_2erefcount_2eagrees_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eagrees_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eagrees(V v_ce_240, V v_g_241, V v_argv_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 0), v_g_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_n_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_t_247 = heff_dup(heff_rfield(v_ce_240, 2));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_field_245);
      heff_drop(v_n_246);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_s_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_248, 1, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c_lent(v_t_249, v_n_246, 1)) {
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_m_2410 = v_field_245;
          if (heff_intEq_c(v_n_246, v_m_2410)) {
            return ({ V a_0 = heff_dup(v_ce_240); V b_1 = heff_get_n(v_ce_240, 2, 17); V a_2 = v_g_241; V r_ = (g_heff_2ecompile_2erefcount_2esameAs(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            heff_drop_rec(v_ce_240, 17);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_245);
          heff_drop(v_n_246);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_ce_240, 17);
        heff_drop(v_field_245);
        heff_drop(v_n_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eagrees_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2eagrees(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereuseV_24cpr_str0, 0, "");
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V v_ru_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SGlobal: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SInt: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFloat: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SStr: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SBytes: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFixed: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFloat32: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SPrimFn: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SLam: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_STag: {
    V v_t_2415 = heff_field(v_x3_242, 0);
    V v_argv_2416 = heff_field(v_x3_242, 1);
    V v_ts_2417 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24STag = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2416));
    if ((heff_intEq_c(heff_dup(v_t_2418), heff_dup(heff_rfield(v_n_241, 0))) && ((heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), ((V)&g_heff_2ecompile_2erefcount_2ereuseV_24cpr_str0)) || heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), heff_dup(v_t_2415))) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2415, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2415, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)))) {
      heff_drop_rec(v_n_241, 2);
      heff_drop(v_t_2418);
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_argv_2416, v_ts_2417}), NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_240}), v_t_2419});
      return ((HeffT2){{NTAG(TAG_True), heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()), v_t_2420})}});
    } else {
      heff_drop(v_t_2418);
      V v_x3_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2416; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2416); r_; });
      switch (heff_tag_of(v_x3_2422)) {
      case TAG_MkPair: {
        V v_b_2423 = heff_field(v_x3_2422, 0);
        V v_argv_2424 = heff_field(v_x3_2422, 1);
        heff_take_n(v_x3_2422, 3ULL, 2);
        return ((HeffT2){{v_b_2423, heff_tag_at_n(v_ru_24x3_242_24STag, TAG_STag, 3, (V[]){v_t_2415, v_argv_2424, v_ts_2417})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_2422)}});
      }
    }
  }
  case TAG_SRec: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SProj: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SPrim: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0(V self, V *args) {
  V v_v_2421 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2421));
}

static V g_heff_2ecompile_2erefcount_2ecellIn_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2ecellIn_st;
static V g_heff_2ecompile_2erefcount_2ecellIn_init(void) {
  return ((V)&g_list_2eany_24s1877524499x1789047582_clo);
}
V g_heff_2ecompile_2erefcount_2ecellIn_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2ecellIn_st)) return g_heff_2ecompile_2erefcount_2ecellIn_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2ecellIn_val, &g_heff_2ecompile_2erefcount_2ecellIn_st, g_heff_2ecompile_2erefcount_2ecellIn_init);
}
Clo g_heff_2ecompile_2erefcount_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebuiltOf_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2ebuiltOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_OSimple: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24OSimple = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_SVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      V v_xs_2412 = heff_field(v_x11_241, 0);
      V v_x112_2413 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x112_2413)) {
      case TAG_MkBlock: {
        V v_t_2414 = heff_field(v_x112_2413, 0);
        heff_take_n(v_x112_2413, 1ULL, 1);
        V v_xs_2415 = (g_heff_2ecompile_2erefcount_2efreeOf(v_xs_2412, v_t_2414));
        V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2415; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownClo, 1, (V[]){v_t_2416})});
      }
      default: return heff_nomatch(v_x112_2413);
      }
    }
    case TAG_STag: {
      V v_argv_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 3);
      V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_2418; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_2418); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2420})});
    }
    case TAG_SRec: {
      V v_fs_2421 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      V v_t_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2421; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownRec, 1, (V[]){v_t_2423})});
    }
    case TAG_SProj: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      V v_p_2428 = heff_field(v_x11_241, 0);
      V v_argv_2429 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      if (heff_strEq_c(v_p_2428, heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()))) {
        return ({ V a_0 = v_ru_24x1_240_24OSimple; V a_1 = v_argv_2429; V r_ = (g_heff_2ecompile_2erefcount_2ereusedOf_24tok1(a_0, a_1)); heff_drop(v_argv_2429); r_; });
      } else {
        heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
        heff_drop(v_argv_2429);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_OCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OPrim: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_OBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebuiltOf(a[0]);
}

HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_v_242 = heff_field(v_x2_241, 0);
    V v_vs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_vs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_242}});
    } else {
      heff_drop(v_v_242);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_vs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V v_ce_240, V v_x_241, V v_fa_242, V v_binding_243, V v_known_244, V v_takes_245, V v_rest_246, V v_after_247, V v_wb_248) {
top: ;
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_242), heff_dup(v_wb_248)));
  V v_xs_2412 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0, 1, 1, (V[]){v_wanted_249}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_fa_242, heff_dup(v_wb_248)));
  V v_t_2417 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1, 1, 1, (V[]){v_wanted_2415}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_248), heff_dup(v_ce_240)));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithTakes(v_takes_245, v_t_2418));
  V v_t_2420 = heff_tr(heff_call(v_binding_243, 1, (V[]){v_t_2419}));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_241, v_wb_248));
  V v_t_2426;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_t_2426 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_2421);
    V v_ce_2423;
    switch (heff_tag_of(v_known_244)) {
    case TAG_Nothing: {
      v_ce_2423 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_k_2422 = heff_field(v_known_244, 0);
      v_ce_2423 = (g_heff_2ecompile_2erefcount_2ewithKnown(heff_dup(v_x_241), heff_dup(v_k_2422), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_known_244);
    }
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_2425 = (g_heff_2ecompile_2erefcount_2edropsOf(v_ce_2423, v_t_2424));
    v_t_2426 = (g_list_2emap_24s1796125103x644876049(v_t_2425));
  }
  V v_t_2428 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2, 1, 1, (V[]){heff_dup(v_wb_248)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2429 = ({ V a_0 = v_x_241; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wb_248); r_; });
  V v_t_2436;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    v_t_2436 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_2430));
  } else {
    heff_drop(v_t_2429);
    v_t_2436 = NTAG(TAG_Nil);
  }
  V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2436));
  V v_t_2439;
  switch (heff_tag_of(v_known_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    v_t_2439 = heff_dup(v_ce_240);
    break;
  }
  case TAG_Just: {
    V v_k_2438 = heff_field(v_known_244, 0);
    v_t_2439 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_x_241, heff_dup(v_k_2438), heff_dup(v_ce_240)));
    break;
  }
  default: heff_nomatch(v_known_244);
  }
  V v_t_2440 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2439));
  V v_ce_2441 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2437, heff_get_n(v_ce_240, 5, 17), v_t_2440));
  V v_t_2442 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2441, v_rest_246, v_after_247));
  V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2442));
  V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2443));
  return (g_prelude_2e_2b_2b(v_t_2414, v_t_2444));
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2(V self, V *args) {
  V v_v_2427 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2427; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2427); heff_drop(v_wb_248); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2432 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2431; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2431); r_; });
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2433 == ((int64_t)0ULL)) ? ({ V v_x_2435 = heff_dup(v_field_2434); int c_ = 0; heff_drop(v_x_2435); c_; }) : 1));
    heff_drop(v_field_2434);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(V v_ce_240, V v_live_241, V v_t_242, V v_argv_243, V v_ts_244) {
top: ;
  V v_n_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_245, MK_INT(1LL))));
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam0, 1, 1, (V[]){heff_dup(v_ts_244)}), v_t_246));
  V v_t_2410 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_249));
  V v_n_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_243));
  V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2411, MK_INT(1LL))));
  V v_rps_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam1, 1, 1, (V[]){heff_dup(v_ts_244)}), v_t_2412));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, v_live_241, heff_dup(v_rps_2415), v_argv_243));
  V v_t_2417 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2415, v_t_2416));
  return heff_tag_n(TAG_RTag, 3, (V[]){v_t_242, v_t_2410, v_t_2417});
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_ts_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = heff_dup(v_i_247); V a_1 = v_ts_244; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_244); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_247, v_t_248));
}
V g_heff_2ecompile_2erefcount_2etagVal_24s1109446582x451714561_lam1(V self, V *args) {
  V v_i_2413 = args[0];
  V v_ts_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = ({ V a_0 = heff_dup(v_i_2413); V a_1 = v_ts_244; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_244); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2413, v_t_2414));
}
Clo g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_may_245, V v_x8_246, V v_x9_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x9_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
      return heff_tag_n(TAG_RGetN, 3, (V[]){v_t_248, v_i_243, v_n_244});
    }
    case TAG_Just: {
      V v_g_249 = heff_field(v_x9_247, 0);
      V v_ru_24x9_247_24Just = heff_take_reuse_n(v_x9_247, 1ULL, 1);
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_244);
      if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
        return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x9_247_24Just, TAG_RGetRaw, 1, (V[]){v_g_249}), v_i_243});
      } else {
        V v_t_2410 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x9_247_24Just, TAG_RGetRaw, 1, (V[]){v_g_249}), v_i_243});
        return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2410});
      }
    }
    default: return heff_nomatch(v_x9_247);
    }
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_x9_247);
    V v_t_2412 = ({ V a_0 = v_x_2411; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_n_244);
      heff_drop(v_t_2412);
      if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
        return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
      } else {
        V v_t_2413 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
        return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2413});
      }
    } else {
      heff_drop(v_t_2412);
      V v_t_2414 = ({ V a_0 = v_x_2411; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_n_244);
        heff_drop(v_t_2414);
        if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
          return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
        } else {
          V v_t_2415 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
          return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2415});
        }
      } else {
        heff_drop(v_t_2414);
        return heff_tag_n(TAG_RGetN, 3, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243, v_n_244});
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erefcount_2efieldIn_24s428448813x2033497539(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V v_ce_240, V v_x3_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 17);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CondTrue));
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 17);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CondFalse));
  }
  case TAG_PRel: {
    V v_p_244 = heff_field(v_x3_241, 0);
    V v_a_245 = heff_field(v_x3_241, 1);
    V v_b_246 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_244));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_sh_2410 = v_field_249;
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, NTAG(TAG_Nil), heff_get_n(v_sh_2410, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_t_2411})));
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_244, v_t_2412}));
      } else {
        heff_drop(v_field_249);
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
        V v_t_2414 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_t_2413})));
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondRel, 2, (V[]){v_p_244, v_t_2414}));
      }
    }
  }
  case TAG_PBool: {
    V v_v_2415 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_2415));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2416}));
  }
  case TAG_PNot: {
    V v_c_2417 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2418 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2419 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_ce_240;
    V t_1 = v_c_2417;
    V t_2 = v_cell_2418;
    V t_3 = MK_INT(0LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2420 = heff_field(v_x3_241, 0);
    V v_b_2421 = heff_field(v_x3_241, 1);
    V v_c_2422 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_a_2420));
    V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_b_2421));
    V v_cell_2425 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2423, v_t_2424, heff_hole()});
    V v_u_2426 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2425));
    heff_drop(v_u_2426);
    V t_0 = v_ce_240;
    V t_1 = v_c_2422;
    V t_2 = v_cell_2425;
    V t_3 = MK_INT(2LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PLet: {
    V v_x_2427 = heff_field(v_x3_241, 0);
    V v_o_2428 = heff_field(v_x3_241, 1);
    V v_c_2429 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_2430 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 10), v_x_2427));
    V v_t_2435;
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      V v_t_2434;
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2432;
        v_t_2434 = v_x_2433;
      } else {
        heff_drop(v_field_2432);
        v_t_2434 = NTAG(TAG_RepV);
      }
      v_t_2435 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2434, v_o_2428));
    }
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2427), heff_dup(heff_rfield(v_ce_240, 6))});
    V v_t_2437 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2436, heff_dup(v_ce_240)));
    V v_t_2438 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2437, v_c_2429));
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2427), NTAG(TAG_Nil)});
    V v_t_2445 = (g_list_2emap_24f408128283x2136699628(heff_clo_n(g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_lam0, 1, 1, (V[]){v_ce_240}), v_t_2439));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2427, v_t_2435, v_t_2438, v_t_2445}));
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_lam0(V self, V *args) {
  V v_x_2440 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2441 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2440; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2440); r_; });
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2442 == ((int64_t)0ULL)) ? ({ V v_x_2444 = heff_dup(v_field_2443); int c_ = 0; heff_drop(v_x_2444); c_; }) : 1));
    heff_drop(v_field_2443);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){heff_dup(v_c_241)}), NTAG(TAG_Nil)});
  HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
  V v_t_2413;
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_bs_248 = v_field_246;
    V v_ms_249 = v_field_247;
    V v_bs_2410 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_248));
    V v_ms_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_249));
    V v_t_2412 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2410; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_2410); r_; });
    v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_2411; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
  }
  V v_t_2416;
  switch (heff_tag_of(v_yes_242)) {
  case TAG_ATail: {
    V v_t_2414 = heff_field(v_yes_242, 0);
    v_t_2416 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2414)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2415 = heff_field(v_yes_242, 0);
    v_t_2416 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_2415)));
    break;
  }
  default: heff_nomatch(v_yes_242);
  }
  V v_t_2419;
  switch (heff_tag_of(v_no_243)) {
  case TAG_ATail: {
    V v_t_2417 = heff_field(v_no_243, 0);
    v_t_2419 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_2417)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2418 = heff_field(v_no_243, 0);
    v_t_2419 = (g_heff_2ecompile_2erefcount_2efvSts(heff_dup(v_ss_2418)));
    break;
  }
  default: heff_nomatch(v_no_243);
  }
  V v_t_2420 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2416, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2420));
  return (g_heff_2ecompile_2erefcount_2econdTestWith_24s1613593324x896883769(v_ce_240, v_c_241, v_yes_242, v_no_243, v_t_2421));
}
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ercDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ercDef_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ercDef(V v_facts_240, V v_reprs_241, V v_x3_242) {
top: ;
  V v_arity_243 = heff_take_field(v_facts_240, 0);
  V v_bounce_244 = heff_take_field(v_facts_240, 1);
  V v_lent_245 = heff_take_field(v_facts_240, 3);
  V v_workers_246 = heff_take_field(v_facts_240, 4);
  V v_flat_247 = heff_take_field(v_facts_240, 5);
  V v_sure_248 = heff_take_field(v_facts_240, 6);
  V v_sureRecs_249 = heff_take_field(v_facts_240, 7);
  V v_tokens_2410 = heff_get_n(v_facts_240, 10, 11);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkDef: {
    V v_key_2411 = heff_field(v_x3_242, 0);
    V v_x33_2413 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x33_2413)) {
    case TAG_DefFun: {
      V v_xs_2414 = heff_field(v_x33_2413, 0);
      V v_x332_2415 = heff_field(v_x33_2413, 1);
      switch (heff_tag_of(v_x332_2415)) {
      case TAG_MkBlock: {
        V v_t_2416 = heff_field(v_x332_2415, 0);
        V v_t_2417 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        return (g_heff_2ecompile_2erefcount_2efunRc(v_t_2417, heff_dup(v_key_2411), heff_dup(v_xs_2414), heff_dup(v_t_2416)));
      }
      default: return heff_nomatch(v_x332_2415);
      }
    }
    case TAG_DefVal: {
      V v_x331_2418 = heff_field(v_x33_2413, 0);
      switch (heff_tag_of(v_x331_2418)) {
      case TAG_MkBlock: {
        V v_t_2419 = heff_field(v_x331_2418, 0);
        V v_t_2420 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        HEFF_LAST return g_heff_2ecompile_2erefcount_2evalRc(v_t_2420, heff_dup(v_key_2411), heff_dup(v_t_2419));
      }
      default: return heff_nomatch(v_x331_2418);
      }
    }
    default: return heff_nomatch(v_x33_2413);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2ercDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ercDef(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1(V v_tok_240, V v_ce_241, V v_n_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_241, 17);
    heff_drop(v_n_242);
    V v_t_244 = heff_tag_at_n(v_tok_240, TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_243, 0);
    V v_vs_246 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    V v_t_247;
    if ((heff_intLt_c_lent(MK_INT(0LL), v_n_242, 1) && heff_intLe_c(heff_dup(v_n_242), heff_dup(heff_rfield(v_ce_241, 3))))) {
      heff_drop_rec(v_ce_241, 17);
      heff_drop(v_n_242);
      v_t_247 = heff_tag_n(TAG_CInPlace, 2, (V[]){v_f_245, v_vs_246});
    } else {
      if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_ce_241, 3))) && heff_intLe_c_lent(v_n_242, MK_INT(4LL), 2))) {
        heff_drop_rec(v_ce_241, 17);
        heff_drop(v_n_242);
        v_t_247 = heff_tag_n(TAG_CRoomed, 2, (V[]){v_f_245, v_vs_246});
      } else {
        heff_drop_rec(v_ce_241, 17);
        heff_drop(v_n_242);
        v_t_247 = heff_tag_n(TAG_CTail, 2, (V[]){v_f_245, v_vs_246});
      }
    }
    return heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eapplyLast_24tok1(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erefcount_2earmFound_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2earmFound_24tok3_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2earmFound_24tok3(V v_tok_240, V v_t_241, V v_vs_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_b_244 = heff_field(v_x3_243, 0);
    V v_x_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24MkPair = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x3_243_24MkPair, TAG_MkPair, 2, (V[]){v_b_244, heff_tag_at_n(v_tok_240, TAG_MkArm, 3, (V[]){v_t_241, v_vs_242, v_x_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2erefcount_2earmFound_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2earmFound_24tok3(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2efunRc_24tok2_str0, 0, "");
Clo g_heff_2ecompile_2erefcount_2efunRc_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efunRc_24tok2_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2efunRc_24tok2(V v_tok_240, V v_ce_241, V v_key_242, V v_xs_243, V v_b_244) {
top: ;
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_ce_241, 15)), 1, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_key_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_n_249 = v_field_248;
      switch (heff_tag_of(v_xs_243)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_n_249);
        return (g_heff_2ecompile_2erefcount_2efunPlain(v_ce_241, v_key_242, NTAG(TAG_Nil), v_b_244));
      }
      case TAG_Cons: {
        V v_tok_2410 = heff_field(v_xs_243, 0);
        V v_xs_2411 = heff_field(v_xs_243, 1);
        heff_take_n(v_xs_243, 3ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2ewithKnown(heff_dup(v_tok_2410), heff_tag_n(TAG_KnownCell, 1, (V[]){heff_dup(v_n_249)}), v_ce_241));
        HeffT2 v_t_2413 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(heff_dup(v_tok_2410), heff_rec_n(2, shape_n__tag, (V[]){v_n_249, ((V)&g_heff_2ecompile_2erefcount_2efunRc_24tok2_str0)}), v_b_244));
        V v_t_2418;
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          heff_drop(v_x_2416);
          V v_y_2417 = v_field_2415;
          v_t_2418 = v_y_2417;
        }
        return (g_heff_2ecompile_2erefcount_2efunPlain(v_t_2412, v_key_242, heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_tok_2410, v_xs_2411}), v_t_2418));
      }
      default: return heff_nomatch(v_xs_243);
      }
    } else {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_field_248);
      return (g_heff_2ecompile_2erefcount_2efunPlain(v_ce_241, v_key_242, v_xs_243, v_b_244));
    }
  }
}
V g_heff_2ecompile_2erefcount_2efunRc_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efunRc_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V v_tok_240, V v_ce_241, V v_x_242, V v_argv_243, V v_rest_244) {
top: ;
  V v_borrowed_245 = heff_take_field(v_ce_241, 6);
  V v_reprs_246 = heff_get_n(v_ce_241, 10, 17);
  switch (heff_tag_of(v_argv_243)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_rest_244);
    heff_drop(v_borrowed_245);
    heff_drop(v_reprs_246);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_247 = heff_field(v_argv_243, 0);
    V v_argv2_248 = heff_field(v_argv_243, 1);
    heff_take_n(v_argv_243, 3ULL, 2);
    switch (heff_tag_of(v_argv1_247)) {
    case TAG_SVar: {
      V v_a_249 = heff_field(v_argv1_247, 0);
      heff_take_n(v_argv1_247, 1ULL, 1);
      switch (heff_tag_of(v_argv2_248)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_rest_244);
        heff_drop(v_borrowed_245);
        heff_drop(v_reprs_246);
        heff_drop(v_a_249);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_2410 = heff_field(v_argv2_248, 0);
        V v_argv22_2411 = heff_field(v_argv2_248, 1);
        heff_take_n(v_argv2_248, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2411)) {
        case TAG_Nil: {
          V v_t_2412 = ({ V a_0 = v_a_249; V a_1 = v_borrowed_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_245); r_; });
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            HeffT2 v_t_2413 = ({ V a_0 = v_reprs_246; V a_1 = v_x_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_reprs_246); r_; });
            {
              V v_field_2415 = v_t_2413.f[1];
              int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
              if ((v_tag_2414 == ((int64_t)0ULL))) {
                V v_x_2416 = v_field_2415;
                switch (heff_tag_of(v_x_2416)) {
                case TAG_RepV: {
                  V v_t_2417 = (g_heff_2ecompile_2erefcount_2eintW(v_x_242, v_rest_244));
                  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                    heff_drop(v_t_2417);
                    return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                  } else {
                    heff_drop_cell(v_tok_240, 1);
                    heff_drop(v_a_249);
                    heff_drop(v_i_2410);
                    heff_drop(v_t_2417);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2416, 0ULL, 1);
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_rest_244);
                  heff_drop(v_a_249);
                  heff_drop(v_i_2410);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2416);
                }
              } else {
                heff_drop(v_field_2415);
                V v_t_2419 = (g_heff_2ecompile_2erefcount_2eintW(v_x_242, v_rest_244));
                if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                  heff_drop(v_t_2419);
                  return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_249, v_i_2410})});
                } else {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_a_249);
                  heff_drop(v_i_2410);
                  heff_drop(v_t_2419);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop_cell(v_tok_240, 1);
            heff_drop(v_rest_244);
            heff_drop(v_reprs_246);
            heff_drop(v_a_249);
            heff_drop(v_i_2410);
            heff_drop(v_t_2412);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2411, 0ULL, 2);
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_rest_244);
          heff_drop(v_borrowed_245);
          heff_drop(v_reprs_246);
          heff_drop(v_a_249);
          heff_drop(v_i_2410);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2411);
        }
      }
      default: return heff_nomatch(v_argv2_248);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_247, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_247, 0ULL, 3);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_247, 0ULL, 4);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_247, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_argv2_248);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_247);
    }
  }
  default: return heff_nomatch(v_argv_243);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2ereusedOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereusedOf_24tok1_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ereusedOf_24tok1(V v_tok_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_241, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x121_244)) {
      case TAG_SVar: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SInt: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SStr: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SBytes: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFixed: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        V v_argv_2419 = heff_field(v_x121_244, 1);
        switch (heff_tag_of(v_x122_245)) {
        case TAG_Nil: {
          V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2419));
          return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2421})});
        }
        case TAG_Cons: {
          heff_drop_cell(v_tok_240, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_245);
        }
      }
      case TAG_SRec: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_drop_cell(v_tok_240, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_244);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2erefcount_2ereusedOf_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ereusedOf_24tok1(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2evalRc_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalRc_24tok3_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2evalRc_24tok3(V v_tok_240, V v_ce_241, V v_key_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_243, NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_244));
  V v_t_246 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), MK_INT(0LL), v_t_246));
  V v_ce_248 = (g_heff_2ecompile_2erefcount_2ewithPath(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247));
  V v_t_249 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_248, v_t_243));
  return heff_tag_at_n(v_tok_240, TAG_DVal, 3, (V[]){v_key_242, v_t_249, heff_get_n(v_ce_241, 10, 17)});
}
V g_heff_2ecompile_2erefcount_2evalRc_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalRc_24tok3(a[0], a[1], a[2], a[3]);
}