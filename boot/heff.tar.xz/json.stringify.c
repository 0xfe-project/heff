// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
V g_json_2efloatText_2enumberTextFrom_240(V, V);
V g_json_2efloatText_2enumberTextFrom_240_entry(V self, V *a);
extern Clo g_json_2efloatText_2enumberTextFrom_240_clo;
V g_json_2ejoinInto_2erestInto_240(V, V, V, V);
V g_json_2ejoinInto_2erestInto_240_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_clo;
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str0, 4, "null");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str1, 4, "true");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str2, 5, "false");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str3, 4, "null");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str4, 1, "\"");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str5, 1, "\"");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str6, 1, "[");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str7, 1, ",");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str8, 1, "]");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str9, 1, "{");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str10, 1, "\"");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str11, 1, "\"");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str12, 1, ":");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str13, 1, ",");
HEFF_LIT(g_json_2estringify_2ewriteInto_240_str14, 1, "}");
Clo g_json_2estringify_2ewriteInto_240_clo = {{0x80000000u, K_CLO, 0}, g_json_2estringify_2ewriteInto_240_entry, 2, 0};

V g_json_2estringify_2ewriteInto_240(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_JNull: {
    return heff_strAppend(v_acc_240, ((V)&g_json_2estringify_2ewriteInto_240_str0));
  }
  case TAG_JBool: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_t_243;
    if ((heff_dup(v_b_242) == NTAG(TAG_True))) {
      v_t_243 = ((V)&g_json_2estringify_2ewriteInto_240_str1);
    } else {
      v_t_243 = ((V)&g_json_2estringify_2ewriteInto_240_str2);
    }
    return heff_strAppend(v_acc_240, v_t_243);
  }
  case TAG_JInt: {
    V v_i_244 = heff_field(v_x2_241, 0);
    return heff_strAppend(v_acc_240, heff_intShow(heff_dup(v_i_244)));
  }
  case TAG_JFloat: {
    double v_x_245 = heff_tflat_f64(v_x2_241, 0);
    V v_t_246;
    if (!((v_x_245 - v_x_245) == (0.0))) {
      v_t_246 = ((V)&g_json_2estringify_2ewriteInto_240_str3);
    } else {
      v_t_246 = (g_json_2efloatText_2enumberTextFrom_240(heff_floatShow(heff_box_f64(v_x_245)), MK_INT(0LL)));
    }
    return heff_strAppend(v_acc_240, v_t_246);
  }
  case TAG_JString: {
    V v_s_247 = heff_field(v_x2_241, 0);
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(heff_dup(v_s_247), heff_strAppend(v_acc_240, ((V)&g_json_2estringify_2ewriteInto_240_str4)), MK_INT(0LL)));
    return heff_strAppend(v_t_248, ((V)&g_json_2estringify_2ewriteInto_240_str5));
  }
  case TAG_JArray: {
    V v_xs_249 = heff_field(v_x2_241, 0);
    V v_acc_2410 = heff_strAppend(v_acc_240, ((V)&g_json_2estringify_2ewriteInto_240_str6));
    V v_t_2414;
    switch (heff_tag_of(v_xs_249)) {
    case TAG_Nil: {
      v_t_2414 = v_acc_2410;
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_xs_249, 0);
      V v_xs_2412 = heff_field(v_xs_249, 1);
      V v_t_2413 = (g_json_2estringify_2ewriteInto_240(v_acc_2410, v_x_2411));
      v_t_2414 = (g_json_2ejoinInto_2erestInto_240(((V)&g_json_2estringify_2ewriteInto_240_clo), ((V)&g_json_2estringify_2ewriteInto_240_str7), v_t_2413, v_xs_2412));
      break;
    }
    default: heff_nomatch(v_xs_249);
    }
    return heff_strAppend(v_t_2414, ((V)&g_json_2estringify_2ewriteInto_240_str8));
  }
  case TAG_JObject: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_acc_2416 = heff_strAppend(v_acc_240, ((V)&g_json_2estringify_2ewriteInto_240_str9));
    V v_t_2424;
    switch (heff_tag_of(v_fs_2415)) {
    case TAG_Nil: {
      v_t_2424 = v_acc_2416;
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_fs_2415, 0);
      V v_xs_2418 = heff_field(v_fs_2415, 1);
      V v_t_2423;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_MkPair: {
        V v_k_2419 = heff_field(v_x_2417, 0);
        V v_v_2420 = heff_field(v_x_2417, 1);
        V v_t_2421 = (g_json_2equotedInto_2eescapeInto_241(heff_dup(v_k_2419), heff_strAppend(v_acc_2416, ((V)&g_json_2estringify_2ewriteInto_240_str10)), MK_INT(0LL)));
        V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_json_2estringify_2ewriteInto_240_str11)), ((V)&g_json_2estringify_2ewriteInto_240_str12));
        v_t_2423 = (g_json_2estringify_2ewriteInto_240(v_t_2422, v_v_2420));
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      v_t_2424 = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(((V)&g_json_2estringify_2ewriteInto_240_str13), v_t_2423, v_xs_2418));
      break;
    }
    default: heff_nomatch(v_fs_2415);
    }
    return heff_strAppend(v_t_2424, ((V)&g_json_2estringify_2ewriteInto_240_str14));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_json_2estringify_2ewriteInto_240(a[0], a1); heff_drop(a1); return r;
}