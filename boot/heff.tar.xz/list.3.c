// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_Boxed 28180
#define TAG_CDrop 58400
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Many 40086
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_Rest 61983
#define TAG_SError 24172
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_Some 35657
#define TAG_Text 56194
#define TAG_Wants 58903
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_hash 9690581
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_library 398066429
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_version 583465758
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_module__code__msg[] = {LBL_module, LBL_code, LBL_msg};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2eglobalOfPart(V);
V g_heff_2ecompile_2eemit_2eglobalOfPart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalOfPart_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eall_24s107199714x217634386(V, V, V);
V g_list_2eall_24s107199714x217634386_entry(V self, V *a);
extern Clo g_list_2eall_24s107199714x217634386_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2eany_24s866339829x15734905(V, V, V, V);
V g_list_2eany_24s866339829x15734905_entry(V self, V *a);
extern Clo g_list_2eany_24s866339829x15734905_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1880530801x1683594418_24dps(V, V, V);
V g_list_2efilter_24s1880530801x1683594418_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1880530801x1683594418_24dps_clo;
V g_list_2efilter_24s2048945121x1749617505(V, V);
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_clo;
V g_list_2efilter_24s2048945121x1749617505_24dps(V, V, V);
V g_list_2efilter_24s2048945121x1749617505_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_24dps_clo;
V g_list_2efilter_24s2056490818x625949248(V, V);
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_clo;
V g_list_2efilter_24s2056490818x625949248_24dps(V, V, V);
V g_list_2efilter_24s2056490818x625949248_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_24dps_clo;
V g_list_2efoldl_24f1090240733x1330738919(V, V, V);
V g_list_2efoldl_24f1090240733x1330738919_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1090240733x1330738919_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f330817203x748281807(V, V, V, V);
V g_list_2efoldl_24f330817203x748281807_entry(V self, V *a);
extern Clo g_list_2efoldl_24f330817203x748281807_clo;
V g_list_2efoldl_24s1106937552x2116104854(V, V, V);
V g_list_2efoldl_24s1106937552x2116104854_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1106937552x2116104854_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1732572494x729779974(V, V);
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1732572494x729779974_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s29004368x870998936(V, V);
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a);
extern Clo g_list_2efoldl_24s29004368x870998936_clo;
V g_list_2efoldl_24s31530661x2067693293(V, V);
V g_list_2efoldl_24s31530661x2067693293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s31530661x2067693293_clo;
V g_list_2efoldl_24s407249128x802036125(V, V);
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s407249128x802036125_clo;
V g_list_2efoldl_24s432565707x521643915(V, V);
V g_list_2efoldl_24s432565707x521643915_entry(V self, V *a);
extern Clo g_list_2efoldl_24s432565707x521643915_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s516752187x192962254(V, V, V, V);
V g_list_2efoldl_24s516752187x192962254_entry(V self, V *a);
extern Clo g_list_2efoldl_24s516752187x192962254_clo;
V g_list_2efoldl_24s589588949x194367275(V, V, V);
V g_list_2efoldl_24s589588949x194367275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s589588949x194367275_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s787927001x2102341300(V, V);
V g_list_2efoldl_24s787927001x2102341300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s787927001x2102341300_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1156519715x726760149(V);
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_clo;
V g_list_2emap_24f1156519715x726760149_24dps(V, V);
V g_list_2emap_24f1156519715x726760149_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_24dps_clo;
V g_list_2emap_24f1548644028x2098102081(V, V);
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_clo;
V g_list_2emap_24f1548644028x2098102081_24dps(V, V, V);
V g_list_2emap_24f1548644028x2098102081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_24dps_clo;
V g_list_2emap_24f1649958057x1967137941(V, V, V);
V g_list_2emap_24f1649958057x1967137941_entry(V self, V *a);
extern Clo g_list_2emap_24f1649958057x1967137941_clo;
V g_list_2emap_24f1649958057x1967137941_24dps(V, V, V, V);
V g_list_2emap_24f1649958057x1967137941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1649958057x1967137941_24dps_clo;
V g_list_2emap_24f1801471045x554404499(V, V, V, V);
V g_list_2emap_24f1801471045x554404499_entry(V self, V *a);
extern Clo g_list_2emap_24f1801471045x554404499_clo;
V g_list_2emap_24f1801471045x554404499_24dps(V, V, V, V, V);
V g_list_2emap_24f1801471045x554404499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1801471045x554404499_24dps_clo;
V g_list_2emap_24f403129162x387433139_24dps(V, V, V, V, V);
V g_list_2emap_24f403129162x387433139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f403129162x387433139_24dps_clo;
V g_list_2emap_24f88106788x1680212182(V);
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_clo;
V g_list_2emap_24f88106788x1680212182_24dps(V, V);
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_24dps_clo;
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps(V, V, V, V);
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_clo;
V g_list_2emap_24s1049333826x1545174117(V, V, V);
V g_list_2emap_24s1049333826x1545174117_entry(V self, V *a);
extern Clo g_list_2emap_24s1049333826x1545174117_clo;
V g_list_2emap_24s1049333826x1545174117_24dps(V, V, V, V);
V g_list_2emap_24s1049333826x1545174117_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1049333826x1545174117_24dps_clo;
V g_list_2emap_24s1150457979x1978067071_24dps(V, V);
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_24dps_clo;
V g_list_2emap_24s1165563338x395196550(V, V, V, V);
V g_list_2emap_24s1165563338x395196550_entry(V self, V *a);
extern Clo g_list_2emap_24s1165563338x395196550_clo;
V g_list_2emap_24s1165563338x395196550_24dps(V, V, V, V, V);
V g_list_2emap_24s1165563338x395196550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1165563338x395196550_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1234524601x742515152_24dps(V, V);
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_24dps_clo;
V g_list_2emap_24s1270156656x1320515496_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1270156656x1320515496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1270156656x1320515496_24dps_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s129316455x2072694707_24dps(V, V);
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_24dps_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1455783996x1449538216(V);
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_clo;
V g_list_2emap_24s1455783996x1449538216_24dps(V, V);
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_24dps_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1785262601x1752264566(V, V, V, V);
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a);
extern Clo g_list_2emap_24s1785262601x1752264566_clo;
V g_list_2emap_24s1785262601x1752264566_24dps(V, V, V, V, V);
V g_list_2emap_24s1785262601x1752264566_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1785262601x1752264566_24dps_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1842320150x747311840_24dps(V, V);
V g_list_2emap_24s1842320150x747311840_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1842320150x747311840_24dps_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s1898144261x1783169347_24dps(V, V);
V g_list_2emap_24s1898144261x1783169347_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1898144261x1783169347_24dps_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s1901363476x1479927424_24dps(V, V);
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_24dps_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2081626528x1476576812_24dps(V, V);
V g_list_2emap_24s2081626528x1476576812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_24dps_clo;
V g_list_2emap_24s272272626x1430728348(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s272272626x1430728348_entry(V self, V *a);
extern Clo g_list_2emap_24s272272626x1430728348_clo;
V g_list_2emap_24s272272626x1430728348_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s272272626x1430728348_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272272626x1430728348_24dps_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s422923909x1655406376(V);
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_clo;
V g_list_2emap_24s422923909x1655406376_24dps(V, V);
V g_list_2emap_24s422923909x1655406376_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_24dps_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s499977176x606563528_24dps(V, V, V, V);
V g_list_2emap_24s499977176x606563528_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_24dps_clo;
V g_list_2emap_24s520719551x1264915833_24dps(V, V);
V g_list_2emap_24s520719551x1264915833_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s520719551x1264915833_24dps_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2emap_24s890213172x1049425163_24dps(V, V);
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_24dps_clo;
V g_list_2emap_24s914137198x2013970988_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s914137198x2013970988_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s914137198x2013970988_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1037857700x2096250953(V, V);
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s509014022x1733915733(V, V);
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_clo;
V g_list_2emerge_24s509014022x1733915733_24dps(V, V, V);
V g_list_2emerge_24s509014022x1733915733_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_24dps_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s212505720x1447378304_24dps(V, V, V);
V g_list_2ezipWith_24s212505720x1447378304_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s212505720x1447378304_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_244 = (g_list_2ereplicate_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_entry, 2, 0};

V g_list_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = (g_list_2etake(heff_intDiv(v_t_246, MK_INT(2LL)), heff_dup(v_xs_241)));
      V v_t_248 = (g_list_2esortBy(heff_dup(v_le_240), v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2410 = (g_list_2edrop(heff_intDiv(v_t_249, MK_INT(2LL)), v_xs_241));
      V v_t_2411 = (g_list_2esortBy(heff_dup(v_le_240), v_t_2410));
      return (g_list_2emerge(v_le_240, v_t_248, v_t_2411));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy(a[0], a[1]);
}
Clo g_list_2emap_24s1173914895x100384474_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_24dps_entry, 2, 0};

V g_list_2emap_24s1173914895x100384474_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s584454411x1006678865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_entry, 1, 0};

V g_list_2emap_24s584454411x1006678865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s584454411x1006678865_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865(a[0]);
}
Clo g_list_2efilter_24s2056490818x625949248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2056490818x625949248_entry, 2, 0};

V g_list_2efilter_24s2056490818x625949248(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength(heff_dup(v_x_242)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s2056490818x625949248_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2056490818x625949248(a[0], a[1]);
}
Clo g_list_2esortBy_24s88152486x2058486153_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s88152486x2058486153_entry, 1, 0};

V g_list_2esortBy_24s88152486x2058486153(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s88152486x2058486153(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s88152486x2058486153(v_t_249));
      return (g_list_2emerge_24s1347843181x1368204458(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s88152486x2058486153(a[0]);
}
HEFF_LIT(g_list_2emap_24s1898144261x1783169347_24dps_str0, 0, "");
Clo g_list_2emap_24s1898144261x1783169347_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1898144261x1783169347_24dps_entry, 2, 0};

V g_list_2emap_24s1898144261x1783169347_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_x_242, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_242}), ((V)&g_list_2emap_24s1898144261x1783169347_24dps_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1898144261x1783169347_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1898144261x1783169347_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s520719551x1264915833_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s520719551x1264915833_24dps_entry, 2, 0};

V g_list_2emap_24s520719551x1264915833_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_x_242, 0), heff_take_field(v_x_242, 1), NTAG(TAG_Nothing), heff_get_n(v_x_242, 2, 3), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s520719551x1264915833_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s520719551x1264915833_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2081626528x1476576812_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081626528x1476576812_24dps_entry, 2, 0};

V g_list_2emap_24s2081626528x1476576812_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081626528x1476576812_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081626528x1476576812_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1150457979x1978067071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_24dps_entry, 2, 0};

V g_list_2emap_24s1150457979x1978067071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgExplicit = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2410});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2411 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgProject = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x_242_24At, TAG_ArgNamed, 2, (V[]){v_a_2412, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s366989016x166432442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_24dps_entry, 2, 0};

V g_list_2emap_24s366989016x166432442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24x_242_24At, TAG_SetPath, 2, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s474585387x1072098790_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_24dps_entry, 2, 0};

V g_list_2emap_24s474585387x1072098790_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ExplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_a_2414 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ImplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2417;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_At: {
          V v_a_2415 = heff_field(v_a_2414, 0);
          V v_a_2416 = heff_field(v_a_2414, 1);
          heff_take_n(v_a_2414, 3ULL, 2);
          v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2416, v_a_2415));
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2412, v_a_2413, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1624059865x1140896478_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_24dps_entry, 2, 0};

V g_list_2emap_24s1624059865x1140896478_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2esurface_2easNameE(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s589588949x194367275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s589588949x194367275_entry, 3, 0};

V g_list_2efoldl_24s589588949x194367275(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_a_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_a_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_nf(v_a_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s589588949x194367275_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s589588949x194367275(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s338694954x1326523169_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_entry, 1, 0};

V g_list_2emap_24s338694954x1326523169(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get_n(v_x_241, 2, 3), v_t_243, NTAG(TAG_Nothing)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s338694954x1326523169_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169(a[0]);
}
Clo g_list_2emap_24s60612435x257154841_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_24dps_entry, 2, 0};

V g_list_2emap_24s60612435x257154841_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s432565707x521643915_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s432565707x521643915_entry, 2, 0};

V g_list_2efoldl_24s432565707x521643915(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s432565707x521643915_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s432565707x521643915(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s29004368x870998936_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s29004368x870998936_entry, 2, 0};

V g_list_2efoldl_24s29004368x870998936(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Wants, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_RepV)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_245});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s29004368x870998936(a[0], a[1]);
}
Clo g_list_2efoldl_24s657006386x1833506039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s657006386x1833506039_entry, 2, 0};

V g_list_2efoldl_24s657006386x1833506039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s657006386x1833506039(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s445268946x679229867_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s445268946x679229867_entry, 2, 0};

V g_list_2efoldl_24s445268946x679229867(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecallarity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s445268946x679229867(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_entry, 1, 0};

V g_list_2emap_24s1181937096x2120532116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_x_241), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1181937096x2120532116_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1181937096x2120532116_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116(a[0]);
}
Clo g_list_2emap_24s272272626x1430728348_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272272626x1430728348_entry, 11, 0};

V g_list_2emap_24s272272626x1430728348(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      heff_take_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2413, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)));
      v_t_2422 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, v_t_2421));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s272272626x1430728348_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s272272626x1430728348_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s272272626x1430728348(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2efoldl_24s978059622x523571930_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s978059622x523571930_entry, 2, 0};

V g_list_2efoldl_24s978059622x523571930(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s978059622x523571930(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1049333826x1545174117_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1049333826x1545174117_entry, 3, 0};

V g_list_2emap_24s1049333826x1545174117(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 6);
    V v_t_246 = heff_tr(heff_call(v_t_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_247 = heff_get_n(heff_get_n(v_x_243, 0, 3), 1, 6);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_247, heff_dup(v_lit_241)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, v_t_248), heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1049333826x1545174117_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1049333826x1545174117_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1049333826x1545174117(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1990719097x1419059608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_24dps_entry, 2, 0};

V g_list_2emap_24s1990719097x1419059608_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(v_x_242, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s738847920x410598254_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_entry, 2, 0};

V g_list_2ezipWith_24s738847920x410598254(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), heff_hole()});
      V v_u_2415 = (g_list_2ezipWith_24s738847920x410598254_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254(a[0], a[1]);
}
Clo g_list_2emap_24s1842320150x747311840_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1842320150x747311840_24dps_entry, 2, 0};

V g_list_2emap_24s1842320150x747311840_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_a_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_246, 0);
      heff_take_n(v_a_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1842320150x747311840_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1842320150x747311840_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1901363476x1479927424_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1901363476x1479927424_entry, 1, 0};

V g_list_2emap_24s1901363476x1479927424(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkDrop, 2, (V[]){v_x_241, NTAG(TAG_Nothing)});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_t_243}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1901363476x1479927424_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1901363476x1479927424(a[0]);
}
Clo g_list_2ezipWith_24s212505720x1447378304_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s212505720x1447378304_24dps_entry, 3, 0};

V g_list_2ezipWith_24s212505720x1447378304_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24xs_240_24Cons, 2);
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        v_t_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepF64: {
        v_t_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_249;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s212505720x1447378304_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s212505720x1447378304_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1651310864x859456474_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1651310864x859456474_entry, 2, 0};

V g_list_2efoldl_24s1651310864x859456474(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1651310864x859456474(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s31530661x2067693293_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s31530661x2067693293_entry, 2, 0};

V g_list_2efoldl_24s31530661x2067693293(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s31530661x2067693293_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s31530661x2067693293(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s499977176x606563528_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499977176x606563528_entry, 3, 0};

V g_list_2emap_24s499977176x606563528(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s499977176x606563528_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s499977176x606563528_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499977176x606563528(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1270156656x1320515496_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1270156656x1320515496_24dps_entry, 9, 0};

V g_list_2emap_24s1270156656x1320515496_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return heff_setField(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_x_249), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2411));
    V v_a_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_a_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      v_a_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2413});
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_a_2417;
    switch (heff_tag_of(v_a_2415)) {
    case TAG_Nothing: {
      v_a_2417 = v_x_249;
      break;
    }
    case TAG_Just: {
      V v_a_2416 = heff_field(v_a_2415, 0);
      heff_take_n(v_a_2415, 1ULL, 1);
      heff_drop(v_x_249);
      v_a_2417 = v_a_2416;
      break;
    }
    default: heff_nomatch(v_a_2415);
    }
    V v_t_2418 = heff_intSub(heff_strLength(heff_dup(v_a_2417)), heff_dup(v_lit_242));
    V v_t_2419 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_a_2417), v_t_2418));
    V v_t_2420 = (g_heff_2ecompile_2eemit_2espellAt(v_a_2417, v_t_2419));
    V v_a_2421 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2420, heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2423;
    if (heff_strEq_c(heff_dup(v_a_2421), heff_dup(v_lit_245))) {
      heff_drop(v_a_2421);
      v_t_2423 = heff_dup(v_lit_246);
    } else {
      v_t_2423 = v_a_2421;
    }
    V v_t_2424 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2423));
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = heff_setField(v_d_248, MK_INT(1LL), heff_dup(v_cell_2425));
    heff_drop(v_u_2426);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_cell_2425;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1270156656x1320515496_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1270156656x1320515496_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1455783996x1449538216_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_entry, 1, 0};

V g_list_2emap_24s1455783996x1449538216(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2eglobalOfPart(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1455783996x1449538216_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1455783996x1449538216(a[0]);
}
Clo g_list_2emap_24s1455783996x1449538216_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_24dps_entry, 2, 0};

V g_list_2emap_24s1455783996x1449538216_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eglobalOfPart(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1455783996x1449538216_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s732475005x1616712052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_entry, 1, 0};

V g_list_2emap_24s732475005x1616712052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2eexportNameOf(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s732475005x1616712052_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052(a[0]);
}
Clo g_list_2eany_24s651308273x925219243_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s651308273x925219243_entry, 1, 0};

V g_list_2eany_24s651308273x925219243(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s651308273x925219243_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s651308273x925219243(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s129316455x2072694707_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_entry, 1, 0};

V g_list_2emap_24s129316455x2072694707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s129316455x2072694707_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707(a[0]);
}
Clo g_list_2emap_24s129316455x2072694707_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_24dps_entry, 2, 0};

V g_list_2emap_24s129316455x2072694707_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_244), v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_24dps_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_24dps_entry, 2, 0};

V g_list_2emap_24s420582357x1720502382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s420582357x1720502382_24dps_str0)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1785262601x1752264566_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1785262601x1752264566_entry, 4, 0};

V g_list_2emap_24s1785262601x1752264566(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_x_244)), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_intShow(v_x_244), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s1785262601x1752264566_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1785262601x1752264566(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s2073083146x1445066245_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_24dps_entry, 2, 0};

V g_list_2emap_24s2073083146x1445066245_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1732572494x729779974_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1732572494x729779974_entry, 2, 0};

V g_list_2efoldl_24s1732572494x729779974(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_a_244, 2)));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_a_244, 0, 3), v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1732572494x729779974(a[0], a[1]);
}
Clo g_list_2emap_24s1817208647x1282894070_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_entry, 1, 0};

V g_list_2emap_24s1817208647x1282894070(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1817208647x1282894070_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817208647x1282894070(a[0]);
}
Clo g_list_2efoldl_24s787927001x2102341300_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s787927001x2102341300_entry, 2, 0};

V g_list_2efoldl_24s787927001x2102341300(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 5)), heff_dup(heff_rfield(v_x_242, 3))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 4), v_t_244));
    V v_t_246 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s787927001x2102341300_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s787927001x2102341300(a[0], a[1]);
}
Clo g_list_2efoldl_24s407249128x802036125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s407249128x802036125_entry, 2, 0};

V g_list_2efoldl_24s407249128x802036125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s407249128x802036125(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1895313378x47656836_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_entry, 1, 0};

V g_list_2emap_24s1895313378x47656836(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1895313378x47656836_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836(a[0]);
}
Clo g_list_2efilter_24s2048945121x1749617505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2048945121x1749617505_entry, 2, 0};

V g_list_2efilter_24s2048945121x1749617505(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s2048945121x1749617505_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2048945121x1749617505(a[0], a[1]);
}
Clo g_list_2efoldl_24s516752187x192962254_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s516752187x192962254_entry, 4, 0};

V g_list_2efoldl_24s516752187x192962254(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = heff_take_field(v_x_244, 0);
    V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
    V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_a_246));
    V v_a_249 = heff_get_n(v_x_244, 1, 2);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(heff_dup(v_lit_241), v_a_249));
    V v_t_2412 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2412}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s516752187x192962254_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s516752187x192962254(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str0, 1, "\012");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str1, 0, "");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str2, 0, "");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str3, 1, " ");
Clo g_list_2emap_24s422923909x1655406376_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s422923909x1655406376_entry, 1, 0};

V g_list_2emap_24s422923909x1655406376(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s422923909x1655406376_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s422923909x1655406376_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s422923909x1655406376_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag_n(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_248, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_list_2emap_24s422923909x1655406376_str3)})));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s422923909x1655406376_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s422923909x1655406376(a[0]);
}
Clo g_list_2eall_24s107199714x217634386_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s107199714x217634386_entry, 3, 0};

V g_list_2eall_24s107199714x217634386(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_243))) {
      if (heff_intLe_c(heff_dup(v_x_243), heff_dup(v_lit_241))) {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s107199714x217634386_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s107199714x217634386(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s890213172x1049425163_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_entry, 1, 0};

V g_list_2emap_24s890213172x1049425163(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s890213172x1049425163_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163(a[0]);
}
Clo g_list_2emap_24s890213172x1049425163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_24dps_entry, 2, 0};

V g_list_2emap_24s890213172x1049425163_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1165563338x395196550_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1165563338x395196550_entry, 4, 0};

V g_list_2emap_24s1165563338x395196550(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 2), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_take_field(v_x_244, 1), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_t_248 = heff_strAppend(heff_get_n(v_x_244, 0, 3), heff_strAppend(heff_dup(v_lit_240), v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s1165563338x395196550_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1165563338x395196550_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1165563338x395196550(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s435407392x1528135477_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_entry, 1, 0};

V g_list_2emap_24s435407392x1528135477(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s435407392x1528135477_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477(a[0]);
}
Clo g_list_2emerge_24s509014022x1733915733_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s509014022x1733915733_entry, 2, 0};

V g_list_2emerge_24s509014022x1733915733(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s509014022x1733915733_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s509014022x1733915733_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s509014022x1733915733(a[0], a[1]);
}
Clo g_list_2esortBy_24s1681607803x465385494_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1681607803x465385494_entry, 1, 0};

V g_list_2esortBy_24s1681607803x465385494(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1681607803x465385494(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1681607803x465385494(v_t_249));
      return (g_list_2emerge_24s1037857700x2096250953(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1681607803x465385494(a[0]);
}
Clo g_list_2emap_24s388004800x1261967008_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_24dps_entry, 2, 0};

V g_list_2emap_24s388004800x1261967008_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1106937552x2116104854_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1106937552x2116104854_entry, 3, 0};

V g_list_2efoldl_24s1106937552x2116104854(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 5);
        v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_a_247, heff_dup(v_lit_240), v_a_248}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_a_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1106937552x2116104854_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1106937552x2116104854(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1975553568x1034350329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1975553568x1034350329_entry, 2, 0};

V g_list_2efoldl_24s1975553568x1034350329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1975553568x1034350329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1880530801x1683594418_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1880530801x1683594418_24dps_entry, 3, 0};

V g_list_2efilter_24s1880530801x1683594418_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1880530801x1683594418_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1880530801x1683594418_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1234524601x742515152_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1234524601x742515152_24dps_entry, 2, 0};

V g_list_2emap_24s1234524601x742515152_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1234524601x742515152_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1420651609x666245096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_24dps_entry, 2, 0};

V g_list_2emap_24s1420651609x666245096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_242});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s914137198x2013970988_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s914137198x2013970988_24dps_entry, 7, 0};

V g_list_2emap_24s914137198x2013970988_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_a_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = (g_heff_2eutil_2ejson_2eescapeGo(v_a_2411, heff_dup(v_lit_241), heff_dup(v_lit_242)));
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
    V v_t_2416;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_244), v_t_2417));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s914137198x2013970988_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s914137198x2013970988_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str0, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str1, 6, "detail");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str2, 5, "label");
Clo g_list_2emap_24s4199228x1154005405_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_entry, 1, 0};

V g_list_2emap_24s4199228x1154005405(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_241, 0)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_241, 1, 2)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str2), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_247}), heff_hole()});
    V v_u_249 = (g_list_2emap_24s4199228x1154005405_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405(a[0]);
}
Clo g_list_2eany_24s866339829x15734905_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s866339829x15734905_entry, 4, 0};

V g_list_2eany_24s866339829x15734905(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (heff_intLt_c(heff_dup(v_lit_240), v_t_246)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_xs_245;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_x2_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s866339829x15734905_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s866339829x15734905(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_entry, 1, 0};

V g_list_2emap_24s2029999044x514618413(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_243 = heff_take_field(v_x_241, 0);
    V v_t_244 = heff_get_n(v_x_241, 1, 3);
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      v_t_245 = v_m_243;
      break;
    }
    case TAG_Optional: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str0), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str1)));
      break;
    }
    case TAG_Many: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str2), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str3)));
      break;
    }
    case TAG_Some: {
      v_t_245 = heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str4));
      break;
    }
    case TAG_Rest: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str5), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str6)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s2029999044x514618413_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413(a[0]);
}
Clo g_list_2emap_24f88106788x1680212182_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f88106788x1680212182_entry, 1, 0};

V g_list_2emap_24f88106788x1680212182(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_x_241, 3);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), heff_hole()});
      V v_u_245 = (g_list_2emap_24f88106788x1680212182_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f88106788x1680212182(a[0]);
}
Clo g_list_2efoldl_24f330817203x748281807_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f330817203x748281807_entry, 4, 0};

V g_list_2efoldl_24f330817203x748281807(V v_z_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_244, 1);
      v_a_248 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_x_249 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_a_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_a_248); r_; });
    V t_0 = heff_intAdd(v_z_240, v_x_249);
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_245;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f330817203x748281807_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f330817203x748281807(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1090240733x1330738919_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1090240733x1330738919_entry, 3, 0};

V g_list_2efoldl_24f1090240733x1330738919(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_dup(v_x_243) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1090240733x1330738919_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1090240733x1330738919(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1548644028x2098102081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1548644028x2098102081_entry, 2, 0};

V g_list_2emap_24f1548644028x2098102081(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkDrop, 2, (V[]){v_x_242, NTAG(TAG_Nothing)});
      V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1548644028x2098102081_24dps(v_p_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1548644028x2098102081(a[0], a[1]);
}
Clo g_list_2emap_24f1801471045x554404499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1801471045x554404499_entry, 4, 0};

V g_list_2emap_24f1801471045x554404499(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_243), heff_dup(v_a_242))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_245 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24f1801471045x554404499_24dps(v_lit_240, v_lit_241, heff_intAdd(v_a_242, MK_INT(1LL)), v_b_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
}
V g_list_2emap_24f1801471045x554404499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1801471045x554404499(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1801471045x554404499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1801471045x554404499_24dps_entry, 5, 0};

V g_list_2emap_24f1801471045x554404499_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_243), heff_dup(v_a_242))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f1801471045x554404499_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1801471045x554404499_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f1649958057x1967137941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1649958057x1967137941_entry, 3, 0};

V g_list_2emap_24f1649958057x1967137941(V v_f_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_f_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_i_241)}));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f1649958057x1967137941_24dps(v_f_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_n_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f1649958057x1967137941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1649958057x1967137941(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1156519715x726760149_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1156519715x726760149_entry, 1, 0};

V g_list_2emap_24f1156519715x726760149(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_241, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
      V v_u_245 = (g_list_2emap_24f1156519715x726760149_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1156519715x726760149(a[0]);
}
Clo g_list_2emap_24f1156519715x726760149_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1156519715x726760149_24dps_entry, 2, 0};

V g_list_2emap_24f1156519715x726760149_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1156519715x726760149_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1156519715x726760149_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f1488358745x465096512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1488358745x465096512_entry, 2, 0};

V g_list_2efoldl_24f1488358745x465096512(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_r_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        V v_sp_2424 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 5);
        V v_x_2428 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2428, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2429 = heff_field(v_x111_2418, 0);
        V v_sp_2430 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 4);
        V v_x_2433 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_sp_2430, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2433, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1488358745x465096512(a[0], a[1]);
}
Clo g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_entry, 4, 0};

V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps(V v_lit_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_take_field(v_x_244, 2);
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x_247 = heff_get_n(v_x_244, 0, 4);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_247)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_247, heff_dup(v_lit_240)), heff_hole()});
        V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_p_241;
        V t_2 = v_xs_245;
        V t_3 = v_cell_249;
        v_lit_240 = t_0;
        v_p_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        heff_drop(v_x_247);
        heff_drop(v_t_248);
        V t_0 = v_lit_240;
        V t_1 = v_p_241;
        V t_2 = v_xs_245;
        V t_3 = v_d_243;
        v_lit_240 = t_0;
        v_p_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_244, 4);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f935318736x1254281698_24f812639102x862288937_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24f403129162x387433139_24dps_str0, 8, "browser.");
Clo g_list_2emap_24f403129162x387433139_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f403129162x387433139_24dps_entry, 5, 0};

V g_list_2emap_24f403129162x387433139_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_take_field(v_x_245, 6);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strSlice(heff_dup(heff_rfield(v_x_245, 0)), MK_INT(0LL), MK_INT(8LL));
      if (heff_strEq_c(v_t_248, ((V)&g_list_2emap_24f403129162x387433139_24dps_str0))) {
        V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242));
        V v_t_2411 = heff_rec_n(3, shape_module__code__msg, (V[]){heff_get_n(v_x_245, 0, 7), heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2410)});
        V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
        V v_u_2413 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2412;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_rec(v_x_245, 7);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f403129162x387433139_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f403129162x387433139_24dps(a[0], a[1], a[2], a[3], a[4]);
}