// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_Inverse 25398
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_SetPath 11095
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_absolute 325777132
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_by 9918
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_hidden 729654485
#define LBL_id 10114
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_size 10026184
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unexposed 2027212082
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_unexposed, LBL_instances};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2edriver_2ewithUnexposedOpen(V, V);
V g_heff_2ebuild_2edriver_2ewithUnexposedOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithUnexposedOpen_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ecompile_2ecpr_2elayTag(V, V);
V g_heff_2ecompile_2ecpr_2elayTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayTag_clo;
V g_heff_2ecompile_2ecycles_2elastCalls(V, V);
V g_heff_2ecompile_2ecycles_2elastCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2elastCalls_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eglue_2eglueOf(V, V, V);
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eglueOf_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eranges_2eabsorbOne(V, V);
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
V g_heff_2ecompile_2erepr_2ereprOfName(V);
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprOfName_clo;
V g_heff_2ecompile_2escalars_2eslotFor(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotFor_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(V);
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2eany_24s1081981235x855852216(V, V);
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a);
extern Clo g_list_2eany_24s1081981235x855852216_clo;
V g_list_2eany_24s150647489x375460461(V, V);
V g_list_2eany_24s150647489x375460461_entry(V self, V *a);
extern Clo g_list_2eany_24s150647489x375460461_clo;
V g_list_2eany_24s1681212806x1534785672(V, V, V);
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a);
extern Clo g_list_2eany_24s1681212806x1534785672_clo;
V g_list_2eany_24s2002848564x1372628513(V, V);
V g_list_2eany_24s2002848564x1372628513_entry(V self, V *a);
extern Clo g_list_2eany_24s2002848564x1372628513_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1351460748x1231260144(V, V);
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_clo;
V g_list_2efilter_24s1351460748x1231260144_24dps(V, V, V);
V g_list_2efilter_24s1351460748x1231260144_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_24dps_clo;
V g_list_2efilter_24s1535080205x545126304(V, V, V, V);
V g_list_2efilter_24s1535080205x545126304_entry(V self, V *a);
extern Clo g_list_2efilter_24s1535080205x545126304_clo;
V g_list_2efilter_24s1535080205x545126304_24dps(V, V, V, V, V);
V g_list_2efilter_24s1535080205x545126304_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1535080205x545126304_24dps_clo;
V g_list_2efilter_24s716173495x680820632(V, V);
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_clo;
V g_list_2efilter_24s716173495x680820632_24dps(V, V, V);
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_24dps_clo;
HeffT2 g_list_2efind_24s1303721783x1302064695_24cpr(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_list_2efind_24s1983706162x228765702_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1128388138x103163567(V, V, V, V);
V g_list_2efoldl_24f1128388138x103163567_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1128388138x103163567_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24f765463553x1160475073(V, V, V, V, V, V, V);
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a);
extern Clo g_list_2efoldl_24f765463553x1160475073_clo;
V g_list_2efoldl_24s1111588856x1684976655(V, V);
V g_list_2efoldl_24s1111588856x1684976655_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1111588856x1684976655_clo;
V g_list_2efoldl_24s1122556128x1089664899(V, V);
V g_list_2efoldl_24s1122556128x1089664899_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1122556128x1089664899_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1406601474x338829258(V, V);
V g_list_2efoldl_24s1406601474x338829258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1406601474x338829258_clo;
V g_list_2efoldl_24s1431636639x1417377628(V, V);
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1431636639x1417377628_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s1732572494x729779974(V, V);
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1732572494x729779974_clo;
V g_list_2efoldl_24s1810151735x2071939409(V, V);
V g_list_2efoldl_24s1810151735x2071939409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810151735x2071939409_clo;
V g_list_2efoldl_24s2092021924x904081891(V, V);
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092021924x904081891_clo;
V g_list_2efoldl_24s405709498x1837254440(V, V);
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s405709498x1837254440_clo;
V g_list_2efoldl_24s497871705x469972998(V, V);
V g_list_2efoldl_24s497871705x469972998_entry(V self, V *a);
extern Clo g_list_2efoldl_24s497871705x469972998_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s762187723x368876092(V, V);
V g_list_2efoldl_24s762187723x368876092_entry(V self, V *a);
extern Clo g_list_2efoldl_24s762187723x368876092_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2efoldr(V, V, V);
V g_list_2efoldr_entry(V self, V *a);
extern Clo g_list_2efoldr_clo;
V g_list_2emap_24f1156519715x726760149(V);
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_clo;
V g_list_2emap_24f1156519715x726760149_24dps(V, V);
V g_list_2emap_24f1156519715x726760149_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_24dps_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24f1293205645x619162872_24dps(V, V, V, V, V);
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_24dps_clo;
V g_list_2emap_24f130772758x674845987_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24dps_clo;
V g_list_2emap_24f88106788x1680212182(V);
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_clo;
V g_list_2emap_24f88106788x1680212182_24dps(V, V);
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_24dps_clo;
V g_list_2emap_24f990982947x2126256822_24dps(V, V, V);
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_24dps_clo;
V g_list_2emap_24s1105764576x1671327425_24dps(V, V, V, V);
V g_list_2emap_24s1105764576x1671327425_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1105764576x1671327425_24dps_clo;
V g_list_2emap_24s1134745827x519521524(V);
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_clo;
V g_list_2emap_24s1134745827x519521524_24dps(V, V);
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_24dps_clo;
V g_list_2emap_24s1150457979x1978067071_24dps(V, V);
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_24dps_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1234524601x742515152_24dps(V, V);
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_24dps_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1492759219x1917596721_24dps(V, V, V);
V g_list_2emap_24s1492759219x1917596721_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1492759219x1917596721_24dps_clo;
V g_list_2emap_24s1512999845x472671375_24dps(V, V, V, V, V, V);
V g_list_2emap_24s1512999845x472671375_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512999845x472671375_24dps_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s164225955x66209884_24dps(V, V, V, V);
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_24dps_clo;
V g_list_2emap_24s1690674600x556093466(V);
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s1936967306x1304226505_24dps(V, V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_24dps_clo;
V g_list_2emap_24s2010608108x1221393166_24dps(V, V);
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_24dps_clo;
V g_list_2emap_24s2016443462x370533815_24dps(V, V);
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_24dps_clo;
V g_list_2emap_24s2051429168x672290949_24dps(V, V);
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_24dps_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s354283597x484250159_24dps(V, V, V);
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_24dps_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s857425298x1024652640(V);
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_clo;
V g_list_2emap_24s857425298x1024652640_24dps(V, V);
V g_list_2emap_24s857425298x1024652640_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_24dps_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2emap_24s890213172x1049425163_24dps(V, V);
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_24dps_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24s942566919x1152393003_24dps(V, V, V);
V g_list_2emap_24s942566919x1152393003_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1037857700x2096250953(V, V);
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_clo;
V g_list_2emerge_24s1081221956x1079757426(V, V);
V g_list_2emerge_24s1081221956x1079757426_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s2063716145x1843377885_24dps(V, V, V);
V g_list_2emerge_24s2063716145x1843377885_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s2063716145x1843377885_24dps_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2esortBy_24s655524619x299640735(V);
V g_list_2esortBy_24s655524619x299640735_entry(V self, V *a);
extern Clo g_list_2esortBy_24s655524619x299640735_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1259666496x1713656817_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_24dps_clo;
V g_list_2ezipWith_24s706961545x2112949112_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
V g_list_2efoldr_lam0(V self, V *args);
Clo g_list_2efoldr_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldr_entry, 3, 0};

V g_list_2efoldr(V v_f_240, V v_z_241, V v_xs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  return ({ V a_0 = heff_clo_n(g_list_2efoldr_lam0, 2, 1, (V[]){v_f_240}); V a_1 = v_z_241; V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_list_2efoldr_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldr(a[0], a[1], a[2]);
}
V g_list_2efoldr_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_240;
  args[0] = v_x_245;
  args[1] = v_acc_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_244 = (g_list_2ereplicate_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_entry, 2, 0};

V g_list_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = (g_list_2etake(heff_intDiv(v_t_246, MK_INT(2LL)), heff_dup(v_xs_241)));
      V v_t_248 = (g_list_2esortBy(heff_dup(v_le_240), v_t_247));
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2410 = ({ V a_0 = heff_intDiv(v_t_249, MK_INT(2LL)); V a_1 = v_xs_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_241, 2); r_; });
      V v_t_2411 = (g_list_2esortBy(heff_dup(v_le_240), v_t_2410));
      return (g_list_2emerge(v_le_240, v_t_248, v_t_2411));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1303721783x1302064695_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_lit_2412, V v_lit_2413, V v_lit_2414, V v_lit_2415, V v_lit_2416, V v_lit_2417, V v_lit_2418, V v_lit_2419, V v_lit_2420, V v_lit_2421, V v_lit_2422, V v_lit_2423, V v_lit_2424, V v_lit_2425, V v_lit_2426, V v_lit_2427, V v_lit_2428, V v_lit_2429, V v_lit_2430, V v_x2_2431) {
top: ;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    heff_drop(v_lit_2412);
    heff_drop(v_lit_2413);
    heff_drop(v_lit_2414);
    heff_drop(v_lit_2415);
    heff_drop(v_lit_2416);
    heff_drop(v_lit_2417);
    heff_drop(v_lit_2418);
    heff_drop(v_lit_2419);
    heff_drop(v_lit_2420);
    heff_drop(v_lit_2421);
    heff_drop(v_lit_2422);
    heff_drop(v_lit_2423);
    heff_drop(v_lit_2424);
    heff_drop(v_lit_2425);
    heff_drop(v_lit_2426);
    heff_drop(v_lit_2427);
    heff_drop(v_lit_2428);
    heff_drop(v_lit_2429);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_t_2434;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_I8: {
      v_t_2434 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I16: {
      v_t_2434 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I32: {
      v_t_2434 = heff_dup(v_lit_243);
      break;
    }
    case TAG_I64: {
      v_t_2434 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U8: {
      v_t_2434 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U16: {
      v_t_2434 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U32: {
      v_t_2434 = heff_dup(v_lit_247);
      break;
    }
    case TAG_U64: {
      v_t_2434 = heff_dup(v_lit_248);
      break;
    }
    case TAG_F32: {
      v_t_2434 = heff_dup(v_lit_249);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2435;
    switch (heff_tag_of(v_x_2432)) {
    case TAG_OpAdd: {
      v_t_2435 = heff_dup(v_lit_2410);
      break;
    }
    case TAG_OpSub: {
      v_t_2435 = heff_dup(v_lit_2411);
      break;
    }
    case TAG_OpMul: {
      v_t_2435 = heff_dup(v_lit_2412);
      break;
    }
    case TAG_OpDiv: {
      v_t_2435 = heff_dup(v_lit_2413);
      break;
    }
    case TAG_OpRem: {
      v_t_2435 = heff_dup(v_lit_2414);
      break;
    }
    case TAG_OpEq: {
      v_t_2435 = heff_dup(v_lit_2415);
      break;
    }
    case TAG_OpLt: {
      v_t_2435 = heff_dup(v_lit_2416);
      break;
    }
    case TAG_OpLe: {
      v_t_2435 = heff_dup(v_lit_2417);
      break;
    }
    case TAG_OpAnd: {
      v_t_2435 = heff_dup(v_lit_2418);
      break;
    }
    case TAG_OpOr: {
      v_t_2435 = heff_dup(v_lit_2419);
      break;
    }
    case TAG_OpXor: {
      v_t_2435 = heff_dup(v_lit_2420);
      break;
    }
    case TAG_OpShl: {
      v_t_2435 = heff_dup(v_lit_2421);
      break;
    }
    case TAG_OpShr: {
      v_t_2435 = heff_dup(v_lit_2422);
      break;
    }
    case TAG_OpShow: {
      v_t_2435 = heff_dup(v_lit_2423);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2435 = heff_dup(v_lit_2424);
      break;
    }
    case TAG_OpToInt: {
      v_t_2435 = heff_dup(v_lit_2425);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2435 = heff_dup(v_lit_2426);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2435 = heff_dup(v_lit_2427);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2435 = heff_dup(v_lit_2428);
      break;
    }
    case TAG_OpFloor: {
      v_t_2435 = heff_dup(v_lit_2429);
      break;
    }
    default: heff_nomatch(v_x_2432);
    }
    if (heff_strEq_c(heff_strAppend(v_t_2434, v_t_2435), heff_dup(v_lit_2430))) {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      heff_drop(v_lit_2410);
      heff_drop(v_lit_2411);
      heff_drop(v_lit_2412);
      heff_drop(v_lit_2413);
      heff_drop(v_lit_2414);
      heff_drop(v_lit_2415);
      heff_drop(v_lit_2416);
      heff_drop(v_lit_2417);
      heff_drop(v_lit_2418);
      heff_drop(v_lit_2419);
      heff_drop(v_lit_2420);
      heff_drop(v_lit_2421);
      heff_drop(v_lit_2422);
      heff_drop(v_lit_2423);
      heff_drop(v_lit_2424);
      heff_drop(v_lit_2425);
      heff_drop(v_lit_2426);
      heff_drop(v_lit_2427);
      heff_drop(v_lit_2428);
      heff_drop(v_lit_2429);
      heff_drop(v_xs_2433);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2432}});
    } else {
      heff_drop(v_x_2432);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_lit_2412;
      V t_13 = v_lit_2413;
      V t_14 = v_lit_2414;
      V t_15 = v_lit_2415;
      V t_16 = v_lit_2416;
      V t_17 = v_lit_2417;
      V t_18 = v_lit_2418;
      V t_19 = v_lit_2419;
      V t_20 = v_lit_2420;
      V t_21 = v_lit_2421;
      V t_22 = v_lit_2422;
      V t_23 = v_lit_2423;
      V t_24 = v_lit_2424;
      V t_25 = v_lit_2425;
      V t_26 = v_lit_2426;
      V t_27 = v_lit_2427;
      V t_28 = v_lit_2428;
      V t_29 = v_lit_2429;
      V t_30 = v_lit_2430;
      V t_31 = v_xs_2433;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_lit_2412 = t_12;
      v_lit_2413 = t_13;
      v_lit_2414 = t_14;
      v_lit_2415 = t_15;
      v_lit_2416 = t_16;
      v_lit_2417 = t_17;
      v_lit_2418 = t_18;
      v_lit_2419 = t_19;
      v_lit_2420 = t_20;
      v_lit_2421 = t_21;
      v_lit_2422 = t_22;
      v_lit_2423 = t_23;
      v_lit_2424 = t_24;
      v_lit_2425 = t_25;
      v_lit_2426 = t_26;
      v_lit_2427 = t_27;
      v_lit_2428 = t_28;
      v_lit_2429 = t_29;
      v_lit_2430 = t_30;
      v_x2_2431 = t_31;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2431)}});
  }
}
Clo g_list_2efilter_24s716173495x680820632_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s716173495x680820632_entry, 2, 0};

V g_list_2efilter_24s716173495x680820632(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s716173495x680820632_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s716173495x680820632(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s584454411x1006678865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_entry, 1, 0};

V g_list_2emap_24s584454411x1006678865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s584454411x1006678865_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865(a[0]);
}
Clo g_list_2efoldl_24s405709498x1837254440_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s405709498x1837254440_entry, 2, 0};

V g_list_2efoldl_24s405709498x1837254440(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eranges_2eabsorbOne(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s405709498x1837254440(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s88152486x2058486153_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s88152486x2058486153_entry, 1, 0};

V g_list_2esortBy_24s88152486x2058486153(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s88152486x2058486153(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = ({ V a_0 = heff_intDiv(v_t_248, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2410 = (g_list_2esortBy_24s88152486x2058486153(v_t_249));
      return (g_list_2emerge_24s1347843181x1368204458(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s88152486x2058486153(a[0]);
}
Clo g_list_2esortBy_24s655524619x299640735_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s655524619x299640735_entry, 1, 0};

V g_list_2esortBy_24s655524619x299640735(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s655524619x299640735(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = ({ V a_0 = heff_intDiv(v_t_248, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2410 = (g_list_2esortBy_24s655524619x299640735(v_t_249));
      return (g_list_2emerge_24s1081221956x1079757426(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s655524619x299640735_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s655524619x299640735(a[0]);
}
Clo g_list_2emap_24s942566919x1152393003_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s942566919x1152393003_entry, 2, 0};

V g_list_2emap_24s942566919x1152393003(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s942566919x1152393003_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s942566919x1152393003(a[0], a[1]);
}
Clo g_list_2emap_24s2051429168x672290949_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051429168x672290949_24dps_entry, 2, 0};

V g_list_2emap_24s2051429168x672290949_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2051429168x672290949_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1150457979x1978067071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_24dps_entry, 2, 0};

V g_list_2emap_24s1150457979x1978067071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgExplicit = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2410});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2411 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgProject = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24ArgNamed = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_a_2412, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s366989016x166432442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_24dps_entry, 2, 0};

V g_list_2emap_24s366989016x166432442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s474585387x1072098790_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_24dps_entry, 2, 0};

V g_list_2emap_24s474585387x1072098790_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ExplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_a_2414 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ImplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2417;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_At: {
          V v_a_2415 = heff_field(v_a_2414, 0);
          V v_a_2416 = heff_field(v_a_2414, 1);
          heff_take_n(v_a_2414, 3ULL, 2);
          v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2416, v_a_2415));
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2412, v_a_2413, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1810151735x2071939409_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1810151735x2071939409_entry, 2, 0};

V g_list_2efoldl_24s1810151735x2071939409(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_248 = (g_heff_2ecompile_2esimplify_2ewaysOut(v_t_247));
    V v_t_2414;
    switch (heff_tag_of(v_z_240)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_z_240, 0);
      V v_a_2410 = heff_field(v_z_240, 1);
      heff_take_n(v_z_240, 3ULL, 2);
      switch (heff_tag_of(v_a_248)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_a_248, 0);
        V v_a_2412 = heff_field(v_a_248, 1);
        heff_take_n(v_a_248, 3ULL, 2);
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2eappendL(v_a_249, v_a_2411));
        v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2413, heff_intAdd(v_a_2410, v_a_2412)});
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1810151735x2071939409_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1810151735x2071939409(a[0], a[1]);
}
Clo g_list_2emap_24s1492759219x1917596721_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1492759219x1917596721_24dps_entry, 3, 0};

V g_list_2emap_24s1492759219x1917596721_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_lit_240; V a_1 = v_x_243; V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1492759219x1917596721_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1492759219x1917596721_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2010608108x1221393166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2010608108x1221393166_24dps_entry, 2, 0};

V g_list_2emap_24s2010608108x1221393166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2erepr_2ereprOfName(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2010608108x1221393166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2010608108x1221393166_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1431636639x1417377628_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1431636639x1417377628_entry, 2, 0};

V g_list_2efoldl_24s1431636639x1417377628(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2elayTag(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1431636639x1417377628(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1406601474x338829258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1406601474x338829258_entry, 2, 0};

V g_list_2efoldl_24s1406601474x338829258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2ecycles_2elastCalls(v_z_240, v_t_247));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1406601474x338829258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1406601474x338829258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1535080205x545126304_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1535080205x545126304_entry, 4, 0};

V g_list_2efilter_24s1535080205x545126304(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    if (heff_intLe_c_lent(v_lit_242, v_a_246, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1535080205x545126304_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1535080205x545126304_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1535080205x545126304(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_entry, 1, 0};

V g_list_2emap_24s1181937096x2120532116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c_lent(v_x_241, MK_INT(0LL), 2)) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1181937096x2120532116_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1181937096x2120532116_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116(a[0]);
}
Clo g_list_2efoldl_24s978059622x523571930_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s978059622x523571930_entry, 2, 0};

V g_list_2efoldl_24s978059622x523571930(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s978059622x523571930(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s738847920x410598254_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_entry, 2, 0};

V g_list_2ezipWith_24s738847920x410598254(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), heff_hole()});
      V v_u_2415 = (g_list_2ezipWith_24s738847920x410598254_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254(a[0], a[1]);
}
Clo g_list_2emap_24s1690674600x556093466_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_entry, 1, 0};

V g_list_2emap_24s1690674600x556093466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1690674600x556093466_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1690674600x556093466(a[0]);
}
Clo g_list_2efoldl_24s826961155x1314392429_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s826961155x1314392429_entry, 2, 0};

V g_list_2efoldl_24s826961155x1314392429(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s826961155x1314392429(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1681212806x1534785672_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1681212806x1534785672_entry, 3, 0};

V g_list_2eany_24s1681212806x1534785672(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_t_2411;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_field(v_x_243, 1);
        v_t_2411 = heff_dup(v_a_2410);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      if (heff_strEq_c_lent(v_t_2411, v_lit_241, 1)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s1681212806x1534785672(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s2092021924x904081891_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2092021924x904081891_entry, 2, 0};

V g_list_2efoldl_24s2092021924x904081891(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      V v_a2_245 = heff_field(v_x_242, 1);
      V v_a3_246 = heff_field(v_x_242, 2);
      V v_a6_249 = heff_field(v_x_242, 5);
      heff_take_n(v_x_242, 39ULL, 8);
      switch (heff_tag_of(v_a2_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a3_246)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_a6_249)) {
          case TAG_TakeNone: {
            v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, v_z_240});
            break;
          }
          case TAG_TakeN: {
            heff_take_n(v_a6_249, 0ULL, 3);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_t_244);
            v_t_2423 = v_z_240;
            break;
          }
          case TAG_TakeKeep: {
            heff_take_n(v_a6_249, 0ULL, 4);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_t_244);
            v_t_2423 = v_z_240;
            break;
          }
          default: heff_nomatch(v_a6_249);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_a3_246, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_a6_249);
          v_t_2423 = v_z_240;
          break;
        }
        default: heff_nomatch(v_a3_246);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_a2_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_t_244);
        heff_drop(v_a3_246);
        heff_drop(v_a6_249);
        v_t_2423 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a2_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2423;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2092021924x904081891(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1259666496x1713656817_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1259666496x1713656817_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1259666496x1713656817_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2escalars_2eslotFor(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_246, v_y_248));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_cell_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1259666496x1713656817_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s1259666496x1713656817_24dps(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s732475005x1616712052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_entry, 1, 0};

V g_list_2emap_24s732475005x1616712052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eemit_2eexportNameOf(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s732475005x1616712052_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052(a[0]);
}
Clo g_list_2eany_24s651308273x925219243_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s651308273x925219243_entry, 1, 0};

V g_list_2eany_24s651308273x925219243(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s651308273x925219243_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s651308273x925219243(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s164225955x66209884_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s164225955x66209884_entry, 3, 0};

V g_list_2emap_24s164225955x66209884(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eglue_2eglueOf(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s164225955x66209884_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s164225955x66209884_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s164225955x66209884(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_24dps_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_24dps_entry, 2, 0};

V g_list_2emap_24s420582357x1720502382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s420582357x1720502382_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s706961545x2112949112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s706961545x2112949112_24dps_entry, 6, 0};

V g_list_2ezipWith_24s706961545x2112949112_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_246, heff_dup(v_lit_242)));
      V v_t_2411 = heff_strAppend(heff_intShow(v_y_248), v_t_2410);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2411), heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s706961545x2112949112_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s706961545x2112949112_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1936967306x1304226505_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936967306x1304226505_24dps_entry, 5, 0};

V g_list_2emap_24s1936967306x1304226505_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_245; V r_ = (g_heff_2ecompile_2eemitc_2eflatLine(a_0, a_1, a_2, a_3)); heff_drop(v_x_245); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1936967306x1304226505_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2073083146x1445066245_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_24dps_entry, 2, 0};

V g_list_2emap_24s2073083146x1445066245_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1732572494x729779974_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1732572494x729779974_entry, 2, 0};

V g_list_2efoldl_24s1732572494x729779974(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_a_244, 2)));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_a_244, 0, 3), v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1732572494x729779974(a[0], a[1]);
}
Clo g_list_2efoldl_24s497871705x469972998_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s497871705x469972998_entry, 2, 0};

V g_list_2efoldl_24s497871705x469972998(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_get_n(v_t_246, 0, 3), v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s497871705x469972998_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s497871705x469972998(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1111588856x1684976655_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1111588856x1684976655_entry, 2, 0};

V g_list_2efoldl_24s1111588856x1684976655(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      v_t_2412 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, v_t_249, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1111588856x1684976655_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1111588856x1684976655(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1134745827x519521524_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134745827x519521524_entry, 1, 0};

V g_list_2emap_24s1134745827x519521524(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = heff_take_field(v_x_241, 1); V b_1 = heff_get_n(v_x_241, 2, 5); V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1134745827x519521524_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1134745827x519521524(a[0]);
}
Clo g_list_2efoldl_24s762187723x368876092_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s762187723x368876092_entry, 2, 0};

V g_list_2efoldl_24s762187723x368876092(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_z_240, 3), heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V v_t_245 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_z_240, 503ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s762187723x368876092_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s762187723x368876092(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1122556128x1089664899_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1122556128x1089664899_entry, 2, 0};

V g_list_2efoldl_24s1122556128x1089664899(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2ewithUnexposedOpen(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1122556128x1089664899_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1122556128x1089664899(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1512999845x472671375_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512999845x472671375_24dps_entry, 6, 0};

V g_list_2emap_24s1512999845x472671375_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_242), heff_strLength_lent(v_a_248, 0));
    V v_t_2413;
    if (heff_strEq_c(v_t_249, v_a_248)) {
      V v_t_2411 = heff_intAdd(heff_strLength_lent(v_lit_240, 0), heff_dup(v_lit_243));
      V v_t_2412 = heff_strSlice(heff_dup(v_x_246), v_t_2411, heff_strLength_lent(v_x_246, 0));
      v_t_2413 = heff_rec_n(2, shape_name__key, (V[]){v_t_2412, v_x_246});
    } else {
      v_t_2413 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_246), v_x_246});
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2414;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1512999845x472671375_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s1512999845x472671375_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_list_2eany_24s150647489x375460461_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s150647489x375460461_entry, 2, 0};

V g_list_2eany_24s150647489x375460461(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      V v_a_245 = heff_dup(heff_rfield(v_x_242, 1));
      V v_t_246 = heff_dup(heff_rfield(v_lit_240, 1));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_Nothing: {
          heff_drop_rec(v_lit_240, 3);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_a_245, 0ULL, 1);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_245);
        }
      }
      case TAG_Just: {
        V v_a_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_Nothing: {
          heff_drop(v_a_248);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Just: {
          V v_a_249 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          if (heff_strEq_c(v_a_248, v_a_249)) {
            heff_drop_rec(v_lit_240, 3);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_lit_240;
            V t_1 = v_xs_243;
            v_lit_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_245);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s150647489x375460461_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s150647489x375460461(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1983706162x228765702_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 14);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 7);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s2016443462x370533815_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016443462x370533815_24dps_entry, 2, 0};

V g_list_2emap_24s2016443462x370533815_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016443462x370533815_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s354283597x484250159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s354283597x484250159_24dps_entry, 3, 0};

V g_list_2emap_24s354283597x484250159_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2eformat_2evariantKey(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s354283597x484250159_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s354283597x484250159_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s890213172x1049425163_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_entry, 1, 0};

V g_list_2emap_24s890213172x1049425163(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s890213172x1049425163_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163(a[0]);
}
Clo g_list_2emap_24s890213172x1049425163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_24dps_entry, 2, 0};

V g_list_2emap_24s890213172x1049425163_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1725521117x1379101383_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1725521117x1379101383_entry, 7, 0};

V g_list_2efoldl_24s1725521117x1379101383(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_z_245, V v_x3_246) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_241, 3);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    return v_z_245;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_246, 0);
    V v_xs_248 = heff_field(v_x3_246, 1);
    V v_ru_24x3_246_24Cons = heff_take_reuse_n(v_x3_246, 3ULL, 2);
    V v_t_2414;
    if (heff_strEq_c_lent(v_x_247, v_lit_240, 0)) {
      heff_drop(v_x_247);
      switch (heff_tag_of(v_z_245)) {
      case TAG_Nil: {
        V v_t_2410 = heff_dup(heff_rfield(v_lit_241, 1));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          heff_drop(v_t_2410);
          v_t_2414 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2410);
          v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_242), NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_Cons: {
        V v_a_2411 = heff_dup(heff_field(v_z_245, 0));
        V v_a_2412 = heff_dup(heff_field(v_z_245, 1));
        if (heff_strEq_c_lent(v_a_2411, v_lit_243, 1)) {
          heff_drop(v_a_2412);
          v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_244), v_z_245});
        } else {
          heff_drop_tag(v_z_245, 2);
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2414 = v_a_2412;
        }
        break;
      }
      default: heff_nomatch(v_z_245);
      }
    } else {
      v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_245});
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_t_2414;
    V t_6 = v_xs_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_z_245 = t_5;
    v_x3_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2efoldl_24s1725521117x1379101383(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2emap_24s675147852x248982264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_24dps_entry, 3, 0};

V g_list_2emap_24s675147852x248982264_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), heff_take_field(v_x_243, 1), heff_get_n(v_x_243, 2, 3)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1081981235x855852216_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1081981235x855852216_entry, 2, 0};

V g_list_2eany_24s1081981235x855852216(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1081981235x855852216(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2esortBy_24s1681607803x465385494_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1681607803x465385494_entry, 1, 0};

V g_list_2esortBy_24s1681607803x465385494(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1681607803x465385494(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = ({ V a_0 = heff_intDiv(v_t_248, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2410 = (g_list_2esortBy_24s1681607803x465385494(v_t_249));
      return (g_list_2emerge_24s1037857700x2096250953(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1681607803x465385494(a[0]);
}
Clo g_list_2emap_24s388004800x1261967008_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_24dps_entry, 2, 0};

V g_list_2emap_24s388004800x1261967008_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1234524601x742515152_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1234524601x742515152_24dps_entry, 2, 0};

V g_list_2emap_24s1234524601x742515152_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rr_ = heff_rec_reuse_na(v_x_242, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1234524601x742515152_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s2063716145x1843377885_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s2063716145x1843377885_24dps_entry, 3, 0};

V g_list_2emerge_24s2063716145x1843377885_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 4);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_247 = (g_heff_2ebuild_2ecommands_2eplaceBefore(heff_rfield(v_x_243, 1), heff_rfield(v_y_245, 1)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_248;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_247);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2410;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s2063716145x1843377885_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s2063716145x1843377885_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1420651609x666245096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_24dps_entry, 2, 0};

V g_list_2emap_24s1420651609x666245096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1105764576x1671327425_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1105764576x1671327425_24dps_entry, 4, 0};

V g_list_2emap_24s1105764576x1671327425_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 5);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_246 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_a_246), heff_dup(heff_rfield(v_lit_241, 2)), v_t_247);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_2410 = heff_strSlice(v_a_246, v_t_249, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(v_x_244, v_t_2410));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1105764576x1671327425_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1105764576x1671327425_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s2002848564x1372628513_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2002848564x1372628513_entry, 2, 0};

V g_list_2eany_24s2002848564x1372628513(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 14);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2002848564x1372628513_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s2002848564x1372628513(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1351460748x1231260144_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1351460748x1231260144_entry, 2, 0};

V g_list_2efilter_24s1351460748x1231260144(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intLe_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1351460748x1231260144_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1351460748x1231260144(a[0], a[1]);
}
Clo g_list_2efilter_24s1351460748x1231260144_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1351460748x1231260144_24dps_entry, 3, 0};

V g_list_2efilter_24s1351460748x1231260144_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1351460748x1231260144_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1351460748x1231260144_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s857425298x1024652640_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s857425298x1024652640_entry, 1, 0};

V g_list_2emap_24s857425298x1024652640(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V rv_1 = NTAG(TAG_Inverse); V rr_ = heff_rec_reuse_nf(v_x_241, 1ULL, 2, shape_text__style, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s857425298x1024652640_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s857425298x1024652640(a[0]);
}
Clo g_list_2emap_24s857425298x1024652640_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s857425298x1024652640_24dps_entry, 2, 0};

V g_list_2emap_24s857425298x1024652640_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rv_1 = NTAG(TAG_Inverse); V rr_ = heff_rec_reuse_nf(v_x_242, 1ULL, 2, shape_text__style, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s857425298x1024652640_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s857425298x1024652640_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f88106788x1680212182_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f88106788x1680212182_entry, 1, 0};

V g_list_2emap_24f88106788x1680212182(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_x_241, 3);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), heff_hole()});
      V v_u_245 = (g_list_2emap_24f88106788x1680212182_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f88106788x1680212182(a[0]);
}
Clo g_list_2efoldl_24f1922461191x750914054_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1922461191x750914054_entry, 4, 0};

V g_list_2efoldl_24f1922461191x750914054(V v_z_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_244, 1);
      v_t_248 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_x_249 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = heff_intAdd(v_z_240, v_x_249);
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_245;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1922461191x750914054(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1128388138x103163567_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1128388138x103163567_entry, 4, 0};

V g_list_2efoldl_24f1128388138x103163567(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_242, 4);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(v_x_244), heff_dup(heff_rfield(v_lit_242, 0)))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1128388138x103163567_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1128388138x103163567(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1293205645x619162872_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1293205645x619162872_entry, 4, 0};

V g_list_2emap_24f1293205645x619162872(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_245 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24f1293205645x619162872_24dps(v_lit_240, v_lit_241, heff_box_word((heff_unbox_word(v_a_242) + ((int64_t)1ULL))), v_b_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
}
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1293205645x619162872(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1156519715x726760149_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1156519715x726760149_entry, 1, 0};

V g_list_2emap_24f1156519715x726760149(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_241, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
      V v_u_245 = (g_list_2emap_24f1156519715x726760149_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1156519715x726760149(a[0]);
}
Clo g_list_2emap_24f990982947x2126256822_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f990982947x2126256822_24dps_entry, 3, 0};

V g_list_2emap_24f990982947x2126256822_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f990982947x2126256822_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f765463553x1160475073_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f765463553x1160475073_entry, 7, 0};

V g_list_2efoldl_24f765463553x1160475073(V v_z_240, V v_box_24lit_241, V v_lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24a_245, V v_box_24b_246) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
  int64_t v_a_245 = heff_unbox_word(v_box_24a_245);
  int64_t v_b_246 = heff_unbox_word(v_box_24b_246);
top: ;
  if ((v_b_246 < v_a_245)) {
    return v_z_240;
  } else {
    if ((v_a_245 == v_lit_241)) {
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_a_245), v_z_240});
      int64_t t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
      int64_t t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    } else {
      V v_t_249 = heff_strByteAt_lent(v_lit_242, heff_box_word((v_a_245 - v_lit_243)), 2);
      if ((heff_unbox_word(v_t_249) == v_lit_244)) {
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_a_245), v_z_240});
        int64_t t_1 = v_lit_241;
        V t_2 = v_lit_242;
        int64_t t_3 = v_lit_243;
        int64_t t_4 = v_lit_244;
        int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
        int64_t t_6 = v_b_246;
        v_z_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_a_245 = t_5;
        v_b_246 = t_6;
        goto top;
      } else {
        V t_0 = v_z_240;
        int64_t t_1 = v_lit_241;
        V t_2 = v_lit_242;
        int64_t t_3 = v_lit_243;
        int64_t t_4 = v_lit_244;
        int64_t t_5 = (v_a_245 + ((int64_t)1ULL));
        int64_t t_6 = v_b_246;
        v_z_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_a_245 = t_5;
        v_b_246 = t_6;
        goto top;
      }
    }
  }
}
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f765463553x1160475073(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f130772758x674845987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_24dps_entry, 5, 0};

V g_list_2emap_24f130772758x674845987_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
    if (heff_strEq_c_lent(v_t_247, v_lit_242, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_245, heff_dup(v_lit_240)), heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f130772758x674845987_24dps(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f547094838x440994078_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f547094838x440994078_entry, 3, 0};

V g_list_2efoldl_24f547094838x440994078(V v_z_240, V v_n_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_n_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c_lent(v_n_241, MK_INT(0LL), 2)) {
      heff_drop(v_n_241);
      return v_z_240;
    } else {
      V v_x_246 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_x_243)));
      V t_0 = heff_intAdd(v_z_240, v_x_246);
      V t_1 = heff_intSub(v_n_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_n_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f547094838x440994078(a[0], a[1], a2); heff_drop(a2); return r;
}