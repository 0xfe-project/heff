// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArmCovered 35323
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Flat 38290
#define TAG_Inverse 25398
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkSegment 38079
#define TAG_Nest 8345
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_assoc 294479919
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_cons 9554936
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_flds 9641116
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_index 301704428
#define LBL_kinds 303412089
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_size 10026184
#define LBL_skipped 231818613
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_tag 324116
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_tys 324872
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_kinds__cons[] = {LBL_kinds, LBL_cons};
static uint32_t shape_kinds__places[] = {LBL_kinds, LBL_places};
static uint32_t shape_tag__index__tys__flds__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_flds, LBL_places};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eglue_2eglueOf(V, V, V);
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eglueOf_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eranges_2eabsorbOne(V, V);
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo;
V g_heff_2eelab_2etoplevel_2ecoveredAbove_get(void);
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_list_2eall_24s1934518973x1420187537(V);
V g_list_2eall_24s1934518973x1420187537_entry(V self, V *a);
extern Clo g_list_2eall_24s1934518973x1420187537_clo;
V g_list_2eany_24s1032636598x1013662416(V);
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a);
extern Clo g_list_2eany_24s1032636598x1013662416_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2eany_24s752896332x1549544792(V, V);
V g_list_2eany_24s752896332x1549544792_entry(V self, V *a);
extern Clo g_list_2eany_24s752896332x1549544792_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
HeffT2 g_list_2efind_24s792771115x178990339_24cpr(V, V);
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1431636639x1417377628(V, V);
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1431636639x1417377628_clo;
V g_list_2efoldl_24s1513567688x204074300(V, V);
V g_list_2efoldl_24s1513567688x204074300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513567688x204074300_clo;
V g_list_2efoldl_24s1682887903x724363097(V, V, V);
V g_list_2efoldl_24s1682887903x724363097_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1682887903x724363097_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s2124979901x587925464(V, V);
V g_list_2efoldl_24s2124979901x587925464_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2124979901x587925464_clo;
V g_list_2efoldl_24s405709498x1837254440(V, V);
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s405709498x1837254440_clo;
V g_list_2efoldl_24s465028312x319285028(V, V);
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s465028312x319285028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s257286374x378693326(V, V);
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_clo;
V g_list_2ekeepIf_24s257286374x378693326_24dps(V, V, V);
V g_list_2ekeepIf_24s257286374x378693326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_24dps_clo;
V g_list_2ekeepIf_24s537296923x1092827761_24dps(V, V, V);
V g_list_2ekeepIf_24s537296923x1092827761_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_24dps_clo;
V g_list_2ekeepIf_24s741838803x941779121(V);
V g_list_2ekeepIf_24s741838803x941779121_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_clo;
V g_list_2ekeepIf_24s741838803x941779121_24dps(V, V);
V g_list_2ekeepIf_24s741838803x941779121_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s741838803x941779121_24dps_clo;
V g_list_2emap_24f719546030x1732151491(V, V);
V g_list_2emap_24f719546030x1732151491_entry(V self, V *a);
extern Clo g_list_2emap_24f719546030x1732151491_clo;
V g_list_2emap_24f719546030x1732151491_24dps(V, V, V);
V g_list_2emap_24f719546030x1732151491_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f719546030x1732151491_24dps_clo;
V g_list_2emap_24s1134745827x519521524(V);
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_clo;
V g_list_2emap_24s1134745827x519521524_24dps(V, V);
V g_list_2emap_24s1134745827x519521524_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_24dps_clo;
V g_list_2emap_24s1155474388x1593011685_24dps(V, V);
V g_list_2emap_24s1155474388x1593011685_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1155474388x1593011685_24dps_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1429062098x1340918317_24dps(V, V);
V g_list_2emap_24s1429062098x1340918317_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1429062098x1340918317_24dps_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s164225955x66209884_24dps(V, V, V, V);
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_24dps_clo;
V g_list_2emap_24s1690674600x556093466(V);
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s1936967306x1304226505_24dps(V, V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_24dps_clo;
V g_list_2emap_24s2016443462x370533815_24dps(V, V);
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_24dps_clo;
V g_list_2emap_24s224183526x935259397_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s224183526x935259397_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s224183526x935259397_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s388277778x1355328594(V);
V g_list_2emap_24s388277778x1355328594_entry(V self, V *a);
extern Clo g_list_2emap_24s388277778x1355328594_clo;
V g_list_2emap_24s388277778x1355328594_24dps(V, V);
V g_list_2emap_24s388277778x1355328594_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388277778x1355328594_24dps_clo;
V g_list_2emap_24s409254358x573963502(V);
V g_list_2emap_24s409254358x573963502_entry(V self, V *a);
extern Clo g_list_2emap_24s409254358x573963502_clo;
V g_list_2emap_24s409254358x573963502_24dps(V, V);
V g_list_2emap_24s409254358x573963502_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s409254358x573963502_24dps_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s839307021x1449425912_24dps(V, V);
V g_list_2emap_24s839307021x1449425912_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s839307021x1449425912_24dps_clo;
V g_list_2emap_24s857425298x1024652640(V);
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_clo;
V g_list_2emap_24s857425298x1024652640_24dps(V, V);
V g_list_2emap_24s857425298x1024652640_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_24dps_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_243 = (g_list_2ereplicate_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241, heff_dup(v_cell_242)));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2emap_24s584454411x1006678865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_entry, 1, 0};

V g_list_2emap_24s584454411x1006678865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s584454411x1006678865_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865(a[0]);
}
Clo g_list_2efoldl_24s405709498x1837254440_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s405709498x1837254440_entry, 2, 0};

V g_list_2efoldl_24s405709498x1837254440(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eranges_2eabsorbOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s405709498x1837254440_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s405709498x1837254440(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2eall_24s1934518973x1420187537_str0, 1, "_");
Clo g_list_2eall_24s1934518973x1420187537_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1934518973x1420187537_entry, 1, 0};

V g_list_2eall_24s1934518973x1420187537(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_p_243 = heff_dup(v_x_241);
    V v_t_2445;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_v_244 = heff_field(v_p_243, 0);
      V v_p2_245 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 3ULL, 2);
      switch (heff_tag_of(v_p2_245)) {
      case TAG_EVar: {
        V v_y_246 = heff_field(v_p2_245, 0);
        heff_take_n(v_p2_245, 1ULL, 1);
        v_t_2445 = heff_bool((heff_strEq_c_lent(v_v_244, v_y_246, 0) && !heff_strEq_c_lent(v_v_244, ((V)&g_list_2eall_24s1934518973x1420187537_str0), 2)));
        heff_drop(v_v_244);
        heff_drop(v_y_246);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_p2_245, 0ULL, 3);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_p2_245, 0ULL, 4);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_p2_245, 0ULL, 3);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_p2_245, 0ULL, 3);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_p2_245, 0ULL, 1);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_p2_245, 0ULL, 2);
        heff_drop(v_v_244);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_p2_245);
      }
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2445);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1934518973x1420187537_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1934518973x1420187537(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1155474388x1593011685_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1155474388x1593011685_24dps_entry, 2, 0};

V g_list_2emap_24s1155474388x1593011685_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      V v_ru_24x_242_24MkArm = heff_take_reuse_n(v_x_242, 7ULL, 3);
      V v_t_247 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_a_246));
      v_t_248 = heff_tag_at_n(v_ru_24x_242_24MkArm, TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1155474388x1593011685_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1155474388x1593011685_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2015232937x23400545_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2015232937x23400545_entry, 2, 0};

V g_list_2efoldl_24s2015232937x23400545(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_s_245 = v_x_242;
    V v_t_2436;
    switch (heff_tag_of(v_s_245)) {
    case TAG_CDrop: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CLet: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CDecl: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CSet: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CIf: {
      V v_a_2413 = heff_field(v_s_245, 1);
      V v_b_2414 = heff_field(v_s_245, 2);
      heff_take_n(v_s_245, 6ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2415 = (g_list_2efoldl_24s2015232937x23400545(v_acc_244, v_a_2413));
      v_t_2436 = (g_list_2efoldl_24s2015232937x23400545(v_t_2415, v_b_2414));
      break;
    }
    case TAG_CSwitch: {
      V v_arms_2417 = heff_field(v_s_245, 1);
      heff_take_n(v_s_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = ({ V a_0 = v_acc_244; V a_1 = v_arms_2417; V r_ = (g_list_2efoldl_24s1513567688x204074300(a_0, a_1)); heff_drop(v_arms_2417); r_; });
      break;
    }
    case TAG_CReturn: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CInPlace: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CRoomed: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CTail: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CLoop: {
      V v_ps_2426 = heff_field(v_s_245, 0);
      V v_es_2427 = heff_field(v_s_245, 1);
      heff_take_n(v_s_245, 3ULL, 2);
      V v_t_2428 = (g_list_2ezipWith_24s1876717925x1404326288(v_ps_2426, v_es_2427));
      v_t_2436 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_acc_244});
      break;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CLabel: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    case TAG_CJump: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2436 = v_acc_244;
      break;
    }
    default: heff_nomatch(v_s_245);
    }
    V t_0 = v_t_2436;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2015232937x23400545(a[0], a[1]);
}
Clo g_list_2emap_24s409254358x573963502_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s409254358x573963502_entry, 1, 0};

V g_list_2emap_24s409254358x573963502(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Flat: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_248 = v_a_243;
      break;
    }
    case TAG_Nest: {
      V v_a_244 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 4);
      v_t_248 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s409254358x573963502_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s409254358x573963502_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s409254358x573963502(a[0]);
}
Clo g_list_2emap_24s388277778x1355328594_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388277778x1355328594_entry, 1, 0};

V g_list_2emap_24s388277778x1355328594(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Flat, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s388277778x1355328594_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388277778x1355328594_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388277778x1355328594(a[0]);
}
Clo g_list_2efoldl_24s1431636639x1417377628_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1431636639x1417377628_entry, 2, 0};

V g_list_2efoldl_24s1431636639x1417377628(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_kinds_245 = heff_take_field(v_acc_244, 0);
    V v_cons_246 = heff_get_n(v_acc_244, 1, 2);
    V v_x2_247 = v_x_242;
    V v_t_2420;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_x2_247, 0);
      V v_fs_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      V v_t_2410 = heff_rec_n(2, shape_kinds__places, (V[]){v_kinds_245, NTAG(TAG_Nil)});
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_249)));
      V v_t_2412 = (g_list_2efoldl_24s2124979901x587925464(NTAG(TAG_Nil), v_t_2411));
      V v_p_2413 = (g_list_2efoldl_24s465028312x319285028(v_t_2410, v_t_2412));
      V v_kinds_2414 = heff_take_field(v_p_2413, 0);
      V v_places_2415 = heff_get_n(v_p_2413, 1, 2);
      V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cons_246));
      V v_t_2417 = (g_list_2emap_24s409254358x573963502(heff_dup(v_fs_249)));
      V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_tag__index__tys__flds__places, (V[]){v_t_248, v_t_2416, v_t_2417, v_fs_249, v_places_2415}), NTAG(TAG_Nil)});
      V v_t_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_247_24MkPair, v_cons_246, v_t_2418));
      v_t_2420 = heff_rec_n(2, shape_kinds__cons, (V[]){v_kinds_2414, v_t_2419});
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1431636639x1417377628(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_entry, 1, 0};

V g_list_2emap_24s1181937096x2120532116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_intLt_c_lent(v_x_241, MK_INT(0LL), 2)) {
      V v_t_243 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_244 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_str0), v_t_243), ((V)&g_list_2emap_24s1181937096x2120532116_str1));
    } else {
      v_t_244 = heff_intShow(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1181937096x2120532116_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116(a[0]);
}
Clo g_list_2emap_24s1690674600x556093466_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_entry, 1, 0};

V g_list_2emap_24s1690674600x556093466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1690674600x556093466_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1690674600x556093466(a[0]);
}
Clo g_list_2emap_24s1429062098x1340918317_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1429062098x1340918317_24dps_entry, 2, 0};

V g_list_2emap_24s1429062098x1340918317_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_t_249));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1429062098x1340918317_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1429062098x1340918317_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1682887903x724363097_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1682887903x724363097_entry, 3, 0};

V g_list_2efoldl_24s1682887903x724363097(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_f_245 = heff_dup(v_lit_240);
    V v_acc_246 = v_z_241;
    V v_e_247 = v_x_243;
    V v_t_2447;
    switch (heff_tag_of(v_e_247)) {
    case TAG_EVar: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_247, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ECall: {
      V v_g_2431 = heff_field(v_e_247, 0);
      V v_args_2432 = heff_field(v_e_247, 1);
      heff_take_n(v_e_247, 3ULL, 2);
      if (heff_strEq_c(v_g_2431, v_f_245)) {
        v_t_2447 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_args_2432, v_acc_246});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_args_2432);
        v_t_2447 = v_acc_246;
      }
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_f_245);
      v_t_2447 = v_acc_246;
      break;
    }
    default: heff_nomatch(v_e_247);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2447;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1682887903x724363097_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1682887903x724363097(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s164225955x66209884_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s164225955x66209884_entry, 3, 0};

V g_list_2emap_24s164225955x66209884(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eglue_2eglueOf(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s164225955x66209884_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s164225955x66209884_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s164225955x66209884(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_24dps_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_24dps_entry, 2, 0};

V g_list_2emap_24s420582357x1720502382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s420582357x1720502382_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str0, 2, "  ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str1, 1, " ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str3, 2, "v_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str4, 13, " = heff_tget_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str5, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str6, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str7, 14, " = heff_tflat_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str8, 13, " = heff_tget_");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str9, 1, "v");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str10, 3, "f64");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str11, 4, "word");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str12, 1, "(");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str13, 2, ", ");
HEFF_LIT(g_list_2emap_24s1936967306x1304226505_24dps_str14, 2, ");");
Clo g_list_2emap_24s1936967306x1304226505_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936967306x1304226505_24dps_entry, 5, 0};

V g_list_2emap_24s1936967306x1304226505_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_k_247 = heff_dup(v_lit_240);
    V v_sv_248 = heff_dup(v_lit_241);
    V v_sure_249 = heff_dup(v_lit_242);
    V v_x4_2410 = v_x_245;
    V v_t_2427;
    switch (heff_tag_of(v_x4_2410)) {
    case TAG_MkPair: {
      V v_v_2411 = heff_field(v_x4_2410, 0);
      V v_x42_2412 = heff_field(v_x4_2410, 1);
      heff_take_n(v_x4_2410, 3ULL, 2);
      switch (heff_tag_of(v_x42_2412)) {
      case TAG_MkPair: {
        V v_i_2413 = heff_field(v_x42_2412, 0);
        V v_r_2414 = heff_field(v_x42_2412, 1);
        heff_take_n(v_x42_2412, 3ULL, 2);
        V v_t_2415 = heff_tr(heff_call(heff_get_n(v_k_247, 2, 6), 1, (V[]){heff_dup(v_v_2411)}));
        V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1936967306x1304226505_24dps_str0), v_t_2415), ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str1));
        V v_t_2417 = ({ V a_0 = v_v_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_v_2411); r_; });
        V v_t_2418 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_list_2emap_24s1936967306x1304226505_24dps_str3), v_t_2417));
        V v_t_2419 = ({ V a_0 = heff_dup(v_i_2413); V a_1 = v_sure_249; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_sure_249); r_; });
        V v_t_2421;
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_t_2419);
          switch (heff_tag_of(v_r_2414)) {
          case TAG_RepV: {
            v_t_2421 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str4);
            break;
          }
          case TAG_RepFix: {
            v_t_2421 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str5);
            break;
          }
          case TAG_RepF64: {
            v_t_2421 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str6);
            break;
          }
          case TAG_RepInt: {
            v_t_2421 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str7);
            break;
          }
          default: heff_nomatch(v_r_2414);
          }
        } else {
          heff_drop(v_t_2419);
          v_t_2421 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str8);
        }
        V v_t_2423;
        switch (heff_tag_of(v_r_2414)) {
        case TAG_RepV: {
          v_t_2423 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str9);
          break;
        }
        case TAG_RepFix: {
          V v_w_2422 = heff_field(v_r_2414, 0);
          heff_take_n(v_r_2414, 1ULL, 1);
          v_t_2423 = ({ V a_0 = v_w_2422; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_2422); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2423 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str10);
          break;
        }
        case TAG_RepInt: {
          v_t_2423 = ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str11);
          break;
        }
        default: heff_nomatch(v_r_2414);
        }
        V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2421), v_t_2423);
        V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str12)), v_sv_248);
        V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str13)), heff_intShow(v_i_2413));
        v_t_2427 = heff_strAppend(v_t_2426, ((V)&g_list_2emap_24s1936967306x1304226505_24dps_str14));
        break;
      }
      default: heff_nomatch(v_x42_2412);
      }
      break;
    }
    default: heff_nomatch(v_x4_2410);
    }
    V v_cell_2428 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2427, heff_hole()});
    V v_u_2429 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2428));
    heff_drop(v_u_2429);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2428;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1936967306x1304226505_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1936967306x1304226505_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1134745827x519521524_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134745827x519521524_entry, 1, 0};

V g_list_2emap_24s1134745827x519521524(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_ty_243 = heff_take_field(v_x_241, 1);
    V v_size_244 = heff_get_n(v_x_241, 2, 5);
    V v_t_245 = ({ V a_0 = v_ty_243; V a_1 = v_size_244; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_243); heff_drop(v_size_244); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1134745827x519521524_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1134745827x519521524(a[0]);
}
Clo g_list_2emap_24s839307021x1449425912_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s839307021x1449425912_24dps_entry, 2, 0};

V g_list_2emap_24s839307021x1449425912_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ArmCovered, 2, (V[]){v_x_242, heff_dup(g_heff_2eelab_2etoplevel_2ecoveredAbove_get())}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s839307021x1449425912_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s839307021x1449425912_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s752896332x1549544792_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s752896332x1549544792_entry, 2, 0};

V g_list_2eany_24s752896332x1549544792(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_code_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_span_245 = heff_dup(heff_rfield(v_x_242, 3));
    V v_msg_246 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_intEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_code_244)) && (heff_intEq_c(heff_get_n(heff_dup(heff_rfield(v_lit_240, 3)), 0, 2), heff_dup(heff_rfield(v_span_245, 0))) && (heff_intEq_c(heff_get_n(heff_dup(heff_rfield(v_lit_240, 3)), 1, 2), heff_dup(heff_rfield(v_span_245, 1))) && heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 2)), heff_dup(v_msg_246)))))) {
      heff_drop_rec(v_lit_240, 5);
      heff_drop(v_code_244);
      heff_drop_rec(v_span_245, 2);
      heff_drop(v_msg_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_code_244);
      heff_drop_rec(v_span_245, 2);
      heff_drop(v_msg_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s752896332x1549544792_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s752896332x1549544792(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 14);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s224183526x935259397_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s224183526x935259397_24dps_entry, 11, 0};

V g_list_2emap_24s224183526x935259397_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249, V v_d_2410) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return heff_setField(v_d_2410, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_249, 0);
    V v_xs_2412 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_id_2413 = heff_take_field(v_x_2411, 0);
    V v_assoc_2414 = heff_take_field(v_x_2411, 1);
    V v_loosest_2415 = heff_take_field(v_x_2411, 3);
    V v_ops_2416 = heff_get_n(v_x_2411, 2, 5);
    V v_t_2417;
    switch (heff_tag_of(v_assoc_2414)) {
    case TAG_AssocLeft: {
      v_t_2417 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2417 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2417 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_assoc_2414);
    }
    V v_t_2418 = heff_strAppend(heff_strAppend(v_id_2413, heff_dup(v_lit_240)), heff_intShow(v_t_2417));
    V v_t_2419;
    if ((heff_dup(v_loosest_2415) == NTAG(TAG_True))) {
      heff_drop(v_loosest_2415);
      v_t_2419 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_loosest_2415);
      v_t_2419 = heff_dup(v_lit_245);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2419), heff_dup(v_lit_246));
    V v_t_2423;
    switch (heff_tag_of(v_ops_2416)) {
    case TAG_Nil: {
      v_t_2423 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2421 = heff_field(v_ops_2416, 0);
      V v_a_2422 = heff_field(v_ops_2416, 1);
      heff_take_n(v_ops_2416, 3ULL, 2);
      v_t_2423 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2421; V a_2 = v_a_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2422); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2416);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2420, v_t_2423), heff_hole()});
    V v_u_2425 = heff_setField(v_d_2410, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_xs_2412;
    V t_10 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_x2_249 = t_9;
    v_d_2410 = t_10;
    goto top;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s224183526x935259397_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s224183526x935259397_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2ekeepIf_24s537296923x1092827761_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s537296923x1092827761_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s537296923x1092827761_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s537296923x1092827761_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s537296923x1092827761_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s675147852x248982264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_24dps_entry, 3, 0};

V g_list_2emap_24s675147852x248982264_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_path_245 = heff_take_field(v_x_243, 1);
    V v_version_246 = heff_get_n(v_x_243, 2, 3);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), v_path_245, v_version_246}), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s388004800x1261967008_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_24dps_entry, 2, 0};

V g_list_2emap_24s388004800x1261967008_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s257286374x378693326_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s257286374x378693326_entry, 2, 0};

V g_list_2ekeepIf_24s257286374x378693326(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_244)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s257286374x378693326_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s257286374x378693326(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str0, 7, "integer");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str1, 6, "binary");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str2, 4, "bits");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str3, 5, "float");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str4, 3, "utf");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str5, 7, "default");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str6, 1, "*");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str7, 4, "true");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str8, 5, "false");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str9, 4, "true");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str10, 5, "false");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str11, 1, " ");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str12, 0, "");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str13, 0, "");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str14, 8, "(segment");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_24dps_str15, 1, ")");
Clo g_list_2emap_24s2016443462x370533815_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016443462x370533815_24dps_entry, 2, 0};

V g_list_2emap_24s2016443462x370533815_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2429;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 1ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_MkSegment: {
        V v_v_247 = heff_field(v_x21_245, 0);
        V v_ty_248 = heff_field(v_x21_245, 1);
        V v_size_249 = heff_field(v_x21_245, 2);
        V v_little_2410 = heff_field(v_x21_245, 3);
        V v_signed_2411 = heff_field(v_x21_245, 4);
        heff_take_n(v_x21_245, 31ULL, 5);
        V v_t_2412 = (g_heff_2esyntax_2eformat_2epatKey(v_v_247));
        V v_t_2414;
        switch (heff_tag_of(v_ty_248)) {
        case TAG_SegmentInteger: {
          v_t_2414 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str0);
          break;
        }
        case TAG_SegmentBinary: {
          v_t_2414 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str1);
          break;
        }
        case TAG_SegmentBits: {
          v_t_2414 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str2);
          break;
        }
        case TAG_SegmentFloat: {
          v_t_2414 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str3);
          break;
        }
        case TAG_SegmentUtf: {
          V v_n_2413 = heff_field(v_ty_248, 0);
          heff_take_n(v_ty_248, 1ULL, 1);
          v_t_2414 = heff_strAppend(((V)&g_list_2emap_24s2016443462x370533815_24dps_str4), heff_intShow(v_n_2413));
          break;
        }
        default: heff_nomatch(v_ty_248);
        }
        V v_t_2419;
        switch (heff_tag_of(v_size_249)) {
        case TAG_SizeDefault: {
          v_t_2419 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str5);
          break;
        }
        case TAG_SizeNumber: {
          V v_n_2415 = heff_field(v_size_249, 0);
          heff_take_n(v_size_249, 1ULL, 1);
          v_t_2419 = heff_intShow(v_n_2415);
          break;
        }
        case TAG_SizeName: {
          V v_x_2416 = heff_field(v_size_249, 0);
          V v_unit_2418 = heff_field(v_size_249, 2);
          heff_take_n(v_size_249, 5ULL, 3);
          v_t_2419 = heff_strAppend(heff_strAppend(v_x_2416, ((V)&g_list_2emap_24s2016443462x370533815_24dps_str6)), heff_intShow(v_unit_2418));
          break;
        }
        default: heff_nomatch(v_size_249);
        }
        V v_t_2420;
        if ((heff_dup(v_little_2410) == NTAG(TAG_True))) {
          heff_drop(v_little_2410);
          v_t_2420 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str7);
        } else {
          heff_drop(v_little_2410);
          v_t_2420 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str8);
        }
        V v_t_2421;
        if ((heff_dup(v_signed_2411) == NTAG(TAG_True))) {
          heff_drop(v_signed_2411);
          v_t_2421 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str9);
        } else {
          heff_drop(v_signed_2411);
          v_t_2421 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str10);
        }
        V v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        V v_t_2423 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_Cons, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
        V v_parts_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2423})});
        V v_x2_2425 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s2016443462x370533815_24dps_str11), v_parts_2424));
        V v_t_2428;
        switch (heff_tag_of(v_x2_2425)) {
        case TAG_Nil: {
          v_t_2428 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_x2_2425, 0);
          V v_xs_2427 = heff_field(v_x2_2425, 1);
          heff_take_n(v_x2_2425, 3ULL, 2);
          v_t_2428 = ({ V a_0 = ((V)&g_list_2emap_24s2016443462x370533815_24dps_str13); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2425);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2016443462x370533815_24dps_str14), v_t_2428), ((V)&g_list_2emap_24s2016443462x370533815_24dps_str15));
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
    heff_drop(v_u_2431);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2430;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016443462x370533815_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s741838803x941779121_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s741838803x941779121_entry, 1, 0};

V g_list_2ekeepIf_24s741838803x941779121(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 2)), 6, 10);
    if (!(heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s741838803x941779121_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s741838803x941779121_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s741838803x941779121(a[0]);
}

HeffT2 g_list_2efind_24s792771115x178990339_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_list_2eany_24s1032636598x1013662416_str0, 8, "quickfix");
Clo g_list_2eany_24s1032636598x1013662416_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1032636598x1013662416_entry, 1, 0};

V g_list_2eany_24s1032636598x1013662416(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JInt: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JString: {
      V v_k_246 = heff_field(v_x_241, 0);
      V v_t_247 = heff_strSlice(((V)&g_list_2eany_24s1032636598x1013662416_str0), MK_INT(0LL), heff_strLength_lent(v_k_246, 0));
      if (heff_strEq_c_lent(v_t_247, v_k_246, 1)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
    case TAG_JArray: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_JObject: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1032636598x1013662416(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s857425298x1024652640_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s857425298x1024652640_entry, 1, 0};

V g_list_2emap_24s857425298x1024652640(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V rv_1 = NTAG(TAG_Inverse); V rr_ = heff_rec_reuse_nf(v_x_241, 1ULL, 2, shape_text__style, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s857425298x1024652640_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s857425298x1024652640(a[0]);
}
Clo g_list_2emap_24s857425298x1024652640_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s857425298x1024652640_24dps_entry, 2, 0};

V g_list_2emap_24s857425298x1024652640_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rv_1 = NTAG(TAG_Inverse); V rr_ = heff_rec_reuse_nf(v_x_242, 1ULL, 2, shape_text__style, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s857425298x1024652640_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s857425298x1024652640_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f719546030x1732151491_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f719546030x1732151491_entry, 2, 0};

V g_list_2emap_24f719546030x1732151491(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_244 = heff_take_field(v_x_242, 0);
    V v_looser_245 = heff_get_n(v_x_242, 1, 2);
    if (heff_strEq_c_lent(v_tighter_244, v_lit_240, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_looser_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f719546030x1732151491_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_looser_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f719546030x1732151491_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f719546030x1732151491(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f1922461191x750914054_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1922461191x750914054_entry, 4, 0};

V g_list_2efoldl_24f1922461191x750914054(V v_z_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_244, 1);
      v_t_248 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_x_249 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = heff_intAdd(v_z_240, v_x_249);
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_245;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1922461191x750914054(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f496521120x176206934_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f496521120x176206934_entry, 3, 0};

V g_list_2efoldl_24f496521120x176206934(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_x_243, 2));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f496521120x176206934(a[0], a[1], a2); heff_drop(a2); return r;
}