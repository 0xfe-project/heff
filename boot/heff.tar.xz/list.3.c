// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Boxed 28180
#define TAG_CDrop 58400
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Many 40086
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PVar 52952
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_Rest 61983
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_Some 35657
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Wants 58903
#define LBL_absolute 325777132
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_def 308863
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_library 398066429
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2eglobalOfPart(V);
V g_heff_2ecompile_2eemit_2eglobalOfPart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalOfPart_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(V);
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_list_2eall_24s1251569107x847515346(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1251569107x847515346_entry(V self, V *a);
extern Clo g_list_2eall_24s1251569107x847515346_clo;
V g_list_2eany_24s1081981235x855852216(V, V);
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a);
extern Clo g_list_2eany_24s1081981235x855852216_clo;
V g_list_2eany_24s150647489x375460461(V, V);
V g_list_2eany_24s150647489x375460461_entry(V self, V *a);
extern Clo g_list_2eany_24s150647489x375460461_clo;
V g_list_2eany_24s1681212806x1534785672(V, V, V);
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a);
extern Clo g_list_2eany_24s1681212806x1534785672_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1330420811x172858565_24dps(V, V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_24dps_clo;
V g_list_2efilter_24s1351460748x1231260144(V, V);
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_clo;
V g_list_2efilter_24s1351460748x1231260144_24dps(V, V, V);
V g_list_2efilter_24s1351460748x1231260144_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_24dps_clo;
V g_list_2efilter_24s1716878720x675187502(V, V);
V g_list_2efilter_24s1716878720x675187502_entry(V self, V *a);
extern Clo g_list_2efilter_24s1716878720x675187502_clo;
V g_list_2efilter_24s1716878720x675187502_24dps(V, V, V);
V g_list_2efilter_24s1716878720x675187502_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1716878720x675187502_24dps_clo;
V g_list_2efilter_24s179107915x1917665184_24dps(V, V);
V g_list_2efilter_24s179107915x1917665184_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s179107915x1917665184_24dps_clo;
V g_list_2efilter_24s2009824277x1398398543(V, V, V);
V g_list_2efilter_24s2009824277x1398398543_entry(V self, V *a);
extern Clo g_list_2efilter_24s2009824277x1398398543_clo;
V g_list_2efilter_24s2009824277x1398398543_24dps(V, V, V, V);
V g_list_2efilter_24s2009824277x1398398543_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2009824277x1398398543_24dps_clo;
V g_list_2efilter_24s2016771181x401513202_24dps(V, V, V, V);
V g_list_2efilter_24s2016771181x401513202_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2016771181x401513202_24dps_clo;
V g_list_2efilter_24s716173495x680820632(V, V);
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_clo;
V g_list_2efilter_24s716173495x680820632_24dps(V, V, V);
V g_list_2efilter_24s716173495x680820632_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_24dps_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
V g_list_2efilter_24s999680916x306845608_24dps(V, V, V);
V g_list_2efilter_24s999680916x306845608_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_24dps_clo;
V g_list_2efind_24s1236173780x2048419812(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1236173780x2048419812_entry(V self, V *a);
extern Clo g_list_2efind_24s1236173780x2048419812_clo;
V g_list_2efind_24s1541406305x377496150(V, V);
V g_list_2efind_24s1541406305x377496150_entry(V self, V *a);
extern Clo g_list_2efind_24s1541406305x377496150_clo;
V g_list_2efind_24s1990539953x112149757(V, V);
V g_list_2efind_24s1990539953x112149757_entry(V self, V *a);
extern Clo g_list_2efind_24s1990539953x112149757_clo;
V g_list_2efind_24s575827429x1292946038(V, V);
V g_list_2efind_24s575827429x1292946038_entry(V self, V *a);
extern Clo g_list_2efind_24s575827429x1292946038_clo;
V g_list_2efind_24s582687515x818787580(V, V);
V g_list_2efind_24s582687515x818787580_entry(V self, V *a);
extern Clo g_list_2efind_24s582687515x818787580_clo;
V g_list_2efoldl_24f1128388138x103163567(V, V, V, V);
V g_list_2efoldl_24f1128388138x103163567_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1128388138x103163567_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24f765463553x1160475073(V, V, V, V, V, V, V);
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a);
extern Clo g_list_2efoldl_24f765463553x1160475073_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s1732572494x729779974(V, V);
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1732572494x729779974_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s29004368x870998936(V, V);
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a);
extern Clo g_list_2efoldl_24s29004368x870998936_clo;
V g_list_2efoldl_24s31530661x2067693293(V, V);
V g_list_2efoldl_24s31530661x2067693293_entry(V self, V *a);
extern Clo g_list_2efoldl_24s31530661x2067693293_clo;
V g_list_2efoldl_24s407249128x802036125(V, V);
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s407249128x802036125_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s544151770x491236151(V, V);
V g_list_2efoldl_24s544151770x491236151_entry(V self, V *a);
extern Clo g_list_2efoldl_24s544151770x491236151_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s787927001x2102341300(V, V);
V g_list_2efoldl_24s787927001x2102341300_entry(V self, V *a);
extern Clo g_list_2efoldl_24s787927001x2102341300_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2emap_24f1156519715x726760149(V);
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_clo;
V g_list_2emap_24f1156519715x726760149_24dps(V, V);
V g_list_2emap_24f1156519715x726760149_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_24dps_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24f1293205645x619162872_24dps(V, V, V, V, V);
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_24dps_clo;
V g_list_2emap_24f130772758x674845987_24dps(V, V, V, V, V);
V g_list_2emap_24f130772758x674845987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24dps_clo;
V g_list_2emap_24f1451184245x2111935062(V, V, V, V, V, V, V);
V g_list_2emap_24f1451184245x2111935062_entry(V self, V *a);
extern Clo g_list_2emap_24f1451184245x2111935062_clo;
V g_list_2emap_24f1451184245x2111935062_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f1451184245x2111935062_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1451184245x2111935062_24dps_clo;
V g_list_2emap_24f1548644028x2098102081(V, V);
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_clo;
V g_list_2emap_24f1548644028x2098102081_24dps(V, V, V);
V g_list_2emap_24f1548644028x2098102081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_24dps_clo;
V g_list_2emap_24f1819215186x476901667_24dps(V, V, V, V, V);
V g_list_2emap_24f1819215186x476901667_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_24dps_clo;
V g_list_2emap_24f88106788x1680212182(V);
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_clo;
V g_list_2emap_24f88106788x1680212182_24dps(V, V);
V g_list_2emap_24f88106788x1680212182_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f88106788x1680212182_24dps_clo;
V g_list_2emap_24f990982947x2126256822_24dps(V, V, V);
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_24dps_clo;
V g_list_2emap_24s1150457979x1978067071_24dps(V, V);
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1183242293x627656570(V, V);
V g_list_2emap_24s1183242293x627656570_entry(V self, V *a);
extern Clo g_list_2emap_24s1183242293x627656570_clo;
V g_list_2emap_24s1183242293x627656570_24dps(V, V, V);
V g_list_2emap_24s1183242293x627656570_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1183242293x627656570_24dps_clo;
V g_list_2emap_24s1234524601x742515152_24dps(V, V);
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_24dps_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s129316455x2072694707_24dps(V, V);
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_24dps_clo;
V g_list_2emap_24s1372232877x278600396_24dps(V, V);
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_24dps_clo;
V g_list_2emap_24s1420651609x666245096_24dps(V, V);
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_24dps_clo;
V g_list_2emap_24s1455783996x1449538216(V);
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_clo;
V g_list_2emap_24s1455783996x1449538216_24dps(V, V);
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_24dps_clo;
V g_list_2emap_24s1512999845x472671375_24dps(V, V, V, V, V, V);
V g_list_2emap_24s1512999845x472671375_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512999845x472671375_24dps_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1690674600x556093466(V);
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s1814289659x520383890(V, V, V);
V g_list_2emap_24s1814289659x520383890_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_clo;
V g_list_2emap_24s1814289659x520383890_24dps(V, V, V, V);
V g_list_2emap_24s1814289659x520383890_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_24dps_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s1901363476x1479927424_24dps(V, V);
V g_list_2emap_24s1901363476x1479927424_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_24dps_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s2016443462x370533815_24dps(V, V);
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_24dps_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2081626528x1476576812_24dps(V, V);
V g_list_2emap_24s2081626528x1476576812_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_24dps_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s353858844x950951807_24dps(V, V, V, V, V);
V g_list_2emap_24s353858844x950951807_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_24dps_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s388004800x1261967008_24dps(V, V);
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_24dps_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s420582357x1720502382_24dps(V, V);
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_24dps_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s435407392x1528135477_24dps(V, V);
V g_list_2emap_24s435407392x1528135477_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_24dps_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s60612435x257154841_24dps(V, V);
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_24dps_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s732475005x1616712052_24dps(V, V);
V g_list_2emap_24s732475005x1616712052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_24dps_clo;
V g_list_2emap_24s796727596x829078925_24dps(V, V);
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_24dps_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2emap_24s890213172x1049425163_24dps(V, V);
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_24dps_clo;
V g_list_2emap_24s966611702x135720910_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s966611702x135720910_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s966611702x135720910_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1037857700x2096250953(V, V);
V g_list_2emerge_24s1037857700x2096250953_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_clo;
V g_list_2emerge_24s1081221956x1079757426(V, V);
V g_list_2emerge_24s1081221956x1079757426_entry(V self, V *a);
extern Clo g_list_2emerge_24s1081221956x1079757426_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s509014022x1733915733(V, V);
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_clo;
V g_list_2emerge_24s509014022x1733915733_24dps(V, V, V);
V g_list_2emerge_24s509014022x1733915733_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s509014022x1733915733_24dps_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2esortBy_24s655524619x299640735(V);
V g_list_2esortBy_24s655524619x299640735_entry(V self, V *a);
extern Clo g_list_2esortBy_24s655524619x299640735_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s706961545x2112949112_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_244 = (g_list_2ereplicate_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_entry, 2, 0};

V g_list_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = (g_list_2etake(heff_intDiv(v_t_246, MK_INT(2LL)), heff_dup(v_xs_241)));
      V v_t_248 = (g_list_2esortBy(heff_dup(v_le_240), v_t_247));
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2410 = (g_list_2edrop(heff_intDiv(v_t_249, MK_INT(2LL)), v_xs_241));
      V v_t_2411 = (g_list_2esortBy(heff_dup(v_le_240), v_t_2410));
      return (g_list_2emerge(v_le_240, v_t_248, v_t_2411));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy(a[0], a[1]);
}
Clo g_list_2emap_24s1173914895x100384474_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_24dps_entry, 2, 0};

V g_list_2emap_24s1173914895x100384474_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s1236173780x2048419812_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1236173780x2048419812_entry, 11, 0};

V g_list_2efind_24s1236173780x2048419812(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_t_2413;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_I8: {
      v_t_2413 = heff_dup(v_lit_240);
      break;
    }
    case TAG_I16: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I32: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I64: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    case TAG_U8: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U16: {
      v_t_2413 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U32: {
      v_t_2413 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U64: {
      v_t_2413 = heff_dup(v_lit_247);
      break;
    }
    case TAG_F32: {
      v_t_2413 = heff_dup(v_lit_248);
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_249, 1)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      heff_drop(v_lit_249);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2411)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2efind_24s1236173780x2048419812_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_list_2efind_24s1236173780x2048419812(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
Clo g_list_2efilter_24s716173495x680820632_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s716173495x680820632_entry, 2, 0};

V g_list_2efilter_24s716173495x680820632(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s716173495x680820632_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s716173495x680820632(a[0], a[1]);
}
Clo g_list_2emap_24s584454411x1006678865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_entry, 1, 0};

V g_list_2emap_24s584454411x1006678865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s584454411x1006678865_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865(a[0]);
}
Clo g_list_2esortBy_24s88152486x2058486153_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s88152486x2058486153_entry, 1, 0};

V g_list_2esortBy_24s88152486x2058486153(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s88152486x2058486153(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s88152486x2058486153(v_t_249));
      return (g_list_2emerge_24s1347843181x1368204458(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s88152486x2058486153(a[0]);
}
Clo g_list_2esortBy_24s655524619x299640735_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s655524619x299640735_entry, 1, 0};

V g_list_2esortBy_24s655524619x299640735(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s655524619x299640735(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s655524619x299640735(v_t_249));
      return (g_list_2emerge_24s1081221956x1079757426(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s655524619x299640735_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s655524619x299640735(a[0]);
}
Clo g_list_2emap_24s2081626528x1476576812_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081626528x1476576812_24dps_entry, 2, 0};

V g_list_2emap_24s2081626528x1476576812_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081626528x1476576812_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081626528x1476576812_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1150457979x1978067071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_24dps_entry, 2, 0};

V g_list_2emap_24s1150457979x1978067071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgExplicit = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2410});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2411 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgProject = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24ArgNamed = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ArgNamed, TAG_ArgNamed, 2, (V[]){v_a_2412, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s366989016x166432442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_24dps_entry, 2, 0};

V g_list_2emap_24s366989016x166432442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s474585387x1072098790_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_24dps_entry, 2, 0};

V g_list_2emap_24s474585387x1072098790_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ExplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_a_2414 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24ImplicitParam = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2417;
        switch (heff_tag_of(v_a_2414)) {
        case TAG_At: {
          V v_a_2415 = heff_field(v_a_2414, 0);
          V v_a_2416 = heff_field(v_a_2414, 1);
          heff_take_n(v_a_2414, 3ULL, 2);
          v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2416, v_a_2415));
          break;
        }
        default: heff_nomatch(v_a_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2412, v_a_2413, v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1624059865x1140896478_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_24dps_entry, 2, 0};

V g_list_2emap_24s1624059865x1140896478_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2esurface_2easNameE(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1330420811x172858565_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1330420811x172858565_24dps_entry, 5, 0};

V g_list_2efilter_24s1330420811x172858565_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_245, 1)));
    if (heff_intEq_c(v_t_247, heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_245, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1330420811x172858565_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1330420811x172858565_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s338694954x1326523169_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_entry, 1, 0};

V g_list_2emap_24s338694954x1326523169(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get_n(v_x_241, 2, 3), v_t_243, NTAG(TAG_Nothing)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s338694954x1326523169_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169(a[0]);
}
Clo g_list_2emap_24s60612435x257154841_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_24dps_entry, 2, 0};

V g_list_2emap_24s60612435x257154841_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s29004368x870998936_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s29004368x870998936_entry, 2, 0};

V g_list_2efoldl_24s29004368x870998936(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_RepV)});
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_245});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s29004368x870998936(a[0], a[1]);
}
Clo g_list_2efoldl_24s657006386x1833506039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s657006386x1833506039_entry, 2, 0};

V g_list_2efoldl_24s657006386x1833506039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s657006386x1833506039(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s445268946x679229867_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s445268946x679229867_entry, 2, 0};

V g_list_2efoldl_24s445268946x679229867(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecallarity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s445268946x679229867(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_entry, 1, 0};

V g_list_2emap_24s1181937096x2120532116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_x_241), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1181937096x2120532116_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1181937096x2120532116_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116(a[0]);
}
Clo g_list_2emap_24s966611702x135720910_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s966611702x135720910_24dps_entry, 8, 0};

V g_list_2emap_24s966611702x135720910_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2410, heff_dup(v_lit_242)));
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s966611702x135720910_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s966611702x135720910_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s978059622x523571930_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s978059622x523571930_entry, 2, 0};

V g_list_2efoldl_24s978059622x523571930(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s978059622x523571930(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1990719097x1419059608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_24dps_entry, 2, 0};

V g_list_2emap_24s1990719097x1419059608_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(v_x_242, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s738847920x410598254_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_entry, 2, 0};

V g_list_2ezipWith_24s738847920x410598254(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), heff_hole()});
      V v_u_2415 = (g_list_2ezipWith_24s738847920x410598254_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254(a[0], a[1]);
}
Clo g_list_2emap_24s1690674600x556093466_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_entry, 1, 0};

V g_list_2emap_24s1690674600x556093466(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1690674600x556093466_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1690674600x556093466(a[0]);
}
Clo g_list_2efoldl_24s1548442597x958354846_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1548442597x958354846_entry, 2, 0};

V g_list_2efoldl_24s1548442597x958354846(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1548442597x958354846(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s826961155x1314392429_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s826961155x1314392429_entry, 2, 0};

V g_list_2efoldl_24s826961155x1314392429(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s826961155x1314392429(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1901363476x1479927424_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1901363476x1479927424_entry, 1, 0};

V g_list_2emap_24s1901363476x1479927424(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_241, NTAG(TAG_Nothing)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_t_243}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1901363476x1479927424_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1901363476x1479927424(a[0]);
}
Clo g_list_2eany_24s1681212806x1534785672_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1681212806x1534785672_entry, 3, 0};

V g_list_2eany_24s1681212806x1534785672(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_t_2411;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_2410 = heff_field(v_x_243, 1);
        v_t_2411 = heff_dup(v_a_2410);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      if (heff_strEq_c_lent(v_t_2411, v_lit_241, 1)) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1681212806x1534785672_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s1681212806x1534785672(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efilter_24s179107915x1917665184_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s179107915x1917665184_24dps_entry, 2, 0};

V g_list_2efilter_24s179107915x1917665184_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_RepV: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_249, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s179107915x1917665184_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s179107915x1917665184_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1651310864x859456474_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1651310864x859456474_entry, 2, 0};

V g_list_2efoldl_24s1651310864x859456474(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1651310864x859456474(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s31530661x2067693293_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s31530661x2067693293_entry, 2, 0};

V g_list_2efoldl_24s31530661x2067693293(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s31530661x2067693293_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s31530661x2067693293(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1455783996x1449538216_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_entry, 1, 0};

V g_list_2emap_24s1455783996x1449538216(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2eglobalOfPart(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1455783996x1449538216_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1455783996x1449538216(a[0]);
}
Clo g_list_2emap_24s1455783996x1449538216_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_24dps_entry, 2, 0};

V g_list_2emap_24s1455783996x1449538216_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eglobalOfPart(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1455783996x1449538216_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s732475005x1616712052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_entry, 1, 0};

V g_list_2emap_24s732475005x1616712052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2eexportNameOf(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s732475005x1616712052_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052(a[0]);
}
Clo g_list_2eany_24s651308273x925219243_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s651308273x925219243_entry, 1, 0};

V g_list_2eany_24s651308273x925219243(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s651308273x925219243_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s651308273x925219243(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s129316455x2072694707_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_entry, 1, 0};

V g_list_2emap_24s129316455x2072694707(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s129316455x2072694707_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707(a[0]);
}
Clo g_list_2emap_24s129316455x2072694707_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_24dps_entry, 2, 0};

V g_list_2emap_24s129316455x2072694707_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_244), v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_24dps_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_24dps_entry, 2, 0};

V g_list_2emap_24s420582357x1720502382_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s420582357x1720502382_24dps_str0)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s706961545x2112949112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s706961545x2112949112_24dps_entry, 6, 0};

V g_list_2ezipWith_24s706961545x2112949112_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_243, 0);
    V v_xs2_247 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs2_247);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_ys_244, 0);
      V v_ys2_249 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_246, heff_dup(v_lit_242)));
      V v_t_2411 = heff_strAppend(heff_intShow(v_y_248), v_t_2410);
      V v_cell_2412 = heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2411), heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs2_247;
      V t_4 = v_ys2_249;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_xs_243 = t_3;
      v_ys_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s706961545x2112949112_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s706961545x2112949112_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s353858844x950951807_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s353858844x950951807_24dps_entry, 5, 0};

V g_list_2emap_24s353858844x950951807_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_intShow(heff_dup(v_x_245)), heff_dup(v_lit_242));
    V v_t_248 = heff_strAppend(heff_intShow(v_x_245), heff_strAppend(heff_dup(v_lit_241), v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_248), heff_hole()});
    V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s353858844x950951807_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s353858844x950951807_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s2073083146x1445066245_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_24dps_entry, 2, 0};

V g_list_2emap_24s2073083146x1445066245_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1732572494x729779974_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1732572494x729779974_entry, 2, 0};

V g_list_2efoldl_24s1732572494x729779974(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_a_244, 2)));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_a_244, 0, 3), v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1732572494x729779974_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1732572494x729779974(a[0], a[1]);
}
Clo g_list_2efoldl_24s544151770x491236151_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s544151770x491236151_entry, 2, 0};

V g_list_2efoldl_24s544151770x491236151(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      v_t_2412 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s544151770x491236151_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s544151770x491236151(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s1990539953x112149757_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1990539953x112149757_entry, 2, 0};

V g_list_2efind_24s1990539953x112149757(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 7);
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1990539953x112149757_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1990539953x112149757(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1817208647x1282894070_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_entry, 1, 0};

V g_list_2emap_24s1817208647x1282894070(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1817208647x1282894070_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817208647x1282894070(a[0]);
}
Clo g_list_2emap_24s796727596x829078925_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s796727596x829078925_24dps_entry, 2, 0};

V g_list_2emap_24s796727596x829078925_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s796727596x829078925_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1183242293x627656570_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1183242293x627656570_entry, 2, 0};

V g_list_2emap_24s1183242293x627656570(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_rec_n(3, shape_name__key__module, (V[]){heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 1, 2), heff_dup(heff_rfield(v_lit_240, 0))});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1183242293x627656570_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1183242293x627656570_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1183242293x627656570(a[0], a[1]);
}
Clo g_list_2emap_24s1183242293x627656570_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1183242293x627656570_24dps_entry, 3, 0};

V g_list_2emap_24s1183242293x627656570_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_rec_n(3, shape_name__key__module, (V[]){heff_take_field(v_x_243, 0), heff_get_n(v_x_243, 1, 2), heff_dup(heff_rfield(v_lit_240, 0))});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1183242293x627656570_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1183242293x627656570_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1512999845x472671375_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512999845x472671375_24dps_entry, 6, 0};

V g_list_2emap_24s1512999845x472671375_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_242), heff_strLength_lent(v_a_248, 0));
    V v_t_2413;
    if (heff_strEq_c(v_t_249, v_a_248)) {
      V v_t_2411 = heff_intAdd(heff_strLength_lent(v_lit_240, 0), heff_dup(v_lit_243));
      V v_t_2412 = heff_strSlice(heff_dup(v_x_246), v_t_2411, heff_strLength_lent(v_x_246, 0));
      v_t_2413 = heff_rec_n(2, shape_name__key, (V[]){v_t_2412, v_x_246});
    } else {
      v_t_2413 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_246), v_x_246});
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2414;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1512999845x472671375_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1512999845x472671375_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2eany_24s150647489x375460461_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s150647489x375460461_entry, 2, 0};

V g_list_2eany_24s150647489x375460461(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      V v_a_245 = heff_dup(heff_rfield(v_x_242, 1));
      V v_t_246 = heff_dup(heff_rfield(v_lit_240, 1));
      V v_t_2410;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_Nothing: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_Just: {
        V v_a_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_Nothing: {
          heff_drop(v_a_248);
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_a_249 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_2410 = heff_strEq(v_a_248, v_a_249);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_lit_240, 3);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s150647489x375460461_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s150647489x375460461(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s787927001x2102341300_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s787927001x2102341300_entry, 2, 0};

V g_list_2efoldl_24s787927001x2102341300(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 5)), heff_dup(heff_rfield(v_x_242, 3))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 4), v_t_244));
    V v_t_246 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s787927001x2102341300_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s787927001x2102341300(a[0], a[1]);
}
Clo g_list_2efoldl_24s407249128x802036125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s407249128x802036125_entry, 2, 0};

V g_list_2efoldl_24s407249128x802036125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s407249128x802036125(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1895313378x47656836_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_entry, 1, 0};

V g_list_2emap_24s1895313378x47656836(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1895313378x47656836_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836(a[0]);
}
Clo g_list_2emap_24s2016443462x370533815_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016443462x370533815_24dps_entry, 2, 0};

V g_list_2emap_24s2016443462x370533815_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016443462x370533815_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s1251569107x847515346_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1251569107x847515346_entry, 13, 0};

V g_list_2eall_24s1251569107x847515346(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_t_2416 = heff_bool((heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_2413)) && heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_241))));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    } else {
      heff_drop(v_t_2416);
      V v_t_2423 = heff_bool((heff_intLe_c(heff_dup(v_lit_242), heff_dup(v_x_2413)) ? (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_243)) || (heff_intLe_c(heff_dup(v_lit_244), heff_dup(v_x_2413)) ? (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_245)) || heff_intEq_c(heff_dup(v_x_2413), heff_dup(v_lit_246))) : heff_intEq_c(heff_dup(v_x_2413), heff_dup(v_lit_247)))) : (heff_intLe_c(heff_dup(v_lit_248), heff_dup(v_x_2413)) ? (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_249)) || heff_intEq_c(heff_dup(v_x_2413), heff_dup(v_lit_2410))) : heff_intEq_c(heff_dup(v_x_2413), heff_dup(v_lit_2411)))));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_t_2423);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        heff_drop(v_lit_2410);
        heff_drop(v_lit_2411);
        heff_drop(v_t_2423);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_list_2eall_24s1251569107x847515346_entry(V self, V *a) {
  (void)self;
  V a12 = a[12]; V r = g_list_2eall_24s1251569107x847515346(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a12); heff_drop(a12); return r;
}
Clo g_list_2emap_24s890213172x1049425163_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_entry, 1, 0};

V g_list_2emap_24s890213172x1049425163(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s890213172x1049425163_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163(a[0]);
}
Clo g_list_2emap_24s890213172x1049425163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s890213172x1049425163_24dps_entry, 2, 0};

V g_list_2emap_24s890213172x1049425163_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s890213172x1049425163_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s890213172x1049425163_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1725521117x1379101383_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1725521117x1379101383_entry, 7, 0};

V g_list_2efoldl_24s1725521117x1379101383(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_z_245, V v_x3_246) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 3);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return v_z_245;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_246, 0);
    V v_xs_248 = heff_field(v_x3_246, 1);
    V v_ru_24x3_246_24Cons = heff_take_reuse_n(v_x3_246, 3ULL, 2);
    V v_t_2414;
    if (heff_strEq_c_lent(v_x_247, v_lit_240, 0)) {
      heff_drop(v_x_247);
      switch (heff_tag_of(v_z_245)) {
      case TAG_Nil: {
        V v_t_2410 = heff_dup(heff_rfield(v_lit_241, 1));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          heff_drop(v_t_2410);
          v_t_2414 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2410);
          v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_242), NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_Cons: {
        V v_a_2411 = heff_dup(heff_field(v_z_245, 0));
        V v_a_2412 = heff_dup(heff_field(v_z_245, 1));
        if (heff_strEq_c_lent(v_a_2411, v_lit_243, 1)) {
          heff_drop(v_a_2412);
          v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_244), v_z_245});
        } else {
          heff_drop_tag(v_z_245, 2);
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2414 = v_a_2412;
        }
        break;
      }
      default: heff_nomatch(v_z_245);
      }
    } else {
      v_t_2414 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_245});
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_t_2414;
    V t_6 = v_xs_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_z_245 = t_5;
    v_x3_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1725521117x1379101383(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s675147852x248982264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_24dps_entry, 3, 0};

V g_list_2emap_24s675147852x248982264_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), heff_take_field(v_x_243, 1), heff_get_n(v_x_243, 2, 3)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1081981235x855852216_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1081981235x855852216_entry, 2, 0};

V g_list_2eany_24s1081981235x855852216(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1081981235x855852216_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1081981235x855852216(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s435407392x1528135477_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s435407392x1528135477_entry, 1, 0};

V g_list_2emap_24s435407392x1528135477(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s435407392x1528135477_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s435407392x1528135477(a[0]);
}
Clo g_list_2emerge_24s509014022x1733915733_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s509014022x1733915733_entry, 2, 0};

V g_list_2emerge_24s509014022x1733915733(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s509014022x1733915733_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s509014022x1733915733_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s509014022x1733915733_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s509014022x1733915733(a[0], a[1]);
}
Clo g_list_2esortBy_24s1681607803x465385494_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1681607803x465385494_entry, 1, 0};

V g_list_2esortBy_24s1681607803x465385494(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s1681607803x465385494(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s1681607803x465385494(v_t_249));
      return (g_list_2emerge_24s1037857700x2096250953(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1681607803x465385494(a[0]);
}
Clo g_list_2efind_24s582687515x818787580_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s582687515x818787580_entry, 2, 0};

V g_list_2efind_24s582687515x818787580(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_a_245, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_get_n(v_a_245, 1, 2))) {
        heff_drop_rec(v_lit_240, 3);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      heff_drop_rec(v_a_245, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s582687515x818787580_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s582687515x818787580(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s388004800x1261967008_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388004800x1261967008_24dps_entry, 2, 0};

V g_list_2emap_24s388004800x1261967008_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 2, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388004800x1261967008_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s388004800x1261967008_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1975553568x1034350329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1975553568x1034350329_entry, 2, 0};

V g_list_2efoldl_24s1975553568x1034350329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1975553568x1034350329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1716878720x675187502_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1716878720x675187502_entry, 2, 0};

V g_list_2efilter_24s1716878720x675187502(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    if (heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), v_t_244)) {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
      if (heff_intLe_c(v_t_246, heff_dup(heff_rfield(v_lit_240, 1)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_249 = (g_list_2efilter_24s1716878720x675187502_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_rec(v_x_242, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1716878720x675187502_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1716878720x675187502(a[0], a[1]);
}
Clo g_list_2emap_24s1234524601x742515152_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1234524601x742515152_24dps_entry, 2, 0};

V g_list_2emap_24s1234524601x742515152_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1234524601x742515152_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1234524601x742515152_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1420651609x666245096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_24dps_entry, 2, 0};

V g_list_2emap_24s1420651609x666245096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1814289659x520383890_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1814289659x520383890_entry, 3, 0};

V g_list_2emap_24s1814289659x520383890(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      v_t_246 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_243, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_246 = v_x_243;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1814289659x520383890_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1814289659x520383890_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1814289659x520383890(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s580776739x648604941_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_24dps_entry, 2, 0};

V g_list_2emap_24s580776739x648604941_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_args_248 = heff_field(v_x11_244, 2);
        heff_take_n(v_x11_244, 5ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_246, v_args_248})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1372232877x278600396_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1372232877x278600396_24dps_entry, 2, 0};

V g_list_2emap_24s1372232877x278600396_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2elsp_2esplit_2eexprName(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1372232877x278600396_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s999680916x306845608_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s999680916x306845608_entry, 2, 0};

V g_list_2efilter_24s999680916x306845608(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s999680916x306845608_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s999680916x306845608(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str0, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str1, 6, "detail");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str2, 5, "label");
Clo g_list_2emap_24s4199228x1154005405_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_entry, 1, 0};

V g_list_2emap_24s4199228x1154005405(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_241, 0)});
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_241, 1, 2)});
    V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str2), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_247}), heff_hole()});
    V v_u_249 = (g_list_2emap_24s4199228x1154005405_24dps(v_xs_242, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405(a[0]);
}
Clo g_list_2efilter_24s1351460748x1231260144_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1351460748x1231260144_entry, 2, 0};

V g_list_2efilter_24s1351460748x1231260144(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intLe_c(v_t_246, heff_dup(v_lit_240))) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1351460748x1231260144_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1351460748x1231260144(a[0], a[1]);
}
Clo g_list_2efilter_24s1351460748x1231260144_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1351460748x1231260144_24dps_entry, 3, 0};

V g_list_2efilter_24s1351460748x1231260144_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_intLe_c(v_t_247, heff_dup(v_lit_240))) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1351460748x1231260144_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1351460748x1231260144_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s575827429x1292946038_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s575827429x1292946038_entry, 2, 0};

V g_list_2efind_24s575827429x1292946038(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s575827429x1292946038_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s575827429x1292946038(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s2009824277x1398398543_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2009824277x1398398543_entry, 3, 0};

V g_list_2efilter_24s2009824277x1398398543(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_245, v_lit_241, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s2009824277x1398398543_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s2009824277x1398398543_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2009824277x1398398543(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_entry, 1, 0};

V g_list_2emap_24s2029999044x514618413(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_243 = heff_take_field(v_x_241, 0);
    V v_t_244 = heff_get_n(v_x_241, 1, 3);
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      v_t_245 = v_m_243;
      break;
    }
    case TAG_Optional: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str0), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str1)));
      break;
    }
    case TAG_Many: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str2), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str3)));
      break;
    }
    case TAG_Some: {
      v_t_245 = heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str4));
      break;
    }
    case TAG_Rest: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str5), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str6)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s2029999044x514618413_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413(a[0]);
}
Clo g_list_2efind_24s1541406305x377496150_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1541406305x377496150_entry, 2, 0};

V g_list_2efind_24s1541406305x377496150(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1541406305x377496150_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1541406305x377496150(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s2016771181x401513202_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2016771181x401513202_24dps_entry, 4, 0};

V g_list_2efilter_24s2016771181x401513202_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_249 = heff_strSlice(v_t_248, heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_249, v_lit_241, 1)) {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s2016771181x401513202_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2016771181x401513202_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f88106788x1680212182_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f88106788x1680212182_entry, 1, 0};

V g_list_2emap_24f88106788x1680212182(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_x_241, 3);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), heff_hole()});
      V v_u_245 = (g_list_2emap_24f88106788x1680212182_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f88106788x1680212182_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f88106788x1680212182(a[0]);
}
Clo g_list_2efoldl_24f1922461191x750914054_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1922461191x750914054_entry, 4, 0};

V g_list_2efoldl_24f1922461191x750914054(V v_z_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_244, 1);
      v_t_248 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_x_249 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = heff_intAdd(v_z_240, v_x_249);
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_245;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1922461191x750914054(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1128388138x103163567_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1128388138x103163567_entry, 4, 0};

V g_list_2efoldl_24f1128388138x103163567(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_242, 4);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(v_x_244), heff_dup(heff_rfield(v_lit_242, 0)))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1128388138x103163567_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f1128388138x103163567(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1548644028x2098102081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1548644028x2098102081_entry, 2, 0};

V g_list_2emap_24f1548644028x2098102081(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_242, NTAG(TAG_Nothing)});
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1548644028x2098102081_24dps(v_p_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1548644028x2098102081(a[0], a[1]);
}
Clo g_list_2emap_24f1293205645x619162872_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1293205645x619162872_entry, 4, 0};

V g_list_2emap_24f1293205645x619162872(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_243), heff_dup(v_a_242))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_245 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24f1293205645x619162872_24dps(v_lit_240, v_lit_241, heff_intAdd(v_a_242, MK_INT(1LL)), v_b_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
}
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1293205645x619162872(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1156519715x726760149_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1156519715x726760149_entry, 1, 0};

V g_list_2emap_24f1156519715x726760149(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_241, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), heff_hole()});
      V v_u_245 = (g_list_2emap_24f1156519715x726760149_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1156519715x726760149(a[0]);
}
Clo g_list_2emap_24f1156519715x726760149_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1156519715x726760149_24dps_entry, 2, 0};

V g_list_2emap_24f1156519715x726760149_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1156519715x726760149_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1156519715x726760149_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f1488358745x465096512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1488358745x465096512_entry, 2, 0};

V g_list_2efoldl_24f1488358745x465096512(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_r_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        V v_sp_2424 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 5);
        V v_x_2428 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2428, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2429 = heff_field(v_x111_2418, 0);
        V v_sp_2430 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 4);
        V v_x_2433 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_sp_2430, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2433, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1488358745x465096512(a[0], a[1]);
}
Clo g_list_2emap_24f990982947x2126256822_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f990982947x2126256822_24dps_entry, 3, 0};

V g_list_2emap_24f990982947x2126256822_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_243, 1, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f990982947x2126256822_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f990982947x2126256822_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f765463553x1160475073_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f765463553x1160475073_entry, 7, 0};

V g_list_2efoldl_24f765463553x1160475073(V v_z_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_a_245, V v_b_246) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_246), heff_dup(v_a_245))) {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return v_z_240;
  } else {
    if (heff_intEq_c(heff_dup(v_a_245), heff_dup(v_lit_241))) {
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), v_z_240});
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = heff_intAdd(v_a_245, MK_INT(1LL));
      V t_6 = v_b_246;
      v_z_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_a_245 = t_5;
      v_b_246 = t_6;
      goto top;
    } else {
      V v_t_249 = heff_strByteAt(heff_dup(v_lit_242), heff_intSub(heff_dup(v_a_245), heff_dup(v_lit_243)));
      if (heff_intEq_c(v_t_249, heff_dup(v_lit_244))) {
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), v_z_240});
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = heff_intAdd(v_a_245, MK_INT(1LL));
        V t_6 = v_b_246;
        v_z_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_a_245 = t_5;
        v_b_246 = t_6;
        goto top;
      } else {
        V t_0 = v_z_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = heff_intAdd(v_a_245, MK_INT(1LL));
        V t_6 = v_b_246;
        v_z_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_a_245 = t_5;
        v_b_246 = t_6;
        goto top;
      }
    }
  }
}
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f765463553x1160475073(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24f1451184245x2111935062_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1451184245x2111935062_entry, 7, 0};

V g_list_2emap_24f1451184245x2111935062(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    heff_drop_rec(v_lit_241, 2);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_x_247, 0)), 1, 3);
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_247, 3);
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_249, 0ULL, 1);
      V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_lit_241, 0)), heff_dup(v_lit_242));
      V v_t_2412 = heff_strSlice(heff_dup(heff_rfield(v_lit_240, 3)), heff_dup(heff_rfield(v_lit_241, 0)), v_t_2411);
      V v_t_2414;
      if (heff_strEq_c_lent(v_t_2412, v_lit_243, 1)) {
        v_t_2414 = heff_dup(v_lit_244);
      } else {
        v_t_2414 = heff_dup(v_lit_245);
      }
      V v_t_2415 = heff_rec_n(3, shape_name__kind__span, (V[]){heff_take_field(v_x_247, 1), v_t_2414, heff_get_n(v_x_247, 2, 3)});
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_list_2emap_24f1451184245x2111935062_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
      heff_drop(v_u_2417);
      return v_cell_2416;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24f1451184245x2111935062_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1451184245x2111935062(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24f130772758x674845987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f130772758x674845987_24dps_entry, 5, 0};

V g_list_2emap_24f130772758x674845987_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
    if (heff_strEq_c_lent(v_t_247, v_lit_242, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_245, heff_dup(v_lit_240)), heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f130772758x674845987_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f130772758x674845987_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24f1819215186x476901667_24dps_str0, 8, "browser.");
Clo g_list_2emap_24f1819215186x476901667_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1819215186x476901667_24dps_entry, 5, 0};

V g_list_2emap_24f1819215186x476901667_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_take_field(v_x_245, 6);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strSlice(heff_dup(heff_rfield(v_x_245, 0)), MK_INT(0LL), MK_INT(8LL));
      if (heff_strEq_c(v_t_248, ((V)&g_list_2emap_24f1819215186x476901667_24dps_str0))) {
        V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 0)), heff_dup(v_lit_242));
        V v_t_2411 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_x_245, 0, 7), heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2410), NTAG(TAG_Nothing)});
        V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
        V v_u_2413 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_2412;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        heff_drop_rec(v_x_245, 7);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1819215186x476901667_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1819215186x476901667_24dps(a[0], a[1], a[2], a[3], a[4]);
}