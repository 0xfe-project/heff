// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_line 9817275
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_waiting 1348170899
static uint32_t shape_assoc__ops__above__below__loosest__errors__span__line[] = {LBL_assoc, LBL_ops, LBL_above, LBL_below, LBL_loosest, LBL_errors, LBL_span, LBL_line};
static uint32_t shape_binder__span[] = {LBL_binder, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_heff_2esyntax_2esurface_2eanyS(V, V);
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eanyS_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2ecycleDiag(V, V);
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo;
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclDone(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2elastEnd(V, V);
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elastEnd_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627_clo;
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewholeDefines(V);
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24f482741271x1112521151(V, V, V, V, V);
V g_list_2emap_24f482741271x1112521151_entry(V self, V *a);
extern Clo g_list_2emap_24f482741271x1112521151_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
Clo g_heff_2esyntax_2esurface_2enameSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameSet_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2enameSet(v_rest_242));
    return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_241), NTAG(TAG_MkUnit), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enameSet(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str3, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str5, 76, "` is defined twice: its equations are apart, another definition between them");
Clo g_heff_2esyntax_2esurface_2edefinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefinesOf(V v_open_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Sig: {
    V v_f_243 = heff_field(v_x2_241, 1);
    V v_fsp_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24Sig = heff_take_reuse_n(v_x2_241, 6ULL, 5);
    heff_drop(v_open_240);
    V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str0), heff_strAppend(heff_dup(v_f_243), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str1)));
    return heff_tag_at_n(v_ru_24x2_241_24Sig, TAG_Names, 5, (V[]){heff_dup(v_f_243), v_fsp_244, heff_tag_n(TAG_Just, 1, (V[]){v_f_243}), v_t_247, NTAG(TAG_False)});
  }
  case TAG_Eqn: {
    V v_g_248 = heff_field(v_x2_241, 0);
    V v_e_249 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 3);
    switch (heff_tag_of(v_open_240)) {
    case TAG_Nothing: {
      V v_t_2417;
      switch (heff_tag_of(v_e_249)) {
      case TAG_At: {
        V v_x11_2411 = heff_field(v_e_249, 0);
        heff_take_n(v_e_249, 1ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_MkEquation: {
          V v_fsp_2414 = heff_field(v_x11_2411, 1);
          heff_take_n(v_x11_2411, 2ULL, 4);
          v_t_2417 = v_fsp_2414;
          break;
        }
        default: heff_nomatch(v_x11_2411);
        }
        break;
      }
      default: heff_nomatch(v_e_249);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str2), heff_strAppend(heff_dup(v_g_248), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str3)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2417, heff_tag_n(TAG_Just, 1, (V[]){v_g_248}), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_open_240, 0);
      V v_ru_24open_240_24Just = heff_take_reuse_n(v_open_240, 1ULL, 1);
      if (heff_strEq_c(v_f_2419, heff_dup(v_g_248))) {
        heff_drop(v_g_248);
        heff_drop(v_e_249);
        heff_drop_cell(v_ru_24open_240_24Just, 1);
        return NTAG(TAG_Passes);
      } else {
        V v_t_2427;
        switch (heff_tag_of(v_e_249)) {
        case TAG_At: {
          V v_x11_2421 = heff_field(v_e_249, 0);
          heff_take_n(v_e_249, 1ULL, 2);
          switch (heff_tag_of(v_x11_2421)) {
          case TAG_MkEquation: {
            V v_fsp_2424 = heff_field(v_x11_2421, 1);
            heff_take_n(v_x11_2421, 2ULL, 4);
            v_t_2427 = v_fsp_2424;
            break;
          }
          default: heff_nomatch(v_x11_2421);
          }
          break;
        }
        default: heff_nomatch(v_e_249);
        }
        V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str4), heff_strAppend(heff_dup(v_g_248), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str5)));
        return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2427, heff_tag_at_n(v_ru_24open_240_24Just, TAG_Just, 1, (V[]){v_g_248}), v_t_2428, NTAG(TAG_False)});
      }
    }
    default: return heff_nomatch(v_open_240);
    }
  }
  case TAG_Whole: {
    V v_d_2429 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_open_240);
    return ({ V a_0 = v_d_2429; V r_ = (g_heff_2esyntax_2esurface_2ewholeDefines(a_0)); heff_drop(v_d_2429); r_; });
  }
  case TAG_Doc: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_open_240);
    return NTAG(TAG_Passes);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefinesOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edefNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefNext(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  V v_at_2419;
  switch (heff_tag_of(v_it_242)) {
  case TAG_Sig: {
    V v_sp_247 = heff_dup(heff_field(v_it_242, 4));
    v_at_2419 = heff_get_n(v_sp_247, 0, 2);
    break;
  }
  case TAG_Eqn: {
    V v_sp_2410 = heff_dup(heff_field(v_it_242, 2));
    v_at_2419 = heff_get_n(v_sp_2410, 0, 2);
    break;
  }
  case TAG_Whole: {
    V v_d_2411 = heff_dup(heff_field(v_it_242, 0));
    V v_t_2414;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_At: {
      V v_s_2413 = heff_field(v_d_2411, 1);
      heff_take_n(v_d_2411, 2ULL, 2);
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    v_at_2419 = heff_get_n(v_t_2414, 0, 2);
    break;
  }
  case TAG_Doc: {
    V v_d_2415 = heff_dup(heff_field(v_it_242, 0));
    V v_t_2418;
    switch (heff_tag_of(v_d_2415)) {
    case TAG_At: {
      V v_s_2417 = heff_field(v_d_2415, 1);
      heff_take_n(v_d_2415, 2ULL, 2);
      v_t_2418 = v_s_2417;
      break;
    }
    default: heff_nomatch(v_d_2415);
    }
    v_at_2419 = heff_get_n(v_t_2418, 0, 2);
    break;
  }
  default: heff_nomatch(v_it_242);
  }
  V v_t_2420 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2430;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nil: {
    heff_drop(v_src_240);
    heff_drop(v_at_2419);
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_d_2421 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_d_2421)) {
    case TAG_At: {
      V v_s_2424 = heff_field(v_d_2421, 1);
      heff_take_n(v_d_2421, 2ULL, 2);
      v_t_2425 = v_s_2424;
      break;
    }
    default: heff_nomatch(v_d_2421);
    }
    V v_from_2426 = heff_get_n(v_t_2425, 1, 2);
    V v_x2_2427 = (g_prelude_2eindexFrom(((V)&g_heff_2esyntax_2esurface_2edefNext_str0), heff_dup(v_src_240), v_from_2426));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nothing: {
      v_t_2429 = heff_strLength(heff_dup(v_src_240));
      break;
    }
    case TAG_Just: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      heff_take_n(v_x2_2427, 1ULL, 1);
      v_t_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    v_t_2430 = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(v_src_240, heff_intAdd(v_t_2429, MK_INT(1LL)), v_at_2419));
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_t_2430);
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, heff_take_field(v_p_241, 0)});
    V v_items_2432 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_t_2431, heff_take_field(v_p_241, 1)));
    return ({ V rv_0 = v_items_2432; V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_p_241, 4ULL, 3, shape_items__waiting__diags, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    heff_drop(v_t_2430);
    V v_items_2433 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2434 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2434);
    V v_items_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2433});
    V v_items_2436 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2436);
    V v_diags_2437 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
    return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2435, NTAG(TAG_Nil), v_diags_2437});
  }
}
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefNext(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2evariantL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Braces: {
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam4, 1, 1, (V[]){v_m_2451});
  }
  case TAG_Update: {
    V v_m_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam5, 1, 1, (V[]){v_m_2465});
  }
  case TAG_EUSet: {
    V v_m_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_InstB: {
    V v_m_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam7, 1, 1, (V[]){v_m_2489});
  }
  case TAG_EFSet: {
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFDefault: {
    V v_m_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam9, 1, 1, (V[]){v_m_24111});
  }
  case TAG_Sum: {
    V v_m_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam10, 1, 1, (V[]){v_m_24124});
  }
  case TAG_ECon: {
    V v_c_24132 = heff_field(v_e_241, 0);
    V v_args_24133 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24134 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24132, v_args_24133));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam11, 1, 1, (V[]){v_m_24134});
  }
  case TAG_EField: {
    V v_m_24144 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam12, 1, 1, (V[]){v_m_24144});
  }
  case TAG_ENeg: {
    V v_m_24154 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam13, 1, 1, (V[]){v_m_24154});
  }
  case TAG_App: {
    V v_m_24164 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam14, 1, 1, (V[]){v_m_24164});
  }
  case TAG_Op: {
    V v_m_24175 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam15, 1, 1, (V[]){v_m_24175});
  }
  case TAG_Ops: {
    V v_m_24185 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam16, 1, 1, (V[]){v_m_24185});
  }
  case TAG_OpRhs: {
    V v_m_24195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam17, 1, 1, (V[]){v_m_24195});
  }
  case TAG_Ann: {
    V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam18, 1, 1, (V[]){v_m_24206});
  }
  case TAG_BVar: {
    V v_m_24215 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam19, 1, 1, (V[]){v_m_24215});
  }
  case TAG_BImp: {
    V v_m_24226 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam20, 1, 1, (V[]){v_m_24226});
  }
  case TAG_BAnn: {
    V v_m_24239 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam21, 1, 1, (V[]){v_m_24239});
  }
  case TAG_Lam: {
    V v_m_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam22, 1, 1, (V[]){v_m_24251});
  }
  case TAG_Case: {
    V v_m_24263 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam23, 1, 1, (V[]){v_m_24263});
  }
  case TAG_EAlt: {
    V v_m_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam24, 1, 1, (V[]){v_m_24274});
  }
  case TAG_If: {
    V v_m_24288 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam25, 1, 1, (V[]){v_m_24288});
  }
  case TAG_Do: {
    V v_m_24298 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam26, 1, 1, (V[]){v_m_24298});
  }
  case TAG_ESBind: {
    V v_m_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam27, 1, 1, (V[]){v_m_24309});
  }
  case TAG_ELet: {
    V v_m_24323 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam28, 1, 1, (V[]){v_m_24323});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_249));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2420));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2433));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2445));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam4(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      V v_x_2458 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2457));
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2458}), v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam5(V self, V *args) {
  V v_st_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_st_2466}));
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_MkPair: {
    V v_x11_2468 = heff_field(v_x1_2467, 0);
    V v_st_2469 = heff_field(v_x1_2467, 1);
    V v_ru_24x1_2467_24MkPair = heff_take_reuse_n(v_x1_2467, 3ULL, 2);
    switch (heff_tag_of(v_x11_2468)) {
    case TAG_Left: {
      V v_e_2470 = heff_field(v_x11_2468, 0);
      heff_take_n(v_x11_2468, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2470}), v_st_2469});
    }
    case TAG_Right: {
      V v_x_2471 = heff_field(v_x11_2468, 0);
      heff_take_n(v_x11_2468, 1ULL, 1);
      V v_x_2472 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2471));
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2469});
    }
    default: return heff_nomatch(v_x11_2468);
    }
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2482));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam7(V self, V *args) {
  V v_st_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_st_2490}));
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_MkPair: {
    V v_x11_2492 = heff_field(v_x1_2491, 0);
    V v_st_2493 = heff_field(v_x1_2491, 1);
    V v_ru_24x1_2491_24MkPair = heff_take_reuse_n(v_x1_2491, 3ULL, 2);
    switch (heff_tag_of(v_x11_2492)) {
    case TAG_Left: {
      V v_e_2494 = heff_field(v_x11_2492, 0);
      heff_take_n(v_x11_2492, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2494}), v_st_2493});
    }
    case TAG_Right: {
      V v_x_2495 = heff_field(v_x11_2492, 0);
      heff_take_n(v_x11_2492, 1ULL, 1);
      V v_x_2496 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2495));
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2496}), v_st_2493});
    }
    default: return heff_nomatch(v_x11_2492);
    }
  }
  default: return heff_nomatch(v_x1_2491);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      V v_x_24118 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24117));
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24118}), v_st_24115});
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam10(V self, V *args) {
  V v_st_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_st_24125}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_MkPair: {
    V v_x11_24127 = heff_field(v_x1_24126, 0);
    V v_st_24128 = heff_field(v_x1_24126, 1);
    V v_ru_24x1_24126_24MkPair = heff_take_reuse_n(v_x1_24126, 3ULL, 2);
    switch (heff_tag_of(v_x11_24127)) {
    case TAG_Left: {
      V v_e_24129 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24129}), v_st_24128});
    }
    case TAG_Right: {
      V v_x_24130 = heff_field(v_x11_24127, 0);
      heff_take_n(v_x11_24127, 1ULL, 1);
      V v_x_24131 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24130));
      return heff_tag_at_n(v_ru_24x1_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24131}), v_st_24128});
    }
    default: return heff_nomatch(v_x11_24127);
    }
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam11(V self, V *args) {
  V v_st_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_st_24135}));
  switch (heff_tag_of(v_x1_24136)) {
  case TAG_MkPair: {
    V v_x11_24137 = heff_field(v_x1_24136, 0);
    V v_st_24138 = heff_field(v_x1_24136, 1);
    V v_ru_24x1_24136_24MkPair = heff_take_reuse_n(v_x1_24136, 3ULL, 2);
    switch (heff_tag_of(v_x11_24137)) {
    case TAG_Left: {
      V v_e_24139 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24139}), v_st_24138});
    }
    case TAG_Right: {
      V v_x_24140 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      V v_x_24141 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24140));
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24141}), v_st_24138});
    }
    default: return heff_nomatch(v_x11_24137);
    }
  }
  default: return heff_nomatch(v_x1_24136);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam12(V self, V *args) {
  V v_st_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_st_24145}));
  switch (heff_tag_of(v_x1_24146)) {
  case TAG_MkPair: {
    V v_x11_24147 = heff_field(v_x1_24146, 0);
    V v_st_24148 = heff_field(v_x1_24146, 1);
    V v_ru_24x1_24146_24MkPair = heff_take_reuse_n(v_x1_24146, 3ULL, 2);
    switch (heff_tag_of(v_x11_24147)) {
    case TAG_Left: {
      V v_e_24149 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24149}), v_st_24148});
    }
    case TAG_Right: {
      V v_x_24150 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      V v_x_24151 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24150));
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24151}), v_st_24148});
    }
    default: return heff_nomatch(v_x11_24147);
    }
  }
  default: return heff_nomatch(v_x1_24146);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam13(V self, V *args) {
  V v_st_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_st_24155}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_MkPair: {
    V v_x11_24157 = heff_field(v_x1_24156, 0);
    V v_st_24158 = heff_field(v_x1_24156, 1);
    V v_ru_24x1_24156_24MkPair = heff_take_reuse_n(v_x1_24156, 3ULL, 2);
    switch (heff_tag_of(v_x11_24157)) {
    case TAG_Left: {
      V v_e_24159 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24159}), v_st_24158});
    }
    case TAG_Right: {
      V v_x_24160 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      V v_x_24161 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24160));
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24161}), v_st_24158});
    }
    default: return heff_nomatch(v_x11_24157);
    }
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam14(V self, V *args) {
  V v_st_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_st_24165}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_MkPair: {
    V v_x11_24167 = heff_field(v_x1_24166, 0);
    V v_st_24168 = heff_field(v_x1_24166, 1);
    V v_ru_24x1_24166_24MkPair = heff_take_reuse_n(v_x1_24166, 3ULL, 2);
    switch (heff_tag_of(v_x11_24167)) {
    case TAG_Left: {
      V v_e_24169 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24169}), v_st_24168});
    }
    case TAG_Right: {
      V v_x_24170 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      V v_x_24171 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24170));
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24171}), v_st_24168});
    }
    default: return heff_nomatch(v_x11_24167);
    }
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam15(V self, V *args) {
  V v_st_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_st_24176}));
  switch (heff_tag_of(v_x1_24177)) {
  case TAG_MkPair: {
    V v_x11_24178 = heff_field(v_x1_24177, 0);
    V v_st_24179 = heff_field(v_x1_24177, 1);
    V v_ru_24x1_24177_24MkPair = heff_take_reuse_n(v_x1_24177, 3ULL, 2);
    switch (heff_tag_of(v_x11_24178)) {
    case TAG_Left: {
      V v_e_24180 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24180}), v_st_24179});
    }
    case TAG_Right: {
      V v_x_24181 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      V v_x_24182 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24181));
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24182}), v_st_24179});
    }
    default: return heff_nomatch(v_x11_24178);
    }
  }
  default: return heff_nomatch(v_x1_24177);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam16(V self, V *args) {
  V v_st_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_st_24186}));
  switch (heff_tag_of(v_x1_24187)) {
  case TAG_MkPair: {
    V v_x11_24188 = heff_field(v_x1_24187, 0);
    V v_st_24189 = heff_field(v_x1_24187, 1);
    V v_ru_24x1_24187_24MkPair = heff_take_reuse_n(v_x1_24187, 3ULL, 2);
    switch (heff_tag_of(v_x11_24188)) {
    case TAG_Left: {
      V v_e_24190 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24190}), v_st_24189});
    }
    case TAG_Right: {
      V v_x_24191 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      V v_x_24192 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24191));
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24192}), v_st_24189});
    }
    default: return heff_nomatch(v_x11_24188);
    }
  }
  default: return heff_nomatch(v_x1_24187);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam17(V self, V *args) {
  V v_st_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_st_24196}));
  switch (heff_tag_of(v_x1_24197)) {
  case TAG_MkPair: {
    V v_x11_24198 = heff_field(v_x1_24197, 0);
    V v_st_24199 = heff_field(v_x1_24197, 1);
    V v_ru_24x1_24197_24MkPair = heff_take_reuse_n(v_x1_24197, 3ULL, 2);
    switch (heff_tag_of(v_x11_24198)) {
    case TAG_Left: {
      V v_e_24200 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24200}), v_st_24199});
    }
    case TAG_Right: {
      V v_x_24201 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      V v_x_24202 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24201));
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24199});
    }
    default: return heff_nomatch(v_x11_24198);
    }
  }
  default: return heff_nomatch(v_x1_24197);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam18(V self, V *args) {
  V v_st_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_st_24207}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24212));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam19(V self, V *args) {
  V v_st_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_st_24216}));
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_MkPair: {
    V v_x11_24218 = heff_field(v_x1_24217, 0);
    V v_st_24219 = heff_field(v_x1_24217, 1);
    V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_Left: {
      V v_e_24220 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
    }
    case TAG_Right: {
      V v_x_24221 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      V v_x_24222 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24221));
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24222}), v_st_24219});
    }
    default: return heff_nomatch(v_x11_24218);
    }
  }
  default: return heff_nomatch(v_x1_24217);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam20(V self, V *args) {
  V v_st_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_st_24227}));
  switch (heff_tag_of(v_x1_24228)) {
  case TAG_MkPair: {
    V v_x11_24229 = heff_field(v_x1_24228, 0);
    V v_st_24230 = heff_field(v_x1_24228, 1);
    V v_ru_24x1_24228_24MkPair = heff_take_reuse_n(v_x1_24228, 3ULL, 2);
    switch (heff_tag_of(v_x11_24229)) {
    case TAG_Left: {
      V v_e_24231 = heff_field(v_x11_24229, 0);
      heff_take_n(v_x11_24229, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24231}), v_st_24230});
    }
    case TAG_Right: {
      V v_x_24232 = heff_field(v_x11_24229, 0);
      heff_take_n(v_x11_24229, 1ULL, 1);
      V v_x_24233 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24232));
      return heff_tag_at_n(v_ru_24x1_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24233}), v_st_24230});
    }
    default: return heff_nomatch(v_x11_24229);
    }
  }
  default: return heff_nomatch(v_x1_24228);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam21(V self, V *args) {
  V v_st_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_st_24240}));
  switch (heff_tag_of(v_x1_24241)) {
  case TAG_MkPair: {
    V v_x11_24242 = heff_field(v_x1_24241, 0);
    V v_st_24243 = heff_field(v_x1_24241, 1);
    V v_ru_24x1_24241_24MkPair = heff_take_reuse_n(v_x1_24241, 3ULL, 2);
    switch (heff_tag_of(v_x11_24242)) {
    case TAG_Left: {
      V v_e_24244 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24244}), v_st_24243});
    }
    case TAG_Right: {
      V v_x_24245 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      V v_x_24246 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24245));
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24246}), v_st_24243});
    }
    default: return heff_nomatch(v_x11_24242);
    }
  }
  default: return heff_nomatch(v_x1_24241);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam22(V self, V *args) {
  V v_st_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_st_24252}));
  switch (heff_tag_of(v_x1_24253)) {
  case TAG_MkPair: {
    V v_x11_24254 = heff_field(v_x1_24253, 0);
    V v_st_24255 = heff_field(v_x1_24253, 1);
    V v_ru_24x1_24253_24MkPair = heff_take_reuse_n(v_x1_24253, 3ULL, 2);
    switch (heff_tag_of(v_x11_24254)) {
    case TAG_Left: {
      V v_e_24256 = heff_field(v_x11_24254, 0);
      heff_take_n(v_x11_24254, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24253_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24256}), v_st_24255});
    }
    case TAG_Right: {
      V v_x_24257 = heff_field(v_x11_24254, 0);
      heff_take_n(v_x11_24254, 1ULL, 1);
      V v_x_24258 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24257));
      return heff_tag_at_n(v_ru_24x1_24253_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24258}), v_st_24255});
    }
    default: return heff_nomatch(v_x11_24254);
    }
  }
  default: return heff_nomatch(v_x1_24253);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam23(V self, V *args) {
  V v_st_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_st_24264}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_MkPair: {
    V v_x11_24266 = heff_field(v_x1_24265, 0);
    V v_st_24267 = heff_field(v_x1_24265, 1);
    V v_ru_24x1_24265_24MkPair = heff_take_reuse_n(v_x1_24265, 3ULL, 2);
    switch (heff_tag_of(v_x11_24266)) {
    case TAG_Left: {
      V v_e_24268 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24268}), v_st_24267});
    }
    case TAG_Right: {
      V v_x_24269 = heff_field(v_x11_24266, 0);
      heff_take_n(v_x11_24266, 1ULL, 1);
      V v_x_24270 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24269));
      return heff_tag_at_n(v_ru_24x1_24265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24270}), v_st_24267});
    }
    default: return heff_nomatch(v_x11_24266);
    }
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam24(V self, V *args) {
  V v_st_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24276 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_st_24275}));
  switch (heff_tag_of(v_x1_24276)) {
  case TAG_MkPair: {
    V v_x11_24277 = heff_field(v_x1_24276, 0);
    V v_st_24278 = heff_field(v_x1_24276, 1);
    V v_ru_24x1_24276_24MkPair = heff_take_reuse_n(v_x1_24276, 3ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_Left: {
      V v_e_24279 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24279}), v_st_24278});
    }
    case TAG_Right: {
      V v_x_24280 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      V v_x_24281 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24280));
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24281}), v_st_24278});
    }
    default: return heff_nomatch(v_x11_24277);
    }
  }
  default: return heff_nomatch(v_x1_24276);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam25(V self, V *args) {
  V v_st_24289 = args[0];
  V v_m_24288 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24290 = heff_tr(heff_call(v_m_24288, 1, (V[]){v_st_24289}));
  switch (heff_tag_of(v_x1_24290)) {
  case TAG_MkPair: {
    V v_x11_24291 = heff_field(v_x1_24290, 0);
    V v_st_24292 = heff_field(v_x1_24290, 1);
    V v_ru_24x1_24290_24MkPair = heff_take_reuse_n(v_x1_24290, 3ULL, 2);
    switch (heff_tag_of(v_x11_24291)) {
    case TAG_Left: {
      V v_e_24293 = heff_field(v_x11_24291, 0);
      heff_take_n(v_x11_24291, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24293}), v_st_24292});
    }
    case TAG_Right: {
      V v_x_24294 = heff_field(v_x11_24291, 0);
      heff_take_n(v_x11_24291, 1ULL, 1);
      V v_x_24295 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24294));
      return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24295}), v_st_24292});
    }
    default: return heff_nomatch(v_x11_24291);
    }
  }
  default: return heff_nomatch(v_x1_24290);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam26(V self, V *args) {
  V v_st_24299 = args[0];
  V v_m_24298 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24300 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_st_24299}));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_MkPair: {
    V v_x11_24301 = heff_field(v_x1_24300, 0);
    V v_st_24302 = heff_field(v_x1_24300, 1);
    V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
    switch (heff_tag_of(v_x11_24301)) {
    case TAG_Left: {
      V v_e_24303 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
    }
    case TAG_Right: {
      V v_x_24304 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      V v_x_24305 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24304));
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24305}), v_st_24302});
    }
    default: return heff_nomatch(v_x11_24301);
    }
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam27(V self, V *args) {
  V v_st_24310 = args[0];
  V v_m_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24311 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_st_24310}));
  switch (heff_tag_of(v_x1_24311)) {
  case TAG_MkPair: {
    V v_x11_24312 = heff_field(v_x1_24311, 0);
    V v_st_24313 = heff_field(v_x1_24311, 1);
    V v_ru_24x1_24311_24MkPair = heff_take_reuse_n(v_x1_24311, 3ULL, 2);
    switch (heff_tag_of(v_x11_24312)) {
    case TAG_Left: {
      V v_e_24314 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24314}), v_st_24313});
    }
    case TAG_Right: {
      V v_x_24315 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      V v_x_24316 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24315));
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24313});
    }
    default: return heff_nomatch(v_x11_24312);
    }
  }
  default: return heff_nomatch(v_x1_24311);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam28(V self, V *args) {
  V v_st_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24325 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_st_24324}));
  switch (heff_tag_of(v_x1_24325)) {
  case TAG_MkPair: {
    V v_x11_24326 = heff_field(v_x1_24325, 0);
    V v_st_24327 = heff_field(v_x1_24325, 1);
    V v_ru_24x1_24325_24MkPair = heff_take_reuse_n(v_x1_24325, 3ULL, 2);
    switch (heff_tag_of(v_x11_24326)) {
    case TAG_Left: {
      V v_e_24328 = heff_field(v_x11_24326, 0);
      heff_take_n(v_x11_24326, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24325_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24328}), v_st_24327});
    }
    case TAG_Right: {
      V v_x_24329 = heff_field(v_x11_24326, 0);
      heff_take_n(v_x11_24326, 1ULL, 1);
      V v_x_24330 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24329));
      return heff_tag_at_n(v_ru_24x1_24325_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24330}), v_st_24327});
    }
    default: return heff_nomatch(v_x11_24326);
    }
  }
  default: return heff_nomatch(v_x1_24325);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str51, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2elamBinderL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elamBinderL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elamBinderL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Braces: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2448 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2449 = heff_strAppend(heff_get_n(v_t_2448, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str8));
    V v_msg_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str9), v_t_2449);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam4, 1, 2, (V[]){v_t_2447, v_msg_2450});
  }
  case TAG_Update: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2460 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2461 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2462 = heff_strAppend(heff_get_n(v_t_2461, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str10));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str11), v_t_2462);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam5, 1, 2, (V[]){v_t_2460, v_msg_2463});
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_InstB: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2482 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2483 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2484 = heff_strAppend(heff_get_n(v_t_2483, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str14));
    V v_msg_2485 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str15), v_t_2484);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam7, 1, 2, (V[]){v_t_2482, v_msg_2485});
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_Sum: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24114 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24115 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24116 = heff_strAppend(heff_get_n(v_t_24115, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str20));
    V v_msg_24117 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str21), v_t_24116);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam10, 1, 2, (V[]){v_t_24114, v_msg_24117});
  }
  case TAG_ECon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24123 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24124 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24125 = heff_strAppend(heff_get_n(v_t_24124, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str22));
    V v_msg_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str23), v_t_24125);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam11, 1, 2, (V[]){v_t_24123, v_msg_24126});
  }
  case TAG_EField: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24132 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24133 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24134 = heff_strAppend(heff_get_n(v_t_24133, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str24));
    V v_msg_24135 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str25), v_t_24134);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam12, 1, 2, (V[]){v_t_24132, v_msg_24135});
  }
  case TAG_ENeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24141 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24142 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24143 = heff_strAppend(heff_get_n(v_t_24142, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str26));
    V v_msg_24144 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str27), v_t_24143);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam13, 1, 2, (V[]){v_t_24141, v_msg_24144});
  }
  case TAG_App: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24150 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24151 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24152 = heff_strAppend(heff_get_n(v_t_24151, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str28));
    V v_msg_24153 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str29), v_t_24152);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam14, 1, 2, (V[]){v_t_24150, v_msg_24153});
  }
  case TAG_Op: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Ops: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24169 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24170 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24171 = heff_strAppend(heff_get_n(v_t_24170, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str32));
    V v_msg_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str33), v_t_24171);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam16, 1, 2, (V[]){v_t_24169, v_msg_24172});
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24178 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24179 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24180 = heff_strAppend(heff_get_n(v_t_24179, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str34));
    V v_msg_24181 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str35), v_t_24180);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam17, 1, 2, (V[]){v_t_24178, v_msg_24181});
  }
  case TAG_Ann: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_BVar: {
    V v_x_24195 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam19, 1, 1, (V[]){v_x_24195});
  }
  case TAG_BImp: {
    V v_o_24201 = heff_field(v_e_241, 0);
    V v_x_24202 = heff_field(v_e_241, 1);
    V v_c_24203 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam20, 1, 3, (V[]){v_x_24202, v_o_24201, v_c_24203});
  }
  case TAG_BAnn: {
    V v_x_24210 = heff_field(v_e_241, 1);
    V v_ty_24212 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 5);
    V v_m_24214 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24212}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam21, 1, 2, (V[]){v_m_24214, v_x_24210});
  }
  case TAG_Lam: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24232 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24233 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24234 = heff_strAppend(heff_get_n(v_t_24233, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str38));
    V v_msg_24235 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str39), v_t_24234);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam22, 1, 2, (V[]){v_t_24232, v_msg_24235});
  }
  case TAG_Case: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24245 = heff_strAppend(heff_get_n(v_t_24244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str40));
    V v_msg_24246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str41), v_t_24245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam23, 1, 2, (V[]){v_t_24243, v_msg_24246});
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24253 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24254 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24255 = heff_strAppend(heff_get_n(v_t_24254, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str42));
    V v_msg_24256 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str43), v_t_24255);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam24, 1, 2, (V[]){v_t_24253, v_msg_24256});
  }
  case TAG_If: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24266 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24267 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24268 = heff_strAppend(heff_get_n(v_t_24267, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str44));
    V v_msg_24269 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str45), v_t_24268);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam25, 1, 2, (V[]){v_t_24266, v_msg_24269});
  }
  case TAG_Do: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24275 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24276 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24277 = heff_strAppend(heff_get_n(v_t_24276, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str46));
    V v_msg_24278 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str47), v_t_24277);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam26, 1, 2, (V[]){v_t_24275, v_msg_24278});
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24285 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24286 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24287 = heff_strAppend(heff_get_n(v_t_24286, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str48));
    V v_msg_24288 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str49), v_t_24287);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam27, 1, 2, (V[]){v_t_24285, v_msg_24288});
  }
  case TAG_ELet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24298 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24299 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24300 = heff_strAppend(heff_get_n(v_t_24299, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str50));
    V v_msg_24301 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str51), v_t_24300);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam28, 1, 2, (V[]){v_t_24298, v_msg_24301});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elamBinderL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_t_2447 = heff_env(self)[0];
  V v_msg_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2447, 3), heff_get_n(v_t_2447, 4, 9)});
  V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2450, v_t_2452, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2453}), v_st_2451});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam5(V self, V *args) {
  V v_st_2464 = args[0];
  V v_t_2460 = heff_env(self)[0];
  V v_msg_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2460, 3), heff_get_n(v_t_2460, 4, 9)});
  V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2463, v_t_2465, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2466}), v_st_2464});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam7(V self, V *args) {
  V v_st_2486 = args[0];
  V v_t_2482 = heff_env(self)[0];
  V v_msg_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2487 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2482, 3), heff_get_n(v_t_2482, 4, 9)});
  V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2485, v_t_2487, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2488}), v_st_2486});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam10(V self, V *args) {
  V v_st_24118 = args[0];
  V v_t_24114 = heff_env(self)[0];
  V v_msg_24117 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24119 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24114, 3), heff_get_n(v_t_24114, 4, 9)});
  V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24117, v_t_24119, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24120}), v_st_24118});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam11(V self, V *args) {
  V v_st_24127 = args[0];
  V v_t_24123 = heff_env(self)[0];
  V v_msg_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24123, 3), heff_get_n(v_t_24123, 4, 9)});
  V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24126, v_t_24128, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24129}), v_st_24127});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam12(V self, V *args) {
  V v_st_24136 = args[0];
  V v_t_24132 = heff_env(self)[0];
  V v_msg_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24137 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24132, 3), heff_get_n(v_t_24132, 4, 9)});
  V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24135, v_t_24137, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24138}), v_st_24136});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam13(V self, V *args) {
  V v_st_24145 = args[0];
  V v_t_24141 = heff_env(self)[0];
  V v_msg_24144 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24146 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
  V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24144, v_t_24146, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24147}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam14(V self, V *args) {
  V v_st_24154 = args[0];
  V v_t_24150 = heff_env(self)[0];
  V v_msg_24153 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24155 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24150, 3), heff_get_n(v_t_24150, 4, 9)});
  V v_t_24156 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24153, v_t_24155, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24156}), v_st_24154});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam16(V self, V *args) {
  V v_st_24173 = args[0];
  V v_t_24169 = heff_env(self)[0];
  V v_msg_24172 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24174 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24169, 3), heff_get_n(v_t_24169, 4, 9)});
  V v_t_24175 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24172, v_t_24174, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24175}), v_st_24173});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam17(V self, V *args) {
  V v_st_24182 = args[0];
  V v_t_24178 = heff_env(self)[0];
  V v_msg_24181 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24183 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24178, 3), heff_get_n(v_t_24178, 4, 9)});
  V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24181, v_t_24183, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24184}), v_st_24182});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam19(V self, V *args) {
  V v_st_24196 = args[0];
  V v_x_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24197 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24195, 3)), heff_dup(heff_rfield(v_x_24195, 4))});
  V v_t_24198 = heff_tag_n(TAG_LamName, 2, (V[]){heff_take_field(v_x_24195, 1), v_t_24197});
  V v_t_24199 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24195, 3), heff_get_n(v_x_24195, 4, 9)});
  V v_t_24200 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_binder__span, (V[]){v_t_24198, v_t_24199})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24200, v_st_24196});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam20(V self, V *args) {
  V v_st_24204 = args[0];
  V v_x_24202 = heff_env(self)[0];
  V v_o_24201 = heff_env(self)[1];
  V v_c_24203 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24205 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24202, 3), heff_take_field(v_x_24202, 4)});
  V v_t_24206 = heff_tag_n(TAG_LamImplicit, 2, (V[]){heff_get_n(v_x_24202, 1, 9), v_t_24205});
  V v_t_24207 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24201, 3, 9), heff_get_n(v_c_24203, 4, 9)});
  V v_t_24208 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_binder__span, (V[]){v_t_24206, v_t_24207})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24208, v_st_24204});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam21(V self, V *args) {
  V v_st_24215 = args[0];
  V v_m_24214 = heff_env(self)[0];
  V v_x_24210 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24216 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_st_24215}));
  switch (heff_tag_of(v_x1_24216)) {
  case TAG_MkPair: {
    V v_x11_24217 = heff_field(v_x1_24216, 0);
    V v_st_24218 = heff_field(v_x1_24216, 1);
    V v_ru_24x1_24216_24MkPair = heff_take_reuse_n(v_x1_24216, 3ULL, 2);
    switch (heff_tag_of(v_x11_24217)) {
    case TAG_Left: {
      V v_e_24219 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      heff_drop_rec(v_x_24210, 9);
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24219}), v_st_24218});
    }
    case TAG_Right: {
      V v_x_24220 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      V v_t_24221 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24210, 3)), heff_take_field(v_x_24210, 4)});
      V v_t_24222 = heff_tag_n(TAG_LamAnn, 3, (V[]){heff_take_field(v_x_24210, 1), v_t_24221, heff_dup(v_x_24220)});
      V v_b_24225;
      switch (heff_tag_of(v_x_24220)) {
      case TAG_At: {
        V v_s_24224 = heff_field(v_x_24220, 1);
        heff_take_n(v_x_24220, 2ULL, 2);
        v_b_24225 = v_s_24224;
        break;
      }
      default: heff_nomatch(v_x_24220);
      }
      V v_t_24226 = ({ V rv_0 = heff_get_n(v_x_24210, 3, 9); V rr_ = heff_rec_reuse_nf(v_b_24225, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_24227 = heff_rec_n(2, shape_binder__span, (V[]){v_t_24222, v_t_24226});
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24227}), v_st_24218});
    }
    default: return heff_nomatch(v_x11_24217);
    }
  }
  default: return heff_nomatch(v_x1_24216);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam22(V self, V *args) {
  V v_st_24236 = args[0];
  V v_t_24232 = heff_env(self)[0];
  V v_msg_24235 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24237 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24232, 3), heff_get_n(v_t_24232, 4, 9)});
  V v_t_24238 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24235, v_t_24237, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24238}), v_st_24236});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam23(V self, V *args) {
  V v_st_24247 = args[0];
  V v_t_24243 = heff_env(self)[0];
  V v_msg_24246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24243, 3), heff_get_n(v_t_24243, 4, 9)});
  V v_t_24249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24246, v_t_24248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24249}), v_st_24247});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam24(V self, V *args) {
  V v_st_24257 = args[0];
  V v_t_24253 = heff_env(self)[0];
  V v_msg_24256 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24258 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24253, 3), heff_get_n(v_t_24253, 4, 9)});
  V v_t_24259 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24256, v_t_24258, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24259}), v_st_24257});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam25(V self, V *args) {
  V v_st_24270 = args[0];
  V v_t_24266 = heff_env(self)[0];
  V v_msg_24269 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24271 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24266, 3), heff_get_n(v_t_24266, 4, 9)});
  V v_t_24272 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24269, v_t_24271, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24272}), v_st_24270});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam26(V self, V *args) {
  V v_st_24279 = args[0];
  V v_t_24275 = heff_env(self)[0];
  V v_msg_24278 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24280 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24275, 3), heff_get_n(v_t_24275, 4, 9)});
  V v_t_24281 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24278, v_t_24280, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24281}), v_st_24279});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam27(V self, V *args) {
  V v_st_24289 = args[0];
  V v_t_24285 = heff_env(self)[0];
  V v_msg_24288 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24290 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24285, 3), heff_get_n(v_t_24285, 4, 9)});
  V v_t_24291 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24288, v_t_24290, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24291}), v_st_24289});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam28(V self, V *args) {
  V v_st_24302 = args[0];
  V v_t_24298 = heff_env(self)[0];
  V v_msg_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24303 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24298, 3), heff_get_n(v_t_24298, 4, 9)});
  V v_t_24304 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24301, v_t_24303, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24304}), v_st_24302});
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str2, 4, "type");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str3, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str4, 4, "data");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str7, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str10, 1, ":");
Clo g_heff_2esyntax_2esurface_2eprescanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprescanGo_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eprescanGo(V v_ts_240, V v_k_241, V v_acc_242) {
top: ;
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_k_241))) {
    if (heff_intLt_c(heff_dup(v_k_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_245 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_k_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_ts_240);
    heff_drop(v_k_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_i_248 = heff_intAdd(heff_dup(v_k_241), MK_INT(1LL));
    V v_t_2412;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_ts_240)))) {
        V v_t_2411 = heff_arrayIndex(heff_dup(v_ts_240), v_i_248);
        v_t_2412 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2411});
      } else {
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        heff_drop(v_i_248);
        v_t_2412 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      heff_drop(v_i_248);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_247, 7);
      V t_0 = v_ts_240;
      V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      v_ts_240 = t_0;
      v_k_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_u_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2414 = heff_dup(heff_rfield(v_t_247, 6));
      V v_t_2420;
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        if (heff_intEq_c(heff_dup(heff_rfield(v_t_247, 5)), MK_INT(0LL))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str0))) {
            V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_247, 1))}));
            V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str1), NTAG(TAG_Nil)});
            V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str3), v_t_2418})});
            v_t_2420 = ({ V a_0 = v_t_2417; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str4), v_t_2419}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
          } else {
            v_t_2420 = NTAG(TAG_False);
          }
        } else {
          v_t_2420 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_t_2414);
        v_t_2420 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_247, 7);
        heff_drop(v_t_2420);
        V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_u_2413, 1, 7), v_acc_242});
        V t_0 = v_ts_240;
        V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
        V t_2 = v_t_2421;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2420);
        V v_t_2422 = heff_take_field(v_t_247, 6);
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop(v_t_2422);
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_247, 5)), MK_INT(0LL))) {
            V v_t_2428 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str5)) ? (heff_strEq_c(heff_dup(heff_rfield(v_u_2413, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2413, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str7))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str8)) && (heff_strEq_c(heff_dup(heff_rfield(v_u_2413, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str9)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2413, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str10))))));
            heff_drop_rec(v_u_2413, 7);
            if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
              heff_drop(v_t_2428);
              V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_247, 1, 7), v_acc_242});
              V t_0 = v_ts_240;
              V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
              V t_2 = v_t_2429;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            } else {
              heff_drop_rec(v_t_247, 7);
              heff_drop(v_t_2428);
              V t_0 = v_ts_240;
              V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
              V t_2 = v_acc_242;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            }
          } else {
            heff_drop_rec(v_t_247, 7);
            heff_drop_rec(v_u_2413, 7);
            V t_0 = v_ts_240;
            V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
            V t_2 = v_acc_242;
            v_ts_240 = t_0;
            v_k_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          }
        } else {
          heff_drop_rec(v_t_247, 7);
          heff_drop_rec(v_u_2413, 7);
          heff_drop(v_t_2422);
          V t_0 = v_ts_240;
          V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
          V t_2 = v_acc_242;
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprescanGo(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2edropN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edropN_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edropN(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_rest_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edropN(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclDone_str0, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclDone_str1, 6, "infixr");
Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclDone_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixDeclDone(V v_t_240, V v_rest_241, V v_ops_242, V v_r_243) {
top: ;
  V v_s_244 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_247;
  if (heff_strEq_c(heff_dup(v_s_244), ((V)&g_heff_2esyntax_2esurface_2efixDeclDone_str0))) {
    heff_drop(v_s_244);
    v_t_247 = NTAG(TAG_AssocLeft);
  } else {
    if (heff_strEq_c(v_s_244, ((V)&g_heff_2esyntax_2esurface_2efixDeclDone_str1))) {
      v_t_247 = NTAG(TAG_AssocRight);
    } else {
      v_t_247 = NTAG(TAG_AssocNone);
    }
  }
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_r_243, 3)));
  V v_b_249 = (g_heff_2esyntax_2esurface_2elastEnd(heff_dup(v_t_240), v_rest_241));
  V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 2), v_b_249});
  return heff_rec_n(8, shape_assoc__ops__above__below__loosest__errors__span__line, (V[]){v_t_247, v_ops_242, heff_dup(heff_rfield(v_r_243, 0)), heff_dup(heff_rfield(v_r_243, 1)), heff_get_n(v_r_243, 2, 4), v_t_248, v_t_2410, heff_get_n(v_t_240, 4, 7)});
}
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixDeclDone(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str0, 15, "the fixity of `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str1, 19, "` is declared twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str2, 22, "` ends up above itself");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str3, 26, "these fixities go round: `");
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecycleDiag_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecycleDiag(V v_all_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 1));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_all_240, 2);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Cons = heff_take_reuse_n(v_t_242, 1ULL, 2);
    V v_t_249 = (g_list_2emap_24f482741271x1112521151(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str0), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str1), heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam0, 1, 2, (V[]){heff_dup(v_g_243), heff_dup(v_all_240)}), heff_take_field(v_d_241, 1)));
    V v_t_2410 = heff_tag_at_n(v_ru_24t_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_g_243, 1)), NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2esyntax_2efixity_2etighterGo(v_all_240, heff_dup(heff_rfield(v_g_243, 1)), v_t_2410, NTAG(TAG_Nil)));
    V v_t_2414;
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_strAppend(heff_get_n(v_g_243, 1, 7), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str2));
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str3), v_t_2412), heff_get_n(v_d_241, 6, 8), NTAG(TAG_Nothing)});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_d_241, 8);
      heff_drop_rec(v_g_243, 7);
      heff_drop(v_t_2411);
      v_t_2414 = NTAG(TAG_Nil);
    }
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_249, v_t_2414);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecycleDiag(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args) {
  V v_h_246 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_u_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_h_246, 0)), heff_get_n(v_g_243, 1, 7))) {
    heff_drop_rec(v_h_246, 5);
    heff_drop_rec(v_u_245, 7);
    return NTAG(TAG_False);
  } else {
    V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_245, 1, 7)}));
    return ({ V a_0 = v_t_248; V b_1 = heff_get_n(v_h_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_all_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam1, 1, 2, (V[]){v_g_243, v_u_245}); V b_1 = heff_get_n(v_all_240, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eanyS(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_entry, 5, 0};

V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(V v_kw_240, V v_name_241, V v_params_242, V v_body_243, V v_z_244) {
top: ;
  V v_m_245 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_params_242));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_name_241, 9);
      heff_drop(v_body_243);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_246_24MkPair, 2);
      V v_t_2411 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2410)));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2411, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_lam0, 1, 4, (V[]){v_body_243, v_name_241, v_kw_240, v_x_2410}), v_st_248));
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_body_243 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  V v_kw_240 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_body_243), v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_body_243);
      heff_drop_rec(v_name_241, 9);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_x_2410);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_241, 3), heff_take_field(v_name_241, 4)});
      V v_t_2419 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2420 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_243)));
      V v_e_2421 = heff_get_n(v_t_2420, 4, 9);
      V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_240, 3)), v_e_2421});
      V v_t_2423 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_241, 1, 9), v_t_2418, v_x_2410, heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_At, 2, (V[]){v_t_2419, v_t_2422}), v_x_2417});
      V v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(v_body_243));
      V v_e_2425 = heff_get_n(v_t_2424, 4, 9);
      V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2425});
      V v_t_2427 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2426})});
      V v_x_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2428}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_245 = (g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839(v_x_243, v_p_241));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_x11_246 = heff_field(v_x1_245, 0);
      V v_st_247 = heff_field(v_x1_245, 1);
      V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x11_246, 0);
        heff_take_n(v_x11_246, 1ULL, 1);
        heff_drop(v_xs_244);
        heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x11_246, 0);
        V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
        V v_x1_2410 = (g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627(v_xs_244, v_st_247));
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_MkPair: {
          V v_x11_2411 = heff_field(v_x1_2410, 0);
          V v_st_2412 = heff_field(v_x1_2410, 1);
          heff_take_n(v_x1_2410, 3ULL, 2);
          switch (heff_tag_of(v_x11_2411)) {
          case TAG_Left: {
            V v_e_2413 = heff_field(v_x11_2411, 0);
            heff_take_n(v_x11_2411, 1ULL, 1);
            heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
            heff_drop(v_x_249);
            heff_drop_cell(v_ru_24x11_246_24Right, 1);
            return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
          }
          case TAG_Right: {
            V v_x_2414 = heff_field(v_x11_2411, 0);
            heff_take_n(v_x11_2411, 1ULL, 1);
            V v_t_2415 = heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_249, v_x_2414})});
            return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_st_2412});
          }
          default: return heff_nomatch(v_x11_2411);
          }
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      default: return heff_nomatch(v_x11_246);
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etraverseS_24s1769424965x1395105627(a[0], a[1]);
}