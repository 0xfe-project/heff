// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_little 844663329
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_waiting 1348170899
static uint32_t shape_assoc__ops__above__below__loosest__errors__span__line[] = {LBL_assoc, LBL_ops, LBL_above, LBL_below, LBL_loosest, LBL_errors, LBL_span, LBL_line};
static uint32_t shape_binder__span[] = {LBL_binder, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eanyS(V, V);
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eanyS_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_24cpr(V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2ecycleDiag(V, V);
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixDeclDone(V, V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo;
V g_heff_2esyntax_2esurface_2eisAnnE(V);
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisAnnE_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
V g_heff_2esyntax_2esurface_2elastEnd(V, V);
V g_heff_2esyntax_2esurface_2elastEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elastEnd_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
V g_heff_2esyntax_2esurface_2esizeSaid(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esizeSaid_clo;
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewholeDefines(V);
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24f1352858702x862623587(V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
HeffT2 g_prelude_2etraverse_24s1597998392x1477757120_24cpr(V, V);
V g_prelude_2etraverse_24s1726903169x1952011622(V);
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1726903169x1952011622_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebind(V v_m_240, V v_f_241, V v_st_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_243_24MkPair, 2);
      return heff_tail(v_f_241, 2, (V[]){v_x_247, v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2enameSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameSet_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2enameSet(v_rest_242));
    return (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_243, heff_dup(v_x_241), NTAG(TAG_MkUnit)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enameSet(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str3, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str5, 76, "` is defined twice: its equations are apart, another definition between them");
Clo g_heff_2esyntax_2esurface_2edefinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefinesOf(V v_open_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Sig: {
    V v_f_243 = heff_field(v_x2_241, 1);
    V v_fsp_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24Sig = heff_take_reuse_n(v_x2_241, 6ULL, 5);
    heff_drop(v_open_240);
    V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str0), heff_strAppend(heff_dup(v_f_243), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str1)));
    return heff_tag_at_n(v_ru_24x2_241_24Sig, TAG_Names, 5, (V[]){heff_dup(v_f_243), v_fsp_244, heff_tag_n(TAG_Just, 1, (V[]){v_f_243}), v_t_247, NTAG(TAG_False)});
  }
  case TAG_Eqn: {
    V v_g_248 = heff_field(v_x2_241, 0);
    V v_e_249 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 3);
    switch (heff_tag_of(v_open_240)) {
    case TAG_Nothing: {
      V v_t_2417;
      switch (heff_tag_of(v_e_249)) {
      case TAG_At: {
        V v_x11_2411 = heff_field(v_e_249, 0);
        heff_take_n(v_e_249, 1ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_MkEquation: {
          V v_fsp_2414 = heff_field(v_x11_2411, 1);
          heff_take_n(v_x11_2411, 2ULL, 4);
          v_t_2417 = v_fsp_2414;
          break;
        }
        default: heff_nomatch(v_x11_2411);
        }
        break;
      }
      default: heff_nomatch(v_e_249);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str2), heff_strAppend(heff_dup(v_g_248), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str3)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2417, heff_tag_n(TAG_Just, 1, (V[]){v_g_248}), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_open_240, 0);
      V v_ru_24open_240_24Just = heff_take_reuse_n(v_open_240, 1ULL, 1);
      if (heff_strEq_c_lent(v_f_2419, v_g_248, 1)) {
        heff_drop(v_g_248);
        heff_drop(v_e_249);
        heff_drop_cell(v_ru_24open_240_24Just, 1);
        return NTAG(TAG_Passes);
      } else {
        V v_t_2427;
        switch (heff_tag_of(v_e_249)) {
        case TAG_At: {
          V v_x11_2421 = heff_field(v_e_249, 0);
          heff_take_n(v_e_249, 1ULL, 2);
          switch (heff_tag_of(v_x11_2421)) {
          case TAG_MkEquation: {
            V v_fsp_2424 = heff_field(v_x11_2421, 1);
            heff_take_n(v_x11_2421, 2ULL, 4);
            v_t_2427 = v_fsp_2424;
            break;
          }
          default: heff_nomatch(v_x11_2421);
          }
          break;
        }
        default: heff_nomatch(v_e_249);
        }
        V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str4), heff_strAppend(heff_dup(v_g_248), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str5)));
        return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2427, heff_tag_at_n(v_ru_24open_240_24Just, TAG_Just, 1, (V[]){v_g_248}), v_t_2428, NTAG(TAG_False)});
      }
    }
    default: return heff_nomatch(v_open_240);
    }
  }
  case TAG_Whole: {
    V v_d_2429 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_open_240);
    return ({ V a_0 = v_d_2429; V r_ = (g_heff_2esyntax_2esurface_2ewholeDefines(a_0)); heff_drop(v_d_2429); r_; });
  }
  case TAG_Doc: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_open_240);
    return NTAG(TAG_Passes);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefinesOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edefNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefNext(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2429;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_d_244)) {
    case TAG_At: {
      V v_s_247 = heff_field(v_d_244, 1);
      heff_take_n(v_d_244, 2ULL, 2);
      v_t_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_j_249 = heff_strFind(((V)&g_heff_2esyntax_2esurface_2edefNext_str0), heff_dup(v_src_240), heff_get_n(v_t_248, 1, 2));
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_j_249);
      v_t_2411 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_2411 = v_j_249;
    }
    V v_t_2428;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_sp_2416 = heff_dup(heff_field(v_it_242, 4));
      v_t_2428 = heff_get_n(v_sp_2416, 0, 2);
      break;
    }
    case TAG_Eqn: {
      V v_sp_2419 = heff_dup(heff_field(v_it_242, 2));
      v_t_2428 = heff_get_n(v_sp_2419, 0, 2);
      break;
    }
    case TAG_Whole: {
      V v_d_2420 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2423;
      switch (heff_tag_of(v_d_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_d_2420, 1);
        heff_take_n(v_d_2420, 2ULL, 2);
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_d_2420);
      }
      v_t_2428 = heff_get_n(v_t_2423, 0, 2);
      break;
    }
    case TAG_Doc: {
      V v_d_2424 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2427;
      switch (heff_tag_of(v_d_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_d_2424, 1);
        heff_take_n(v_d_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_d_2424);
      }
      v_t_2428 = heff_get_n(v_t_2427, 0, 2);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    v_t_2429 = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(v_src_240, heff_intAdd(v_t_2411, MK_INT(1LL)), v_t_2428));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, heff_take_field(v_p_241, 0)});
    V v_items_2431 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_t_2430, heff_take_field(v_p_241, 1)));
    return ({ V rv_0 = v_items_2431; V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_p_241, 4ULL, 3, shape_items__waiting__diags, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    heff_drop(v_t_2429);
    V v_items_2432 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2433 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2433);
    V v_items_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2432});
    V v_items_2435 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2435);
    V v_diags_2436 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
    return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2434, NTAG(TAG_Nil), v_diags_2436});
  }
}
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edefNext(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam41(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2evariantL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Seg: {
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_Braces: {
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam5, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Update: {
    V v_m_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_EUSet: {
    V v_m_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam7, 1, 1, (V[]){v_m_2487});
  }
  case TAG_InstB: {
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFSet: {
    V v_m_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam9, 1, 1, (V[]){v_m_24111});
  }
  case TAG_EFDefault: {
    V v_m_24122 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam10, 1, 1, (V[]){v_m_24122});
  }
  case TAG_Sum: {
    V v_m_24135 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam11, 1, 1, (V[]){v_m_24135});
  }
  case TAG_ECon: {
    V v_c_24143 = heff_field(v_x2_241, 0);
    V v_args_24144 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24145 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24143, v_args_24144));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam12, 1, 1, (V[]){v_m_24145});
  }
  case TAG_EField: {
    V v_m_24155 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam13, 1, 1, (V[]){v_m_24155});
  }
  case TAG_ENeg: {
    V v_m_24165 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam14, 1, 1, (V[]){v_m_24165});
  }
  case TAG_App: {
    V v_m_24175 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam15, 1, 1, (V[]){v_m_24175});
  }
  case TAG_Op: {
    V v_m_24186 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam16, 1, 1, (V[]){v_m_24186});
  }
  case TAG_Ops: {
    V v_m_24196 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam17, 1, 1, (V[]){v_m_24196});
  }
  case TAG_OpRhs: {
    V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam18, 1, 1, (V[]){v_m_24206});
  }
  case TAG_Ann: {
    V v_m_24217 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam19, 1, 1, (V[]){v_m_24217});
  }
  case TAG_BVar: {
    V v_m_24226 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam20, 1, 1, (V[]){v_m_24226});
  }
  case TAG_BImp: {
    V v_m_24237 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam21, 1, 1, (V[]){v_m_24237});
  }
  case TAG_BAnn: {
    V v_m_24250 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam22, 1, 1, (V[]){v_m_24250});
  }
  case TAG_Lam: {
    V v_m_24262 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam23, 1, 1, (V[]){v_m_24262});
  }
  case TAG_Case: {
    V v_m_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam24, 1, 1, (V[]){v_m_24274});
  }
  case TAG_EAlt: {
    V v_m_24285 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam25, 1, 1, (V[]){v_m_24285});
  }
  case TAG_If: {
    V v_m_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam26, 1, 1, (V[]){v_m_24299});
  }
  case TAG_Do: {
    V v_m_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam27, 1, 1, (V[]){v_m_24309});
  }
  case TAG_ESBind: {
    V v_m_24320 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam28, 1, 1, (V[]){v_m_24320});
  }
  case TAG_ELet: {
    V v_m_24334 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam29, 1, 1, (V[]){v_m_24334});
  }
  case TAG_ELetMut: {
    V v_m_24348 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam30, 1, 1, (V[]){v_m_24348});
  }
  case TAG_EAssign: {
    V v_m_24359 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam31, 1, 1, (V[]){v_m_24359});
  }
  case TAG_EWhile: {
    V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam32, 1, 1, (V[]){v_m_24371});
  }
  case TAG_EFor: {
    V v_m_24385 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam33, 1, 1, (V[]){v_m_24385});
  }
  case TAG_EJump: {
    V v_m_24394 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam34, 1, 1, (V[]){v_m_24394});
  }
  case TAG_EReturn: {
    V v_m_24404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam35, 1, 1, (V[]){v_m_24404});
  }
  case TAG_ENest: {
    V v_m_24416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam36, 1, 1, (V[]){v_m_24416});
  }
  case TAG_IfThen: {
    V v_m_24428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam37, 1, 1, (V[]){v_m_24428});
  }
  case TAG_ELetCond: {
    V v_m_24440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam38, 1, 1, (V[]){v_m_24440});
  }
  case TAG_ETry: {
    V v_m_24452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam39, 1, 1, (V[]){v_m_24452});
  }
  case TAG_ECatch: {
    V v_m_24464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam40, 1, 1, (V[]){v_m_24464});
  }
  case TAG_EWith: {
    V v_m_24478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam41, 1, 1, (V[]){v_m_24478});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_249));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2420));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2433));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2445));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_st_2451}));
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_MkPair: {
    V v_x11_2453 = heff_field(v_x1_2452, 0);
    V v_st_2454 = heff_field(v_x1_2452, 1);
    V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
    switch (heff_tag_of(v_x11_2453)) {
    case TAG_Left: {
      V v_e_2455 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
    }
    case TAG_Right: {
      V v_x_2456 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      V v_x_2457 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2456));
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2457}), v_st_2454});
    }
    default: return heff_nomatch(v_x11_2453);
    }
  }
  default: return heff_nomatch(v_x1_2452);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam5(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      V v_x_2469 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2468));
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2469}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2482));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam7(V self, V *args) {
  V v_st_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2488}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_x11_2490 = heff_field(v_x1_2489, 0);
    V v_st_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    switch (heff_tag_of(v_x11_2490)) {
    case TAG_Left: {
      V v_e_2492 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
    }
    case TAG_Right: {
      V v_x_2493 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      V v_x_2494 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2493));
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2494}), v_st_2491});
    }
    default: return heff_nomatch(v_x11_2490);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      V v_x_24118 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24117));
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24118}), v_st_24115});
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam10(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      V v_x_24129 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24128));
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24129}), v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam11(V self, V *args) {
  V v_st_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24137 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_st_24136}));
  switch (heff_tag_of(v_x1_24137)) {
  case TAG_MkPair: {
    V v_x11_24138 = heff_field(v_x1_24137, 0);
    V v_st_24139 = heff_field(v_x1_24137, 1);
    V v_ru_24x1_24137_24MkPair = heff_take_reuse_n(v_x1_24137, 3ULL, 2);
    switch (heff_tag_of(v_x11_24138)) {
    case TAG_Left: {
      V v_e_24140 = heff_field(v_x11_24138, 0);
      heff_take_n(v_x11_24138, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24140}), v_st_24139});
    }
    case TAG_Right: {
      V v_x_24141 = heff_field(v_x11_24138, 0);
      heff_take_n(v_x11_24138, 1ULL, 1);
      V v_x_24142 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24141));
      return heff_tag_at_n(v_ru_24x1_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24142}), v_st_24139});
    }
    default: return heff_nomatch(v_x11_24138);
    }
  }
  default: return heff_nomatch(v_x1_24137);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam12(V self, V *args) {
  V v_st_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_st_24146}));
  switch (heff_tag_of(v_x1_24147)) {
  case TAG_MkPair: {
    V v_x11_24148 = heff_field(v_x1_24147, 0);
    V v_st_24149 = heff_field(v_x1_24147, 1);
    V v_ru_24x1_24147_24MkPair = heff_take_reuse_n(v_x1_24147, 3ULL, 2);
    switch (heff_tag_of(v_x11_24148)) {
    case TAG_Left: {
      V v_e_24150 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24150}), v_st_24149});
    }
    case TAG_Right: {
      V v_x_24151 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      V v_x_24152 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24151));
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24149});
    }
    default: return heff_nomatch(v_x11_24148);
    }
  }
  default: return heff_nomatch(v_x1_24147);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam13(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      V v_x_24162 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24161));
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24162}), v_st_24159});
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam14(V self, V *args) {
  V v_st_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_st_24166}));
  switch (heff_tag_of(v_x1_24167)) {
  case TAG_MkPair: {
    V v_x11_24168 = heff_field(v_x1_24167, 0);
    V v_st_24169 = heff_field(v_x1_24167, 1);
    V v_ru_24x1_24167_24MkPair = heff_take_reuse_n(v_x1_24167, 3ULL, 2);
    switch (heff_tag_of(v_x11_24168)) {
    case TAG_Left: {
      V v_e_24170 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24170}), v_st_24169});
    }
    case TAG_Right: {
      V v_x_24171 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      V v_x_24172 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24171));
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24172}), v_st_24169});
    }
    default: return heff_nomatch(v_x11_24168);
    }
  }
  default: return heff_nomatch(v_x1_24167);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam15(V self, V *args) {
  V v_st_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_st_24176}));
  switch (heff_tag_of(v_x1_24177)) {
  case TAG_MkPair: {
    V v_x11_24178 = heff_field(v_x1_24177, 0);
    V v_st_24179 = heff_field(v_x1_24177, 1);
    V v_ru_24x1_24177_24MkPair = heff_take_reuse_n(v_x1_24177, 3ULL, 2);
    switch (heff_tag_of(v_x11_24178)) {
    case TAG_Left: {
      V v_e_24180 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24180}), v_st_24179});
    }
    case TAG_Right: {
      V v_x_24181 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      V v_x_24182 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24181));
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24182}), v_st_24179});
    }
    default: return heff_nomatch(v_x11_24178);
    }
  }
  default: return heff_nomatch(v_x1_24177);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam16(V self, V *args) {
  V v_st_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_st_24187}));
  switch (heff_tag_of(v_x1_24188)) {
  case TAG_MkPair: {
    V v_x11_24189 = heff_field(v_x1_24188, 0);
    V v_st_24190 = heff_field(v_x1_24188, 1);
    V v_ru_24x1_24188_24MkPair = heff_take_reuse_n(v_x1_24188, 3ULL, 2);
    switch (heff_tag_of(v_x11_24189)) {
    case TAG_Left: {
      V v_e_24191 = heff_field(v_x11_24189, 0);
      heff_take_n(v_x11_24189, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24191}), v_st_24190});
    }
    case TAG_Right: {
      V v_x_24192 = heff_field(v_x11_24189, 0);
      heff_take_n(v_x11_24189, 1ULL, 1);
      V v_x_24193 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24192));
      return heff_tag_at_n(v_ru_24x1_24188_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24193}), v_st_24190});
    }
    default: return heff_nomatch(v_x11_24189);
    }
  }
  default: return heff_nomatch(v_x1_24188);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam17(V self, V *args) {
  V v_st_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_st_24197}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      V v_x_24203 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24202));
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24203}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam18(V self, V *args) {
  V v_st_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_st_24207}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24212));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam19(V self, V *args) {
  V v_st_24218 = args[0];
  V v_m_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24219 = heff_tr(heff_call(v_m_24217, 1, (V[]){v_st_24218}));
  switch (heff_tag_of(v_x1_24219)) {
  case TAG_MkPair: {
    V v_x11_24220 = heff_field(v_x1_24219, 0);
    V v_st_24221 = heff_field(v_x1_24219, 1);
    V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
    switch (heff_tag_of(v_x11_24220)) {
    case TAG_Left: {
      V v_e_24222 = heff_field(v_x11_24220, 0);
      heff_take_n(v_x11_24220, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
    }
    case TAG_Right: {
      V v_x_24223 = heff_field(v_x11_24220, 0);
      heff_take_n(v_x11_24220, 1ULL, 1);
      V v_x_24224 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24223));
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24221});
    }
    default: return heff_nomatch(v_x11_24220);
    }
  }
  default: return heff_nomatch(v_x1_24219);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam20(V self, V *args) {
  V v_st_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_st_24227}));
  switch (heff_tag_of(v_x1_24228)) {
  case TAG_MkPair: {
    V v_x11_24229 = heff_field(v_x1_24228, 0);
    V v_st_24230 = heff_field(v_x1_24228, 1);
    V v_ru_24x1_24228_24MkPair = heff_take_reuse_n(v_x1_24228, 3ULL, 2);
    switch (heff_tag_of(v_x11_24229)) {
    case TAG_Left: {
      V v_e_24231 = heff_field(v_x11_24229, 0);
      heff_take_n(v_x11_24229, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24231}), v_st_24230});
    }
    case TAG_Right: {
      V v_x_24232 = heff_field(v_x11_24229, 0);
      heff_take_n(v_x11_24229, 1ULL, 1);
      V v_x_24233 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24232));
      return heff_tag_at_n(v_ru_24x1_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24233}), v_st_24230});
    }
    default: return heff_nomatch(v_x11_24229);
    }
  }
  default: return heff_nomatch(v_x1_24228);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam21(V self, V *args) {
  V v_st_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_st_24238}));
  switch (heff_tag_of(v_x1_24239)) {
  case TAG_MkPair: {
    V v_x11_24240 = heff_field(v_x1_24239, 0);
    V v_st_24241 = heff_field(v_x1_24239, 1);
    V v_ru_24x1_24239_24MkPair = heff_take_reuse_n(v_x1_24239, 3ULL, 2);
    switch (heff_tag_of(v_x11_24240)) {
    case TAG_Left: {
      V v_e_24242 = heff_field(v_x11_24240, 0);
      heff_take_n(v_x11_24240, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24242}), v_st_24241});
    }
    case TAG_Right: {
      V v_x_24243 = heff_field(v_x11_24240, 0);
      heff_take_n(v_x11_24240, 1ULL, 1);
      V v_x_24244 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24243));
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24244}), v_st_24241});
    }
    default: return heff_nomatch(v_x11_24240);
    }
  }
  default: return heff_nomatch(v_x1_24239);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam22(V self, V *args) {
  V v_st_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_st_24251}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_MkPair: {
    V v_x11_24253 = heff_field(v_x1_24252, 0);
    V v_st_24254 = heff_field(v_x1_24252, 1);
    V v_ru_24x1_24252_24MkPair = heff_take_reuse_n(v_x1_24252, 3ULL, 2);
    switch (heff_tag_of(v_x11_24253)) {
    case TAG_Left: {
      V v_e_24255 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24255}), v_st_24254});
    }
    case TAG_Right: {
      V v_x_24256 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      V v_x_24257 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24256));
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24257}), v_st_24254});
    }
    default: return heff_nomatch(v_x11_24253);
    }
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam23(V self, V *args) {
  V v_st_24263 = args[0];
  V v_m_24262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24264 = heff_tr(heff_call(v_m_24262, 1, (V[]){v_st_24263}));
  switch (heff_tag_of(v_x1_24264)) {
  case TAG_MkPair: {
    V v_x11_24265 = heff_field(v_x1_24264, 0);
    V v_st_24266 = heff_field(v_x1_24264, 1);
    V v_ru_24x1_24264_24MkPair = heff_take_reuse_n(v_x1_24264, 3ULL, 2);
    switch (heff_tag_of(v_x11_24265)) {
    case TAG_Left: {
      V v_e_24267 = heff_field(v_x11_24265, 0);
      heff_take_n(v_x11_24265, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24267}), v_st_24266});
    }
    case TAG_Right: {
      V v_x_24268 = heff_field(v_x11_24265, 0);
      heff_take_n(v_x11_24265, 1ULL, 1);
      V v_x_24269 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24268));
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24269}), v_st_24266});
    }
    default: return heff_nomatch(v_x11_24265);
    }
  }
  default: return heff_nomatch(v_x1_24264);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam24(V self, V *args) {
  V v_st_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24276 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_st_24275}));
  switch (heff_tag_of(v_x1_24276)) {
  case TAG_MkPair: {
    V v_x11_24277 = heff_field(v_x1_24276, 0);
    V v_st_24278 = heff_field(v_x1_24276, 1);
    V v_ru_24x1_24276_24MkPair = heff_take_reuse_n(v_x1_24276, 3ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_Left: {
      V v_e_24279 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24279}), v_st_24278});
    }
    case TAG_Right: {
      V v_x_24280 = heff_field(v_x11_24277, 0);
      heff_take_n(v_x11_24277, 1ULL, 1);
      V v_x_24281 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24280));
      return heff_tag_at_n(v_ru_24x1_24276_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24281}), v_st_24278});
    }
    default: return heff_nomatch(v_x11_24277);
    }
  }
  default: return heff_nomatch(v_x1_24276);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam25(V self, V *args) {
  V v_st_24286 = args[0];
  V v_m_24285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24287 = heff_tr(heff_call(v_m_24285, 1, (V[]){v_st_24286}));
  switch (heff_tag_of(v_x1_24287)) {
  case TAG_MkPair: {
    V v_x11_24288 = heff_field(v_x1_24287, 0);
    V v_st_24289 = heff_field(v_x1_24287, 1);
    V v_ru_24x1_24287_24MkPair = heff_take_reuse_n(v_x1_24287, 3ULL, 2);
    switch (heff_tag_of(v_x11_24288)) {
    case TAG_Left: {
      V v_e_24290 = heff_field(v_x11_24288, 0);
      heff_take_n(v_x11_24288, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24287_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24290}), v_st_24289});
    }
    case TAG_Right: {
      V v_x_24291 = heff_field(v_x11_24288, 0);
      heff_take_n(v_x11_24288, 1ULL, 1);
      V v_x_24292 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24291));
      return heff_tag_at_n(v_ru_24x1_24287_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24292}), v_st_24289});
    }
    default: return heff_nomatch(v_x11_24288);
    }
  }
  default: return heff_nomatch(v_x1_24287);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam26(V self, V *args) {
  V v_st_24300 = args[0];
  V v_m_24299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24301 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_st_24300}));
  switch (heff_tag_of(v_x1_24301)) {
  case TAG_MkPair: {
    V v_x11_24302 = heff_field(v_x1_24301, 0);
    V v_st_24303 = heff_field(v_x1_24301, 1);
    V v_ru_24x1_24301_24MkPair = heff_take_reuse_n(v_x1_24301, 3ULL, 2);
    switch (heff_tag_of(v_x11_24302)) {
    case TAG_Left: {
      V v_e_24304 = heff_field(v_x11_24302, 0);
      heff_take_n(v_x11_24302, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24304}), v_st_24303});
    }
    case TAG_Right: {
      V v_x_24305 = heff_field(v_x11_24302, 0);
      heff_take_n(v_x11_24302, 1ULL, 1);
      V v_x_24306 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24305));
      return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24303});
    }
    default: return heff_nomatch(v_x11_24302);
    }
  }
  default: return heff_nomatch(v_x1_24301);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam27(V self, V *args) {
  V v_st_24310 = args[0];
  V v_m_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24311 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_st_24310}));
  switch (heff_tag_of(v_x1_24311)) {
  case TAG_MkPair: {
    V v_x11_24312 = heff_field(v_x1_24311, 0);
    V v_st_24313 = heff_field(v_x1_24311, 1);
    V v_ru_24x1_24311_24MkPair = heff_take_reuse_n(v_x1_24311, 3ULL, 2);
    switch (heff_tag_of(v_x11_24312)) {
    case TAG_Left: {
      V v_e_24314 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24314}), v_st_24313});
    }
    case TAG_Right: {
      V v_x_24315 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      V v_x_24316 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24315));
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24313});
    }
    default: return heff_nomatch(v_x11_24312);
    }
  }
  default: return heff_nomatch(v_x1_24311);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam28(V self, V *args) {
  V v_st_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_st_24321}));
  switch (heff_tag_of(v_x1_24322)) {
  case TAG_MkPair: {
    V v_x11_24323 = heff_field(v_x1_24322, 0);
    V v_st_24324 = heff_field(v_x1_24322, 1);
    V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
    switch (heff_tag_of(v_x11_24323)) {
    case TAG_Left: {
      V v_e_24325 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
    }
    case TAG_Right: {
      V v_x_24326 = heff_field(v_x11_24323, 0);
      heff_take_n(v_x11_24323, 1ULL, 1);
      V v_x_24327 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24326));
      return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24327}), v_st_24324});
    }
    default: return heff_nomatch(v_x11_24323);
    }
  }
  default: return heff_nomatch(v_x1_24322);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam29(V self, V *args) {
  V v_st_24335 = args[0];
  V v_m_24334 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24336 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_st_24335}));
  switch (heff_tag_of(v_x1_24336)) {
  case TAG_MkPair: {
    V v_x11_24337 = heff_field(v_x1_24336, 0);
    V v_st_24338 = heff_field(v_x1_24336, 1);
    V v_ru_24x1_24336_24MkPair = heff_take_reuse_n(v_x1_24336, 3ULL, 2);
    switch (heff_tag_of(v_x11_24337)) {
    case TAG_Left: {
      V v_e_24339 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24339}), v_st_24338});
    }
    case TAG_Right: {
      V v_x_24340 = heff_field(v_x11_24337, 0);
      heff_take_n(v_x11_24337, 1ULL, 1);
      V v_x_24341 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24340));
      return heff_tag_at_n(v_ru_24x1_24336_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24341}), v_st_24338});
    }
    default: return heff_nomatch(v_x11_24337);
    }
  }
  default: return heff_nomatch(v_x1_24336);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam30(V self, V *args) {
  V v_st_24349 = args[0];
  V v_m_24348 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24350 = heff_tr(heff_call(v_m_24348, 1, (V[]){v_st_24349}));
  switch (heff_tag_of(v_x1_24350)) {
  case TAG_MkPair: {
    V v_x11_24351 = heff_field(v_x1_24350, 0);
    V v_st_24352 = heff_field(v_x1_24350, 1);
    V v_ru_24x1_24350_24MkPair = heff_take_reuse_n(v_x1_24350, 3ULL, 2);
    switch (heff_tag_of(v_x11_24351)) {
    case TAG_Left: {
      V v_e_24353 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24353}), v_st_24352});
    }
    case TAG_Right: {
      V v_x_24354 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      V v_x_24355 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24354));
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24352});
    }
    default: return heff_nomatch(v_x11_24351);
    }
  }
  default: return heff_nomatch(v_x1_24350);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam31(V self, V *args) {
  V v_st_24360 = args[0];
  V v_m_24359 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24361 = heff_tr(heff_call(v_m_24359, 1, (V[]){v_st_24360}));
  switch (heff_tag_of(v_x1_24361)) {
  case TAG_MkPair: {
    V v_x11_24362 = heff_field(v_x1_24361, 0);
    V v_st_24363 = heff_field(v_x1_24361, 1);
    V v_ru_24x1_24361_24MkPair = heff_take_reuse_n(v_x1_24361, 3ULL, 2);
    switch (heff_tag_of(v_x11_24362)) {
    case TAG_Left: {
      V v_e_24364 = heff_field(v_x11_24362, 0);
      heff_take_n(v_x11_24362, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24364}), v_st_24363});
    }
    case TAG_Right: {
      V v_x_24365 = heff_field(v_x11_24362, 0);
      heff_take_n(v_x11_24362, 1ULL, 1);
      V v_x_24366 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24365));
      return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24366}), v_st_24363});
    }
    default: return heff_nomatch(v_x11_24362);
    }
  }
  default: return heff_nomatch(v_x1_24361);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam32(V self, V *args) {
  V v_st_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24373 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_st_24372}));
  switch (heff_tag_of(v_x1_24373)) {
  case TAG_MkPair: {
    V v_x11_24374 = heff_field(v_x1_24373, 0);
    V v_st_24375 = heff_field(v_x1_24373, 1);
    V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
    switch (heff_tag_of(v_x11_24374)) {
    case TAG_Left: {
      V v_e_24376 = heff_field(v_x11_24374, 0);
      heff_take_n(v_x11_24374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
    }
    case TAG_Right: {
      V v_x_24377 = heff_field(v_x11_24374, 0);
      heff_take_n(v_x11_24374, 1ULL, 1);
      V v_x_24378 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24377));
      return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24378}), v_st_24375});
    }
    default: return heff_nomatch(v_x11_24374);
    }
  }
  default: return heff_nomatch(v_x1_24373);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam33(V self, V *args) {
  V v_st_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24386}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_MkPair: {
    V v_x11_24388 = heff_field(v_x1_24387, 0);
    V v_st_24389 = heff_field(v_x1_24387, 1);
    V v_ru_24x1_24387_24MkPair = heff_take_reuse_n(v_x1_24387, 3ULL, 2);
    switch (heff_tag_of(v_x11_24388)) {
    case TAG_Left: {
      V v_e_24390 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24390}), v_st_24389});
    }
    case TAG_Right: {
      V v_x_24391 = heff_field(v_x11_24388, 0);
      heff_take_n(v_x11_24388, 1ULL, 1);
      V v_x_24392 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24391));
      return heff_tag_at_n(v_ru_24x1_24387_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24392}), v_st_24389});
    }
    default: return heff_nomatch(v_x11_24388);
    }
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam34(V self, V *args) {
  V v_st_24395 = args[0];
  V v_m_24394 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24396 = heff_tr(heff_call(v_m_24394, 1, (V[]){v_st_24395}));
  switch (heff_tag_of(v_x1_24396)) {
  case TAG_MkPair: {
    V v_x11_24397 = heff_field(v_x1_24396, 0);
    V v_st_24398 = heff_field(v_x1_24396, 1);
    V v_ru_24x1_24396_24MkPair = heff_take_reuse_n(v_x1_24396, 3ULL, 2);
    switch (heff_tag_of(v_x11_24397)) {
    case TAG_Left: {
      V v_e_24399 = heff_field(v_x11_24397, 0);
      heff_take_n(v_x11_24397, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24396_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24399}), v_st_24398});
    }
    case TAG_Right: {
      V v_x_24400 = heff_field(v_x11_24397, 0);
      heff_take_n(v_x11_24397, 1ULL, 1);
      V v_x_24401 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24400));
      return heff_tag_at_n(v_ru_24x1_24396_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24401}), v_st_24398});
    }
    default: return heff_nomatch(v_x11_24397);
    }
  }
  default: return heff_nomatch(v_x1_24396);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam35(V self, V *args) {
  V v_st_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_st_24405}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      V v_x_24411 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24410));
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24411}), v_st_24408});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam36(V self, V *args) {
  V v_st_24417 = args[0];
  V v_m_24416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24418 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_st_24417}));
  switch (heff_tag_of(v_x1_24418)) {
  case TAG_MkPair: {
    V v_x11_24419 = heff_field(v_x1_24418, 0);
    V v_st_24420 = heff_field(v_x1_24418, 1);
    V v_ru_24x1_24418_24MkPair = heff_take_reuse_n(v_x1_24418, 3ULL, 2);
    switch (heff_tag_of(v_x11_24419)) {
    case TAG_Left: {
      V v_e_24421 = heff_field(v_x11_24419, 0);
      heff_take_n(v_x11_24419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24421}), v_st_24420});
    }
    case TAG_Right: {
      V v_x_24422 = heff_field(v_x11_24419, 0);
      heff_take_n(v_x11_24419, 1ULL, 1);
      V v_x_24423 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24422));
      return heff_tag_at_n(v_ru_24x1_24418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24423}), v_st_24420});
    }
    default: return heff_nomatch(v_x11_24419);
    }
  }
  default: return heff_nomatch(v_x1_24418);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam37(V self, V *args) {
  V v_st_24429 = args[0];
  V v_m_24428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24430 = heff_tr(heff_call(v_m_24428, 1, (V[]){v_st_24429}));
  switch (heff_tag_of(v_x1_24430)) {
  case TAG_MkPair: {
    V v_x11_24431 = heff_field(v_x1_24430, 0);
    V v_st_24432 = heff_field(v_x1_24430, 1);
    V v_ru_24x1_24430_24MkPair = heff_take_reuse_n(v_x1_24430, 3ULL, 2);
    switch (heff_tag_of(v_x11_24431)) {
    case TAG_Left: {
      V v_e_24433 = heff_field(v_x11_24431, 0);
      heff_take_n(v_x11_24431, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24433}), v_st_24432});
    }
    case TAG_Right: {
      V v_x_24434 = heff_field(v_x11_24431, 0);
      heff_take_n(v_x11_24431, 1ULL, 1);
      V v_x_24435 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24434));
      return heff_tag_at_n(v_ru_24x1_24430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24435}), v_st_24432});
    }
    default: return heff_nomatch(v_x11_24431);
    }
  }
  default: return heff_nomatch(v_x1_24430);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam38(V self, V *args) {
  V v_st_24441 = args[0];
  V v_m_24440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24442 = heff_tr(heff_call(v_m_24440, 1, (V[]){v_st_24441}));
  switch (heff_tag_of(v_x1_24442)) {
  case TAG_MkPair: {
    V v_x11_24443 = heff_field(v_x1_24442, 0);
    V v_st_24444 = heff_field(v_x1_24442, 1);
    V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
    switch (heff_tag_of(v_x11_24443)) {
    case TAG_Left: {
      V v_e_24445 = heff_field(v_x11_24443, 0);
      heff_take_n(v_x11_24443, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24445}), v_st_24444});
    }
    case TAG_Right: {
      V v_x_24446 = heff_field(v_x11_24443, 0);
      heff_take_n(v_x11_24443, 1ULL, 1);
      V v_x_24447 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24446));
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24447}), v_st_24444});
    }
    default: return heff_nomatch(v_x11_24443);
    }
  }
  default: return heff_nomatch(v_x1_24442);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam39(V self, V *args) {
  V v_st_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24454 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_st_24453}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      V v_x_24459 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24458));
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24459}), v_st_24456});
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam40(V self, V *args) {
  V v_st_24465 = args[0];
  V v_m_24464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24466 = heff_tr(heff_call(v_m_24464, 1, (V[]){v_st_24465}));
  switch (heff_tag_of(v_x1_24466)) {
  case TAG_MkPair: {
    V v_x11_24467 = heff_field(v_x1_24466, 0);
    V v_st_24468 = heff_field(v_x1_24466, 1);
    V v_ru_24x1_24466_24MkPair = heff_take_reuse_n(v_x1_24466, 3ULL, 2);
    switch (heff_tag_of(v_x11_24467)) {
    case TAG_Left: {
      V v_e_24469 = heff_field(v_x11_24467, 0);
      heff_take_n(v_x11_24467, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24469}), v_st_24468});
    }
    case TAG_Right: {
      V v_x_24470 = heff_field(v_x11_24467, 0);
      heff_take_n(v_x11_24467, 1ULL, 1);
      V v_x_24471 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24470));
      return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24471}), v_st_24468});
    }
    default: return heff_nomatch(v_x11_24467);
    }
  }
  default: return heff_nomatch(v_x1_24466);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam41(V self, V *args) {
  V v_st_24479 = args[0];
  V v_m_24478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24480 = heff_tr(heff_call(v_m_24478, 1, (V[]){v_st_24479}));
  switch (heff_tag_of(v_x1_24480)) {
  case TAG_MkPair: {
    V v_x11_24481 = heff_field(v_x1_24480, 0);
    V v_st_24482 = heff_field(v_x1_24480, 1);
    V v_ru_24x1_24480_24MkPair = heff_take_reuse_n(v_x1_24480, 3ULL, 2);
    switch (heff_tag_of(v_x11_24481)) {
    case TAG_Left: {
      V v_e_24483 = heff_field(v_x11_24481, 0);
      heff_take_n(v_x11_24481, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24483}), v_st_24482});
    }
    case TAG_Right: {
      V v_x_24484 = heff_field(v_x11_24481, 0);
      heff_take_n(v_x11_24481, 1ULL, 1);
      V v_x_24485 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24484));
      return heff_tag_at_n(v_ru_24x1_24480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24485}), v_st_24482});
    }
    default: return heff_nomatch(v_x11_24481);
    }
  }
  default: return heff_nomatch(v_x1_24480);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str77, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam41(V self, V *args);
Clo g_heff_2esyntax_2esurface_2elamBinderL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elamBinderL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elamBinderL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2447 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str8));
    V v_msg_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str9), v_t_2448);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam4, 1, 2, (V[]){v_t_2446, v_msg_2449});
  }
  case TAG_Braces: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2458 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2459 = heff_strAppend(heff_get_n(v_t_2458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str10));
    V v_msg_2460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str11), v_t_2459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam5, 1, 2, (V[]){v_t_2457, v_msg_2460});
  }
  case TAG_Update: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2481 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str14));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str15), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam7, 1, 2, (V[]){v_t_2480, v_msg_2483});
  }
  case TAG_InstB: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24113 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24114 = heff_strAppend(heff_get_n(v_t_24113, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str20));
    V v_msg_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str21), v_t_24114);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam10, 1, 2, (V[]){v_t_24112, v_msg_24115});
  }
  case TAG_Sum: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24125 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str22));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str23), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam11, 1, 2, (V[]){v_t_24124, v_msg_24127});
  }
  case TAG_ECon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24133 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24134 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str24));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str25), v_t_24135);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam12, 1, 2, (V[]){v_t_24133, v_msg_24136});
  }
  case TAG_EField: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24143 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24144 = heff_strAppend(heff_get_n(v_t_24143, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str26));
    V v_msg_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str27), v_t_24144);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam13, 1, 2, (V[]){v_t_24142, v_msg_24145});
  }
  case TAG_ENeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24151 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24152 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24153 = heff_strAppend(heff_get_n(v_t_24152, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str28));
    V v_msg_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str29), v_t_24153);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam14, 1, 2, (V[]){v_t_24151, v_msg_24154});
  }
  case TAG_App: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Op: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24171 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24172 = heff_strAppend(heff_get_n(v_t_24171, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str32));
    V v_msg_24173 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str33), v_t_24172);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam16, 1, 2, (V[]){v_t_24170, v_msg_24173});
  }
  case TAG_Ops: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24179 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24180 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str34));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str35), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam17, 1, 2, (V[]){v_t_24179, v_msg_24182});
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_Ann: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24199 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str38));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str39), v_t_24200);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam19, 1, 2, (V[]){v_t_24198, v_msg_24201});
  }
  case TAG_BVar: {
    V v_x_24205 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam20, 1, 1, (V[]){v_x_24205});
  }
  case TAG_BImp: {
    V v_o_24211 = heff_field(v_e_241, 0);
    V v_x_24212 = heff_field(v_e_241, 1);
    V v_c_24213 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam21, 1, 3, (V[]){v_x_24212, v_o_24211, v_c_24213});
  }
  case TAG_BAnn: {
    V v_x_24220 = heff_field(v_e_241, 1);
    V v_ty_24222 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 5);
    V v_m_24224 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24222}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam22, 1, 2, (V[]){v_m_24224, v_x_24220});
  }
  case TAG_Lam: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24242 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24243 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24244 = heff_strAppend(heff_get_n(v_t_24243, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str40));
    V v_msg_24245 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str41), v_t_24244);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam23, 1, 2, (V[]){v_t_24242, v_msg_24245});
  }
  case TAG_Case: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24253 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24254 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24255 = heff_strAppend(heff_get_n(v_t_24254, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str42));
    V v_msg_24256 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str43), v_t_24255);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam24, 1, 2, (V[]){v_t_24253, v_msg_24256});
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24263 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24264 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24265 = heff_strAppend(heff_get_n(v_t_24264, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str44));
    V v_msg_24266 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str45), v_t_24265);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam25, 1, 2, (V[]){v_t_24263, v_msg_24266});
  }
  case TAG_If: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24276 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24277 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24278 = heff_strAppend(heff_get_n(v_t_24277, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str46));
    V v_msg_24279 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str47), v_t_24278);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam26, 1, 2, (V[]){v_t_24276, v_msg_24279});
  }
  case TAG_Do: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24285 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24286 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24287 = heff_strAppend(heff_get_n(v_t_24286, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str48));
    V v_msg_24288 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str49), v_t_24287);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam27, 1, 2, (V[]){v_t_24285, v_msg_24288});
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24295 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24296 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24297 = heff_strAppend(heff_get_n(v_t_24296, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str50));
    V v_msg_24298 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str51), v_t_24297);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam28, 1, 2, (V[]){v_t_24295, v_msg_24298});
  }
  case TAG_ELet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24308 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24309 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24310 = heff_strAppend(heff_get_n(v_t_24309, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str52));
    V v_msg_24311 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str53), v_t_24310);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam29, 1, 2, (V[]){v_t_24308, v_msg_24311});
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24321 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24322 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24323 = heff_strAppend(heff_get_n(v_t_24322, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str54));
    V v_msg_24324 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str55), v_t_24323);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam30, 1, 2, (V[]){v_t_24321, v_msg_24324});
  }
  case TAG_EAssign: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24331 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24332 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24333 = heff_strAppend(heff_get_n(v_t_24332, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str56));
    V v_msg_24334 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str57), v_t_24333);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam31, 1, 2, (V[]){v_t_24331, v_msg_24334});
  }
  case TAG_EWhile: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24342 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24343 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24344 = heff_strAppend(heff_get_n(v_t_24343, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str58));
    V v_msg_24345 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str59), v_t_24344);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam32, 1, 2, (V[]){v_t_24342, v_msg_24345});
  }
  case TAG_EFor: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24355 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24356 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24357 = heff_strAppend(heff_get_n(v_t_24356, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str60));
    V v_msg_24358 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str61), v_t_24357);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam33, 1, 2, (V[]){v_t_24355, v_msg_24358});
  }
  case TAG_EJump: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24363 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24364 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24365 = heff_strAppend(heff_get_n(v_t_24364, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str62));
    V v_msg_24366 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str63), v_t_24365);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam34, 1, 2, (V[]){v_t_24363, v_msg_24366});
  }
  case TAG_EReturn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24372 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24373 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24374 = heff_strAppend(heff_get_n(v_t_24373, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str64));
    V v_msg_24375 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str65), v_t_24374);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam35, 1, 2, (V[]){v_t_24372, v_msg_24375});
  }
  case TAG_ENest: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24383 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24384 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24385 = heff_strAppend(heff_get_n(v_t_24384, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str66));
    V v_msg_24386 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str67), v_t_24385);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam36, 1, 2, (V[]){v_t_24383, v_msg_24386});
  }
  case TAG_IfThen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24394 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24395 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24396 = heff_strAppend(heff_get_n(v_t_24395, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str68));
    V v_msg_24397 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str69), v_t_24396);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam37, 1, 2, (V[]){v_t_24394, v_msg_24397});
  }
  case TAG_ELetCond: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24405 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24406 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24407 = heff_strAppend(heff_get_n(v_t_24406, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str70));
    V v_msg_24408 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str71), v_t_24407);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam38, 1, 2, (V[]){v_t_24405, v_msg_24408});
  }
  case TAG_ETry: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24416 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24417 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24418 = heff_strAppend(heff_get_n(v_t_24417, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str72));
    V v_msg_24419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str73), v_t_24418);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam39, 1, 2, (V[]){v_t_24416, v_msg_24419});
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24427 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24428 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24429 = heff_strAppend(heff_get_n(v_t_24428, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str74));
    V v_msg_24430 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str75), v_t_24429);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam40, 1, 2, (V[]){v_t_24427, v_msg_24430});
  }
  case TAG_EWith: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24440 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24441 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24442 = heff_strAppend(heff_get_n(v_t_24441, 1, 9), ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str76));
    V v_msg_24443 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str77), v_t_24442);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam41, 1, 2, (V[]){v_t_24440, v_msg_24443});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elamBinderL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args) {
  V v_st_2450 = args[0];
  V v_t_2446 = heff_env(self)[0];
  V v_msg_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2446, 3), heff_get_n(v_t_2446, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, v_t_2451, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2452}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam5(V self, V *args) {
  V v_st_2461 = args[0];
  V v_t_2457 = heff_env(self)[0];
  V v_msg_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2457, 3), heff_get_n(v_t_2457, 4, 9)});
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2460, v_t_2462, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2461});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam7(V self, V *args) {
  V v_st_2484 = args[0];
  V v_t_2480 = heff_env(self)[0];
  V v_msg_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2480, 3), heff_get_n(v_t_2480, 4, 9)});
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, v_t_2485, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam10(V self, V *args) {
  V v_st_24116 = args[0];
  V v_t_24112 = heff_env(self)[0];
  V v_msg_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24112, 3), heff_get_n(v_t_24112, 4, 9)});
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24115, v_t_24117, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24116});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam11(V self, V *args) {
  V v_st_24128 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_msg_24127 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24124, 3), heff_get_n(v_t_24124, 4, 9)});
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, v_t_24129, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam12(V self, V *args) {
  V v_st_24137 = args[0];
  V v_t_24133 = heff_env(self)[0];
  V v_msg_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24133, 3), heff_get_n(v_t_24133, 4, 9)});
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, v_t_24138, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam13(V self, V *args) {
  V v_st_24146 = args[0];
  V v_t_24142 = heff_env(self)[0];
  V v_msg_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24142, 3), heff_get_n(v_t_24142, 4, 9)});
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24145, v_t_24147, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24148}), v_st_24146});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam14(V self, V *args) {
  V v_st_24155 = args[0];
  V v_t_24151 = heff_env(self)[0];
  V v_msg_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24151, 3), heff_get_n(v_t_24151, 4, 9)});
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24154, v_t_24156, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24155});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam16(V self, V *args) {
  V v_st_24174 = args[0];
  V v_t_24170 = heff_env(self)[0];
  V v_msg_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24170, 3), heff_get_n(v_t_24170, 4, 9)});
  V v_t_24176 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24173, v_t_24175, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24176}), v_st_24174});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam17(V self, V *args) {
  V v_st_24183 = args[0];
  V v_t_24179 = heff_env(self)[0];
  V v_msg_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24179, 3), heff_get_n(v_t_24179, 4, 9)});
  V v_t_24185 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, v_t_24184, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24185}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam19(V self, V *args) {
  V v_st_24202 = args[0];
  V v_t_24198 = heff_env(self)[0];
  V v_msg_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24203 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24198, 3), heff_get_n(v_t_24198, 4, 9)});
  V v_t_24204 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, v_t_24203, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24204}), v_st_24202});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam20(V self, V *args) {
  V v_st_24206 = args[0];
  V v_x_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24207 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24205, 3)), heff_dup(heff_rfield(v_x_24205, 4))});
  V v_t_24208 = heff_tag_n(TAG_LamName, 2, (V[]){heff_take_field(v_x_24205, 1), v_t_24207});
  V v_t_24209 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24205, 3), heff_get_n(v_x_24205, 4, 9)});
  V v_t_24210 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_binder__span, (V[]){v_t_24208, v_t_24209})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24210, v_st_24206});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam21(V self, V *args) {
  V v_st_24214 = args[0];
  V v_x_24212 = heff_env(self)[0];
  V v_o_24211 = heff_env(self)[1];
  V v_c_24213 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24215 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_24212, 3), heff_take_field(v_x_24212, 4)});
  V v_t_24216 = heff_tag_n(TAG_LamImplicit, 2, (V[]){heff_get_n(v_x_24212, 1, 9), v_t_24215});
  V v_t_24217 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24211, 3, 9), heff_get_n(v_c_24213, 4, 9)});
  V v_t_24218 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_binder__span, (V[]){v_t_24216, v_t_24217})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24218, v_st_24214});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam22(V self, V *args) {
  V v_st_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  V v_x_24220 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_st_24225}));
  switch (heff_tag_of(v_x1_24226)) {
  case TAG_MkPair: {
    V v_x11_24227 = heff_field(v_x1_24226, 0);
    V v_st_24228 = heff_field(v_x1_24226, 1);
    V v_ru_24x1_24226_24MkPair = heff_take_reuse_n(v_x1_24226, 3ULL, 2);
    switch (heff_tag_of(v_x11_24227)) {
    case TAG_Left: {
      V v_e_24229 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      heff_drop_rec(v_x_24220, 9);
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24229}), v_st_24228});
    }
    case TAG_Right: {
      V v_x_24230 = heff_field(v_x11_24227, 0);
      V v_ru_24x11_24227_24Right = heff_take_reuse_n(v_x11_24227, 1ULL, 1);
      V v_t_24231 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24220, 3)), heff_take_field(v_x_24220, 4)});
      V v_t_24232 = heff_tag_n(TAG_LamAnn, 3, (V[]){heff_take_field(v_x_24220, 1), v_t_24231, heff_dup(v_x_24230)});
      V v_t_24235;
      switch (heff_tag_of(v_x_24230)) {
      case TAG_At: {
        V v_s_24234 = heff_field(v_x_24230, 1);
        heff_take_n(v_x_24230, 2ULL, 2);
        v_t_24235 = v_s_24234;
        break;
      }
      default: heff_nomatch(v_x_24230);
      }
      V v_t_24236 = ({ V rv_0 = heff_get_n(v_x_24220, 3, 9); V rr_ = heff_rec_reuse_nf(v_t_24235, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24237 = heff_tag_at_n(v_ru_24x11_24227_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_binder__span, (V[]){v_t_24232, v_t_24236})});
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){v_t_24237, v_st_24228});
    }
    default: return heff_nomatch(v_x11_24227);
    }
  }
  default: return heff_nomatch(v_x1_24226);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam23(V self, V *args) {
  V v_st_24246 = args[0];
  V v_t_24242 = heff_env(self)[0];
  V v_msg_24245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24242, 3), heff_get_n(v_t_24242, 4, 9)});
  V v_t_24248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24245, v_t_24247, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24248}), v_st_24246});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam24(V self, V *args) {
  V v_st_24257 = args[0];
  V v_t_24253 = heff_env(self)[0];
  V v_msg_24256 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24258 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24253, 3), heff_get_n(v_t_24253, 4, 9)});
  V v_t_24259 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24256, v_t_24258, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24259}), v_st_24257});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam25(V self, V *args) {
  V v_st_24267 = args[0];
  V v_t_24263 = heff_env(self)[0];
  V v_msg_24266 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24268 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24263, 3), heff_get_n(v_t_24263, 4, 9)});
  V v_t_24269 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24266, v_t_24268, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24269}), v_st_24267});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam26(V self, V *args) {
  V v_st_24280 = args[0];
  V v_t_24276 = heff_env(self)[0];
  V v_msg_24279 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24281 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24276, 3), heff_get_n(v_t_24276, 4, 9)});
  V v_t_24282 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24279, v_t_24281, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24282}), v_st_24280});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam27(V self, V *args) {
  V v_st_24289 = args[0];
  V v_t_24285 = heff_env(self)[0];
  V v_msg_24288 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24290 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24285, 3), heff_get_n(v_t_24285, 4, 9)});
  V v_t_24291 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24288, v_t_24290, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24291}), v_st_24289});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam28(V self, V *args) {
  V v_st_24299 = args[0];
  V v_t_24295 = heff_env(self)[0];
  V v_msg_24298 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24300 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24295, 3), heff_get_n(v_t_24295, 4, 9)});
  V v_t_24301 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24298, v_t_24300, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24301}), v_st_24299});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam29(V self, V *args) {
  V v_st_24312 = args[0];
  V v_t_24308 = heff_env(self)[0];
  V v_msg_24311 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24308, 3), heff_get_n(v_t_24308, 4, 9)});
  V v_t_24314 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24311, v_t_24313, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24314}), v_st_24312});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam30(V self, V *args) {
  V v_st_24325 = args[0];
  V v_t_24321 = heff_env(self)[0];
  V v_msg_24324 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24326 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24321, 3), heff_get_n(v_t_24321, 4, 9)});
  V v_t_24327 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24324, v_t_24326, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24327}), v_st_24325});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam31(V self, V *args) {
  V v_st_24335 = args[0];
  V v_t_24331 = heff_env(self)[0];
  V v_msg_24334 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24336 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24331, 3), heff_get_n(v_t_24331, 4, 9)});
  V v_t_24337 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24334, v_t_24336, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24337}), v_st_24335});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam32(V self, V *args) {
  V v_st_24346 = args[0];
  V v_t_24342 = heff_env(self)[0];
  V v_msg_24345 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24347 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24342, 3), heff_get_n(v_t_24342, 4, 9)});
  V v_t_24348 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24345, v_t_24347, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24348}), v_st_24346});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam33(V self, V *args) {
  V v_st_24359 = args[0];
  V v_t_24355 = heff_env(self)[0];
  V v_msg_24358 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24360 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24355, 3), heff_get_n(v_t_24355, 4, 9)});
  V v_t_24361 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24358, v_t_24360, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24361}), v_st_24359});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam34(V self, V *args) {
  V v_st_24367 = args[0];
  V v_t_24363 = heff_env(self)[0];
  V v_msg_24366 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24368 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24363, 3), heff_get_n(v_t_24363, 4, 9)});
  V v_t_24369 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24366, v_t_24368, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24369}), v_st_24367});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam35(V self, V *args) {
  V v_st_24376 = args[0];
  V v_t_24372 = heff_env(self)[0];
  V v_msg_24375 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24377 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24372, 3), heff_get_n(v_t_24372, 4, 9)});
  V v_t_24378 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24375, v_t_24377, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24378}), v_st_24376});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam36(V self, V *args) {
  V v_st_24387 = args[0];
  V v_t_24383 = heff_env(self)[0];
  V v_msg_24386 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24388 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24383, 3), heff_get_n(v_t_24383, 4, 9)});
  V v_t_24389 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24386, v_t_24388, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24389}), v_st_24387});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam37(V self, V *args) {
  V v_st_24398 = args[0];
  V v_t_24394 = heff_env(self)[0];
  V v_msg_24397 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24399 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24394, 3), heff_get_n(v_t_24394, 4, 9)});
  V v_t_24400 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24397, v_t_24399, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24400}), v_st_24398});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam38(V self, V *args) {
  V v_st_24409 = args[0];
  V v_t_24405 = heff_env(self)[0];
  V v_msg_24408 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24405, 3), heff_get_n(v_t_24405, 4, 9)});
  V v_t_24411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24408, v_t_24410, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24411}), v_st_24409});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam39(V self, V *args) {
  V v_st_24420 = args[0];
  V v_t_24416 = heff_env(self)[0];
  V v_msg_24419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24416, 3), heff_get_n(v_t_24416, 4, 9)});
  V v_t_24422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24419, v_t_24421, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24422}), v_st_24420});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam40(V self, V *args) {
  V v_st_24431 = args[0];
  V v_t_24427 = heff_env(self)[0];
  V v_msg_24430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24432 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24427, 3), heff_get_n(v_t_24427, 4, 9)});
  V v_t_24433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24430, v_t_24432, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24433}), v_st_24431});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam41(V self, V *args) {
  V v_st_24444 = args[0];
  V v_t_24440 = heff_env(self)[0];
  V v_msg_24443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24445 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24440, 3), heff_get_n(v_t_24440, 4, 9)});
  V v_t_24446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24443, v_t_24445, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24446}), v_st_24444});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str0, 28, "a segment says its size once");
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str1, 28, "a segment says its size once");
Clo g_heff_2esyntax_2esurface_2esizeSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esizeSaid_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esizeSaid(V v_sp_240, V v_n_241, V v_x3_242, V v_s_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SizeDefault: {
    heff_drop(v_sp_240);
    V v_t_245 = ({ V rv_1 = v_n_241; V rr_ = heff_rec_reuse_nf(v_s_243, 29ULL, 5, shape_ty__size__unit__little__signed, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_245}), v_p_244});
  }
  case TAG_SizeNumber: {
    V v_ru_24x3_242_24SizeNumber = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str0), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24SizeNumber, TAG_Left, 1, (V[]){v_t_247}), v_p_244});
  }
  case TAG_SizeName: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esizeSaid(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2esurface_2evarAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evarAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2evarAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  V v_t_244 = (g_list_2eany(v_t_243, heff_rfield(v_st_242, 1)));
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_242, 8), heff_rfield(v_t_240, 1)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_x_2418;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_k_249 = v_field_247;
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        heff_drop(v_k_249);
        V v_e_2410 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
        V v_t_2411 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2410, v_t_2411));
      } else {
        heff_drop(v_t_244);
        V v_t_2412 = heff_intAdd(heff_dup(heff_rfield(v_t_240, 3)), heff_strLength_lent(v_k_249, 0));
        V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_240, 3)), heff_intAdd(v_t_2412, MK_INT(2LL))});
        V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_249}), v_t_2413});
        V v_t_2415 = (g_list_2emap_24s513201124x806973253(heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_fs_241})));
        v_x_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2415));
      }
    } else {
      heff_drop(v_t_244);
      heff_drop(v_field_247);
      V v_e_2416 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
      V v_t_2417 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2418 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2416, v_t_2417));
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2418}), v_st_242});
  }
}
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evarAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str1, 6, "mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str3, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str4, 4, "type");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str5, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str6, 4, "data");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str8, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str9, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str10, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str11, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str12, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str13, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str14, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str15, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str16, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str17, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str18, 1, ":");
Clo g_heff_2esyntax_2esurface_2eprescanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprescanGo_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprescanGo(V v_ts_240, V v_box_24k_241, V v_inMutual_242, V v_acc_243) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if ((((int64_t)0ULL) <= v_k_241)) {
    if ((v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
      V v_t_246 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_k_241), 2);
      int64_t v_i_247 = (v_k_241 + ((int64_t)1ULL));
      if ((((int64_t)0ULL) <= v_i_247)) {
        if ((v_i_247 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
          V v_u_2410 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_247), 2);
          V v_t_2411 = heff_dup(heff_rfield(v_t_246, 6));
          V v_t_2414 = heff_bool(((heff_dup(v_t_2411) == NTAG(TAG_True)) && (heff_intEq_c(heff_dup(heff_rfield(v_t_246, 5)), MK_INT(0LL)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_t_246, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str1))))));
          heff_drop(v_t_2411);
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_inMutual_242);
            heff_drop_rec(v_t_246, 7);
            heff_drop_rec(v_u_2410, 7);
            heff_drop(v_t_2414);
            V t_0 = v_ts_240;
            int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
            V t_2 = NTAG(TAG_True);
            V t_3 = v_acc_243;
            v_ts_240 = t_0;
            v_k_241 = t_1;
            v_inMutual_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_t_2414);
            V v_t_2415 = heff_dup(heff_rfield(v_t_246, 6));
            V v_t_2421;
            if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
              heff_drop(v_t_2415);
              if (heff_intEq_c(heff_dup(heff_rfield(v_t_246, 5)), MK_INT(0LL))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str2))) {
                  V v_t_2418 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_246, 1))}));
                  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str3), NTAG(TAG_Nil)});
                  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str5), v_t_2419})});
                  v_t_2421 = ({ V a_0 = v_t_2418; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str6), v_t_2420}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
                } else {
                  v_t_2421 = NTAG(TAG_False);
                }
              } else {
                v_t_2421 = NTAG(TAG_False);
              }
            } else {
              heff_drop(v_t_2415);
              v_t_2421 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
              heff_drop(v_inMutual_242);
              heff_drop_rec(v_t_246, 7);
              heff_drop(v_t_2421);
              V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_u_2410, 1, 7), v_acc_243});
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
              V t_2 = NTAG(TAG_False);
              V t_3 = v_t_2422;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_inMutual_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            } else {
              heff_drop(v_t_2421);
              V v_t_2423 = heff_dup(heff_rfield(v_t_246, 6));
              V v_t_2433 = heff_bool(((heff_dup(v_t_2423) == NTAG(TAG_True)) && (heff_intEq_c(heff_dup(heff_rfield(v_t_246, 5)), MK_INT(0LL)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str7)) ? (heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str8)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str9))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str10)) && (heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str11)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str12))))) : ((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str13)) ? (heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str14)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str15))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str16)) && (heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 0)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str17)) && heff_strEq_c(heff_dup(heff_rfield(v_u_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str18)))))))));
              heff_drop_rec(v_u_2410, 7);
              heff_drop(v_t_2423);
              if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                heff_drop(v_t_2433);
                V v_t_2434 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_t_246, 5)))));
                heff_drop(v_inMutual_242);
                V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 1, 7), v_acc_243});
                V t_0 = v_ts_240;
                int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
                V t_2 = v_t_2434;
                V t_3 = v_t_2435;
                v_ts_240 = t_0;
                v_k_241 = t_1;
                v_inMutual_242 = t_2;
                v_acc_243 = t_3;
                goto top;
              } else {
                heff_drop(v_t_2433);
                V v_t_2438 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && ({ V v_t_2436 = heff_dup(heff_rfield(v_t_246, 6)); int c_ = ((heff_dup(v_t_2436) == NTAG(TAG_True)) ? !heff_intEq_c(heff_dup(heff_rfield(v_t_246, 5)), MK_INT(0LL)) : 1); heff_drop(v_t_2436); c_; })));
                heff_drop(v_inMutual_242);
                heff_drop_rec(v_t_246, 7);
                V t_0 = v_ts_240;
                int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
                V t_2 = v_t_2438;
                V t_3 = v_acc_243;
                v_ts_240 = t_0;
                v_k_241 = t_1;
                v_inMutual_242 = t_2;
                v_acc_243 = t_3;
                goto top;
              }
            }
          }
        } else {
          heff_drop_rec(v_t_246, 7);
          V t_0 = v_ts_240;
          int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
          V t_2 = v_inMutual_242;
          V t_3 = v_acc_243;
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_inMutual_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      } else {
        heff_drop_rec(v_t_246, 7);
        V t_0 = v_ts_240;
        int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
        V t_2 = v_inMutual_242;
        V t_3 = v_acc_243;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_inMutual_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_inMutual_242);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    }
  } else {
    heff_drop(v_inMutual_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
}
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eprescanGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2edropN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edropN_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edropN(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_rest_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edropN(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclDone_str0, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclDone_str1, 6, "infixr");
Clo g_heff_2esyntax_2esurface_2efixDeclDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDeclDone_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efixDeclDone(V v_t_240, V v_rest_241, V v_ops_242, V v_r_243) {
top: ;
  V v_s_244 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_247;
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2esyntax_2esurface_2efixDeclDone_str0), 2)) {
    heff_drop(v_s_244);
    v_t_247 = NTAG(TAG_AssocLeft);
  } else {
    if (heff_strEq_c(v_s_244, ((V)&g_heff_2esyntax_2esurface_2efixDeclDone_str1))) {
      v_t_247 = NTAG(TAG_AssocRight);
    } else {
      v_t_247 = NTAG(TAG_AssocNone);
    }
  }
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_r_243, 3)));
  V v_b_249 = (g_heff_2esyntax_2esurface_2elastEnd(heff_dup(v_t_240), v_rest_241));
  V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 2), v_b_249});
  return heff_rec_n(8, shape_assoc__ops__above__below__loosest__errors__span__line, (V[]){v_t_247, v_ops_242, heff_dup(heff_rfield(v_r_243, 0)), heff_dup(heff_rfield(v_r_243, 1)), heff_get_n(v_r_243, 2, 4), v_t_248, v_t_2410, heff_get_n(v_t_240, 4, 7)});
}
V g_heff_2esyntax_2esurface_2efixDeclDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efixDeclDone(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str0, 15, "the fixity of `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str1, 19, "` is declared twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str2, 22, "` ends up above itself");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str3, 26, "these fixities go round: `");
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecycleDiag_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecycleDiag(V v_all_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 1));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_all_240, 2);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Cons = heff_take_reuse_n(v_t_242, 1ULL, 2);
    V v_t_249 = (g_list_2emap_24f1352858702x862623587(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str0), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str1), heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam0, 1, 2, (V[]){heff_dup(v_g_243), heff_dup(v_all_240)}), heff_take_field(v_d_241, 1)));
    V v_t_2410 = heff_tag_at_n(v_ru_24t_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_g_243, 1)), NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2esyntax_2efixity_2etighterGo(v_all_240, heff_dup(heff_rfield(v_g_243, 1)), v_t_2410, NTAG(TAG_Nil)));
    V v_t_2414;
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_strAppend(heff_get_n(v_g_243, 1, 7), ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str2));
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str3), v_t_2412), heff_get_n(v_d_241, 6, 8), NTAG(TAG_Nothing)});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    } else {
      heff_drop_rec(v_d_241, 8);
      heff_drop_rec(v_g_243, 7);
      heff_drop(v_t_2411);
      v_t_2414 = NTAG(TAG_Nil);
    }
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_249, v_t_2414);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecycleDiag(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args) {
  V v_h_246 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_u_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_h_246, 0)), heff_get_n(v_g_243, 1, 7))) {
    heff_drop_rec(v_h_246, 5);
    heff_drop_rec(v_u_245, 7);
    return NTAG(TAG_False);
  } else {
    V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_245, 1, 7)}));
    return ({ V a_0 = v_t_248; V b_1 = heff_get_n(v_h_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_all_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam1, 1, 2, (V[]){v_g_243, v_u_245}); V b_1 = heff_get_n(v_all_240, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eanyS(a_0, b_1)); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr_str0, 24, "a field is `name : Type`");

HeffT2 g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(V v_e_240, V v_st_241) {
top: ;
  V v_x1_242 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_241));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_st_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x11_243, 0);
      V v_ru_24x11_243_24Left = heff_take_reuse_n(v_x11_243, 1ULL, 1);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_243_24Left, TAG_Left, 1, (V[]){v_e_245}), v_st_244}});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x11_243, 0);
      V v_ru_24x11_243_24Right = heff_take_reuse_n(v_x11_243, 1ULL, 1);
      V v_t_247 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_246));
      HeffT2 v_t_248 = (g_heff_2esyntax_2esurface_2easBinderOn_24cpr(v_t_247, v_st_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x11_2411 = v_field_249;
        V v_st_2412 = v_field_2410;
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_Left: {
          V v_e_2413 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_243_24Right, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412}});
        }
        case TAG_Right: {
          V v_x_2414 = heff_field(v_x11_2411, 0);
          V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
          V v_t_2415 = (g_heff_2esyntax_2esurface_2eisAnnE(v_x_2414));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x11_2411_24Right, 1);
            heff_drop(v_t_2415);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_243_24Right, TAG_Right, 1, (V[]){v_x_2414}), v_st_2412}});
          } else {
            heff_drop_cell(v_ru_24x11_243_24Right, 1);
            heff_drop(v_t_2415);
            V v_t_2418;
            switch (heff_tag_of(v_x_2414)) {
            case TAG_At: {
              V v_s_2417 = heff_field(v_x_2414, 1);
              heff_take_n(v_x_2414, 2ULL, 2);
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_x_2414);
            }
            V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr_str0), v_t_2418, NTAG(TAG_Nothing)});
            V v_f_2420 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Left, 1, (V[]){v_t_2419});
            return ((HeffT2){{v_f_2420, v_st_2412}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2411)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245, V v_z_246) {
top: ;
  V v_m_247 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    heff_take_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_universe_244);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410}});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2412)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2413, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0, 1, 6, (V[]){v_universe_244, heff_dup(v_alts_245), v_name_242, v_d_240, v_kw_241, v_x_2412}), v_st_2410));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_249)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_universe_244 = heff_env(self)[0];
  V v_alts_245 = heff_env(self)[1];
  V v_name_242 = heff_env(self)[2];
  V v_d_240 = heff_env(self)[3];
  V v_kw_241 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_universe_244)) {
  case TAG_Nothing: {
    V v_t_2419;
    switch (heff_tag_of(v_alts_245)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x11_2415 = heff_field(v_alts_245, 0);
      heff_take_n(v_alts_245, 1ULL, 1);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_MkDAlts: {
        V v_alts_2417 = heff_field(v_x11_2415, 1);
        heff_take_n(v_x11_2415, 2ULL, 3);
        v_t_2419 = v_alts_2417;
        break;
      }
      default: heff_nomatch(v_x11_2415);
      }
      break;
    }
    default: heff_nomatch(v_alts_245);
    }
    V v_m_2420 = (g_prelude_2etraverse_24s1726903169x1952011622(v_t_2419));
    V v_x1_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_st_2414}));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_MkPair: {
      V v_x11_2422 = heff_field(v_x1_2421, 0);
      V v_st_2423 = heff_field(v_x1_2421, 1);
      V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
      switch (heff_tag_of(v_x11_2422)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x11_2422, 0);
        heff_take_n(v_x11_2422, 1ULL, 1);
        heff_drop_rec(v_name_242, 9);
        heff_drop(v_d_240);
        heff_drop_rec(v_kw_241, 9);
        heff_drop(v_x_2412);
        return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
      }
      case TAG_Right: {
        V v_x_2425 = heff_field(v_x11_2422, 0);
        V v_ru_24x11_2422_24Right = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
        V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_name_242, 3)), heff_dup(heff_rfield(v_name_242, 4))});
        V v_t_2427 = heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
        V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
        V v_t_2429 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
        V v_e_2430 = heff_get_n(v_t_2429, 4, 9);
        V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2430});
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESum, 1, (V[]){v_x_2425}), v_t_2431});
        V v_t_2433 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2426, v_x_2412, heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2428}), v_t_2432});
        V v_t_2434 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
        V v_e_2435 = heff_get_n(v_t_2434, 4, 9);
        V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2435});
        V v_t_2437 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, v_t_2436})});
        V v_x_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2423});
      }
      default: return heff_nomatch(v_x11_2422);
      }
    }
    default: return heff_nomatch(v_x1_2421);
    }
  }
  case TAG_Just: {
    V v_it1_2439 = heff_field(v_universe_244, 0);
    V v_ru_24universe_244_24Just = heff_take_reuse_n(v_universe_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_2439)) {
    case TAG_MkPair: {
      V v_u_2441 = heff_field(v_it1_2439, 1);
      V v_ru_24it1_2439_24MkPair = heff_take_reuse_n(v_it1_2439, 2ULL, 2);
      V v_x1_2442 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_u_2441, v_st_2414));
      switch (heff_tag_of(v_x1_2442)) {
      case TAG_MkPair: {
        V v_x11_2443 = heff_field(v_x1_2442, 0);
        V v_st_2444 = heff_field(v_x1_2442, 1);
        V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
        switch (heff_tag_of(v_x11_2443)) {
        case TAG_Left: {
          V v_e_2445 = heff_field(v_x11_2443, 0);
          heff_take_n(v_x11_2443, 1ULL, 1);
          heff_drop(v_alts_245);
          heff_drop_rec(v_name_242, 9);
          heff_drop(v_d_240);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x1_2442_24MkPair, 2);
          return heff_tag_at_n(v_ru_24it1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24universe_244_24Just, TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
        }
        case TAG_Right: {
          V v_x_2446 = heff_field(v_x11_2443, 0);
          V v_ru_24x11_2443_24Right = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
          V v_t_2451;
          switch (heff_tag_of(v_alts_245)) {
          case TAG_Nothing: {
            v_t_2451 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_x11_2447 = heff_field(v_alts_245, 0);
            heff_take_n(v_alts_245, 1ULL, 1);
            switch (heff_tag_of(v_x11_2447)) {
            case TAG_MkDAlts: {
              V v_alts_2449 = heff_field(v_x11_2447, 1);
              heff_take_n(v_x11_2447, 2ULL, 3);
              v_t_2451 = v_alts_2449;
              break;
            }
            default: heff_nomatch(v_x11_2447);
            }
            break;
          }
          default: heff_nomatch(v_alts_245);
          }
          V v_m_2452 = (g_prelude_2etraverse_24s1726903169x1952011622(v_t_2451));
          V v_x1_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_st_2444}));
          switch (heff_tag_of(v_x1_2453)) {
          case TAG_MkPair: {
            V v_x11_2454 = heff_field(v_x1_2453, 0);
            V v_st_2455 = heff_field(v_x1_2453, 1);
            V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
            switch (heff_tag_of(v_x11_2454)) {
            case TAG_Left: {
              V v_e_2456 = heff_field(v_x11_2454, 0);
              heff_take_n(v_x11_2454, 1ULL, 1);
              heff_drop_rec(v_name_242, 9);
              heff_drop(v_d_240);
              heff_drop_rec(v_kw_241, 9);
              heff_drop(v_x_2412);
              heff_drop_cell(v_ru_24x1_2442_24MkPair, 2);
              heff_drop(v_x_2446);
              heff_drop_cell(v_ru_24x11_2443_24Right, 1);
              heff_drop_cell(v_ru_24x1_2453_24MkPair, 2);
              return heff_tag_at_n(v_ru_24it1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24universe_244_24Just, TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
            }
            case TAG_Right: {
              V v_x_2457 = heff_field(v_x11_2454, 0);
              heff_take_n(v_x11_2454, 1ULL, 1);
              V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
              V v_t_2459 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
              V v_e_2460 = heff_get_n(v_t_2459, 4, 9);
              V v_t_2461 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2460});
              V v_t_2462 = heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24universe_244_24Just, TAG_ESum, 1, (V[]){v_x_2457}), v_t_2461});
              V v_t_2463 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2458, v_x_2412, v_x_2446, v_t_2462});
              V v_t_2464 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
              V v_e_2465 = heff_get_n(v_t_2464, 4, 9);
              V v_t_2466 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2465});
              V v_t_2467 = heff_tag_at_n(v_ru_24x11_2443_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2463, v_t_2466})});
              V v_x_2468 = heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
              return heff_tag_at_n(v_ru_24it1_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2468}), v_st_2455});
            }
            default: return heff_nomatch(v_x11_2454);
            }
          }
          default: return heff_nomatch(v_x1_2453);
          }
        }
        default: return heff_nomatch(v_x11_2443);
        }
      }
      default: return heff_nomatch(v_x1_2442);
      }
    }
    default: return heff_nomatch(v_it1_2439);
    }
  }
  default: return heff_nomatch(v_universe_244);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_24cpr(V v_xs_240, V v_st_241) {
top: ;
  HeffT2 v_t_242 = (g_prelude_2etraverse_24s1597998392x1477757120_24cpr(v_xs_240, heff_dup(v_st_241)));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x11_245 = v_field_243;
    V v_st_246 = v_field_244;
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop_rec(v_st_241, 9);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Left, TAG_Left, 1, (V[]){v_e_247}), v_st_246}});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_f_249 = ({ V rv_1 = heff_get_n(v_st_241, 1, 9); V rr_ = heff_rec_reuse_nf(v_st_246, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){v_x_248}), v_f_249}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
}