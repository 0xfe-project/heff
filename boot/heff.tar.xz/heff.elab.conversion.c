// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IntoCons 46138
#define TAG_LNil 57394
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
Clo g_heff_2eelab_2econversion_2eeqHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2econversion_2eeqHead_entry, 2, 0};

V g_heff_2eelab_2econversion_2eeqHead(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_HLocal: {
    V v_i_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      V v_j_243 = heff_field(v_x2_241, 0);
      return heff_intEq(heff_dup(v_i_242), heff_dup(v_j_243));
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HGlobal: {
    V v_x_246 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_y_248 = heff_field(v_x2_241, 0);
      return heff_strEq_lent(v_x_246, v_y_248, 0);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HMeta: {
    V v_m_2410 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      V v_m_27_2413 = heff_field(v_x2_241, 0);
      return heff_intEq(heff_dup(v_m_2410), heff_dup(v_m_27_2413));
    }
    case TAG_HError: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_HError: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2econversion_2eeqHead(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2econversion_2ecanon_str0, 1, "x");
V g_heff_2eelab_2econversion_2ecanon_lam1(V self, V *args);
V g_heff_2eelab_2econversion_2ecanon_lam0(V self, V *args);
V g_heff_2eelab_2econversion_2ecanon_lam2(V self, V *args);
Clo g_heff_2eelab_2econversion_2ecanon_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2econversion_2ecanon_entry, 1, 0};

V g_heff_2eelab_2econversion_2ecanon(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_ty_243 = heff_dup(heff_field(v_v_240, 2));
    V v_expansion_244 = heff_dup(heff_field(v_v_240, 3));
    V v_t_246 = heff_tr(heff_call(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(v_t_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      heff_drop(v_expansion_244);
      V v_t_2415 = heff_tag_n(TAG_MkClo, 3, (V[]){((V)&g_heff_2eelab_2econversion_2ecanon_str0), NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2econversion_2ecanon_lam0, 1, 1, (V[]){v_v_240})});
      return heff_tag_n(TAG_VLam, 2, (V[]){v_ty_243, v_t_2415});
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_tag(v_v_240, 5);
      heff_drop(v_ty_243);
      V v_t_2419 = heff_tr(heff_call(v_expansion_244, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_IntoCons: {
        V v_fields_2420 = heff_field(v_t_2419, 0);
        V v_ru_24t_2419_24IntoCons = heff_take_reuse_n(v_t_2419, 1ULL, 1);
        V v_xs_2421 = heff_take_field(v_fields_2420, 2);
        V v_t_2424 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2421, 0), heff_clo_n(g_heff_2eelab_2econversion_2ecanon_lam2, 1, 1, (V[]){v_xs_2421}));
        V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_fields_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return heff_tag_at_n(v_ru_24t_2419_24IntoCons, TAG_VCons, 1, (V[]){v_t_2425});
      }
      case TAG_NotApplicable: {
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeInt: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeFloat: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeString: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeRune: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    case TAG_NoRules: {
      heff_drop(v_ty_243);
      heff_drop(v_expansion_244);
      return v_v_240;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VCode: {
    return v_v_240;
  }
  case TAG_VLam: {
    return v_v_240;
  }
  case TAG_VCons: {
    return v_v_240;
  }
  case TAG_VOpaque: {
    return v_v_240;
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2econversion_2ecanon(a[0]);
}
V g_heff_2eelab_2econversion_2ecanon_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_w_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return ({ V a_0 = v_w_2413; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_w_2413); r_; });
}
V g_heff_2eelab_2econversion_2ecanon_lam0(V self, V *args) {
  V v_w_2413 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_v_240, heff_clo_n(g_heff_2eelab_2econversion_2ecanon_lam1, 1, 1, (V[]){v_w_2413})));
}
V g_heff_2eelab_2econversion_2ecanon_lam2(V self, V *args) {
  V v_i_2422 = args[0];
  V v_xs_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_arrayIndex(v_xs_2421, v_i_2422);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2423});
}