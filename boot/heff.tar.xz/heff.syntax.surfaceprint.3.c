// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_typed 312202372
#define LBL_values 1123329101
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_n__inner[] = {LBL_n, LBL_inner};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685_clo;
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elazyArg_24cpr(V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eopHead(V);
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f317004629x745102808(V, V, V, V, V);
V g_list_2efoldl_24f317004629x745102808_entry(V self, V *a);
extern Clo g_list_2efoldl_24f317004629x745102808_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1245654234x191876439(V);
V g_list_2ekeepIf_24s1245654234x191876439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1245654234x191876439_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;

HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    V v_f_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_w_249 = v_field_247;
        V t_0 = v_x_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_249, v_acc_242});
        v_x_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str0, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str3, 1, "\?");
Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elocalName_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_dup(v_xs_240), heff_dup(v_i_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2emadeNameSaid(heff_dup(v_x_246)));
      V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V a_3 = v_i_241; V a_4 = v_xs_240; V r_ = (g_list_2efoldl_24f317004629x745102808(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_246); heff_drop(v_xs_240); r_; });
      V v_x2_249 = (g_list_2ereplicate(v_t_248, ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str0)));
      V v_t_2412;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_xs_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        v_t_2412 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      return heff_strAppend(v_t_247, v_t_2412);
    } else {
      heff_drop(v_xs_240);
      heff_drop(v_field_244);
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str3), heff_intShow(v_i_241));
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2elocalName(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(V v_names_240, V v_i_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_SLocal: {
    HeffT2 v_t_244 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_m_248 = v_field_246;
        switch (heff_tag_of(v_m_248)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_249 = heff_field(v_m_248, 0);
          heff_take_n(v_m_248, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_249, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_248)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_m_2415 = v_field_2413;
        switch (heff_tag_of(v_m_2415)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2416 = heff_field(v_m_2415, 0);
          heff_take_n(v_m_2415, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2416, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2415)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_m_2422 = v_field_2420;
        switch (heff_tag_of(v_m_2422)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2423 = heff_field(v_m_2422, 0);
          heff_take_n(v_m_2422, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2423, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2422)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2420);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_m_2430 = v_field_2428;
        switch (heff_tag_of(v_m_2430)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2431 = heff_field(v_m_2430, 0);
          heff_take_n(v_m_2430, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2431, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2430)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2428);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_m_2438 = v_field_2436;
        switch (heff_tag_of(v_m_2438)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2439 = heff_field(v_m_2438, 0);
          heff_take_n(v_m_2438, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2439, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2438)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2443 = v_t_2441.f[1];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        V v_m_2445 = v_field_2443;
        switch (heff_tag_of(v_m_2445)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2446 = heff_field(v_m_2445, 0);
          heff_take_n(v_m_2445, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2446, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2445)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2443);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_m_2453 = v_field_2451;
        switch (heff_tag_of(v_m_2453)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2454 = heff_field(v_m_2453, 0);
          heff_take_n(v_m_2453, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2454, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2453)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2451);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_2457 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2459 = v_t_2457.f[1];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_m_2461 = v_field_2459;
        switch (heff_tag_of(v_m_2461)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2462 = heff_field(v_m_2461, 0);
          heff_take_n(v_m_2461, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2462, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2461)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2459);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_2465 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2467 = v_t_2465.f[1];
      int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
      if ((v_tag_2466 == ((int64_t)0ULL))) {
        V v_m_2469 = v_field_2467;
        switch (heff_tag_of(v_m_2469)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2470 = heff_field(v_m_2469, 0);
          heff_take_n(v_m_2469, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2470, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2469)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2467);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_2474 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2476 = v_t_2474.f[1];
      int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
      if ((v_tag_2475 == ((int64_t)0ULL))) {
        V v_m_2478 = v_field_2476;
        switch (heff_tag_of(v_m_2478)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2479 = heff_field(v_m_2478, 0);
          heff_take_n(v_m_2478, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2479, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2478)}});
        }
      } else {
        heff_drop_tag(v_a_242, 3);
        heff_drop(v_field_2476);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_2481 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_m_2485 = v_field_2483;
        switch (heff_tag_of(v_m_2485)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2486 = heff_field(v_m_2485, 0);
          heff_take_n(v_m_2485, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2486, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2485)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2483);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_2487 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        V v_m_2491 = v_field_2489;
        switch (heff_tag_of(v_m_2491)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2492 = heff_field(v_m_2491, 0);
          heff_take_n(v_m_2491, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2492, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2491)}});
        }
      } else {
        heff_drop(v_field_2489);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SAbandon: {
    HeffT2 v_t_2493 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2495 = v_t_2493.f[1];
      int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
      if ((v_tag_2494 == ((int64_t)0ULL))) {
        V v_m_2497 = v_field_2495;
        switch (heff_tag_of(v_m_2497)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2498 = heff_field(v_m_2497, 0);
          heff_take_n(v_m_2497, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2498, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2497)}});
        }
      } else {
        heff_drop(v_field_2495);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SRec: {
    HeffT2 v_t_24100 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24102 = v_t_24100.f[1];
      int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
      if ((v_tag_24101 == ((int64_t)0ULL))) {
        V v_m_24104 = v_field_24102;
        switch (heff_tag_of(v_m_24104)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24105 = heff_field(v_m_24104, 0);
          heff_take_n(v_m_24104, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24105, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24104)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24102);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24108 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24110 = v_t_24108.f[1];
      int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
      if ((v_tag_24109 == ((int64_t)0ULL))) {
        V v_m_24112 = v_field_24110;
        switch (heff_tag_of(v_m_24112)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24113 = heff_field(v_m_24112, 0);
          heff_take_n(v_m_24112, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24113, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24112)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_24110);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SImplicit: {
    V v_a1_24114 = heff_field(v_a_242, 0);
    V v_a2_24115 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    heff_drop(v_names_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_a1_24114, v_a2_24115})}});
  }
  case TAG_SPrim: {
    HeffT2 v_t_24117 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24119 = v_t_24117.f[1];
      int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
      if ((v_tag_24118 == ((int64_t)0ULL))) {
        V v_m_24121 = v_field_24119;
        switch (heff_tag_of(v_m_24121)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24122 = heff_field(v_m_24121, 0);
          heff_take_n(v_m_24121, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24122, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24121)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24119);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24126 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24128 = v_t_24126.f[1];
      int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
      if ((v_tag_24127 == ((int64_t)0ULL))) {
        V v_m_24130 = v_field_24128;
        switch (heff_tag_of(v_m_24130)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24131 = heff_field(v_m_24130, 0);
          heff_take_n(v_m_24130, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24131, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24130)}});
        }
      } else {
        heff_drop_tag(v_a_242, 3);
        heff_drop(v_field_24128);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24133 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        V v_m_24137 = v_field_24135;
        switch (heff_tag_of(v_m_24137)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24138 = heff_field(v_m_24137, 0);
          heff_take_n(v_m_24137, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24138, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24137)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24135);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24140 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24142 = v_t_24140.f[1];
      int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
      if ((v_tag_24141 == ((int64_t)0ULL))) {
        V v_m_24144 = v_field_24142;
        switch (heff_tag_of(v_m_24144)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24145 = heff_field(v_m_24144, 0);
          heff_take_n(v_m_24144, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24145, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24144)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24142);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24147 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24149 = v_t_24147.f[1];
      int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
      if ((v_tag_24148 == ((int64_t)0ULL))) {
        V v_m_24151 = v_field_24149;
        switch (heff_tag_of(v_m_24151)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24152 = heff_field(v_m_24151, 0);
          heff_take_n(v_m_24151, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24152, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24151)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24149);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24154 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24156 = v_t_24154.f[1];
      int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
      if ((v_tag_24155 == ((int64_t)0ULL))) {
        V v_m_24158 = v_field_24156;
        switch (heff_tag_of(v_m_24158)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24159 = heff_field(v_m_24158, 0);
          heff_take_n(v_m_24158, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24159, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24158)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24156);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24161 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24163 = v_t_24161.f[1];
      int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
      if ((v_tag_24162 == ((int64_t)0ULL))) {
        V v_m_24165 = v_field_24163;
        switch (heff_tag_of(v_m_24165)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24166 = heff_field(v_m_24165, 0);
          heff_take_n(v_m_24165, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24166, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24165)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24163);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24169 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24171 = v_t_24169.f[1];
      int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
      if ((v_tag_24170 == ((int64_t)0ULL))) {
        V v_m_24173 = v_field_24171;
        switch (heff_tag_of(v_m_24173)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24174 = heff_field(v_m_24173, 0);
          heff_take_n(v_m_24173, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24174, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24173)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_24171);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24176 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24178 = v_t_24176.f[1];
      int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
      if ((v_tag_24177 == ((int64_t)0ULL))) {
        V v_m_24180 = v_field_24178;
        switch (heff_tag_of(v_m_24180)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24181 = heff_field(v_m_24180, 0);
          heff_take_n(v_m_24180, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24181, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24180)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24178);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_a_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str17, 1, "_");
Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elambdas_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_e2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_SU: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_e2_2413, 0);
        V v_b_2416 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_e2_2413, 0);
        V v_b_2420 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFunction: {
      V v_e14_2425 = heff_field(v_e1_2412, 3);
      heff_take_n(v_e1_2412, 8ULL, 5);
      switch (heff_tag_of(v_e14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_e2_2413, 0);
          V v_b_2428 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_e2_2413, 0);
          V v_b_2431 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str4)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_e2_2413, 0);
          V v_b_2435 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str7)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      default: return heff_nomatch(v_e14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_e1_2412, 0ULL, 3);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_e2_2413, 0);
        V v_b_2442 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_e2_2413, 0);
        V v_b_2446 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_e2_2413, 0);
        V v_b_2450 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_e2_2413, 0);
        V v_b_2453 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_e2_2413, 0);
        V v_b_2456 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_e2_2413, 0);
        V v_b_2459 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2461 = heff_field(v_e2_2413, 0);
        V v_b_2462 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2461), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2461, v_bs_241});
        V t_2 = v_b_2462;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2463 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2465 = heff_field(v_e2_2413, 0);
        V v_b_2466 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2465), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2465, v_bs_241});
        V t_2 = v_b_2466;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2467 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2469 = heff_field(v_e2_2413, 0);
        V v_b_2470 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2469), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2469, v_bs_241});
        V t_2 = v_b_2470;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2471 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str17), v_bs_241});
        V t_2 = v_b_2471;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_STag: {
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2482, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2488, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2490, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2498, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_24100 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24100, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24104, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24106, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24108, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitBytes: {
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  case TAG_SLitRune: {
    V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24114, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24117, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24119, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2elambdas(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str23, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eopHead_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eopHead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str0);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_242);
  }
  case TAG_SCode: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str1);
  }
  case TAG_SApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str2);
  }
  case TAG_SLam: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str3);
  }
  case TAG_SCons: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str4);
  }
  case TAG_SProj: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str5);
  }
  case TAG_STag: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str6);
  }
  case TAG_SMatch: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str7);
  }
  case TAG_SSpecialize: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str8);
  }
  case TAG_SIs: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str9);
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str10);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str11);
  }
  case TAG_SRec: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str12);
  }
  case TAG_SFix: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str13);
  }
  case TAG_SImplicit: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str14);
  }
  case TAG_SPrim: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str15);
  }
  case TAG_SMetaApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str16);
  }
  case TAG_SLitInt: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str17);
  }
  case TAG_SLitFloat: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str18);
  }
  case TAG_SLitString: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str19);
  }
  case TAG_SLitBytes: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str20);
  }
  case TAG_SLitRune: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str21);
  }
  case TAG_SLitFixed: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str22);
  }
  case TAG_SLitFloat32: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str23);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2eopHead(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str3, 3, "op_");

HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_take_field(v_sp_242, 0);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_args_246 = heff_get_n(v_sp_242, 1, 2);
    V v_t_247 = heff_get_n(heff_get_n(v_c_240, 0, 3), 1, 2);
    V v_it_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_it_248 = (g_list_2ekeepIf_24s1245654234x191876439(v_args_246));
    } else {
      heff_drop(v_t_247);
      v_it_248 = v_args_246;
    }
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_l_249 = heff_field(v_it_248, 0);
      V v_it2_2410 = heff_field(v_it_248, 1);
      V v_ru_24it_248_24Cons = heff_take_reuse_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it2_2410)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop(v_l_249);
        heff_drop_cell(v_ru_24it_248_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_r2_2411 = heff_field(v_it2_2410, 0);
        V v_it22_2412 = heff_field(v_it2_2410, 1);
        heff_take_n(v_it2_2410, 3ULL, 2);
        switch (heff_tag_of(v_it22_2412)) {
        case TAG_Nil: {
          V v_t_2494;
          if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str0), 2)) {
            heff_drop(v_x_245);
            v_t_2494 = NTAG(TAG_False);
          } else {
            HeffT2 v_t_2414 = ({ V a_0 = v_x_245; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_ws_2418 = v_field_2416;
                V v_t_2421;
                switch (heff_tag_of(v_ws_2418)) {
                case TAG_Nil: {
                  v_t_2421 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str1);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2419 = heff_field(v_ws_2418, 0);
                  V v_xs_2420 = heff_field(v_ws_2418, 1);
                  heff_take_n(v_ws_2418, 3ULL, 2);
                  v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str2); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
                  break;
                }
                default: heff_nomatch(v_ws_2418);
                }
                V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str3), v_t_2421);
                heff_drop(v_t_2422);
                V v_t_2458;
                switch (heff_tag_of(v_l_249)) {
                case TAG_SLocal: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SGlobal: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SCode: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SApp: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLam: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SCons: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SProj: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_STag: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SMatch: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SSpecialize: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SIs: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SOpaque: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SAbandon: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SRec: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SFix: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SImplicit: {
                  v_t_2458 = NTAG(TAG_True);
                  break;
                }
                case TAG_SPrim: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SMetaApp: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitInt: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFloat: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitString: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitBytes: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitRune: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFixed: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFloat32: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_l_249);
                }
                if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
                  heff_drop(v_t_2458);
                  v_t_2494 = NTAG(TAG_False);
                } else {
                  heff_drop(v_t_2458);
                  switch (heff_tag_of(v_r2_2411)) {
                  case TAG_SLocal: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SGlobal: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SCode: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SApp: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLam: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SCons: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SProj: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_STag: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SMatch: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SSpecialize: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SIs: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SOpaque: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SAbandon: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SRec: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SFix: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SImplicit: {
                    v_t_2494 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrim: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SMetaApp: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitInt: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFloat: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitString: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitBytes: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitRune: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFixed: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFloat32: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_r2_2411);
                  }
                }
              } else {
                heff_drop(v_field_2416);
                v_t_2494 = NTAG(TAG_False);
              }
            }
          }
          if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
            heff_drop(v_t_2494);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24it_248_24Cons, TAG_MkPair, 2, (V[]){v_l_249, v_r2_2411})}});
          } else {
            heff_drop(v_l_249);
            heff_drop_cell(v_ru_24it_248_24Cons, 2);
            heff_drop(v_r2_2411);
            heff_drop(v_t_2494);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2412, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop(v_l_249);
          heff_drop_cell(v_ru_24it_248_24Cons, 2);
          heff_drop(v_r2_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it22_2412)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it_248)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elazyArg_24cpr_str0, 12, "builtin.Lazy");

HeffT2 g_heff_2esyntax_2esurfaceprint_2elazyArg_24cpr(V v_sp_240) {
top: ;
  V v_t_241 = heff_take_field(v_sp_240, 0);
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_243 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_244 = heff_get_n(v_sp_240, 1, 2);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_t_244, 0);
      V v_it2_246 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        if (heff_strEq_c(v_x_243, ((V)&g_heff_2esyntax_2esurfaceprint_2elazyArg_24cpr_str0))) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_245}});
        } else {
          heff_drop(v_a_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it2_246, 0ULL, 2);
        heff_drop(v_x_243);
        heff_drop(v_a_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_244)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str1, 4, "Cons");

HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    V v_x11_2411 = heff_field(v_x1_240, 0);
    V v_ts_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str0), 2)) {
      heff_drop(v_x11_2411);
      heff_drop_cell(v_ru_24x1_240_24STag, 2);
      if ((heff_unbox_word(heff_arrayLength(v_ts_2412)) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      if (heff_strEq_c(v_x11_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str1))) {
        if ((heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)) == ((int64_t)2ULL))) {
          if ((((int64_t)0ULL) < heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)))) {
            V v_t_2418 = heff_arrayIndex_lent(v_ts_2412, MK_INT(0LL), 2);
            if ((((int64_t)1ULL) < heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)))) {
              V v_t_2420 = heff_arrayIndex(v_ts_2412, MK_INT(1LL));
              HeffT2 v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_t_2420));
              {
                V v_field_2423 = v_t_2421.f[1];
                int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                if ((v_tag_2422 == ((int64_t)0ULL))) {
                  V v_ts_2425 = v_field_2423;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24STag, TAG_Cons, 2, (V[]){v_t_2418, v_ts_2425})}});
                } else {
                  heff_drop_cell(v_ru_24x1_240_24STag, 2);
                  heff_drop(v_t_2418);
                  heff_drop(v_field_2423);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_ts_2412);
              heff_drop_cell(v_ru_24x1_240_24STag, 2);
              heff_drop(v_t_2418);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_ts_2412);
            heff_drop_cell(v_ru_24x1_240_24STag, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_ts_2412);
          heff_drop_cell(v_ru_24x1_240_24STag, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_ts_2412);
        heff_drop_cell(v_ru_24x1_240_24STag, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2especChain_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SCode: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SApp: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLam: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SCons: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SProj: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_STag: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SSpecialize: {
    V v_e_2416 = heff_field(v_x1_240, 0);
    V v_x_2417 = heff_field(v_x1_240, 1);
    V v_v_2418 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_v_2418}), v_acc_241});
    V t_0 = v_e_2416;
    V t_1 = v_t_2419;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SIs: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SOpaque: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SRec: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SFix: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop(v_a_245);
        V v_imp_2411 = v_field_249;
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop_rec(v_imp_2411, 2);
          heff_drop(v_t_2412);
          V t_0 = v_c_240;
          V t_1 = v_xs_241;
          V t_2 = v_names_242;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          V t_4 = v_rest_246;
          v_c_240 = t_0;
          v_xs_241 = t_1;
          v_names_242 = t_2;
          v_i_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2412);
          V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2411, 1)));
          V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1)));
          V v_t_2415 = heff_strAppend(heff_get_n(v_imp_2411, 0, 2), v_t_2414);
          V v_cell_2416 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2), v_t_2415), heff_hole()});
          V v_u_2417 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2416)));
          heff_drop(v_u_2417);
          return v_cell_2416;
        }
      } else {
        heff_drop(v_field_249);
        V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
        V v_cell_2419 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
        V v_u_2420 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2419)));
        heff_drop(v_u_2420);
        return v_cell_2419;
      }
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 0, 2);
  V v_t_246 = heff_tr(heff_call(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))}));
  V v_args_247 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_take_field(v_sp_243, 1)));
  V v_headAlone_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get_n(v_sp_243, 0, 2)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2)));
    } else {
      return v_s_2411;
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0, 1, "~");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str4, 1, ")");
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2elazyArg_24cpr(v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_p_241);
      heff_drop(v_t_243);
      V v_a_249 = v_field_247;
      V v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(2LL), v_xs_242, v_a_249));
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0), v_t_2410);
    } else {
      heff_drop(v_field_247);
      V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
      HeffT2 v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2epairItems_24cpr(v_t_2411));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop(v_p_241);
          heff_drop(v_t_243);
          V v_items_2416 = v_field_2414;
          V v_x2_2418 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_lam0, 1, 2, (V[]){v_c_240, v_xs_242}), v_items_2416));
          V v_t_2421;
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_Nil: {
            v_t_2421 = ((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_xs_2420 = heff_field(v_x2_2418, 1);
            heff_take_n(v_x2_2418, 3ULL, 2);
            v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2418);
          }
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str4)));
        } else {
          heff_drop(v_field_2414);
          HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappOp_24s43889592x654481685(v_c_240, v_p_241, v_xs_242, v_t_243);
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), v_xs_242, v_a_2417));
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_take_field(v_l_243, 0), heff_get_n(v_l_243, 2, 3)));
  V v_t_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2), v_t_248));
  V v_s_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3), v_t_249);
  if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4), heff_strAppend(v_s_2410, ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5)));
  } else {
    return v_s_2410;
  }
}
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str3, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str5, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str7, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str9, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str10, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str11, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str13, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str16, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str18, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str20, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str22, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str27, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str28, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str30, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str32, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str34, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str36, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str38, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str40, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str42, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str44, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str46, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str48, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str50, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str52, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str54, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str56, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str58, 5, "type ");
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V v_c_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str0), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_247 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_247, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str1), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str2)));
      V v_f_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str3), heff_strAppend(v_t_246, v_t_249));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
    }
  }
  case TAG_SDecode: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2412 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2412);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2412);
      V v_t_2413 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str4), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2414 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2414, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str5), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str6)));
      V v_f_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str7), heff_strAppend(v_t_2413, v_t_2416));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2423 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2423);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2423);
      V v_t_2424 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str8), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2425 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2425, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str9), heff_strAppend(v_t_2426, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str10)));
      V v_f_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str11), heff_strAppend(v_t_2424, v_t_2427));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
    }
  }
  case TAG_SRecord: {
    V v_fs_2430 = heff_field(v_t_243, 1);
    V v_ds_2431 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2432 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      V v_t_2433 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str12), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2434 = heff_arrayToList(heff_take_field(v_fs_2430, 0));
      V v_t_2435 = heff_arrayToList(heff_get_n(v_fs_2430, 2, 3));
      V v_fs_2436 = (g_heff_2eutil_2edict_2ezipKV(v_t_2434, v_t_2435));
      V v_t_2437 = heff_rec_n(2, shape_names__out, (V[]){heff_get_n(v_tf_242, 1, 4), NTAG(TAG_Nil)});
      V v_acc_2440 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0, 2, 2, (V[]){v_c_240, v_ds_2431}); V a_1 = v_t_2437; V a_2 = v_fs_2436; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2436); r_; });
      V v_x2_2441 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str13), heff_get_n(v_acc_2440, 1, 2)));
      V v_t_2444;
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_xs_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str15); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2441);
      }
      V v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str16), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str17)));
      V v_f_2446 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str18), heff_strAppend(v_t_2433, v_t_2445));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
    } else {
      heff_drop_rec(v_fs_2430, 3);
      heff_drop(v_ds_2431);
      heff_drop(v_t_2432);
      V v_t_2447 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str19), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2448 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2448, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str20), heff_strAppend(v_t_2449, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str21)));
      V v_f_2451 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str22), heff_strAppend(v_t_2447, v_t_2450));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2451}});
    }
  }
  case TAG_SSum: {
    V v_vs_2452 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2453 = heff_dup(heff_rfield(v_tf_242, 3));
    if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_rec(v_vs_2452, 3);
      heff_drop(v_t_2453);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2453);
      V v_t_2454 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str23), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2455 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2452, 0)));
      V v_t_2456 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2452, 2)));
      V v_x1_2457 = (g_heff_2eutil_2edict_2ezipKV(v_t_2455, v_t_2456));
      V v_t_2472;
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_Nil: {
        heff_drop_rec(v_c_240, 3);
        heff_drop_rec(v_tf_242, 4);
        heff_drop_rec(v_vs_2452, 3);
        v_t_2472 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str24);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2457, 0ULL, 2);
        V v_t_2460 = heff_arrayToList(heff_take_field(v_vs_2452, 0));
        V v_t_2461 = heff_arrayToList(heff_get_n(v_vs_2452, 2, 3));
        V v_t_2462 = (g_heff_2eutil_2edict_2ezipKV(v_t_2460, v_t_2461));
        V v_x2_2468 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1, 1, 2, (V[]){v_c_240, v_tf_242}), v_t_2462));
        V v_t_2471;
        switch (heff_tag_of(v_x2_2468)) {
        case TAG_Nil: {
          v_t_2471 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str26);
          break;
        }
        case TAG_Cons: {
          V v_x_2469 = heff_field(v_x2_2468, 0);
          V v_xs_2470 = heff_field(v_x2_2468, 1);
          heff_take_n(v_x2_2468, 3ULL, 2);
          v_t_2471 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str27); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2468);
        }
        v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str28), v_t_2471);
        break;
      }
      default: heff_nomatch(v_x1_2457);
      }
      V v_t_2473 = heff_strAppend(v_t_2454, heff_strAppend(v_t_2472, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str29)));
      V v_f_2474 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str30), v_t_2473);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
    }
  }
  case TAG_SIsTy: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2476 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2476);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2476);
      V v_t_2477 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str31), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2478 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2479 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2478, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2480 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str32), heff_strAppend(v_t_2479, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str33)));
      V v_f_2481 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str34), heff_strAppend(v_t_2477, v_t_2480));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2481}});
    }
  }
  case TAG_SPrimInt: {
    V v_t_2482 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2482);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2482);
      V v_t_2483 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str35), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2484 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2485 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2484, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2486 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str36), heff_strAppend(v_t_2485, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str37)));
      V v_f_2487 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str38), heff_strAppend(v_t_2483, v_t_2486));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2487}});
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2488 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2488);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2488);
      V v_t_2489 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str39), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2490 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2491 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2490, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2492 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str40), heff_strAppend(v_t_2491, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str41)));
      V v_f_2493 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str42), heff_strAppend(v_t_2489, v_t_2492));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2493}});
    }
  }
  case TAG_SPrimString: {
    V v_t_2494 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2494);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2494);
      V v_t_2495 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str43), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2496 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2497 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2496, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2498 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str44), heff_strAppend(v_t_2497, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str45)));
      V v_f_2499 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str46), heff_strAppend(v_t_2495, v_t_2498));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2499}});
    }
  }
  case TAG_SPrimRune: {
    V v_t_24100 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_24100);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_24100);
      V v_t_24101 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str47), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24102 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_24103 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24102, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str48), heff_strAppend(v_t_24103, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str49)));
      V v_f_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str50), heff_strAppend(v_t_24101, v_t_24104));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24105}});
    }
  }
  case TAG_SPrimArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24107 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24107) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_24107);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_24107);
      V v_t_24108 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str51), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24109 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_24110 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24109, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_24111 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str52), heff_strAppend(v_t_24110, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str53)));
      V v_f_24112 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str54), heff_strAppend(v_t_24108, v_t_24111));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24112}});
    }
  }
  case TAG_SFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24114 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_24114);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_24114);
      V v_t_24115 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str55), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24116 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_24117 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_24116, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_24118 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str56), heff_strAppend(v_t_24117, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str57)));
      V v_f_24119 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str58), heff_strAppend(v_t_24115, v_t_24118));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24119}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0(V self, V *args) {
  V v_acc_2438 = args[0];
  V v_f_2439 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_c_240, v_ds_2431, v_acc_2438, v_f_2439));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2(V self, V *args) {
  V v_t2_2466 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 3, shape_im__indent__typed, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_t_2467, MK_INT(2LL), heff_get_n(v_tf_242, 1, 4), v_t2_2466));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1(V self, V *args) {
  V v_v_2463 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2463)) {
  case TAG_MkPair: {
    V v_t_2464 = heff_field(v_v_2463, 0);
    V v_ts_2465 = heff_field(v_v_2463, 1);
    heff_take_n(v_v_2463, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str25); V a_1 = v_t_2464; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2, 1, 2, (V[]){v_c_240, v_tf_242}); V b_3 = heff_arrayToList(v_ts_2465); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2463);
  }
}