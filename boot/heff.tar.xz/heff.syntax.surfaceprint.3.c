// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_n__inner[] = {LBL_n, LBL_inner};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2enth_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eopHead(V);
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764_clo;
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
HeffT2 g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efilter_24s1022178817x2079624138(V);
V g_list_2efilter_24s1022178817x2079624138_entry(V self, V *a);
extern Clo g_list_2efilter_24s1022178817x2079624138_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1841208961x1043590714(V, V, V, V, V);
V g_list_2efoldl_24f1841208961x1043590714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1841208961x1043590714_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;

HeffT2 g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(V v_x_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    V v_f_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
  } else {
    HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2ewordOf_24cpr(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_w_249 = v_field_247;
        V t_0 = v_x_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_249, v_acc_242});
        v_x_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str0, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str3, 1, "\?");
Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elocalName_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_dup(v_xs_240), heff_dup(v_i_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V a_3 = v_i_241; V a_4 = v_xs_240; V r_ = (g_list_2efoldl_24f1841208961x1043590714(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_240); r_; });
      V v_x2_248 = (g_list_2ereplicate(v_t_247, ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str0)));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      return heff_strAppend(v_x_246, v_t_2411);
    } else {
      heff_drop(v_xs_240);
      heff_drop(v_field_244);
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str3), heff_intShow(v_i_241));
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2elocalName(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(V v_names_240, V v_i_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_SLocal: {
    HeffT2 v_t_244 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_m_248 = v_field_246;
        switch (heff_tag_of(v_m_248)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_249 = heff_field(v_m_248, 0);
          heff_take_n(v_m_248, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_249, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_248)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SGlobal: {
    HeffT2 v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_m_2415 = v_field_2413;
        switch (heff_tag_of(v_m_2415)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2416 = heff_field(v_m_2415, 0);
          heff_take_n(v_m_2415, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2416, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2415)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SCode: {
    HeffT2 v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_m_2422 = v_field_2420;
        switch (heff_tag_of(v_m_2422)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2423 = heff_field(v_m_2422, 0);
          heff_take_n(v_m_2422, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2423, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2422)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2420);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SApp: {
    HeffT2 v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_m_2430 = v_field_2428;
        switch (heff_tag_of(v_m_2430)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2431 = heff_field(v_m_2430, 0);
          heff_take_n(v_m_2430, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2431, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2430)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2428);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLam: {
    HeffT2 v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_m_2438 = v_field_2436;
        switch (heff_tag_of(v_m_2438)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2439 = heff_field(v_m_2438, 0);
          heff_take_n(v_m_2438, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2439, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2438)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2436);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SCons: {
    HeffT2 v_t_2441 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2443 = v_t_2441.f[1];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        V v_m_2445 = v_field_2443;
        switch (heff_tag_of(v_m_2445)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2446 = heff_field(v_m_2445, 0);
          heff_take_n(v_m_2445, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2446, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2445)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2443);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SProj: {
    HeffT2 v_t_2449 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_m_2453 = v_field_2451;
        switch (heff_tag_of(v_m_2453)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2454 = heff_field(v_m_2453, 0);
          heff_take_n(v_m_2453, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2454, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2453)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2451);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_STag: {
    HeffT2 v_t_2457 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2459 = v_t_2457.f[1];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_m_2461 = v_field_2459;
        switch (heff_tag_of(v_m_2461)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2462 = heff_field(v_m_2461, 0);
          heff_take_n(v_m_2461, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2462, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2461)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2459);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMatch: {
    HeffT2 v_t_2465 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2467 = v_t_2465.f[1];
      int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
      if ((v_tag_2466 == ((int64_t)0ULL))) {
        V v_m_2469 = v_field_2467;
        switch (heff_tag_of(v_m_2469)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2470 = heff_field(v_m_2469, 0);
          heff_take_n(v_m_2469, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2470, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2469)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_2467);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SSpecialize: {
    HeffT2 v_t_2474 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2476 = v_t_2474.f[1];
      int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
      if ((v_tag_2475 == ((int64_t)0ULL))) {
        V v_m_2478 = v_field_2476;
        switch (heff_tag_of(v_m_2478)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2479 = heff_field(v_m_2478, 0);
          heff_take_n(v_m_2478, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2479, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2478)}});
        }
      } else {
        heff_drop_tag(v_a_242, 3);
        heff_drop(v_field_2476);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SIs: {
    HeffT2 v_t_2481 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_m_2485 = v_field_2483;
        switch (heff_tag_of(v_m_2485)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2486 = heff_field(v_m_2485, 0);
          heff_take_n(v_m_2485, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2486, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2485)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_2483);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SOpaque: {
    HeffT2 v_t_2487 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        V v_m_2491 = v_field_2489;
        switch (heff_tag_of(v_m_2491)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2492 = heff_field(v_m_2491, 0);
          heff_take_n(v_m_2491, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2492, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2491)}});
        }
      } else {
        heff_drop(v_field_2489);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SAbandon: {
    HeffT2 v_t_2493 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_2495 = v_t_2493.f[1];
      int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
      if ((v_tag_2494 == ((int64_t)0ULL))) {
        V v_m_2497 = v_field_2495;
        switch (heff_tag_of(v_m_2497)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_2498 = heff_field(v_m_2497, 0);
          heff_take_n(v_m_2497, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_2498, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_2497)}});
        }
      } else {
        heff_drop(v_field_2495);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SRec: {
    HeffT2 v_t_24100 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24102 = v_t_24100.f[1];
      int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
      if ((v_tag_24101 == ((int64_t)0ULL))) {
        V v_m_24104 = v_field_24102;
        switch (heff_tag_of(v_m_24104)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24105 = heff_field(v_m_24104, 0);
          heff_take_n(v_m_24104, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24105, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24104)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24102);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SFix: {
    HeffT2 v_t_24108 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24110 = v_t_24108.f[1];
      int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
      if ((v_tag_24109 == ((int64_t)0ULL))) {
        V v_m_24112 = v_field_24110;
        switch (heff_tag_of(v_m_24112)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24113 = heff_field(v_m_24112, 0);
          heff_take_n(v_m_24112, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24113, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24112)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_24110);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SImplicit: {
    V v_a1_24114 = heff_field(v_a_242, 0);
    V v_a2_24115 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    heff_drop(v_names_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_a1_24114, v_a2_24115})}});
  }
  case TAG_SPrim: {
    HeffT2 v_t_24117 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24119 = v_t_24117.f[1];
      int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
      if ((v_tag_24118 == ((int64_t)0ULL))) {
        V v_m_24121 = v_field_24119;
        switch (heff_tag_of(v_m_24121)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24122 = heff_field(v_m_24121, 0);
          heff_take_n(v_m_24121, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24122, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24121)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24119);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMetaApp: {
    HeffT2 v_t_24126 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24128 = v_t_24126.f[1];
      int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
      if ((v_tag_24127 == ((int64_t)0ULL))) {
        V v_m_24130 = v_field_24128;
        switch (heff_tag_of(v_m_24130)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24131 = heff_field(v_m_24130, 0);
          heff_take_n(v_m_24130, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24131, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24130)}});
        }
      } else {
        heff_drop_tag(v_a_242, 3);
        heff_drop(v_field_24128);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitInt: {
    HeffT2 v_t_24133 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        V v_m_24137 = v_field_24135;
        switch (heff_tag_of(v_m_24137)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24138 = heff_field(v_m_24137, 0);
          heff_take_n(v_m_24137, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24138, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24137)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24135);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFloat: {
    HeffT2 v_t_24140 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24142 = v_t_24140.f[1];
      int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
      if ((v_tag_24141 == ((int64_t)0ULL))) {
        V v_m_24144 = v_field_24142;
        switch (heff_tag_of(v_m_24144)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24145 = heff_field(v_m_24144, 0);
          heff_take_n(v_m_24144, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24145, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24144)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24142);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitString: {
    HeffT2 v_t_24147 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24149 = v_t_24147.f[1];
      int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
      if ((v_tag_24148 == ((int64_t)0ULL))) {
        V v_m_24151 = v_field_24149;
        switch (heff_tag_of(v_m_24151)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24152 = heff_field(v_m_24151, 0);
          heff_take_n(v_m_24151, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24152, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24151)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24149);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitBytes: {
    HeffT2 v_t_24154 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24156 = v_t_24154.f[1];
      int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
      if ((v_tag_24155 == ((int64_t)0ULL))) {
        V v_m_24158 = v_field_24156;
        switch (heff_tag_of(v_m_24158)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24159 = heff_field(v_m_24158, 0);
          heff_take_n(v_m_24158, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24159, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24158)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24156);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitRune: {
    HeffT2 v_t_24161 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24163 = v_t_24161.f[1];
      int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
      if ((v_tag_24162 == ((int64_t)0ULL))) {
        V v_m_24165 = v_field_24163;
        switch (heff_tag_of(v_m_24165)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24166 = heff_field(v_m_24165, 0);
          heff_take_n(v_m_24165, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24166, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24165)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24163);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFixed: {
    HeffT2 v_t_24169 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24171 = v_t_24169.f[1];
      int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
      if ((v_tag_24170 == ((int64_t)0ULL))) {
        V v_m_24173 = v_field_24171;
        switch (heff_tag_of(v_m_24173)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24174 = heff_field(v_m_24173, 0);
          heff_take_n(v_m_24173, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24174, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24173)}});
        }
      } else {
        heff_drop_tag(v_a_242, 2);
        heff_drop(v_field_24171);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SLitFloat32: {
    HeffT2 v_t_24176 = (g_heff_2esyntax_2esurfaceprint_2enth_24cpr(heff_arrayToList(v_names_240), v_i_241));
    {
      V v_field_24178 = v_t_24176.f[1];
      int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
      if ((v_tag_24177 == ((int64_t)0ULL))) {
        V v_m_24180 = v_field_24178;
        switch (heff_tag_of(v_m_24180)) {
        case TAG_Nothing: {
          heff_drop_tag(v_a_242, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_n_24181 = heff_field(v_m_24180, 0);
          heff_take_n(v_m_24180, 1ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_n__inner, (V[]){v_n_24181, v_a_242})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_m_24180)}});
        }
      } else {
        heff_drop_tag(v_a_242, 1);
        heff_drop(v_field_24178);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_a_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str17, 1, "_");
Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elambdas_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_e2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_SU: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_e2_2413, 0);
        V v_b_2416 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_e2_2413, 0);
        V v_b_2420 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFunction: {
      V v_e14_2425 = heff_field(v_e1_2412, 3);
      heff_take_n(v_e1_2412, 8ULL, 5);
      switch (heff_tag_of(v_e14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_e2_2413, 0);
          V v_b_2428 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_e2_2413, 0);
          V v_b_2431 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str4)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_e2_2413, 0);
          V v_b_2435 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str7)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      default: return heff_nomatch(v_e14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_e1_2412, 0ULL, 3);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_e2_2413, 0);
        V v_b_2442 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_e2_2413, 0);
        V v_b_2446 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_e2_2413, 0);
        V v_b_2450 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_e2_2413, 0);
        V v_b_2453 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_e2_2413, 0);
        V v_b_2456 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_e2_2413, 0);
        V v_b_2459 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2461 = heff_field(v_e2_2413, 0);
        V v_b_2462 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2461), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2461, v_bs_241});
        V t_2 = v_b_2462;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2463 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2465 = heff_field(v_e2_2413, 0);
        V v_b_2466 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2465), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2465, v_bs_241});
        V t_2 = v_b_2466;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2467 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2469 = heff_field(v_e2_2413, 0);
        V v_b_2470 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2469), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2469, v_bs_241});
        V t_2 = v_b_2470;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2471 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str17), v_bs_241});
        V t_2 = v_b_2471;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_STag: {
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2482, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2488, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2490, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2498, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_24100 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24100, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24104, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24106, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24108, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitBytes: {
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  case TAG_SLitRune: {
    V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24114, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24117, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24119, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2elambdas(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str23, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eopHead_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eopHead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str0);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_242);
  }
  case TAG_SCode: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str1);
  }
  case TAG_SApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str2);
  }
  case TAG_SLam: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str3);
  }
  case TAG_SCons: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str4);
  }
  case TAG_SProj: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str5);
  }
  case TAG_STag: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str6);
  }
  case TAG_SMatch: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str7);
  }
  case TAG_SSpecialize: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str8);
  }
  case TAG_SIs: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str9);
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str10);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str11);
  }
  case TAG_SRec: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str12);
  }
  case TAG_SFix: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str13);
  }
  case TAG_SImplicit: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str14);
  }
  case TAG_SPrim: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str15);
  }
  case TAG_SMetaApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str16);
  }
  case TAG_SLitInt: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str17);
  }
  case TAG_SLitFloat: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str18);
  }
  case TAG_SLitString: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str19);
  }
  case TAG_SLitBytes: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str20);
  }
  case TAG_SLitRune: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str21);
  }
  case TAG_SLitFixed: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str22);
  }
  case TAG_SLitFloat32: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str23);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2eopHead(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str3, 3, "op_");

HeffT2 g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_take_field(v_sp_242, 0);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_args_246 = heff_get_n(v_sp_242, 1, 2);
    V v_t_247 = heff_get_n(heff_get_n(v_c_240, 0, 2), 1, 2);
    V v_it_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_it_248 = (g_list_2efilter_24s1022178817x2079624138(v_args_246));
    } else {
      heff_drop(v_t_247);
      v_it_248 = v_args_246;
    }
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_l_249 = heff_field(v_it_248, 0);
      V v_it2_2410 = heff_field(v_it_248, 1);
      V v_ru_24it_248_24Cons = heff_take_reuse_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it2_2410)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop(v_l_249);
        heff_drop_cell(v_ru_24it_248_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_r2_2411 = heff_field(v_it2_2410, 0);
        V v_it22_2412 = heff_field(v_it2_2410, 1);
        heff_take_n(v_it2_2410, 3ULL, 2);
        switch (heff_tag_of(v_it22_2412)) {
        case TAG_Nil: {
          V v_t_2494;
          if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str0), 2)) {
            heff_drop(v_x_245);
            v_t_2494 = NTAG(TAG_False);
          } else {
            HeffT2 v_t_2414 = ({ V a_0 = v_x_245; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_ws_2418 = v_field_2416;
                V v_t_2421;
                switch (heff_tag_of(v_ws_2418)) {
                case TAG_Nil: {
                  v_t_2421 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str1);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2419 = heff_field(v_ws_2418, 0);
                  V v_xs_2420 = heff_field(v_ws_2418, 1);
                  heff_take_n(v_ws_2418, 3ULL, 2);
                  v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str2); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
                  break;
                }
                default: heff_nomatch(v_ws_2418);
                }
                V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr_str3), v_t_2421);
                heff_drop(v_t_2422);
                V v_t_2458;
                switch (heff_tag_of(v_l_249)) {
                case TAG_SLocal: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SGlobal: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SCode: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SApp: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLam: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SCons: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SProj: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_STag: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SMatch: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SSpecialize: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SIs: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SOpaque: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SAbandon: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SRec: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SFix: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SImplicit: {
                  v_t_2458 = NTAG(TAG_True);
                  break;
                }
                case TAG_SPrim: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SMetaApp: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitInt: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFloat: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitString: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitBytes: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitRune: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFixed: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                case TAG_SLitFloat32: {
                  v_t_2458 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_l_249);
                }
                if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
                  heff_drop(v_t_2458);
                  v_t_2494 = NTAG(TAG_False);
                } else {
                  heff_drop(v_t_2458);
                  switch (heff_tag_of(v_r2_2411)) {
                  case TAG_SLocal: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SGlobal: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SCode: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SApp: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLam: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SCons: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SProj: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_STag: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SMatch: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SSpecialize: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SIs: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SOpaque: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SAbandon: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SRec: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SFix: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SImplicit: {
                    v_t_2494 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_SPrim: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SMetaApp: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitInt: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFloat: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitString: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitBytes: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitRune: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFixed: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_SLitFloat32: {
                    v_t_2494 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_r2_2411);
                  }
                }
              } else {
                heff_drop(v_field_2416);
                v_t_2494 = NTAG(TAG_False);
              }
            }
          }
          if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
            heff_drop(v_t_2494);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24it_248_24Cons, TAG_MkPair, 2, (V[]){v_l_249, v_r2_2411})}});
          } else {
            heff_drop(v_l_249);
            heff_drop_cell(v_ru_24it_248_24Cons, 2);
            heff_drop(v_r2_2411);
            heff_drop(v_t_2494);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2412, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop(v_l_249);
          heff_drop_cell(v_ru_24it_248_24Cons, 2);
          heff_drop(v_r2_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it22_2412)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it_248)}});
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str1, 4, "Cons");

HeffT2 g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_STag: {
    V v_x11_2411 = heff_field(v_x1_240, 0);
    V v_ts_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str0), 2)) {
      heff_drop(v_x11_2411);
      heff_drop_cell(v_ru_24x1_240_24STag, 2);
      if ((heff_unbox_word(heff_arrayLength(v_ts_2412)) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      if (heff_strEq_c(v_x11_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr_str1))) {
        if ((heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)) == ((int64_t)2ULL))) {
          if ((((int64_t)0ULL) < heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)))) {
            V v_t_2418 = heff_arrayIndex_lent(v_ts_2412, MK_INT(0LL), 2);
            if ((((int64_t)1ULL) < heff_unbox_word(heff_arrayLength_lent(v_ts_2412, 0)))) {
              V v_t_2420 = heff_arrayIndex(v_ts_2412, MK_INT(1LL));
              HeffT2 v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_t_2420));
              {
                V v_field_2423 = v_t_2421.f[1];
                int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                if ((v_tag_2422 == ((int64_t)0ULL))) {
                  V v_ts_2425 = v_field_2423;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24STag, TAG_Cons, 2, (V[]){v_t_2418, v_ts_2425})}});
                } else {
                  heff_drop_cell(v_ru_24x1_240_24STag, 2);
                  heff_drop(v_t_2418);
                  heff_drop(v_field_2423);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_ts_2412);
              heff_drop_cell(v_ru_24x1_240_24STag, 2);
              heff_drop(v_t_2418);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_ts_2412);
            heff_drop_cell(v_ru_24x1_240_24STag, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_ts_2412);
          heff_drop_cell(v_ru_24x1_240_24STag, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_ts_2412);
        heff_drop_cell(v_ru_24x1_240_24STag, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eimplicitName_24cpr(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop(v_a_245);
        V v_imp_2411 = v_field_249;
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop_rec(v_imp_2411, 2);
          heff_drop(v_t_2412);
          V t_0 = v_c_240;
          V t_1 = v_xs_241;
          V t_2 = v_names_242;
          V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
          V t_4 = v_rest_246;
          v_c_240 = t_0;
          v_xs_241 = t_1;
          v_names_242 = t_2;
          v_i_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2412);
          V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2411, 1)));
          V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1)));
          V v_t_2415 = heff_strAppend(heff_get_n(v_imp_2411, 0, 2), v_t_2414);
          V v_cell_2416 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2), v_t_2415), heff_hole()});
          V v_u_2417 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2416)));
          heff_drop(v_u_2417);
          return v_cell_2416;
        }
      } else {
        heff_drop(v_field_249);
        V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
        V v_cell_2419 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
        V v_u_2420 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2419)));
        heff_drop(v_u_2420);
        return v_cell_2419;
      }
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 0, 2);
  V v_t_246 = heff_tr(heff_call(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))}));
  V v_args_247 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_take_field(v_sp_243, 1)));
  V v_headAlone_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get_n(v_sp_243, 0, 2)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2)));
    } else {
      return v_s_2411;
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurfaceprint_2eopApp_24cpr(heff_dup(v_c_240), v_xs_242, v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_it1_249 = v_field_247;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_MkPair: {
        V v_l_2410 = heff_field(v_it1_249, 0);
        V v_r2_2411 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        V v_t_2412 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_2410));
        V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
        V v_t_2414 = ({ V b_0 = heff_get_n(v_t_2413, 0, 2); V r_ = (g_heff_2esyntax_2esurfaceprint_2eopHead(b_0)); heff_drop(b_0); r_; });
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(1LL), v_xs_242, v_r2_2411));
        V v_t_2416 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0), v_t_2415));
        V v_s_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1), v_t_2416));
        if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2), heff_strAppend(v_s_2417, ((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3)));
        } else {
          return v_s_2417;
        }
      }
      default: return heff_nomatch(v_it1_249);
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2419 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
      HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(v_c_240, v_p_241, v_xs_242, v_t_2419);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_take_field(v_l_243, 0), heff_get_n(v_l_243, 2, 3)));
  V v_t_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2), v_t_248));
  V v_s_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3), v_t_249);
  if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4), heff_strAppend(v_s_2410, ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5)));
  } else {
    return v_s_2410;
  }
}
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str3, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str5, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str7, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str9, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str10, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str11, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str13, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str16, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str17, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str18, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str20, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str21, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str22, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str27, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str28, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str30, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str32, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str33, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str34, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str36, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str37, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str38, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str40, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str41, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str42, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str44, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str45, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str46, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str48, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str49, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str50, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str52, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str53, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str54, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str56, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str57, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str58, 5, "type ");
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr(V v_c_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str0), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str1), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str2)));
      V v_f_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str3), heff_strAppend(v_t_246, v_t_248));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
    }
  }
  case TAG_SDecode: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2411 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str4), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str5), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str6)));
      V v_f_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str7), heff_strAppend(v_t_2412, v_t_2414));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2421 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2421);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2421);
      V v_t_2422 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str8), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2423 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str9), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str10)));
      V v_f_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str11), heff_strAppend(v_t_2422, v_t_2424));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
    }
  }
  case TAG_SRecord: {
    V v_fs_2427 = heff_field(v_t_243, 1);
    V v_ds_2428 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2429 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      V v_t_2430 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str12), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2431 = heff_arrayToList(heff_take_field(v_fs_2427, 0));
      V v_t_2432 = heff_arrayToList(heff_get_n(v_fs_2427, 2, 3));
      V v_fs_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
      V v_t_2434 = heff_rec_n(2, shape_names__out, (V[]){heff_get_n(v_tf_242, 1, 4), NTAG(TAG_Nil)});
      V v_acc_2437 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0, 2, 2, (V[]){v_c_240, v_ds_2428}); V a_1 = v_t_2434; V a_2 = v_fs_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2433); r_; });
      V v_x2_2438 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str13), heff_get_n(v_acc_2437, 1, 2)));
      V v_t_2441;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str15); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str16), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str17)));
      V v_f_2443 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str18), heff_strAppend(v_t_2430, v_t_2442));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2443}});
    } else {
      heff_drop_rec(v_fs_2427, 3);
      heff_drop(v_ds_2428);
      heff_drop(v_t_2429);
      V v_t_2444 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str19), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2445 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str20), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str21)));
      V v_f_2447 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str22), heff_strAppend(v_t_2444, v_t_2446));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2447}});
    }
  }
  case TAG_SSum: {
    V v_vs_2448 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2449 = heff_dup(heff_rfield(v_tf_242, 3));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_rec(v_vs_2448, 3);
      heff_drop(v_t_2449);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2449);
      V v_t_2450 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str23), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2451 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 0)));
      V v_t_2452 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2448, 2)));
      V v_x1_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_t_2467;
      switch (heff_tag_of(v_x1_2453)) {
      case TAG_Nil: {
        heff_drop(v_c_240);
        heff_drop_rec(v_tf_242, 4);
        heff_drop_rec(v_vs_2448, 3);
        v_t_2467 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str24);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2453, 0ULL, 2);
        V v_t_2456 = heff_arrayToList(heff_take_field(v_vs_2448, 0));
        V v_t_2457 = heff_arrayToList(heff_get_n(v_vs_2448, 2, 3));
        V v_t_2458 = (g_heff_2eutil_2edict_2ezipKV(v_t_2456, v_t_2457));
        V v_x2_2463 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1, 1, 2, (V[]){v_c_240, v_tf_242}), v_t_2458));
        V v_t_2466;
        switch (heff_tag_of(v_x2_2463)) {
        case TAG_Nil: {
          v_t_2466 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str26);
          break;
        }
        case TAG_Cons: {
          V v_x_2464 = heff_field(v_x2_2463, 0);
          V v_xs_2465 = heff_field(v_x2_2463, 1);
          heff_take_n(v_x2_2463, 3ULL, 2);
          v_t_2466 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str27); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2463);
        }
        v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str28), v_t_2466);
        break;
      }
      default: heff_nomatch(v_x1_2453);
      }
      V v_t_2468 = heff_strAppend(v_t_2450, heff_strAppend(v_t_2467, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str29)));
      V v_f_2469 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str30), v_t_2468);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2469}});
    }
  }
  case TAG_SIsTy: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2471 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2471);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2471);
      V v_t_2472 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str31), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str32), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str33)));
      V v_f_2475 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str34), heff_strAppend(v_t_2472, v_t_2474));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
    }
  }
  case TAG_SPrimInt: {
    V v_t_2476 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2476);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2476);
      V v_t_2477 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str35), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2478 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str36), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str37)));
      V v_f_2480 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str38), heff_strAppend(v_t_2477, v_t_2479));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2480}});
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2481 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2481);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2481);
      V v_t_2482 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str39), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2483 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str40), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str41)));
      V v_f_2485 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str42), heff_strAppend(v_t_2482, v_t_2484));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2485}});
    }
  }
  case TAG_SPrimString: {
    V v_t_2486 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2486);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2486);
      V v_t_2487 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str43), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2488 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str44), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str45)));
      V v_f_2490 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str46), heff_strAppend(v_t_2487, v_t_2489));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2490}});
    }
  }
  case TAG_SPrimRune: {
    V v_t_2491 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2491);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2491);
      V v_t_2492 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str47), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2493 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_2494 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str48), heff_strAppend(v_t_2493, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str49)));
      V v_f_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str50), heff_strAppend(v_t_2492, v_t_2494));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2495}});
    }
  }
  case TAG_SPrimArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2497 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_2497) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_2497);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2497);
      V v_t_2498 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str51), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2499 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_24100 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str52), heff_strAppend(v_t_2499, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str53)));
      V v_f_24101 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str54), heff_strAppend(v_t_2498, v_t_24100));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24101}});
    }
  }
  case TAG_SFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24103 = heff_take_field(v_tf_242, 3);
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_c_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop(v_t_24103);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_24103);
      V v_t_24104 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str55), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_24105 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(0LL), heff_take_field(v_tf_242, 1), heff_get_n(v_tf_242, 2, 4)));
      V v_t_24106 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str56), heff_strAppend(v_t_24105, ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str57)));
      V v_f_24107 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str58), heff_strAppend(v_t_24104, v_t_24106));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24107}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_f_2436 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2erecordField_24s1024973208x2082054764(v_c_240, v_ds_2428, v_acc_2435, v_f_2436));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2(V self, V *args) {
  V v_t2_2462 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(v_c_240, MK_INT(2LL), heff_get_n(v_tf_242, 1, 4), v_t2_2462));
}
V g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam1(V self, V *args) {
  V v_v_2459 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2459)) {
  case TAG_MkPair: {
    V v_t_2460 = heff_field(v_v_2459, 0);
    V v_ts_2461 = heff_field(v_v_2459, 1);
    heff_take_n(v_v_2459, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_str25); V a_1 = v_t_2460; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eformerOf_24cpr_lam2, 1, 2, (V[]){v_c_240, v_tf_242}); V b_3 = heff_arrayToList(v_ts_2461); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  default: return heff_nomatch(v_v_2459);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str18, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str21, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str22, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str25, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str26, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str27, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str29, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str30, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str31, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str32, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str33, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str34, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str35, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str36, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str37, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str38, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str41, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str42, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str43, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str44, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return (g_heff_2esyntax_2esurfaceprint_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str0), 2)) {
      return v_x_245;
    } else {
      HeffT2 v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo_24cpr(v_x_245, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_ws_2411 = v_field_249;
          V v_t_2414;
          switch (heff_tag_of(v_ws_2411)) {
          case TAG_Nil: {
            v_t_2414 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_ws_2411, 0);
            V v_xs_2413 = heff_field(v_ws_2411, 1);
            heff_take_n(v_ws_2411, 3ULL, 2);
            v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2411);
          }
          V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str3), v_t_2414);
          heff_drop(v_t_2415);
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str4), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str5)));
        } else {
          heff_drop(v_field_249);
          return v_x_245;
        }
      }
    }
  }
  case TAG_SCode: {
    V v_t_2416 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_t_2416);
  }
  case TAG_SApp: {
    V v_f_2417 = heff_field(v_e_243, 0);
    V v_a_2418 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2417, v_a_2418}));
  }
  case TAG_SLam: {
    V v_t_2419 = heff_field(v_e_243, 0);
    V v_b_2420 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2419, v_b_2420})));
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2421; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2422 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2423 = heff_arrayToList(heff_take_field(v_d_2422, 0));
    V v_t_2424 = heff_arrayToList(heff_get_n(v_d_2422, 2, 3));
    V v_t_2425 = (g_heff_2eutil_2edict_2ezipKV(v_t_2423, v_t_2424));
    V v_x2_2430 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2425));
    V v_t_2433;
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_Nil: {
      v_t_2433 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_xs_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      v_t_2433 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str8); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2430);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str9), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str10)));
  }
  case TAG_SProj: {
    V v_e2_2434 = heff_field(v_e_243, 0);
    V v_l_2435 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2436 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_e2_2434));
    return heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str11), v_l_2435));
  }
  case TAG_STag: {
    V v_x_2437 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2438 = heff_dup(heff_field(v_e_243, 1));
    HeffT2 v_t_2439 = (g_heff_2esyntax_2esurfaceprint_2elistItems_24cpr(v_e_243));
    {
      V v_field_2441 = v_t_2439.f[1];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      if ((v_tag_2440 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_x_2437);
        heff_drop(v_ts_2438);
        V v_items_2443 = v_field_2441;
        V v_x2_2445 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2443));
        V v_t_2448;
        switch (heff_tag_of(v_x2_2445)) {
        case TAG_Nil: {
          v_t_2448 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2446 = heff_field(v_x2_2445, 0);
          V v_xs_2447 = heff_field(v_x2_2445, 1);
          heff_take_n(v_x2_2445, 3ULL, 2);
          v_t_2448 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str13); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2445);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str14), heff_strAppend(v_t_2448, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str15)));
      } else {
        heff_drop(v_field_2441);
        V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2438)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intEq_c(v_t_2449, MK_INT(0LL))) {
          heff_drop(v_lit_240);
          heff_drop(v_p_241);
          heff_drop(v_xs_242);
          heff_drop(v_ts_2438);
          return v_x_2437;
        } else {
          V v_s_2452 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str16); V a_1 = v_x_2437; V a_2 = heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}); V b_3 = heff_arrayToList(v_ts_2438); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          if ((((int64_t)2ULL) <= heff_unbox_word(v_p_241))) {
            return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str17), heff_strAppend(v_s_2452, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str18)));
          } else {
            return v_s_2452;
          }
        }
      }
    }
  }
  case TAG_SMatch: {
    V v_s_2454 = heff_field(v_e_243, 0);
    V v_cases_2455 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2456 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(0LL), heff_dup(v_xs_242), v_s_2454));
    V v_t_2457 = heff_arrayToList(heff_take_field(v_cases_2455, 0));
    V v_t_2458 = heff_arrayToList(heff_get_n(v_cases_2455, 2, 3));
    V v_t_2459 = (g_heff_2eutil_2edict_2ezipKV(v_t_2457, v_t_2458));
    V v_x2_2462 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2459));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str20); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    V v_t_2466 = heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str21), v_t_2465));
    V v_s_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str22), v_t_2466);
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str23), heff_strAppend(v_s_2467, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str24)));
    } else {
      return v_s_2467;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2469 = heff_field(v_e_243, 0);
    V v_x_2470 = heff_field(v_e_243, 1);
    V v_v_2471 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2472 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2469));
    V v_t_2473 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_v_2471));
    V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str25), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str26)));
    V v_t_2475 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str27), heff_strAppend(v_x_2470, v_t_2474));
    V v_s_2476 = heff_strAppend(v_t_2472, v_t_2475);
    if ((((int64_t)1ULL) <= heff_unbox_word(v_p_241))) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str28), heff_strAppend(v_s_2476, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str29)));
    } else {
      return v_s_2476;
    }
  }
  case TAG_SIs: {
    V v_e2_2478 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2478);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str30);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str31);
  }
  case TAG_SRec: {
    V v_e2_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2479);
  }
  case TAG_SFix: {
    V v_e2_27_2481 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2481)) {
    case TAG_MkAbs: {
      V v_x_2482 = heff_field(v_e2_27_2481, 0);
      heff_take_n(v_e2_27_2481, 1ULL, 2);
      return v_x_2482;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2481, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str32);
    }
    default: return heff_nomatch(v_e2_27_2481);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2486 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2486);
  }
  case TAG_SPrim: {
    V v_x_2487 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str33), heff_strAppend(v_x_2487, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str34)));
  }
  case TAG_SMetaApp: {
    V v_m_2488 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str35), heff_intShow(v_m_2488));
  }
  case TAG_SLitInt: {
    V v_i_2491 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2491);
  }
  case TAG_SLitFloat: {
    V v_x_2492 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2492);
  }
  case TAG_SLitString: {
    V v_s_2493 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2494 = ({ V a_0 = v_s_2493; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str36); V r_ = (g_heff_2eutil_2erune_2equoteGo(a_0, a_1, a_2)); heff_drop(v_s_2493); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str37), heff_strAppend(v_t_2494, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str38)));
  }
  case TAG_SLitBytes: {
    V v_s_2495 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2496 = ({ V a_0 = v_s_2495; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str39); V a_3 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str40); V r_ = (g_heff_2eutil_2erune_2equoteBytesGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2495); r_; });
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str41), heff_strAppend(v_t_2496, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str42)));
  }
  case TAG_SLitRune: {
    V v_ch_2497 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2498 = (g_heff_2eutil_2erune_2equoted(v_ch_2497));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str43), heff_strAppend(v_t_2498, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str44)));
  }
  case TAG_SLitFixed: {
    V v_n_24100 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_24100);
  }
  case TAG_SLitFloat32: {
    V v_x_24101 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_24101);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0(V self, V *args) {
  V v_f_2426 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_f_2426, 0);
    V v_e_2428 = heff_field(v_f_2426, 1);
    heff_take_n(v_f_2426, 3ULL, 2);
    V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_e_2428));
    return heff_strAppend(v_l_2427, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str6), v_t_2429));
  }
  default: return heff_nomatch(v_f_2426);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1(V self, V *args) {
  V v_a_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_a_2444));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2(V self, V *args) {
  V v_a_2451 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2451));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3(V self, V *args) {
  V v_alt_2460 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_box_word((heff_unbox_word(v_lit_240) + ((int64_t)2ULL)))});
  return ({ V a_0 = v_t_2461; V a_1 = v_xs_242; V a_2 = v_alt_2460; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2460); r_; });
}