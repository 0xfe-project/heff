// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_n 328
#define LBL_names 305943394
#define LBL_values 1123329101
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381_clo;
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo;
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo;
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(V, V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891_clo;
V g_heff_2esyntax_2esurfaceprint_2eimplicitName(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eimplicitName_clo;
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo;
V g_heff_2esyntax_2esurfaceprint_2elambdas(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo;
V g_heff_2esyntax_2esurfaceprint_2elistItems(V);
V g_heff_2esyntax_2esurfaceprint_2elistItems_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elistItems_clo;
V g_heff_2esyntax_2esurfaceprint_2elocalName(V, V);
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo;
V g_heff_2esyntax_2esurfaceprint_2enth(V, V);
V g_heff_2esyntax_2esurfaceprint_2enth_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enth_clo;
V g_heff_2esyntax_2esurfaceprint_2eopApp(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eopApp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopApp_clo;
V g_heff_2esyntax_2esurfaceprint_2eopHead(V);
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo;
V g_heff_2esyntax_2esurfaceprint_2eoperatorGo(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eoperatorGo_clo;
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(V);
V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_clo;
V g_heff_2esyntax_2esurfaceprint_2espineGo(V, V);
V g_heff_2esyntax_2esurfaceprint_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2espineGo_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2esyntax_2esurfaceprint_2ewordOf(V);
V g_heff_2esyntax_2esurfaceprint_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2ewordOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efilter_24s1022178817x2079624138(V);
V g_list_2efilter_24s1022178817x2079624138_entry(V self, V *a);
extern Clo g_list_2efilter_24s1022178817x2079624138_clo;
V g_list_2efoldl_24f1841208961x1043590714(V, V, V, V, V);
V g_list_2efoldl_24f1841208961x1043590714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1841208961x1043590714_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str0, 4, "plus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str1, 5, "minus");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str2, 5, "times");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str3, 5, "slash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str4, 7, "percent");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str5, 2, "eq");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str6, 2, "lt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str7, 2, "gt");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str8, 3, "amp");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str9, 3, "bar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str10, 4, "bang");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str11, 5, "caret");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str12, 1, "q");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str13, 2, "at");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str14, 4, "hash");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str15, 6, "dollar");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str16, 5, "tilde");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str17, 5, "colon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str18, 3, "dot");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2ewordOf_str19, 9, "backslash");
Clo g_heff_2esyntax_2esurfaceprint_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2ewordOf_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2ewordOf(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(43LL))) {
    heff_drop(v_c_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str0)});
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL))) {
      heff_drop(v_c_240);
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str1)});
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(42LL))) {
        heff_drop(v_c_240);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str2)});
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
          heff_drop(v_c_240);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str3)});
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(37LL))) {
            heff_drop(v_c_240);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str4)});
          } else {
            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(61LL))) {
              heff_drop(v_c_240);
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str5)});
            } else {
              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(60LL))) {
                heff_drop(v_c_240);
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str6)});
              } else {
                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(62LL))) {
                  heff_drop(v_c_240);
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str7)});
                } else {
                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(38LL))) {
                    heff_drop(v_c_240);
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str8)});
                  } else {
                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(124LL))) {
                      heff_drop(v_c_240);
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str9)});
                    } else {
                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(33LL))) {
                        heff_drop(v_c_240);
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str10)});
                      } else {
                        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(94LL))) {
                          heff_drop(v_c_240);
                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str11)});
                        } else {
                          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(63LL))) {
                            heff_drop(v_c_240);
                            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str12)});
                          } else {
                            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(64LL))) {
                              heff_drop(v_c_240);
                              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str13)});
                            } else {
                              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(35LL))) {
                                heff_drop(v_c_240);
                                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str14)});
                              } else {
                                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(36LL))) {
                                  heff_drop(v_c_240);
                                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str15)});
                                } else {
                                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(126LL))) {
                                    heff_drop(v_c_240);
                                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str16)});
                                  } else {
                                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(58LL))) {
                                      heff_drop(v_c_240);
                                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str17)});
                                    } else {
                                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL))) {
                                        heff_drop(v_c_240);
                                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str18)});
                                      } else {
                                        if (heff_intEq_c(v_c_240, MK_INT(92LL))) {
                                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2ewordOf_str19)});
                                        } else {
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2ewordOf(a[0]);
}
Clo g_heff_2esyntax_2esurfaceprint_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eoperatorGo_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_t_245 = (g_heff_2esyntax_2esurfaceprint_2ewordOf(heff_strByteAt(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_246, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
}
V g_heff_2esyntax_2esurfaceprint_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eoperatorGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str0, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str1, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elocalName_str3, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elocalName_entry, 2, 0};

V g_heff_2esyntax_2esurfaceprint_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurfaceprint_2enth(v_xs_240, heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str0), heff_intShow(v_i_241));
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24f1841208961x1043590714(MK_INT(1LL), MK_INT(0LL), heff_dup(v_x_243), v_i_241, v_xs_240));
    V v_x2_245 = (g_list_2ereplicate(v_t_244, ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str1)));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elocalName_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_strAppend(v_x_243, v_t_248);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2elocalName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2elocalName(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elambdas_str17, 1, "_");
Clo g_heff_2esyntax_2esurfaceprint_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elambdas_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_e2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_SU: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_e2_2413, 0);
        V v_b_2416 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_e2_2413, 0);
        V v_b_2420 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFunction: {
      V v_e14_2425 = heff_field(v_e1_2412, 3);
      heff_take_n(v_e1_2412, 8ULL, 5);
      switch (heff_tag_of(v_e14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_e2_2413, 0);
          V v_b_2428 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_e2_2413, 0);
          V v_b_2431 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str4)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_e2_2413, 0);
          V v_b_2435 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str7)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      default: return heff_nomatch(v_e14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_e1_2412, 0ULL, 3);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_e2_2413, 0);
        V v_b_2442 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_e2_2413, 0);
        V v_b_2446 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_e2_2413, 0);
        V v_b_2450 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_e2_2413, 0);
        V v_b_2453 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_e2_2413, 0);
        V v_b_2456 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_e2_2413, 0);
        V v_b_2459 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2461 = heff_field(v_e2_2413, 0);
        V v_b_2462 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2461), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2461, v_bs_241});
        V t_2 = v_b_2462;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2463 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2465 = heff_field(v_e2_2413, 0);
        V v_b_2466 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2465), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2465, v_bs_241});
        V t_2 = v_b_2466;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2467 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2469 = heff_field(v_e2_2413, 0);
        V v_b_2470 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2469), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2469, v_bs_241});
        V t_2 = v_b_2470;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2471 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurfaceprint_2elambdas_str17), v_bs_241});
        V t_2 = v_b_2471;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_STag: {
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2482, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2488, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2490, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2498, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_24100 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24100, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24104, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24106, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24108, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitBytes: {
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  case TAG_SLitRune: {
    V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24114, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24117, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24119, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2esurfaceprint_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2elambdas(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopHead_str23, 0, "");
Clo g_heff_2esyntax_2esurfaceprint_2eopHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eopHead_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eopHead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str0);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_242);
  }
  case TAG_SCode: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str1);
  }
  case TAG_SApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str2);
  }
  case TAG_SLam: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str3);
  }
  case TAG_SCons: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str4);
  }
  case TAG_SProj: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str5);
  }
  case TAG_STag: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str6);
  }
  case TAG_SMatch: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str7);
  }
  case TAG_SSpecialize: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str8);
  }
  case TAG_SIs: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str9);
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str10);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str11);
  }
  case TAG_SRec: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str12);
  }
  case TAG_SFix: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str13);
  }
  case TAG_SImplicit: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str14);
  }
  case TAG_SPrim: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str15);
  }
  case TAG_SMetaApp: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str16);
  }
  case TAG_SLitInt: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str17);
  }
  case TAG_SLitFloat: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str18);
  }
  case TAG_SLitString: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str19);
  }
  case TAG_SLitBytes: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str20);
  }
  case TAG_SLitRune: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str21);
  }
  case TAG_SLitFixed: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str22);
  }
  case TAG_SLitFloat32: {
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eopHead_str23);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eopHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurfaceprint_2eopHead(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eopApp_str3, 3, "op_");
Clo g_heff_2esyntax_2esurfaceprint_2eopApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eopApp_entry, 3, 0};

V g_heff_2esyntax_2esurfaceprint_2eopApp(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_take_field(v_sp_242, 0);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_args_246 = heff_get_n(v_sp_242, 1, 2);
    V v_t_247 = heff_get_n(heff_get_n(v_c_240, 0, 2), 1, 2);
    V v_it_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_it_248 = (g_list_2efilter_24s1022178817x2079624138(v_args_246));
    } else {
      heff_drop(v_t_247);
      v_it_248 = v_args_246;
    }
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_l_249 = heff_field(v_it_248, 0);
      V v_it2_2410 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it2_2410)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
        heff_drop(v_l_249);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_r2_2411 = heff_field(v_it2_2410, 0);
        V v_it22_2412 = heff_field(v_it2_2410, 1);
        heff_take_n(v_it2_2410, 3ULL, 2);
        switch (heff_tag_of(v_it22_2412)) {
        case TAG_Nil: {
          V v_t_2420;
          if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_str0))) {
            heff_drop(v_x_245);
            v_t_2420 = NTAG(TAG_False);
          } else {
            V v_x1_2414 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo(v_x_245, MK_INT(0LL), NTAG(TAG_Nil)));
            switch (heff_tag_of(v_x1_2414)) {
            case TAG_Nothing: {
              v_t_2420 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              V v_ws_2415 = heff_field(v_x1_2414, 0);
              heff_take_n(v_x1_2414, 1ULL, 1);
              V v_t_2418;
              switch (heff_tag_of(v_ws_2415)) {
              case TAG_Nil: {
                v_t_2418 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_str1);
                break;
              }
              case TAG_Cons: {
                V v_x_2416 = heff_field(v_ws_2415, 0);
                V v_xs_2417 = heff_field(v_ws_2415, 1);
                heff_take_n(v_ws_2415, 3ULL, 2);
                v_t_2418 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
                break;
              }
              default: heff_nomatch(v_ws_2415);
              }
              V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eopApp_str3), v_t_2418);
              heff_drop(v_t_2419);
              v_t_2420 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x1_2414);
            }
          }
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_t_2420);
            V v_t_2456;
            switch (heff_tag_of(v_l_249)) {
            case TAG_SLocal: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SGlobal: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SCode: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SApp: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLam: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SCons: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SProj: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_STag: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SMatch: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SSpecialize: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SIs: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SOpaque: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SAbandon: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SRec: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SFix: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SImplicit: {
              v_t_2456 = NTAG(TAG_True);
              break;
            }
            case TAG_SPrim: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SMetaApp: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitInt: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitString: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitBytes: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitRune: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFixed: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat32: {
              v_t_2456 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_l_249);
            }
            if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
              heff_drop(v_l_249);
              heff_drop(v_r2_2411);
              heff_drop(v_t_2456);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_2456);
              V v_t_2492;
              switch (heff_tag_of(v_r2_2411)) {
              case TAG_SLocal: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SGlobal: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SCode: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SApp: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLam: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SCons: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SProj: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_STag: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SMatch: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SSpecialize: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SIs: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SOpaque: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SAbandon: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SRec: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SFix: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SImplicit: {
                v_t_2492 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrim: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SMetaApp: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitInt: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitFloat: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitString: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitBytes: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitRune: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitFixed: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              case TAG_SLitFloat32: {
                v_t_2492 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_r2_2411);
              }
              if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
                heff_drop(v_t_2492);
                return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_249, v_r2_2411})});
              } else {
                heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
                heff_drop(v_l_249);
                heff_drop(v_r2_2411);
                heff_drop(v_t_2492);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
            heff_drop(v_l_249);
            heff_drop(v_r2_2411);
            heff_drop(v_t_2420);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2412, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
          heff_drop(v_l_249);
          heff_drop(v_r2_2411);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it22_2412);
        }
      }
      default: return heff_nomatch(v_it2_2410);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eopApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurfaceprint_2eopApp(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2, 1, "(");
Clo g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry, 5, 0};

V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
      V v_cell_249 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_Just: {
      V v_imp_2411 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_a_245);
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop_rec(v_imp_2411, 2);
        heff_drop(v_t_2412);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_246;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_2411, 1)));
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str0), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str1)));
        V v_t_2415 = heff_strAppend(heff_get_n(v_imp_2411, 0, 2), v_t_2414);
        V v_cell_2416 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_str2), v_t_2415), heff_hole()});
        V v_u_2417 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_24dps(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246, heff_dup(v_cell_2416)));
        heff_drop(v_u_2417);
        return v_cell_2416;
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 0, 2);
  V v_t_246 = heff_tr(heff_call(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))}));
  V v_args_247 = (g_heff_2esyntax_2esurfaceprint_2eargStrs_24s442738857x192312210(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_take_field(v_sp_243, 1)));
  V v_headAlone_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get_n(v_sp_243, 0, 2)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_str2)));
    } else {
      return v_s_2411;
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2esurfaceprint_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  V v_it_245 = (g_heff_2esyntax_2esurfaceprint_2eopApp(heff_dup(v_c_240), v_xs_242, v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappPlain_24s2015132829x1541672402(v_c_240, v_p_241, v_xs_242, v_t_246);
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_MkPair: {
      V v_l_248 = heff_field(v_it1_247, 0);
      V v_r2_249 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      V v_t_2410 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_248));
      V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2espineGo(v_t_243, NTAG(TAG_Nil)));
      V v_t_2412 = ({ V b_0 = heff_get_n(v_t_2411, 0, 2); V r_ = (g_heff_2esyntax_2esurfaceprint_2eopHead(b_0)); heff_drop(b_0); r_; });
      V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(1LL), v_xs_242, v_r2_249));
      V v_t_2414 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str0), v_t_2413));
      V v_s_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str1), v_t_2414));
      if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str2), heff_strAppend(v_s_2415, ((V)&g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_str3)));
      } else {
        return v_s_2415;
      }
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5, 1, ")");
Clo g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(v_c_240, MK_INT(0LL), heff_take_field(v_l_243, 0), heff_get_n(v_l_243, 2, 3)));
  V v_t_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str2), v_t_248));
  V v_s_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str3), v_t_249);
  if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str4), heff_strAppend(v_s_2410, ((V)&g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_str5)));
  } else {
    return v_s_2410;
  }
}
V g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_entry, 1, 0};

V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24SPrim, TAG_Just, 1, (V[]){v_x_2424});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eprimitiveOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eprimitiveOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str3, 3, "op_");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str8, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str9, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str10, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str11, 1, ".");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str14, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str17, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str18, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str19, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str22, 3, " of");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str23, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str24, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str25, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str26, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str27, 2, " }");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str28, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str31, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str32, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str33, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str34, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str35, 1, ">");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str36, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str37, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str38, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str39, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str42, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str43, 1, "]");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str44, 1, "'");
HEFF_LIT(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str45, 1, "'");
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2(V self, V *args);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry, 4, 0};

V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return ({ V a_0 = v_xs_242; V a_1 = v_i_244; V r_ = (g_heff_2esyntax_2esurfaceprint_2elocalName(a_0, a_1)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str0))) {
      return v_x_245;
    } else {
      V v_x1_247 = (g_heff_2esyntax_2esurfaceprint_2eoperatorGo(heff_dup(v_x_245), MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Nothing: {
        return v_x_245;
      }
      case TAG_Just: {
        V v_ws_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_ws_248)) {
        case TAG_Nil: {
          v_t_2411 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_ws_248, 0);
          V v_xs_2410 = heff_field(v_ws_248, 1);
          heff_take_n(v_ws_248, 3ULL, 2);
          v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
          break;
        }
        default: heff_nomatch(v_ws_248);
        }
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str3), v_t_2411);
        heff_drop(v_t_2412);
        return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str4), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str5)));
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
  }
  case TAG_SCode: {
    V v_t_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2413; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
  }
  case TAG_SApp: {
    V v_f_2414 = heff_field(v_e_243, 0);
    V v_a_2415 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eappStr_24s1954203866x1498020998(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_2414, v_a_2415}));
  }
  case TAG_SLam: {
    V v_t_2416 = heff_field(v_e_243, 0);
    V v_b_2417 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2416, v_b_2417})));
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2418; V r_ = (g_heff_2esyntax_2esurfaceprint_2elamStr_24s72485813x553960852(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2419 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2420 = heff_arrayToList(heff_take_field(v_d_2419, 0));
    V v_t_2421 = heff_arrayToList(heff_get_n(v_d_2419, 2, 3));
    V v_t_2422 = (g_heff_2eutil_2edict_2ezipKV(v_t_2420, v_t_2421));
    V v_x2_2427 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2422));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str8); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str9), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str10)));
  }
  case TAG_SProj: {
    V v_e2_2431 = heff_field(v_e_243, 0);
    V v_l_2432 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_e2_2431));
    return heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str11), v_l_2432));
  }
  case TAG_STag: {
    V v_x_2434 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2435 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2436 = (g_heff_2esyntax_2esurfaceprint_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nothing: {
      V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2435)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2437, MK_INT(0LL))) {
        heff_drop(v_lit_240);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2435);
        return v_x_2434;
      } else {
        V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2435)));
        V v_x2_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2434, v_t_2440});
        V v_s_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_s_2444 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_s_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str13); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str14), heff_strAppend(v_s_2444, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str15)));
        } else {
          return v_s_2444;
        }
      }
    }
    case TAG_Just: {
      V v_items_2446 = heff_field(v_t_2436, 0);
      heff_take_n(v_t_2436, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2434);
      heff_drop(v_ts_2435);
      V v_x2_2448 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2446));
      V v_t_2451;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nil: {
        v_t_2451 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_xs_2450 = heff_field(v_x2_2448, 1);
        heff_take_n(v_x2_2448, 3ULL, 2);
        v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str17); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str18), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str19)));
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_SMatch: {
    V v_s_2452 = heff_field(v_e_243, 0);
    V v_cases_2453 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2454 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(0LL), heff_dup(v_xs_242), v_s_2452));
    V v_t_2455 = heff_arrayToList(heff_take_field(v_cases_2453, 0));
    V v_t_2456 = heff_arrayToList(heff_get_n(v_cases_2453, 2, 3));
    V v_t_2457 = (g_heff_2eutil_2edict_2ezipKV(v_t_2455, v_t_2456));
    V v_x2_2460 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2457));
    V v_t_2463;
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_Nil: {
      v_t_2463 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_xs_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      v_t_2463 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str21); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2460);
    }
    V v_t_2464 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str22), v_t_2463));
    V v_s_2465 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str23), v_t_2464);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str24), heff_strAppend(v_s_2465, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str25)));
    } else {
      return v_s_2465;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2467 = heff_field(v_e_243, 0);
    V v_x_2468 = heff_field(v_e_243, 1);
    V v_v_2469 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2470 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2467));
    V v_t_2471 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_v_2469));
    V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str26), heff_strAppend(v_t_2471, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str27)));
    V v_t_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str28), heff_strAppend(v_x_2468, v_t_2472));
    V v_s_2474 = heff_strAppend(v_t_2470, v_t_2473);
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str29), heff_strAppend(v_s_2474, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str30)));
    } else {
      return v_s_2474;
    }
  }
  case TAG_SIs: {
    V v_e2_2476 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2476);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str31);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str32);
  }
  case TAG_SRec: {
    V v_e2_2477 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2477);
  }
  case TAG_SFix: {
    V v_e2_27_2479 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2479)) {
    case TAG_MkAbs: {
      V v_x_2480 = heff_field(v_e2_27_2479, 0);
      heff_take_n(v_e2_27_2479, 1ULL, 2);
      return v_x_2480;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2479, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str33);
    }
    default: return heff_nomatch(v_e2_27_2479);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2484 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2484);
  }
  case TAG_SPrim: {
    V v_x_2485 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str34), heff_strAppend(v_x_2485, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str35)));
  }
  case TAG_SMetaApp: {
    V v_m_2486 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str36), heff_intShow(v_m_2486));
  }
  case TAG_SLitInt: {
    V v_i_2489 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2489);
  }
  case TAG_SLitFloat: {
    V v_x_2490 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2490);
  }
  case TAG_SLitString: {
    V v_s_2491 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2492 = (g_heff_2eutil_2erune_2equoteGo(v_s_2491, MK_INT(0LL), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str37)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str38), heff_strAppend(v_t_2492, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str39)));
  }
  case TAG_SLitBytes: {
    V v_s_2493 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2494 = (g_heff_2eutil_2erune_2equoteBytesGo(v_s_2493, MK_INT(0LL), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str40), ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str41)));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str42), heff_strAppend(v_t_2494, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str43)));
  }
  case TAG_SLitRune: {
    V v_ch_2495 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2496 = (g_heff_2eutil_2erune_2equoted(v_ch_2495));
    return heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str44), heff_strAppend(v_t_2496, ((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str45)));
  }
  case TAG_SLitFixed: {
    V v_n_2498 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2498);
  }
  case TAG_SLitFloat32: {
    V v_x_2499 = heff_tget_v(v_e_243, 0);
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2499);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_l_2424 = heff_field(v_f_2423, 0);
    V v_e_2425 = heff_field(v_f_2423, 1);
    heff_take_n(v_f_2423, 3ULL, 2);
    V v_t_2426 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_e_2425));
    return heff_strAppend(v_l_2424, heff_strAppend(((V)&g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_str6), v_t_2426));
  }
  default: return heff_nomatch(v_f_2423);
  }
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam1(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2439));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam2(V self, V *args) {
  V v_a_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1899084609x920612891(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_a_2447));
}
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_lam3(V self, V *args) {
  V v_alt_2458 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), heff_intAdd(v_lit_240, MK_INT(2LL))});
  return ({ V a_0 = v_t_2459; V a_1 = v_xs_242; V a_2 = v_alt_2458; V r_ = (g_heff_2esyntax_2esurfaceprint_2ealtLine_24s191482215x1468822381(a_0, a_1, a_2)); heff_drop(v_alt_2458); r_; });
}