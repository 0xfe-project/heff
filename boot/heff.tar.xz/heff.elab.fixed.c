// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_fixed 298804110
#define LBL_op 10312
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_heff_2eelab_2efixed_2efixedPrims_get(void);
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s371903670x1850896738(V, V);
V g_list_2efoldl_24s371903670x1850896738_entry(V self, V *a);
extern Clo g_list_2efoldl_24s371903670x1850896738_clo;

static V g_heff_2eelab_2efixed_2eallFixed_val;
static int g_heff_2eelab_2efixed_2eallFixed_st;
static V g_heff_2eelab_2efixed_2eallFixed_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_F32), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U64), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U32), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U16), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U8), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I64), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I32), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I16), v_t_246});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I8), v_t_247});
}
V g_heff_2eelab_2efixed_2eallFixed_get(void) {
  if (g_heff_2eelab_2efixed_2eallFixed_st == 2) return g_heff_2eelab_2efixed_2eallFixed_val;
  if (g_heff_2eelab_2efixed_2eallFixed_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2efixed_2eallFixed_st = 1;
  g_heff_2eelab_2efixed_2eallFixed_val = heff_tr(g_heff_2eelab_2efixed_2eallFixed_init());
  g_heff_2eelab_2efixed_2eallFixed_st = 2;
  return g_heff_2eelab_2efixed_2eallFixed_val;
}
Clo g_heff_2eelab_2efixed_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2etwoTo_entry, 1, 0};

V g_heff_2eelab_2efixed_2etwoTo(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2etwoTo(a[0]);
}
Clo g_heff_2eelab_2efixed_2efixedMin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedMin_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedMin(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_242 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_242 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_242 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_242 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_242 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(v_t_242, MK_INT(1LL))));
    return heff_intSub(MK_INT(0LL), v_t_243);
  }
  case TAG_False: {
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2efixed_2efixedMin(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2efixed_2efixedMax_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedMax_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedMax(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_242 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_242 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_242 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_242 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_242 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_242 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(v_t_242, MK_INT(1LL))));
    return heff_intSub(v_t_243, MK_INT(1LL));
  }
  case TAG_False: {
    V v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_245 = (g_heff_2eelab_2efixed_2etwoTo(v_t_244));
    return heff_intSub(v_t_245, MK_INT(1LL));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2efixed_2efixedMax(a[0]); heff_drop(a[0]); return r;
}

static V g_heff_2eelab_2efixed_2eintOps_val;
static int g_heff_2eelab_2efixed_2eintOps_st;
static V g_heff_2eelab_2efixed_2eintOps_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpToInt), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromInt), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShow), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShr), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShl), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpXor), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpOr), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAnd), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLe), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLt), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpEq), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpRem), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpDiv), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpMul), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSub), v_t_2413});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAdd), v_t_2414});
}
V g_heff_2eelab_2efixed_2eintOps_get(void) {
  if (g_heff_2eelab_2efixed_2eintOps_st == 2) return g_heff_2eelab_2efixed_2eintOps_val;
  if (g_heff_2eelab_2efixed_2eintOps_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2efixed_2eintOps_st = 1;
  g_heff_2eelab_2efixed_2eintOps_val = heff_tr(g_heff_2eelab_2efixed_2eintOps_init());
  g_heff_2eelab_2efixed_2eintOps_st = 2;
  return g_heff_2eelab_2efixed_2eintOps_val;
}

static V g_heff_2eelab_2efixed_2efloat32Ops_val;
static int g_heff_2eelab_2efixed_2efloat32Ops_st;
static V g_heff_2eelab_2efixed_2efloat32Ops_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFloor), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromInt), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpToFloat), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromFloat), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShow), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSqrt), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLe), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLt), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpEq), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpDiv), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpMul), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSub), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAdd), v_t_2411});
}
V g_heff_2eelab_2efixed_2efloat32Ops_get(void) {
  if (g_heff_2eelab_2efixed_2efloat32Ops_st == 2) return g_heff_2eelab_2efixed_2efloat32Ops_val;
  if (g_heff_2eelab_2efixed_2efloat32Ops_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2efixed_2efloat32Ops_st = 1;
  g_heff_2eelab_2efixed_2efloat32Ops_val = heff_tr(g_heff_2eelab_2efixed_2efloat32Ops_init());
  g_heff_2eelab_2efixed_2efloat32Ops_st = 2;
  return g_heff_2eelab_2efixed_2efloat32Ops_val;
}

static V g_heff_2eelab_2efixed_2efixedPrims_val;
static int g_heff_2eelab_2efixed_2efixedPrims_st;
static V g_heff_2eelab_2efixed_2efixedPrims_init(void) {
  V v_t_240 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_240; V r_ = (g_list_2efoldl_24s371903670x1850896738(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eelab_2efixed_2efixedPrims_get(void) {
  if (g_heff_2eelab_2efixed_2efixedPrims_st == 2) return g_heff_2eelab_2efixed_2efixedPrims_val;
  if (g_heff_2eelab_2efixed_2efixedPrims_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2efixed_2efixedPrims_st = 1;
  g_heff_2eelab_2efixed_2efixedPrims_val = heff_tr(g_heff_2eelab_2efixed_2efixedPrims_init());
  g_heff_2eelab_2efixed_2efixedPrims_st = 2;
  return g_heff_2eelab_2efixed_2efixedPrims_val;
}
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str0, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str1, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str2, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str3, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str4, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str5, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str6, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str7, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str8, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str9, 3, "Add");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str10, 3, "Sub");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str11, 3, "Mul");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str12, 3, "Div");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str13, 3, "Rem");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str14, 2, "Eq");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str15, 2, "Lt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str16, 2, "Le");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str17, 3, "And");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str18, 2, "Or");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str19, 3, "Xor");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str20, 3, "Shl");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str21, 3, "Shr");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str22, 4, "Show");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str23, 7, "FromInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str24, 5, "ToInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str25, 4, "Sqrt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str26, 9, "FromFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str27, 7, "ToFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str28, 5, "Floor");
Clo g_heff_2eelab_2efixed_2efixedPrimName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedPrimName_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedPrimName(V v_p_240) {
top: ;
  V v_t_241 = heff_take_field(v_p_240, 0);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str0);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str1);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str2);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str3);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str4);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str5);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str6);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str7);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str8);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get_n(v_p_240, 1, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_OpAdd: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str9);
    break;
  }
  case TAG_OpSub: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str10);
    break;
  }
  case TAG_OpMul: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str11);
    break;
  }
  case TAG_OpDiv: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str12);
    break;
  }
  case TAG_OpRem: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str13);
    break;
  }
  case TAG_OpEq: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str14);
    break;
  }
  case TAG_OpLt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str15);
    break;
  }
  case TAG_OpLe: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str16);
    break;
  }
  case TAG_OpAnd: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str17);
    break;
  }
  case TAG_OpOr: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str18);
    break;
  }
  case TAG_OpXor: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str19);
    break;
  }
  case TAG_OpShl: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str20);
    break;
  }
  case TAG_OpShr: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str21);
    break;
  }
  case TAG_OpShow: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str22);
    break;
  }
  case TAG_OpFromInt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str23);
    break;
  }
  case TAG_OpToInt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str24);
    break;
  }
  case TAG_OpSqrt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str25);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str26);
    break;
  }
  case TAG_OpToFloat: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str27);
    break;
  }
  case TAG_OpFloor: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str28);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_strAppend(v_t_242, v_t_244);
}
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2efixedPrimName(a[0]);
}
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str0, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str1, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str2, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str3, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str4, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str5, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str6, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str7, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str8, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str9, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str10, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str11, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str12, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str13, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str14, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str15, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str16, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str17, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str18, 3, "Add");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str19, 3, "Sub");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str20, 3, "Mul");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str21, 3, "Div");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str22, 3, "Rem");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str23, 2, "Eq");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str24, 2, "Lt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str25, 2, "Le");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str26, 3, "And");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str27, 2, "Or");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str28, 3, "Xor");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str29, 3, "Shl");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str30, 3, "Shr");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str31, 4, "Show");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str32, 7, "FromInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str33, 5, "ToInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str34, 4, "Sqrt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str35, 9, "FromFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str36, 7, "ToFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_str37, 5, "Floor");
V g_heff_2eelab_2efixed_2efixedPrimOf_lam0(V self, V *args);
V g_heff_2eelab_2efixed_2efixedPrimOf_lam1(V self, V *args);
Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedPrimOf_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedPrimOf(V v_x_240) {
top: ;
  V v_t_244 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2efixed_2efixedPrimOf_lam0, 1, 1, (V[]){heff_dup(v_x_240)}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246;
    switch (heff_tag_of(v_w_245)) {
    case TAG_I8: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_246 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_w_245);
    }
    V v_x3_2410 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2efixed_2efixedPrimOf_lam1, 1, 2, (V[]){heff_dup(v_w_245), v_x_240}); V a_1 = v_t_246; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      heff_drop(v_w_245);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_fixed__op, (V[]){v_w_245, v_x_2411})});
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2efixedPrimOf(a[0]);
}
V g_heff_2eelab_2efixed_2efixedPrimOf_lam0(V self, V *args) {
  V v_w_241 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_prefix_242;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str0);
    break;
  }
  case TAG_I16: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str1);
    break;
  }
  case TAG_I32: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str2);
    break;
  }
  case TAG_I64: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str3);
    break;
  }
  case TAG_U8: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str4);
    break;
  }
  case TAG_U16: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str5);
    break;
  }
  case TAG_U32: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str6);
    break;
  }
  case TAG_U64: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str7);
    break;
  }
  case TAG_F32: {
    v_prefix_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str8);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_243 = heff_strSlice(v_x_240, MK_INT(0LL), heff_strLength(heff_dup(v_prefix_242)));
  return heff_strEq(v_t_243, v_prefix_242);
}
V g_heff_2eelab_2efixed_2efixedPrimOf_lam1(V self, V *args) {
  V v_o_247 = args[0];
  V v_w_245 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  switch (heff_tag_of(v_w_245)) {
  case TAG_I8: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str9);
    break;
  }
  case TAG_I16: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str10);
    break;
  }
  case TAG_I32: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str11);
    break;
  }
  case TAG_I64: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str12);
    break;
  }
  case TAG_U8: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str13);
    break;
  }
  case TAG_U16: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str14);
    break;
  }
  case TAG_U32: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str15);
    break;
  }
  case TAG_U64: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str16);
    break;
  }
  case TAG_F32: {
    v_t_248 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str17);
    break;
  }
  default: heff_nomatch(v_w_245);
  }
  V v_t_249;
  switch (heff_tag_of(v_o_247)) {
  case TAG_OpAdd: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str18);
    break;
  }
  case TAG_OpSub: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str19);
    break;
  }
  case TAG_OpMul: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str20);
    break;
  }
  case TAG_OpDiv: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str21);
    break;
  }
  case TAG_OpRem: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str22);
    break;
  }
  case TAG_OpEq: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str23);
    break;
  }
  case TAG_OpLt: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str24);
    break;
  }
  case TAG_OpLe: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str25);
    break;
  }
  case TAG_OpAnd: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str26);
    break;
  }
  case TAG_OpOr: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str27);
    break;
  }
  case TAG_OpXor: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str28);
    break;
  }
  case TAG_OpShl: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str29);
    break;
  }
  case TAG_OpShr: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str30);
    break;
  }
  case TAG_OpShow: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str31);
    break;
  }
  case TAG_OpFromInt: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str32);
    break;
  }
  case TAG_OpToInt: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str33);
    break;
  }
  case TAG_OpSqrt: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str34);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str35);
    break;
  }
  case TAG_OpToFloat: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str36);
    break;
  }
  case TAG_OpFloor: {
    v_t_249 = ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_str37);
    break;
  }
  default: heff_nomatch(v_o_247);
  }
  return heff_strEq(heff_strAppend(v_t_248, v_t_249), v_x_240);
}