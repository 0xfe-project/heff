// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_fixed 298804110
#define LBL_op 10312
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_heff_2eelab_2efixed_2efixedPrims_get(void);
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
HeffT2 g_list_2efind_24s1303721783x1302064695_24cpr(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
HeffT2 g_list_2efind_24s2097169879x1343877600_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s199835065x1975386105(V, V);
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a);
extern Clo g_list_2efoldl_24s199835065x1975386105_clo;

static V g_heff_2eelab_2efixed_2eallFixed_val;
static HEFF_ONCE g_heff_2eelab_2efixed_2eallFixed_st;
static V g_heff_2eelab_2efixed_2eallFixed_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_F32), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U64), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U32), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U16), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_U8), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I64), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I32), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I16), v_t_246});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_I8), v_t_247});
}
V g_heff_2eelab_2efixed_2eallFixed_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2efixed_2eallFixed_st)) return g_heff_2eelab_2efixed_2eallFixed_val;
  return heff_global(&g_heff_2eelab_2efixed_2eallFixed_val, &g_heff_2eelab_2efixed_2eallFixed_st, g_heff_2eelab_2efixed_2eallFixed_init);
}
Clo g_heff_2eelab_2efixed_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2etwoTo_entry, 1, 0};

V g_heff_2eelab_2efixed_2etwoTo(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2etwoTo(a[0]);
}
Clo g_heff_2eelab_2efixed_2efixedMin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedMin_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedMin(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    int64_t v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(heff_box_word((v_t_242 - ((int64_t)1ULL)))));
    return heff_intSub(MK_INT(0LL), v_t_243);
  } else {
    heff_drop(v_t_241);
    return MK_INT(0LL);
  }
}
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2efixed_2efixedMin(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2efixed_2efixedMax_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedMax_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedMax(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    int64_t v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(heff_box_word((v_t_242 - ((int64_t)1ULL)))));
    return heff_intSub(v_t_243, MK_INT(1LL));
  } else {
    heff_drop(v_t_241);
    V v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_245 = (g_heff_2eelab_2efixed_2etwoTo(v_t_244));
    return heff_intSub(v_t_245, MK_INT(1LL));
  }
}
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2efixed_2efixedMax(a0); heff_drop(a0); return r;
}

static V g_heff_2eelab_2efixed_2eintOps_val;
static HEFF_ONCE g_heff_2eelab_2efixed_2eintOps_st;
static V g_heff_2eelab_2efixed_2eintOps_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpToInt), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromInt), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShow), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShr), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShl), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpXor), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpOr), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAnd), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLe), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLt), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpEq), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpRem), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpDiv), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpMul), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSub), v_t_2413});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAdd), v_t_2414});
}
V g_heff_2eelab_2efixed_2eintOps_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2efixed_2eintOps_st)) return g_heff_2eelab_2efixed_2eintOps_val;
  return heff_global(&g_heff_2eelab_2efixed_2eintOps_val, &g_heff_2eelab_2efixed_2eintOps_st, g_heff_2eelab_2efixed_2eintOps_init);
}

static V g_heff_2eelab_2efixed_2efloat32Ops_val;
static HEFF_ONCE g_heff_2eelab_2efixed_2efloat32Ops_st;
static V g_heff_2eelab_2efixed_2efloat32Ops_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFloor), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromInt), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpToFloat), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpFromFloat), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpShow), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSqrt), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLe), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpLt), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpEq), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpDiv), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpMul), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpSub), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_OpAdd), v_t_2411});
}
V g_heff_2eelab_2efixed_2efloat32Ops_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2efixed_2efloat32Ops_st)) return g_heff_2eelab_2efixed_2efloat32Ops_val;
  return heff_global(&g_heff_2eelab_2efixed_2efloat32Ops_val, &g_heff_2eelab_2efixed_2efloat32Ops_st, g_heff_2eelab_2efixed_2efloat32Ops_init);
}

static V g_heff_2eelab_2efixed_2efixedPrims_val;
static HEFF_ONCE g_heff_2eelab_2efixed_2efixedPrims_st;
static V g_heff_2eelab_2efixed_2efixedPrims_init(void) {
  V v_t_240 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_240; V r_ = (g_list_2efoldl_24s199835065x1975386105(a_0, a_1)); heff_drop(v_t_240); r_; });
}
V g_heff_2eelab_2efixed_2efixedPrims_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2efixed_2efixedPrims_st)) return g_heff_2eelab_2efixed_2efixedPrims_val;
  return heff_global(&g_heff_2eelab_2efixed_2efixedPrims_val, &g_heff_2eelab_2efixed_2efixedPrims_st, g_heff_2eelab_2efixed_2efixedPrims_init);
}
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str0, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str1, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str2, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str3, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str4, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str5, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str6, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str7, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str8, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str9, 3, "Add");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str10, 3, "Sub");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str11, 3, "Mul");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str12, 3, "Div");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str13, 3, "Rem");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str14, 2, "Eq");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str15, 2, "Lt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str16, 2, "Le");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str17, 3, "And");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str18, 2, "Or");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str19, 3, "Xor");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str20, 3, "Shl");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str21, 3, "Shr");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str22, 4, "Show");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str23, 7, "FromInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str24, 5, "ToInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str25, 4, "Sqrt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str26, 9, "FromFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str27, 7, "ToFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimName_str28, 5, "Floor");
Clo g_heff_2eelab_2efixed_2efixedPrimName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedPrimName_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedPrimName(V v_p_240) {
top: ;
  V v_t_241 = heff_take_field(v_p_240, 0);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str0);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str1);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str2);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str3);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str4);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str5);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str6);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str7);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str8);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get_n(v_p_240, 1, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_OpAdd: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str9);
    break;
  }
  case TAG_OpSub: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str10);
    break;
  }
  case TAG_OpMul: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str11);
    break;
  }
  case TAG_OpDiv: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str12);
    break;
  }
  case TAG_OpRem: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str13);
    break;
  }
  case TAG_OpEq: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str14);
    break;
  }
  case TAG_OpLt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str15);
    break;
  }
  case TAG_OpLe: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str16);
    break;
  }
  case TAG_OpAnd: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str17);
    break;
  }
  case TAG_OpOr: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str18);
    break;
  }
  case TAG_OpXor: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str19);
    break;
  }
  case TAG_OpShl: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str20);
    break;
  }
  case TAG_OpShr: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str21);
    break;
  }
  case TAG_OpShow: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str22);
    break;
  }
  case TAG_OpFromInt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str23);
    break;
  }
  case TAG_OpToInt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str24);
    break;
  }
  case TAG_OpSqrt: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str25);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str26);
    break;
  }
  case TAG_OpToFloat: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str27);
    break;
  }
  case TAG_OpFloor: {
    v_t_244 = ((V)&g_heff_2eelab_2efixed_2efixedPrimName_str28);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_strAppend(v_t_242, v_t_244);
}
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2efixedPrimName(a[0]);
}
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str0, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str1, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str2, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str3, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str4, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str5, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str6, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str7, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str8, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str9, 4, "int8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str10, 5, "int16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str11, 5, "int32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str12, 5, "int64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str13, 5, "uint8");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str14, 6, "uint16");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str15, 6, "uint32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str16, 6, "uint64");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str17, 7, "float32");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str18, 3, "Add");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str19, 3, "Sub");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str20, 3, "Mul");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str21, 3, "Div");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str22, 3, "Rem");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str23, 2, "Eq");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str24, 2, "Lt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str25, 2, "Le");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str26, 3, "And");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str27, 2, "Or");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str28, 3, "Xor");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str29, 3, "Shl");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str30, 3, "Shr");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str31, 4, "Show");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str32, 7, "FromInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str33, 5, "ToInt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str34, 4, "Sqrt");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str35, 9, "FromFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str36, 7, "ToFloat");
HEFF_LIT(g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str37, 5, "Floor");

HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_list_2efind_24s2097169879x1343877600_24cpr(((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str0), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str1), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str2), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str3), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str4), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str5), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str6), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str7), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str8), heff_dup(v_x_240), MK_INT(0LL), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_w_245 = v_field_243;
      V v_t_246;
      switch (heff_tag_of(v_w_245)) {
      case TAG_I8: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_I16: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_I32: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_I64: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_U8: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_U16: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_U32: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_U64: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
        break;
      }
      case TAG_F32: {
        v_t_246 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
        break;
      }
      default: heff_nomatch(v_w_245);
      }
      HeffT2 v_t_247 = (g_list_2efind_24s1303721783x1302064695_24cpr(v_w_245, ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str9), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str10), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str11), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str12), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str13), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str14), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str15), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str16), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str17), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str18), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str19), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str20), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str21), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str22), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str23), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str24), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str25), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str26), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str27), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str28), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str29), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str30), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str31), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str32), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str33), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str34), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str35), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str36), ((V)&g_heff_2eelab_2efixed_2efixedPrimOf_24cpr_str37), v_x_240, v_t_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_fixed__op, (V[]){v_w_245, v_x_2411})}});
        } else {
          heff_drop(v_w_245);
          heff_drop(v_field_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_x_240);
      heff_drop(v_field_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2efixed_2efixedPrimOf_entry, 1, 0};

V g_heff_2eelab_2efixed_2efixedPrimOf(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2efixed_2efixedPrimOf(a[0]);
}