// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Timeout 14063
#define LBL_checked 974171621
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s500502878x2081065250(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s500502878x2081065250_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s500502878x2081065250_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V);
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_clo;
V g_heff_2elsp_2elsp_2elastChange(V);
V g_heff_2elsp_2elsp_2elastChange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elastChange_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_clo;
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_clo;
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(V, V);
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_clo;
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(V, V);
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_clo;
V g_heff_2elsp_2elsp_2esplitAction(V, V, V);
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitAction_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2eutil_2ejson_2eat(V, V);
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eat_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1351460748x1231260144(V, V);
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_clo;
V g_list_2efilter_24s1392550889x861369760(V, V);
V g_list_2efilter_24s1392550889x861369760_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
V g_list_2efind_24s465947678x1101118081(V, V);
V g_list_2efind_24s465947678x1101118081_entry(V self, V *a);
extern Clo g_list_2efind_24s465947678x1101118081_clo;
V g_list_2efoldl_24f1045673032x1961362160(V, V, V, V, V);
V g_list_2efoldl_24f1045673032x1961362160_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1045673032x1961362160_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s209635602x622053613(V, V);
V g_list_2efoldl_24s209635602x622053613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s209635602x622053613_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s513294106x1954328253(V, V, V, V);
V g_list_2efoldl_24s513294106x1954328253_entry(V self, V *a);
extern Clo g_list_2efoldl_24s513294106x1954328253_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s727803713x1346936525(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1392550889x861369760(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str0, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str2, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str3, 4, "name");
Clo g_heff_2elsp_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_m_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_m_241, 1)});
  V v_t_244 = (g_heff_2elsp_2elsp_2erange(heff_dup(v_src_240), heff_dup(heff_rfield(v_m_241, 2))));
  V v_t_245 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_get_n(v_m_241, 2, 3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str0), v_t_245}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str1), v_t_244}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str2), v_t_243}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str3), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echildJson(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_243 = heff_take_field(v_target_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get_n(v_target_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      V v_t_248 = heff_intSub(heff_strLength(v_t_246), v_t_247);
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), v_t_248), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_target_242, 3);
    V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    V v_t_2414 = heff_intSub(heff_strLength_lent(v_new_241, 0), v_t_2413);
    V v_t_2415 = (g_list_2efoldl_24f1045673032x1961362160(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2416 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(v_t_2414, v_t_2415));
    V v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    V v_t_2418 = heff_intSub(heff_strLength_lent(v_new_241, 0), v_t_2417);
    V v_t_2419 = (g_list_2efoldl_24f1045673032x1961362160(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_t_2420 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(v_t_2418, v_t_2419));
    V v_e_2421 = heff_intAdd(v_t_2420, heff_strLength(v_new_241));
    V v_t_2422 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
    V v_t_2423 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2416, v_e_2421})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2422, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str0, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str1, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str3, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_2417;
  if (heff_intLt_c(heff_dup(v_errorsBefore_243), heff_dup(v_errorsAfter_244))) {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str0), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str1)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str2), heff_strAppend(v_new_242, v_t_248));
    V v_t_2410 = heff_strAppend(heff_get_n(v_t_241, 2, 4), v_t_249);
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str3), v_t_2410)});
  } else {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_2411 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2412 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_245, v_t_2411, heff_dup(v_new_242)));
    V v_x_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_y_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_241, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_x_2413, v_y_2414)) {
      heff_drop(v_new_242);
      v_t_2417 = NTAG(TAG_Nothing);
    } else {
      V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str5)));
      v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_240, 0, 2), v_t_2417});
}
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_243, 1))}));
    V v_t_246 = (g_list_2eany(v_t_245, v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 13), v_mods_241});
      V v_u_249 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_248, v_rest_244, heff_dup(v_cell_247)));
      heff_drop(v_u_249);
      return v_cell_247;
    } else {
      heff_drop(v_t_246);
      V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 13), v_mods_241});
        V v_u_2415 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2414, v_rest_244, heff_dup(v_cell_2413)));
        heff_drop(v_u_2415);
        return v_cell_2413;
      } else {
        heff_drop_rec(v_c_243, 13);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2412);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2410}));
  return ({ V a_0 = v_t_2411; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str1, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str5, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str7, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str8, 5, "title");
Clo g_heff_2elsp_2elsp_2esplitAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitAction_entry, 3, 0};

V g_heff_2elsp_2elsp_2esplitAction(V v_uri_240, V v_src_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str1)})});
  V v_t_245 = heff_take_field(v_x_242, 1);
  V v_t_246 = heff_take_field(v_x_242, 2);
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(heff_dup(v_src_241), heff_dup(v_t_245)));
  V v_t_249;
  if (heff_intLe_c(heff_dup(v_t_245), heff_dup(v_t_246))) {
    heff_drop(v_t_245);
    v_t_249 = v_t_246;
  } else {
    heff_drop(v_t_246);
    v_t_249 = v_t_245;
  }
  V v_t_2410 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str2), v_t_2410}), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str3), v_t_247}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 3, 4)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str5), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str8), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2423})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitAction(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_241), heff_take_field(v_st_240, 2)));
  V v_c_243 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_241), heff_take_field(v_st_240, 1)));
  V v_d_244 = (g_map_2edelete_24s805420727x38051515(v_f_241, heff_take_field(v_st_240, 0)));
  return ({ V rv_0 = v_d_244; V rv_1 = v_c_243; V rv_2 = v_t_242; V rr_ = heff_rec_reuse_nf(v_st_240, 120ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16320u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclosed(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str2, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str3, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str5, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str6, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str7, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str22, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str23, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str24, 21, "textDocument/didClose");
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0, 2, 4, (V[]){v_c_243, v_m_241, v_st_240, v_p_242});
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3(V self, V *args) {
  V v_n_2449 = args[0];
  return v_n_2449;
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4(V self, V *args) {
  V v_x_2452 = args[0];
  V v_f_2421 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_text_2448 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2421), heff_intAdd(v_x_2452, MK_INT(200LL)), heff_dup(heff_rfield(v_st_240, 2))));
  V v_s_2454 = (g_heff_2elsp_2elsp_2echanged(v_st_240, v_f_2421, v_text_2448));
  V v_t_2455 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_s_2454, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  heff_drop(v_hd_2460);
  V f_ = v_k_2461;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6(V self, V *args) {
  V v_x_2464 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2464);
  V v_x_2465 = (g_heff_2elsp_2elsp_2eclosed(v_st_240, v_f_2421));
  V f_ = v_k_245;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str0), 2)) {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_248 = heff_get_n(v_st_240, 5, 7);
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(0LL);
    } else {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(1LL);
    }
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_244, v_k_245));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str1), 2)) {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2413 = heff_dup(heff_rfield(v_st_240, 4));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = ({ V b_0 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_heff_2eutil_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_a_2415 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
        return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
      } else {
        heff_drop(v_hd_244);
        heff_drop(v_t_2413);
        V f_ = v_k_245;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str2), 2)) {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2419 = (g_map_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
        V v_t_2420 = (g_list_2emap_24s1415906091x1371825187(v_t_2419));
        return ({ V a_0 = v_st_240; V a_1 = v_t_2420; V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); r_; });
      } else {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_m_241);
          heff_drop(v_hd_244);
          heff_drop(v_p_242);
          V f_ = v_k_245;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2421 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str3), 2)) {
            heff_drop(v_m_241);
            heff_drop_cell(v_ru_24x_246_24Just, 1);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str4), NTAG(TAG_Nil)});
            V v_it_2424 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str5), v_t_2423}); V a_1 = heff_dup(v_p_242); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str6), NTAG(TAG_Nil)});
            V v_it_2426 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str7), v_t_2425}); V a_1 = v_p_242; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2434;
            switch (heff_tag_of(v_it_2424)) {
            case TAG_Nothing: {
              v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str8);
              break;
            }
            case TAG_Just: {
              V v_it1_2427 = heff_field(v_it_2424, 0);
              heff_take_n(v_it_2424, 1ULL, 1);
              switch (heff_tag_of(v_it1_2427)) {
              case TAG_JNull: {
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str9);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2427, 0ULL, 1);
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str10);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2427, 0ULL, 1);
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str11);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2427, 0ULL, 1);
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str12);
                break;
              }
              case TAG_JString: {
                V v_s_2431 = heff_field(v_it1_2427, 0);
                heff_take_n(v_it1_2427, 1ULL, 1);
                v_t_2434 = v_s_2431;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2427, 0ULL, 1);
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str13);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2427, 0ULL, 1);
                v_t_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str14);
                break;
              }
              default: heff_nomatch(v_it1_2427);
              }
              break;
            }
            default: heff_nomatch(v_it_2424);
            }
            V v_t_2442;
            switch (heff_tag_of(v_it_2426)) {
            case TAG_Nothing: {
              v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str15);
              break;
            }
            case TAG_Just: {
              V v_it1_2435 = heff_field(v_it_2426, 0);
              heff_take_n(v_it_2426, 1ULL, 1);
              switch (heff_tag_of(v_it1_2435)) {
              case TAG_JNull: {
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str16);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2435, 0ULL, 1);
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str17);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2435, 0ULL, 1);
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str18);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2435, 0ULL, 1);
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str19);
                break;
              }
              case TAG_JString: {
                V v_s_2439 = heff_field(v_it1_2435, 0);
                heff_take_n(v_it1_2435, 1ULL, 1);
                v_t_2442 = v_s_2439;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2435, 0ULL, 1);
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str20);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2435, 0ULL, 1);
                v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str21);
                break;
              }
              default: heff_nomatch(v_it1_2435);
              }
              break;
            }
            default: heff_nomatch(v_it_2426);
            }
            V v_d_2443 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2421), heff_rec_n(2, shape_uri__text, (V[]){v_t_2434, v_t_2442}), heff_take_field(v_st_240, 0)));
            V v_t_2444 = ({ V rv_0 = v_d_2443; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2445 = (g_heff_2elsp_2elsp_2echeckNow_24s500502878x2081065250(v_t_2444, v_f_2421));
            V f_ = v_t_2445;
            heff_room[0] = v_hd_244;
            heff_room[1] = v_k_245;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str22), 2)) {
              heff_drop(v_m_241);
              V v_t_2447 = (g_heff_2elsp_2elsp_2elastChange(v_p_242));
              switch (heff_tag_of(v_t_2447)) {
              case TAG_Nothing: {
                heff_drop(v_hd_244);
                heff_drop(v_f_2421);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                V f_ = v_k_245;
                args[0] = v_st_240;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_2448 = heff_field(v_t_2447, 0);
                V v_ru_24t_2447_24Just = heff_take_reuse_n(v_t_2447, 1ULL, 1);
                V v_t_2450 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3_clo)})});
                V v_t_2451 = heff_tag_at_n(v_ru_24t_2447_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
                return (g_co_2eop_24s954557541x749476273(v_t_2451, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4, 1, 4, (V[]){v_f_2421, v_st_240, v_text_2448, v_k_245})));
              }
              default: return heff_nomatch(v_t_2447);
              }
            } else {
              heff_drop(v_p_242);
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str23), 2)) {
                heff_drop(v_m_241);
                V v_t_2457 = (g_heff_2elsp_2elsp_2echeckNow_24s500502878x2081065250(v_st_240, v_f_2421));
                V f_ = v_t_2457;
                heff_room[0] = v_hd_244;
                heff_room[1] = v_k_245;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str24))) {
                  V v_t_2459 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_2421), heff_rfield(v_st_240, 0)));
                  V v_c_2463;
                  switch (heff_tag_of(v_t_2459)) {
                  case TAG_Nothing: {
                    v_c_2463 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5_clo);
                    break;
                  }
                  case TAG_Just: {
                    V v_d_2462 = heff_field(v_t_2459, 0);
                    heff_take_n(v_t_2459, 1ULL, 1);
                    v_c_2463 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(heff_get_n(v_d_2462, 0, 2), NTAG(TAG_Nil)));
                    break;
                  }
                  default: heff_nomatch(v_t_2459);
                  }
                  V f_ = v_c_2463;
                  heff_room[0] = v_hd_244;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6, 1, 3, (V[]){v_st_240, v_f_2421, v_k_245});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2421);
                  V f_ = v_k_245;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1, 1, 5, (V[]){v_m_241, v_st_240, v_hd_244, v_k_245, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(v_p_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2414 = heff_get_n(v_d_2410, 1, 2);
  V v_t_2415 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_x_2413, 1)));
  V v_x_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_2416, 0)), heff_dup(v_text_2414))) {
      v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, heff_get_n(v_c_2416, 1, 2)});
    } else {
      heff_drop_rec(v_c_2416, 2);
      v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_k_244;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2428 = heff_get_n(v_d_2410, 1, 2);
  V v_t_2429 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_x_2427, 1)));
  V v_x_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_2430, 0)), heff_dup(v_text_2428))) {
      v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, heff_get_n(v_c_2430, 1, 2)});
    } else {
      heff_drop_rec(v_c_2430, 2);
      v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    }
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V f_ = v_k_244;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str1), NTAG(TAG_Nil)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 1)));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        V v_c_2412 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_247)));
        V f_ = v_c_2412;
        heff_room[0] = v_hd_243;
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_c_2419 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_c_2419, 0, 2), heff_dup(heff_rfield(v_d_2410, 1)))) {
          heff_drop(v_hd_243);
          V v_text_2421 = heff_get_n(v_d_2410, 1, 2);
          V v_t_2422 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_st_240, 1)));
          V v_x_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            break;
          }
          case TAG_Just: {
            V v_c_2423 = heff_field(v_t_2422, 0);
            heff_take_n(v_t_2422, 1ULL, 1);
            if (heff_strEq_c(heff_dup(heff_rfield(v_c_2423, 0)), heff_dup(v_text_2421))) {
              v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, heff_get_n(v_c_2423, 1, 2)});
            } else {
              heff_drop_rec(v_c_2423, 2);
              v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            }
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V f_ = v_k_244;
          args[0] = v_x_2425;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          V v_c_2426 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_247)));
          V f_ = v_c_2426;
          heff_room[0] = v_hd_243;
          heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(heff_dup(v_st_240), v_o_244));
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1, 2, 3, (V[]){v_c_246, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_str0, 0, "");
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry, 3, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0, 2, 4, (V[]){v_c_243, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_os_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2411 = (g_list_2efilter_24s999680916x306845608(heff_dup(v_p_2410), v_os_247));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2410, v_os_2411});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4(V self, V *args) {
  V v_p_2420 = args[0];
  V v_os_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2421 = (g_list_2efilter_24s999680916x306845608(heff_dup(v_p_2420), v_os_2417));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2420, v_os_2421});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5(V self, V *args) {
  V v_b_2423 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2424 = heff_take_field(v_b_2423, 1);
  V v_t_2427;
  switch (heff_tag_of(v_os_2424)) {
  case TAG_Nil: {
    v_t_2427 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2425 = heff_dup(heff_field(v_os_2424, 0));
    v_t_2427 = heff_get_n(v_x_2425, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2424);
  }
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2424));
  V v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = v_new_242; V a_2 = v_t_2427; V a_3 = v_t_2428; V r_ = (g_list_2efoldl_24s2051016282x1892781518(a_0, a_1, a_2, a_3)); heff_drop(v_t_2428); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_b_2423, 0, 2), v_t_2429});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_d_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2438);
  V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2437, 1, 2)});
  V f_ = v_k_2439;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_q_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2442);
  V v_t_2446;
  switch (heff_tag_of(v_q_2441)) {
  case TAG_MkPair: {
    V v_y_2445 = heff_field(v_q_2441, 1);
    heff_take_n(v_q_2441, 2ULL, 2);
    v_t_2446 = v_y_2445;
    break;
  }
  default: heff_nomatch(v_q_2441);
  }
  V f_ = v_k_2443;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3(V self, V *args) {
  V v_p_2416 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2417 = heff_get_n(v_t_241, 3, 4);
  V v_t_2418 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2417)));
  V v_t_2419 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2418));
  V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4, 1, 1, (V[]){v_os_2417}), v_t_2419));
  V v_texts_2430 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5, 1, 1, (V[]){v_new_242}), v_t_2422));
  V v_t_2431 = ({ V a_0 = heff_dup(v_p_2416); V a_1 = v_texts_2430; V r_ = (g_list_2efind_24s465947678x1101118081(a_0, a_1)); heff_drop(v_texts_2430); r_; });
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Nothing: {
    V v_t_2432 = ({ V a_0 = heff_dup(v_p_2416); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2416, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6_clo)})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
      args[0] = v_t_2436;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2437 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      heff_drop(v_p_2416);
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7, 2, 1, (V[]){v_d_2437});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_Just: {
    V v_q_2441 = heff_field(v_t_2431, 0);
    heff_take_n(v_t_2431, 1ULL, 1);
    heff_drop(v_p_2416);
    heff_drop_rec(v_st_240, 7);
    return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8, 2, 1, (V[]){v_q_2441});
  }
  default: return heff_nomatch(v_t_2431);
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10(V self, V *args) {
  V v_c_2451 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2451, 1, 13)}));
  return ({ V a_0 = v_t_2452; V a_1 = v_x_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2414); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11(V self, V *args) {
  V v_c_2456 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2456, 1, 13)}));
  return ({ V a_0 = v_t_2457; V a_1 = v_x_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2414); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sources_2449 = (g_heff_2elsp_2elsp_2enubSources(v_x_2448));
  V v_x_2450 = (g_list_2efoldl_24s209635602x622053613(NTAG(TAG_Nil), v_sources_2449));
  V v_program_2453 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10, 1, 1, (V[]){heff_dup(v_x_2414)}), heff_dup(heff_rfield(v_x_246, 1))));
  V v_t_2454 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2453));
  V v_t_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2454; V r_ = (g_list_2efoldl_24s513294106x1954328253(a_0, a_1, a_2, a_3)); heff_drop(v_t_2454); r_; });
  V v_program_2458 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11, 1, 1, (V[]){v_x_2414}), heff_dup(v_x_2450)));
  V v_t_2459 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2458));
  V v_t_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2459; V r_ = (g_list_2efoldl_24s513294106x1954328253(a_0, a_1, a_2, a_3)); heff_drop(v_t_2459); r_; });
  V v_x_2461 = (g_heff_2elsp_2elsp_2erenameVerdict(v_x_246, v_t_241, v_new_242, v_t_2455, v_t_2460, v_x_2450));
  V f_ = v_k_245;
  args[0] = v_x_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_247 = heff_dup(heff_rfield(v_t_241, 3));
  V v_t_248 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_247)));
  V v_t_249 = (g_heff_2elsp_2elsp_2enubPaths(v_t_248));
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2, 1, 1, (V[]){v_os_247}), v_t_249));
  V v_t_2413 = (g_list_2emap_24s582709368x2113456071(v_t_2412));
  V v_x_2414 = ({ V a_0 = v_t_2413; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_246, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2414)));
  V v_c_2447 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3, 1, 3, (V[]){heff_dup(v_t_241), heff_dup(v_new_242), heff_dup(v_st_240)}); V a_1 = heff_get_n(v_st_240, 6, 7); V a_2 = v_t_2415; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V f_ = v_c_2447;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9, 1, 5, (V[]){v_x_2414, v_x_246, v_t_241, v_new_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1, 1, 5, (V[]){v_t_241, v_new_242, v_st_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str7, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str8, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str9, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str10, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str11, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str12, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str13, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str15, 2, "id");
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry, 6, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(V v_st_240, V v_id_241, V v_d_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  V v_src_246 = heff_dup(heff_rfield(v_d_242, 1));
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_246)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Left: {
    V v_why_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Left = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_src_246);
    v_t_2414 = heff_tag_at_n(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_why_248});
    break;
  }
  case TAG_Right: {
    V v_out_249 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_246), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2411 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2410));
    V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_249), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
    v_t_2414 = (g_heff_2esyntax_2eformat_2esameMeaning(v_src_246, v_out_249, v_t_2411, v_t_2413));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Left: {
    V v_ru_24t_2414_24Left = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    heff_drop_rec(v_d_242, 2);
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str0), heff_tag_at_n(v_ru_24t_2414_24Left, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str1)})});
    V v_t_2417 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str2), v_t_2417}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str3), v_id_241}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2419})});
    V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2420, 1); r_; });
    V v_a_2422 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0, 1, 2, (V[]){v_z_245, v_st_240})));
  }
  case TAG_Right: {
    V v_t_2425 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24Right = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_t_2425), heff_dup(heff_rfield(v_d_242, 1)))) {
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_t_2425);
      V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str4), heff_tag_at_n(v_ru_24t_2414_24Right, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str5)})});
      V v_t_2428 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str6), v_t_2428}), NTAG(TAG_Nil)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str7), v_id_241}), v_t_2429});
      V v_t_2431 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2430})});
      V v_t_2432 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2431, 1); r_; });
      V v_a_2433 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2432, NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1, 1, 2, (V[]){v_z_245, v_st_240})));
    } else {
      V v_src_2436 = heff_dup(heff_rfield(v_d_242, 1));
      V v_t_2437 = heff_strLength(heff_get_n(v_d_242, 1, 2));
      V v_t_2438 = (g_heff_2elsp_2elsp_2eposition(heff_dup(v_src_2436), MK_INT(0LL)));
      V v_t_2440;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_t_2437))) {
        v_t_2440 = v_t_2437;
      } else {
        heff_drop(v_t_2437);
        v_t_2440 = MK_INT(0LL);
      }
      V v_t_2441 = (g_heff_2elsp_2elsp_2eposition(v_src_2436, v_t_2440));
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str8), v_t_2441}), NTAG(TAG_Nil)});
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str9), v_t_2438}), v_t_2442});
      V v_t_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str10), heff_tag_at_n(v_ru_24t_2414_24Right, TAG_JObject, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str11), heff_tag_n(TAG_JString, 1, (V[]){v_t_2425})});
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
      V v_t_2447 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
      V v_result_2449 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2448});
      V v_t_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str12), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str13)})});
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str14), v_result_2449}), NTAG(TAG_Nil)});
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str15), v_id_241}), v_t_2451});
      V v_t_2453 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2452})});
      V v_t_2454 = ({ V a_0 = v_t_2453; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2453, 1); r_; });
      V v_a_2455 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2454, NTAG(TAG_MkUnit)});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2455})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2, 1, 2, (V[]){v_z_245, v_st_240})));
    }
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2(V self, V *args) {
  V v_x_2457 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str7, 2, "id");
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry, 3, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0, 2, 3, (V[]){v_c_243, v_id_241, v_st_240});
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_d_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2434, 1, 2)});
  V f_ = v_k_2436;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4(V self, V *args) {
  V v_q_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = ({ V a_0 = heff_dup(v_q_2428); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_q_2428, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5_clo)})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
    args[0] = v_t_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_d_2434 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    heff_drop(v_q_2428);
    return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6, 2, 1, (V[]){v_d_2434});
  }
  default: return heff_nomatch(v_t_2429);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2427 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2439, 0, 5)));
  return (g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(v_st_240, v_id_241, v_d_2427, v_t_2440, v_hd_244, v_k_245));
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str1)})});
    V v_t_248 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str2), v_t_248}), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str3), v_id_241}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
  }
  case TAG_Just: {
    V v_f_2416 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2417 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_2416), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      heff_drop(v_f_2416);
      V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str4), heff_tag_at_n(v_ru_24x_246_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str5)})});
      V v_t_2419 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str6), v_t_2419}), NTAG(TAG_Nil)});
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str7), v_id_241}), v_t_2420});
      V v_t_2422 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2421})});
      V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2422, 1); r_; });
      V v_a_2424 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3, 1, 2, (V[]){v_k_245, v_st_240})));
    }
    case TAG_Just: {
      V v_d_2427 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_246_24Just, 1);
      V v_c_2438 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), v_f_2416));
      V f_ = v_c_2438;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7, 1, 5, (V[]){v_st_240, v_id_241, v_d_2427, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry, 3, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_245, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242}));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2(V self, V *args) {
  V v_x_249 = args[0];
  return v_x_249;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  return v_x_2418;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(v_x_2425, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6(V self, V *args) {
  V v_n_2426 = args[0];
  return v_n_2426;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(v_x_2434, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = (g_map_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2431 = (g_list_2efilter_24s1351460748x1231260144(v_x_2429, v_t_2430));
  V v_t_2432 = (g_list_2emap_24s1415906091x1371825187(v_t_2431));
  V v_c_2433 = ({ V a_0 = v_st_240; V a_1 = v_t_2432; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a_0, a_1)); heff_drop(v_t_2432); r_; });
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Message: {
    V v_msg_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_c_2424 = (g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(v_st_240, v_msg_2423));
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Timeout: {
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6_clo)})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_240, 7);
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s954557541x749476273(v_t_2436, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_map_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
  V v_c_2421;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_x_246);
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){MK_INT(-1LL), ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2_clo)})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    v_c_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2411}));
    break;
  }
  case TAG_Cons: {
    V v_d_2412 = heff_field(v_t_248, 0);
    V v_ds_2413 = heff_field(v_t_248, 1);
    V v_ru_24t_248_24Cons = heff_take_reuse_n(v_t_248, 3ULL, 2);
    V v_t_2414 = ({ V a_0 = v_d_2412; V a_1 = v_ds_2413; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_ds_2413); r_; });
    V v_y_2415 = heff_intSub(v_t_2414, v_x_246);
    V v_t_2417;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_y_2415))) {
      v_t_2417 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_t_2417 = MK_INT(0LL);
    }
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24t_248_24Cons, TAG_Await, 2, (V[]){v_t_2417, ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3_clo)})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    v_c_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2420}));
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}