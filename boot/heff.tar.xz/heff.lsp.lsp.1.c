// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_Closed 4831
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_Timeout 14063
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_shutdown 575795380
#define LBL_text 10052084
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_clo;
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907(V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s696017795x59635877_clo;
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_entry, 2, 0};

V g_heff_2elsp_2elsp_2elinesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_src_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_d_242 = heff_strLength_lent(v_src_240, 0);
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_244;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_244 = v_d_242;
    } else {
      heff_drop(v_d_242);
      v_t_244 = v_j_243;
    }
    V v_t_245 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_244, 4)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_d_247 = heff_strLength_lent(v_src_240, 0);
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str1), v_src_240, v_i_241, 5);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_249 = v_d_247;
    } else {
      heff_drop(v_d_247);
      v_t_249 = v_j_248;
    }
    V v_u_2410 = (g_heff_2elsp_2elsp_2elinesFrom_24dps(v_src_240, heff_intAdd(v_t_249, MK_INT(1LL)), heff_dup(v_cell_246)));
    heff_drop(v_u_2410);
    return v_cell_246;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str7, 6, "infixr");

HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_242 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_241, 6);
  if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str0), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str1), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str2), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str3), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str4), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str5), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str6), v_w_242, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str7), v_w_242, 1))))))))) {
    heff_drop(v_w_242);
    V v_t_243 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_244 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_243));
    V v_x_245 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_244));
    V v_t_246 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_y_247 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_246));
    if (heff_intLt_c(v_y_247, v_x_245)) {
      V v_t_248 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_s_249 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_248));
      V v_t_2410 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2411 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2410));
      V v_e_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_2411));
      return ((HeffT2){{v_s_249, v_e_2412}});
    } else {
      V v_y_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_f_2414;
      if (heff_intLe_c_lent(MK_INT(1LL), v_y_2413, 1)) {
        v_f_2414 = v_y_2413;
      } else {
        heff_drop(v_y_2413);
        v_f_2414 = MK_INT(1LL);
      }
      return ((HeffT2){{MK_INT(0LL), v_f_2414}});
    }
  } else {
    heff_drop(v_w_242);
    V v_y_2415 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_f_2416;
    if (heff_intLe_c_lent(MK_INT(1LL), v_y_2415, 1)) {
      v_f_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_f_2416 = MK_INT(1LL);
    }
    return ((HeffT2){{MK_INT(0LL), v_f_2416}});
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam7, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam10, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_entry, 3, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam4(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam3(V self, V *args) {
  V v_use_2421 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_msg_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_2422 = heff_dup(heff_rfield(v_hd_241, 0));
  V v_t_2423 = heff_tr(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265(v_st_240, v_msg_2420, v_hd_241, v_k_2422));
  V f_ = v_use_2421;
  heff_room[0] = v_t_2423;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam4_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884(v_x_2433, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_msg_2420 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2432 = (g_heff_2elsp_2elsp_2ehandled_24s1538271442x899889907(v_st_240, v_msg_2420, v_x_2431));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam6, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam7(V self, V *args) {
  V v_n_2434 = args[0];
  return v_n_2434;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam10(V self, V *args) {
  V v_r_2448 = args[0];
  return v_r_2448;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam9(V self, V *args) {
  V v_use_2442 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_2443 = heff_dup(heff_rfield(v_hd_241, 0));
  V v_t_2444 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2445 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2441, v_t_2444));
  V v_t_2446 = (g_list_2emap_24s1415906091x1371825187(v_t_2445));
  V v_t_2447 = ({ V a_0 = v_st_240; V a_1 = v_t_2446; V a_2 = v_hd_241; V a_3 = v_k_2443; V r_ = heff_tr(g_heff_2elsp_2elsp_2echeckDue_24s1729119029x98171206(a_0, a_1, a_2, a_3)); heff_drop(v_t_2446); r_; });
  V f_ = v_use_2442;
  heff_room[0] = v_t_2447;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam10_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_2441 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2456 = heff_dup(v_st_240);
  V v_t_2457 = ({ V b_0 = heff_get_n(v_st_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2458 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2441, v_t_2457));
  V v_fs_2459 = (g_list_2emap_24s1415906091x1371825187(v_t_2458));
  V v_x3_2460 = v_x_2455;
  V v_t_2468;
  switch (heff_tag_of(v_x3_2460)) {
  case TAG_Left: {
    heff_take_n(v_x3_2460, 0ULL, 1);
    V v_t_2462 = ({ V a_0 = heff_take_field(v_st_2456, 2); V a_1 = v_fs_2459; V r_ = (g_heff_2elsp_2elsp_2eundue(a_0, a_1)); heff_drop(v_fs_2459); r_; });
    V v_project_2463 = heff_take_field(v_st_2456, 3);
    V v_watch_2464 = heff_take_field(v_st_2456, 4);
    V v_shutdown_2465 = heff_take_field(v_st_2456, 5);
    V v_lib_2466 = heff_take_field(v_st_2456, 6);
    v_t_2468 = ({ V rv_2 = v_t_2462; V rv_3 = v_project_2463; V rv_4 = v_watch_2464; V rv_5 = v_shutdown_2465; V rv_6 = v_lib_2466; V rr_ = heff_rec_reuse_nf(v_st_2456, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    break;
  }
  case TAG_Right: {
    V v_st2_2467 = heff_field(v_x3_2460, 0);
    heff_take_n(v_x3_2460, 1ULL, 1);
    heff_drop_rec(v_st_2456, 7);
    heff_drop(v_fs_2459);
    v_t_2468 = v_st2_2467;
    break;
  }
  default: heff_nomatch(v_x3_2460);
  }
  return (g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884(v_t_2468, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam9, 1, 3, (V[]){heff_dup(v_hd_241), heff_dup(v_st_240), heff_dup(v_x_2441)})})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2454;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam11, 1, 4, (V[]){v_st_240, v_x_2441, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Message: {
    V v_msg_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Message = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2419_24Message, TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam3, 1, 3, (V[]){heff_dup(v_hd_241), heff_dup(v_st_240), heff_dup(v_msg_2420)})})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2430;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam5, 1, 4, (V[]){v_st_240, v_msg_2420, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Timeout: {
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam7_clo)})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2440;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam8, 1, 3, (V[]){v_hd_241, v_st_240, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_240, 7);
    V v_lit_2469 = MK_INT(1LL);
    V v_hd_2470 = v_hd_241;
    V v_bind_2471 = heff_take_field(v_hd_2470, 1);
    V v_malg_2472 = heff_get_n(v_hd_2470, 2, 3);
    V v_k2_2473 = v_k_242;
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_lit_2469})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tr(heff_call(v_malg_2472, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})}));
    V f_ = v_bind_2471;
    heff_room[0] = v_t_2479;
    heff_room[1] = v_k2_2473;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2412 = (g_list_2emap_24s366344330x1145113647(v_t_2411));
  V v_t_2418;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    heff_drop(v_x_2410);
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_2413 = heff_field(v_t_2412, 0);
    V v_ds_2414 = heff_field(v_t_2412, 1);
    heff_take_n(v_t_2412, 3ULL, 2);
    V v_t_2415 = ({ V a_0 = v_d_2413; V a_1 = v_ds_2414; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_ds_2414); r_; });
    V v_y_2416 = heff_intSub(v_t_2415, v_x_2410);
    V v_t_2417;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2416, 1)) {
      v_t_2417 = v_y_2416;
    } else {
      heff_drop(v_y_2416);
      v_t_2417 = MK_INT(0LL);
    }
    v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  return (g_heff_2elsp_2erpc_2eawait_24s696017795x59635877(v_t_2418, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s707277422x1866918884_lam2, 1, 3, (V[]){v_hd_241, v_st_240, v_k_242})));
}