// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Send 26077
#define TAG_UriPath 39251
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555(V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_clo;
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207_clo;
V g_heff_2elsp_2elsp_2eclaimable(V);
V g_heff_2elsp_2elsp_2eclaimable_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimable_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_clo;
V g_heff_2elsp_2elsp_2edeclLine(V);
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclLine_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V);
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478(V, V, V);
V g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966(V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_clo;
V g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723(V, V, V);
V g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_clo;
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2esplitAction(V, V, V);
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitAction_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_clo;
V g_heff_2elsp_2elsp_2estoppedAnalysis(V, V, V);
V g_heff_2elsp_2elsp_2estoppedAnalysis_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAnalysis_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458(V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
HeffT2 g_heff_2elsp_2esplit_2esplit_24cpr(V, V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl(V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotInDecl_clo;
HeffT2 g_heff_2elsp_2esplit_2eusedType_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1518670704x517758217(V, V, V, V, V);
V g_list_2efoldl_24f1518670704x517758217_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1518670704x517758217_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1498116261x2030182253(V, V);
V g_list_2ekeepIf_24s1498116261x2030182253_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1498116261x2030182253_clo;
V g_list_2ekeepIf_24s1592706127x1457322737(V, V);
V g_list_2ekeepIf_24s1592706127x1457322737_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1592706127x1457322737_clo;
V g_list_2ekeepIf_24s677751599x1843430141(V, V);
V g_list_2ekeepIf_24s677751599x1843430141_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s677751599x1843430141_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_entry, 2, 0};

V g_heff_2elsp_2elsp_2elinesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_src_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_245 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_245 = v_j_243;
    }
    V v_t_246 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_245, 4)});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str1), v_src_240, v_i_241, 5);
    V v_t_2410;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_2410 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_2410 = v_j_248;
    }
    V v_u_2411 = (g_heff_2elsp_2elsp_2elinesFrom_24dps(v_src_240, heff_intAdd(v_t_2410, MK_INT(1LL)), heff_dup(v_cell_247)));
    heff_drop(v_u_2411);
    return v_cell_247;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewordEnd_str0, 12, " \011\015(){}[]:,=");
Clo g_heff_2elsp_2elsp_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewordEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewordEnd(V v_l_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_l_240, 0), heff_dup(v_i_241))) {
    return v_i_241;
  } else {
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    if (heff_intLe_c(MK_INT(0LL), heff_strFind(v_t_243, ((V)&g_heff_2elsp_2elsp_2ewordEnd_str0), MK_INT(0LL)))) {
      return v_i_241;
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_l_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str0, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str1, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str2, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str5, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str6, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str7, 4, "data");

HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_242 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_241, 6);
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str2), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str4), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str6), v_t_245})});
  V v_t_247 = ({ V a_0 = v_w_242; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str7), v_t_246}); V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, b_1)); heff_drop(v_w_242); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_249 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_248));
    V v_x_2410 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_249));
    V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_y_2412 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2411));
    if (heff_intLt_c(v_y_2412, v_x_2410)) {
      V v_t_2414 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_s_2415 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2414));
      V v_t_2416 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2417 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2416));
      V v_e_2418 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_2417));
      return ((HeffT2){{v_s_2415, v_e_2418}});
    } else {
      V v_y_2419 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_f_2421;
      if (heff_intLe_c_lent(MK_INT(1LL), v_y_2419, 1)) {
        v_f_2421 = v_y_2419;
      } else {
        heff_drop(v_y_2419);
        v_f_2421 = MK_INT(1LL);
      }
      return ((HeffT2){{MK_INT(0LL), v_f_2421}});
    }
  } else {
    heff_drop(v_t_247);
    V v_y_2422 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_f_2424;
    if (heff_intLe_c_lent(MK_INT(1LL), v_y_2422, 1)) {
      v_f_2424 = v_y_2422;
    } else {
      heff_drop(v_y_2422);
      v_f_2424 = MK_INT(1LL);
    }
    return ((HeffT2){{MK_INT(0LL), v_f_2424}});
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str0, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str1, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str2, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str5, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str6, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str7, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str9, 1, " ");
Clo g_heff_2elsp_2elsp_2ekeyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeyOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeyOf(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_242 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_get_n(v_t_241, 0, 2), heff_get_n(v_t_242, 1, 2));
  V v_t_244 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_245 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_244, 6);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str2), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str4), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str6), v_t_248})});
  V v_t_2410 = ({ V a_0 = v_w_245; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str7), v_t_249}); V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, b_1)); heff_drop(v_w_245); heff_drop(b_1); r_; });
  V v_t_2412;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    v_t_2412 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_2411, 6);
  } else {
    heff_drop(v_t_2410);
    v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ekeyOf_str8);
  }
  return heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ekeyOf_str9), v_t_2412));
}
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ekeyOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str2, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str3, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclLine_entry, 1, 0};

V g_heff_2elsp_2elsp_2edeclLine(V v_l_240) {
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_240, 0))) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)13ULL)) ? 0 : (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclLine_str0)) ? 0 : (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclLine_str1)) ? 0 : ({ V v_t_247 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL))); int c_ = (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_247, 2), ((V)&g_heff_2elsp_2elsp_2edeclLine_str2)) ? 0 : ({ V v_t_249 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL))); int c_ = !heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_249, 2), ((V)&g_heff_2elsp_2elsp_2edeclLine_str3)); heff_drop(v_t_249); c_; })); heff_drop(v_t_247); c_; }))))))));
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2edeclLine(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s677751599x1843430141(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s1592706127x1457322737(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str0, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str2, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str3, 4, "name");
Clo g_heff_2elsp_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_m_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_m_241, 1)});
  V v_t_244 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_dup(heff_rfield(v_m_241, 2))));
  V v_t_245 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_get_n(v_m_241, 2, 3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str0), v_t_245}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str1), v_t_244}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str2), v_t_243}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str3), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2echildJson(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_243 = heff_take_field(v_target_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get_n(v_target_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength(v_t_246)) - heff_unbox_word(v_t_247));
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), heff_box_word(v_t_248)), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_target_242, 3);
    V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2413));
    V v_t_2415 = (g_list_2efoldl_24f1518670704x517758217(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2416 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(heff_box_word(v_t_2414), v_t_2415));
    V v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2417));
    V v_t_2419 = (g_list_2efoldl_24f1518670704x517758217(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_t_2420 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(heff_box_word(v_t_2418), v_t_2419));
    V v_e_2421 = heff_intAdd(v_t_2420, heff_strLength(v_new_241));
    V v_t_2422 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
    V v_t_2423 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2416, v_e_2421})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2422, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str0, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str1, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str3, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_2417;
  if (heff_intLt_c_lent(v_errorsBefore_243, v_errorsAfter_244, 0)) {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str0), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str1)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str2), heff_strAppend(v_new_242, v_t_248));
    V v_t_2410 = heff_strAppend(heff_get_n(v_t_241, 2, 4), v_t_249);
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str3), v_t_2410)});
  } else {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_2411 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2412 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_245, v_t_2411, v_new_242));
    V v_x_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_y_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_241, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_x_2413, v_y_2414)) {
      heff_drop(v_new_242);
      v_t_2417 = NTAG(TAG_Nothing);
    } else {
      V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str5)));
      v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_240, 0, 2), v_t_2417});
}
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_243, 1))}));
    V v_t_246 = (g_list_2eany(v_t_245, v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
      V v_u_249 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_248, v_rest_244, heff_dup(v_cell_247)));
      heff_drop(v_u_249);
      return v_cell_247;
    } else {
      heff_drop(v_t_246);
      V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
        V v_u_2415 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2414, v_rest_244, heff_dup(v_cell_2413)));
        heff_drop(v_u_2415);
        return v_cell_2413;
      } else {
        heff_drop_rec(v_c_243, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2412);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2410}));
  return ({ V a_0 = v_t_2411; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str1, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str5, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str7, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str8, 5, "title");
Clo g_heff_2elsp_2elsp_2esplitAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitAction_entry, 3, 0};

V g_heff_2elsp_2elsp_2esplitAction(V v_uri_240, V v_src_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str1)})});
  V v_t_245 = heff_take_field(v_x_242, 1);
  V v_t_246 = heff_take_field(v_x_242, 2);
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_t_245)));
  V v_t_249;
  if (heff_intLe_c_lent(v_t_245, v_t_246, 0)) {
    heff_drop(v_t_245);
    v_t_249 = v_t_246;
  } else {
    heff_drop(v_t_246);
    v_t_249 = v_t_245;
  }
  V v_t_2410 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str2), v_t_2410}), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str3), v_t_247}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 3, 4)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str5), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str8), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2423})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2esplitAction(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimable_str0, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimable_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eclaimable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimable_entry, 1, 0};

V g_heff_2elsp_2elsp_2eclaimable(V v_n_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimable_str0), heff_strAppend(heff_dup(v_n_240), ((V)&g_heff_2elsp_2elsp_2eclaimable_str1)));
  V v_t_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_t_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_x2_243 = heff_get_n(v_t_242, 2, 4);
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_h_244 = heff_field(v_x2_243, 0);
    V v_ru_24x2_243_24Just = heff_take_reuse_n(v_x2_243, 1ULL, 1);
    V v_t_245 = heff_take_field(v_h_244, 0);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop_rec(v_h_244, 5);
      heff_drop_cell(v_ru_24x2_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_t_247 = heff_get_n(v_h_244, 4, 5);
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        if (heff_strEq_c_lent(v_m_246, v_n_240, 1)) {
          return heff_tag_at_n(v_ru_24x2_243_24Just, TAG_Just, 1, (V[]){v_n_240});
        } else {
          heff_drop(v_n_240);
          heff_drop_cell(v_ru_24x2_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_247, 0ULL, 1);
        heff_drop(v_n_240);
        heff_drop_cell(v_ru_24x2_243_24Just, 1);
        heff_drop(v_m_246);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2elsp_2elsp_2eclaimable_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimable(a[0]);
}
Clo g_heff_2elsp_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 2), v_f_241));
  V v_c_243 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 1), v_f_241));
  V v_d_244 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 0), v_f_241));
  return ({ V rv_0 = v_d_244; V rv_1 = v_c_243; V rv_2 = v_t_242; V rr_ = heff_rec_reuse_nf(v_st_240, 120ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16320u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclosed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(V v_wire_240, V v_p_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_str1), v_t_242}), v_p_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2419 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2421 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2419, ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam4_clo)})}));
        return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2421});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam6_clo);
      }
      default: return heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_field_245);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam4(V self, V *args) {
  V v_p_2420 = args[0];
  return v_p_2420;
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_str0, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_str1, 1, ")");
V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_entry, 9, 0};

V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319(V v_wire_240, V v_st_241, V v_f_242, V v_d_243, V v_why_244, V v_ds_245, V v_x6_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Left: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    heff_drop(v_f_242);
    heff_drop(v_z_247);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_str0), heff_strAppend(v_why_244, ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_str1)));
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2410, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2412 = ({ V b_0 = heff_get_n(v_d_243, 1, 2); V a_1 = v_t_2411; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
    V v_diags_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
    V v_t_2414 = heff_rec_n(2, shape_program__diags, (V[]){NTAG(TAG_Nil), v_diags_2413});
    return heff_tail(v_z_248, 1, (V[]){v_t_2414});
  }
  case TAG_Right: {
    V v_a_2415 = heff_field(v_x6_246, 0);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ds_245));
    V v_c_2417 = (g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(v_wire_240, v_st_241, v_f_242, heff_dup(v_d_243), v_ds_245, MK_INT(0LL), v_t_2416, heff_dup(v_a_2415)));
    return heff_tail(v_c_2417, 2, (V[]){v_z_247, heff_clo_n(g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_lam0, 1, 3, (V[]){v_d_243, v_why_244, v_z_248})});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7], a[8]); heff_drop(a5); heff_drop(a6); return r;
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_why_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419 = ({ V b_0 = heff_get_n(v_d_243, 1, 2); V a_1 = v_why_244; V a_2 = v_x_2418; V r_ = (g_heff_2elsp_2elsp_2estoppedAnalysis(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V f_ = v_z_248;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_str1, 0, "");
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam2, 1, 0};
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_entry, 5, 0};

V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458(V v_wire_240, V v_st_241, V v_f_242, V v_d_243, V v_why_244) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam0, 1, 3, (V[]){heff_dup(v_d_243), heff_dup(v_st_241), heff_dup(v_f_242)})})}));
  return heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam3, 2, 6, (V[]){v_t_2419, v_d_243, v_wire_240, v_st_241, v_f_242, v_why_244});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_d_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_ds_249 = ({ V a_0 = v_t_248; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_str0); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  HeffT3 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ds_249; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_249); r_; });
  V v_t_2417;
  {
    V v_field_2412 = v_t_2410.f[1];
    V v_field_2413 = v_t_2410.f[2];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2412;
      V v_x12_2416 = v_field_2413;
      heff_drop(v_x12_2416);
      v_t_2417 = heff_get_n(v_x_2415, 0, 2);
    } else {
      heff_drop(v_field_2412);
      heff_drop(v_field_2413);
      v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_d_243, 1)));
    }
  }
  return ({ V a_0 = v_st_241; V a_1 = v_f_242; V a_2 = v_d_243; V a_3 = v_t_2417; V a_4 = v_hd_246; V a_5 = v_k_247; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam0(V self, V *args) {
  V v_use_245 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_245;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam1, 2, 3, (V[]){v_d_243, v_st_241, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_why_244 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2423 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_t_2424 = ({ V a_0 = v_t_2423; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_str1); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_why_244; V a_5 = v_t_2424; V a_6 = v_x_2422; V a_7 = v_hd_2420; V a_8 = v_k_2421; V r_ = (g_heff_2elsp_2elsp_2estoppedFrom_24s151690147x1236613319(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2424); heff_drop(v_x_2422); r_; });
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_why_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s615738393x1686646143(v_t_2419, heff_dup(v_hd_2420), heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458_lam4, 1, 7, (V[]){v_d_243, v_wire_240, v_st_241, v_f_242, v_why_244, v_hd_2420, v_k_2421})));
}
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str2, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str3, 31, "textDocument/publishDiagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str6, 6, "params");
Clo g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_entry, 3, 0};

V g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723(V v_wire_240, V v_uri_241, V v_ds_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str3)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str4), heff_tag_n(TAG_JString, 1, (V[]){v_uri_241})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_242})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_str6), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_249})});
  V v_t_2411 = ({ V b_0 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410}); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_t_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2412}));
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2413});
}
V g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_247 = v_field_245;
      V v_t_2412 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam0, 1, 3, (V[]){heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_247)})})}));
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam3, 2, 5, (V[]){v_t_2412, v_wire_240, v_st_241, v_f_242, v_d_247});
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_f_242);
      heff_drop(v_field_245);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam8, 2, 1, (V[]){v_st_241});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_d_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eanalysed_24s1921449305x1496141813(v_st_241, v_f_242, v_d_247, v_hd_249, v_k_2410));
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam2(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam0(V self, V *args) {
  V v_use_248 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_d_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_248;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam1, 2, 3, (V[]){v_st_241, v_f_242, v_d_247});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_a_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_a_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_d_247 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_247, 1, 2), heff_get_n(v_x_2421, 0, 2)});
  V v_c_2425 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_st_241, 1), v_f_242, v_t_2424));
  V v_t_2426 = ({ V rv_1 = v_c_2425; V rr_ = heff_rec_reuse_nf(v_st_241, 125ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2414;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2422 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723(v_wire_240, heff_dup(heff_rfield(v_d_247, 0)), heff_dup(heff_rfield(v_x_2421, 1))));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam7, 1, 5, (V[]){v_d_247, v_x_2421, v_st_241, v_f_242, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_247 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_c_2420 = (g_heff_2elsp_2elsp_2estoppedAt_24s1946818061x1245309458(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_247), v_why_2416));
    break;
  }
  case TAG_Right: {
    V v_a_2417 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_c_2420 = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam5, 2, 1, (V[]){v_a_2417});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam6, 1, 6, (V[]){v_wire_240, v_d_247, v_hd_2413, v_st_241, v_f_242, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_d_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam4, 1, 6, (V[]){v_wire_240, v_st_241, v_f_242, v_d_247, v_hd_2413, v_k_2414})));
}
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_lam8(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str2, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str3, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str5, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str6, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str7, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str22, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str23, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str24, 21, "textDocument/didClose");
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam3, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam5, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_entry, 4, 0};

V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966(V v_wire_240, V v_st_241, V v_m_242, V v_p_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(heff_dup(v_wire_240), heff_dup(v_p_243)));
  return heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam0, 2, 5, (V[]){v_c_244, heff_dup(v_m_242), v_st_241, v_wire_240, v_p_243});
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enotified_24s374980071x891489966(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam3(V self, V *args) {
  V v_n_2459 = args[0];
  return v_n_2459;
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam4(V self, V *args) {
  V v_x_2461 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_text_2458 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2462 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_st_241, 2)), heff_dup(v_f_2421), heff_intAdd(v_x_2461, MK_INT(200LL))));
  V v_s_2463 = (g_heff_2elsp_2elsp_2echanged(v_st_241, v_f_2421, v_text_2458));
  V v_t_2464 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_s_2463, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_246;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam5(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  heff_drop(v_hd_2473);
  V f_ = v_k_2474;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam6(V self, V *args) {
  V v_x_2476 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V v_x_2477 = ({ V a_0 = v_st_241; V a_1 = v_f_2421; V r_ = (g_heff_2elsp_2elsp_2eclosed(a_0, a_1)); heff_drop(v_f_2421); r_; });
  V f_ = v_k_246;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str0), 2)) {
    heff_drop(v_x_247);
    heff_drop(v_m_242);
    heff_drop(v_p_243);
    V v_t_249 = heff_get_n(v_st_241, 5, 7);
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = MK_INT(0LL);
    } else {
      heff_drop(v_t_249);
      v_t_2410 = MK_INT(1LL);
    }
    V v_t_2411 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_2410})}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2411, v_hd_245, v_k_246));
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str1), 2)) {
      heff_drop(v_x_247);
      heff_drop(v_m_242);
      heff_drop(v_p_243);
      V v_t_2413 = heff_dup(heff_rfield(v_st_241, 4));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = ({ V b_0 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_t_2415 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_t_2416 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2415}));
        return (g_co_2eop_24s615738393x1686646143(v_t_2416, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam2, 1, 2, (V[]){v_k_246, v_st_241})));
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_245);
        heff_drop(v_t_2413);
        V f_ = v_k_246;
        args[0] = v_st_241;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str2), 2)) {
        heff_drop(v_x_247);
        heff_drop(v_m_242);
        heff_drop(v_p_243);
        V v_t_2419 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
        V v_t_2420 = (g_list_2emap_24s1415906091x1371825187(v_t_2419));
        return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_t_2420; V a_3 = v_hd_245; V a_4 = v_k_246; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2420); r_; });
      } else {
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nothing: {
          heff_drop(v_m_242);
          heff_drop(v_wire_240);
          heff_drop(v_hd_245);
          heff_drop(v_p_243);
          V f_ = v_k_246;
          args[0] = v_st_241;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2421 = heff_field(v_x_247, 0);
          heff_take_n(v_x_247, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str3), 2)) {
            heff_drop(v_m_242);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str4), NTAG(TAG_Nil)});
            HeffT2 v_t_2424 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str5), v_t_2423}), heff_dup(v_p_243)));
            V v_t_2449;
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str6), NTAG(TAG_Nil)});
              HeffT2 v_t_2428 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str7), v_t_2427}), v_p_243));
              {
                V v_field_2430 = v_t_2428.f[1];
                int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                V v_t_2439;
                if ((v_tag_2425 == ((int64_t)0ULL))) {
                  V v_it1_2432 = v_field_2426;
                  switch (heff_tag_of(v_it1_2432)) {
                  case TAG_JNull: {
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str8);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str9);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str10);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str11);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2436 = heff_field(v_it1_2432, 0);
                    heff_take_n(v_it1_2432, 1ULL, 1);
                    v_t_2439 = v_s_2436;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str12);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str13);
                    break;
                  }
                  default: heff_nomatch(v_it1_2432);
                  }
                } else {
                  heff_drop(v_field_2426);
                  v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str14);
                }
                V v_t_2448;
                if ((v_tag_2429 == ((int64_t)0ULL))) {
                  V v_it1_2441 = v_field_2430;
                  switch (heff_tag_of(v_it1_2441)) {
                  case TAG_JNull: {
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str15);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str16);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str17);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str18);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2445 = heff_field(v_it1_2441, 0);
                    heff_take_n(v_it1_2441, 1ULL, 1);
                    v_t_2448 = v_s_2445;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str19);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2441, 0ULL, 1);
                    v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str20);
                    break;
                  }
                  default: heff_nomatch(v_it1_2441);
                  }
                } else {
                  heff_drop(v_field_2430);
                  v_t_2448 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str21);
                }
                v_t_2449 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2439, v_t_2448});
              }
            }
            V v_d_2450 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_st_241, 0), heff_dup(v_f_2421), v_t_2449));
            V v_t_2451 = ({ V rv_0 = v_d_2450; V rr_ = heff_rec_reuse_nf(v_st_241, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2452 = (g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(v_wire_240, v_t_2451, v_f_2421));
            V f_ = v_t_2452;
            heff_room[0] = v_hd_245;
            heff_room[1] = v_k_246;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str22), 2)) {
              heff_drop(v_m_242);
              HeffT2 v_t_2454 = (g_heff_2elsp_2elsp_2elastChange_24cpr(v_p_243));
              {
                V v_field_2456 = v_t_2454.f[1];
                int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                if ((v_tag_2455 == ((int64_t)0ULL))) {
                  V v_text_2458 = v_field_2456;
                  V v_t_2460 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam3_clo)})}));
                  return (g_co_2eop_24s615738393x1686646143(v_t_2460, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam4, 1, 4, (V[]){v_st_241, v_f_2421, v_text_2458, v_k_246})));
                } else {
                  heff_drop(v_wire_240);
                  heff_drop(v_hd_245);
                  heff_drop(v_f_2421);
                  heff_drop(v_field_2456);
                  V f_ = v_k_246;
                  args[0] = v_st_241;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            } else {
              heff_drop(v_p_243);
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str23), 2)) {
                heff_drop(v_m_242);
                V v_t_2466 = (g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(v_wire_240, v_st_241, v_f_2421));
                V f_ = v_t_2466;
                heff_room[0] = v_hd_245;
                heff_room[1] = v_k_246;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_str24))) {
                  HeffT2 v_t_2468 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_2421));
                  V v_c_2475;
                  {
                    V v_field_2470 = v_t_2468.f[1];
                    int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                    if ((v_tag_2469 == ((int64_t)0ULL))) {
                      V v_d_2472 = v_field_2470;
                      v_c_2475 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s1921196052x1919167723(v_wire_240, heff_get_n(v_d_2472, 0, 2), NTAG(TAG_Nil)));
                    } else {
                      heff_drop(v_wire_240);
                      heff_drop(v_field_2470);
                      v_c_2475 = ((V)&g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam5_clo);
                    }
                  }
                  V f_ = v_c_2475;
                  heff_room[0] = v_hd_245;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam6, 1, 3, (V[]){v_st_241, v_f_2421, v_k_246});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_wire_240);
                  heff_drop(v_hd_245);
                  heff_drop(v_f_2421);
                  V f_ = v_k_246;
                  args[0] = v_st_241;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_247);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_lam1, 1, 6, (V[]){v_m_242, v_st_241, v_wire_240, v_hd_245, v_k_246, v_p_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str2, 8, "location");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str3, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str4, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str5, 4, "name");
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746(V v_wire_240, V v_st_241, V v_c_242, V v_y_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_c_242, 1));
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2414;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_wire_240);
      heff_drop(v_p_244);
      V v_d_249 = v_field_247;
      v_c_2414 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam0, 2, 1, (V[]){v_d_249});
    } else {
      heff_drop(v_field_247);
      V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_244, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam1_clo)})}));
      v_c_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2413}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam2, 2, 3, (V[]){v_c_2414, v_y_243, v_c_242});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_get_n(v_d_249, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  return v_u_2412;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_y_243 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_243, 0)});
  V v_t_2419 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_243, 1)});
  V v_t_2420 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_c_242, 0)});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2417})});
  V v_t_2422 = ({ V b_0 = heff_get_n(v_c_242, 3, 14); V a_1 = heff_get_n(v_y_243, 3, 5); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str1), v_t_2422}), NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str2), v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str3), v_t_2420}), v_t_2425});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str4), v_t_2419}), v_t_2426});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_str5), v_t_2418}), v_t_2427});
  V v_x_2429 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
  V f_ = v_k_2416;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_y_243 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746_lam3, 1, 3, (V[]){v_y_243, v_c_242, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_entry, 4, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(V v_wire_240, V v_st_241, V v_c_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    heff_drop(v_c_242);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_c_248 = (g_heff_2elsp_2elsp_2esymbolJson_24s1633373566x390133746(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_c_242), v_y_246));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam1, 2, 5, (V[]){v_c_248, v_wire_240, v_st_241, v_c_242, v_rest_247});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(v_wire_240, v_st_241, v_c_242, v_rest_247));
  V f_ = v_c_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam3, 1, 2, (V[]){v_k_2410, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_lam2, 1, 6, (V[]){v_wire_240, v_st_241, v_c_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_entry, 4, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555(V v_wire_240, V v_st_241, V v_new_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_new_242);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_p_248 = heff_dup(heff_rfield(v_b_246, 0));
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_p_248));
    V v_c_2418;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop(v_p_248);
        V v_d_2413 = v_field_2411;
        v_c_2418 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam1, 2, 1, (V[]){v_d_2413});
      } else {
        heff_drop(v_field_2411);
        V v_t_2417 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_248, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam2_clo)})}));
        v_c_2418 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2417}));
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam3, 2, 6, (V[]){v_c_2418, v_wire_240, v_st_241, v_new_242, v_rest_247, v_b_246});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam2(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam6(V self, V *args) {
  V v_o_2424 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = ({ V b_0 = heff_take_field(v_o_2424, 1); V a_1 = heff_get_n(v_o_2424, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_242})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_str1), v_t_2425}), v_t_2427});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_new_242 = heff_env(self)[0];
  V v_b_246 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam6, 1, 1, (V[]){v_new_242}), heff_get_n(v_b_246, 1, 2)));
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2421, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2429})});
  V v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_x_2423});
  V f_ = v_k_2420;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2419 = heff_env(self)[4];
  V v_b_246 = heff_env(self)[5];
  V v_k_2420 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2422 = (g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555(v_wire_240, v_st_241, heff_dup(v_new_242), v_rest_247));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_2419;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam5, 1, 4, (V[]){v_new_242, v_b_246, v_x_2421, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_b_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555_lam4, 1, 7, (V[]){v_wire_240, v_st_241, v_new_242, v_rest_247, v_hd_2419, v_b_246, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str7, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str8, 2, "id");
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730(V v_wire_240, V v_id_241, V v_new_242, V v_tg_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_tg_243, 2));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_new_242);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str1)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str2), NTAG(TAG_JNull)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str3), v_id_241}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_t_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2413}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2414, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam0, 1, 2, (V[]){v_z_245, v_tg_243})));
  }
  case TAG_Just: {
    V v_t_2416 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2416, 1)), heff_dup(heff_rfield(v_t_2416, 2)), heff_dup(v_new_242)));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        heff_drop(v_new_242);
        heff_drop_rec(v_t_2416, 4);
        V v_why_2421 = v_field_2419;
        V v_c_2422 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2421));
        return heff_tail(v_c_2422, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam1, 1, 2, (V[]){v_z_245, v_tg_243})});
      } else {
        heff_drop(v_field_2419);
        V v_c_2424 = (g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770(heff_dup(v_wire_240), heff_get_n(v_tg_243, 0, 3), heff_dup(v_t_2416), heff_dup(v_new_242)));
        return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam2, 1, 6, (V[]){v_t_2416, v_wire_240, v_new_242, v_z_244, v_id_241, v_z_245})});
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_tg_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_tg_243, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_tg_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_tg_243, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam3(V self, V *args) {
  V v_p_2435 = args[0];
  V v_os_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2436 = (g_list_2ekeepIf_24s1498116261x2030182253(v_p_2435, v_os_2432));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2435, v_os_2436});
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2453;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 2);
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_z_245;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str5)})});
  V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_x_2439})});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_str8), v_id_241}), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2445})});
  V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2446, 1); r_; });
  V v_t_2448 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2448}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2449, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam5, 1, 2, (V[]){v_x_2425, v_z_245})));
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2456);
  V v_t_2459;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 2);
    v_t_2459 = v_x_2457;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_z_245;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_t_2416 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_id_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_dup(heff_field(v_x_2425, 1));
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_Nothing: {
    V v_t_2431;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_dup(heff_field(v_x_2425, 0));
      v_t_2431 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    V v_os_2432 = heff_get_n(v_t_2416, 3, 4);
    V v_t_2433 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2432)));
    V v_t_2434 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2433));
    V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam3, 1, 1, (V[]){v_os_2432}), v_t_2434));
    V v_c_2438 = (g_heff_2elsp_2elsp_2echangesOf_24s84388057x1357365555(heff_dup(v_wire_240), v_t_2431, v_new_242, v_t_2437));
    V f_ = v_c_2438;
    heff_room[0] = heff_dup(v_z_244);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam4, 1, 5, (V[]){v_id_241, v_wire_240, v_z_244, v_x_2425, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2454 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    heff_drop_rec(v_t_2416, 4);
    heff_drop(v_new_242);
    V v_c_2455 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2454));
    V f_ = v_c_2455;
    heff_room[0] = v_z_244;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730_lam6, 1, 2, (V[]){v_x_2425, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_entry, 9, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849(V v_wire_240, V v_st_241, V v_f_242, V v_uri_243, V v_program_244, V v_c_245, V v_off_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam0, 1, 2, (V[]){heff_dup(v_c_245), v_off_246}), heff_dup(heff_rfield(v_c_245, 4))));
  HeffT2 v_t_2411 = (g_heff_2elsp_2esplit_2efirstJust_24cpr(v_t_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_s_2415 = v_field_2413;
      HeffT2 v_t_2416 = (g_heff_2elsp_2esplit_2eusedType_24cpr(heff_dup(v_c_245), heff_dup(v_s_2415)));
      V v_c_2423;
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          heff_drop(v_wire_240);
          heff_drop(v_st_241);
          heff_drop(v_f_242);
          V v_t_2420 = v_field_2418;
          v_c_2423 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam1, 2, 1, (V[]){v_t_2420});
        } else {
          heff_drop(v_field_2418);
          v_c_2423 = (g_heff_2elsp_2elsp_2eprobedType_24s1350594109x526550021(v_wire_240, v_st_241, v_f_242, heff_dup(v_program_244), heff_dup(v_c_245), heff_dup(v_s_2415)));
        }
      }
      return heff_tail(v_c_2423, 2, (V[]){v_z_247, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam2, 1, 5, (V[]){v_program_244, v_c_245, v_s_2415, v_uri_243, v_z_248})});
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_st_241);
      heff_drop(v_f_242);
      heff_drop(v_uri_243);
      heff_drop(v_program_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_z_247);
      heff_drop(v_field_2413);
      return heff_tail(v_z_248, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_off_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 14); V a_1 = v_off_246; V a_2 = v_d_249; V r_ = (g_heff_2elsp_2esplit_2espotInDecl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_program_244 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_s_2415 = heff_env(self)[2];
  V v_uri_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2432;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_program_244);
    heff_drop_rec(v_c_245, 14);
    heff_drop(v_s_2415);
    heff_drop(v_uri_243);
    v_x_2432 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    HeffT2 v_t_2426 = ({ V a_0 = v_program_244; V a_1 = heff_dup(v_c_245); V a_2 = v_s_2415; V a_3 = v_t_2425; HeffT2 r_ = (g_heff_2elsp_2esplit_2esplit_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_x_2430 = v_field_2428;
        V v_t_2431 = ({ V a_0 = v_uri_243; V b_1 = heff_get_n(v_c_245, 3, 14); V a_2 = v_x_2430; V r_ = (g_heff_2elsp_2elsp_2esplitAction(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_c_245, 14);
        heff_drop(v_uri_243);
        heff_drop(v_field_2428);
        v_x_2432 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V f_ = v_z_248;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str2, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str3, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str5, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str6, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str7, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str8, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str9, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str13, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str14, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str15, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str16, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str17, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str18, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str19, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str20, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str21, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str22, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str23, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str24, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str25, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str26, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str27, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str28, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str30, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str31, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str32, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str34, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str35, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str36, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str37, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str39, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str40, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str41, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str42, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str43, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str44, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str45, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str46, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str47, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str48, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str49, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str50, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str51, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str52, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str54, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str55, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str56, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str57, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str58, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str59, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str60, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str61, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str62, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str63, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str64, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str65, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str66, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str67, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str68, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str69, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str70, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str71, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str72, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str73, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str74, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str75, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str76, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str77, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str78, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str79, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str80, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str81, 15, "heff/moduleName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str82, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str83, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str84, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str85, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str86, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam6, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam32(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_entry, 7, 0};

V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(V v_wire_240, V v_st_241, V v_m_242, V v_id_243, V v_p_244, V v_z_245, V v_z_246) {
top: ;
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str0), 2)) {
    heff_drop(v_m_242);
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str2)})});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str3), heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get())}), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str4), v_id_243}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_t_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2413}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2414, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam0, 1, 3, (V[]){v_p_244, v_st_241, v_z_246})));
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str9), 2)) {
      heff_drop(v_m_242);
      heff_drop(v_p_244);
      V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str11)})});
      V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str12), NTAG(TAG_JNull)});
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str13), v_id_243}), v_t_2434});
      V v_t_2436 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2435})});
      V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2436, 1); r_; });
      V v_t_2438 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
      V v_t_2439 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2438}));
      return (g_co_2eop_24s615738393x1686646143(v_t_2439, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam1, 1, 2, (V[]){v_st_241, v_z_246})));
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str14), 2)) {
        heff_drop(v_m_242);
        V v_c_2443 = (g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
        return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam2, 1, 5, (V[]){v_p_244, v_id_243, v_wire_240, v_z_245, v_z_246})});
      } else {
        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str19), 2)) {
          heff_drop(v_m_242);
          V v_c_2455 = (g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
          return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam4, 1, 5, (V[]){v_p_244, v_wire_240, v_id_243, v_z_245, v_z_246})});
        } else {
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str30), 2)) {
            heff_drop(v_m_242);
            V v_c_24100 = (g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
            return heff_tail(v_c_24100, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam10, 1, 5, (V[]){v_p_244, v_id_243, v_wire_240, v_z_245, v_z_246})});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str35), 2)) {
              heff_drop(v_m_242);
              V v_c_24118 = (g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(heff_dup(v_wire_240), v_st_241, v_p_244));
              return heff_tail(v_c_24118, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam12, 1, 4, (V[]){v_id_243, v_wire_240, v_z_245, v_z_246})});
            } else {
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str40), 2)) {
                heff_drop(v_m_242);
                V v_t_24136 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
                V v_t_24137 = (g_list_2emap_24s1415906091x1371825187(v_t_24136));
                V v_c_24138 = (g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(heff_dup(v_st_241), v_t_24137));
                return heff_tail(v_c_24138, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam15, 1, 6, (V[]){v_wire_240, v_st_241, v_z_245, v_p_244, v_id_243, v_z_246})});
              } else {
                if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str54), 2)) {
                  heff_drop(v_m_242);
                  V v_c_24170 = (g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                  return heff_tail(v_c_24170, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam19, 1, 5, (V[]){v_id_243, v_wire_240, v_p_244, v_z_245, v_z_246})});
                } else {
                  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str65), 2)) {
                    heff_drop(v_m_242);
                    V v_c_24212 = (g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(heff_dup(v_wire_240), v_st_241, v_p_244));
                    return heff_tail(v_c_24212, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam24, 1, 4, (V[]){v_wire_240, v_id_243, v_z_245, v_z_246})});
                  } else {
                    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str66), 2)) {
                      heff_drop(v_m_242);
                      V v_c_24215 = (g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                      return heff_tail(v_c_24215, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam25, 1, 5, (V[]){v_p_244, v_wire_240, v_id_243, v_z_245, v_z_246})});
                    } else {
                      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str75), 2)) {
                        heff_drop(v_m_242);
                        V v_t_24231 = (g_heff_2elsp_2elsp_2eformatted_24s1756101267x1778656595(v_wire_240, v_st_241, v_id_243, v_p_244));
                        return heff_tail(v_t_24231, 2, (V[]){v_z_245, v_z_246});
                      } else {
                        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str76), 2)) {
                          heff_drop(v_m_242);
                          V v_c_24233 = (g_heff_2elsp_2elsp_2ewithProgram_24s764201068x1458107523(heff_dup(v_wire_240), v_st_241, heff_dup(v_p_244)));
                          return heff_tail(v_c_24233, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam26, 1, 5, (V[]){v_wire_240, v_p_244, v_z_245, v_id_243, v_z_246})});
                        } else {
                          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str81), 2)) {
                            heff_drop(v_m_242);
                            V v_c_24250 = (g_heff_2elsp_2elsp_2emoduleNamed_24s1134837896x1718828478(heff_dup(v_wire_240), heff_dup(v_st_241), v_p_244));
                            return heff_tail(v_c_24250, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam30, 1, 5, (V[]){v_id_243, v_wire_240, v_z_245, v_z_246, v_st_241})});
                          } else {
                            heff_drop(v_p_244);
                            V v_c_24260 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_243, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str86), v_m_242)));
                            return heff_tail(v_c_24260, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam32, 1, 2, (V[]){v_z_246, v_st_241})});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str5), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str7), v_t_2416})});
  HeffT2 v_t_2418 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str8), v_t_2417}), v_p_244));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    V v_t_2429;
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_it1_2422 = v_field_2420;
      switch (heff_tag_of(v_it1_2422)) {
      case TAG_JNull: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_2423 = heff_field(v_it1_2422, 0);
        heff_take_n(v_it1_2422, 1ULL, 1);
        v_t_2429 = v_b_2423;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2422, 0ULL, 1);
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2422);
      }
    } else {
      heff_drop(v_field_2420);
      v_t_2429 = NTAG(TAG_False);
    }
    V v_t_2430 = ({ V rv_4 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_st_241, 111ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V f_ = v_z_246;
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam1(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V v_t_2441 = ({ V rv_5 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_st_241, 95ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_z_246;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam3(V self, V *args) {
  V v_x_2453 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_2444, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam2(V self, V *args) {
  V v_x_2444 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_result_2445 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2444), v_p_244));
  V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str15), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str16)})});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str17), v_result_2445}), NTAG(TAG_Nil)});
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str18), v_id_243}), v_t_2447});
  V v_t_2449 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2448})});
  V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2449, 1); r_; });
  V v_t_2451 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2450, NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2451}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2452, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam3, 1, 2, (V[]){v_z_246, v_x_2444})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam5(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_d_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = heff_get_n(v_d_2469, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam6(V self, V *args) {
  V v_u_2472 = args[0];
  return v_u_2472;
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam8(V self, V *args) {
  V v_x_2477 = args[0];
  V v_d_2462 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_2475 = heff_env(self)[3];
  V v_k_2476 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str20), heff_tag_n(TAG_JString, 1, (V[]){v_x_2477})});
  V v_t_2479 = ({ V b_0 = heff_take_field(v_d_2462, 1); V a_1 = heff_get_n(v_d_2462, 2, 3); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str21), v_t_2479}), NTAG(TAG_Nil)});
  V v_result_2481 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str22), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str23)})});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str24), v_result_2481}), NTAG(TAG_Nil)});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str25), v_id_243}), v_t_2483});
  V v_t_2485 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2484})});
  V v_t_2486 = ({ V a_0 = v_t_2485; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2485, 1); r_; });
  V v_t_2487 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2486, NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2487}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2488, v_hd_2475, v_k_2476));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam7(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_c_2474 = heff_env(self)[0];
  V v_d_2462 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2474;
  args[0] = heff_dup(v_hd_2475);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam8, 1, 5, (V[]){v_d_2462, v_id_243, v_wire_240, v_hd_2475, v_k_2476});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam9(V self, V *args) {
  V v_x_2498 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2498);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_2456, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam4(V self, V *args) {
  V v_x_2456 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2457 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_2456, 1), v_p_244));
  HeffT2 v_t_2458 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(heff_dup(heff_rfield(v_x_2456, 2)), v_t_2457));
  V v_c_2497;
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    if ((v_tag_2459 == ((int64_t)0ULL))) {
      V v_d_2462 = v_field_2460;
      V v_p_2463 = heff_dup(heff_rfield(v_d_2462, 0));
      V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_x_2456, 0)), 0, 7);
      HeffT2 v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = v_p_2463; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2464); r_; });
      V v_c_2474;
      {
        V v_field_2467 = v_t_2465.f[1];
        int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
        if ((v_tag_2466 == ((int64_t)0ULL))) {
          heff_drop(v_p_2463);
          V v_d_2469 = v_field_2467;
          v_c_2474 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam5, 2, 1, (V[]){v_d_2469});
        } else {
          heff_drop(v_field_2467);
          V v_t_2473 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2463, ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam6_clo)})}));
          v_c_2474 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2473}));
        }
      }
      v_c_2497 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam7, 2, 4, (V[]){v_c_2474, v_d_2462, v_id_243, v_wire_240});
    } else {
      heff_drop(v_field_2460);
      V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str26), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str27)})});
      V v_t_2490 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str28), NTAG(TAG_JNull)});
      V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, NTAG(TAG_Nil)});
      V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str29), v_id_243}), v_t_2491});
      V v_t_2493 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_t_2492})});
      V v_t_2494 = ({ V a_0 = v_t_2493; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2493, 1); r_; });
      V v_t_2495 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2494, NTAG(TAG_MkUnit)});
      V v_t_2496 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2495}));
      v_c_2497 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2496}));
    }
  }
  V f_ = v_c_2497;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam9, 1, 2, (V[]){v_z_246, v_x_2456});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam11(V self, V *args) {
  V v_x_24116 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24116);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24101, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam10(V self, V *args) {
  V v_x_24101 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24101, 2))));
  V v_t_24107;
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_Nil: {
    heff_drop(v_p_244);
    v_t_24107 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24103 = heff_field(v_x1_24102, 0);
    heff_take_n(v_x1_24102, 1ULL, 2);
    V v_t_24105 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_24101, 1), v_p_244));
    V v_t_24106 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24103, v_t_24105));
    v_t_24107 = (g_list_2emap_24s4199228x1154005405(v_t_24106));
    break;
  }
  default: heff_nomatch(v_x1_24102);
  }
  V v_result_24108 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24107});
  V v_t_24109 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str31), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str32)})});
  V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str33), v_result_24108}), NTAG(TAG_Nil)});
  V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str34), v_id_243}), v_t_24110});
  V v_t_24112 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_t_24111})});
  V v_t_24113 = ({ V a_0 = v_t_24112; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24112, 1); r_; });
  V v_t_24114 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24113, NTAG(TAG_MkUnit)});
  V v_t_24115 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24114}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24115, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam11, 1, 2, (V[]){v_z_246, v_x_24101})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam13(V self, V *args) {
  V v_y_24124 = args[0];
  V v_x_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_x_24119, 1, 3); V a_1 = v_y_24124; V r_ = (g_heff_2elsp_2elsp_2edocSymbol(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam14(V self, V *args) {
  V v_x_24134 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24119 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24134);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24119, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam12(V self, V *args) {
  V v_x_24119 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24120 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24119, 2))));
  V v_t_24125;
  switch (heff_tag_of(v_x1_24120)) {
  case TAG_Nil: {
    v_t_24125 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24121 = heff_field(v_x1_24120, 0);
    heff_take_n(v_x1_24120, 1ULL, 2);
    V v_t_24123 = (g_heff_2ebuild_2equery_2esymbols(v_x_24121));
    v_t_24125 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam13, 1, 1, (V[]){heff_dup(v_x_24119)}), v_t_24123));
    break;
  }
  default: heff_nomatch(v_x1_24120);
  }
  V v_result_24126 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24125});
  V v_t_24127 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str36), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str37)})});
  V v_t_24128 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str38), v_result_24126}), NTAG(TAG_Nil)});
  V v_t_24129 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str39), v_id_243}), v_t_24128});
  V v_t_24130 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24127, v_t_24129})});
  V v_t_24131 = ({ V a_0 = v_t_24130; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24130, 1); r_; });
  V v_t_24132 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24131, NTAG(TAG_MkUnit)});
  V v_t_24133 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24132}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24133, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam14, 1, 2, (V[]){v_z_246, v_x_24119})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam18(V self, V *args) {
  V v_x_24168 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24142 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24168);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24142, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam17(V self, V *args) {
  V v_x_24159 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_x_24142 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24160 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str50), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str51)})});
  V v_t_24161 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str52), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24159})});
  V v_t_24162 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24161, NTAG(TAG_Nil)});
  V v_t_24163 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str53), v_id_243}), v_t_24162});
  V v_t_24164 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24160, v_t_24163})});
  V v_t_24165 = ({ V a_0 = v_t_24164; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24164, 1); r_; });
  V v_t_24166 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24165, NTAG(TAG_MkUnit)});
  V v_t_24167 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24166}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24167, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam18, 1, 2, (V[]){v_z_246, v_x_24142})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam16(V self, V *args) {
  V v_x_24142 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str41), NTAG(TAG_Nil)});
  HeffT2 v_t_24144 = (g_json_2eat_24cpr(v_t_24143, v_p_244));
  V v_t_24156;
  {
    V v_field_24146 = v_t_24144.f[1];
    int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
    V v_t_24155;
    if ((v_tag_24145 == ((int64_t)0ULL))) {
      V v_it1_24148 = v_field_24146;
      switch (heff_tag_of(v_it1_24148)) {
      case TAG_JNull: {
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str42);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24148, 0ULL, 1);
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str43);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24148, 0ULL, 1);
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str44);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24148, 0ULL, 1);
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str45);
        break;
      }
      case TAG_JString: {
        V v_s_24152 = heff_field(v_it1_24148, 0);
        heff_take_n(v_it1_24148, 1ULL, 1);
        v_t_24155 = v_s_24152;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24148, 0ULL, 1);
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str46);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24148, 0ULL, 1);
        v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str47);
        break;
      }
      default: heff_nomatch(v_it1_24148);
      }
    } else {
      heff_drop(v_field_24146);
      v_t_24155 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str48);
    }
    v_t_24156 = ({ V a_0 = v_t_24155; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str49); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24155); r_; });
  }
  V v_t_24157 = (g_heff_2elsp_2elsp_2enubCheckedPaths(heff_dup(heff_rfield(v_x_24142, 1))));
  V v_c_24158 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = heff_dup(heff_rfield(v_x_24142, 0)); V a_2 = v_t_24156; V a_3 = v_t_24157; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(a_0, a_1, a_2, a_3)); heff_drop(v_t_24156); heff_drop(v_t_24157); r_; });
  V f_ = v_c_24158;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam17, 1, 5, (V[]){v_id_243, v_wire_240, v_z_245, v_z_246, v_x_24142});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam15(V self, V *args) {
  V v_x_24139 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24140 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24139));
  V v_c_24141 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = v_st_241; V a_2 = v_t_24140; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(a_0, a_1, a_2)); heff_drop(v_t_24140); r_; });
  V f_ = v_c_24141;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam16, 1, 5, (V[]){v_p_244, v_wire_240, v_z_245, v_id_243, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam20(V self, V *args) {
  V v_o_24182 = args[0];
  V v_p_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24183 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str59), NTAG(TAG_Nil)});
  HeffT2 v_t_24184 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str60), v_t_24183}), v_p_244));
  {
    V v_field_24186 = v_t_24184.f[1];
    int64_t v_tag_24185 = ((int64_t)v_t_24184.f[0]);
    if ((v_tag_24185 == ((int64_t)0ULL))) {
      V v_it1_24188 = v_field_24186;
      switch (heff_tag_of(v_it1_24188)) {
      case TAG_JNull: {
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      case TAG_JBool: {
        V v_b_24189 = heff_field(v_it1_24188, 0);
        heff_take_n(v_it1_24188, 1ULL, 1);
        V v_ret_24bool = heff_bool(((heff_dup(v_b_24189) == NTAG(TAG_True)) || ({ V v_t_24190 = heff_dup(heff_rfield(v_o_24182, 3)); int c_ = !(heff_dup(v_t_24190) == NTAG(TAG_True)); heff_drop(v_t_24190); c_; })));
        heff_drop_rec(v_o_24182, 4);
        heff_drop(v_b_24189);
        return v_ret_24bool;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24188, 0ULL, 1);
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24188, 0ULL, 1);
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      case TAG_JString: {
        heff_take_n(v_it1_24188, 0ULL, 1);
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24188, 0ULL, 1);
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24188, 0ULL, 1);
        heff_drop_rec(v_o_24182, 4);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24188);
      }
    } else {
      heff_drop_rec(v_o_24182, 4);
      heff_drop(v_field_24186);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam22(V self, V *args) {
  V v_x_24200 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_24198 = heff_env(self)[2];
  V v_k_24199 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24201 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str61), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str62)})});
  V v_t_24202 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str63), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24200})});
  V v_t_24203 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24202, NTAG(TAG_Nil)});
  V v_t_24204 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str64), v_id_243}), v_t_24203});
  V v_t_24205 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24201, v_t_24204})});
  V v_t_24206 = ({ V a_0 = v_t_24205; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24205, 1); r_; });
  V v_t_24207 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24206, NTAG(TAG_MkUnit)});
  V v_t_24208 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24207}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24208, v_hd_24198, v_k_24199));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam21(V self, V *args) {
  V v_hd_24198 = args[0];
  V v_k_24199 = args[1];
  V v_c_24197 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24197;
  args[0] = heff_dup(v_hd_24198);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam22, 1, 4, (V[]){v_id_243, v_wire_240, v_hd_24198, v_k_24199});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam23(V self, V *args) {
  V v_x_24210 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24171 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24210);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24171, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam19(V self, V *args) {
  V v_x_24171 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24172 = heff_dup(heff_rfield(v_x_24171, 2));
  V v_c_24209;
  switch (heff_tag_of(v_t_24172)) {
  case TAG_Nothing: {
    heff_drop(v_p_244);
    V v_t_24173 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str55), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str56)})});
    V v_t_24174 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str57), NTAG(TAG_JNull)});
    V v_t_24175 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24174, NTAG(TAG_Nil)});
    V v_t_24176 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str58), v_id_243}), v_t_24175});
    V v_t_24177 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24173, v_t_24176})});
    V v_t_24178 = ({ V a_0 = v_t_24177; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24177, 1); r_; });
    V v_t_24179 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24178, NTAG(TAG_MkUnit)});
    V v_t_24180 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24179}));
    v_c_24209 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_24180}));
    break;
  }
  case TAG_Just: {
    V v_t_24181 = heff_field(v_t_24172, 0);
    heff_take_n(v_t_24172, 1ULL, 1);
    V v_t_24196 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam20, 1, 1, (V[]){v_p_244}), heff_get_n(v_t_24181, 3, 4)));
    V v_c_24197 = (g_heff_2elsp_2elsp_2elocations_24s500939437x1628253360(heff_dup(v_wire_240), heff_dup(heff_rfield(v_x_24171, 0)), v_t_24196));
    v_c_24209 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam21, 2, 3, (V[]){v_c_24197, v_id_243, v_wire_240});
    break;
  }
  default: heff_nomatch(v_t_24172);
  }
  V f_ = v_c_24209;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam23, 1, 2, (V[]){v_z_246, v_x_24171});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam24(V self, V *args) {
  V v_x_24213 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550(v_wire_240, v_id_243, v_x_24213, v_z_245, v_z_246));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam25(V self, V *args) {
  V v_x_24216 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24217 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str67), NTAG(TAG_Nil)});
  HeffT2 v_t_24218 = (g_json_2eat_24cpr(v_t_24217, v_p_244));
  V v_t_24229;
  {
    V v_field_24220 = v_t_24218.f[1];
    int64_t v_tag_24219 = ((int64_t)v_t_24218.f[0]);
    if ((v_tag_24219 == ((int64_t)0ULL))) {
      V v_it1_24222 = v_field_24220;
      switch (heff_tag_of(v_it1_24222)) {
      case TAG_JNull: {
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str68);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24222, 0ULL, 1);
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str69);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24222, 0ULL, 1);
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str70);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24222, 0ULL, 1);
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str71);
        break;
      }
      case TAG_JString: {
        V v_s_24226 = heff_field(v_it1_24222, 0);
        heff_take_n(v_it1_24222, 1ULL, 1);
        v_t_24229 = v_s_24226;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24222, 0ULL, 1);
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str72);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24222, 0ULL, 1);
        v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str73);
        break;
      }
      default: heff_nomatch(v_it1_24222);
      }
    } else {
      heff_drop(v_field_24220);
      v_t_24229 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str74);
    }
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s2075616163x1355414730(v_wire_240, v_id_243, v_t_24229, v_x_24216, v_z_245, v_z_246));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam29(V self, V *args) {
  V v_x_24248 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24234 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24248);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24234, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam28(V self, V *args) {
  V v_x_24238 = args[0];
  V v_x_24236 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_x_24234 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24239 = (g_prelude_2e_2b_2b(v_x_24238, v_x_24236));
  V v_result_24240 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24239});
  V v_t_24241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str77), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str78)})});
  V v_t_24242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str79), v_result_24240}), NTAG(TAG_Nil)});
  V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str80), v_id_243}), v_t_24242});
  V v_t_24244 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24241, v_t_24243})});
  V v_t_24245 = ({ V a_0 = v_t_24244; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24244, 1); r_; });
  V v_t_24246 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24245, NTAG(TAG_MkUnit)});
  V v_t_24247 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24246}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24247, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam29, 1, 2, (V[]){v_z_246, v_x_24234})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam27(V self, V *args) {
  V v_x_24236 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_x_24234 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_24237 = (g_heff_2elsp_2elsp_2eclaimFixes_24s1925768017x2081281207(heff_dup(v_wire_240), heff_dup(heff_rfield(v_x_24234, 0)), v_p_244));
  V f_ = v_c_24237;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam28, 1, 6, (V[]){v_x_24236, v_id_243, v_wire_240, v_z_245, v_z_246, v_x_24234});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam26(V self, V *args) {
  V v_x_24234 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24235 = (g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823(heff_dup(v_wire_240), heff_dup(v_x_24234), heff_dup(v_p_244)));
  V f_ = v_c_24235;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam27, 1, 6, (V[]){v_wire_240, v_x_24234, v_p_244, v_z_245, v_id_243, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam31(V self, V *args) {
  V v_x_24259 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24259);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam30(V self, V *args) {
  V v_x_24251 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24252 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str82), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str83)})});
  V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str84), v_x_24251}), NTAG(TAG_Nil)});
  V v_t_24254 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_str85), v_id_243}), v_t_24253});
  V v_t_24255 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24252, v_t_24254})});
  V v_t_24256 = ({ V a_0 = v_t_24255; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24255, 1); r_; });
  V v_t_24257 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24256, NTAG(TAG_MkUnit)});
  V v_t_24258 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_24257}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24258, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam31, 1, 2, (V[]){v_z_246, v_st_241})));
}
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_lam32(V self, V *args) {
  V v_x_24261 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24261);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}