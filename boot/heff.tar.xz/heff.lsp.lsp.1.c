// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_cut 308412
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_error 298143266
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1009044490x378628932(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1009044490x378628932_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1009044490x378628932_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542_clo;
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclaimable(V);
V g_heff_2elsp_2elsp_2eclaimable_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimable_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2edeclLine(V);
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclLine_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_clo;
V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(V, V, V);
V g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_clo;
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2esplitAction(V, V, V);
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitAction_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308(V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s1645707018x558573062(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s1645707018x558573062_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s1645707018x558573062_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
HeffT2 g_heff_2elsp_2esplit_2esplit_24cpr(V, V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl(V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotInDecl_clo;
HeffT2 g_heff_2elsp_2esplit_2eusedType_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s250366202x1057933814_24cpr(V, V, V);
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
V g_list_2efoldl_24f1518670704x517758217(V, V, V, V, V);
V g_list_2efoldl_24f1518670704x517758217_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1518670704x517758217_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1498116261x2030182253(V, V);
V g_list_2ekeepIf_24s1498116261x2030182253_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1498116261x2030182253_clo;
V g_list_2ekeepIf_24s1592706127x1457322737(V, V);
V g_list_2ekeepIf_24s1592706127x1457322737_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1592706127x1457322737_clo;
V g_list_2ekeepIf_24s677751599x1843430141(V, V);
V g_list_2ekeepIf_24s677751599x1843430141_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s677751599x1843430141_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_entry, 2, 0};

V g_heff_2elsp_2elsp_2elinesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_src_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_245 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_245 = v_j_243;
    }
    V v_t_246 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_245, 4)});
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str1), v_src_240, v_i_241, 5);
    V v_t_2410;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_2410 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_2410 = v_j_248;
    }
    V v_u_2411 = (g_heff_2elsp_2elsp_2elinesFrom_24dps(v_src_240, heff_intAdd(v_t_2410, MK_INT(1LL)), heff_dup(v_cell_247)));
    heff_drop(v_u_2411);
    return v_cell_247;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewordEnd_str0, 12, " \011\015(){}[]:,=");
Clo g_heff_2elsp_2elsp_2ewordEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewordEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewordEnd(V v_l_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_l_240, 0), heff_dup(v_i_241))) {
    return v_i_241;
  } else {
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    if (heff_intLe_c(MK_INT(0LL), heff_strFind(v_t_243, ((V)&g_heff_2elsp_2elsp_2ewordEnd_str0), MK_INT(0LL)))) {
      return v_i_241;
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_l_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ewordEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str0, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str1, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str2, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str5, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str6, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str7, 4, "data");

HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_242 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_241, 6);
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str2), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str4), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str6), v_t_245})});
  V v_t_247 = ({ V a_0 = v_w_242; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str7), v_t_246}); V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, b_1)); heff_drop(v_w_242); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_249 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_248));
    V v_x_2410 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_249));
    V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_y_2412 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2411));
    if (heff_intLt_c(v_y_2412, v_x_2410)) {
      V v_t_2414 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_s_2415 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2414));
      V v_t_2416 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2417 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2416));
      V v_e_2418 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_2417));
      return ((HeffT2){{v_s_2415, v_e_2418}});
    } else {
      V v_y_2419 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_f_2421;
      if (heff_intLe_c_lent(MK_INT(1LL), v_y_2419, 1)) {
        v_f_2421 = v_y_2419;
      } else {
        heff_drop(v_y_2419);
        v_f_2421 = MK_INT(1LL);
      }
      return ((HeffT2){{MK_INT(0LL), v_f_2421}});
    }
  } else {
    heff_drop(v_t_247);
    V v_y_2422 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_f_2424;
    if (heff_intLe_c_lent(MK_INT(1LL), v_y_2422, 1)) {
      v_f_2424 = v_y_2422;
    } else {
      heff_drop(v_y_2422);
      v_f_2424 = MK_INT(1LL);
    }
    return ((HeffT2){{MK_INT(0LL), v_f_2424}});
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str0, 6, "infixr");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str1, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str2, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str5, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str6, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str7, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeyOf_str9, 1, " ");
Clo g_heff_2elsp_2elsp_2ekeyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeyOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeyOf(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_242 = (g_heff_2elsp_2elsp_2enamedIn(v_l_240));
  V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_get_n(v_t_241, 0, 2), heff_get_n(v_t_242, 1, 2));
  V v_t_244 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_245 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_244, 6);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str2), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str4), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str6), v_t_248})});
  V v_t_2410 = ({ V a_0 = v_w_245; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeyOf_str7), v_t_249}); V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, b_1)); heff_drop(v_w_245); heff_drop(b_1); r_; });
  V v_t_2412;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    v_t_2412 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_2411, 6);
  } else {
    heff_drop(v_t_2410);
    v_t_2412 = ((V)&g_heff_2elsp_2elsp_2ekeyOf_str8);
  }
  return heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ekeyOf_str9), v_t_2412));
}
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ekeyOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str2, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclLine_str3, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclLine_entry, 1, 0};

V g_heff_2elsp_2elsp_2edeclLine(V v_l_240) {
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_240, 0))) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_240, MK_INT(0LL), 2)) == ((int64_t)13ULL)) ? 0 : (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclLine_str0)) ? 0 : (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclLine_str1)) ? 0 : ({ V v_t_247 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL))); int c_ = (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_247, 2), ((V)&g_heff_2elsp_2elsp_2edeclLine_str2)) ? 0 : ({ V v_t_249 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL))); int c_ = !heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_249, 2), ((V)&g_heff_2elsp_2elsp_2edeclLine_str3)); heff_drop(v_t_249); c_; })); heff_drop(v_t_247); c_; }))))))));
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2edeclLine(a0); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s677751599x1843430141(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s1592706127x1457322737(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str0, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str2, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str3, 4, "name");
Clo g_heff_2elsp_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_m_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_m_241, 1)});
  V v_t_244 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_dup(heff_rfield(v_m_241, 2))));
  V v_t_245 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_get_n(v_m_241, 2, 3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str0), v_t_245}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str1), v_t_244}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str2), v_t_243}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str3), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2echildJson(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_243 = heff_take_field(v_target_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get_n(v_target_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength(v_t_246)) - heff_unbox_word(v_t_247));
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), heff_box_word(v_t_248)), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_target_242, 3);
    V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2413));
    V v_t_2415 = (g_list_2efoldl_24f1518670704x517758217(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2416 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(heff_box_word(v_t_2414), v_t_2415));
    V v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2417));
    V v_t_2419 = (g_list_2efoldl_24f1518670704x517758217(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_t_2420 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(heff_box_word(v_t_2418), v_t_2419));
    V v_e_2421 = heff_intAdd(v_t_2420, heff_strLength(v_new_241));
    V v_t_2422 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
    V v_t_2423 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2416, v_e_2421})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2422, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str0, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str1, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str3, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_2417;
  if (heff_intLt_c_lent(v_errorsBefore_243, v_errorsAfter_244, 0)) {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str0), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str1)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str2), heff_strAppend(v_new_242, v_t_248));
    V v_t_2410 = heff_strAppend(heff_get_n(v_t_241, 2, 4), v_t_249);
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str3), v_t_2410)});
  } else {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_2411 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2412 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_245, v_t_2411, v_new_242));
    V v_x_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_y_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_241, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_x_2413, v_y_2414)) {
      heff_drop(v_new_242);
      v_t_2417 = NTAG(TAG_Nothing);
    } else {
      V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str5)));
      v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_240, 0, 2), v_t_2417});
}
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_243, 1))}));
    V v_t_246 = (g_list_2eany(v_t_245, v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
      V v_u_249 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_248, v_rest_244, heff_dup(v_cell_247)));
      heff_drop(v_u_249);
      return v_cell_247;
    } else {
      heff_drop(v_t_246);
      V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
        V v_u_2415 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2414, v_rest_244, heff_dup(v_cell_2413)));
        heff_drop(v_u_2415);
        return v_cell_2413;
      } else {
        heff_drop_rec(v_c_243, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2412);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2410}));
  return ({ V a_0 = v_t_2411; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str1, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str5, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str7, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str8, 5, "title");
Clo g_heff_2elsp_2elsp_2esplitAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitAction_entry, 3, 0};

V g_heff_2elsp_2elsp_2esplitAction(V v_uri_240, V v_src_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str1)})});
  V v_t_245 = heff_take_field(v_x_242, 1);
  V v_t_246 = heff_take_field(v_x_242, 2);
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_t_245)));
  V v_t_249;
  if (heff_intLe_c_lent(v_t_245, v_t_246, 0)) {
    heff_drop(v_t_245);
    v_t_249 = v_t_246;
  } else {
    heff_drop(v_t_246);
    v_t_249 = v_t_245;
  }
  V v_t_2410 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str2), v_t_2410}), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str3), v_t_247}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 3, 4)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str5), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str8), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2423})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2esplitAction(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimable_str0, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimable_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eclaimable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimable_entry, 1, 0};

V g_heff_2elsp_2elsp_2eclaimable(V v_n_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimable_str0), heff_strAppend(heff_dup(v_n_240), ((V)&g_heff_2elsp_2elsp_2eclaimable_str1)));
  V v_t_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_t_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_x2_243 = heff_get_n(v_t_242, 2, 4);
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_h_244 = heff_field(v_x2_243, 0);
    V v_ru_24x2_243_24Just = heff_take_reuse_n(v_x2_243, 1ULL, 1);
    V v_t_245 = heff_take_field(v_h_244, 0);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_n_240);
      heff_drop_rec(v_h_244, 5);
      heff_drop_cell(v_ru_24x2_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_t_247 = heff_get_n(v_h_244, 4, 5);
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        if (heff_strEq_c_lent(v_m_246, v_n_240, 1)) {
          return heff_tag_at_n(v_ru_24x2_243_24Just, TAG_Just, 1, (V[]){v_n_240});
        } else {
          heff_drop(v_n_240);
          heff_drop_cell(v_ru_24x2_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_247, 0ULL, 1);
        heff_drop(v_n_240);
        heff_drop_cell(v_ru_24x2_243_24Just, 1);
        heff_drop(v_m_246);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2elsp_2elsp_2eclaimable_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimable(a[0]);
}
Clo g_heff_2elsp_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 2), v_f_241));
  V v_c_243 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 1), v_f_241));
  V v_d_244 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_st_240, 0), v_f_241));
  return ({ V rv_0 = v_d_244; V rv_1 = v_c_243; V rv_2 = v_t_242; V rr_ = heff_rec_reuse_nf(v_st_240, 120ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16320u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclosed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_str1, 0, "");
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam2, 1, 0};
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_entry, 5, 0};

V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308(V v_wire_240, V v_st_241, V v_f_242, V v_d_243, V v_why_244) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam0, 1, 3, (V[]){heff_dup(v_d_243), heff_dup(v_st_241), heff_dup(v_f_242)})})}));
  return heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam3, 2, 6, (V[]){v_t_2419, v_d_243, v_wire_240, v_st_241, v_f_242, v_why_244});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_d_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_ds_249 = ({ V a_0 = v_t_248; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_str0); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  HeffT3 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ds_249; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_249); r_; });
  V v_t_2417;
  {
    V v_field_2412 = v_t_2410.f[1];
    V v_field_2413 = v_t_2410.f[2];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2412;
      V v_x12_2416 = v_field_2413;
      heff_drop(v_x12_2416);
      v_t_2417 = heff_get_n(v_x_2415, 0, 2);
    } else {
      heff_drop(v_field_2412);
      heff_drop(v_field_2413);
      v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_d_243, 1)));
    }
  }
  return ({ V a_0 = v_st_241; V a_1 = v_f_242; V a_2 = v_d_243; V a_3 = v_t_2417; V a_4 = v_hd_246; V a_5 = v_k_247; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam0(V self, V *args) {
  V v_use_245 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_245;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam1, 2, 3, (V[]){v_d_243, v_st_241, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_why_244 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2423 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_t_2424 = ({ V a_0 = v_t_2423; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_str1); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_why_244; V a_5 = v_t_2424; V a_6 = v_x_2422; V a_7 = v_hd_2420; V a_8 = v_k_2421; V r_ = (g_heff_2elsp_2elsp_2estoppedFrom_24s1645707018x558573062(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2424); heff_drop(v_x_2422); r_; });
}
V g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_why_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_2420), heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308_lam4, 1, 7, (V[]){v_d_243, v_wire_240, v_st_241, v_f_242, v_why_244, v_hd_2420, v_k_2421})));
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_247 = v_field_245;
      V v_t_2412 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam0, 1, 3, (V[]){heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_247)})})}));
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam3, 2, 5, (V[]){v_t_2412, v_wire_240, v_st_241, v_f_242, v_d_247});
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_f_242);
      heff_drop(v_field_245);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam8, 2, 1, (V[]){v_st_241});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_d_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eanalysed_24s1009044490x378628932(v_st_241, v_f_242, v_d_247, v_hd_249, v_k_2410));
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam2(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam0(V self, V *args) {
  V v_use_248 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_d_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_248;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam1, 2, 3, (V[]){v_st_241, v_f_242, v_d_247});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_a_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_a_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_d_247 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_247, 1, 2), heff_get_n(v_x_2421, 0, 2)});
  V v_c_2425 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_st_241, 1), v_f_242, v_t_2424));
  V v_t_2426 = ({ V rv_1 = v_c_2425; V rr_ = heff_rec_reuse_nf(v_st_241, 125ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2414;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2422 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s1801093281x965699515(v_wire_240, heff_dup(heff_rfield(v_d_247, 0)), heff_dup(heff_rfield(v_x_2421, 1))));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam7, 1, 5, (V[]){v_d_247, v_x_2421, v_st_241, v_f_242, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_d_247 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_c_2420 = (g_heff_2elsp_2elsp_2estoppedAt_24s112382957x1740861308(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_f_242), heff_dup(v_d_247), v_why_2416));
    break;
  }
  case TAG_Right: {
    V v_a_2417 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_c_2420 = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam5, 2, 1, (V[]){v_a_2417});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam6, 1, 6, (V[]){v_wire_240, v_d_247, v_hd_2413, v_st_241, v_f_242, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_d_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam4, 1, 6, (V[]){v_wire_240, v_st_241, v_f_242, v_d_247, v_hd_2413, v_k_2414})));
}
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_lam8(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1773879688x1765563164_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str4, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str6, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str7, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str8, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str10, 21, "` is not written here");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str11, 1, "`");
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342(V v_wire_240, V v_id_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_tg_242, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str1)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str2), NTAG(TAG_JNull)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str3), v_id_241}), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})});
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
    V v_t_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2412}));
    return (g_co_2eop_24s495635622x733177935(v_t_2413, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam0, 1, 2, (V[]){v_z_244, v_tg_242})));
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(heff_rfield(v_t_2415, 2)), heff_dup(heff_rfield(v_t_2415, 2))));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_2415, 4);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_why_2420 = v_field_2418;
        V v_c_2421 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2420));
        return heff_tail(v_c_2421, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam1, 1, 2, (V[]){v_z_244, v_tg_242})});
      } else {
        heff_drop(v_field_2418);
        HeffT2 v_t_2423 = (g_list_2efind_24s250366202x1057933814_24cpr(heff_dup(v_t_2415), heff_dup(heff_rfield(v_tg_242, 1)), heff_dup(heff_rfield(v_t_2415, 3))));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_o_2427 = v_field_2425;
            V v_t_2428 = ({ V b_0 = heff_take_field(v_o_2427, 1); V a_1 = heff_get_n(v_o_2427, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2429 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2415, 2, 4)});
            V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str4), v_t_2429}), NTAG(TAG_Nil)});
            V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str5), v_t_2428}), v_t_2430});
            V v_result_2432 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2431});
            V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str7)})});
            V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str8), v_result_2432}), NTAG(TAG_Nil)});
            V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str9), v_id_241}), v_t_2434});
            V v_t_2436 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2435})});
            V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2436, 1); r_; });
            V v_t_2438 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
            V v_t_2439 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2438}));
            return (g_co_2eop_24s495635622x733177935(v_t_2439, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam2, 1, 2, (V[]){v_z_244, v_tg_242})));
          } else {
            heff_drop_cell(v_ru_24t_245_24Just, 1);
            heff_drop(v_field_2425);
            V v_t_2441 = heff_strAppend(heff_get_n(v_t_2415, 2, 4), ((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str10));
            V v_c_2442 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_241, MK_INT(-32803LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_str11), v_t_2441)));
            return heff_tail(v_c_2442, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam3, 1, 2, (V[]){v_z_244, v_tg_242})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1944984971x1062838342_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str7, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str8, 2, "id");
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992(V v_wire_240, V v_id_241, V v_new_242, V v_tg_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_tg_243, 2));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_new_242);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str1)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str2), NTAG(TAG_JNull)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str3), v_id_241}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_t_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2413}));
    return (g_co_2eop_24s495635622x733177935(v_t_2414, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam0, 1, 2, (V[]){v_z_245, v_tg_243})));
  }
  case TAG_Just: {
    V v_t_2416 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2416, 1)), heff_dup(heff_rfield(v_t_2416, 2)), heff_dup(v_new_242)));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        heff_drop(v_new_242);
        heff_drop_rec(v_t_2416, 4);
        V v_why_2421 = v_field_2419;
        V v_c_2422 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2421));
        return heff_tail(v_c_2422, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam1, 1, 2, (V[]){v_z_245, v_tg_243})});
      } else {
        heff_drop(v_field_2419);
        V v_c_2424 = (g_heff_2elsp_2elsp_2erenameChecked_24s551548004x1136302032(heff_dup(v_wire_240), heff_get_n(v_tg_243, 0, 3), heff_dup(v_t_2416), heff_dup(v_new_242)));
        return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam2, 1, 6, (V[]){v_t_2416, v_wire_240, v_new_242, v_z_244, v_id_241, v_z_245})});
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_tg_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_tg_243, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_tg_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_tg_243, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam3(V self, V *args) {
  V v_p_2435 = args[0];
  V v_os_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2436 = (g_list_2ekeepIf_24s1498116261x2030182253(v_p_2435, v_os_2432));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2435, v_os_2436});
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2453;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 2);
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_z_245;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str5)})});
  V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_x_2439})});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_str8), v_id_241}), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2445})});
  V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2446, 1); r_; });
  V v_t_2448 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2448}));
  return (g_co_2eop_24s495635622x733177935(v_t_2449, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam5, 1, 2, (V[]){v_x_2425, v_z_245})));
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2456);
  V v_t_2459;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 2);
    v_t_2459 = v_x_2457;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_z_245;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_t_2416 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_id_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_dup(heff_field(v_x_2425, 1));
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  switch (heff_tag_of(v_t_2428)) {
  case TAG_Nothing: {
    V v_t_2431;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_dup(heff_field(v_x_2425, 0));
      v_t_2431 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    V v_os_2432 = heff_get_n(v_t_2416, 3, 4);
    V v_t_2433 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2432)));
    V v_t_2434 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2433));
    V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam3, 1, 1, (V[]){v_os_2432}), v_t_2434));
    V v_c_2438 = (g_heff_2elsp_2elsp_2echangesOf_24s301345439x1796186542(heff_dup(v_wire_240), v_t_2431, v_new_242, v_t_2437));
    V f_ = v_c_2438;
    heff_room[0] = heff_dup(v_z_244);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam4, 1, 5, (V[]){v_id_241, v_wire_240, v_z_244, v_x_2425, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2454 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    heff_drop_rec(v_t_2416, 4);
    heff_drop(v_new_242);
    V v_c_2455 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2454));
    V f_ = v_c_2455;
    heff_room[0] = v_z_244;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s24413291x834464992_lam6, 1, 2, (V[]){v_x_2425, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_entry, 9, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592(V v_wire_240, V v_st_241, V v_f_242, V v_uri_243, V v_program_244, V v_c_245, V v_off_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam0, 1, 2, (V[]){heff_dup(v_c_245), v_off_246}), heff_dup(heff_rfield(v_c_245, 4))));
  HeffT2 v_t_2411 = (g_heff_2elsp_2esplit_2efirstJust_24cpr(v_t_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_s_2415 = v_field_2413;
      HeffT2 v_t_2416 = (g_heff_2elsp_2esplit_2eusedType_24cpr(heff_dup(v_c_245), heff_dup(v_s_2415)));
      V v_c_2423;
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          heff_drop(v_wire_240);
          heff_drop(v_st_241);
          heff_drop(v_f_242);
          V v_t_2420 = v_field_2418;
          v_c_2423 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam1, 2, 1, (V[]){v_t_2420});
        } else {
          heff_drop(v_field_2418);
          v_c_2423 = (g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661(v_wire_240, v_st_241, v_f_242, heff_dup(v_program_244), heff_dup(v_c_245), heff_dup(v_s_2415)));
        }
      }
      return heff_tail(v_c_2423, 2, (V[]){v_z_247, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam2, 1, 5, (V[]){v_program_244, v_c_245, v_s_2415, v_uri_243, v_z_248})});
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_st_241);
      heff_drop(v_f_242);
      heff_drop(v_uri_243);
      heff_drop(v_program_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_z_247);
      heff_drop(v_field_2413);
      return heff_tail(v_z_248, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam0(V self, V *args) {
  V v_d_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_off_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 14); V a_1 = v_off_246; V a_2 = v_d_249; V r_ = (g_heff_2elsp_2esplit_2espotInDecl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1410539186x122267592_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_program_244 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_s_2415 = heff_env(self)[2];
  V v_uri_243 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2432;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_program_244);
    heff_drop_rec(v_c_245, 14);
    heff_drop(v_s_2415);
    heff_drop(v_uri_243);
    v_x_2432 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    HeffT2 v_t_2426 = ({ V a_0 = v_program_244; V a_1 = heff_dup(v_c_245); V a_2 = v_s_2415; V a_3 = v_t_2425; HeffT2 r_ = (g_heff_2elsp_2esplit_2esplit_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_x_2430 = v_field_2428;
        V v_t_2431 = ({ V a_0 = v_uri_243; V b_1 = heff_get_n(v_c_245, 3, 14); V a_2 = v_x_2430; V r_ = (g_heff_2elsp_2elsp_2esplitAction(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_c_245, 14);
        heff_drop(v_uri_243);
        heff_drop(v_field_2428);
        v_x_2432 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V f_ = v_z_248;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str4, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str5, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str6, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_entry, 5, 0};

V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137(V v_wire_240, V v_st_241, V v_msg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_246 = (g_json_2eat_24cpr(v_t_245, heff_dup(v_msg_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_JNull: {
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JString: {
        V v_s_2414 = heff_field(v_it1_2410, 0);
        V v_ru_24it1_2410_24JString = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_msg_242)) {
        case TAG_JNull: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2420 = heff_dup(heff_field(v_msg_242, 0));
          HeffT2 v_t_2421 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str1); V a_1 = v_fs_2420; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_p_2425 = v_field_2423;
              V v_t_2428;
              switch (heff_tag_of(v_p_2425)) {
              case TAG_MkPair: {
                V v_y_2427 = heff_field(v_p_2425, 1);
                heff_take_n(v_p_2425, 2ULL, 2);
                v_t_2428 = v_y_2427;
                break;
              }
              default: heff_nomatch(v_p_2425);
              }
              v_t_2429 = heff_tag_at_n(v_ru_24it1_2410_24JString, TAG_Just, 1, (V[]){v_t_2428});
            } else {
              heff_drop_cell(v_ru_24it1_2410_24JString, 1);
              heff_drop(v_field_2423);
              v_t_2429 = NTAG(TAG_Nothing);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_242);
        }
        switch (heff_tag_of(v_t_2429)) {
        case TAG_Nothing: {
          V v_t_2443;
          switch (heff_tag_of(v_msg_242)) {
          case TAG_JNull: {
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JObject: {
            V v_fs_2435 = heff_field(v_msg_242, 0);
            heff_take_n(v_msg_242, 1ULL, 1);
            HeffT2 v_t_2436 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str2); V a_1 = v_fs_2435; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2438 = v_t_2436.f[1];
              int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
              if ((v_tag_2437 == ((int64_t)0ULL))) {
                V v_p_2440 = v_field_2438;
                switch (heff_tag_of(v_p_2440)) {
                case TAG_MkPair: {
                  V v_y_2442 = heff_field(v_p_2440, 1);
                  heff_take_n(v_p_2440, 2ULL, 2);
                  v_t_2443 = v_y_2442;
                  break;
                }
                default: heff_nomatch(v_p_2440);
                }
              } else {
                heff_drop(v_field_2438);
                v_t_2443 = NTAG(TAG_JNull);
              }
            }
            break;
          }
          default: heff_nomatch(v_msg_242);
          }
          return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_s_2414; V a_3 = v_t_2443; V a_4 = v_z_243; V a_5 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_s_2414); r_; });
        }
        case TAG_Just: {
          V v_id_2444 = heff_field(v_t_2429, 0);
          heff_take_n(v_t_2429, 1ULL, 1);
          V v_t_2445 = heff_dup(heff_rfield(v_st_241, 5));
          if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
            heff_drop(v_t_2445);
            if (heff_strEq_c_lent(v_s_2414, ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str3), 2)) {
              V v_t_2460;
              switch (heff_tag_of(v_msg_242)) {
              case TAG_JNull: {
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JObject: {
                V v_fs_2452 = heff_field(v_msg_242, 0);
                heff_take_n(v_msg_242, 1ULL, 1);
                HeffT2 v_t_2453 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str4); V a_1 = v_fs_2452; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                {
                  V v_field_2455 = v_t_2453.f[1];
                  int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                  if ((v_tag_2454 == ((int64_t)0ULL))) {
                    V v_p_2457 = v_field_2455;
                    switch (heff_tag_of(v_p_2457)) {
                    case TAG_MkPair: {
                      V v_y_2459 = heff_field(v_p_2457, 1);
                      heff_take_n(v_p_2457, 2ULL, 2);
                      v_t_2460 = v_y_2459;
                      break;
                    }
                    default: heff_nomatch(v_p_2457);
                    }
                  } else {
                    heff_drop(v_field_2455);
                    v_t_2460 = NTAG(TAG_JNull);
                  }
                }
                break;
              }
              default: heff_nomatch(v_msg_242);
              }
              return (g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(v_wire_240, v_st_241, v_s_2414, v_id_2444, v_t_2460, v_z_243, v_z_244));
            } else {
              heff_drop(v_msg_242);
              heff_drop(v_s_2414);
              V v_c_2461 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(v_wire_240, v_id_2444, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str5)));
              return heff_tail(v_c_2461, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_lam0, 1, 2, (V[]){v_z_244, v_st_241})});
            }
          } else {
            heff_drop(v_t_2445);
            V v_t_2476;
            switch (heff_tag_of(v_msg_242)) {
            case TAG_JNull: {
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JObject: {
              V v_fs_2468 = heff_field(v_msg_242, 0);
              heff_take_n(v_msg_242, 1ULL, 1);
              HeffT2 v_t_2469 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_str6); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2471 = v_t_2469.f[1];
                int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                if ((v_tag_2470 == ((int64_t)0ULL))) {
                  V v_p_2473 = v_field_2471;
                  switch (heff_tag_of(v_p_2473)) {
                  case TAG_MkPair: {
                    V v_y_2475 = heff_field(v_p_2473, 1);
                    heff_take_n(v_p_2473, 2ULL, 2);
                    v_t_2476 = v_y_2475;
                    break;
                  }
                  default: heff_nomatch(v_p_2473);
                  }
                } else {
                  heff_drop(v_field_2471);
                  v_t_2476 = NTAG(TAG_JNull);
                }
              }
              break;
            }
            default: heff_nomatch(v_msg_242);
            }
            return (g_heff_2elsp_2elsp_2erequest_24s13897184x1544077881(v_wire_240, v_st_241, v_s_2414, v_id_2444, v_t_2476, v_z_243, v_z_244));
          }
        }
        default: return heff_nomatch(v_t_2429);
        }
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_msg_242);
      heff_drop(v_z_243);
      heff_drop(v_field_248);
      return heff_tail(v_z_244, 1, (V[]){v_st_241});
    }
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_lam0(V self, V *args) {
  V v_x_2462 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V f_ = v_z_244;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}