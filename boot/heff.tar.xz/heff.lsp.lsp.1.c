// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Send 26077
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_current 1358797751
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_lib 316671
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_clo;
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(V, V, V);
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_clo;
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1032636598x1013662416(V);
V g_list_2eany_24s1032636598x1013662416_entry(V self, V *a);
extern Clo g_list_2eany_24s1032636598x1013662416_clo;
V g_list_2eany_24s1795474228x706402294(V, V);
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a);
extern Clo g_list_2eany_24s1795474228x706402294_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s446714453x706785629_24cpr(V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s735270044x1288664053(V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_entry, 2, 0};

V g_heff_2elsp_2elsp_2elinesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_src_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_d_242 = heff_strLength_lent(v_src_240, 0);
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_244;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_244 = v_d_242;
    } else {
      heff_drop(v_d_242);
      v_t_244 = v_j_243;
    }
    V v_t_245 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_244, 4)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_d_247 = heff_strLength_lent(v_src_240, 0);
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str1), v_src_240, v_i_241, 5);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_249 = v_d_247;
    } else {
      heff_drop(v_d_247);
      v_t_249 = v_j_248;
    }
    V v_u_2410 = (g_heff_2elsp_2elsp_2elinesFrom_24dps(v_src_240, heff_intAdd(v_t_249, MK_INT(1LL)), heff_dup(v_cell_246)));
    heff_drop(v_u_2410);
    return v_cell_246;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str7, 6, "infixr");

HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_242 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_241, 6);
  if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str0), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str1), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str2), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str3), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str4), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str5), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str6), v_w_242, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str7), v_w_242, 1))))))))) {
    heff_drop(v_w_242);
    V v_t_243 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_244 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_243));
    V v_x_245 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_244));
    V v_t_246 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_y_247 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_246));
    if (heff_intLt_c(v_y_247, v_x_245)) {
      V v_t_248 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_s_249 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_248));
      V v_t_2410 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2411 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2410));
      V v_e_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_2411));
      return ((HeffT2){{v_s_249, v_e_2412}});
    } else {
      V v_y_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_f_2414;
      if (heff_intLe_c_lent(MK_INT(1LL), v_y_2413, 1)) {
        v_f_2414 = v_y_2413;
      } else {
        heff_drop(v_y_2413);
        v_f_2414 = MK_INT(1LL);
      }
      return ((HeffT2){{MK_INT(0LL), v_f_2414}});
    }
  } else {
    heff_drop(v_w_242);
    V v_y_2415 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_f_2416;
    if (heff_intLe_c_lent(MK_INT(1LL), v_y_2415, 1)) {
      v_f_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_f_2416 = MK_INT(1LL);
    }
    return ((HeffT2){{MK_INT(0LL), v_f_2416}});
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str0, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str1, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str2, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str3, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str4, 59, "heff could not finish checking this file: it stopped here (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str5, 30, "); what follows is not checked");
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_entry, 9, 0};

V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385(V v_e_240, V v_st_241, V v_f_242, V v_d_243, V v_why_244, V v_ds_245, V v_x6_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Left: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_f_242);
    heff_drop(v_z_247);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str0), v_why_244), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str1));
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2410, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2412 = ({ V b_0 = heff_get_n(v_d_243, 1, 2); V a_1 = v_t_2411; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
    V v_diags_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
    V v_t_2414 = heff_rec_n(2, shape_program__diags, (V[]){NTAG(TAG_Nil), v_diags_2413});
    return heff_tail(v_z_248, 1, (V[]){v_t_2414});
  }
  case TAG_Right: {
    V v_a_2415 = heff_field(v_x6_246, 0);
    V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ds_245));
    V v_c_2417 = (g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(v_e_240, v_st_241, v_f_242, heff_dup(v_d_243), v_ds_245, MK_INT(0LL), v_t_2416, heff_dup(v_a_2415)));
    return heff_tail(v_c_2417, 2, (V[]){v_z_247, heff_clo_n(g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_lam0, 1, 3, (V[]){v_d_243, v_why_244, v_z_248})});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7], a[8]); heff_drop(a5); heff_drop(a6); return r;
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_why_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_2419 = heff_get_n(v_d_243, 1, 2);
  V v_why_2420 = v_why_244;
  V v_s_2421 = v_x_2418;
  V v_analysis_2422 = heff_take_field(v_s_2421, 0);
  V v_at_2423 = heff_get_n(v_s_2421, 1, 2);
  V v_program_2424 = heff_take_field(v_analysis_2422, 0);
  V v_t_2430;
  switch (heff_tag_of(v_at_2423)) {
  case TAG_Nothing: {
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str2), v_why_2420), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str3));
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2425, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    v_t_2430 = ({ V a_0 = v_src_2419; V a_1 = v_t_2426; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(a_0, a_1)); heff_drop(v_src_2419); r_; });
    break;
  }
  case TAG_Just: {
    V v_t_2427 = heff_field(v_at_2423, 0);
    V v_ru_24at_2423_24Just = heff_take_reuse_n(v_at_2423, 1ULL, 1);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str4), v_why_2420), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_str5));
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2428, heff_get_n(v_t_2427, 1, 2), NTAG(TAG_Nothing)});
    v_t_2430 = ({ V a_0 = v_ru_24at_2423_24Just; V a_1 = v_src_2419; V a_2 = v_t_2429; V r_ = (g_heff_2elsp_2elsp_2ediagnostic_24tok1(a_0, a_1, a_2)); heff_drop(v_src_2419); r_; });
    break;
  }
  default: heff_nomatch(v_at_2423);
  }
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_diags_2432 = (g_prelude_2e_2b_2b(heff_get_n(v_analysis_2422, 1, 2), v_t_2431));
  V v_x_2433 = heff_rec_n(2, shape_program__diags, (V[]){v_program_2424, v_diags_2432});
  V f_ = v_z_248;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(V v_e_240, V v_st_241, V v_f_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_dup(heff_rfield(v_st_241, 2)), v_f_242));
  V v_project_244 = heff_dup(heff_rfield(v_st_241, 3));
  V v_watch_245 = heff_dup(heff_rfield(v_st_241, 4));
  V v_shutdown_246 = heff_dup(heff_rfield(v_st_241, 5));
  V v_lib_247 = heff_dup(heff_rfield(v_st_241, 6));
  V v_t_248 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_241, 0)), heff_dup(heff_rfield(v_st_241, 1)), v_t_243, v_project_244, v_watch_245, v_shutdown_246, v_lib_247});
  V v_c_249 = (g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(heff_dup(v_e_240), v_t_248, heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam0, 2, 4, (V[]){v_c_249, v_st_241, v_f_242, v_e_240});
}
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam2(V self, V *args) {
  V v_p_2414 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_dup(heff_field(v_p_2414, 0));
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  if (!heff_strEq_c_lent(v_t_2417, v_f_242, 0)) {
    heff_drop(v_t_2417);
    V v_t_2420;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_y_2419 = heff_field(v_p_2414, 1);
      heff_take_n(v_p_2414, 2ULL, 2);
      v_t_2420 = v_y_2419;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    return ({ V a_0 = v_f_242; V b_1 = heff_get_n(v_t_2420, 1, 2); V r_ = (g_list_2eany_24s1795474228x706402294(a_0, b_1)); heff_drop(v_f_242); heff_drop(b_1); r_; });
  } else {
    heff_drop(v_p_2414);
    heff_drop(v_f_242);
    heff_drop(v_t_2417);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = ({ V b_0 = heff_get_n(v_st_241, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam2, 1, 1, (V[]){v_f_242}), v_t_2413));
  V v_t_2422 = (g_list_2emap_24s1415906091x1371825187(v_t_2421));
  return ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_t_2422; V a_3 = v_hd_2410; V a_4 = v_k_2411; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2422); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287_lam1, 1, 5, (V[]){v_st_241, v_f_242, v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str3, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str4, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str5, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str6, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str7, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str8, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str22, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str23, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str24, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str25, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str26, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str27, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str28, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str29, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str30, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam2, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam4, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_entry, 6, 0};

V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967(V v_e_240, V v_st_241, V v_m_242, V v_p_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), heff_dup(v_p_243)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam0, 1, 6, (V[]){heff_dup(v_m_242), v_st_241, v_e_240, v_z_244, v_z_245, v_p_243})});
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enotified_24s738584401x754960967(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V f_ = v_z_245;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam2(V self, V *args) {
  V v_n_24104 = args[0];
  return v_n_24104;
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam3(V self, V *args) {
  V v_x_24110 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  V v_text_24103 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24111 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_st_241, 2)), heff_dup(v_f_2426), heff_intAdd(v_x_24110, MK_INT(200LL))));
  V v_st_24112 = v_st_241;
  V v_f_24113 = v_f_2426;
  V v_text_24114 = v_text_24103;
  HeffT2 v_t_24115 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24112, 0), v_f_24113));
  V v_s_24126;
  {
    V v_field_24117 = v_t_24115.f[1];
    int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
    if ((v_tag_24116 == ((int64_t)0ULL))) {
      V v_d_24118 = v_field_24117;
      V v_t_24119 = ({ V rv_1 = v_text_24114; V rr_ = heff_rec_reuse_nf(v_d_24118, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_24120 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_24112, 0), v_f_24113, v_t_24119));
      V v_due_24121 = heff_take_field(v_st_24112, 2);
      V v_project_24122 = heff_take_field(v_st_24112, 3);
      V v_watch_24123 = heff_take_field(v_st_24112, 4);
      V v_shutdown_24124 = heff_take_field(v_st_24112, 5);
      V v_lib_24125 = heff_take_field(v_st_24112, 6);
      v_s_24126 = ({ V rv_0 = v_d_24120; V rv_2 = v_due_24121; V rv_3 = v_project_24122; V rv_4 = v_watch_24123; V rv_5 = v_shutdown_24124; V rv_6 = v_lib_24125; V rr_ = heff_rec_reuse_nf(v_st_24112, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(v_f_24113);
      heff_drop(v_text_24114);
      heff_drop(v_field_24117);
      v_s_24126 = v_st_24112;
    }
  }
  V v_project_24127 = heff_take_field(v_s_24126, 3);
  V v_watch_24128 = heff_take_field(v_s_24126, 4);
  V v_shutdown_24129 = heff_take_field(v_s_24126, 5);
  V v_lib_24130 = heff_take_field(v_s_24126, 6);
  V v_t_24131 = ({ V rv_2 = v_t_24111; V rv_3 = v_project_24127; V rv_4 = v_watch_24128; V rv_5 = v_shutdown_24129; V rv_6 = v_lib_24130; V rr_ = heff_rec_reuse_nf(v_s_24126, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_245;
  args[0] = v_t_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam4(V self, V *args) {
  V v_hd_24141 = args[0];
  V v_k_24142 = args[1];
  heff_drop(v_hd_24141);
  V f_ = v_k_24142;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam5(V self, V *args) {
  V v_x_24144 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24144);
  V v_st_24145 = v_st_241;
  V v_f_24146 = v_f_2426;
  V v_t_24147 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24145, 2), v_f_24146));
  V v_c_24148 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24145, 1), v_f_24146));
  V v_d_24149 = ({ V a_0 = heff_take_field(v_st_24145, 0); V a_1 = v_f_24146; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_f_24146); r_; });
  V v_project_24150 = heff_take_field(v_st_24145, 3);
  V v_watch_24151 = heff_take_field(v_st_24145, 4);
  V v_shutdown_24152 = heff_take_field(v_st_24145, 5);
  V v_x_24153 = ({ V rv_0 = v_d_24149; V rv_1 = v_c_24148; V rv_2 = v_t_24147; V rv_3 = v_project_24150; V rv_4 = v_watch_24151; V rv_5 = v_shutdown_24152; V rr_ = heff_rec_reuse_nf(v_st_24145, 64ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12288u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_z_245;
  args[0] = v_x_24153;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str0), 2)) {
    heff_drop(v_x_247);
    heff_drop(v_m_242);
    heff_drop(v_p_243);
    V v_t_248 = heff_get_n(v_st_241, 5, 7);
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(0LL);
    } else {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(1LL);
    }
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_z_244, v_z_245));
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str1), 2)) {
      heff_drop(v_x_247);
      heff_drop(v_m_242);
      heff_drop(v_p_243);
      V v_t_2415 = heff_dup(heff_rfield(v_st_241, 4));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str2); V b_1 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
        V v_a_2417 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2422, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam1, 1, 2, (V[]){v_z_245, v_st_241})));
      } else {
        heff_drop(v_e_240);
        heff_drop(v_z_244);
        heff_drop(v_t_2415);
        V f_ = v_z_245;
        args[0] = v_st_241;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str3), 2)) {
        heff_drop(v_x_247);
        heff_drop(v_m_242);
        heff_drop(v_p_243);
        V v_t_2424 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
        V v_t_2425 = (g_list_2emap_24s1415906091x1371825187(v_t_2424));
        return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_t_2425; V a_3 = v_z_244; V a_4 = v_z_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1224637613x1455865362(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2425); r_; });
      } else {
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nothing: {
          heff_drop(v_m_242);
          heff_drop(v_e_240);
          heff_drop(v_z_244);
          heff_drop(v_p_243);
          V f_ = v_z_245;
          args[0] = v_st_241;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2426 = heff_field(v_x_247, 0);
          V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str4), 2)) {
            heff_drop(v_m_242);
            heff_drop_cell(v_ru_24x_247_24Just, 1);
            V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str5), NTAG(TAG_Nil)});
            HeffT2 v_t_2428 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str6), v_t_2427}); V a_1 = heff_dup(v_p_243); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2451;
            {
              V v_field_2430 = v_t_2428.f[1];
              int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
              V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str7), NTAG(TAG_Nil)});
              HeffT2 v_t_2432 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str8), v_t_2431}); V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2434 = v_t_2432.f[1];
                int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                V v_t_2442;
                if ((v_tag_2429 == ((int64_t)0ULL))) {
                  V v_it1_2435 = v_field_2430;
                  switch (heff_tag_of(v_it1_2435)) {
                  case TAG_JNull: {
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str9);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2435, 0ULL, 1);
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str10);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2435, 0ULL, 1);
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str11);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2435, 0ULL, 1);
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str12);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2439 = heff_field(v_it1_2435, 0);
                    heff_take_n(v_it1_2435, 1ULL, 1);
                    v_t_2442 = v_s_2439;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2435, 0ULL, 1);
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str13);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2435, 0ULL, 1);
                    v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str14);
                    break;
                  }
                  default: heff_nomatch(v_it1_2435);
                  }
                } else {
                  heff_drop(v_field_2430);
                  v_t_2442 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str15);
                }
                V v_t_2450;
                if ((v_tag_2433 == ((int64_t)0ULL))) {
                  V v_it1_2443 = v_field_2434;
                  switch (heff_tag_of(v_it1_2443)) {
                  case TAG_JNull: {
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str16);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str17);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str18);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2443, 0ULL, 1);
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str19);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2447 = heff_field(v_it1_2443, 0);
                    heff_take_n(v_it1_2443, 1ULL, 1);
                    v_t_2450 = v_s_2447;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str20);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str21);
                    break;
                  }
                  default: heff_nomatch(v_it1_2443);
                  }
                } else {
                  heff_drop(v_field_2434);
                  v_t_2450 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str22);
                }
                v_t_2451 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2442, v_t_2450});
              }
            }
            V v_d_2452 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_241, 0), heff_dup(v_f_2426), v_t_2451));
            V v_due_2453 = heff_take_field(v_st_241, 2);
            V v_project_2454 = heff_take_field(v_st_241, 3);
            V v_watch_2455 = heff_take_field(v_st_241, 4);
            V v_shutdown_2456 = heff_take_field(v_st_241, 5);
            V v_lib_2457 = heff_take_field(v_st_241, 6);
            V v_t_2458 = ({ V rv_0 = v_d_2452; V rv_2 = v_due_2453; V rv_3 = v_project_2454; V rv_4 = v_watch_2455; V rv_5 = v_shutdown_2456; V rv_6 = v_lib_2457; V rr_ = heff_rec_reuse_nf(v_st_241, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
            V v_t_2459 = (g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(v_e_240, v_t_2458, v_f_2426));
            V f_ = v_t_2459;
            heff_room[0] = v_z_244;
            heff_room[1] = v_z_245;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str23), 2)) {
              heff_drop(v_m_242);
              V v_p_2460 = v_p_243;
              V v_t_24102;
              switch (heff_tag_of(v_p_2460)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_p_2460, 0ULL, 1);
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_p_2460, 0ULL, 1);
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_p_2460, 0ULL, 1);
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_p_2460, 0ULL, 1);
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_p_2460, 0ULL, 1);
                heff_drop_cell(v_ru_24x_247_24Just, 1);
                v_t_24102 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                V v_fs_2466 = heff_field(v_p_2460, 0);
                heff_take_n(v_p_2460, 1ULL, 1);
                HeffT2 v_t_2467 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str24); V a_1 = v_fs_2466; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2466); r_; });
                {
                  V v_field_2469 = v_t_2467.f[1];
                  int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                  if ((v_tag_2468 == ((int64_t)0ULL))) {
                    V v_p_2470 = v_field_2469;
                    V v_t_2473;
                    switch (heff_tag_of(v_p_2470)) {
                    case TAG_MkPair: {
                      V v_y_2472 = heff_field(v_p_2470, 1);
                      heff_take_n(v_p_2470, 2ULL, 2);
                      v_t_2473 = v_y_2472;
                      break;
                    }
                    default: heff_nomatch(v_p_2470);
                    }
                    switch (heff_tag_of(v_t_2473)) {
                    case TAG_JNull: {
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JBool: {
                      heff_take_n(v_t_2473, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JInt: {
                      heff_take_n(v_t_2473, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JFloat: {
                      heff_take_na(v_t_2473, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JString: {
                      heff_take_n(v_t_2473, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JArray: {
                      V v_xs_2478 = heff_field(v_t_2473, 0);
                      heff_take_n(v_t_2473, 1ULL, 1);
                      V v_x1_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2478));
                      switch (heff_tag_of(v_x1_2479)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x_247_24Just, 1);
                        v_t_24102 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Cons: {
                        V v_x_2480 = heff_field(v_x1_2479, 0);
                        heff_take_n(v_x1_2479, 1ULL, 2);
                        switch (heff_tag_of(v_x_2480)) {
                        case TAG_JNull: {
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JBool: {
                          heff_take_n(v_x_2480, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JInt: {
                          heff_take_n(v_x_2480, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JFloat: {
                          heff_take_na(v_x_2480, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JString: {
                          heff_take_n(v_x_2480, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JArray: {
                          heff_take_n(v_x_2480, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_247_24Just, 1);
                          v_t_24102 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JObject: {
                          V v_fs_2487 = heff_field(v_x_2480, 0);
                          heff_take_n(v_x_2480, 1ULL, 1);
                          HeffT2 v_t_2488 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str25); V a_1 = v_fs_2487; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2487); r_; });
                          {
                            V v_field_2490 = v_t_2488.f[1];
                            int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
                            if ((v_tag_2489 == ((int64_t)0ULL))) {
                              V v_p_2491 = v_field_2490;
                              V v_t_2494;
                              switch (heff_tag_of(v_p_2491)) {
                              case TAG_MkPair: {
                                V v_y_2493 = heff_field(v_p_2491, 1);
                                heff_take_n(v_p_2491, 2ULL, 2);
                                v_t_2494 = v_y_2493;
                                break;
                              }
                              default: heff_nomatch(v_p_2491);
                              }
                              switch (heff_tag_of(v_t_2494)) {
                              case TAG_JNull: {
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JBool: {
                                heff_take_n(v_t_2494, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JInt: {
                                heff_take_n(v_t_2494, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JFloat: {
                                heff_take_na(v_t_2494, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JString: {
                                V v_s_2498 = heff_field(v_t_2494, 0);
                                heff_take_n(v_t_2494, 1ULL, 1);
                                v_t_24102 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_Just, 1, (V[]){v_s_2498});
                                break;
                              }
                              case TAG_JArray: {
                                heff_take_n(v_t_2494, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JObject: {
                                heff_take_n(v_t_2494, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_247_24Just, 1);
                                v_t_24102 = NTAG(TAG_Nothing);
                                break;
                              }
                              default: heff_nomatch(v_t_2494);
                              }
                            } else {
                              heff_drop_cell(v_ru_24x_247_24Just, 1);
                              heff_drop(v_field_2490);
                              v_t_24102 = NTAG(TAG_Nothing);
                            }
                          }
                          break;
                        }
                        default: heff_nomatch(v_x_2480);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x1_2479);
                      }
                      break;
                    }
                    case TAG_JObject: {
                      heff_take_n(v_t_2473, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_247_24Just, 1);
                      v_t_24102 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_t_2473);
                    }
                  } else {
                    heff_drop_cell(v_ru_24x_247_24Just, 1);
                    heff_drop(v_field_2469);
                    v_t_24102 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_p_2460);
              }
              switch (heff_tag_of(v_t_24102)) {
              case TAG_Nothing: {
                heff_drop(v_e_240);
                heff_drop(v_z_244);
                heff_drop(v_f_2426);
                V f_ = v_z_245;
                args[0] = v_st_241;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_24103 = heff_field(v_t_24102, 0);
                V v_ru_24t_24102_24Just = heff_take_reuse_n(v_t_24102, 1ULL, 1);
                V v_t_24105 = heff_tag_at_n(v_ru_24t_24102_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam2_clo)})});
                V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
                V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
                V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
                V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
                return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam3, 1, 4, (V[]){v_st_241, v_f_2426, v_text_24103, v_z_245})));
              }
              default: return heff_nomatch(v_t_24102);
              }
            } else {
              heff_drop(v_p_243);
              heff_drop_cell(v_ru_24x_247_24Just, 1);
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str26), 2)) {
                heff_drop(v_m_242);
                V v_t_24132 = (g_heff_2elsp_2elsp_2echeckNow_24s1825647134x776689287(v_e_240, v_st_241, v_f_2426));
                V f_ = v_t_24132;
                heff_room[0] = v_z_244;
                heff_room[1] = v_z_245;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str27))) {
                  HeffT2 v_t_24133 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_f_2426));
                  V v_c_24143;
                  {
                    V v_field_24135 = v_t_24133.f[1];
                    int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                    if ((v_tag_24134 == ((int64_t)0ULL))) {
                      V v_d_24136 = v_field_24135;
                      V v_t_24137 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_d_24136, 0, 2)});
                      V v_t_24138 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
                      V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str28), v_t_24138}), NTAG(TAG_Nil)});
                      V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str29), v_t_24137}), v_t_24139});
                      v_c_24143 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(v_e_240, ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_str30), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24140})));
                    } else {
                      heff_drop(v_e_240);
                      heff_drop(v_field_24135);
                      v_c_24143 = ((V)&g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam4_clo);
                    }
                  }
                  V f_ = v_c_24143;
                  heff_room[0] = v_z_244;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s738584401x754960967_lam5, 1, 3, (V[]){v_st_241, v_f_2426, v_z_245});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_e_240);
                  heff_drop(v_z_244);
                  heff_drop(v_f_2426);
                  V f_ = v_z_245;
                  args[0] = v_st_241;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_247);
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry, 4, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(V v_e_240, V v_id_241, V v_code_242, V v_msg_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str1)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_242})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_243})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str4), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str5), v_id_241}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410})});
  V v_t_2412 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_str6); V a_1 = v_t_2411; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2411, 1); r_; });
  V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, v_t_2418});
}
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V v_e_240, V v_st_241, V v_f_242, V v_names_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), heff_dup(heff_rfield(v_st_241, 6)), heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam0, 2, 5, (V[]){v_c_244, v_st_241, v_e_240, v_f_242, v_names_243});
}
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_had_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2416; V a_1 = v_had_2414; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_n_2416); heff_drop(v_had_2414); r_; });
}
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_names_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = heff_dup(heff_rfield(v_st_241, 3));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(v_e_240, v_st_241, heff_get_n(v_x_247, 0, 6), v_f_242, v_names_243, v_hd_245, v_k_246));
  }
  case TAG_Just: {
    V v_pr_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_current_2410 = heff_take_field(v_pr_249, 3);
    V v_root_2411 = heff_take_field(v_pr_249, 0);
    V v_names_2412 = heff_take_field(v_pr_249, 1);
    V v_program_2413 = heff_get_n(v_pr_249, 2, 5);
    if ((heff_dup(v_current_2410) == NTAG(TAG_True))) {
      heff_drop(v_current_2410);
      if (heff_strEq_c(v_root_2411, heff_dup(heff_rfield(v_x_247, 0)))) {
        switch (heff_tag_of(v_names_2412)) {
        case TAG_Nothing: {
          heff_drop_rec(v_x_247, 6);
          heff_drop(v_e_240);
          heff_drop(v_f_242);
          heff_drop(v_names_243);
          heff_drop(v_hd_245);
          V f_ = v_k_246;
          args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_241, v_program_2413});
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_had_2414 = heff_field(v_names_2412, 0);
          heff_take_n(v_names_2412, 1ULL, 1);
          switch (heff_tag_of(v_names_243)) {
          case TAG_Nothing: {
            heff_drop(v_program_2413);
            heff_drop(v_had_2414);
            return (g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(v_e_240, v_st_241, heff_get_n(v_x_247, 0, 6), v_f_242, v_names_243, v_hd_245, v_k_246));
          }
          case TAG_Just: {
            V v_wanted_2415 = heff_dup(heff_field(v_names_243, 0));
            V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam2, 1, 1, (V[]){v_had_2414}); V a_1 = v_wanted_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_wanted_2415); r_; });
            if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
              heff_drop_rec(v_x_247, 6);
              heff_drop(v_e_240);
              heff_drop(v_f_242);
              heff_drop_tag(v_names_243, 1);
              heff_drop(v_hd_245);
              heff_drop(v_t_2417);
              V f_ = v_k_246;
              args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_241, v_program_2413});
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              heff_drop(v_program_2413);
              heff_drop(v_t_2417);
              return (g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(v_e_240, v_st_241, heff_get_n(v_x_247, 0, 6), v_f_242, v_names_243, v_hd_245, v_k_246));
            }
          }
          default: return heff_nomatch(v_names_243);
          }
        }
        default: return heff_nomatch(v_names_2412);
        }
      } else {
        heff_drop(v_names_2412);
        heff_drop(v_program_2413);
        return (g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(v_e_240, v_st_241, heff_get_n(v_x_247, 0, 6), v_f_242, v_names_243, v_hd_245, v_k_246));
      }
    } else {
      heff_drop(v_current_2410);
      heff_drop(v_root_2411);
      heff_drop(v_names_2412);
      heff_drop(v_program_2413);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(v_e_240, v_st_241, heff_get_n(v_x_247, 0, 6), v_f_242, v_names_243, v_hd_245, v_k_246));
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_names_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_lam1, 1, 6, (V[]){v_st_241, v_e_240, v_f_242, v_names_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str19, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str20, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str21, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str22, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str23, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str24, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str25, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str26, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str27, 21, "` is not written here");
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084(V v_e_240, V v_id_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_target_245 = heff_take_field(v_tg_242, 2);
  V v_st_246 = heff_take_field(v_tg_242, 0);
  V v_off_247 = heff_get_n(v_tg_242, 1, 3);
  switch (heff_tag_of(v_target_245)) {
  case TAG_Nothing: {
    heff_drop(v_off_247);
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str0), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str1), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str2)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str3));
    V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str4), heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str5)), MK_INT(0LL)));
    V v_acc_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str7)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str8));
    V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str9), v_t_2412, MK_INT(0LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str10)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str11));
    V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_id_241; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_241); r_; });
    V v_t_2416 = heff_strAppend(heff_strAppend(v_acc_2415, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str12)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str13));
    V v_t_2417 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str14), v_t_2416, MK_INT(0LL)));
    V v_acc_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str15)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str16));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str17)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str18));
    V v_a_2420 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2425, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam0, 1, 2, (V[]){v_z_244, v_st_246})));
  }
  case TAG_Just: {
    V v_t_2427 = heff_field(v_target_245, 0);
    V v_ru_24target_245_24Just = heff_take_reuse_n(v_target_245, 1ULL, 1);
    HeffT2 v_t_2428 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2427, 1)), heff_dup(heff_rfield(v_t_2427, 2)), heff_dup(heff_rfield(v_t_2427, 2))));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_off_247);
        heff_drop_rec(v_t_2427, 4);
        V v_why_2431 = v_field_2430;
        V v_c_2432 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24target_245_24Just, v_e_240, v_id_241, MK_INT(-32803LL), v_why_2431));
        return heff_tail(v_c_2432, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam1, 1, 2, (V[]){v_z_244, v_st_246})});
      } else {
        heff_drop(v_field_2430);
        HeffT2 v_t_2434 = (g_list_2efind_24s446714453x706785629_24cpr(heff_dup(v_t_2427), v_off_247, heff_rfield(v_t_2427, 3)));
        {
          V v_field_2436 = v_t_2434.f[1];
          int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
          if ((v_tag_2435 == ((int64_t)0ULL))) {
            V v_o_2437 = v_field_2436;
            V v_source_2438 = heff_take_field(v_o_2437, 1);
            V v_span_2439 = heff_get_n(v_o_2437, 2, 4);
            V v_t_2440 = ({ V a_0 = v_source_2438; V a_1 = v_span_2439; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2438); r_; });
            V v_t_2441 = heff_tag_at_n(v_ru_24target_245_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2427, 2, 4)});
            V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str19), v_t_2441}), NTAG(TAG_Nil)});
            V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str20), v_t_2440}), v_t_2442});
            V v_result_2444 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2443});
            V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str21), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str22)})});
            V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str23), v_result_2444}), NTAG(TAG_Nil)});
            V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str24), v_id_241}), v_t_2446});
            V v_t_2448 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2447})});
            V v_t_2449 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str25); V a_1 = v_t_2448; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2448, 1); r_; });
            V v_a_2450 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2449, NTAG(TAG_MkUnit)});
            V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2450})});
            V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
            V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
            V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
            V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
            return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2455, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam2, 1, 2, (V[]){v_z_244, v_st_246})));
          } else {
            heff_drop(v_field_2436);
            V v_t_2457 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str26), heff_get_n(v_t_2427, 2, 4));
            V v_c_2458 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24target_245_24Just, v_e_240, v_id_241, MK_INT(-32803LL), heff_strAppend(v_t_2457, ((V)&g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_str27))));
            return heff_tail(v_c_2458, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam3, 1, 2, (V[]){v_z_244, v_st_246})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_target_245);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam2(V self, V *args) {
  V v_x_2456 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2456);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2459);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str2, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str3, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str4, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str5, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str6, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str7, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str8, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str9, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str10, 5, "E0156");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str11, 5, "E0157");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str13, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str14, 2, "\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str15, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str16, 1, " ");
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_entry, 3, 0};

V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950(V v_e_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam0, 2, 4, (V[]){v_c_243, v_st_241, v_p_242, v_e_240});
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_d_2441 = v_d_2411;
  V v_text_2442 = heff_take_field(v_d_2441, 1);
  V v_uri_2443 = heff_get_n(v_d_2441, 0, 2);
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str7), NTAG(TAG_Nil)});
  HeffT2 v_t_2445 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str8), v_t_2444}); V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2455;
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_it1_2448 = v_field_2447;
      switch (heff_tag_of(v_it1_2448)) {
      case TAG_JNull: {
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2448, 0ULL, 1);
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2448, 0ULL, 1);
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2448, 0ULL, 1);
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2448, 0ULL, 1);
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2453 = heff_field(v_it1_2448, 0);
        heff_take_n(v_it1_2448, 1ULL, 1);
        v_t_2455 = v_xs_2453;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2448, 0ULL, 1);
        v_t_2455 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2448);
      }
    } else {
      heff_drop(v_field_2447);
      v_t_2455 = NTAG(TAG_Nil);
    }
  }
  V v_ds_2456 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str9); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str10); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str11); V a_3 = v_t_2455; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_x3_2457 = v_x_2440;
  V v_x_2486;
  switch (heff_tag_of(v_x3_2457)) {
  case TAG_Nothing: {
    heff_drop(v_text_2442);
    heff_drop(v_uri_2443);
    heff_drop(v_ds_2456);
    v_x_2486 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_n_2458 = heff_field(v_x3_2457, 0);
    V v_ru_24x3_2457_24Just = heff_take_reuse_n(v_x3_2457, 1ULL, 1);
    V v_src_2459 = heff_dup(v_text_2442);
    V v_n_2460 = heff_dup(v_n_2458);
    V v_t_2461 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_text_2442), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_x3_2462 = heff_get_n(v_t_2461, 2, 4);
    V v_t_2483;
    switch (heff_tag_of(v_x3_2462)) {
    case TAG_Nothing: {
      V v_t_2463;
      if (heff_strEq_c(v_src_2459, ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str12))) {
        v_t_2463 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str13);
      } else {
        v_t_2463 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str14);
      }
      V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str15), v_n_2460), v_t_2463);
      v_t_2483 = heff_tag_at_n(v_ru_24x3_2457_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), v_t_2464})});
      break;
    }
    case TAG_Just: {
      V v_h_2465 = heff_field(v_x3_2462, 0);
      heff_take_n(v_x3_2462, 1ULL, 1);
      V v_t_2466 = heff_dup(heff_rfield(v_h_2465, 0));
      switch (heff_tag_of(v_t_2466)) {
      case TAG_Nothing: {
        heff_drop(v_src_2459);
        V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_h_2465, 3)), 0, 2);
        V v_t_2468 = heff_get_n(heff_get_n(v_h_2465, 3, 5), 0, 2);
        V v_t_2469 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_t_2467, MK_INT(6LL)), heff_intAdd(v_t_2468, MK_INT(6LL))});
        V v_t_2470 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str16), v_n_2460)});
        v_t_2483 = heff_tag_at_n(v_ru_24x3_2457_24Just, TAG_Just, 1, (V[]){v_t_2470});
        break;
      }
      case TAG_Just: {
        V v_m_2471 = heff_field(v_t_2466, 0);
        heff_take_n(v_t_2466, 1ULL, 1);
        if (heff_strEq_c_lent(v_m_2471, v_n_2460, 0)) {
          heff_drop_cell(v_ru_24x3_2457_24Just, 1);
          heff_drop(v_src_2459);
          heff_drop(v_n_2460);
          heff_drop_rec(v_h_2465, 5);
          heff_drop(v_m_2471);
          v_t_2483 = NTAG(TAG_Nothing);
        } else {
          V v_src_2472 = v_src_2459;
          V v_h_2473 = v_h_2465;
          V v_m_2474 = v_m_2471;
          V v_t_2475 = heff_get_n(heff_dup(heff_rfield(v_h_2473, 3)), 0, 2);
          V v_from_2476 = heff_intAdd(v_t_2475, MK_INT(6LL));
          V v_t_2477 = heff_get_n(heff_get_n(v_h_2473, 3, 5), 1, 2);
          V v_j_2478 = heff_strFind(heff_dup(v_m_2474), heff_strSlice_lent(v_src_2472, v_from_2476, v_t_2477, 5), MK_INT(0LL));
          V v_t_2479;
          if (heff_intLt_c_lent(v_j_2478, MK_INT(0LL), 2)) {
            heff_drop(v_j_2478);
            v_t_2479 = MK_INT(1LL);
          } else {
            v_t_2479 = v_j_2478;
          }
          V v_at_2480 = heff_intAdd(v_from_2476, v_t_2479);
          V v_e_2481 = heff_intAdd(heff_dup(v_at_2480), heff_strLength(v_m_2474));
          V v_t_2482 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_at_2480, v_e_2481}), v_n_2460});
          v_t_2483 = heff_tag_at_n(v_ru_24x3_2457_24Just, TAG_Just, 1, (V[]){v_t_2482});
        }
        break;
      }
      default: heff_nomatch(v_t_2466);
      }
      break;
    }
    default: heff_nomatch(v_x3_2462);
    }
    switch (heff_tag_of(v_t_2483)) {
    case TAG_Nothing: {
      heff_drop(v_text_2442);
      heff_drop(v_uri_2443);
      heff_drop(v_ds_2456);
      heff_drop(v_n_2458);
      v_x_2486 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2484 = heff_field(v_t_2483, 0);
      heff_take_n(v_t_2483, 1ULL, 1);
      V v_t_2485 = ({ V a_0 = v_uri_2443; V a_1 = v_text_2442; V a_2 = v_n_2458; V a_3 = v_ds_2456; V a_4 = v_x_2484; V r_ = (g_heff_2elsp_2elsp_2eclaimAction(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_2442); r_; });
      v_x_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2483);
    }
    break;
  }
  default: heff_nomatch(v_x3_2457);
  }
  V f_ = v_k_245;
  args[0] = v_x_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_p_242);
    heff_drop(v_e_240);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_f_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2411 = v_field_2410;
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str0), NTAG(TAG_Nil)});
        HeffT2 v_t_2413 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str1), v_t_2412}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          V v_t_2423;
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_it1_2416 = v_field_2415;
            switch (heff_tag_of(v_it1_2416)) {
            case TAG_JNull: {
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2416, 0ULL, 1);
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2416, 0ULL, 1);
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2416, 0ULL, 1);
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_it1_2416, 0ULL, 1);
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            case TAG_JArray: {
              V v_xs_2421 = heff_field(v_it1_2416, 0);
              heff_take_n(v_it1_2416, 1ULL, 1);
              v_t_2423 = ({ V a_0 = v_xs_2421; V r_ = (g_list_2eany_24s1032636598x1013662416(a_0)); heff_drop(v_xs_2421); r_; });
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2416, 0ULL, 1);
              v_t_2423 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it1_2416);
            }
          } else {
            heff_drop(v_field_2415);
            v_t_2423 = NTAG(TAG_True);
          }
          if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
            heff_drop(v_t_2423);
            V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str2), NTAG(TAG_Nil)});
            HeffT2 v_t_2425 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str3), v_t_2424}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2435;
            {
              V v_field_2427 = v_t_2425.f[1];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              if ((v_tag_2426 == ((int64_t)0ULL))) {
                V v_it1_2428 = v_field_2427;
                switch (heff_tag_of(v_it1_2428)) {
                case TAG_JNull: {
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2428, 0ULL, 1);
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_it1_2428, 0ULL, 1);
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_it1_2428, 0ULL, 1);
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2428, 0ULL, 1);
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                case TAG_JArray: {
                  V v_xs_2433 = heff_field(v_it1_2428, 0);
                  heff_take_n(v_it1_2428, 1ULL, 1);
                  v_t_2435 = v_xs_2433;
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2428, 0ULL, 1);
                  v_t_2435 = NTAG(TAG_Nil);
                  break;
                }
                default: heff_nomatch(v_it1_2428);
                }
              } else {
                heff_drop(v_field_2427);
                v_t_2435 = NTAG(TAG_Nil);
              }
            }
            V v_x1_2436 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str4); V b_1 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str5); V b_2 = ((V)&g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_str6); V a_3 = v_t_2435; V r_ = (g_list_2ekeepIf_24s735270044x1288664053(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_x1_2436)) {
            case TAG_Nil: {
              heff_drop_rec(v_st_241, 7);
              heff_drop(v_p_242);
              heff_drop(v_e_240);
              heff_drop(v_hd_244);
              heff_drop(v_f_247);
              heff_drop(v_d_2411);
              V f_ = v_k_245;
              args[0] = NTAG(TAG_Nil);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_Cons: {
              heff_take_n(v_x1_2436, 0ULL, 2);
              V v_c_2439 = (g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(v_e_240, v_st_241, v_f_247));
              V f_ = v_c_2439;
              heff_room[0] = v_hd_244;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam2, 1, 3, (V[]){v_d_2411, v_p_242, v_k_245});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
            default: return heff_nomatch(v_x1_2436);
            }
          } else {
            heff_drop_rec(v_st_241, 7);
            heff_drop(v_p_242);
            heff_drop(v_e_240);
            heff_drop(v_hd_244);
            heff_drop(v_f_247);
            heff_drop(v_d_2411);
            heff_drop(v_t_2423);
            V f_ = v_k_245;
            args[0] = NTAG(TAG_Nil);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop_rec(v_st_241, 7);
        heff_drop(v_p_242);
        heff_drop(v_e_240);
        heff_drop(v_hd_244);
        heff_drop(v_f_247);
        heff_drop(v_field_2410);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_lam1, 1, 5, (V[]){v_k_245, v_st_241, v_p_242, v_e_240, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str0, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str1, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str2, 22, "heff failed answering ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str4, 1, ")");
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam1, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_entry, 4, 0};

V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199(V v_e_240, V v_st_241, V v_msg_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_why_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Left = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    V v_x1_2418;
    switch (heff_tag_of(v_msg_242)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2410 = heff_dup(heff_field(v_msg_242, 0));
      HeffT2 v_t_2411 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str0); V a_1 = v_fs_2410; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2410); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_p_2414 = v_field_2413;
          V v_t_2417;
          switch (heff_tag_of(v_p_2414)) {
          case TAG_MkPair: {
            V v_y_2416 = heff_field(v_p_2414, 1);
            heff_take_n(v_p_2414, 2ULL, 2);
            v_t_2417 = v_y_2416;
            break;
          }
          default: heff_nomatch(v_p_2414);
          }
          v_x1_2418 = heff_tag_at_n(v_ru_24x3_243_24Left, TAG_Just, 1, (V[]){v_t_2417});
        } else {
          heff_drop_cell(v_ru_24x3_243_24Left, 1);
          heff_drop(v_field_2413);
          v_x1_2418 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_242);
    }
    V v_x2_2438;
    switch (heff_tag_of(v_msg_242)) {
    case TAG_JNull: {
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_msg_242, 0ULL, 1);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_msg_242, 0ULL, 1);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_msg_242, 0ULL, 1);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_msg_242, 0ULL, 1);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_msg_242, 0ULL, 1);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2424 = heff_field(v_msg_242, 0);
      V v_ru_24msg_242_24JObject = heff_take_reuse_n(v_msg_242, 1ULL, 1);
      HeffT2 v_t_2425 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str1); V a_1 = v_fs_2424; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2424); r_; });
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_p_2428 = v_field_2427;
          V v_t_2431;
          switch (heff_tag_of(v_p_2428)) {
          case TAG_MkPair: {
            V v_y_2430 = heff_field(v_p_2428, 1);
            heff_take_n(v_p_2428, 2ULL, 2);
            v_t_2431 = v_y_2430;
            break;
          }
          default: heff_nomatch(v_p_2428);
          }
          switch (heff_tag_of(v_t_2431)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2431, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2431, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2431, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2435 = heff_field(v_t_2431, 0);
            heff_take_n(v_t_2431, 1ULL, 1);
            v_x2_2438 = heff_tag_at_n(v_ru_24msg_242_24JObject, TAG_Just, 1, (V[]){v_s_2435});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2431, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2431, 0ULL, 1);
            heff_drop_cell(v_ru_24msg_242_24JObject, 1);
            v_x2_2438 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2431);
          }
        } else {
          heff_drop_cell(v_ru_24msg_242_24JObject, 1);
          heff_drop(v_field_2427);
          v_x2_2438 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_242);
    }
    V v_c_2447;
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Nothing: {
      heff_drop(v_e_240);
      heff_drop(v_why_244);
      heff_drop(v_x2_2438);
      v_c_2447 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_id_2441 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24Just = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nothing: {
        heff_drop(v_e_240);
        heff_drop(v_why_244);
        heff_drop(v_id_2441);
        heff_drop_cell(v_ru_24x1_2418_24Just, 1);
        v_c_2447 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam1_clo);
        break;
      }
      case TAG_Just: {
        V v_m_2444 = heff_field(v_x2_2438, 0);
        heff_take_n(v_x2_2438, 1ULL, 1);
        V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str2), v_m_2444), ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str3));
        V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, v_why_244), ((V)&g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_str4));
        v_c_2447 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(v_ru_24x1_2418_24Just, v_e_240, v_id_2441, MK_INT(-32603LL), v_t_2446));
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      break;
    }
    default: heff_nomatch(v_x1_2418);
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam2, 2, 2, (V[]){v_c_2447, v_st_241});
  }
  case TAG_Right: {
    V v_st2_2451 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_msg_242);
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam4, 2, 1, (V[]){v_st2_2451});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam0(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam1(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam3(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V f_ = v_k_2449;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam2(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam3, 1, 2, (V[]){v_k_2449, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_lam4(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_st2_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = v_st2_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}