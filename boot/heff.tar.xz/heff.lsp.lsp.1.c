// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_ReadFile 6783
#define TAG_Send 26077
#define TAG_UriPath 39251
#define LBL_checked 974171621
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_clo;
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314(V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(V);
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889(V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488_clo;
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(V, V);
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777_clo;
V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(V, V);
V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_clo;
V g_heff_2elsp_2elsp_2esplitAction(V, V, V);
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitAction_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
HeffT2 g_heff_2elsp_2esplit_2esplit_24cpr(V, V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl(V, V, V);
V g_heff_2elsp_2esplit_2espotInDecl_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2espotInDecl_clo;
HeffT2 g_heff_2elsp_2esplit_2eusedType_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1392550889x861369760(V, V);
V g_list_2efilter_24s1392550889x861369760_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efilter_24s999680916x306845608(V, V);
V g_list_2efilter_24s999680916x306845608_entry(V self, V *a);
extern Clo g_list_2efilter_24s999680916x306845608_clo;
V g_list_2efoldl_24f1045673032x1961362160(V, V, V, V, V);
V g_list_2efoldl_24f1045673032x1961362160_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1045673032x1961362160_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1392550889x861369760(v_s_241, v_ss_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubSources_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str0, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str2, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str3, 4, "name");
Clo g_heff_2elsp_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_m_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_m_241, 1)});
  V v_t_244 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_dup(heff_rfield(v_m_241, 2))));
  V v_t_245 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_get_n(v_m_241, 2, 3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str0), v_t_245}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str1), v_t_244}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str2), v_t_243}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str3), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2echildJson(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_243 = heff_take_field(v_target_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get_n(v_target_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength(v_t_246)) - heff_unbox_word(v_t_247));
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), heff_box_word(v_t_248)), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_target_242, 3);
    V v_t_2413 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2413));
    V v_t_2415 = (g_list_2efoldl_24f1045673032x1961362160(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_s_2416 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), heff_intMul(heff_box_word(v_t_2414), v_t_2415));
    V v_t_2417 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_new_241, 0)) - heff_unbox_word(v_t_2417));
    V v_t_2419 = (g_list_2efoldl_24f1045673032x1961362160(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_240), heff_dup(v_b_2412), heff_rfield(v_t_240, 3)));
    V v_t_2420 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), heff_intMul(heff_box_word(v_t_2418), v_t_2419));
    V v_e_2421 = heff_intAdd(v_t_2420, heff_strLength(v_new_241));
    V v_t_2422 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
    V v_t_2423 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2416, v_e_2421})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2422, NTAG(TAG_Nothing), v_t_2423});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str0, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str1, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str3, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_2417;
  if (heff_intLt_c_lent(v_errorsBefore_243, v_errorsAfter_244, 0)) {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str0), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str1)));
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str2), heff_strAppend(v_new_242, v_t_248));
    V v_t_2410 = heff_strAppend(heff_get_n(v_t_241, 2, 4), v_t_249);
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str3), v_t_2410)});
  } else {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_2411 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2412 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_245, v_t_2411, v_new_242));
    V v_x_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_y_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_241, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_x_2413, v_y_2414)) {
      heff_drop(v_new_242);
      v_t_2417 = NTAG(TAG_Nothing);
    } else {
      V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str5)));
      v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_240, 0, 2), v_t_2417});
}
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_243, 1))}));
    V v_t_246 = (g_list_2eany(v_t_245, v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
      V v_u_249 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_248, v_rest_244, heff_dup(v_cell_247)));
      heff_drop(v_u_249);
      return v_cell_247;
    } else {
      heff_drop(v_t_246);
      V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 1)), heff_hole()});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 0, 14), v_mods_241});
        V v_u_2415 = (g_heff_2elsp_2elsp_2eaffectedGo_24dps(v_changed_240, v_t_2414, v_rest_244, heff_dup(v_cell_2413)));
        heff_drop(v_u_2415);
        return v_cell_2413;
      } else {
        heff_drop_rec(v_c_243, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2412);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2410}));
  return ({ V a_0 = v_t_2411; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str1, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str5, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str7, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitAction_str8, 5, "title");
Clo g_heff_2elsp_2elsp_2esplitAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitAction_entry, 3, 0};

V g_heff_2elsp_2elsp_2esplitAction(V v_uri_240, V v_src_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_242, 0)});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str1)})});
  V v_t_245 = heff_take_field(v_x_242, 1);
  V v_t_246 = heff_take_field(v_x_242, 2);
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_t_245)));
  V v_t_249;
  if (heff_intLe_c_lent(v_t_245, v_t_246, 0)) {
    heff_drop(v_t_245);
    v_t_249 = v_t_246;
  } else {
    heff_drop(v_t_246);
    v_t_249 = v_t_245;
  }
  V v_t_2410 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str2), v_t_2410}), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str3), v_t_247}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_242, 3, 4)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str5), v_t_2414}), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitAction_str8), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2423})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2esplitAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2esplitAction(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_take_field(v_st_240, 2), v_f_241));
  V v_c_243 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_take_field(v_st_240, 1), v_f_241));
  V v_d_244 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_take_field(v_st_240, 0), v_f_241));
  return ({ V rv_0 = v_d_244; V rv_1 = v_c_243; V rv_2 = v_t_242; V rr_ = heff_rec_reuse_nf(v_st_240, 120ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16320u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclosed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_entry, 1, 0};

V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_str1), v_t_241}), v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2418 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JString = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        V v_t_2420 = heff_tag_at_n(v_ru_24it1_246_24JString, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2418, ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam4_clo)})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        return heff_tail(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam6_clo);
      }
      default: return heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(a[0]);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam4(V self, V *args) {
  V v_p_2419 = args[0];
  return v_p_2419;
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam5(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_lam7(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(V v_st_240, V v_f_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_246 = v_field_244;
      V v_c_2422 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam0, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam3, 2, 4, (V[]){v_c_2422, v_d_246, v_st_240, v_f_241});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam8, 2, 1, (V[]){v_st_240});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_d_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2412, 1, 2)});
  V f_ = v_k_2414;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam2(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_p_247);
      V v_d_2412 = v_field_2410;
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam1, 2, 1, (V[]){v_d_2412});
    } else {
      heff_drop(v_field_2410);
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_247, ((V)&g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam2_clo)})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V f_ = ((V)&g_co_2eop_24s903439140x919002362_clo);
      args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_d_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_246, 1, 2); V a_1 = v_x_2430; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_246, 1, 2), v_x_2428});
  V v_c_2435 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_240, 1), v_f_241, v_t_2434));
  V v_t_2436 = ({ V rv_1 = v_c_2435; V rr_ = heff_rec_reuse_nf(v_st_240, 125ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2424;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_f_241 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2428 = (g_heff_2elsp_2elsp_2ekeptOf(heff_get_n(v_x_2427, 0, 2)));
  V v_t_2429 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_246, 1)), heff_dup(v_x_2428), heff_get_n(v_x_2425, 1, 5)));
  V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam6, 1, 1, (V[]){heff_dup(v_d_246)}), v_t_2429));
  V v_c_2432 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(heff_dup(heff_rfield(v_d_246, 0)), v_t_2431));
  V f_ = v_c_2432;
  heff_room[0] = v_hd_2423;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam7, 1, 5, (V[]){v_d_246, v_x_2428, v_st_240, v_f_241, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_x_2425)));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam5, 1, 6, (V[]){v_d_246, v_x_2425, v_hd_2423, v_st_240, v_f_241, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam4, 1, 5, (V[]){v_hd_2423, v_d_246, v_st_240, v_f_241, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_lam8(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s1798435514x1390842225_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_entry, 2, 0};

V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(V v_st_240, V v_f_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_f_241});
}
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_dup(heff_rfield(v_st_240, 3));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(v_st_240, heff_get_n(v_x_245, 0, 6), v_f_241, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_pr_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pr_247, 0)), heff_dup(heff_rfield(v_x_245, 0)))) {
      heff_drop_rec(v_x_245, 6);
      heff_drop(v_f_241);
      heff_drop(v_hd_243);
      V v_t_249 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, heff_get_n(v_pr_247, 1, 2)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop_rec(v_pr_247, 2);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s1552971528x536992777(v_st_240, heff_get_n(v_x_245, 0, 6), v_f_241, v_hd_243, v_k_244));
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_entry, 3, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2esymbolJson_24s821280090x1719921949(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280(v_st_240, v_c_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s20613629x2099116280(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2410));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam2, 2, 4, (V[]){v_c_2411, v_st_240, heff_dup(v_query_241), heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_249 = ({ V b_0 = heff_get_n(v_y_248, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return heff_intLe(MK_INT(0LL), heff_strFind(v_query_241, v_s_249, MK_INT(0LL)));
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = (g_prelude_2e_2b_2b(v_x_2414, v_x_2416));
  V f_ = v_k_2413;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2415 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(a_0, a_1, a_2)); heff_drop(v_query_241); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam4, 1, 2, (V[]){v_x_2414, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_query_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam1, 1, 0};
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889(V v_st_240, V v_o_241) {
top: ;
  V v_p_242 = heff_dup(heff_rfield(v_o_241, 0));
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2415;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_p_242);
      V v_d_247 = v_field_245;
      v_c_2415 = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam0, 2, 1, (V[]){v_d_247});
    } else {
      heff_drop(v_field_245);
      V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_242, ((V)&g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam1_clo)})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      v_c_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam2, 2, 2, (V[]){v_c_2415, v_o_241});
}
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_get_n(v_d_247, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  return v_u_2410;
}
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_o_241 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2418})});
  V v_t_2420 = ({ V b_0 = heff_take_field(v_o_241, 1); V a_1 = heff_get_n(v_o_241, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_str1), v_t_2420}), NTAG(TAG_Nil)});
  V v_x_2422 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  V f_ = v_k_2417;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1630472499x1670590889_lam3, 1, 2, (V[]){v_o_241, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_entry, 3, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return heff_tail(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_2416});
}
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str7, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str8, 2, "id");
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_entry, 5, 0};

V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390(V v_id_240, V v_new_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_tg_242, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str1)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str2), NTAG(TAG_JNull)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str3), v_id_240}), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})});
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
    V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s94900133x232571340(v_t_2416, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam0, 1, 2, (V[]){v_z_244, v_tg_242})));
  }
  case TAG_Just: {
    V v_t_2418 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    HeffT2 v_t_2419 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2418, 1)), heff_dup(heff_rfield(v_t_2418, 2)), heff_dup(v_new_241)));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_new_241);
        heff_drop_rec(v_t_2418, 4);
        V v_why_2423 = v_field_2421;
        V v_c_2424 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_240, MK_INT(-32803LL), v_why_2423));
        return heff_tail(v_c_2424, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam1, 1, 2, (V[]){v_z_244, v_tg_242})});
      } else {
        heff_drop(v_field_2421);
        V v_c_2426 = (g_heff_2elsp_2elsp_2erenameChecked_24s903790348x1534550835(heff_get_n(v_tg_242, 0, 3), heff_dup(v_t_2418), heff_dup(v_new_241)));
        return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam2, 1, 5, (V[]){v_t_2418, v_new_241, v_z_243, v_id_240, v_z_244})});
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam3(V self, V *args) {
  V v_p_2437 = args[0];
  V v_os_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2438 = (g_list_2efilter_24s999680916x306845608(v_p_2437, v_os_2434));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2437, v_os_2438});
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam5(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V v_t_2458;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 2);
    v_t_2458 = v_x_2456;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_z_244;
  args[0] = v_t_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str5)})});
  V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_x_2441})});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_str8), v_id_240}), v_t_2446});
  V v_t_2448 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2447})});
  V v_t_2449 = ({ V a_0 = v_t_2448; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2448, 1); r_; });
  V v_a_2450 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2449, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s94900133x232571340(v_t_2454, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam5, 1, 2, (V[]){v_x_2427, v_z_244})));
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2464;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 2);
    v_t_2464 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_z_244;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_t_2418 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_dup(heff_field(v_x_2427, 1));
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Nothing: {
    V v_t_2433;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_dup(heff_field(v_x_2427, 0));
      v_t_2433 = v_x_2431;
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    V v_os_2434 = heff_get_n(v_t_2418, 3, 4);
    V v_t_2435 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2434)));
    V v_t_2436 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2435));
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam3, 1, 1, (V[]){v_os_2434}), v_t_2436));
    V v_c_2440 = (g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(v_t_2433, v_new_241, v_t_2439));
    V f_ = v_c_2440;
    heff_room[0] = heff_dup(v_z_243);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam4, 1, 4, (V[]){v_id_240, v_z_243, v_x_2427, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2459 = heff_field(v_t_2430, 0);
    heff_take_n(v_t_2430, 1ULL, 1);
    heff_drop_rec(v_t_2418, 4);
    heff_drop(v_new_241);
    V v_c_2460 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_240, MK_INT(-32803LL), v_why_2459));
    V f_ = v_c_2460;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_lam6, 1, 2, (V[]){v_x_2427, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2430);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str7, 2, "id");
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_entry, 3, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam0, 2, 3, (V[]){v_c_243, v_id_241, v_st_240});
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_d_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2430, 1, 2)});
  V f_ = v_k_2432;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam5(V self, V *args) {
  V v_t_2434 = args[0];
  return v_t_2434;
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam3(V self, V *args) {
  V v_q_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2426 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_q_2425; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      heff_drop(v_q_2425);
      V v_d_2430 = v_field_2428;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam4, 2, 1, (V[]){v_d_2430});
    } else {
      heff_drop(v_field_2428);
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_q_2425, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam5_clo)})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V f_ = ((V)&g_co_2eop_24s903439140x919002362_clo);
      args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_t_2439});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2424 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2442 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2441, 0, 5)));
  return (g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629(v_st_240, v_id_241, v_d_2424, v_t_2442, v_hd_244, v_k_245));
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam7(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2454);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str1)})});
    V v_t_248 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str2), v_t_248}), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str3), v_id_241}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s94900133x232571340(v_t_2417, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
  }
  case TAG_Just: {
    V v_f_2419 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_2419));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_246_24Just, 1);
        V v_d_2424 = v_field_2422;
        V v_c_2440 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1983791393x272362964(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam3, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), v_f_2419));
        V f_ = v_c_2440;
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam6, 1, 5, (V[]){v_st_240, v_id_241, v_d_2424, v_hd_244, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2419);
        heff_drop(v_field_2422);
        V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str4), heff_tag_at_n(v_ru_24x_246_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str5)})});
        V v_t_2444 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str6), v_t_2444}), NTAG(TAG_Nil)});
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_str7), v_id_241}), v_t_2445});
        V v_t_2447 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2446})});
        V v_t_2448 = ({ V a_0 = v_t_2447; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2447, 1); r_; });
        V v_a_2449 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2448, NTAG(TAG_MkUnit)});
        V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
        V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
        V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
        V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
        return (g_co_2eop_24s94900133x232571340(v_t_2453, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam7, 1, 2, (V[]){v_k_245, v_st_240})));
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_entry, 8, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466(V v_st_240, V v_f_241, V v_uri_242, V v_program_243, V v_c_244, V v_off_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam0, 1, 2, (V[]){heff_dup(v_c_244), v_off_245}), heff_dup(heff_rfield(v_c_244, 4))));
  HeffT2 v_t_2410 = (g_heff_2elsp_2esplit_2efirstJust_24cpr(v_t_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_s_2414 = v_field_2412;
      HeffT2 v_t_2415 = (g_heff_2elsp_2esplit_2eusedType_24cpr(heff_dup(v_c_244), heff_dup(v_s_2414)));
      V v_c_2422;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_st_240);
          heff_drop(v_f_241);
          V v_t_2419 = v_field_2417;
          v_c_2422 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam1, 2, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_field_2417);
          v_c_2422 = (g_heff_2elsp_2elsp_2eprobedType_24s267401543x704966488(v_st_240, v_f_241, heff_dup(v_program_243), heff_dup(v_c_244), heff_dup(v_s_2414)));
        }
      }
      return heff_tail(v_c_2422, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam2, 1, 5, (V[]){v_program_243, v_c_244, v_s_2414, v_uri_242, v_z_247})});
    } else {
      heff_drop(v_st_240);
      heff_drop(v_f_241);
      heff_drop(v_uri_242);
      heff_drop(v_program_243);
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_z_246);
      heff_drop(v_field_2412);
      return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_off_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = heff_get_n(v_c_244, 3, 14); V a_1 = v_off_245; V a_2 = v_d_248; V r_ = (g_heff_2elsp_2esplit_2espotInDecl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_2414 = heff_env(self)[2];
  V v_uri_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2431;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop_rec(v_c_244, 14);
    heff_drop(v_s_2414);
    heff_drop(v_uri_242);
    v_x_2431 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2424 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    HeffT2 v_t_2425 = ({ V a_0 = v_program_243; V a_1 = heff_dup(v_c_244); V a_2 = v_s_2414; V a_3 = v_t_2424; HeffT2 r_ = (g_heff_2elsp_2esplit_2esplit_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); r_; });
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x_2429 = v_field_2427;
        V v_t_2430 = ({ V a_0 = v_uri_242; V b_1 = heff_get_n(v_c_244, 3, 14); V a_2 = v_x_2429; V r_ = (g_heff_2elsp_2elsp_2esplitAction(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop(v_uri_242);
        heff_drop(v_field_2427);
        v_x_2431 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_z_247;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314(V v_a_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam0, 2, 3, (V[]){v_c_242, v_a_240, v_p_241});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_a_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_240, 3);
      heff_drop(v_p_241);
      heff_drop(v_hd_243);
      heff_drop(v_f_246);
      V f_ = v_k_244;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 1ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x1_247_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str1), v_t_2410}), heff_dup(v_p_241)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        V v_t_2423;
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_it1_2415 = v_field_2413;
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_JNull: {
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2415, 0ULL, 1);
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          case TAG_JArray: {
            V v_xs_2420 = heff_field(v_it1_2415, 0);
            heff_take_n(v_it1_2415, 1ULL, 1);
            V v_t_2421 = ({ V a_0 = v_xs_2420; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2420); r_; });
            v_t_2423 = heff_bool(((heff_dup(v_t_2421) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)))));
            heff_drop(v_t_2421);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
            break;
          }
          default: heff_nomatch(v_it1_2415);
          }
        } else {
          heff_drop(v_field_2413);
          v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_x_248, 3)), heff_dup(heff_rfield(v_a_240, 1)));
        }
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_t_2423);
          V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str2), NTAG(TAG_Nil)});
          HeffT2 v_t_2425 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str3), v_t_2424}), heff_dup(v_p_241)));
          V v_t_2436;
          {
            V v_field_2427 = v_t_2425.f[1];
            int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
            if ((v_tag_2426 == ((int64_t)0ULL))) {
              V v_it1_2429 = v_field_2427;
              switch (heff_tag_of(v_it1_2429)) {
              case TAG_JNull: {
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str4);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str5);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str6);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str7);
                break;
              }
              case TAG_JString: {
                V v_s_2433 = heff_field(v_it1_2429, 0);
                heff_take_n(v_it1_2429, 1ULL, 1);
                v_t_2436 = v_s_2433;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str8);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str9);
                break;
              }
              default: heff_nomatch(v_it1_2429);
              }
            } else {
              heff_drop(v_field_2427);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str10);
            }
          }
          V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str11), NTAG(TAG_Nil)});
          V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str13), v_t_2437})});
          HeffT2 v_t_2439 = (g_json_2eat_24cpr(v_t_2438, heff_dup(v_p_241)));
          V v_t_2465;
          {
            V v_field_2441 = v_t_2439.f[1];
            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
            V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str14), NTAG(TAG_Nil)});
            V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_str16), v_t_2442})});
            HeffT2 v_t_2444 = (g_json_2eat_24cpr(v_t_2443, v_p_241));
            {
              V v_field_2446 = v_t_2444.f[1];
              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
              V v_t_2455;
              if ((v_tag_2440 == ((int64_t)0ULL))) {
                V v_it1_2448 = v_field_2441;
                switch (heff_tag_of(v_it1_2448)) {
                case TAG_JNull: {
                  v_t_2455 = MK_INT(0LL);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2448, 0ULL, 1);
                  v_t_2455 = MK_INT(0LL);
                  break;
                }
                case TAG_JInt: {
                  V v_i_2450 = heff_field(v_it1_2448, 0);
                  heff_take_n(v_it1_2448, 1ULL, 1);
                  v_t_2455 = v_i_2450;
                  break;
                }
                case TAG_JFloat: {
                  double v_x_2451 = heff_tflat_f64(v_it1_2448, 0);
                  heff_take_na(v_it1_2448, 0ULL, 1);
                  v_t_2455 = heff_floor_f64(v_x_2451);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2448, 0ULL, 1);
                  v_t_2455 = MK_INT(0LL);
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_it1_2448, 0ULL, 1);
                  v_t_2455 = MK_INT(0LL);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2448, 0ULL, 1);
                  v_t_2455 = MK_INT(0LL);
                  break;
                }
                default: heff_nomatch(v_it1_2448);
                }
              } else {
                heff_drop(v_field_2441);
                v_t_2455 = MK_INT(0LL);
              }
              V v_t_2464;
              if ((v_tag_2445 == ((int64_t)0ULL))) {
                V v_it1_2457 = v_field_2446;
                switch (heff_tag_of(v_it1_2457)) {
                case TAG_JNull: {
                  v_t_2464 = MK_INT(0LL);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2457, 0ULL, 1);
                  v_t_2464 = MK_INT(0LL);
                  break;
                }
                case TAG_JInt: {
                  V v_i_2459 = heff_field(v_it1_2457, 0);
                  heff_take_n(v_it1_2457, 1ULL, 1);
                  v_t_2464 = v_i_2459;
                  break;
                }
                case TAG_JFloat: {
                  double v_x_2460 = heff_tflat_f64(v_it1_2457, 0);
                  heff_take_na(v_it1_2457, 0ULL, 1);
                  v_t_2464 = heff_floor_f64(v_x_2460);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2457, 0ULL, 1);
                  v_t_2464 = MK_INT(0LL);
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_it1_2457, 0ULL, 1);
                  v_t_2464 = MK_INT(0LL);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2457, 0ULL, 1);
                  v_t_2464 = MK_INT(0LL);
                  break;
                }
                default: heff_nomatch(v_it1_2457);
                }
              } else {
                heff_drop(v_field_2446);
                v_t_2464 = MK_INT(0LL);
              }
              v_t_2465 = (g_heff_2elsp_2elsp_2eoffsetGo(heff_rfield(v_a_240, 1), v_t_2455, v_t_2464, MK_INT(0LL), MK_INT(0LL)));
            }
          }
          return (g_heff_2elsp_2elsp_2esplitIn_24s1108060531x1787485466(heff_dup(heff_rfield(v_a_240, 0)), v_f_246, v_t_2436, heff_get_n(v_a_240, 2, 3), v_x_248, v_t_2465, v_hd_243, v_k_244));
        } else {
          heff_drop_rec(v_a_240, 3);
          heff_drop(v_p_241);
          heff_drop(v_hd_243);
          heff_drop(v_f_246);
          heff_drop_rec(v_x_248, 14);
          heff_drop(v_t_2423);
          V f_ = v_k_244;
          args[0] = NTAG(TAG_Nil);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_a_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_lam1, 1, 4, (V[]){v_k_244, v_a_240, v_p_241, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}