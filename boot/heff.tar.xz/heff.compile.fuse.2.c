// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_c 317
#define LBL_consumers 1203455020
#define LBL_cp 9940
#define LBL_cvars 296399145
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_goes 9673821
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_p 330
#define LBL_params 951713969
#define LBL_parity 951721880
#define LBL_producers 572620898
#define LBL_supply 1056026650
static uint32_t shape_c__arity__at__arms__goes__p__parity__cp__cvars[] = {LBL_c, LBL_arity, LBL_at, LBL_arms, LBL_goes, LBL_p, LBL_parity, LBL_cp, LBL_cvars};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__at__arms__goes__fixed[] = {LBL_params, LBL_at, LBL_arms, LBL_goes, LBL_fixed};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ecompile_2efuse_2earmGiven(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_clo;
V g_heff_2ecompile_2efuse_2eatEnds(V, V);
V g_heff_2ecompile_2efuse_2eatEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eatEnds_clo;
V g_heff_2ecompile_2efuse_2ebindsOf(V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerWith_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2efixedGo(V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_clo;
V g_heff_2ecompile_2efuse_2efuseKnown(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_clo;
V g_heff_2ecompile_2efuse_2efuseOn(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_clo;
V g_heff_2ecompile_2efuse_2efuseWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseWith_clo;
V g_heff_2ecompile_2efuse_2efusedOf(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efusedOf_clo;
HeffT2 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V);
V g_heff_2ecompile_2efuse_2egoesOf(V);
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_clo;
V g_heff_2ecompile_2efuse_2ehere(V, V);
V g_heff_2ecompile_2efuse_2ehere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ehere_clo;
V g_heff_2ecompile_2efuse_2einitF(V);
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2ekidsF(V, V);
V g_heff_2ecompile_2efuse_2ekidsF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ekidsF_clo;
HeffT2 g_heff_2ecompile_2efuse_2elastF_24cpr(V);
V g_heff_2ecompile_2efuse_2emakeFused(V, V, V, V);
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emakeFused_clo;
V g_heff_2ecompile_2efuse_2emayFuse(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2emayFuse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emayFuse_clo;
HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V, V);
HeffT2 g_heff_2ecompile_2efuse_2eposF_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2erecall(V, V, V, V);
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecall_clo;
V g_heff_2ecompile_2efuse_2eselfArgs(V, V, V);
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfArgs_clo;
V g_heff_2ecompile_2efuse_2esites(V, V);
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esites_clo;
V g_heff_2ecompile_2efuse_2etailsOf(V);
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etailsOf_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s324619290x435523318(V, V);
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a);
extern Clo g_list_2efoldl_24s324619290x435523318_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f505181408x1813697659(V, V);
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;

HeffT2 g_heff_2ecompile_2efuse_2eposF_24cpr(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 2)) {
      heff_drop(v_ys_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2efuse_2econsumerWith_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2efuse_2econsumerWith_24cpr(V v_key_240, V v_ps_241, V v_at_242, V v_arms_243, V v_ks_244) {
top: ;
  V v_t_245 = (g_list_2eall_24s1373454977x2143028054(v_ks_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2eany_24s1375915522x445000623(v_ks_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_arms_243), v_ks_244));
      V v_t_248 = (g_heff_2ecompile_2efuse_2egoesOf(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_243)));
      V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2econsumerWith_24cpr_lam0, 2, 2, (V[]){heff_dup(v_ps_241), v_key_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_ps_241); V r_ = (g_heff_2ecompile_2efuse_2efixedGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
      V v_f_2420 = heff_rec_n(5, shape_params__at__arms__goes__fixed, (V[]){v_ps_241, v_at_242, v_arms_243, v_t_248, v_t_2419});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
    } else {
      heff_drop(v_key_240);
      heff_drop(v_ps_241);
      heff_drop(v_at_242);
      heff_drop(v_arms_243);
      heff_drop(v_ks_244);
      heff_drop(v_t_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_key_240);
    heff_drop(v_ps_241);
    heff_drop(v_at_242);
    heff_drop(v_arms_243);
    heff_drop(v_ks_244);
    heff_drop(v_t_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
V g_heff_2ecompile_2efuse_2econsumerWith_24cpr_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_ps_241 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ps_241); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkArm: {
    V v_b_2415 = heff_field(v_x_2411, 2);
    heff_take_n(v_x_2411, 4ULL, 3);
    v_t_2416 = v_b_2415;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2417 = (g_heff_2ecompile_2efuse_2eselfArgs(v_key_240, v_t_2412, v_t_2416));
  return (g_prelude_2e_2b_2b(v_t_2417, v_acc_2410));
}
Clo g_heff_2ecompile_2efuse_2etailsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etailsOf_entry, 1, 0};

V g_heff_2ecompile_2efuse_2etailsOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2420));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s324619290x435523318(a_0, a_1)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etailsOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2efuse_2earmGiven_str0, 0, "");
Clo g_heff_2ecompile_2efuse_2earmGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmGiven_entry, 6, 0};

V g_heff_2ecompile_2efuse_2earmGiven(V v_fu_240, V v_t_241, V v_hs_242, V v_ts_243, V v_e_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    V v_ru_24e_244_24EVar = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_247 = heff_tag_at_n(v_ru_24e_244_24EVar, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_248 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_249 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_247, v_t_248});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_z_245});
  }
  case TAG_EGlobal: {
    V v_ru_24e_244_24EGlobal = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24e_244_24EGlobal, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_2412 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2413 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2411, v_t_2412});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_z_245});
  }
  case TAG_ELam: {
    V v_vs_2414 = heff_field(v_e_244, 0);
    V v_b_2415 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_x_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2414));
    V v_y_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_hs_242));
    if (heff_intEq_c(v_x_2416, v_y_2417)) {
      heff_drop(v_ts_243);
      V v_t_2419 = ({ V a_0 = v_t_241; V a_1 = heff_rfield(v_fu_240, 4); V r_ = (g_heff_2ecompile_2efuse_2eelemF(a_0, a_1)); heff_drop(v_t_241); r_; });
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        HeffT2 v_t_2420 = (g_heff_2ecompile_2efuse_2elastF_24cpr(heff_dup(v_vs_2414)));
        V v_t_2425;
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_x_2424 = v_field_2422;
            v_t_2425 = v_x_2424;
          } else {
            heff_drop(v_field_2422);
            v_t_2425 = ((V)&g_heff_2ecompile_2efuse_2earmGiven_str0);
          }
        }
        HeffT2 v_t_2426 = (g_heff_2ecompile_2efuse_2elastF_24cpr(heff_dup(v_hs_242)));
        V v_t_2431;
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_x_2430 = v_field_2428;
            v_t_2431 = v_x_2430;
          } else {
            heff_drop(v_field_2428);
            v_t_2431 = heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
          }
        }
        V v_m_2432 = (g_heff_2ecompile_2efuse_2erecall(v_fu_240, v_t_2425, v_t_2431, v_b_2415));
        V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_z_245}));
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_MkPair: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_s_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          V v_t_2436 = (g_heff_2ecompile_2efuse_2einitF(v_vs_2414));
          V v_t_2437 = (g_heff_2ecompile_2efuse_2einitF(v_hs_242));
          V v_x_2438 = ({ V a_0 = v_t_2436; V a_1 = v_t_2437; V a_2 = v_x_2434; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_t_2436); heff_drop(v_t_2437); r_; });
          return heff_tag_at_n(v_ru_24e_244_24ELam, TAG_MkPair, 2, (V[]){v_x_2438, v_s_2435});
        }
        default: return heff_nomatch(v_x2_2433);
        }
      } else {
        heff_drop_rec(v_fu_240, 9);
        heff_drop(v_t_2419);
        V v_x_2439 = ({ V a_0 = v_vs_2414; V a_1 = v_hs_242; V a_2 = v_b_2415; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_vs_2414); heff_drop(v_hs_242); r_; });
        return heff_tag_at_n(v_ru_24e_244_24ELam, TAG_MkPair, 2, (V[]){v_x_2439, v_z_245});
      }
    } else {
      heff_drop(v_vs_2414);
      heff_drop(v_b_2415);
      V v_t_2440 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
      V v_t_2441 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
      V v_x_2442 = heff_tag_at_n(v_ru_24e_244_24ELam, TAG_EApp, 2, (V[]){v_t_2440, v_t_2441});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2442, v_z_245});
    }
  }
  case TAG_EApp: {
    V v_ru_24e_244_24EApp = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_2445 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2446 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2447 = heff_tag_at_n(v_ru_24e_244_24EApp, TAG_EApp, 2, (V[]){v_t_2445, v_t_2446});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_z_245});
  }
  case TAG_ELet: {
    V v_ru_24e_244_24ELet = heff_take_reuse_n(v_e_244, 0ULL, 3);
    V v_t_2451 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2452 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_at_n(v_ru_24e_244_24ELet, TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2453 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2451, v_t_2452});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2453, v_z_245});
  }
  case TAG_ERecord: {
    V v_ru_24e_244_24ERecord = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_2456 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2457 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2458 = heff_tag_at_n(v_ru_24e_244_24ERecord, TAG_EApp, 2, (V[]){v_t_2456, v_t_2457});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2458, v_z_245});
  }
  case TAG_EProj: {
    heff_take_n(v_e_244, 0ULL, 4);
    V v_t_2463 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2464 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2465 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2463, v_t_2464});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2465, v_z_245});
  }
  case TAG_ETag: {
    V v_ru_24e_244_24ETag = heff_take_reuse_n(v_e_244, 0ULL, 3);
    V v_t_2469 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2470 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_at_n(v_ru_24e_244_24ETag, TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2471 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2469, v_t_2470});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2471, v_z_245});
  }
  case TAG_EMatch: {
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_2474 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2475 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2476 = heff_tag_at_n(v_ru_24e_244_24EMatch, TAG_EApp, 2, (V[]){v_t_2474, v_t_2475});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2476, v_z_245});
  }
  case TAG_EPrim: {
    V v_ru_24e_244_24EPrim = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_2478 = heff_tag_at_n(v_ru_24e_244_24EPrim, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_2479 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2480 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2478, v_t_2479});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2480, v_z_245});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_244_24EPrimCall = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_2483 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2484 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2485 = heff_tag_at_n(v_ru_24e_244_24EPrimCall, TAG_EApp, 2, (V[]){v_t_2483, v_t_2484});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2485, v_z_245});
  }
  case TAG_ECall: {
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_2488 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_2489 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2490 = heff_tag_at_n(v_ru_24e_244_24ECall, TAG_EApp, 2, (V[]){v_t_2488, v_t_2489});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2490, v_z_245});
  }
  case TAG_EInt: {
    V v_ru_24e_244_24EInt = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_2492 = heff_tag_at_n(v_ru_24e_244_24EInt, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_2493 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2494 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2492, v_t_2493});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2494, v_z_245});
  }
  case TAG_EFloat: {
    V v_ru_24e_244_24EFloat = heff_take_reuse_na(v_e_244, 0ULL, 1);
    V v_t_2496 = heff_tag_at_n(v_ru_24e_244_24EFloat, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_2497 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_2498 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2496, v_t_2497});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2498, v_z_245});
  }
  case TAG_EStr: {
    V v_ru_24e_244_24EStr = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_24100 = heff_tag_at_n(v_ru_24e_244_24EStr, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_24101 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24102 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24100, v_t_24101});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24102, v_z_245});
  }
  case TAG_EBytes: {
    V v_ru_24e_244_24EBytes = heff_take_reuse_n(v_e_244, 0ULL, 1);
    V v_t_24104 = heff_tag_at_n(v_ru_24e_244_24EBytes, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_24105 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24106 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24104, v_t_24105});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24106, v_z_245});
  }
  case TAG_EFixed: {
    V v_ru_24e_244_24EFixed = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_24109 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_24110 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24111 = heff_tag_at_n(v_ru_24e_244_24EFixed, TAG_EApp, 2, (V[]){v_t_24109, v_t_24110});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24111, v_z_245});
  }
  case TAG_EFloat32: {
    V v_ru_24e_244_24EFloat32 = heff_take_reuse_na(v_e_244, 0ULL, 1);
    V v_t_24113 = heff_tag_at_n(v_ru_24e_244_24EFloat32, TAG_EGlobal, 1, (V[]){heff_dup(heff_rfield(v_fu_240, 0))});
    V v_t_24114 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24115 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24113, v_t_24114});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24115, v_z_245});
  }
  case TAG_EAbandon: {
    V v_t_24116 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_24117 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24118 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_24116, v_t_24117});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24118, v_z_245});
  }
  case TAG_EFix: {
    V v_ru_24e_244_24EFix = heff_take_reuse_n(v_e_244, 0ULL, 2);
    V v_t_24121 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_take_field(v_fu_240, 0)});
    V v_t_24122 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_240, 2), heff_tag_n(TAG_ETag, 3, (V[]){v_t_241, v_hs_242, v_ts_243}), heff_get_n(v_fu_240, 8, 9)));
    V v_x_24123 = heff_tag_at_n(v_ru_24e_244_24EFix, TAG_EApp, 2, (V[]){v_t_24121, v_t_24122});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24123, v_z_245});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2efuse_2earmGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2earmGiven(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str0, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str2, 2, "$f");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str3, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str5, 2, "$f");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str6, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efusedOf_str8, 2, "$f");
V g_heff_2ecompile_2efuse_2efusedOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam2(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam2, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam3, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam4(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam4, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam5(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam5, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam6(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam6, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam8(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam8, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam9(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam9, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam10, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam11(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam11, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2efusedOf_lam13(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam13, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam14(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam14, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam15(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam15, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam16(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam16, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam17(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam17, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam18(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam18, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam19, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam20(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam20, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam21(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam21, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam22(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam22, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam23(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam23, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam24(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam24, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam25(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam25, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam26(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam26, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam27(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam27, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam28(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam28, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam29(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam29, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam30(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam30, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam31(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam31, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam32(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam32, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam33(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam33, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam34(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam34, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam35(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam35, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam36(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam36, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam37(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam37, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam38(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam38, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam39(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam39, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam40(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam40, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam41(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam41, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam42(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam42, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam43(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam43, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam44(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam44, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam45(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam45, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam46(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam46, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam47(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam47, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam48(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam48, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam49(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam49, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam50(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam50, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam51(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam51, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam52(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam52, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam53(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam53, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam54(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam54, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam55(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam55, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam56(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam56, 1, 0};
V g_heff_2ecompile_2efuse_2efusedOf_lam57(V self, V *args); static Clo g_heff_2ecompile_2efuse_2efusedOf_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_lam57, 1, 0};
Clo g_heff_2ecompile_2efuse_2efusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efusedOf_entry, 6, 0};

V g_heff_2ecompile_2efuse_2efusedOf(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_cl_244, V v_pl_245) {
top: ;
  switch (heff_tag_of(v_cl_244)) {
  case TAG_EVar: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam0_clo);
  }
  case TAG_EGlobal: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam1_clo);
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_cl_244, 0);
    V v_cl2_2411 = heff_field(v_cl_244, 1);
    heff_take_n(v_cl_244, 3ULL, 2);
    switch (heff_tag_of(v_cl2_2411)) {
    case TAG_EVar: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam2_clo);
    }
    case TAG_EGlobal: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam3_clo);
    }
    case TAG_ELam: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam4_clo);
    }
    case TAG_EApp: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam5_clo);
    }
    case TAG_ELet: {
      heff_take_n(v_cl2_2411, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam6_clo);
    }
    case TAG_ERecord: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam7_clo);
    }
    case TAG_EProj: {
      heff_take_n(v_cl2_2411, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam8_clo);
    }
    case TAG_ETag: {
      heff_take_n(v_cl2_2411, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam9_clo);
    }
    case TAG_EMatch: {
      V v_arms_2439 = heff_field(v_cl2_2411, 1);
      heff_take_n(v_cl2_2411, 2ULL, 2);
      switch (heff_tag_of(v_pl_245)) {
      case TAG_EVar: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam10_clo);
      }
      case TAG_EGlobal: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam11_clo);
      }
      case TAG_ELam: {
        V v_ys_2444 = heff_field(v_pl_245, 0);
        V v_pb_2445 = heff_field(v_pl_245, 1);
        heff_take_n(v_pl_245, 3ULL, 2);
        V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
        V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2444));
        V v_j_2448 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_str0), v_c_240, MK_INT(0LL), 5);
        V v_t_2450;
        if (heff_intLt_c_lent(v_j_2448, MK_INT(0LL), 2)) {
          heff_drop(v_j_2448);
          v_t_2450 = heff_dup(v_c_240);
        } else {
          v_t_2450 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2448, 6);
        }
        V v_t_2451 = heff_strAppend(heff_dup(v_c_240), heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str1), heff_dup(v_p_242)));
        V v_t_2452 = ({ V a_0 = v_t_2451; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2451); r_; });
        V v_t_2453 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str2), v_t_2452));
        V v_t_2454 = (g_list_2emap_24f505181408x1813697659(heff_dup(heff_rfield(v_cs_241, 1)), heff_dup(v_xs_2410)));
        V v_t_2455 = heff_rec_n(9, shape_c__arity__at__arms__goes__p__parity__cp__cvars, (V[]){heff_dup(v_c_240), v_t_2446, heff_dup(heff_rfield(v_cs_241, 1)), v_arms_2439, heff_dup(heff_rfield(v_cs_241, 3)), heff_dup(v_p_242), v_t_2447, v_t_2453, v_t_2454});
        V v_m_2456 = heff_tr(g_heff_2ecompile_2efuse_2eatEnds(v_t_2455, v_pb_2445));
        return heff_clo_n(g_heff_2ecompile_2efuse_2efusedOf_lam12, 1, 6, (V[]){v_m_2456, v_c_240, v_p_242, v_ys_2444, v_cs_241, v_xs_2410});
      }
      case TAG_EApp: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam13_clo);
      }
      case TAG_ELet: {
        heff_take_n(v_pl_245, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam14_clo);
      }
      case TAG_ERecord: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam15_clo);
      }
      case TAG_EProj: {
        heff_take_n(v_pl_245, 0ULL, 4);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam16_clo);
      }
      case TAG_ETag: {
        heff_take_n(v_pl_245, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam17_clo);
      }
      case TAG_EMatch: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam18_clo);
      }
      case TAG_EPrim: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam19_clo);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam20_clo);
      }
      case TAG_ECall: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam21_clo);
      }
      case TAG_EInt: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam22_clo);
      }
      case TAG_EFloat: {
        heff_take_na(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam23_clo);
      }
      case TAG_EStr: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam24_clo);
      }
      case TAG_EBytes: {
        heff_take_n(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam25_clo);
      }
      case TAG_EFixed: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam26_clo);
      }
      case TAG_EFloat32: {
        heff_take_na(v_pl_245, 0ULL, 1);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam27_clo);
      }
      case TAG_EAbandon: {
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam28_clo);
      }
      case TAG_EFix: {
        heff_take_n(v_pl_245, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_p_242);
        heff_drop(v_xs_2410);
        heff_drop(v_arms_2439);
        return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam29_clo);
      }
      default: return heff_nomatch(v_pl_245);
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam30_clo);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam31_clo);
    }
    case TAG_ECall: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam32_clo);
    }
    case TAG_EInt: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam33_clo);
    }
    case TAG_EFloat: {
      heff_take_na(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam34_clo);
    }
    case TAG_EStr: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam35_clo);
    }
    case TAG_EBytes: {
      heff_take_n(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam36_clo);
    }
    case TAG_EFixed: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam37_clo);
    }
    case TAG_EFloat32: {
      heff_take_na(v_cl2_2411, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam38_clo);
    }
    case TAG_EAbandon: {
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam39_clo);
    }
    case TAG_EFix: {
      heff_take_n(v_cl2_2411, 0ULL, 2);
      heff_drop(v_c_240);
      heff_drop_rec(v_cs_241, 5);
      heff_drop(v_p_242);
      heff_drop(v_pl_245);
      heff_drop(v_xs_2410);
      return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam40_clo);
    }
    default: return heff_nomatch(v_cl2_2411);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam41_clo);
  }
  case TAG_ELet: {
    heff_take_n(v_cl_244, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam42_clo);
  }
  case TAG_ERecord: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam43_clo);
  }
  case TAG_EProj: {
    heff_take_n(v_cl_244, 0ULL, 4);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam44_clo);
  }
  case TAG_ETag: {
    heff_take_n(v_cl_244, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam45_clo);
  }
  case TAG_EMatch: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam46_clo);
  }
  case TAG_EPrim: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam47_clo);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam48_clo);
  }
  case TAG_ECall: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam49_clo);
  }
  case TAG_EInt: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam50_clo);
  }
  case TAG_EFloat: {
    heff_take_na(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam51_clo);
  }
  case TAG_EStr: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam52_clo);
  }
  case TAG_EBytes: {
    heff_take_n(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam53_clo);
  }
  case TAG_EFixed: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam54_clo);
  }
  case TAG_EFloat32: {
    heff_take_na(v_cl_244, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam55_clo);
  }
  case TAG_EAbandon: {
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam56_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_cl_244, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_pl_245);
    return ((V)&g_heff_2ecompile_2efuse_2efusedOf_lam57_clo);
  }
  default: return heff_nomatch(v_cl_244);
  }
}
V g_heff_2ecompile_2efuse_2efusedOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2efusedOf(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2efusedOf_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_247});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam1(V self, V *args) {
  V v_s_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_249});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2413});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam3(V self, V *args) {
  V v_s_2415 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2415});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam4(V self, V *args) {
  V v_s_2418 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2418});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam5(V self, V *args) {
  V v_s_2421 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2421});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam6(V self, V *args) {
  V v_s_2425 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2425});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam7(V self, V *args) {
  V v_s_2428 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2428});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam8(V self, V *args) {
  V v_s_2433 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2433});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam9(V self, V *args) {
  V v_s_2437 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2437});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam10(V self, V *args) {
  V v_s_2441 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2441});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam11(V self, V *args) {
  V v_s_2443 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2443});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam12(V self, V *args) {
  V v_s_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_ys_2444 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_xs_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_s_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    V v_j_2461 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_str3), v_c_240, MK_INT(0LL), 5);
    V v_t_2463;
    if (heff_intLt_c_lent(v_j_2461, MK_INT(0LL), 2)) {
      heff_drop(v_j_2461);
      v_t_2463 = heff_dup(v_c_240);
    } else {
      v_t_2463 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2461, 6);
    }
    V v_t_2464 = heff_strAppend(heff_dup(v_c_240), heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str4), heff_dup(v_p_242)));
    V v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2464); r_; });
    V v_key_2466 = heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str5), v_t_2465));
    V v_j_2467 = heff_strFind_lent(((V)&g_heff_2ecompile_2efuse_2efusedOf_str6), v_c_240, MK_INT(0LL), 5);
    V v_t_2469;
    if (heff_intLt_c_lent(v_j_2467, MK_INT(0LL), 2)) {
      heff_drop(v_j_2467);
      v_t_2469 = heff_dup(v_c_240);
    } else {
      v_t_2469 = heff_strSlice_lent(v_c_240, MK_INT(0LL), v_j_2467, 6);
    }
    V v_t_2470 = heff_strAppend(v_c_240, heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str7), v_p_242));
    V v_t_2471 = ({ V a_0 = v_t_2470; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ecompile_2espec_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2470); r_; });
    V v_name_2472 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efusedOf_str8), v_t_2471));
    V v_t_2473 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_ys_2444, heff_get_n(v_cs_241, 1, 5), v_xs_2410));
    V v_body_2474 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2473, v_x_2459});
    V v_x_2475 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_2466, v_name_2472, v_body_2474})});
    return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){v_x_2475, v_s_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2efuse_2efusedOf_lam13(V self, V *args) {
  V v_s_2478 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2478});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam14(V self, V *args) {
  V v_s_2482 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2482});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam15(V self, V *args) {
  V v_s_2485 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2485});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam16(V self, V *args) {
  V v_s_2490 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2490});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam17(V self, V *args) {
  V v_s_2494 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2494});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam18(V self, V *args) {
  V v_s_2497 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2497});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam19(V self, V *args) {
  V v_s_2499 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2499});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam20(V self, V *args) {
  V v_s_24102 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24102});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam21(V self, V *args) {
  V v_s_24105 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24105});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam22(V self, V *args) {
  V v_s_24107 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24107});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam23(V self, V *args) {
  V v_s_24109 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24109});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam24(V self, V *args) {
  V v_s_24111 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24111});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam25(V self, V *args) {
  V v_s_24113 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24113});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam26(V self, V *args) {
  V v_s_24116 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24116});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam27(V self, V *args) {
  V v_s_24118 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24118});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam28(V self, V *args) {
  V v_s_24119 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24119});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam29(V self, V *args) {
  V v_s_24122 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24122});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam30(V self, V *args) {
  V v_s_24124 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24124});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam31(V self, V *args) {
  V v_s_24127 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24127});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam32(V self, V *args) {
  V v_s_24130 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24130});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam33(V self, V *args) {
  V v_s_24132 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24132});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam34(V self, V *args) {
  V v_s_24134 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24134});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam35(V self, V *args) {
  V v_s_24136 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24136});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam36(V self, V *args) {
  V v_s_24138 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24138});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam37(V self, V *args) {
  V v_s_24141 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24141});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam38(V self, V *args) {
  V v_s_24143 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24143});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam39(V self, V *args) {
  V v_s_24144 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24144});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam40(V self, V *args) {
  V v_s_24147 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24147});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam41(V self, V *args) {
  V v_s_24150 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24150});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam42(V self, V *args) {
  V v_s_24154 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24154});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam43(V self, V *args) {
  V v_s_24157 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24157});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam44(V self, V *args) {
  V v_s_24162 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24162});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam45(V self, V *args) {
  V v_s_24166 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24166});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam46(V self, V *args) {
  V v_s_24169 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24169});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam47(V self, V *args) {
  V v_s_24171 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24171});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam48(V self, V *args) {
  V v_s_24174 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24174});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam49(V self, V *args) {
  V v_s_24177 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24177});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam50(V self, V *args) {
  V v_s_24179 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24179});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam51(V self, V *args) {
  V v_s_24181 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24181});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam52(V self, V *args) {
  V v_s_24183 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24183});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam53(V self, V *args) {
  V v_s_24185 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24185});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam54(V self, V *args) {
  V v_s_24188 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24188});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam55(V self, V *args) {
  V v_s_24190 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24190});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam56(V self, V *args) {
  V v_s_24191 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24191});
}
V g_heff_2ecompile_2efuse_2efusedOf_lam57(V self, V *args) {
  V v_s_24194 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24194});
}
HEFF_LIT(g_heff_2ecompile_2efuse_2emakeFused_str0, 0, "");
V g_heff_2ecompile_2efuse_2emakeFused_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2emakeFused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2emakeFused_entry, 4, 0};

V g_heff_2ecompile_2efuse_2emakeFused(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2efuse_2enthF_24cpr(heff_dup(heff_rfield(v_cs_241, 1)), heff_dup(heff_rfield(v_cs_241, 0))));
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_246);
      v_t_249 = ((V)&g_heff_2ecompile_2efuse_2emakeFused_str0);
    }
  }
  V v_t_2410 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_249}), heff_dup(heff_rfield(v_cs_241, 2))});
  V v_e_2411 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_cs_241, 0)), v_t_2410});
  return heff_clo_n(g_heff_2ecompile_2efuse_2emakeFused_lam0, 1, 5, (V[]){v_e_2411, v_ps_243, v_c_240, v_cs_241, v_p_242});
}
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2emakeFused(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2emakeFused_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_e_2411 = heff_env(self)[0];
  V v_ps_243 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2413 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), heff_take_field(v_s_2412, 0), v_e_2411));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_e_2416 = v_field_2414;
    V v_n_2417 = v_field_2415;
    V v_t_2418 = heff_take_field(v_s_2412, 1);
    V v_t_2419 = heff_take_field(v_s_2412, 2);
    V v_t_2420 = heff_take_field(v_s_2412, 3);
    V v_t_2421 = heff_take_field(v_s_2412, 4);
    V v_t_2422 = heff_get_n(v_s_2412, 5, 6);
    V v_t_2423 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(heff_rfield(v_ps_243, 0)), heff_dup(heff_rfield(v_ps_243, 1))});
    HeffT2 v_t_2424 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), v_n_2417, v_t_2423));
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v_e_2427 = v_field_2425;
      V v_n_2428 = v_field_2426;
      V v_m_2429 = ({ V a_0 = v_c_240; V a_1 = v_cs_241; V a_2 = v_p_242; V a_3 = v_ps_243; V a_4 = heff_dup(v_e_2416); V a_5 = heff_dup(v_e_2427); V r_ = (g_heff_2ecompile_2efuse_2efusedOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_rec(v_ps_243, 3); r_; });
      V v_x2_2430 = heff_tr(heff_call(v_m_2429, 1, (V[]){heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_n_2428, v_t_2418, v_t_2419, v_t_2420, v_t_2421, v_t_2422})}));
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_MkPair: {
        V v_x_2431 = heff_field(v_x2_2430, 0);
        V v_s_2432 = heff_field(v_x2_2430, 1);
        V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
        V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2416, NTAG(TAG_Nil)});
        V v_t_2434 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2433));
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2427, NTAG(TAG_Nil)});
        V v_t_2436 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2435));
        V v_lim_2437 = heff_intAdd(heff_intAdd(v_t_2434, v_t_2436), MK_INT(64LL));
        V v_x_2442;
        switch (heff_tag_of(v_x_2431)) {
        case TAG_Nothing: {
          heff_drop(v_lim_2437);
          v_x_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_d_2438 = heff_field(v_x_2431, 0);
          V v_ru_24x_2431_24Just = heff_take_reuse_n(v_x_2431, 1ULL, 1);
          V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_2438, 2)), NTAG(TAG_Nil)});
          V v_x_2440 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2437), MK_INT(0LL), v_t_2439));
          if (heff_intLt_c(v_lim_2437, v_x_2440)) {
            heff_drop_rec(v_d_2438, 3);
            heff_drop_cell(v_ru_24x_2431_24Just, 1);
            v_x_2442 = NTAG(TAG_Nothing);
          } else {
            v_x_2442 = heff_tag_at_n(v_ru_24x_2431_24Just, TAG_Just, 1, (V[]){v_d_2438});
          }
          break;
        }
        default: heff_nomatch(v_x_2431);
        }
        return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){v_x_2442, v_s_2432});
      }
      default: return heff_nomatch(v_x2_2430);
      }
    }
  }
}
Clo g_heff_2ecompile_2efuse_2efuseKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseKnown_entry, 8, 0};

V g_heff_2ecompile_2efuse_2efuseKnown(V v_sg_240, V v_c_241, V v_args_242, V v_p_243, V v_bs_244, V v_x6_245, V v_x7_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop(v_args_242);
    heff_drop(v_p_243);
    heff_drop(v_bs_244);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
  }
  case TAG_Just: {
    V v_cs_248 = heff_field(v_x6_245, 0);
    switch (heff_tag_of(v_x7_246)) {
    case TAG_Nothing: {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop(v_args_242);
      heff_drop(v_p_243);
      heff_drop(v_bs_244);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
    }
    case TAG_Just: {
      V v_ps_249 = heff_field(v_x7_246, 0);
      V v_t_2410 = (g_heff_2ecompile_2efuse_2emayFuse(v_sg_240, heff_dup(v_c_241), heff_dup(v_cs_248), heff_dup(v_ps_249), heff_dup(v_args_242), v_bs_244));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        return (g_heff_2ecompile_2efuse_2efuseWith(v_c_241, heff_dup(v_cs_248), v_p_243, heff_dup(v_ps_249), v_args_242, v_bs_244, v_z_247));
      } else {
        heff_drop(v_c_241);
        heff_drop(v_args_242);
        heff_drop(v_p_243);
        heff_drop(v_bs_244);
        heff_drop(v_t_2410);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
      }
    }
    default: return heff_nomatch(v_x7_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2ecompile_2efuse_2efuseKnown(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7]); heff_drop(a5); heff_drop(a6); return r;
}
Clo g_heff_2ecompile_2efuse_2efuseOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseOn_entry, 5, 0};

V g_heff_2ecompile_2efuse_2efuseOn(V v_sg_240, V v_c_241, V v_args_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_sg_240);
    heff_drop(v_c_241);
    heff_drop(v_args_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_244});
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_x4_243, 0);
    HeffT2 v_t_246 = (g_heff_2ecompile_2efuse_2eglobalCall_24cpr(heff_dup(v_e_245)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_248;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_MkPair: {
          V v_p_2411 = heff_field(v_it1_2410, 0);
          V v_bs_2412 = heff_field(v_it1_2410, 1);
          heff_take_n(v_it1_2410, 3ULL, 2);
          V v_t_2413 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_z_244, 1), v_c_241));
          V v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411(heff_rfield(v_z_244, 2), v_p_2411));
          return ({ V a_0 = v_sg_240; V a_1 = v_c_241; V a_2 = v_args_242; V a_3 = v_p_2411; V a_4 = v_bs_2412; V a_5 = v_t_2413; V a_6 = v_t_2414; V a_7 = v_z_244; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
        }
        default: return heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_sg_240);
        heff_drop(v_c_241);
        heff_drop(v_args_242);
        heff_drop(v_field_248);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_244});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2efuseOn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2efuseOn(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2efuse_2esites_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2esites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esites_entry, 2, 0};

V g_heff_2ecompile_2efuse_2esites(V v_sg_240, V v_e_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2esites_clo), 1, (V[]){heff_dup(v_sg_240)}));
  V v_m_243 = (g_heff_2ecompile_2efuse_2ekidsF(v_t_242, v_e_241));
  return heff_clo_n(g_heff_2ecompile_2efuse_2esites_lam0, 1, 2, (V[]){v_m_243, v_sg_240});
}
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esites(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2esites_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_s_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_m_248 = heff_tr(g_heff_2ecompile_2efuse_2ehere(heff_dup(v_sg_240), heff_dup(v_x_246)));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_247}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_go_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2esites_clo), 1, (V[]){v_sg_240}));
      switch (heff_tag_of(v_x_2410)) {
      case TAG_Nothing: {
        heff_drop(v_go_2412);
        return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, v_s_2411});
      }
      case TAG_Just: {
        V v_e2_2413 = heff_field(v_x_2410, 0);
        heff_take_n(v_x_2410, 1ULL, 1);
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
        V f_ = v_go_2412;
        heff_room[0] = v_e2_2413;
        heff_room[1] = v_s_2411;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_x_2410);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}