// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_clo;
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo;
V g_heff_2esyntax_2ecst_2ecatchF(V, V, V);
V g_heff_2esyntax_2ecst_2ecatchF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecatchF_clo;
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclaredMore(V);
V g_heff_2esyntax_2ecst_2edeclaredMore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredMore_clo;
V g_heff_2esyntax_2ecst_2edeclaredMoreGo(V, V);
V g_heff_2esyntax_2ecst_2edeclaredMoreGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredMoreGo_clo;
V g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(V, V, V);
V g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258(V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo;
V g_heff_2esyntax_2ecst_2escrutineeF(V, V, V);
V g_heff_2esyntax_2ecst_2escrutineeF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2escrutineeF_clo;
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(V, V);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etryCaught(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2etryCaught_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryCaught_clo;
V g_heff_2esyntax_2ecst_2etryF(V, V, V);
V g_heff_2esyntax_2ecst_2etryF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryF_clo;
V g_heff_2esyntax_2ecst_2etryPartF(V, V, V);
V g_heff_2esyntax_2ecst_2etryPartF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryPartF_clo;
V g_heff_2esyntax_2ecst_2etryTypeF(V, V, V);
V g_heff_2esyntax_2ecst_2etryTypeF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryTypeF_clo;
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(V, V, V, V);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2enext_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_entry, 2, 0};

V g_heff_2esyntax_2ecst_2enext(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam0, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enext(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_toks_248 = heff_take_field(v_s_247, 0);
  V v_i_249 = heff_take_field(v_s_247, 1);
  V v_top_2410 = heff_take_field(v_s_247, 2);
  V v_stack_2411 = heff_take_field(v_s_247, 3);
  V v_start_2412 = heff_get_n(v_s_247, 4, 5);
  return heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_248, heff_intAdd(v_i_249, MK_INT(1LL)), v_top_2410, v_stack_2411, v_start_2412});
}
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_k_241;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(v_malg_243, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam3, 1, 2, (V[]){v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2enext_lam1_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam2, 1, 4, (V[]){v_malg_243, v_bind_242, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyGo_entry, 4, 0};

V g_heff_2esyntax_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_p_240})));
}
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_x_244);
    heff_drop(v_p_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_244);
    V v_t_249 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_247)));
    V v_x1_2410 = heff_bool(((heff_dup(v_t_249) == NTAG(TAG_True)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str0)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str1)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str2))))));
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_t_249);
    if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop_rec(v_hd_242, 3);
      heff_drop(v_x1_2410);
      V v_x_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      V f_ = v_k_243;
      args[0] = v_x_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x1_2410);
      V f_ = heff_dup(v_p_240);
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam2, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam1, 1, 5, (V[]){v_x_244, v_acc_241, v_k_243, v_p_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_247, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam5, 1, 3, (V[]){v_k_242, v_x_247, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_text_2411 = heff_env(self)[0];
  V v_kind_2412 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2ecst_2eexprF_str0), 2) && (heff_strEq_c_lent(v_kind_2412, ((V)&g_heff_2esyntax_2ecst_2eexprF_str1), 2) && !(heff_dup(v_x_2413) == NTAG(TAG_True))))) {
    heff_drop(v_x_2413);
    heff_drop(v_text_2411);
    heff_drop(v_kind_2412);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_247})));
  } else {
    heff_drop(v_x_2413);
    heff_drop(v_text_2411);
    heff_drop(v_kind_2412);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_text_2411 = heff_take_field(v_x_2410, 1);
  V v_kind_2412 = heff_get_n(v_x_2410, 0, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam3, 1, 6, (V[]){v_text_2411, v_kind_2412, v_hd_241, v_g_240, v_k_242, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam2, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2esyntax_2ecst_2eexprHead(heff_dup(v_g_240), v_x_245));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam1, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam0, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2419}), v_acc_241});
  V v_x_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2420));
  V f_ = v_k_243;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2426}), v_acc_241});
  V v_x_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2427));
  V f_ = v_k_243;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2429}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2430, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2431}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2432, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_text_2417 = heff_take_field(v_x_2416, 1);
  V v_kind_2418 = heff_get_n(v_x_2416, 0, 9);
  if (heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str1), 2)) {
    heff_drop(v_text_2417);
    heff_drop(v_kind_2418);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_242;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam4, 1, 3, (V[]){v_x_2413, v_acc_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(v_kind_2418, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str2))) {
      V v_t_2422 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_2417}));
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str3), NTAG(TAG_Nil)});
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str5), v_t_2423})});
      V v_t_2425 = ({ V a_0 = v_t_2422; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str6), v_t_2424}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_t_2425);
        V f_ = heff_get_n(v_g_240, 0, 17);
        heff_room[0] = v_hd_242;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam5, 1, 3, (V[]){v_x_2413, v_acc_241, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2425);
        V f_ = heff_dup(heff_rfield(v_g_240, 3));
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam6, 1, 5, (V[]){v_x_2413, v_acc_241, v_g_240, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_text_2417);
      V f_ = heff_dup(heff_rfield(v_g_240, 3));
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam7, 1, 5, (V[]){v_x_2413, v_acc_241, v_g_240, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam3, 1, 5, (V[]){v_g_240, v_hd_242, v_x_2413, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_kind_247 = heff_env(self)[0];
  V v_text_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_acc_241 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412;
  if (heff_strEq_c(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str0))) {
    V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_248}));
    V v_x1_2411 = ({ V a_0 = v_t_2410; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2412 = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
    heff_drop(v_x1_2411);
  } else {
    heff_drop(v_text_248);
    v_t_2412 = NTAG(TAG_False);
  }
  if (((heff_dup(v_t_2412) == NTAG(TAG_True)) && !(heff_dup(v_x_249) == NTAG(TAG_True)))) {
    heff_drop(v_x_249);
    heff_drop(v_t_2412);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam2, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
  } else {
    heff_drop(v_x_249);
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 17);
    heff_drop(v_t_2412);
    V v_x_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam1, 1, 6, (V[]){v_kind_247, v_text_248, v_hd_242, v_g_240, v_acc_241, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2escrutineeF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2escrutineeF_str1, 2, "<-");
V g_heff_2esyntax_2ecst_2escrutineeF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2escrutineeF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2escrutineeF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2escrutineeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2escrutineeF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2escrutineeF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2escrutineeF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2escrutineeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2escrutineeF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2escrutineeF_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EArrow, 2, (V[]){v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2escrutineeF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2escrutineeF_lam2, 1, 2, (V[]){v_k_242, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2escrutineeF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2escrutineeF_str0), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2escrutineeF_str1), 2))) {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2escrutineeF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
  } else {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2etryF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etryF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etryF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etryF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etryF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etryF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_x_243; V a_1 = v_x_244; V a_2 = v_x_245; V a_3 = v_x_247; V a_4 = v_hd_241; V a_5 = v_k_242; V r_ = (g_heff_2esyntax_2ecst_2etryCaught(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_247); r_; });
}
V g_heff_2esyntax_2ecst_2etryF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2ecatchF_clo), 1, (V[]){v_g_240}));
  return (g_heff_2esyntax_2ecst_2etryPartF(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam3, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(v_g_240, 14)), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2etryTypeF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str1, 1, "}");
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(V v_o_240, V v_r_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0, 1, 4, (V[]){v_hd_242, v_o_240, v_r_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkSep: {
    V v_items_249 = heff_field(v_x_247, 0);
    V v_seps_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    v_t_2411 = heff_tag_n(TAG_Update, 6, (V[]){v_o_240, v_r_241, v_x_244, v_items_249, v_seps_2410, v_x_248});
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_243;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str1), v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3, 1, 5, (V[]){v_x_247, v_o_240, v_r_241, v_x_244, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str0); V a_1 = v_t_246; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_242); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry, 7, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_hd_246) {
top: ;
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sep_2416 = heff_env(self)[0];
  V v_items_2417 = heff_env(self)[1];
  V v_seps_2418 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2416, v_items_2417, v_x_2424, v_seps_2418, heff_dup(v_hd_2419), v_k_2420, v_hd_2419));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sep_2416 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_items_2417 = heff_env(self)[2];
  V v_seps_2418 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2423, 1, 9), heff_dup(v_sep_2416))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2419), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6, 1, 5, (V[]){v_sep_2416, v_items_2417, v_seps_2418, v_hd_2419, v_k_2420})));
  } else {
    heff_drop(v_sep_2416);
    heff_drop_rec(v_hd_2419, 3);
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2417));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2418));
    V v_x_2427 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2425, v_t_2426});
    V f_ = v_k_2420;
    args[0] = v_x_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2416 = v_lit_240;
  V v_items_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2414, v_x_2415}), v_lit_241});
  V v_seps_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2419 = v_lit_244;
  V v_k_2420 = v_lit_245;
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2419, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_2419, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5, 1, 5, (V[]){v_sep_2416, v_hd_2419, v_items_2417, v_seps_2418, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2414, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sep_2428 = heff_env(self)[0];
  V v_items_2429 = heff_env(self)[1];
  V v_seps_2430 = heff_env(self)[2];
  V v_hd_2431 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2428, v_items_2429, v_x_2436, v_seps_2430, heff_dup(v_hd_2431), v_k_2432, v_hd_2431));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_sep_2428 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_items_2429 = heff_env(self)[2];
  V v_seps_2430 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2435, 1, 9), heff_dup(v_sep_2428))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2431), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8, 1, 5, (V[]){v_sep_2428, v_items_2429, v_seps_2430, v_hd_2431, v_k_2432})));
  } else {
    heff_drop(v_sep_2428);
    heff_drop_rec(v_hd_2431, 3);
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2429));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2430));
    V v_x_2439 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2437, v_t_2438});
    V f_ = v_k_2432;
    args[0] = v_x_2439;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_kind_2411 = heff_env(self)[0];
  V v_text_2412 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_244 = heff_env(self)[8];
  V v_lit_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str0), 2) && ((heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str1), 2) || heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str2), 2)) && !(heff_dup(v_x_2413) == NTAG(TAG_True))))) {
    heff_drop(v_x_2413);
    heff_drop(v_kind_2411);
    heff_drop(v_text_2412);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
  } else {
    heff_drop(v_x_2413);
    heff_drop(v_kind_2411);
    heff_drop(v_text_2412);
    heff_drop_rec(v_hd_246, 3);
    V v_sep_2428 = v_lit_240;
    V v_items_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
    V v_seps_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
    V v_hd_2431 = v_lit_244;
    V v_k_2432 = v_lit_245;
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2431, 2)), 1, (V[]){v_t_2433}));
    V f_ = heff_dup(heff_rfield(v_hd_2431, 1));
    heff_room[0] = v_t_2434;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7, 1, 5, (V[]){v_sep_2428, v_hd_2431, v_items_2429, v_seps_2430, v_k_2432});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_kind_2411 = heff_take_field(v_x_2410, 0);
  V v_text_2412 = heff_get_n(v_x_2410, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2, 1, 10, (V[]){v_kind_2411, v_text_2412, v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2410, v_x_2411}), NTAG(TAG_Nil)});
  V v_t_2413 = (g_prelude_2e_2b_2b(v_x_243, v_t_2412));
  V v_x_2414 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_t_2413});
  V f_ = v_k_241;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5, 1, 4, (V[]){v_x_2410, v_x_243, v_x_242, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_kind_247 = heff_env(self)[0];
  V v_text_248 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str0), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str1), 2)) && !(heff_dup(v_x_249) == NTAG(TAG_True))))) {
    heff_drop(v_x_249);
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4, 1, 4, (V[]){v_hd_240, v_x_243, v_x_242, v_k_241})));
  } else {
    heff_drop(v_x_249);
    heff_drop(v_kind_247);
    heff_drop(v_text_248);
    heff_drop_rec(v_hd_240, 3);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Nil: {
      v_t_2417 = v_x_242;
      break;
    }
    case TAG_Cons: {
      v_t_2417 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_x_243});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V f_ = v_k_241;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3, 1, 6, (V[]){v_kind_247, v_text_248, v_hd_240, v_x_243, v_x_242, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2, 1, 4, (V[]){v_hd_240, v_x_243, v_x_242, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str12, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str14, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str15, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str16, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str17, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str18, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str19, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str20, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str21, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str22, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str24, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str25, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str26, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str27, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str28, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str29, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str30, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str31, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str32, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str33, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str34, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str35, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str36, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str39, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam8(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(V v_t_240) {
top: ;
  V v_kind_241 = heff_take_field(v_t_240, 0);
  V v_text_242 = heff_take_field(v_t_240, 1);
  V v_start_243 = heff_take_field(v_t_240, 3);
  V v_end_244 = heff_get_n(v_t_240, 4, 9);
  V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_kind_241)}));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str2), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str4), v_t_247})});
  V v_t_249 = ({ V a_0 = v_t_245; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str5), v_t_248}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2420 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_249);
    if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str6), 2)) {
      V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_242)}));
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str7), NTAG(TAG_Nil)});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str9), v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str11), v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str13), v_t_2413})});
      V v_t_2415 = ({ V a_0 = v_t_2410; V a_1 = v_t_2414; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2414, 2); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        v_t_2420 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2415);
        HeffT2 v_t_2416 = (g_list_2efind_24s1896676244x1358329894_24cpr(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str14), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str15), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str16), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str17), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str18), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str19), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str20), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str21), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str22), v_text_242, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          v_t_2420 = heff_bool(((v_tag_2417 == ((int64_t)0ULL)) && ({ V v_x_2419 = heff_dup(v_field_2418); int c_ = 1; heff_drop(v_x_2419); c_; })));
          heff_drop(v_field_2418);
        }
      }
    } else {
      v_t_2420 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_kind_241);
    heff_drop(v_text_242);
    heff_drop(v_start_243);
    heff_drop(v_end_244);
    heff_drop(v_t_2420);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0_clo);
  } else {
    heff_drop(v_t_2420);
    if ((heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str23), 2) && heff_strEq_c_lent(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str24), 2))) {
      heff_drop(v_kind_241);
      heff_drop(v_text_242);
      heff_drop(v_start_243);
      heff_drop(v_end_244);
      return ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo);
    } else {
      if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str25), 2)) {
        heff_drop(v_kind_241);
        heff_drop(v_text_242);
        heff_drop(v_start_243);
        heff_drop(v_end_244);
        return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2_clo);
      } else {
        if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str26), 2)) {
          heff_drop(v_kind_241);
          heff_drop(v_text_242);
          heff_drop(v_start_243);
          heff_drop(v_end_244);
          return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5_clo);
        } else {
          if ((heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str27), 2) && heff_strEq_c_lent(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str28), 2))) {
            heff_drop(v_kind_241);
            heff_drop(v_text_242);
            heff_drop(v_start_243);
            heff_drop(v_end_244);
            return ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo);
          } else {
            if ((heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str29), 2) && heff_strEq_c_lent(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str30), 2))) {
              heff_drop(v_kind_241);
              heff_drop(v_text_242);
              heff_drop(v_start_243);
              heff_drop(v_end_244);
              return ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo);
            } else {
              if ((heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str31), 2) && heff_strEq_c_lent(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str32), 2))) {
                heff_drop(v_kind_241);
                heff_drop(v_text_242);
                heff_drop(v_start_243);
                heff_drop(v_end_244);
                return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 0))});
              } else {
                if ((heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str33), 2) && heff_strEq_c_lent(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str34), 2))) {
                  heff_drop(v_kind_241);
                  heff_drop(v_text_242);
                  heff_drop(v_start_243);
                  heff_drop(v_end_244);
                  return ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo);
                } else {
                  return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam8, 2, 4, (V[]){v_kind_241, v_text_242, v_start_243, v_end_244});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(a[0]);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2421, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_ENeg, 2, (V[]){v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(v_hd_2424, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4, 1, 2, (V[]){v_k_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3, 1, 2, (V[]){v_hd_2424, v_k_2425})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_ETilde, 2, (V[]){v_x_2430, v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_k_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(v_hd_2428, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam7, 1, 2, (V[]){v_k_2429, v_x_2430})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2428), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6, 1, 2, (V[]){v_hd_2428, v_k_2429})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam8(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_kind_241 = heff_env(self)[0];
  V v_text_242 = heff_env(self)[1];
  V v_start_243 = heff_env(self)[2];
  V v_end_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bind_2434 = heff_take_field(v_hd_2432, 1);
  V v_malg_2435 = heff_get_n(v_hd_2432, 2, 3);
  V v_t_2436;
  if (heff_strEq_c(v_kind_241, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str35))) {
    heff_drop(v_text_242);
    v_t_2436 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str36);
  } else {
    v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str37), heff_strAppend(v_text_242, ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str38)));
  }
  V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str39), v_t_2436), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244}), NTAG(TAG_Nothing)});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_call(v_malg_2435, 1, (V[]){v_t_2438}));
  V f_ = v_bind_2434;
  args[0] = v_t_2439;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry, 6, 0};

V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_acc_244, V v_hd_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2415, v_x_2421}), v_acc_244});
  V v_x_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2422));
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nil: {
    v_t_2426 = v_lit_241;
    break;
  }
  case TAG_Cons: {
    v_t_2426 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2423});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2426, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2415, v_x_2431}), v_acc_244});
  V v_x_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2432));
  V v_t_2436;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Nil: {
    v_t_2436 = v_lit_241;
    break;
  }
  case TAG_Cons: {
    v_t_2436 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2433});
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2436, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_text_2419 = heff_take_field(v_x_2418, 1);
  V v_kind_2420 = heff_get_n(v_x_2418, 0, 9);
  if (heff_strEq_c_lent(v_text_2419, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str1), 2)) {
    heff_drop(v_text_2419);
    heff_drop(v_kind_2420);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4, 1, 6, (V[]){v_x_2415, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
  } else {
    if (heff_strEq_c(v_kind_2420, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str2))) {
      V v_t_2427 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_2419}));
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str3), NTAG(TAG_Nil)});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str5), v_t_2428})});
      V v_t_2430 = ({ V a_0 = v_t_2427; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str6), v_t_2429}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_t_2430);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5, 1, 6, (V[]){v_x_2415, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
      } else {
        heff_drop(v_t_2430);
        return (g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_x_2415, v_acc_244, heff_dup(v_hd_245), v_hd_245));
      }
    } else {
      heff_drop(v_text_2419);
      return (g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_x_2415, v_acc_244, heff_dup(v_hd_245), v_hd_245));
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2416}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3, 1, 7, (V[]){v_hd_245, v_x_2415, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_kind_249 = heff_env(self)[0];
  V v_text_2410 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414;
  if (heff_strEq_c(v_kind_249, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str0))) {
    V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_text_2410}));
    V v_x1_2413 = ({ V a_0 = v_t_2412; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2414 = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
    heff_drop(v_x1_2413);
  } else {
    heff_drop(v_text_2410);
    v_t_2414 = NTAG(TAG_False);
  }
  if (((heff_dup(v_t_2414) == NTAG(TAG_True)) && !(heff_dup(v_x_2411) == NTAG(TAG_True)))) {
    heff_drop(v_x_2411);
    heff_drop(v_t_2414);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_hd_245, 3);
    heff_drop(v_t_2414);
    V v_x_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
    V v_t_2440;
    switch (heff_tag_of(v_x_2437)) {
    case TAG_Nil: {
      v_t_2440 = v_lit_241;
      break;
    }
    case TAG_Cons: {
      v_t_2440 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2437});
      break;
    }
    default: heff_nomatch(v_x_2437);
    }
    return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2440, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_kind_249 = heff_take_field(v_x_248, 0);
  V v_text_2410 = heff_get_n(v_x_248, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1, 1, 8, (V[]){v_kind_249, v_text_2410, v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8, 1, "@");
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args) {
  V v_st_2420 = args[0];
  V v_k_2421 = args[1];
  V v_minPrec_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(v_minPrec_2419, heff_dup(v_st_2420), v_k_2421, v_st_2420));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_minPrec_240, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_241, v_x_2414, v_x_2423}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_text_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2415 = heff_dup(v_text_248);
  int64_t v_t_2416;
  if (heff_strEq_c_lent(v_s_2415, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5), 2)) {
    heff_drop(v_s_2415);
    v_t_2416 = ((int64_t)1ULL);
  } else {
    if (heff_strEq_c(v_s_2415, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6))) {
      v_t_2416 = ((int64_t)2ULL);
    } else {
      v_t_2416 = ((int64_t)-1ULL);
    }
  }
  V v_c_2422;
  if ((v_t_2416 == ((int64_t)1ULL))) {
    heff_drop(v_text_248);
    v_c_2422 = ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo);
  } else {
    V v_s_2417 = v_text_248;
    int64_t v_t_2418;
    if (heff_strEq_c_lent(v_s_2417, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7), 2)) {
      heff_drop(v_s_2417);
      v_t_2418 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_2417, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8))) {
        v_t_2418 = ((int64_t)2ULL);
      } else {
        v_t_2418 = ((int64_t)-1ULL);
      }
    }
    V v_minPrec_2419 = heff_box_word((v_t_2418 + ((int64_t)1ULL)));
    v_c_2422 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3, 2, 1, (V[]){v_minPrec_2419});
  }
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2414, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_kind_247 = heff_env(self)[0];
  V v_text_248 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_lhs_241 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2424;
  if (heff_strEq_c(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0))) {
    V v_s_2410 = heff_dup(v_text_248);
    int64_t v_t_2411;
    if (heff_strEq_c_lent(v_s_2410, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1), 2)) {
      heff_drop(v_s_2410);
      v_t_2411 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_2410, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2))) {
        v_t_2411 = ((int64_t)2ULL);
      } else {
        v_t_2411 = ((int64_t)-1ULL);
      }
    }
    V v_t_2425 = heff_bool((((int64_t)1ULL) <= v_t_2411));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      V v_s_2412 = heff_dup(v_text_248);
      V v_t_2413;
      if (heff_strEq_c_lent(v_s_2412, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3), 2)) {
        heff_drop(v_s_2412);
        v_t_2413 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2412, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4))) {
          v_t_2413 = MK_INT(2LL);
        } else {
          v_t_2413 = MK_INT(-1LL);
        }
      }
      V v_t_2426 = heff_bool(heff_intLe_c_lent(v_minPrec_240, v_t_2413, 0));
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_t_2426)) {
      case TAG_True: {
        v_t_2424 = heff_bool(!(heff_dup(v_x_249) == NTAG(TAG_True)));
        heff_drop(v_x_249);
        break;
      }
      case TAG_False: {
        heff_drop(v_x_249);
        v_t_2424 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_x_249);
      v_t_2424 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
  } else {
    heff_drop(v_x_249);
    v_t_2424 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2, 1, 5, (V[]){v_text_248, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
  }
  case TAG_False: {
    heff_drop(v_text_248);
    heff_drop(v_minPrec_240);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_lhs_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1, 1, 6, (V[]){v_kind_247, v_text_248, v_minPrec_240, v_hd_242, v_lhs_241, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11, 5, "break");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str13, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str15, 6, "return");
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5, 2, 0};
Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V v_t_240) {
top: ;
  V v_text_241 = heff_take_field(v_t_240, 1);
  V v_kind_242 = heff_get_n(v_t_240, 0, 9);
  if ((heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0), 2) && heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1), 2))) {
    heff_drop(v_text_241);
    heff_drop(v_kind_242);
    return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 8));
  } else {
    if ((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3), 2))) {
      heff_drop(v_text_241);
      heff_drop(v_kind_242);
      return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 9));
    } else {
      if ((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5), 2))) {
        heff_drop(v_text_241);
        heff_drop(v_kind_242);
        return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 10));
      } else {
        if ((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7), 2))) {
          heff_drop(v_text_241);
          heff_drop(v_kind_242);
          return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 11));
        } else {
          if ((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9), 2))) {
            heff_drop(v_text_241);
            heff_drop(v_kind_242);
            return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
          } else {
            if (((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11), 2)) || (heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str12), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str13), 2)))) {
              heff_drop(v_text_241);
              heff_drop(v_kind_242);
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo);
            } else {
              if ((heff_strEq_c_lent(v_kind_242, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str14), 2) && heff_strEq_c_lent(v_text_241, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str15), 2))) {
                heff_drop(v_text_241);
                heff_drop(v_kind_242);
                return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo);
              } else {
                heff_drop(v_text_241);
                heff_drop(v_kind_242);
                return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5_clo);
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(a[0]);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_EJump, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1, 1, 1, (V[]){v_k_244})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_EReturn, 2, (V[]){v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4, 1, 2, (V[]){v_k_247, v_x_248})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args) {
  V v_st_2410 = args[0];
  V v_k_2411 = args[1];
  return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(MK_INT(0LL), heff_dup(v_st_2410), v_k_2411, v_st_2410));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1, 2, "::");
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_242, v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3, 1, 3, (V[]){v_k_241, v_x_242, v_x_248})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1), 2))) {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
  } else {
    heff_drop_rec(v_hd_240, 3);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str0, 62, "` names the type; its constructor needs another name, e.g. `Mk");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str2, 1, "`");
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_entry, 2, 0};

V g_heff_2esyntax_2ecst_2echeckAltNames(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECon: {
      V v_c_2451 = heff_field(v_x21_244, 0);
      V v_text_2453 = heff_dup(heff_rfield(v_c_2451, 1));
      V v_start_2454 = heff_dup(heff_rfield(v_c_2451, 3));
      V v_end_2455 = heff_dup(heff_rfield(v_c_2451, 4));
      if (heff_strEq_c_lent(v_text_2453, v_name_240, 0)) {
        return heff_clo_n(g_heff_2esyntax_2ecst_2echeckAltNames_lam1, 2, 3, (V[]){v_text_2453, v_start_2454, v_end_2455});
      } else {
        heff_drop(v_text_2453);
        heff_drop(v_start_2454);
        heff_drop(v_end_2455);
        V t_0 = v_name_240;
        V t_1 = v_rest_245;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EField: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETilde: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_OpRhs: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ann: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BPat: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELetElse: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EArrow: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETry: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECatch: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EWith: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2echeckAltNames(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_text_2453 = heff_env(self)[0];
  V v_start_2454 = heff_env(self)[1];
  V v_end_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2458 = heff_take_field(v_hd_2456, 1);
  V v_malg_2459 = heff_get_n(v_hd_2456, 2, 3);
  V v_t_2460 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str0), heff_strAppend(heff_dup(v_text_2453), ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str1)));
  V v_t_2461 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str2), heff_strAppend(v_text_2453, v_t_2460));
  V v_t_2462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2461, heff_rec_n(2, shape_start__end, (V[]){v_start_2454, v_end_2455}), NTAG(TAG_Nothing)});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tr(heff_call(v_malg_2459, 1, (V[]){v_t_2463}));
  V f_ = v_bind_2458;
  args[0] = v_t_2464;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_t_2414 = heff_get_n(v_s_2413, 3, 5);
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_col_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_toks_2424 = heff_take_field(v_s_2423, 0);
  V v_i_2425 = heff_take_field(v_s_2423, 1);
  V v_top_2426 = heff_take_field(v_s_2423, 2);
  V v_stack_2427 = heff_take_field(v_s_2423, 3);
  V v_start_2428 = heff_get_n(v_s_2423, 4, 5);
  return heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_2424, v_i_2425, v_top_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_col_249, v_stack_2427}), v_start_2428});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7(V self, V *args) {
  V v_s_2436 = args[0];
  V v_stack_2437 = heff_take_field(v_s_2436, 3);
  V v_toks_2438 = heff_take_field(v_s_2436, 0);
  V v_i_2439 = heff_take_field(v_s_2436, 1);
  V v_top_2440 = heff_take_field(v_s_2436, 2);
  V v_start_2441 = heff_get_n(v_s_2436, 4, 5);
  V v_k_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = v_stack_2437; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_stack_2437); r_; });
  return heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){v_toks_2438, v_i_2439, v_top_2440, v_k_2442, v_start_2441});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_241;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2445, NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2447;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9, 1, 2, (V[]){v_k_241, v_x_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7_clo)})});
  V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2443}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2444;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_col_249 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(v_col_249, NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5, 1, 3, (V[]){v_col_249, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_first_248 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_start_246 = heff_env(self)[2];
  V v_end_247 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (((heff_dup(v_first_248) == NTAG(TAG_True)) && heff_intLe_c_lent(v_col_249, v_x_2419, 0))) {
    heff_drop(v_x_2419);
    heff_drop(v_first_248);
    heff_drop(v_col_249);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str2), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2419);
    heff_drop(v_first_248);
    heff_drop(v_start_246);
    heff_drop(v_end_247);
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3, 1, 1, (V[]){heff_dup(v_col_249)})})});
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2429}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2430;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4, 1, 3, (V[]){v_hd_240, v_col_249, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_kind_245 = heff_take_field(v_x_244, 0);
  V v_start_246 = heff_take_field(v_x_244, 3);
  V v_end_247 = heff_take_field(v_x_244, 4);
  V v_first_248 = heff_take_field(v_x_244, 6);
  V v_col_249 = heff_get_n(v_x_244, 5, 9);
  if (heff_strEq_c(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str0))) {
    heff_drop(v_first_248);
    heff_drop(v_col_249);
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2, 1, 6, (V[]){v_first_248, v_col_249, v_start_246, v_end_247, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_str4, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredMoreGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredMoreGo_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edeclaredMoreGo(V v_s_240, V v_k_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(v_k_241)));
  if (!heff_strEq_c(heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_str0))) {
    heff_drop(v_s_240);
    heff_drop(v_k_241);
    heff_drop_rec(v_t_242, 9);
    return NTAG(TAG_Nil);
  } else {
    heff_drop_rec(v_t_242, 9);
    V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
    V v_t_245;
    if (heff_strEq_c(heff_get_n(v_t_243, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_str1))) {
      V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(3LL))));
      v_t_245 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_t_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_str2)));
      heff_drop_rec(v_t_244, 9);
    } else {
      v_t_245 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(2LL))));
      V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 1, 9), heff_hole()});
      V v_u_248 = (g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(v_s_240, heff_intAdd(v_k_241, MK_INT(4LL)), heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_t_245);
      V v_t_249 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
      if (heff_strEq_c(heff_get_n(v_t_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_str3))) {
        V v_t_2410 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
        V v_cell_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2410, 1, 9), heff_hole()});
        V v_u_2412 = (g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(v_s_240, heff_intAdd(v_k_241, MK_INT(2LL)), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      } else {
        V v_t_2413 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
        if (heff_strEq_c(heff_get_n(v_t_2413, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_str4))) {
          V v_t_2414 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
          V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2414, 1, 9), heff_hole()});
          V v_u_2416 = (g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(v_s_240, heff_intAdd(v_k_241, MK_INT(2LL)), heff_dup(v_cell_2415)));
          heff_drop(v_u_2416);
          return v_cell_2415;
        } else {
          heff_drop(v_s_240);
          heff_drop(v_k_241);
          return NTAG(TAG_Nil);
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclaredMoreGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredMoreGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str4, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(V v_s_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(v_k_241)));
  if (!heff_strEq_c(heff_dup(heff_rfield(v_t_243, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str0))) {
    heff_drop(v_s_240);
    heff_drop(v_k_241);
    heff_drop_rec(v_t_243, 9);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    heff_drop_rec(v_t_243, 9);
    V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
    V v_t_246;
    if (heff_strEq_c(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str1))) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(3LL))));
      v_t_246 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str2)));
      heff_drop_rec(v_t_245, 9);
    } else {
      v_t_246 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(2LL))));
      V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_247, 1, 9), heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_k_241, MK_INT(4LL));
      V t_2 = v_cell_248;
      v_s_240 = t_0;
      v_k_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_t_2410 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
      if (heff_strEq_c(heff_get_n(v_t_2410, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str3))) {
        V v_t_2411 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
        V v_cell_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2411, 1, 9), heff_hole()});
        V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_k_241, MK_INT(2LL));
        V t_2 = v_cell_2412;
        v_s_240 = t_0;
        v_k_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_t_2414 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
        if (heff_strEq_c(heff_get_n(v_t_2414, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_str4))) {
          V v_t_2415 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_k_241), MK_INT(1LL))));
          V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2415, 1, 9), heff_hole()});
          V v_u_2417 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2416));
          heff_drop(v_u_2417);
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_k_241, MK_INT(2LL));
          V t_2 = v_cell_2416;
          v_s_240 = t_0;
          v_k_241 = t_1;
          v_d_242 = t_2;
          goto top;
        } else {
          heff_drop(v_s_240);
          heff_drop(v_k_241);
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredMoreGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMore_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMore_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredMore_str2, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredMore_entry, 1, 0};

V g_heff_2esyntax_2ecst_2edeclaredMore(V v_s_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 2))));
  if (heff_strEq_c(heff_get_n(v_t_241, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMore_str0))) {
    V v_t_242 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(3LL));
    return (g_heff_2esyntax_2ecst_2edeclaredMoreGo(v_s_240, v_t_242));
  } else {
    V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 2))));
    if (heff_strEq_c(heff_get_n(v_t_243, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMore_str1))) {
      V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
      return (g_heff_2esyntax_2ecst_2edeclaredMoreGo(v_s_240, v_t_244));
    } else {
      V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 2))));
      if (heff_strEq_c(heff_get_n(v_t_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edeclaredMore_str2))) {
        V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
        return (g_heff_2esyntax_2ecst_2edeclaredMoreGo(v_s_240, v_t_246));
      } else {
        heff_drop_rec(v_s_240, 5);
        return NTAG(TAG_Nil);
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclaredMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredMore(a[0]);
}