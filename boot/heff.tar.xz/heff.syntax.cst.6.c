// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1309329256x19280305(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1309329256x19280305_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1309329256x19280305_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692_clo;
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo;
V g_heff_2esyntax_2ecst_2ecatchF(V, V, V);
V g_heff_2esyntax_2ecst_2ecatchF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecatchF_clo;
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258(V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo;
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(V, V);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etryCaught(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2etryCaught_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryCaught_clo;
V g_heff_2esyntax_2ecst_2etryF(V, V, V);
V g_heff_2esyntax_2ecst_2etryF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryF_clo;
V g_heff_2esyntax_2ecst_2etryPartF(V, V, V);
V g_heff_2esyntax_2ecst_2etryPartF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryPartF_clo;
V g_heff_2esyntax_2ecst_2etryTypeF(V, V, V);
V g_heff_2esyntax_2ecst_2etryTypeF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryTypeF_clo;
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(V, V, V, V);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2enext_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_entry, 2, 0};

V g_heff_2esyntax_2ecst_2enext(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enext(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_take_field(v_s_245, 1), MK_INT(1LL));
  return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_245, 29ULL, 5, shape_toks__i__top__stack__start, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_241;
  args[0] = v_x_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam3, 1, 2, (V[]){v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2enext_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyGo_entry, 4, 0};

V g_heff_2esyntax_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_p_240})));
}
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_x_244);
    heff_drop(v_p_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_244);
    V v_t_249 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_247)));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_247, 9);
      heff_drop(v_t_249);
      V f_ = heff_dup(v_p_240);
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam2, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_249);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str0))) {
        heff_drop_rec(v_x_247, 9);
        V f_ = heff_dup(v_p_240);
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam3, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str1))) {
          if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str2))) {
            V f_ = heff_dup(v_p_240);
            heff_room[0] = heff_dup(v_hd_242);
            heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam4, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            heff_drop(v_p_240);
            heff_drop_rec(v_hd_242, 3);
            V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
            V f_ = v_k_243;
            args[0] = v_x_2416;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        } else {
          heff_drop_rec(v_x_247, 9);
          heff_drop(v_p_240);
          heff_drop_rec(v_hd_242, 3);
          V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
          V f_ = v_k_243;
          args[0] = v_x_2417;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam1, 1, 5, (V[]){v_x_244, v_acc_241, v_k_243, v_p_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_247, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam5, 1, 3, (V[]){v_k_242, v_x_247, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_2410, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_str1))) {
      if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 17);
        V f_ = v_k_242;
        args[0] = v_x_247;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2411);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_247})));
      }
    } else {
      heff_drop(v_x_2411);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 17);
      V f_ = v_k_242;
      args[0] = v_x_247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam3, 1, 5, (V[]){v_x_2410, v_k_242, v_x_247, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam2, 1, 4, (V[]){v_hd_241, v_k_242, v_x_247, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2esyntax_2ecst_2eexprHead(heff_dup(v_g_240), v_x_245));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2418}), v_acc_241});
  V v_x_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2419));
  V f_ = v_k_243;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2426}), v_acc_241});
  V v_x_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2427));
  V f_ = v_k_243;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2429}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2430, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2413, v_x_2431}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2432, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2416, 1)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str1))) {
    heff_drop_rec(v_x_2416, 9);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_242;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam4, 1, 3, (V[]){v_x_2413, v_acc_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2416, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str2))) {
      V v_t_2422 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2416, 1, 9)}));
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str3), NTAG(TAG_Nil)});
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str5), v_t_2423})});
      V v_t_2425 = ({ V a_0 = v_t_2422; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str6), v_t_2424}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_t_2425);
        V f_ = heff_get_n(v_g_240, 0, 17);
        heff_room[0] = v_hd_242;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam5, 1, 3, (V[]){v_x_2413, v_acc_241, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2425);
        V f_ = heff_dup(heff_rfield(v_g_240, 3));
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam6, 1, 5, (V[]){v_x_2413, v_acc_241, v_g_240, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2416, 9);
      V f_ = heff_dup(heff_rfield(v_g_240, 3));
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam7, 1, 5, (V[]){v_x_2413, v_acc_241, v_g_240, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam3, 1, 5, (V[]){v_g_240, v_hd_242, v_x_2413, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str0))) {
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_246, 1, 9)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
      heff_drop(v_x_247);
      heff_drop_rec(v_hd_242, 3);
      heff_drop_rec(v_g_240, 17);
      heff_drop(v_x1_2410);
      V v_x_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      V f_ = v_k_243;
      args[0] = v_x_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x1_2410);
      if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop_rec(v_hd_242, 3);
        heff_drop_rec(v_g_240, 17);
        V v_x_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        V f_ = v_k_243;
        args[0] = v_x_2412;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_247);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam2, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
      }
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 17);
    V v_x_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam1, 1, 5, (V[]){v_x_246, v_acc_241, v_k_243, v_hd_242, v_g_240})));
}
V g_heff_2esyntax_2ecst_2etryF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etryF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etryF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etryF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etryF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etryF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etryF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_x_243; V a_1 = v_x_244; V a_2 = v_x_245; V a_3 = v_x_247; V a_4 = v_hd_241; V a_5 = v_k_242; V r_ = (g_heff_2esyntax_2ecst_2etryCaught(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_247); r_; });
}
V g_heff_2esyntax_2ecst_2etryF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2ecatchF_clo), 1, (V[]){v_g_240}));
  return (g_heff_2esyntax_2ecst_2etryPartF(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam3, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(v_g_240, 14)), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2esyntax_2ecst_2etryF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2etryTypeF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2etryF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str0, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str1, 1, "}");
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(V v_o_240, V v_r_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0, 1, 4, (V[]){v_hd_242, v_o_240, v_r_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkSep: {
    V v_items_249 = heff_field(v_x_247, 0);
    V v_seps_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    v_t_2411 = heff_tag_n(TAG_Update, 6, (V[]){v_o_240, v_r_241, v_x_244, v_items_249, v_seps_2410, v_x_248});
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_243;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str1), v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam3, 1, 5, (V[]){v_x_247, v_o_240, v_r_241, v_x_244, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_str0); V a_1 = v_t_246; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_242); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam2, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateF_24s1643929394x542294694_lam1, 1, 5, (V[]){v_hd_242, v_o_240, v_r_241, v_x_244, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry, 7, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_hd_246) {
top: ;
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sep_2414 = heff_env(self)[0];
  V v_items_2415 = heff_env(self)[1];
  V v_seps_2416 = heff_env(self)[2];
  V v_hd_2417 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2414, v_items_2415, v_x_2423, v_seps_2416, heff_dup(v_hd_2417), v_k_2418, v_hd_2417));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_sep_2414 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_items_2415 = heff_env(self)[2];
  V v_seps_2416 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2421, 1, 9), heff_dup(v_sep_2414))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2417), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam4, 1, 5, (V[]){v_sep_2414, v_items_2415, v_seps_2416, v_hd_2417, v_k_2418})));
  } else {
    heff_drop(v_sep_2414);
    heff_drop_rec(v_hd_2417, 3);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2415));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2416));
    V v_x_2426 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2424, v_t_2425});
    V f_ = v_k_2418;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sep_2429 = heff_env(self)[0];
  V v_items_2430 = heff_env(self)[1];
  V v_seps_2431 = heff_env(self)[2];
  V v_hd_2432 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2429, v_items_2430, v_x_2438, v_seps_2431, heff_dup(v_hd_2432), v_k_2433, v_hd_2432));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sep_2429 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_items_2430 = heff_env(self)[2];
  V v_seps_2431 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2436, 1, 9), heff_dup(v_sep_2429))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2432), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam8, 1, 5, (V[]){v_sep_2429, v_items_2430, v_seps_2431, v_hd_2432, v_k_2433})));
  } else {
    heff_drop(v_sep_2429);
    heff_drop_rec(v_hd_2432, 3);
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2430));
    V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2431));
    V v_x_2441 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2439, v_t_2440});
    V f_ = v_k_2433;
    args[0] = v_x_2441;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2429 = v_lit_240;
  V v_items_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2427, v_x_2428}), v_lit_241});
  V v_seps_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2432 = v_lit_244;
  V v_k_2433 = v_lit_245;
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2432, 2)), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(heff_rfield(v_hd_2432, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam7, 1, 5, (V[]){v_sep_2429, v_hd_2432, v_items_2430, v_seps_2431, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam6, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2427, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_sep_2443 = heff_env(self)[0];
  V v_items_2444 = heff_env(self)[1];
  V v_seps_2445 = heff_env(self)[2];
  V v_hd_2446 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2443, v_items_2444, v_x_2452, v_seps_2445, heff_dup(v_hd_2446), v_k_2447, v_hd_2446));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_sep_2443 = heff_env(self)[0];
  V v_hd_2446 = heff_env(self)[1];
  V v_items_2444 = heff_env(self)[2];
  V v_seps_2445 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2450, 1, 9), heff_dup(v_sep_2443))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2446), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam10, 1, 5, (V[]){v_sep_2443, v_items_2444, v_seps_2445, v_hd_2446, v_k_2447})));
  } else {
    heff_drop(v_sep_2443);
    heff_drop_rec(v_hd_2446, 3);
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2444));
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2445));
    V v_x_2455 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2453, v_t_2454});
    V f_ = v_k_2447;
    args[0] = v_x_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam14(V self, V *args) {
  V v_x_2467 = args[0];
  V v_sep_2458 = heff_env(self)[0];
  V v_items_2459 = heff_env(self)[1];
  V v_seps_2460 = heff_env(self)[2];
  V v_hd_2461 = heff_env(self)[3];
  V v_k_2462 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2458, v_items_2459, v_x_2467, v_seps_2460, heff_dup(v_hd_2461), v_k_2462, v_hd_2461));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam13(V self, V *args) {
  V v_x_2465 = args[0];
  V v_sep_2458 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_items_2459 = heff_env(self)[2];
  V v_seps_2460 = heff_env(self)[3];
  V v_k_2462 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2465, 1, 9), heff_dup(v_sep_2458))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2461), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam14, 1, 5, (V[]){v_sep_2458, v_items_2459, v_seps_2460, v_hd_2461, v_k_2462})));
  } else {
    heff_drop(v_sep_2458);
    heff_drop_rec(v_hd_2461, 3);
    V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2459));
    V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2460));
    V v_x_2470 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2468, v_t_2469});
    V f_ = v_k_2462;
    args[0] = v_x_2470;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2456 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2458 = v_lit_240;
  V v_items_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_247, v_x_2456, v_x_2457}), v_lit_241});
  V v_seps_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2461 = v_lit_244;
  V v_k_2462 = v_lit_245;
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2461, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_hd_2461, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam13, 1, 5, (V[]){v_sep_2458, v_hd_2461, v_items_2459, v_seps_2460, v_k_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam12, 1, 8, (V[]){v_lit_240, v_x_247, v_x_2456, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam16(V self, V *args) {
  V v_x_2480 = args[0];
  V v_sep_2471 = heff_env(self)[0];
  V v_items_2472 = heff_env(self)[1];
  V v_seps_2473 = heff_env(self)[2];
  V v_hd_2474 = heff_env(self)[3];
  V v_k_2475 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2471, v_items_2472, v_x_2480, v_seps_2473, heff_dup(v_hd_2474), v_k_2475, v_hd_2474));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam15(V self, V *args) {
  V v_x_2478 = args[0];
  V v_sep_2471 = heff_env(self)[0];
  V v_hd_2474 = heff_env(self)[1];
  V v_items_2472 = heff_env(self)[2];
  V v_seps_2473 = heff_env(self)[3];
  V v_k_2475 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2478, 1, 9), heff_dup(v_sep_2471))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2474), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam16, 1, 5, (V[]){v_sep_2471, v_items_2472, v_seps_2473, v_hd_2474, v_k_2475})));
  } else {
    heff_drop(v_sep_2471);
    heff_drop_rec(v_hd_2474, 3);
    V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2472));
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2473));
    V v_x_2483 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2481, v_t_2482});
    V f_ = v_k_2475;
    args[0] = v_x_2483;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam18(V self, V *args) {
  V v_x_2493 = args[0];
  V v_sep_2484 = heff_env(self)[0];
  V v_items_2485 = heff_env(self)[1];
  V v_seps_2486 = heff_env(self)[2];
  V v_hd_2487 = heff_env(self)[3];
  V v_k_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875(v_sep_2484, v_items_2485, v_x_2493, v_seps_2486, heff_dup(v_hd_2487), v_k_2488, v_hd_2487));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam17(V self, V *args) {
  V v_x_2491 = args[0];
  V v_sep_2484 = heff_env(self)[0];
  V v_hd_2487 = heff_env(self)[1];
  V v_items_2485 = heff_env(self)[2];
  V v_seps_2486 = heff_env(self)[3];
  V v_k_2488 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2491, 1, 9), heff_dup(v_sep_2484))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2487), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam18, 1, 5, (V[]){v_sep_2484, v_items_2485, v_seps_2486, v_hd_2487, v_k_2488})));
  } else {
    heff_drop(v_sep_2484);
    heff_drop_rec(v_hd_2487, 3);
    V v_t_2494 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2485));
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2486));
    V v_x_2496 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2494, v_t_2495});
    V f_ = v_k_2488;
    args[0] = v_x_2496;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str1))) {
      heff_drop_rec(v_x_2410, 9);
      if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_246, 3);
        V v_sep_2414 = v_lit_240;
        V v_items_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
        V v_seps_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
        V v_hd_2417 = v_lit_244;
        V v_k_2418 = v_lit_245;
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
        V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2417, 2)), 1, (V[]){v_t_2419}));
        V f_ = heff_dup(heff_rfield(v_hd_2417, 1));
        heff_room[0] = v_t_2420;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam3, 1, 5, (V[]){v_sep_2414, v_hd_2417, v_items_2415, v_seps_2416, v_k_2418});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2411);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam5, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_str2))) {
        if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
          heff_drop(v_x_2411);
          heff_drop_rec(v_hd_246, 3);
          V v_sep_2443 = v_lit_240;
          V v_items_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
          V v_seps_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
          V v_hd_2446 = v_lit_244;
          V v_k_2447 = v_lit_245;
          V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
          V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2448}));
          V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
          heff_room[0] = v_t_2449;
          heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam9, 1, 5, (V[]){v_sep_2443, v_hd_2446, v_items_2444, v_seps_2445, v_k_2447});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_x_2411);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam11, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
        }
      } else {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_246, 3);
        V v_sep_2471 = v_lit_240;
        V v_items_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
        V v_seps_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
        V v_hd_2474 = v_lit_244;
        V v_k_2475 = v_lit_245;
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
        V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2474, 2)), 1, (V[]){v_t_2476}));
        V f_ = heff_dup(heff_rfield(v_hd_2474, 1));
        heff_room[0] = v_t_2477;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam15, 1, 5, (V[]){v_sep_2471, v_hd_2474, v_items_2472, v_seps_2473, v_k_2475});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_246, 3);
    V v_sep_2484 = v_lit_240;
    V v_items_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_lit_241});
    V v_seps_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
    V v_hd_2487 = v_lit_244;
    V v_k_2488 = v_lit_245;
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2487, 2)), 1, (V[]){v_t_2489}));
    V f_ = heff_dup(heff_rfield(v_hd_2487, 1));
    heff_room[0] = v_t_2490;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam17, 1, 5, (V[]){v_sep_2484, v_hd_2487, v_items_2485, v_seps_2486, v_k_2488});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam2, 1, 9, (V[]){v_x_2410, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_hd_246})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s695541031x1801546875_lam1, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_247, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2414, v_x_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_x_243, v_t_2416));
  V v_x_2418 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_t_2417});
  V f_ = v_k_241;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 14)), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam5, 1, 4, (V[]){v_x_2414, v_x_243, v_x_242, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 16));
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str0))) {
      if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_str1))) {
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop(v_x_247);
          heff_drop_rec(v_hd_240, 3);
          V v_t_2413;
          switch (heff_tag_of(v_x_243)) {
          case TAG_Nil: {
            v_t_2413 = v_x_242;
            break;
          }
          case TAG_Cons: {
            v_t_2413 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_x_243});
            break;
          }
          default: heff_nomatch(v_x_243);
          }
          V f_ = v_k_241;
          args[0] = v_t_2413;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_247);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam4, 1, 4, (V[]){v_hd_240, v_x_243, v_x_242, v_k_241})));
        }
      } else {
        heff_drop(v_x_247);
        heff_drop_rec(v_hd_240, 3);
        V v_t_2421;
        switch (heff_tag_of(v_x_243)) {
        case TAG_Nil: {
          v_t_2421 = v_x_242;
          break;
        }
        case TAG_Cons: {
          v_t_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_x_243});
          break;
        }
        default: heff_nomatch(v_x_243);
        }
        V f_ = v_k_241;
        args[0] = v_t_2421;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_x_247);
      heff_drop_rec(v_x_246, 9);
      heff_drop_rec(v_hd_240, 3);
      V v_t_2424;
      switch (heff_tag_of(v_x_243)) {
      case TAG_Nil: {
        v_t_2424 = v_x_242;
        break;
      }
      case TAG_Cons: {
        v_t_2424 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_x_243});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V f_ = v_k_241;
      args[0] = v_t_2424;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_240, 3);
    heff_drop(v_t_248);
    V v_t_2427;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Nil: {
      v_t_2427 = v_x_242;
      break;
    }
    case TAG_Cons: {
      v_t_2427 = heff_tag_n(TAG_App, 2, (V[]){v_x_242, v_x_243});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V f_ = v_k_241;
    args[0] = v_t_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam3, 1, 5, (V[]){v_x_246, v_x_243, v_x_242, v_k_241, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam2, 1, 4, (V[]){v_hd_240, v_x_243, v_x_242, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s1153426196x1729477045_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str12, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str14, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str15, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str16, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str17, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str18, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str19, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str20, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str21, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str22, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str24, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str25, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str26, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str28, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str29, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str30, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str31, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str32, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str33, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str34, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str35, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str38, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str39, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str40, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str43, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 0))}));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str2), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str5), v_t_244}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2418;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_2418 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_245);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str6))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str7), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str9), v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str11), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str13), v_t_2410})});
      V v_t_2412 = ({ V a_0 = v_t_247; V a_1 = v_t_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2411, 2); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2418 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2412);
        HeffT2 v_t_2413 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str14), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str15), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str16), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str17), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str18), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str19), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str20), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str21), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str22), heff_rfield(v_t_240, 1), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          v_t_2418 = heff_bool(((v_tag_2414 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2415); int c_ = 1; heff_drop(v_x_2417); c_; })));
          heff_drop(v_field_2415);
        }
      }
    } else {
      v_t_2418 = NTAG(TAG_False);
    }
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2423 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str23)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str24))));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_t_2423);
      return ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo);
    } else {
      heff_drop(v_t_2423);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str25))) {
        heff_drop_rec(v_t_240, 9);
        return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2_clo);
      } else {
        V v_t_2430 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str26)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str27))));
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_t_2430);
          return ((V)&g_heff_2esyntax_2ecst_2eparensF_24s100017968x1467579234_clo);
        } else {
          heff_drop(v_t_2430);
          V v_t_2432 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str28)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str29))));
          if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 9);
            heff_drop(v_t_2432);
            return ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s1059047889x1300907546_clo);
          } else {
            heff_drop(v_t_2432);
            V v_t_2434 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str30)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str31))));
            if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_240, 9);
              heff_drop(v_t_2434);
              return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 0))});
            } else {
              heff_drop(v_t_2434);
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str32))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str33))) {
                  heff_drop_rec(v_t_240, 9);
                  return ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s556229811x205834258_clo);
                } else {
                  return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5, 2, 1, (V[]){v_t_240});
                }
              } else {
                return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6, 2, 1, (V[]){v_t_240});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(a[0]);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2419, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam1, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_ENeg, 2, (V[]){v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(v_hd_2425, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam4, 1, 2, (V[]){v_k_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2425), heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam3, 1, 2, (V[]){v_hd_2425, v_k_2426})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str34))) {
    v_t_2441 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str35);
  } else {
    V v_t_2440 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str36));
    v_t_2441 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str37), v_t_2440);
  }
  V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
  V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str38), v_t_2441), v_t_2442, NTAG(TAG_Nothing)});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(heff_take_field(v_hd_2437, 2), 1, (V[]){v_t_2444}));
  V f_ = heff_get_n(v_hd_2437, 1, 3);
  args[0] = v_t_2445;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_lam6(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str39))) {
    v_t_2450 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str40);
  } else {
    V v_t_2449 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str41));
    v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str42), v_t_2449);
  }
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_str43), v_t_2450), v_t_2451, NTAG(TAG_Nothing)});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_2446, 2), 1, (V[]){v_t_2453}));
  V f_ = heff_get_n(v_hd_2446, 1, 3);
  args[0] = v_t_2454;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry, 6, 0};

V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_acc_244, V v_hd_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2421, v_x_2426}), v_acc_244});
  V v_x_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2427));
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Nil: {
    v_t_2431 = v_lit_241;
    break;
  }
  case TAG_Cons: {
    v_t_2431 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2428});
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2431, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2421, v_x_2437}), v_acc_244});
  V v_x_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2438));
  V v_t_2442;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Nil: {
    v_t_2442 = v_lit_241;
    break;
  }
  case TAG_Cons: {
    v_t_2442 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2439});
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2442, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2424, 1)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str1))) {
    heff_drop_rec(v_x_2424, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam4, 1, 6, (V[]){v_x_2421, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2424, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str2))) {
      V v_t_2433 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2424, 1, 9)}));
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str3), NTAG(TAG_Nil)});
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str5), v_t_2434})});
      V v_t_2436 = ({ V a_0 = v_t_2433; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str6), v_t_2435}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_t_2436);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam5, 1, 6, (V[]){v_x_2421, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
      } else {
        heff_drop(v_t_2436);
        return (g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_x_2421, v_acc_244, heff_dup(v_hd_245), v_hd_245));
      }
    } else {
      heff_drop_rec(v_x_2424, 9);
      return (g_heff_2esyntax_2ecst_2eappF_24s1457539732x1751720692(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_x_2421, v_acc_244, heff_dup(v_hd_245), v_hd_245));
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2422}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam3, 1, 7, (V[]){v_hd_245, v_x_2421, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_str0))) {
    V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_248, 1, 9)}));
    V v_x1_2412 = ({ V a_0 = v_t_2411; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x_249);
      heff_drop_rec(v_hd_245, 3);
      heff_drop(v_x1_2412);
      V v_x_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
      V v_t_2416;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_Nil: {
        v_t_2416 = v_lit_241;
        break;
      }
      case TAG_Cons: {
        v_t_2416 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2413});
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2416, v_lit_242, v_lit_243));
    } else {
      heff_drop(v_x1_2412);
      if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
        heff_drop(v_x_249);
        heff_drop_rec(v_hd_245, 3);
        V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
        V v_t_2420;
        switch (heff_tag_of(v_x_2417)) {
        case TAG_Nil: {
          v_t_2420 = v_lit_241;
          break;
        }
        case TAG_Cons: {
          v_t_2420 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2417});
          break;
        }
        default: heff_nomatch(v_x_2417);
        }
        return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2420, v_lit_242, v_lit_243));
      } else {
        heff_drop(v_x_249);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam2, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
      }
    }
  } else {
    heff_drop(v_x_249);
    heff_drop_rec(v_x_248, 9);
    heff_drop_rec(v_hd_245, 3);
    V v_x_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
    V v_t_2446;
    switch (heff_tag_of(v_x_2443)) {
    case TAG_Nil: {
      v_t_2446 = v_lit_241;
      break;
    }
    case TAG_Cons: {
      v_t_2446 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2443});
      break;
    }
    default: heff_nomatch(v_x_2443);
    }
    return (g_heff_2esyntax_2ecst_2eopLoopF_24s1825423150x1664746778(v_lit_240, v_t_2446, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s1070498327x1555168565_lam1, 1, 7, (V[]){v_x_248, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243, v_hd_245})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_k_243, v_lhs_241})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args) {
  V v_st_2425 = args[0];
  V v_k_2426 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_x_246, 1, 9); V b_1 = ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7); V a_2 = MK_INT(1LL); V b_3 = ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8); V a_4 = MK_INT(2LL); V a_5 = MK_INT(-1LL); V a_6 = heff_dup(v_st_2425); V a_7 = v_k_2426; V a_8 = v_st_2425; V r_ = (g_heff_2esyntax_2ecst_2eappF_24s1309329256x19280305(b_0, b_1, a_2, b_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_3); r_; });
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_minPrec_240, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_241, v_x_2419, v_x_2428}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2420 = heff_dup(heff_rfield(v_x_246, 1));
  int64_t v_t_2423;
  if (heff_strEq_c_lent(v_s_2420, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5), 2)) {
    heff_drop(v_s_2420);
    v_t_2423 = ((int64_t)1ULL);
  } else {
    if (heff_strEq_c(v_s_2420, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6))) {
      v_t_2423 = ((int64_t)2ULL);
    } else {
      v_t_2423 = ((int64_t)-1ULL);
    }
  }
  V v_c_2427;
  if ((v_t_2423 == ((int64_t)1ULL))) {
    heff_drop_rec(v_x_246, 9);
    v_c_2427 = ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo);
  } else {
    v_c_2427 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3, 2, 1, (V[]){v_x_246});
  }
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2419, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0))) {
    V v_s_249 = heff_dup(heff_rfield(v_x_246, 1));
    int64_t v_t_2412;
    if (heff_strEq_c_lent(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1), 2)) {
      heff_drop(v_s_249);
      v_t_2412 = ((int64_t)1ULL);
    } else {
      if (heff_strEq_c(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2))) {
        v_t_2412 = ((int64_t)2ULL);
      } else {
        v_t_2412 = ((int64_t)-1ULL);
      }
    }
    if ((((int64_t)1ULL) <= v_t_2412)) {
      V v_s_2414 = heff_dup(heff_rfield(v_x_246, 1));
      V v_t_2417;
      if (heff_strEq_c_lent(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3), 2)) {
        heff_drop(v_s_2414);
        v_t_2417 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4))) {
          v_t_2417 = MK_INT(2LL);
        } else {
          v_t_2417 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c_lent(v_minPrec_240, v_t_2417, 2)) {
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop(v_x_247);
          heff_drop_rec(v_x_246, 9);
          heff_drop(v_minPrec_240);
          heff_drop_rec(v_hd_242, 3);
          V f_ = v_k_243;
          args[0] = v_lhs_241;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          heff_drop(v_x_247);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2, 1, 5, (V[]){v_x_246, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
        }
      } else {
        heff_drop(v_x_247);
        heff_drop_rec(v_x_246, 9);
        heff_drop(v_minPrec_240);
        heff_drop_rec(v_hd_242, 3);
        V f_ = v_k_243;
        args[0] = v_lhs_241;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_x_247);
      heff_drop_rec(v_x_246, 9);
      heff_drop(v_minPrec_240);
      heff_drop_rec(v_hd_242, 3);
      V f_ = v_k_243;
      args[0] = v_lhs_241;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_minPrec_240);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1, 1, 5, (V[]){v_x_246, v_minPrec_240, v_k_243, v_lhs_241, v_hd_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11, 5, "break");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str13, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str15, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str16, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str17, 6, "return");
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6, 2, 0};
Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V v_t_240) {
top: ;
  V v_t_242 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_242);
    return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 8));
  } else {
    heff_drop(v_t_242);
    V v_t_244 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_t_244);
      return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 9));
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5))));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 9);
        heff_drop(v_t_246);
        return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 10));
      } else {
        heff_drop(v_t_246);
        V v_t_248 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7))));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_t_248);
          return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 11));
        } else {
          heff_drop(v_t_248);
          V v_t_2410 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9))));
          if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
            heff_drop_rec(v_t_240, 9);
            heff_drop(v_t_2410);
            return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
          } else {
            heff_drop(v_t_2410);
            V v_t_2415 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10)) ? (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str12)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str13)))) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str14)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str15)))));
            if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
              heff_drop_rec(v_t_240, 9);
              heff_drop(v_t_2415);
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo);
            } else {
              heff_drop(v_t_2415);
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str16))) {
                if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str17))) {
                  return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo);
                } else {
                  return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5_clo);
                }
              } else {
                heff_drop_rec(v_t_240, 9);
                return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6_clo);
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(a[0]);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_EJump, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2416, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1, 1, 1, (V[]){v_k_2417})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_EReturn, 2, (V[]){v_x_2423, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_2421, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4, 1, 2, (V[]){v_k_2422, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2421), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3, 1, 2, (V[]){v_hd_2421, v_k_2422})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args) {
  V v_st_2425 = args[0];
  V v_k_2426 = args[1];
  return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(MK_INT(0LL), heff_dup(v_st_2425), v_k_2426, v_st_2425));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args) {
  V v_st_2427 = args[0];
  V v_k_2428 = args[1];
  return (g_heff_2esyntax_2ecst_2eappF_24s306749068x2065471004(MK_INT(0LL), heff_dup(v_st_2427), v_k_2428, v_st_2427));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1, 2, "::");
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_242, v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3, 1, 3, (V[]){v_k_241, v_x_242, v_x_248})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1))) {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    } else {
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str1, 62, "` names the type; its constructor needs another name, e.g. `Mk");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str2, 1, "`");
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_entry, 2, 0};

V g_heff_2esyntax_2ecst_2echeckAltNames(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECon: {
      V v_c_2451 = heff_field(v_x21_244, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2451, 1)), heff_dup(v_name_240))) {
        return heff_clo_n(g_heff_2esyntax_2ecst_2echeckAltNames_lam1, 2, 1, (V[]){heff_dup(v_c_2451)});
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_245;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EField: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_OpRhs: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ann: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELetCond: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETry: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECatch: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2echeckAltNames(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_c_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_strAppend(heff_dup(heff_rfield(v_c_2451, 1)), ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str0));
  V v_t_2457 = heff_strAppend(heff_take_field(v_c_2451, 1), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str1), v_t_2456));
  V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_2451, 3), heff_get_n(v_c_2451, 4, 9)});
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str2), v_t_2457), v_t_2458, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get_n(v_s_2410, 3, 5);
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    return v_x_2412;
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 5, 9), heff_take_field(v_s_2423, 3)});
  return ({ V rv_3 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_s_2423, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7(V self, V *args) {
  V v_s_2432 = args[0];
  V v_k_2433 = (g_list_2edrop(MK_INT(1LL), heff_rfield(v_s_2432, 3)));
  return ({ V rv_3 = v_k_2433; V rr_ = heff_rec_reuse_nf(v_s_2432, 23ULL, 5, shape_toks__i__top__stack__start, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V f_ = v_k_241;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2436, NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam9, 1, 2, (V[]){v_k_241, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam7_clo)})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(heff_get_n(v_x_244, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_dup(heff_rfield(v_x_244, 6));
  V v_t_2418 = heff_bool(((heff_dup(v_t_2417) == NTAG(TAG_True)) && heff_intLe_c(heff_dup(heff_rfield(v_x_244, 5)), heff_dup(v_x_2416))));
  heff_drop(v_x_2416);
  heff_drop(v_t_2417);
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str2), v_t_2419, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2418);
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2425}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2426;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str0))) {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam1_clo)})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}