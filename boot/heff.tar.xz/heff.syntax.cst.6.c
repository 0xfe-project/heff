// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclaredAt(V);
V g_heff_2esyntax_2ecst_2edeclaredAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredAt_clo;
V g_heff_2esyntax_2ecst_2edeclaredTwo(V, V);
V g_heff_2esyntax_2ecst_2edeclaredTwo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredTwo_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817_clo;
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(V, V);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_clo;
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V, V);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2enext_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_entry, 2, 0};

V g_heff_2esyntax_2ecst_2enext(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enext(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_take_field(v_s_245, 1), MK_INT(1LL));
  return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_245, 29ULL, 5, shape_toks__i__top__stack__start, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_241;
  args[0] = v_x_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam3, 1, 2, (V[]){v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2enext_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyGo_entry, 4, 0};

V g_heff_2esyntax_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_p_240})));
}
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_x_244);
    heff_drop(v_p_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_244);
    V v_t_249 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_247)));
    V v_x1_2412 = heff_bool(((heff_dup(v_t_249) == NTAG(TAG_True)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str0)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str1)) && heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str2))))));
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_t_249);
    if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      V f_ = heff_dup(v_p_240);
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam2, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_240);
      heff_drop_rec(v_hd_242, 3);
      heff_drop(v_x1_2412);
      V v_x_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      V f_ = v_k_243;
      args[0] = v_x_2414;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam1, 1, 5, (V[]){v_x_244, v_acc_241, v_k_243, v_p_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_247, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam5, 1, 3, (V[]){v_k_242, v_x_247, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_2410, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_str1))) {
      if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_2411);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 13);
        V f_ = v_k_242;
        args[0] = v_x_247;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2411);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_247})));
      }
    } else {
      heff_drop(v_x_2411);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 13);
      V f_ = v_k_242;
      args[0] = v_x_247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam3, 1, 5, (V[]){v_x_2410, v_k_242, v_x_247, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam2, 1, 4, (V[]){v_hd_241, v_k_242, v_x_247, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2esyntax_2ecst_2eexprHead(heff_dup(v_g_240), v_x_245));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam0, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2417}), v_acc_241});
  V v_x_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2418));
  V f_ = v_k_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2425}), v_acc_241});
  V v_x_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2426));
  V f_ = v_k_243;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2428}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2429, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2430}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2431, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2415, 1)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str1))) {
    heff_drop_rec(v_x_2415, 9);
    V f_ = heff_get_n(v_g_240, 0, 13);
    heff_room[0] = v_hd_242;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam4, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2415, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str2))) {
      V v_t_2421 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2415, 1, 9)}));
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str3), NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str5), v_t_2422})});
      V v_t_2424 = ({ V a_0 = v_t_2421; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str6), v_t_2423}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_242;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam5, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2424);
        V f_ = heff_dup(heff_rfield(v_g_240, 3));
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam6, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2415, 9);
      V f_ = heff_dup(heff_rfield(v_g_240, 3));
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam7, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam3, 1, 5, (V[]){v_g_240, v_hd_242, v_x_2412, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str0)) && ({ V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_246, 1))})); int c_ = ({ V v_x1_2410 = ({ V a_0 = heff_dup(v_t_249); V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; }); int c_ = ((heff_dup(v_x1_2410) == NTAG(TAG_True)) ? 0 : !(heff_dup(v_x_247) == NTAG(TAG_True))); heff_drop(v_x1_2410); c_; }); heff_drop(v_t_249); c_; })));
  heff_drop(v_x_247);
  heff_drop_rec(v_x_246, 9);
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam2, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
  } else {
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_t_2411);
    V v_x_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam1, 1, 5, (V[]){v_x_246, v_hd_242, v_g_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_2410, v_a_2411}), v_items_241});
  return (g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362(v_sep_240, v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam2(V self, V *args) {
  V v_a_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam3, 1, 7, (V[]){v_a_2410, v_items_241, v_sep_240, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_249, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s680137441x181447362_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2415 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2413, v_t_2414});
    V f_ = v_k_244;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_s_2426 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_st_2427 = heff_env(self)[2];
  V v_k_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2437;
  if (heff_strEq_c_lent(v_s_2426, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7), 2)) {
    heff_drop(v_s_2426);
    v_t_2437 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2426, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8))) {
      v_t_2437 = MK_INT(2LL);
    } else {
      v_t_2437 = MK_INT(-1LL);
    }
  }
  V v_t_2440;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Nil: {
    v_t_2440 = v_x_2433;
    break;
  }
  case TAG_Cons: {
    v_t_2440 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2433, v_x_2434});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_t_2437, v_t_2440, v_st_2427, v_k_2428));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_st_2427 = heff_env(self)[1];
  V v_s_2426 = heff_env(self)[2];
  V v_k_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2433;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nil: {
    v_x_2433 = v_x_2429;
    break;
  }
  case TAG_Cons: {
    v_x_2433 = heff_tag_n(TAG_App, 2, (V[]){v_x_2429, v_x_2430});
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(NTAG(TAG_Nil), heff_dup(v_st_2427), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam6, 1, 4, (V[]){v_s_2426, v_x_2433, v_st_2427, v_k_2428})));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_2427 = heff_env(self)[0];
  V v_s_2426 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_st_2427), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5, 1, 4, (V[]){v_x_2429, v_st_2427, v_s_2426, v_k_2428})));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args) {
  V v_st_2427 = args[0];
  V v_k_2428 = args[1];
  V v_s_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_st_2427), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4, 1, 3, (V[]){v_st_2427, v_s_2426, v_k_2428})));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_minPrec_240, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_241, v_x_2420, v_x_2442}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2421 = heff_dup(heff_rfield(v_x_246, 1));
  V v_t_2424;
  if (heff_strEq_c_lent(v_s_2421, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5), 2)) {
    heff_drop(v_s_2421);
    v_t_2424 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2421, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6))) {
      v_t_2424 = MK_INT(2LL);
    } else {
      v_t_2424 = MK_INT(-1LL);
    }
  }
  V v_c_2441;
  if (heff_intEq_c(v_t_2424, MK_INT(1LL))) {
    heff_drop_rec(v_x_246, 9);
    v_c_2441 = ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo);
  } else {
    V v_s_2426 = heff_get_n(v_x_246, 1, 9);
    v_c_2441 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3, 2, 1, (V[]){v_s_2426});
  }
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam7, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2420, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0))) {
    V v_s_249 = heff_dup(heff_rfield(v_x_246, 1));
    V v_t_2412;
    if (heff_strEq_c_lent(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1), 2)) {
      heff_drop(v_s_249);
      v_t_2412 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2))) {
        v_t_2412 = MK_INT(2LL);
      } else {
        v_t_2412 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_t_2412)) {
      V v_s_2414 = heff_dup(heff_rfield(v_x_246, 1));
      V v_t_2417;
      if (heff_strEq_c_lent(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3), 2)) {
        heff_drop(v_s_2414);
        v_t_2417 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4))) {
          v_t_2417 = MK_INT(2LL);
        } else {
          v_t_2417 = MK_INT(-1LL);
        }
      }
      v_t_2419 = heff_bool((heff_intLe_c(heff_dup(v_minPrec_240), heff_dup(v_t_2417)) && !(heff_dup(v_x_247) == NTAG(TAG_True))));
      heff_drop(v_x_247);
      heff_drop(v_t_2417);
    } else {
      heff_drop(v_x_247);
      v_t_2419 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_247);
    v_t_2419 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2, 1, 5, (V[]){v_x_246, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
  } else {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_minPrec_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_t_2419);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_lhs_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1, 1, 5, (V[]){v_x_246, v_minPrec_240, v_hd_242, v_lhs_241, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11, 3, "let");
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam8, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam12(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam12, 2, 0};
Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V v_t_240) {
top: ;
  V v_t_242 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1))));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_242);
    return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 8));
  } else {
    heff_drop(v_t_242);
    V v_t_244 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_t_244);
      return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 9));
    } else {
      heff_drop(v_t_244);
      V v_t_246 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5))));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 9);
        heff_drop(v_t_246);
        return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 10));
      } else {
        heff_drop(v_t_246);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7))) {
            heff_drop_rec(v_t_240, 9);
            return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 11));
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8))) {
              if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9))) {
                return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
              } else {
                return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo);
              }
            } else {
              heff_drop_rec(v_t_240, 9);
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4_clo);
            }
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10))) {
            if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11))) {
              return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
            } else {
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam8_clo);
            }
          } else {
            heff_drop_rec(v_t_240, 9);
            return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam12_clo);
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(a[0]);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_st_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    v_t_2421 = v_x_2417;
    break;
  }
  case TAG_Cons: {
    v_t_2421 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2417, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_t_2421, v_st_2411, v_k_2412));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_st_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = v_x_2413;
    break;
  }
  case TAG_Cons: {
    v_x_2417 = heff_tag_n(TAG_App, 2, (V[]){v_x_2413, v_x_2414});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(NTAG(TAG_Nil), heff_dup(v_st_2411), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3, 1, 3, (V[]){v_x_2417, v_st_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_st_2411), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2, 1, 3, (V[]){v_x_2413, v_st_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args) {
  V v_st_2411 = args[0];
  V v_k_2412 = args[1];
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_st_2411), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1, 1, 2, (V[]){v_st_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_st_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nil: {
    v_t_2432 = v_x_2428;
    break;
  }
  case TAG_Cons: {
    v_t_2432 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2428, v_x_2429});
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_t_2432, v_st_2422, v_k_2423));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_st_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nil: {
    v_x_2428 = v_x_2424;
    break;
  }
  case TAG_Cons: {
    v_x_2428 = heff_tag_n(TAG_App, 2, (V[]){v_x_2424, v_x_2425});
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(NTAG(TAG_Nil), heff_dup(v_st_2422), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7, 1, 3, (V[]){v_x_2428, v_st_2422, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_st_2422), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6, 1, 3, (V[]){v_x_2424, v_st_2422, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args) {
  V v_st_2422 = args[0];
  V v_k_2423 = args[1];
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_st_2422), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5, 1, 2, (V[]){v_st_2422, v_k_2423})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_st_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2445;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nil: {
    v_t_2445 = v_x_2441;
    break;
  }
  case TAG_Cons: {
    v_t_2445 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2441, v_x_2442});
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_t_2445, v_st_2435, v_k_2436));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_st_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nil: {
    v_x_2441 = v_x_2437;
    break;
  }
  case TAG_Cons: {
    v_x_2441 = heff_tag_n(TAG_App, 2, (V[]){v_x_2437, v_x_2438});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(NTAG(TAG_Nil), heff_dup(v_st_2435), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam11, 1, 3, (V[]){v_x_2441, v_st_2435, v_k_2436})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_2435 = heff_env(self)[0];
  V v_k_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_st_2435), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam10, 1, 3, (V[]){v_x_2437, v_st_2435, v_k_2436})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam8(V self, V *args) {
  V v_st_2435 = args[0];
  V v_k_2436 = args[1];
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_st_2435), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam9, 1, 2, (V[]){v_st_2435, v_k_2436})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam15(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  V v_st_2446 = heff_env(self)[1];
  V v_k_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2456;
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Nil: {
    v_t_2456 = v_x_2452;
    break;
  }
  case TAG_Cons: {
    v_t_2456 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2452, v_x_2453});
    break;
  }
  default: heff_nomatch(v_x_2453);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_t_2456, v_st_2446, v_k_2447));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam14(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_st_2446 = heff_env(self)[1];
  V v_k_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nil: {
    v_x_2452 = v_x_2448;
    break;
  }
  case TAG_Cons: {
    v_x_2452 = heff_tag_n(TAG_App, 2, (V[]){v_x_2448, v_x_2449});
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s1789193705x921140817(NTAG(TAG_Nil), heff_dup(v_st_2446), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam15, 1, 3, (V[]){v_x_2452, v_st_2446, v_k_2447})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam13(V self, V *args) {
  V v_x_2448 = args[0];
  V v_st_2446 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_st_2446), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam14, 1, 3, (V[]){v_x_2448, v_st_2446, v_k_2447})));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam12(V self, V *args) {
  V v_st_2446 = args[0];
  V v_k_2447 = args[1];
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_st_2446), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam13, 1, 2, (V[]){v_st_2446, v_k_2447})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1, 2, "::");
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_242, v_x_248, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam3, 1, 3, (V[]){v_k_241, v_x_242, v_x_248})));
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_str1))) {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    } else {
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_24s671502114x146088130_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str1, 62, "` names the type; its constructor needs another name, e.g. `Mk");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str2, 1, "`");
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_entry, 2, 0};

V g_heff_2esyntax_2ecst_2echeckAltNames(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_name_240);
    return ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECon: {
      V v_c_2451 = heff_field(v_x21_244, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2451, 1)), heff_dup(v_name_240))) {
        heff_drop(v_name_240);
        return heff_clo_n(g_heff_2esyntax_2ecst_2echeckAltNames_lam1, 2, 1, (V[]){heff_dup(v_c_2451)});
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_245;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EField: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_OpRhs: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ann: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2echeckAltNames(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_c_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_strAppend(heff_dup(heff_rfield(v_c_2451, 1)), ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str0));
  V v_t_2457 = heff_strAppend(heff_take_field(v_c_2451, 1), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str1), v_t_2456));
  V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_2451, 3), heff_get_n(v_c_2451, 4, 9)});
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str2), v_t_2457), v_t_2458, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str3, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredAt_entry, 1, 0};

V g_heff_2esyntax_2ecst_2edeclaredAt(V v_s_240) {
top: ;
  V v_xs_241 = heff_dup(heff_rfield(v_s_240, 0));
  V v_i_242 = heff_dup(heff_rfield(v_s_240, 2));
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_242))) {
    if (heff_intLt_c(heff_dup(v_i_242), heff_arrayLength_lent(v_xs_241, 0))) {
      V v_t_245 = heff_arrayIndex(v_xs_241, v_i_242);
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_i_242);
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_xs_241);
    heff_drop(v_i_242);
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_xs_248 = heff_take_field(v_s_240, 0);
    V v_i_249 = heff_intAdd(heff_get_n(v_s_240, 2, 5), MK_INT(1LL));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_249))) {
      if (heff_intLt_c(heff_dup(v_i_249), heff_arrayLength_lent(v_xs_248, 0))) {
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        V v_u_2412 = heff_arrayIndex(v_xs_248, v_i_249);
        return (g_heff_2esyntax_2ecst_2edeclaredTwo(v_t_247, v_u_2412));
      } else {
        heff_drop(v_xs_248);
        heff_drop(v_i_249);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str0))) {
          return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_get_n(v_t_247, 1, 9)});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str1))) {
            return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_get_n(v_t_247, 1, 9)});
          } else {
            heff_drop_rec(v_t_247, 9);
            heff_drop_cell(v_ru_24t_246_24Just, 1);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop(v_xs_248);
      heff_drop(v_i_249);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str2))) {
        return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_get_n(v_t_247, 1, 9)});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str3))) {
          return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_get_n(v_t_247, 1, 9)});
        } else {
          heff_drop_rec(v_t_247, 9);
          heff_drop_cell(v_ru_24t_246_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2ecst_2edeclaredAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredAt(a[0]);
}