// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(V);
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_clo;
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(V);
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_clo;
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2einPlace(V);
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2einPlace_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_heff_2ecompile_2emonadic_2evalue(V);
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2evalue_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
Clo g_heff_2ecompile_2emonadic_2evalue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2evalue_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2evalue(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2evalue(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2emonadic_2evalue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EBytes: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2einPlace(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ERecord: {
    V v_fs_24146 = heff_field(v_x1_240, 0);
    V v_t_24148 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_24146)));
    return ({ V a_0 = v_t_24148; V r_ = (g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(a_0)); heff_drop(v_t_24148); r_; });
  }
  case TAG_EProj: {
    V v_e_24149 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_e_24149)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_24149);
    }
  }
  case TAG_ETag: {
    V v_as_24188 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(v_as_24188);
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EPrimCall: {
    V v_p_24261 = heff_field(v_x1_240, 0);
    V v_as_24262 = heff_field(v_x1_240, 1);
    V v_x1_24263 = ({ V a_0 = v_p_24261; V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_24263) == NTAG(TAG_True))) {
      heff_drop(v_x1_24263);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_24263);
      HEFF_LAST return g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(v_as_24262);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2einPlace(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str18, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam19(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EGlobal: {
    V v_t_2411 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELam: {
    V v_t_2420 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EApp: {
    V v_t_2429 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2429);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELet: {
    V v_y_2436 = heff_field(v_e_240, 0);
    V v_c_2437 = heff_field(v_e_240, 1);
    V v_d_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2439 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_d_2438, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam4, 1, 3, (V[]){v_m_2439, v_y_2436, v_c_2437});
  }
  case TAG_ERecord: {
    V v_t_2446 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2446);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EProj: {
    V v_t_2457 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ETag: {
    V v_t_2467 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
      heff_drop(v_t_2467);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2467);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EMatch: {
    V v_t_2476 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop(v_t_2476);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2476);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrim: {
    V v_t_2484 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrimCall: {
    V v_t_2493 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
      heff_drop(v_t_2493);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2493);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ECall: {
    V v_t_24102 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
      heff_drop(v_t_24102);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24102);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EInt: {
    V v_t_24110 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
      heff_drop(v_t_24110);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24110);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat: {
    V v_t_24118 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24118) == NTAG(TAG_True))) {
      heff_drop(v_t_24118);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24118);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EStr: {
    V v_t_24126 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24126) == NTAG(TAG_True))) {
      heff_drop(v_t_24126);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24126);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBytes: {
    V v_t_24134 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24134) == NTAG(TAG_True))) {
      heff_drop(v_t_24134);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24134);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFixed: {
    V v_t_24143 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24143) == NTAG(TAG_True))) {
      heff_drop(v_t_24143);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24143);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat32: {
    V v_t_24151 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24151) == NTAG(TAG_True))) {
      heff_drop(v_t_24151);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24151);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EAbandon: {
    V v_t_24158 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24158) == NTAG(TAG_True))) {
      heff_drop(v_t_24158);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24158);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFix: {
    V v_t_24167 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
      heff_drop(v_t_24167);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24167);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam19, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str0), heff_intShow(heff_dup(v_n_244)));
  V v_m_246 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_245)})}));
  V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){heff_intAdd(v_n_244, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_245, v_e_240, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str1), heff_intShow(heff_dup(v_n_2412)));
  V v_m_2414 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2413)})}));
  V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_intAdd(v_n_2412, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2413, v_e_240, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str2), heff_intShow(heff_dup(v_n_2421)));
  V v_m_2423 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2422)})}));
  V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2422, v_e_240, v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam3(V self, V *args) {
  V v_n_2430 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str3), heff_intShow(heff_dup(v_n_2430)));
  V v_m_2432 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2431)})}));
  V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){heff_intAdd(v_n_2430, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2431, v_e_240, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam4(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_y_2436 = heff_env(self)[1];
  V v_c_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2436, v_c_2437, v_x_2442}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam5(V self, V *args) {
  V v_n_2447 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str4), heff_intShow(heff_dup(v_n_2447)));
  V v_m_2449 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2448)})}));
  V v_x2_2450 = heff_tr(heff_call(v_m_2449, 1, (V[]){heff_intAdd(v_n_2447, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2448, v_e_240, v_x_2451}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam6(V self, V *args) {
  V v_n_2458 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str5), heff_intShow(heff_dup(v_n_2458)));
  V v_m_2460 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2459)})}));
  V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){heff_intAdd(v_n_2458, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_n_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2459, v_e_240, v_x_2462}), v_n_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam7(V self, V *args) {
  V v_n_2468 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str6), heff_intShow(heff_dup(v_n_2468)));
  V v_m_2470 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2469)})}));
  V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){heff_intAdd(v_n_2468, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_n_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2469, v_e_240, v_x_2472}), v_n_2473});
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam8(V self, V *args) {
  V v_n_2477 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str7), heff_intShow(heff_dup(v_n_2477)));
  V v_m_2479 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2478)})}));
  V v_x2_2480 = heff_tr(heff_call(v_m_2479, 1, (V[]){heff_intAdd(v_n_2477, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_n_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2478, v_e_240, v_x_2481}), v_n_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam9(V self, V *args) {
  V v_n_2485 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str8), heff_intShow(heff_dup(v_n_2485)));
  V v_m_2487 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2486)})}));
  V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){heff_intAdd(v_n_2485, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_n_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2486, v_e_240, v_x_2489}), v_n_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam10(V self, V *args) {
  V v_n_2494 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2495 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str9), heff_intShow(heff_dup(v_n_2494)));
  V v_m_2496 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2495)})}));
  V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){heff_intAdd(v_n_2494, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_n_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2495, v_e_240, v_x_2498}), v_n_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam11(V self, V *args) {
  V v_n_24103 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str10), heff_intShow(heff_dup(v_n_24103)));
  V v_m_24105 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24104)})}));
  V v_x2_24106 = heff_tr(heff_call(v_m_24105, 1, (V[]){heff_intAdd(v_n_24103, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_n_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24104, v_e_240, v_x_24107}), v_n_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam12(V self, V *args) {
  V v_n_24111 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24112 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str11), heff_intShow(heff_dup(v_n_24111)));
  V v_m_24113 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24112)})}));
  V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){heff_intAdd(v_n_24111, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_n_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24112, v_e_240, v_x_24115}), v_n_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam13(V self, V *args) {
  V v_n_24119 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str12), heff_intShow(heff_dup(v_n_24119)));
  V v_m_24121 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24120)})}));
  V v_x2_24122 = heff_tr(heff_call(v_m_24121, 1, (V[]){heff_intAdd(v_n_24119, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_n_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24120, v_e_240, v_x_24123}), v_n_24124});
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam14(V self, V *args) {
  V v_n_24127 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str13), heff_intShow(heff_dup(v_n_24127)));
  V v_m_24129 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24128)})}));
  V v_x2_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){heff_intAdd(v_n_24127, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_MkPair: {
    V v_x_24131 = heff_field(v_x2_24130, 0);
    V v_n_24132 = heff_field(v_x2_24130, 1);
    V v_ru_24x2_24130_24MkPair = heff_take_reuse_n(v_x2_24130, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24130_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24128, v_e_240, v_x_24131}), v_n_24132});
  }
  default: return heff_nomatch(v_x2_24130);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam15(V self, V *args) {
  V v_n_24135 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str14), heff_intShow(heff_dup(v_n_24135)));
  V v_m_24137 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24136)})}));
  V v_x2_24138 = heff_tr(heff_call(v_m_24137, 1, (V[]){heff_intAdd(v_n_24135, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24138)) {
  case TAG_MkPair: {
    V v_x_24139 = heff_field(v_x2_24138, 0);
    V v_n_24140 = heff_field(v_x2_24138, 1);
    V v_ru_24x2_24138_24MkPair = heff_take_reuse_n(v_x2_24138, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24136, v_e_240, v_x_24139}), v_n_24140});
  }
  default: return heff_nomatch(v_x2_24138);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam16(V self, V *args) {
  V v_n_24144 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24145 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str15), heff_intShow(heff_dup(v_n_24144)));
  V v_m_24146 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24145)})}));
  V v_x2_24147 = heff_tr(heff_call(v_m_24146, 1, (V[]){heff_intAdd(v_n_24144, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_n_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24145, v_e_240, v_x_24148}), v_n_24149});
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam17(V self, V *args) {
  V v_n_24152 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24153 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str16), heff_intShow(heff_dup(v_n_24152)));
  V v_m_24154 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24153)})}));
  V v_x2_24155 = heff_tr(heff_call(v_m_24154, 1, (V[]){heff_intAdd(v_n_24152, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_n_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24155_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24153, v_e_240, v_x_24156}), v_n_24157});
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam18(V self, V *args) {
  V v_n_24159 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24160 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str17), heff_intShow(heff_dup(v_n_24159)));
  V v_m_24161 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24160)})}));
  V v_x2_24162 = heff_tr(heff_call(v_m_24161, 1, (V[]){heff_intAdd(v_n_24159, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24162)) {
  case TAG_MkPair: {
    V v_x_24163 = heff_field(v_x2_24162, 0);
    V v_n_24164 = heff_field(v_x2_24162, 1);
    V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24162_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24160, v_e_240, v_x_24163}), v_n_24164});
  }
  default: return heff_nomatch(v_x2_24162);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam19(V self, V *args) {
  V v_n_24168 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str18), heff_intShow(heff_dup(v_n_24168)));
  V v_m_24170 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24169)})}));
  V v_x2_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){heff_intAdd(v_n_24168, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24171)) {
  case TAG_MkPair: {
    V v_x_24172 = heff_field(v_x2_24171, 0);
    V v_n_24173 = heff_field(v_x2_24171, 1);
    V v_ru_24x2_24171_24MkPair = heff_take_reuse_n(v_x2_24171, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24169, v_e_240, v_x_24172}), v_n_24173});
  }
  default: return heff_nomatch(v_x2_24171);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eoperandsWith_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eoperandsWith(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_243}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam0, 1, 4, (V[]){v_m_245, v_go_240, v_rest_244, v_k_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eoperandsWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args) {
  V v_rest_27_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_a_27_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_27_2410, v_rest_27_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args) {
  V v_a_27_2410 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(v_go_240, v_rest_244, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam2, 1, 2, (V[]){v_k_242, v_a_27_2410})));
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2412 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_248, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam1, 1, 3, (V[]){v_go_240, v_rest_244, v_k_242})));
    V f_ = v_t_2412;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eflatLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_a_241, 0);
    V v_c_2410 = heff_field(v_a_241, 1);
    V v_d_2411 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2412 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_249, v_c_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2emonadic_2eflatLet_24dps(v_x_240, v_d_2411, v_b_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str18, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam19(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam20(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam21(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam22(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam23(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam24(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam25(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam26(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam27(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam28(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam29(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam30(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam31(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam32(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam33(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam34(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam35(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam36(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam37(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam38(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_t_245 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_245);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EGlobal: {
    V v_t_2411 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_ELam: {
    V v_t_2418 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam4, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam5, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EApp: {
    V v_t_2425 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam6, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2425);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam7, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_ELet: {
    V v_y_2430 = heff_field(v_e_243, 0);
    V v_c_2431 = heff_field(v_e_243, 1);
    V v_d_2432 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2433 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_lit_240, v_lit_241, v_lit_242, v_d_2432));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam8, 1, 3, (V[]){v_m_2433, v_y_2430, v_c_2431});
  }
  case TAG_ERecord: {
    V v_t_2440 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam9, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2440);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam10, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EProj: {
    V v_t_2449 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_t_2449);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam11, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2449);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam12, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_ETag: {
    V v_t_2457 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam13, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam14, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EMatch: {
    V v_t_2464 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
      heff_drop(v_t_2464);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam15, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2464);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam16, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EPrim: {
    V v_t_2470 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
      heff_drop(v_t_2470);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam17, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2470);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam18, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EPrimCall: {
    V v_t_2477 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_t_2477);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam19, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2477);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam20, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_ECall: {
    V v_t_2484 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam21, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2484);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam22, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EInt: {
    V v_t_2490 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2490) == NTAG(TAG_True))) {
      heff_drop(v_t_2490);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam23, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2490);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam24, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EFloat: {
    V v_t_2496 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2496) == NTAG(TAG_True))) {
      heff_drop(v_t_2496);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam25, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2496);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam26, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EStr: {
    V v_t_24102 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
      heff_drop(v_t_24102);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam27, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24102);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam28, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EBytes: {
    V v_t_24108 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24108) == NTAG(TAG_True))) {
      heff_drop(v_t_24108);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam29, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24108);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam30, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EFixed: {
    V v_t_24115 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24115) == NTAG(TAG_True))) {
      heff_drop(v_t_24115);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam31, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24115);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam32, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EFloat32: {
    V v_t_24121 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24121) == NTAG(TAG_True))) {
      heff_drop(v_t_24121);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam33, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24121);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam34, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EAbandon: {
    V v_t_24126 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24126) == NTAG(TAG_True))) {
      heff_drop(v_t_24126);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam35, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24126);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam36, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  case TAG_EFix: {
    V v_t_24133 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
      heff_drop(v_t_24133);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam37, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_24133);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam38, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_246});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str0), heff_intShow(heff_dup(v_n_247)));
  V v_t_249 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_248)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_248, v_e_243, v_t_249}), heff_intAdd(v_n_247, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2(V self, V *args) {
  V v_a_2412 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2412});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str1), heff_intShow(heff_dup(v_n_2413)));
  V v_t_2415 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2414)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2414, v_e_243, v_t_2415}), heff_intAdd(v_n_2413, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam4(V self, V *args) {
  V v_a_2419 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2419});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str2), heff_intShow(heff_dup(v_n_2420)));
  V v_t_2422 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2421)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2421, v_e_243, v_t_2422}), heff_intAdd(v_n_2420, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam6(V self, V *args) {
  V v_a_2426 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2426});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam7(V self, V *args) {
  V v_n_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str3), heff_intShow(heff_dup(v_n_2427)));
  V v_t_2429 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2428)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2428, v_e_243, v_t_2429}), heff_intAdd(v_n_2427, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam8(V self, V *args) {
  V v_n_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_y_2430 = heff_env(self)[1];
  V v_c_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_n_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2430, v_c_2431, v_x_2436}), v_n_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam9(V self, V *args) {
  V v_a_2441 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2441});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam10(V self, V *args) {
  V v_n_2442 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str4), heff_intShow(heff_dup(v_n_2442)));
  V v_t_2444 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2443)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2443, v_e_243, v_t_2444}), heff_intAdd(v_n_2442, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam11(V self, V *args) {
  V v_a_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2450});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam12(V self, V *args) {
  V v_n_2451 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str5), heff_intShow(heff_dup(v_n_2451)));
  V v_t_2453 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2452)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2452, v_e_243, v_t_2453}), heff_intAdd(v_n_2451, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam13(V self, V *args) {
  V v_a_2458 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2458});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam14(V self, V *args) {
  V v_n_2459 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str6), heff_intShow(heff_dup(v_n_2459)));
  V v_t_2461 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2460)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2460, v_e_243, v_t_2461}), heff_intAdd(v_n_2459, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam15(V self, V *args) {
  V v_a_2465 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2465});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam16(V self, V *args) {
  V v_n_2466 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str7), heff_intShow(heff_dup(v_n_2466)));
  V v_t_2468 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2467)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2467, v_e_243, v_t_2468}), heff_intAdd(v_n_2466, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam17(V self, V *args) {
  V v_a_2471 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2471});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam18(V self, V *args) {
  V v_n_2472 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2473 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str8), heff_intShow(heff_dup(v_n_2472)));
  V v_t_2474 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2473)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2473, v_e_243, v_t_2474}), heff_intAdd(v_n_2472, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam19(V self, V *args) {
  V v_a_2478 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2478});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam20(V self, V *args) {
  V v_n_2479 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str9), heff_intShow(heff_dup(v_n_2479)));
  V v_t_2481 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2480)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2480, v_e_243, v_t_2481}), heff_intAdd(v_n_2479, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam21(V self, V *args) {
  V v_a_2485 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2485});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam22(V self, V *args) {
  V v_n_2486 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str10), heff_intShow(heff_dup(v_n_2486)));
  V v_t_2488 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2487)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2487, v_e_243, v_t_2488}), heff_intAdd(v_n_2486, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam23(V self, V *args) {
  V v_a_2491 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2491});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam24(V self, V *args) {
  V v_n_2492 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str11), heff_intShow(heff_dup(v_n_2492)));
  V v_t_2494 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2493)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2493, v_e_243, v_t_2494}), heff_intAdd(v_n_2492, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam25(V self, V *args) {
  V v_a_2497 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2497});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam26(V self, V *args) {
  V v_n_2498 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str12), heff_intShow(heff_dup(v_n_2498)));
  V v_t_24100 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2499)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2499, v_e_243, v_t_24100}), heff_intAdd(v_n_2498, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam27(V self, V *args) {
  V v_a_24103 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24103});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam28(V self, V *args) {
  V v_n_24104 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str13), heff_intShow(heff_dup(v_n_24104)));
  V v_t_24106 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24105)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24105, v_e_243, v_t_24106}), heff_intAdd(v_n_24104, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam29(V self, V *args) {
  V v_a_24109 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24109});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam30(V self, V *args) {
  V v_n_24110 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str14), heff_intShow(heff_dup(v_n_24110)));
  V v_t_24112 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24111)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24111, v_e_243, v_t_24112}), heff_intAdd(v_n_24110, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam31(V self, V *args) {
  V v_a_24116 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24116});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam32(V self, V *args) {
  V v_n_24117 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24118 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str15), heff_intShow(heff_dup(v_n_24117)));
  V v_t_24119 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24118)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24118, v_e_243, v_t_24119}), heff_intAdd(v_n_24117, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam33(V self, V *args) {
  V v_a_24122 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24122});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam34(V self, V *args) {
  V v_n_24123 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str16), heff_intShow(heff_dup(v_n_24123)));
  V v_t_24125 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24124)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24124, v_e_243, v_t_24125}), heff_intAdd(v_n_24123, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam35(V self, V *args) {
  V v_a_24127 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24127});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam36(V self, V *args) {
  V v_n_24128 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24129 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str17), heff_intShow(heff_dup(v_n_24128)));
  V v_t_24130 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24129)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24129, v_e_243, v_t_24130}), heff_intAdd(v_n_24128, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam37(V self, V *args) {
  V v_a_24134 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_24134});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam38(V self, V *args) {
  V v_n_24135 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str18), heff_intShow(heff_dup(v_n_24135)));
  V v_t_24137 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24136)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_24136, v_e_243, v_t_24137}), heff_intAdd(v_n_24135, MK_INT(1LL))});
}