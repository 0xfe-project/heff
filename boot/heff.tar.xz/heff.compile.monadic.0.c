// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_name 9869138
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(V);
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_clo;
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(V);
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_clo;
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2einPlace(V);
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2einPlace_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(V);
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_clo;
V g_heff_2ecompile_2emonadic_2evalue(V);
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2evalue_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
Clo g_heff_2ecompile_2emonadic_2evalue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2evalue_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2evalue(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2evalue(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2emonadic_2evalue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2436);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2einPlace(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    V v_fs_24142 = heff_field(v_e_240, 0);
    V v_t_24144 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_24142)));
    return ({ V a_0 = v_t_24144; V r_ = (g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(a_0)); heff_drop(v_t_24144); r_; });
  }
  case TAG_EProj: {
    V v_e1_24145 = heff_field(v_e_240, 0);
    switch (heff_tag_of(v_e1_24145)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_24145);
    }
  }
  case TAG_ETag: {
    V v_as_24183 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2ecompile_2emonadic_2eallA_24s945094886x548010488(v_as_24183);
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    V v_p_24253 = heff_field(v_e_240, 0);
    V v_as_24254 = heff_field(v_e_240, 1);
    V v_x1_24255 = ({ V a_0 = heff_dup(v_p_24253); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_24255) == NTAG(TAG_True))) {
      heff_drop(v_x1_24255);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_24255);
      HEFF_LAST return g_heff_2ecompile_2emonadic_2eallA_24s91063759x865326252(v_as_24254);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2einPlace(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str0, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str1, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str2, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str3, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str4, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str5, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str6, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str7, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str8, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str9, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str10, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str11, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str12, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str13, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str14, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str15, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str16, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str17, 2, "t$");
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str18, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam13(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam14(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam15(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam16(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam17(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam18(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam19(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_243);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EGlobal: {
    V v_t_2411 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELam: {
    V v_t_2420 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EApp: {
    V v_t_2429 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2429);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ELet: {
    V v_y_2436 = heff_field(v_e_240, 0);
    V v_c_2437 = heff_field(v_e_240, 1);
    V v_d_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2439 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_d_2438, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam4, 1, 3, (V[]){v_m_2439, v_y_2436, v_c_2437});
  }
  case TAG_ERecord: {
    V v_t_2446 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2446);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EProj: {
    V v_t_2457 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ETag: {
    V v_t_2466 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2466);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EMatch: {
    V v_t_2475 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_t_2475);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2475);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrim: {
    V v_t_2483 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
      heff_drop(v_t_2483);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2483);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EPrimCall: {
    V v_t_2492 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
      heff_drop(v_t_2492);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2492);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_ECall: {
    V v_t_24101 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
      heff_drop(v_t_24101);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24101);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EInt: {
    V v_t_24109 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24109) == NTAG(TAG_True))) {
      heff_drop(v_t_24109);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24109);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat: {
    V v_t_24117 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
      heff_drop(v_t_24117);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24117);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EStr: {
    V v_t_24125 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
      heff_drop(v_t_24125);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24125);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EBytes: {
    V v_t_24133 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
      heff_drop(v_t_24133);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24133);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFixed: {
    V v_t_24142 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24142) == NTAG(TAG_True))) {
      heff_drop(v_t_24142);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24142);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFloat32: {
    V v_t_24150 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24150) == NTAG(TAG_True))) {
      heff_drop(v_t_24150);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24150);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EAbandon: {
    V v_t_24157 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24157) == NTAG(TAG_True))) {
      heff_drop(v_t_24157);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24157);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  case TAG_EFix: {
    V v_t_24166 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_24166) == NTAG(TAG_True))) {
      heff_drop(v_t_24166);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_24166);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam19, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_245 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str0), heff_intShow(heff_dup(v_n_244)));
  V v_m_246 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_245)})}));
  V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){heff_intAdd(v_n_244, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_245, v_e_240, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str1), heff_intShow(heff_dup(v_n_2412)));
  V v_m_2414 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)})}));
  V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_intAdd(v_n_2412, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2413, v_e_240, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str2), heff_intShow(heff_dup(v_n_2421)));
  V v_m_2423 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)})}));
  V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2422, v_e_240, v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam3(V self, V *args) {
  V v_n_2430 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str3), heff_intShow(heff_dup(v_n_2430)));
  V v_m_2432 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2431)})}));
  V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){heff_intAdd(v_n_2430, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2431, v_e_240, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam4(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_y_2436 = heff_env(self)[1];
  V v_c_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2436, v_c_2437, v_x_2442}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam5(V self, V *args) {
  V v_n_2447 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2448 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str4), heff_intShow(heff_dup(v_n_2447)));
  V v_m_2449 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2448)})}));
  V v_x2_2450 = heff_tr(heff_call(v_m_2449, 1, (V[]){heff_intAdd(v_n_2447, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2448, v_e_240, v_x_2451}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam6(V self, V *args) {
  V v_n_2458 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str5), heff_intShow(heff_dup(v_n_2458)));
  V v_m_2460 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2459)})}));
  V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){heff_intAdd(v_n_2458, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_n_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2459, v_e_240, v_x_2462}), v_n_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam7(V self, V *args) {
  V v_n_2467 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2468 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str6), heff_intShow(heff_dup(v_n_2467)));
  V v_m_2469 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2468)})}));
  V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){heff_intAdd(v_n_2467, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkPair: {
    V v_x_2471 = heff_field(v_x2_2470, 0);
    V v_n_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2468, v_e_240, v_x_2471}), v_n_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam8(V self, V *args) {
  V v_n_2476 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2477 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str7), heff_intShow(heff_dup(v_n_2476)));
  V v_m_2478 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2477)})}));
  V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){heff_intAdd(v_n_2476, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_field(v_x2_2479, 0);
    V v_n_2481 = heff_field(v_x2_2479, 1);
    V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2477, v_e_240, v_x_2480}), v_n_2481});
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam9(V self, V *args) {
  V v_n_2484 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2485 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str8), heff_intShow(heff_dup(v_n_2484)));
  V v_m_2486 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2485)})}));
  V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){heff_intAdd(v_n_2484, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_n_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2485, v_e_240, v_x_2488}), v_n_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam10(V self, V *args) {
  V v_n_2493 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2494 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str9), heff_intShow(heff_dup(v_n_2493)));
  V v_m_2495 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2494)})}));
  V v_x2_2496 = heff_tr(heff_call(v_m_2495, 1, (V[]){heff_intAdd(v_n_2493, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_n_2498 = heff_field(v_x2_2496, 1);
    V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2494, v_e_240, v_x_2497}), v_n_2498});
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam11(V self, V *args) {
  V v_n_24102 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24103 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str10), heff_intShow(heff_dup(v_n_24102)));
  V v_m_24104 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24103)})}));
  V v_x2_24105 = heff_tr(heff_call(v_m_24104, 1, (V[]){heff_intAdd(v_n_24102, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_n_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24103, v_e_240, v_x_24106}), v_n_24107});
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam12(V self, V *args) {
  V v_n_24110 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24111 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str11), heff_intShow(heff_dup(v_n_24110)));
  V v_m_24112 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24111)})}));
  V v_x2_24113 = heff_tr(heff_call(v_m_24112, 1, (V[]){heff_intAdd(v_n_24110, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_MkPair: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    V v_n_24115 = heff_field(v_x2_24113, 1);
    V v_ru_24x2_24113_24MkPair = heff_take_reuse_n(v_x2_24113, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24111, v_e_240, v_x_24114}), v_n_24115});
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam13(V self, V *args) {
  V v_n_24118 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24119 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str12), heff_intShow(heff_dup(v_n_24118)));
  V v_m_24120 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24119)})}));
  V v_x2_24121 = heff_tr(heff_call(v_m_24120, 1, (V[]){heff_intAdd(v_n_24118, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_field(v_x2_24121, 0);
    V v_n_24123 = heff_field(v_x2_24121, 1);
    V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24119, v_e_240, v_x_24122}), v_n_24123});
  }
  default: return heff_nomatch(v_x2_24121);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam14(V self, V *args) {
  V v_n_24126 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24127 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str13), heff_intShow(heff_dup(v_n_24126)));
  V v_m_24128 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24127)})}));
  V v_x2_24129 = heff_tr(heff_call(v_m_24128, 1, (V[]){heff_intAdd(v_n_24126, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_n_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24127, v_e_240, v_x_24130}), v_n_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam15(V self, V *args) {
  V v_n_24134 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24135 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str14), heff_intShow(heff_dup(v_n_24134)));
  V v_m_24136 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24135)})}));
  V v_x2_24137 = heff_tr(heff_call(v_m_24136, 1, (V[]){heff_intAdd(v_n_24134, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_n_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24135, v_e_240, v_x_24138}), v_n_24139});
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam16(V self, V *args) {
  V v_n_24143 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24144 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str15), heff_intShow(heff_dup(v_n_24143)));
  V v_m_24145 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24144)})}));
  V v_x2_24146 = heff_tr(heff_call(v_m_24145, 1, (V[]){heff_intAdd(v_n_24143, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_n_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24144, v_e_240, v_x_24147}), v_n_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam17(V self, V *args) {
  V v_n_24151 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24152 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str16), heff_intShow(heff_dup(v_n_24151)));
  V v_m_24153 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24152)})}));
  V v_x2_24154 = heff_tr(heff_call(v_m_24153, 1, (V[]){heff_intAdd(v_n_24151, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_n_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24152, v_e_240, v_x_24155}), v_n_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam18(V self, V *args) {
  V v_n_24158 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24159 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str17), heff_intShow(heff_dup(v_n_24158)));
  V v_m_24160 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24159)})}));
  V v_x2_24161 = heff_tr(heff_call(v_m_24160, 1, (V[]){heff_intAdd(v_n_24158, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_MkPair: {
    V v_x_24162 = heff_field(v_x2_24161, 0);
    V v_n_24163 = heff_field(v_x2_24161, 1);
    V v_ru_24x2_24161_24MkPair = heff_take_reuse_n(v_x2_24161, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24159, v_e_240, v_x_24162}), v_n_24163});
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam19(V self, V *args) {
  V v_n_24167 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24168 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str18), heff_intShow(heff_dup(v_n_24167)));
  V v_m_24169 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24168)})}));
  V v_x2_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){heff_intAdd(v_n_24167, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_MkPair: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    V v_n_24172 = heff_field(v_x2_24170, 1);
    V v_ru_24x2_24170_24MkPair = heff_take_reuse_n(v_x2_24170, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24168, v_e_240, v_x_24171}), v_n_24172});
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eoperandsWith_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eoperandsWith(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_243}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam0, 1, 4, (V[]){v_m_245, v_go_240, v_rest_244, v_k_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eoperandsWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args) {
  V v_rest_27_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_a_27_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_27_2410, v_rest_27_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args) {
  V v_a_27_2410 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(v_go_240, v_rest_244, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam2, 1, 2, (V[]){v_k_242, v_a_27_2410})));
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2412 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_248, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam1, 1, 3, (V[]){v_go_240, v_rest_244, v_k_242})));
    V f_ = v_t_2412;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eflatLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_a_241, 0);
    V v_c_2410 = heff_field(v_a_241, 1);
    V v_d_2411 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2412 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_249, v_c_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2emonadic_2eflatLet_24dps(v_x_240, v_d_2411, v_b_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam0(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam0, 1, 0};
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam1(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(heff_dup(heff_rfield(v_x_242, 2))));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam1, 1, 3, (V[]){v_m_244, v_x_242, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(a[0]);
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_xs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  V v_x2_2410;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = ({ V rv_2 = v_x_247; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_x2_2410 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_n_248});
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = (g_heff_2ecompile_2emonadic_2etraverseN_24s13240303x301679667(v_xs_243));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2415}), v_n_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}