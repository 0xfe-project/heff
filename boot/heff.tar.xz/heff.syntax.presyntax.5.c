// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_EVar 52881
#define TAG_EndValue 24675
#define TAG_IBytes 10857
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkSegment 38079
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x31_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x31_244, 0);
        V v_xsp_247 = heff_field(v_x31_244, 1);
        V v_e_248 = heff_field(v_x31_244, 2);
        heff_take_n(v_x31_244, 7ULL, 3);
        V v_x_249;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_249 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_249 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_248)));
        }
        HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(v_x_249, v_xs_243));
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_x_2413 = v_field_2411;
          V v_y_2414 = v_field_2412;
          V v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_x_246, v_xsp_247, v_e_248}), v_sp_245});
          return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_y_2414})}});
        }
      }
      case TAG_BadFieldSet: {
        V v_e_2416 = heff_field(v_x31_244, 0);
        heff_take_n(v_x31_244, 1ULL, 1);
        V v_x_2417;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2417 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2417 = (g_heff_2esyntax_2epresyntax_2ehasReturn(heff_dup(v_e_2416)));
        }
        HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1879669654x137321221_24cpr(v_x_2417, v_xs_243));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_y_2422 = v_field_2420;
          V v_t_2423 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_e_2416}), v_sp_245});
          return ((HeffT2){{v_x_2421, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_y_2422})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        heff_take_n(v_a_244, 31ULL, 5);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_246)));
        }
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(v_a_2411, v_xs_243));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_y_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2415, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_y_2416})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0, 0, "");

HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_245, MK_INT(0LL)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_n_249 = v_field_248;
          if (!heff_intEq_c_lent(v_n_249, MK_INT(0LL), 2)) {
            heff_drop(v_n_249);
            return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          } else {
            heff_drop(v_n_249);
            V v_x1_2410 = (g_list_2eany_24s689038521x519269801(v_segs_242));
            if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
              heff_drop(v_x1_2410);
              V v_t_2411 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_242));
              if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
                heff_drop(v_t_2411);
                V v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_242, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0)));
                HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(v_r_240, v_segs_242, v_sp_243, v_t_2412);
              } else {
                heff_drop(v_t_2411);
                return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
              }
            } else {
              heff_drop(v_x1_2410);
              return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
            }
          }
        } else {
          heff_drop(v_field_248);
          return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
        }
      }
    }
  }
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x21_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x21_243, 0);
        V v_sp_245 = heff_field(v_x21_243, 1);
        V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x21_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_seg_2410);
          heff_drop_cell(v_ru_24x21_248_24At, 2);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              V v_ru_24x11_2416_24MkPair = heff_take_reuse_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x11_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_241_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = v_t_2421;
          V t_2 = v_acc_242;
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(heff_tag_at_n(v_ru_24x21_248_24At, TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})));
          V v_t_2428;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            v_t_2428 = v_acc_242;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              V v_ru_24x21_2423_24MkPair = heff_take_reuse_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24x21_2423_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2424}), heff_dup(v_sp_2425)});
              V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2426}), v_sp_2425});
              v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_242});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = NTAG(TAG_Nothing);
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428});
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      V v_ru_24t_243_24At = heff_take_reuse_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_243_24At, v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_249));
        v_t_2412 = heff_tag_at_n(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      V v_ru_24e_2414_24At = heff_take_reuse_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24e_2414_24At, v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      V v_ru_24cod_242_24At = heff_take_reuse_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24cod_242_24At, v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_248});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s513391942x823299088(v_vs_249));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2410});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2411 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_a_2411, 0);
      V v_sp_2413 = heff_field(v_a_2411, 1);
      V v_ru_24a_2411_24At = heff_take_reuse_n(v_a_2411, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2411_24At, v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2414});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2416 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_i_2416)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_i_2416, 0);
      V v_sp_2418 = heff_field(v_i_2416, 1);
      V v_ru_24i_2416_24At = heff_take_reuse_n(v_i_2416, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24i_2416_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_i_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2420});
  }
  case TAG_TChk: {
    V v_c_2421 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2425;
    switch (heff_tag_of(v_c_2421)) {
    case TAG_At: {
      V v_n_2422 = heff_field(v_c_2421, 0);
      V v_sp_2423 = heff_field(v_c_2421, 1);
      V v_ru_24c_2421_24At = heff_take_reuse_n(v_c_2421, 3ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2422));
      v_t_2425 = heff_tag_at_n(v_ru_24c_2421_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_2423});
      break;
    }
    default: heff_nomatch(v_c_2421);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2425});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str2, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str4, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str6, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24tok2_str7, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24tok2_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24tok2(V v_tok_240, V v_t_241, V v_cx_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_At: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_sp_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24At = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_244, 0ULL, 3);
      heff_drop(v_t_241);
      heff_drop_rec(v_cx_242, 6);
      heff_drop_cell(v_ru_24x3_243_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str0)}), v_sp_245});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop(v_t_241);
      heff_drop_rec(v_cx_242, 6);
      heff_drop_cell(v_ru_24x3_243_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str1)}), v_sp_245});
    }
    case TAG_StmtExpr: {
      V v_e_2411 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24StmtExpr = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2411));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop_rec(v_sp_245, 2);
        heff_drop_cell(v_ru_24x3_243_24At, 2);
        heff_drop_cell(v_ru_24x31_244_24StmtExpr, 1);
        heff_drop(v_t_2412);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(v_t_241, v_cx_242, v_e_2411, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_241);
        heff_drop(v_t_2412);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_242, 4)))) {
          V v_t_2413 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_242, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2414 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_242), v_t_2413}), NTAG(TAG_Nil), v_e_2411));
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_x_2417 = v_field_2415;
            V v_y_2418 = v_field_2416;
            V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_cx_242, 0)), 1, 3);
            V v_t_2420 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419}), heff_dup(v_sp_245)});
            V v_t_2421 = heff_intShow(heff_dup(heff_rfield(v_sp_245, 0)));
            V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str3), v_t_2421));
            V v_t_2423 = heff_tag_at_n(v_ru_24x3_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2422}), heff_dup(v_sp_245)});
            V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
            V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2420, v_t_2424));
            V v_rest_2426 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_242), heff_dup(v_sp_245), heff_dup(heff_rfield(v_cx_242, 4)), v_t_2425));
            V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_cx_242, 0)), 0, 3);
            V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2427}), heff_dup(heff_rfield(v_cx_242, 3))});
            V v_t_2429 = heff_intShow(heff_dup(heff_rfield(v_sp_245, 0)));
            V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str5), v_t_2429));
            V v_t_2431 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2430, heff_dup(v_sp_245)}), heff_dup(v_rest_2426)});
            V v_t_2434;
            switch (heff_tag_of(v_rest_2426)) {
            case TAG_At: {
              V v_s_2433 = heff_field(v_rest_2426, 1);
              heff_take_n(v_rest_2426, 2ULL, 2);
              v_t_2434 = v_s_2433;
              break;
            }
            default: heff_nomatch(v_rest_2426);
            }
            V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
            V v_t_2437 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2418, v_t_2436})));
            return ({ V a_0 = v_cx_242; V a_1 = v_x_2417; V a_2 = v_t_2437; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2417); r_; });
          }
        } else {
          heff_drop_cell(v_tok_240, 2);
          heff_drop_rec(v_sp_245, 2);
          heff_drop_cell(v_ru_24x3_243_24At, 2);
          heff_drop_cell(v_ru_24x31_244_24StmtExpr, 1);
          V v_t_2438 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_242, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_242), v_t_2438}), NTAG(TAG_Nil), v_e_2411));
          {
            V v_field_2440 = v_t_2439.f[0];
            V v_field_2441 = v_t_2439.f[1];
            V v_x_2442 = v_field_2440;
            V v_y_2443 = v_field_2441;
            return ({ V a_0 = v_cx_242; V a_1 = v_x_2442; V a_2 = v_y_2443; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2442); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_244, 0ULL, 3);
      heff_drop(v_t_241);
      heff_drop_rec(v_cx_242, 6);
      heff_drop_cell(v_ru_24x3_243_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str6)}), v_sp_245});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_244, 0ULL, 3);
      heff_drop(v_t_241);
      heff_drop_rec(v_cx_242, 6);
      heff_drop_cell(v_ru_24x3_243_24At, 2);
      return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24tok2_str7)}), v_sp_245});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24tok2(a[0], a[1], a[2], a[3]);
}