// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_RuneWord 42901
#define TAG_SetPath 11095
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TypeWord 10401
#define LBL_e 319
#define LBL_end 310101
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_start 311115900
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_243 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_244 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_243)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_244;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_st_246 = heff_field(v_x1_245, 0);
      V v_y_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_246, v_xs_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_y_2412 = v_field_2410;
        return ((HeffT2){{v_x_2411, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_247, v_y_2412})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_dup(heff_field(v_x3_242, 0));
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EBinary: {
      V v_segs_2411 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EBinary = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2413 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0, 2, 1, (V[]){v_f_240}), v_st_241, v_segs_2411));
        {
          V v_field_2428 = v_t_2427.f[0];
          V v_field_2429 = v_t_2427.f[1];
          V v_x_2430 = v_field_2428;
          V v_y_2431 = v_field_2429;
          V v_t_2432 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EBinary, TAG_EBinary, 1, (V[]){v_y_2431}), v_sp_2413});
          return ((HeffT2){{v_x_2430, v_t_2432}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EApp: {
      V v_h_2435 = heff_field(v_x31_243, 0);
      V v_args_2436 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2438 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2439 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_h_2435}));
        switch (heff_tag_of(v_x1_2439)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_x1_2439, 0);
          V v_y_2441 = heff_field(v_x1_2439, 1);
          heff_take_n(v_x1_2439, 3ULL, 2);
          HeffT2 v_t_2442 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_x_2440, v_args_2436));
          {
            V v_field_2443 = v_t_2442.f[0];
            V v_field_2444 = v_t_2442.f[1];
            V v_x_2445 = v_field_2443;
            V v_y_2446 = v_field_2444;
            V v_t_2447 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EApp, TAG_EApp, 2, (V[]){v_y_2441, v_y_2446}), v_sp_2438});
            return ((HeffT2){{v_x_2445, v_t_2447}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2439)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENamed: {
      V v_x_2449 = heff_field(v_x31_243, 0);
      V v_e_2450 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ENamed = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2452 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2453 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2450}));
        switch (heff_tag_of(v_x1_2453)) {
        case TAG_MkPair: {
          V v_x_2454 = heff_field(v_x1_2453, 0);
          V v_y_2455 = heff_field(v_x1_2453, 1);
          heff_take_n(v_x1_2453, 3ULL, 2);
          V v_t_2456 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENamed, TAG_ENamed, 2, (V[]){v_x_2449, v_y_2455}), v_sp_2452});
          return ((HeffT2){{v_x_2454, v_t_2456}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2453)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ELam: {
      V v_b_2459 = heff_field(v_x31_243, 0);
      V v_body_2460 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2462 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2463 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_body_2460}));
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_MkPair: {
          V v_x_2464 = heff_field(v_x1_2463, 0);
          V v_y_2465 = heff_field(v_x1_2463, 1);
          heff_take_n(v_x1_2463, 3ULL, 2);
          V v_t_2466 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, (V[]){v_b_2459, v_y_2465}), v_sp_2462});
          return ((HeffT2){{v_x_2464, v_t_2466}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2463)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2467 = heff_field(v_x31_243, 0);
      V v_t_2468 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EAnn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2470 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2471 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2467}));
        switch (heff_tag_of(v_x1_2471)) {
        case TAG_MkPair: {
          V v_x_2472 = heff_field(v_x1_2471, 0);
          V v_y_2473 = heff_field(v_x1_2471, 1);
          heff_take_n(v_x1_2471, 3ULL, 2);
          V v_t_2474 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAnn, TAG_EAnn, 2, (V[]){v_y_2473, v_t_2468}), v_sp_2470});
          return ((HeffT2){{v_x_2472, v_t_2474}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2471)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2475 = heff_field(v_x31_243, 0);
      V v_x_2476 = heff_field(v_x31_243, 1);
      V v_xsp_2477 = heff_field(v_x31_243, 2);
      V v_v_2478 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24ESpec = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2480 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_2481 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2475}));
        switch (heff_tag_of(v_x1_2481)) {
        case TAG_MkPair: {
          V v_x_2482 = heff_field(v_x1_2481, 0);
          V v_y_2483 = heff_field(v_x1_2481, 1);
          heff_take_n(v_x1_2481, 3ULL, 2);
          V v_x1_2484 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_2482, v_v_2478}));
          switch (heff_tag_of(v_x1_2484)) {
          case TAG_MkPair: {
            V v_x_2485 = heff_field(v_x1_2484, 0);
            V v_y_2486 = heff_field(v_x1_2484, 1);
            heff_take_n(v_x1_2484, 3ULL, 2);
            V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ESpec, TAG_ESpec, 4, (V[]){v_y_2483, v_x_2476, v_xsp_2477, v_y_2486}), v_sp_2480});
            return ((HeffT2){{v_x_2485, v_t_2487}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2484)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2481)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EStruct: {
      V v_fs_2490 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EStruct = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_2492 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_f_240, v_st_241, v_fs_2490));
        {
          V v_field_2494 = v_t_2493.f[0];
          V v_field_2495 = v_t_2493.f[1];
          V v_x_2496 = v_field_2494;
          V v_y_2497 = v_field_2495;
          V v_t_2498 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EStruct, TAG_EStruct, 1, (V[]){v_y_2497}), v_sp_2492});
          return ((HeffT2){{v_x_2496, v_t_2498}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2499 = heff_field(v_x31_243, 0);
      V v_fs_24100 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EUpdate = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24102 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24103 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2499}));
        switch (heff_tag_of(v_x1_24103)) {
        case TAG_MkPair: {
          V v_x_24104 = heff_field(v_x1_24103, 0);
          V v_y_24105 = heff_field(v_x1_24103, 1);
          heff_take_n(v_x1_24103, 3ULL, 2);
          HeffT2 v_t_24116 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1, 2, 1, (V[]){v_f_240}), v_x_24104, v_fs_24100));
          {
            V v_field_24117 = v_t_24116.f[0];
            V v_field_24118 = v_t_24116.f[1];
            V v_x_24119 = v_field_24117;
            V v_y_24120 = v_field_24118;
            V v_t_24121 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EUpdate, TAG_EUpdate, 2, (V[]){v_y_24105, v_y_24120}), v_sp_24102});
            return ((HeffT2){{v_x_24119, v_t_24121}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24103)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24122 = heff_field(v_x31_243, 0);
      V v_alts_24123 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24125 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24126 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_s_24122}));
        switch (heff_tag_of(v_x1_24126)) {
        case TAG_MkPair: {
          V v_x_24127 = heff_field(v_x1_24126, 0);
          V v_y_24128 = heff_field(v_x1_24126, 1);
          heff_take_n(v_x1_24126, 3ULL, 2);
          HeffT2 v_t_24139 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2, 2, 1, (V[]){v_f_240}), v_x_24127, v_alts_24123));
          {
            V v_field_24140 = v_t_24139.f[0];
            V v_field_24141 = v_t_24139.f[1];
            V v_x_24142 = v_field_24140;
            V v_y_24143 = v_field_24141;
            V v_t_24144 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_24128, v_y_24143}), v_sp_24125});
            return ((HeffT2){{v_x_24142, v_t_24144}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24126)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24145 = heff_field(v_x31_243, 0);
      V v_a_24146 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELetIn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24148 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24149 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_rhs_24145}));
        switch (heff_tag_of(v_x1_24149)) {
        case TAG_MkPair: {
          V v_x_24150 = heff_field(v_x1_24149, 0);
          V v_y_24151 = heff_field(v_x1_24149, 1);
          V v_ru_24x1_24149_24MkPair = heff_take_reuse_n(v_x1_24149, 3ULL, 2);
          switch (heff_tag_of(v_a_24146)) {
          case TAG_At: {
            V v_x31_24152 = heff_field(v_a_24146, 0);
            V v_sp_24153 = heff_field(v_a_24146, 1);
            V v_ru_24a_24146_24At = heff_take_reuse_n(v_a_24146, 3ULL, 2);
            switch (heff_tag_of(v_x31_24152)) {
            case TAG_MkAlt: {
              V v_p_24154 = heff_field(v_x31_24152, 0);
              V v_e_24155 = heff_field(v_x31_24152, 1);
              heff_take_n(v_x31_24152, 3ULL, 2);
              V v_x1_24156 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24150, v_e_24155}));
              switch (heff_tag_of(v_x1_24156)) {
              case TAG_MkPair: {
                V v_x_24157 = heff_field(v_x1_24156, 0);
                V v_y_24158 = heff_field(v_x1_24156, 1);
                heff_take_n(v_x1_24156, 3ULL, 2);
                V v_t_24159 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24149_24MkPair, TAG_MkAlt, 2, (V[]){v_p_24154, v_y_24158}), v_sp_24153});
                V v_t_24160 = heff_tag_at_n(v_ru_24a_24146_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24151, v_t_24159}), v_sp_24148});
                return ((HeffT2){{v_x_24157, v_t_24160}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x1_24156)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24152)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24146)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24149)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24161 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EDo = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24163 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24164, v_st_241, v_ss_24161));
        {
          V v_field_24166 = v_t_24165.f[0];
          V v_field_24167 = v_t_24165.f[1];
          V v_x_24168 = v_field_24166;
          V v_y_24169 = v_field_24167;
          V v_t_24170 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EDo, TAG_EDo, 1, (V[]){v_y_24169}), v_sp_24163});
          return ((HeffT2){{v_x_24168, v_t_24170}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EAssign: {
      V v_x_24174 = heff_field(v_x31_243, 0);
      V v_xsp_24175 = heff_field(v_x31_243, 1);
      V v_e_24176 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EAssign = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24178 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24179 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24176}));
        switch (heff_tag_of(v_x1_24179)) {
        case TAG_MkPair: {
          V v_x_24180 = heff_field(v_x1_24179, 0);
          V v_y_24181 = heff_field(v_x1_24179, 1);
          heff_take_n(v_x1_24179, 3ULL, 2);
          V v_t_24182 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAssign, TAG_EAssign, 3, (V[]){v_x_24174, v_xsp_24175, v_y_24181}), v_sp_24178});
          return ((HeffT2){{v_x_24180, v_t_24182}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24179)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24183 = heff_field(v_x31_243, 0);
      V v_body_24184 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EWhile = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24186 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24187 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24183}));
        switch (heff_tag_of(v_x1_24187)) {
        case TAG_MkPair: {
          V v_x_24188 = heff_field(v_x1_24187, 0);
          V v_y_24189 = heff_field(v_x1_24187, 1);
          heff_take_n(v_x1_24187, 3ULL, 2);
          V v_t_24190 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24191 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24190, v_x_24188, v_body_24184));
          {
            V v_field_24192 = v_t_24191.f[0];
            V v_field_24193 = v_t_24191.f[1];
            V v_x_24194 = v_field_24192;
            V v_y_24195 = v_field_24193;
            V v_t_24196 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWhile, TAG_EWhile, 2, (V[]){v_y_24189, v_y_24195}), v_sp_24186});
            return ((HeffT2){{v_x_24194, v_t_24196}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24187)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EFor: {
      V v_p_24197 = heff_field(v_x31_243, 0);
      V v_c_24198 = heff_field(v_x31_243, 1);
      V v_body_24199 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EFor = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24201 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24202 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24198}));
        switch (heff_tag_of(v_x1_24202)) {
        case TAG_MkPair: {
          V v_x_24203 = heff_field(v_x1_24202, 0);
          V v_y_24204 = heff_field(v_x1_24202, 1);
          heff_take_n(v_x1_24202, 3ULL, 2);
          V v_t_24205 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24206 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24205, v_x_24203, v_body_24199));
          {
            V v_field_24207 = v_t_24206.f[0];
            V v_field_24208 = v_t_24206.f[1];
            V v_x_24209 = v_field_24207;
            V v_y_24210 = v_field_24208;
            V v_t_24211 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EFor, TAG_EFor, 3, (V[]){v_p_24197, v_y_24204, v_y_24210}), v_sp_24201});
            return ((HeffT2){{v_x_24209, v_t_24211}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24202)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24212 = heff_field(v_x31_243, 0);
      V v_a_24213 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EIfThen = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24215 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24216 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24212}));
        switch (heff_tag_of(v_x1_24216)) {
        case TAG_MkPair: {
          V v_x_24217 = heff_field(v_x1_24216, 0);
          V v_y_24218 = heff_field(v_x1_24216, 1);
          heff_take_n(v_x1_24216, 3ULL, 2);
          V v_x1_24219 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24217, v_a_24213}));
          switch (heff_tag_of(v_x1_24219)) {
          case TAG_MkPair: {
            V v_x_24220 = heff_field(v_x1_24219, 0);
            V v_y_24221 = heff_field(v_x1_24219, 1);
            heff_take_n(v_x1_24219, 3ULL, 2);
            V v_t_24222 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EIfThen, TAG_EIfThen, 2, (V[]){v_y_24218, v_y_24221}), v_sp_24215});
            return ((HeffT2){{v_x_24220, v_t_24222}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_24219)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24216)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EContinue: {
      heff_drop(v_f_240);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EReturn: {
      V v_e_24223 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EReturn = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24225 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24226 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24223}));
        switch (heff_tag_of(v_x1_24226)) {
        case TAG_MkPair: {
          V v_x_24227 = heff_field(v_x1_24226, 0);
          V v_y_24228 = heff_field(v_x1_24226, 1);
          heff_take_n(v_x1_24226, 3ULL, 2);
          V v_t_24229 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EReturn, TAG_EReturn, 1, (V[]){v_y_24228}), v_sp_24225});
          return ((HeffT2){{v_x_24227, v_t_24229}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24226)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ENest: {
      V v_e_24230 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ENest = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24232 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24233 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24230}));
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_MkPair: {
          V v_x_24234 = heff_field(v_x1_24233, 0);
          V v_y_24235 = heff_field(v_x1_24233, 1);
          heff_take_n(v_x1_24233, 3ULL, 2);
          V v_t_24236 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENest, TAG_ENest, 1, (V[]){v_y_24235}), v_sp_24232});
          return ((HeffT2){{v_x_24234, v_t_24236}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24233)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24237 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ELazy = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24239 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24240 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24237}));
        switch (heff_tag_of(v_x1_24240)) {
        case TAG_MkPair: {
          V v_x_24241 = heff_field(v_x1_24240, 0);
          V v_y_24242 = heff_field(v_x1_24240, 1);
          heff_take_n(v_x1_24240, 3ULL, 2);
          V v_t_24243 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELazy, TAG_ELazy, 1, (V[]){v_y_24242}), v_sp_24239});
          return ((HeffT2){{v_x_24241, v_t_24243}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24240)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24244 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETuple = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24246 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        HeffT2 v_t_24247 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_241, v_es_24244));
        {
          V v_field_24248 = v_t_24247.f[0];
          V v_field_24249 = v_t_24247.f[1];
          V v_x_24250 = v_field_24248;
          V v_y_24251 = v_field_24249;
          V v_t_24252 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETuple, TAG_ETuple, 1, (V[]){v_y_24251}), v_sp_24246});
          return ((HeffT2){{v_x_24250, v_t_24252}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24253 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ETry = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24255 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_f_24256 = v_f_240;
        V v_st_24257 = v_st_241;
        V v_x3_24258 = v_tr_24253;
        V v_x1_24277;
        switch (heff_tag_of(v_x3_24258)) {
        case TAG_MkTry: {
          V v_err_24259 = heff_field(v_x3_24258, 0);
          V v_body_24260 = heff_field(v_x3_24258, 1);
          V v_c_24261 = heff_field(v_x3_24258, 2);
          V v_ru_24x3_24258_24MkTry = heff_take_reuse_n(v_x3_24258, 7ULL, 3);
          V v_t_24262 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){heff_dup(v_f_24256)}));
          HeffT2 v_t_24263 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24262, v_st_24257, v_body_24260));
          {
            V v_field_24264 = v_t_24263.f[0];
            V v_field_24265 = v_t_24263.f[1];
            V v_x_24266 = v_field_24264;
            V v_y_24267 = v_field_24265;
            switch (heff_tag_of(v_c_24261)) {
            case TAG_MkCatchArm: {
              V v_b_24268 = heff_field(v_c_24261, 0);
              V v_ss_24269 = heff_field(v_c_24261, 1);
              V v_ru_24c_24261_24MkCatchArm = heff_take_reuse_n(v_c_24261, 3ULL, 2);
              V v_t_24270 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_24256}));
              HeffT2 v_t_24271 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24270, v_x_24266, v_ss_24269));
              {
                V v_field_24272 = v_t_24271.f[0];
                V v_field_24273 = v_t_24271.f[1];
                V v_x_24274 = v_field_24272;
                V v_y_24275 = v_field_24273;
                V v_t_24276 = heff_tag_at_n(v_ru_24x3_24258_24MkTry, TAG_MkTry, 3, (V[]){v_err_24259, v_y_24267, heff_tag_at_n(v_ru_24c_24261_24MkCatchArm, TAG_MkCatchArm, 2, (V[]){v_b_24268, v_y_24275})});
                v_x1_24277 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24274, v_t_24276});
              }
              break;
            }
            default: heff_nomatch(v_c_24261);
            }
          }
          break;
        }
        default: heff_nomatch(v_x3_24258);
        }
        switch (heff_tag_of(v_x1_24277)) {
        case TAG_MkPair: {
          V v_x_24278 = heff_field(v_x1_24277, 0);
          V v_y_24279 = heff_field(v_x1_24277, 1);
          heff_take_n(v_x1_24277, 3ULL, 2);
          V v_t_24280 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ETry, TAG_ETry, 1, (V[]){v_y_24279}), v_sp_24255});
          return ((HeffT2){{v_x_24278, v_t_24280}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24277)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    case TAG_EWith: {
      V v_w_24281 = heff_field(v_x31_243, 0);
      V v_x_24282 = heff_field(v_x31_243, 1);
      V v_xsp_24283 = heff_field(v_x31_243, 2);
      V v_body_24284 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24EWith = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_At: {
        V v_sp_24286 = heff_field(v_x3_242, 1);
        V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 2ULL, 2);
        V v_x1_24287 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_w_24281}));
        switch (heff_tag_of(v_x1_24287)) {
        case TAG_MkPair: {
          V v_x_24288 = heff_field(v_x1_24287, 0);
          V v_y_24289 = heff_field(v_x1_24287, 1);
          heff_take_n(v_x1_24287, 3ULL, 2);
          V v_t_24290 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
          HeffT2 v_t_24291 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_24290, v_x_24288, v_body_24284));
          {
            V v_field_24292 = v_t_24291.f[0];
            V v_field_24293 = v_t_24291.f[1];
            V v_x_24294 = v_field_24292;
            V v_y_24295 = v_field_24293;
            V v_t_24296 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWith, TAG_EWith, 4, (V[]){v_y_24289, v_x_24282, v_xsp_24283, v_y_24295}), v_sp_24286});
            return ((HeffT2){{v_x_24294, v_t_24296}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24287)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_x3_2415 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2415)) {
  case TAG_At: {
    V v_x31_2416 = heff_field(v_x3_2415, 0);
    V v_sp_2417 = heff_field(v_x3_2415, 1);
    V v_ru_24x3_2415_24At = heff_take_reuse_n(v_x3_2415, 3ULL, 2);
    switch (heff_tag_of(v_x31_2416)) {
    case TAG_MkSegment: {
      V v_v_2418 = heff_field(v_x31_2416, 0);
      V v_ty_2419 = heff_field(v_x31_2416, 1);
      V v_size_2420 = heff_field(v_x31_2416, 2);
      V v_little_2421 = heff_field(v_x31_2416, 3);
      V v_signed_2422 = heff_field(v_x31_2416, 4);
      V v_ru_24x31_2416_24MkSegment = heff_take_reuse_n(v_x31_2416, 31ULL, 5);
      V v_x1_2423 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2414, v_v_2418}));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x1_2423, 0);
        V v_y_2425 = heff_field(v_x1_2423, 1);
        V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
        V v_t_2426 = heff_tag_at_n(v_ru_24x3_2415_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_2416_24MkSegment, TAG_MkSegment, 5, (V[]){v_y_2425, v_ty_2419, v_size_2420, v_little_2421, v_signed_2422}), v_sp_2417});
        return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_t_2426});
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x31_2416);
    }
  }
  default: return heff_nomatch(v_x3_2415);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args) {
  V v_st_24106 = args[0];
  V v_x3_24107 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24107)) {
  case TAG_At: {
    V v_x31_24108 = heff_field(v_x3_24107, 0);
    V v_sp_24109 = heff_field(v_x3_24107, 1);
    V v_ru_24x3_24107_24At = heff_take_reuse_n(v_x3_24107, 3ULL, 2);
    switch (heff_tag_of(v_x31_24108)) {
    case TAG_SetPath: {
      V v_path_24110 = heff_field(v_x31_24108, 0);
      V v_e_24111 = heff_field(v_x31_24108, 1);
      V v_ru_24x31_24108_24SetPath = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
      V v_x1_24112 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24106, v_e_24111}));
      switch (heff_tag_of(v_x1_24112)) {
      case TAG_MkPair: {
        V v_x_24113 = heff_field(v_x1_24112, 0);
        V v_y_24114 = heff_field(v_x1_24112, 1);
        V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
        V v_t_24115 = heff_tag_at_n(v_ru_24x3_24107_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24108_24SetPath, TAG_SetPath, 2, (V[]){v_path_24110, v_y_24114}), v_sp_24109});
        return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){v_x_24113, v_t_24115});
      }
      default: return heff_nomatch(v_x1_24112);
      }
    }
    default: return heff_nomatch(v_x31_24108);
    }
  }
  default: return heff_nomatch(v_x3_24107);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args) {
  V v_st_24129 = args[0];
  V v_x3_24130 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24130)) {
  case TAG_At: {
    V v_x31_24131 = heff_field(v_x3_24130, 0);
    V v_sp_24132 = heff_field(v_x3_24130, 1);
    V v_ru_24x3_24130_24At = heff_take_reuse_n(v_x3_24130, 3ULL, 2);
    switch (heff_tag_of(v_x31_24131)) {
    case TAG_MkAlt: {
      V v_p_24133 = heff_field(v_x31_24131, 0);
      V v_e_24134 = heff_field(v_x31_24131, 1);
      V v_ru_24x31_24131_24MkAlt = heff_take_reuse_n(v_x31_24131, 3ULL, 2);
      V v_x1_24135 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24129, v_e_24134}));
      switch (heff_tag_of(v_x1_24135)) {
      case TAG_MkPair: {
        V v_x_24136 = heff_field(v_x1_24135, 0);
        V v_y_24137 = heff_field(v_x1_24135, 1);
        V v_ru_24x1_24135_24MkPair = heff_take_reuse_n(v_x1_24135, 3ULL, 2);
        V v_t_24138 = heff_tag_at_n(v_ru_24x3_24130_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24131_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24133, v_y_24137}), v_sp_24132});
        return heff_tag_at_n(v_ru_24x1_24135_24MkPair, TAG_MkPair, 2, (V[]){v_x_24136, v_t_24138});
      }
      default: return heff_nomatch(v_x1_24135);
      }
    }
    default: return heff_nomatch(v_x31_24131);
    }
  }
  default: return heff_nomatch(v_x3_24130);
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_2433;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_2433 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      switch (heff_tag_of(v_x_242)) {
      case TAG_At: {
        V v_a_244 = heff_dup(heff_field(v_x_242, 0));
        switch (heff_tag_of(v_a_244)) {
        case TAG_ELam: {
          heff_take_n(v_a_244, 0ULL, 2);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EDo: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ENest: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ELazy: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ETry: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EWith: {
          heff_take_n(v_a_244, 0ULL, 4);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        default: {
          heff_drop(v_a_244);
          HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_x_242)));
          {
            V v_field_2429 = v_t_2428.f[0];
            V v_field_2430 = v_t_2428.f[1];
            V v_a_2431 = v_field_2429;
            V v_a_2432 = v_field_2430;
            heff_drop(v_a_2432);
            v_st_2433 = v_a_2431;
          }
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x_242);
      }
    }
    HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(v_st_2433, v_xs_243));
    {
      V v_field_2435 = v_t_2434.f[0];
      V v_field_2436 = v_t_2434.f[1];
      V v_x_2437 = v_field_2435;
      V v_y_2438 = v_field_2436;
      return ((HeffT2){{v_x_2437, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_y_2438})}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2410 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2412 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24cpr(v_st_240, v_segs_2410));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x_2416 = v_field_2414;
          V v_y_2417 = v_field_2415;
          V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2417}), v_sp_2412});
          return ((HeffT2){{v_x_2416, v_t_2418}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2421 = heff_field(v_x31_242, 0);
      V v_args_2422 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2424 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2439;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2439 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_h_2421)) {
          case TAG_At: {
            V v_e1_2425 = heff_dup(heff_field(v_h_2421, 0));
            switch (heff_tag_of(v_e1_2425)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2425, 0ULL, 2);
              switch (heff_tag_of(v_h_2421)) {
              case TAG_At: {
                v_x_2439 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2421);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2425, 0ULL, 1);
              switch (heff_tag_of(v_h_2421)) {
              case TAG_At: {
                v_x_2439 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_h_2421);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2425);
              HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_h_2421)));
              {
                V v_field_2435 = v_t_2434.f[0];
                V v_field_2436 = v_t_2434.f[1];
                V v_x_2437 = v_field_2435;
                V v_y_2438 = v_field_2436;
                heff_drop(v_y_2438);
                v_x_2439 = v_x_2437;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_h_2421);
          }
        }
        HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(v_x_2439, v_args_2422));
        {
          V v_field_2441 = v_t_2440.f[0];
          V v_field_2442 = v_t_2440.f[1];
          V v_x_2443 = v_field_2441;
          V v_y_2444 = v_field_2442;
          V v_t_2445 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, (V[]){v_h_2421, v_y_2444}), v_sp_2424});
          return ((HeffT2){{v_x_2443, v_t_2445}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2447 = heff_field(v_x31_242, 0);
      V v_e_2448 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2450 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2465;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2465 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_2448)) {
          case TAG_At: {
            V v_e1_2451 = heff_dup(heff_field(v_e_2448, 0));
            switch (heff_tag_of(v_e1_2451)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2451, 0ULL, 2);
              switch (heff_tag_of(v_e_2448)) {
              case TAG_At: {
                v_x_2465 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2448);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2451, 0ULL, 1);
              switch (heff_tag_of(v_e_2448)) {
              case TAG_At: {
                v_x_2465 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2448);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2451);
              HeffT2 v_t_2460 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2448)));
              {
                V v_field_2461 = v_t_2460.f[0];
                V v_field_2462 = v_t_2460.f[1];
                V v_x_2463 = v_field_2461;
                V v_y_2464 = v_field_2462;
                heff_drop(v_y_2464);
                v_x_2465 = v_x_2463;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2448);
          }
        }
        V v_t_2466 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, (V[]){v_x_2447, v_e_2448}), v_sp_2450});
        return ((HeffT2){{v_x_2465, v_t_2466}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_2469 = heff_field(v_x31_242, 0);
      V v_body_2470 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2472 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2487;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2487 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_body_2470)) {
          case TAG_At: {
            V v_e1_2473 = heff_dup(heff_field(v_body_2470, 0));
            switch (heff_tag_of(v_e1_2473)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2473, 0ULL, 2);
              switch (heff_tag_of(v_body_2470)) {
              case TAG_At: {
                v_x_2487 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_2470);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2473, 0ULL, 1);
              switch (heff_tag_of(v_body_2470)) {
              case TAG_At: {
                v_x_2487 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_body_2470);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2473);
              HeffT2 v_t_2482 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_body_2470)));
              {
                V v_field_2483 = v_t_2482.f[0];
                V v_field_2484 = v_t_2482.f[1];
                V v_x_2485 = v_field_2483;
                V v_y_2486 = v_field_2484;
                heff_drop(v_y_2486);
                v_x_2487 = v_x_2485;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_body_2470);
          }
        }
        V v_t_2488 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, (V[]){v_b_2469, v_body_2470}), v_sp_2472});
        return ((HeffT2){{v_x_2487, v_t_2488}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2489 = heff_field(v_x31_242, 0);
      V v_t_2490 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2492 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24107;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24107 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_2489)) {
          case TAG_At: {
            V v_e1_2493 = heff_dup(heff_field(v_e_2489, 0));
            switch (heff_tag_of(v_e1_2493)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2493, 0ULL, 2);
              switch (heff_tag_of(v_e_2489)) {
              case TAG_At: {
                v_x_24107 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2489);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_2493, 0ULL, 1);
              switch (heff_tag_of(v_e_2489)) {
              case TAG_At: {
                v_x_24107 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2489);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2493);
              HeffT2 v_t_24102 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2489)));
              {
                V v_field_24103 = v_t_24102.f[0];
                V v_field_24104 = v_t_24102.f[1];
                V v_x_24105 = v_field_24103;
                V v_y_24106 = v_field_24104;
                heff_drop(v_y_24106);
                v_x_24107 = v_x_24105;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2489);
          }
        }
        V v_t_24108 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, (V[]){v_e_2489, v_t_2490}), v_sp_2492});
        return ((HeffT2){{v_x_24107, v_t_24108}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_24109 = heff_field(v_x31_242, 0);
      V v_x_24110 = heff_field(v_x31_242, 1);
      V v_xsp_24111 = heff_field(v_x31_242, 2);
      V v_v_24112 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24114 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24115 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24109, v_x_24110, v_xsp_24111, v_v_24112}), v_sp_24114});
          return ((HeffT2){{NTAG(TAG_True), v_t_24115}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24109)) {
          case TAG_At: {
            V v_e1_24116 = heff_dup(heff_field(v_a_24109, 0));
            switch (heff_tag_of(v_e1_24116)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24116, 0ULL, 2);
              V v_x_24134;
              switch (heff_tag_of(v_v_24112)) {
              case TAG_At: {
                V v_e1_24120 = heff_dup(heff_field(v_v_24112, 0));
                switch (heff_tag_of(v_e1_24120)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24120, 0ULL, 2);
                  switch (heff_tag_of(v_v_24112)) {
                  case TAG_At: {
                    v_x_24134 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24112);
                  }
                  break;
                }
                case TAG_EReturn: {
                  heff_take_n(v_e1_24120, 0ULL, 1);
                  switch (heff_tag_of(v_v_24112)) {
                  case TAG_At: {
                    v_x_24134 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24112);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24120);
                  HeffT2 v_t_24129 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_v_24112)));
                  {
                    V v_field_24130 = v_t_24129.f[0];
                    V v_field_24131 = v_t_24129.f[1];
                    V v_x_24132 = v_field_24130;
                    V v_y_24133 = v_field_24131;
                    heff_drop(v_y_24133);
                    v_x_24134 = v_x_24132;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24112);
              }
              V v_t_24135 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24109, v_x_24110, v_xsp_24111, v_v_24112}), v_sp_24114});
              return ((HeffT2){{v_x_24134, v_t_24135}});
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24116, 0ULL, 1);
              V v_t_24137 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24109, v_x_24110, v_xsp_24111, v_v_24112}), v_sp_24114});
              return ((HeffT2){{NTAG(TAG_True), v_t_24137}});
            }
            default: {
              heff_drop(v_e1_24116);
              HeffT2 v_t_24138 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24109)));
              {
                V v_field_24139 = v_t_24138.f[0];
                V v_field_24140 = v_t_24138.f[1];
                V v_x_24141 = v_field_24139;
                V v_y_24142 = v_field_24140;
                heff_drop(v_y_24142);
                V v_x_24157;
                if ((heff_dup(v_x_24141) == NTAG(TAG_True))) {
                  heff_drop(v_x_24141);
                  v_x_24157 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24141);
                  switch (heff_tag_of(v_v_24112)) {
                  case TAG_At: {
                    V v_e1_24143 = heff_dup(heff_field(v_v_24112, 0));
                    switch (heff_tag_of(v_e1_24143)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24143, 0ULL, 2);
                      switch (heff_tag_of(v_v_24112)) {
                      case TAG_At: {
                        v_x_24157 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24112);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24143, 0ULL, 1);
                      switch (heff_tag_of(v_v_24112)) {
                      case TAG_At: {
                        v_x_24157 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_v_24112);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24143);
                      HeffT2 v_t_24152 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_v_24112)));
                      {
                        V v_field_24153 = v_t_24152.f[0];
                        V v_field_24154 = v_t_24152.f[1];
                        V v_x_24155 = v_field_24153;
                        V v_y_24156 = v_field_24154;
                        heff_drop(v_y_24156);
                        v_x_24157 = v_x_24155;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_v_24112);
                  }
                }
                V v_t_24158 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, (V[]){v_a_24109, v_x_24110, v_xsp_24111, v_v_24112}), v_sp_24114});
                return ((HeffT2){{v_x_24157, v_t_24158}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24109)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_24161 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24163 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24164 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24cpr(v_st_240, v_fs_24161));
        {
          V v_field_24165 = v_t_24164.f[0];
          V v_field_24166 = v_t_24164.f[1];
          V v_x_24167 = v_field_24165;
          V v_y_24168 = v_field_24166;
          V v_t_24169 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_24168}), v_sp_24163});
          return ((HeffT2){{v_x_24167, v_t_24169}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_24170 = heff_field(v_x31_242, 0);
      V v_fs_24171 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24173 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24188;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24188 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24170)) {
          case TAG_At: {
            V v_e1_24174 = heff_dup(heff_field(v_a_24170, 0));
            switch (heff_tag_of(v_e1_24174)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24174, 0ULL, 2);
              switch (heff_tag_of(v_a_24170)) {
              case TAG_At: {
                v_x_24188 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24170);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24174, 0ULL, 1);
              switch (heff_tag_of(v_a_24170)) {
              case TAG_At: {
                v_x_24188 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_24170);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24174);
              HeffT2 v_t_24183 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24170)));
              {
                V v_field_24184 = v_t_24183.f[0];
                V v_field_24185 = v_t_24183.f[1];
                V v_x_24186 = v_field_24184;
                V v_y_24187 = v_field_24185;
                heff_drop(v_y_24187);
                v_x_24188 = v_x_24186;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_24170);
          }
        }
        HeffT2 v_t_24189 = (g_heff_2esyntax_2epresyntax_2eaccList_24s605646493x1315728604_24cpr(v_x_24188, v_fs_24171));
        {
          V v_field_24190 = v_t_24189.f[0];
          V v_field_24191 = v_t_24189.f[1];
          V v_x_24192 = v_field_24190;
          V v_y_24193 = v_field_24191;
          V v_t_24194 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, (V[]){v_a_24170, v_y_24193}), v_sp_24173});
          return ((HeffT2){{v_x_24192, v_t_24194}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24195 = heff_field(v_x31_242, 0);
      V v_alts_24196 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24198 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24213;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24213 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_s_24195)) {
          case TAG_At: {
            V v_e1_24199 = heff_dup(heff_field(v_s_24195, 0));
            switch (heff_tag_of(v_e1_24199)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24199, 0ULL, 2);
              switch (heff_tag_of(v_s_24195)) {
              case TAG_At: {
                v_x_24213 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24195);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24199, 0ULL, 1);
              switch (heff_tag_of(v_s_24195)) {
              case TAG_At: {
                v_x_24213 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_s_24195);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24199);
              HeffT2 v_t_24208 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_s_24195)));
              {
                V v_field_24209 = v_t_24208.f[0];
                V v_field_24210 = v_t_24208.f[1];
                V v_x_24211 = v_field_24209;
                V v_y_24212 = v_field_24210;
                heff_drop(v_y_24212);
                v_x_24213 = v_x_24211;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_s_24195);
          }
        }
        HeffT2 v_t_24214 = (g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(v_x_24213, v_alts_24196));
        {
          V v_field_24215 = v_t_24214.f[0];
          V v_field_24216 = v_t_24214.f[1];
          V v_x_24217 = v_field_24215;
          V v_y_24218 = v_field_24216;
          V v_t_24219 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_24195, v_y_24218}), v_sp_24198});
          return ((HeffT2){{v_x_24217, v_t_24219}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24220 = heff_field(v_x31_242, 0);
      V v_a_24221 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24223 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_24221)) {
          case TAG_At: {
            V v_x31_24224 = heff_field(v_a_24221, 0);
            V v_sp_24225 = heff_field(v_a_24221, 1);
            V v_ru_24a_24221_24At = heff_take_reuse_n(v_a_24221, 3ULL, 2);
            switch (heff_tag_of(v_x31_24224)) {
            case TAG_MkAlt: {
              V v_p_24226 = heff_field(v_x31_24224, 0);
              V v_e_24227 = heff_field(v_x31_24224, 1);
              V v_ru_24x31_24224_24MkAlt = heff_take_reuse_n(v_x31_24224, 3ULL, 2);
              V v_t_24228 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24224_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24226, v_e_24227}), v_sp_24225});
              V v_t_24229 = heff_tag_at_n(v_ru_24a_24221_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24220, v_t_24228}), v_sp_24223});
              return ((HeffT2){{NTAG(TAG_True), v_t_24229}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24224)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24221)}});
          }
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_rhs_24220)) {
          case TAG_At: {
            V v_e1_24230 = heff_dup(heff_field(v_rhs_24220, 0));
            switch (heff_tag_of(v_e1_24230)) {
            case TAG_ELam: {
              V v_ru_24e1_24230_24ELam = heff_take_reuse_n(v_e1_24230, 0ULL, 2);
              switch (heff_tag_of(v_a_24221)) {
              case TAG_At: {
                V v_x31_24234 = heff_field(v_a_24221, 0);
                V v_sp_24235 = heff_field(v_a_24221, 1);
                V v_ru_24a_24221_24At = heff_take_reuse_n(v_a_24221, 3ULL, 2);
                switch (heff_tag_of(v_x31_24234)) {
                case TAG_MkAlt: {
                  V v_p_24236 = heff_field(v_x31_24234, 0);
                  V v_e_24237 = heff_field(v_x31_24234, 1);
                  heff_take_n(v_x31_24234, 3ULL, 2);
                  V v_x_24252;
                  switch (heff_tag_of(v_e_24237)) {
                  case TAG_At: {
                    V v_e1_24238 = heff_dup(heff_field(v_e_24237, 0));
                    switch (heff_tag_of(v_e1_24238)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24238, 0ULL, 2);
                      switch (heff_tag_of(v_e_24237)) {
                      case TAG_At: {
                        v_x_24252 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_e_24237);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24238, 0ULL, 1);
                      switch (heff_tag_of(v_e_24237)) {
                      case TAG_At: {
                        v_x_24252 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_e_24237);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24238);
                      HeffT2 v_t_24247 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24237)));
                      {
                        V v_field_24248 = v_t_24247.f[0];
                        V v_field_24249 = v_t_24247.f[1];
                        V v_x_24250 = v_field_24248;
                        V v_y_24251 = v_field_24249;
                        heff_drop(v_y_24251);
                        v_x_24252 = v_x_24250;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_e_24237);
                  }
                  V v_t_24253 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_24230_24ELam, TAG_MkAlt, 2, (V[]){v_p_24236, v_e_24237}), v_sp_24235});
                  V v_t_24254 = heff_tag_at_n(v_ru_24a_24221_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24220, v_t_24253}), v_sp_24223});
                  return ((HeffT2){{v_x_24252, v_t_24254}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_24234)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_24221)}});
              }
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24230, 0ULL, 1);
              switch (heff_tag_of(v_a_24221)) {
              case TAG_At: {
                V v_x31_24256 = heff_field(v_a_24221, 0);
                V v_sp_24257 = heff_field(v_a_24221, 1);
                V v_ru_24a_24221_24At = heff_take_reuse_n(v_a_24221, 3ULL, 2);
                switch (heff_tag_of(v_x31_24256)) {
                case TAG_MkAlt: {
                  V v_p_24258 = heff_field(v_x31_24256, 0);
                  V v_e_24259 = heff_field(v_x31_24256, 1);
                  V v_ru_24x31_24256_24MkAlt = heff_take_reuse_n(v_x31_24256, 3ULL, 2);
                  V v_t_24260 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24256_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24258, v_e_24259}), v_sp_24257});
                  V v_t_24261 = heff_tag_at_n(v_ru_24a_24221_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24220, v_t_24260}), v_sp_24223});
                  return ((HeffT2){{NTAG(TAG_True), v_t_24261}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_24256)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_a_24221)}});
              }
            }
            default: {
              heff_drop(v_e1_24230);
              HeffT2 v_t_24262 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_rhs_24220)));
              {
                V v_field_24263 = v_t_24262.f[0];
                V v_field_24264 = v_t_24262.f[1];
                V v_x_24265 = v_field_24263;
                V v_y_24266 = v_field_24264;
                heff_drop(v_y_24266);
                switch (heff_tag_of(v_a_24221)) {
                case TAG_At: {
                  V v_x31_24267 = heff_field(v_a_24221, 0);
                  V v_sp_24268 = heff_field(v_a_24221, 1);
                  V v_ru_24a_24221_24At = heff_take_reuse_n(v_a_24221, 3ULL, 2);
                  switch (heff_tag_of(v_x31_24267)) {
                  case TAG_MkAlt: {
                    V v_p_24269 = heff_field(v_x31_24267, 0);
                    V v_e_24270 = heff_field(v_x31_24267, 1);
                    V v_ru_24x31_24267_24MkAlt = heff_take_reuse_n(v_x31_24267, 3ULL, 2);
                    V v_x_24285;
                    if ((heff_dup(v_x_24265) == NTAG(TAG_True))) {
                      heff_drop(v_x_24265);
                      v_x_24285 = NTAG(TAG_True);
                    } else {
                      heff_drop(v_x_24265);
                      switch (heff_tag_of(v_e_24270)) {
                      case TAG_At: {
                        V v_e1_24271 = heff_dup(heff_field(v_e_24270, 0));
                        switch (heff_tag_of(v_e1_24271)) {
                        case TAG_ELam: {
                          heff_take_n(v_e1_24271, 0ULL, 2);
                          switch (heff_tag_of(v_e_24270)) {
                          case TAG_At: {
                            v_x_24285 = NTAG(TAG_False);
                            break;
                          }
                          default: heff_nomatch(v_e_24270);
                          }
                          break;
                        }
                        case TAG_EReturn: {
                          heff_take_n(v_e1_24271, 0ULL, 1);
                          switch (heff_tag_of(v_e_24270)) {
                          case TAG_At: {
                            v_x_24285 = NTAG(TAG_True);
                            break;
                          }
                          default: heff_nomatch(v_e_24270);
                          }
                          break;
                        }
                        default: {
                          heff_drop(v_e1_24271);
                          HeffT2 v_t_24280 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24270)));
                          {
                            V v_field_24281 = v_t_24280.f[0];
                            V v_field_24282 = v_t_24280.f[1];
                            V v_x_24283 = v_field_24281;
                            V v_y_24284 = v_field_24282;
                            heff_drop(v_y_24284);
                            v_x_24285 = v_x_24283;
                          }
                          break;
                        }
                        }
                        break;
                      }
                      default: heff_nomatch(v_e_24270);
                      }
                    }
                    V v_t_24286 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_24267_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_24269, v_e_24270}), v_sp_24268});
                    V v_t_24287 = heff_tag_at_n(v_ru_24a_24221_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, (V[]){v_rhs_24220, v_t_24286}), v_sp_24223});
                    return ((HeffT2){{v_x_24285, v_t_24287}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24267)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_a_24221)}});
                }
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_rhs_24220)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24288 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24290 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24291 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_st_240, v_ss_24288));
        {
          V v_field_24292 = v_t_24291.f[0];
          V v_field_24293 = v_t_24291.f[1];
          V v_x_24294 = v_field_24292;
          V v_y_24295 = v_field_24293;
          V v_t_24296 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24295}), v_sp_24290});
          return ((HeffT2){{v_x_24294, v_t_24296}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24300 = heff_field(v_x31_242, 0);
      V v_xsp_24301 = heff_field(v_x31_242, 1);
      V v_e_24302 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24304 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24319;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24319 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24302)) {
          case TAG_At: {
            V v_e1_24305 = heff_dup(heff_field(v_e_24302, 0));
            switch (heff_tag_of(v_e1_24305)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24305, 0ULL, 2);
              switch (heff_tag_of(v_e_24302)) {
              case TAG_At: {
                v_x_24319 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24302);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24305, 0ULL, 1);
              switch (heff_tag_of(v_e_24302)) {
              case TAG_At: {
                v_x_24319 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24302);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24305);
              HeffT2 v_t_24314 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24302)));
              {
                V v_field_24315 = v_t_24314.f[0];
                V v_field_24316 = v_t_24314.f[1];
                V v_x_24317 = v_field_24315;
                V v_y_24318 = v_field_24316;
                heff_drop(v_y_24318);
                v_x_24319 = v_x_24317;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24302);
          }
        }
        V v_t_24320 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, (V[]){v_x_24300, v_xsp_24301, v_e_24302}), v_sp_24304});
        return ((HeffT2){{v_x_24319, v_t_24320}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24321 = heff_field(v_x31_242, 0);
      V v_body_24322 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24324 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24339;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24339 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24321)) {
          case TAG_At: {
            V v_e1_24325 = heff_dup(heff_field(v_c_24321, 0));
            switch (heff_tag_of(v_e1_24325)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24325, 0ULL, 2);
              switch (heff_tag_of(v_c_24321)) {
              case TAG_At: {
                v_x_24339 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24321);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24325, 0ULL, 1);
              switch (heff_tag_of(v_c_24321)) {
              case TAG_At: {
                v_x_24339 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24321);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24325);
              HeffT2 v_t_24334 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24321)));
              {
                V v_field_24335 = v_t_24334.f[0];
                V v_field_24336 = v_t_24334.f[1];
                V v_x_24337 = v_field_24335;
                V v_y_24338 = v_field_24336;
                heff_drop(v_y_24338);
                v_x_24339 = v_x_24337;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24321);
          }
        }
        HeffT2 v_t_24340 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24339, v_body_24322));
        {
          V v_field_24341 = v_t_24340.f[0];
          V v_field_24342 = v_t_24340.f[1];
          V v_x_24343 = v_field_24341;
          V v_y_24344 = v_field_24342;
          V v_t_24345 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, (V[]){v_c_24321, v_y_24344}), v_sp_24324});
          return ((HeffT2){{v_x_24343, v_t_24345}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24346 = heff_field(v_x31_242, 0);
      V v_c_24347 = heff_field(v_x31_242, 1);
      V v_body_24348 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24350 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24365;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24365 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24347)) {
          case TAG_At: {
            V v_e1_24351 = heff_dup(heff_field(v_c_24347, 0));
            switch (heff_tag_of(v_e1_24351)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24351, 0ULL, 2);
              switch (heff_tag_of(v_c_24347)) {
              case TAG_At: {
                v_x_24365 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24347);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24351, 0ULL, 1);
              switch (heff_tag_of(v_c_24347)) {
              case TAG_At: {
                v_x_24365 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24347);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24351);
              HeffT2 v_t_24360 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24347)));
              {
                V v_field_24361 = v_t_24360.f[0];
                V v_field_24362 = v_t_24360.f[1];
                V v_x_24363 = v_field_24361;
                V v_y_24364 = v_field_24362;
                heff_drop(v_y_24364);
                v_x_24365 = v_x_24363;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24347);
          }
        }
        HeffT2 v_t_24366 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24365, v_body_24348));
        {
          V v_field_24367 = v_t_24366.f[0];
          V v_field_24368 = v_t_24366.f[1];
          V v_x_24369 = v_field_24367;
          V v_y_24370 = v_field_24368;
          V v_t_24371 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, (V[]){v_p_24346, v_c_24347, v_y_24370}), v_sp_24350});
          return ((HeffT2){{v_x_24369, v_t_24371}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24372 = heff_field(v_x31_242, 0);
      V v_a_24373 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24375 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          V v_t_24376 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24372, v_a_24373}), v_sp_24375});
          return ((HeffT2){{NTAG(TAG_True), v_t_24376}});
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_c_24372)) {
          case TAG_At: {
            V v_e1_24377 = heff_dup(heff_field(v_c_24372, 0));
            switch (heff_tag_of(v_e1_24377)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24377, 0ULL, 2);
              V v_x_24395;
              switch (heff_tag_of(v_a_24373)) {
              case TAG_At: {
                V v_e1_24381 = heff_dup(heff_field(v_a_24373, 0));
                switch (heff_tag_of(v_e1_24381)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24381, 0ULL, 2);
                  switch (heff_tag_of(v_a_24373)) {
                  case TAG_At: {
                    v_x_24395 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24373);
                  }
                  break;
                }
                case TAG_EReturn: {
                  heff_take_n(v_e1_24381, 0ULL, 1);
                  switch (heff_tag_of(v_a_24373)) {
                  case TAG_At: {
                    v_x_24395 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24373);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24381);
                  HeffT2 v_t_24390 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24373)));
                  {
                    V v_field_24391 = v_t_24390.f[0];
                    V v_field_24392 = v_t_24390.f[1];
                    V v_x_24393 = v_field_24391;
                    V v_y_24394 = v_field_24392;
                    heff_drop(v_y_24394);
                    v_x_24395 = v_x_24393;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24373);
              }
              V v_t_24396 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24372, v_a_24373}), v_sp_24375});
              return ((HeffT2){{v_x_24395, v_t_24396}});
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24377, 0ULL, 1);
              V v_t_24398 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24372, v_a_24373}), v_sp_24375});
              return ((HeffT2){{NTAG(TAG_True), v_t_24398}});
            }
            default: {
              heff_drop(v_e1_24377);
              HeffT2 v_t_24399 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_24372)));
              {
                V v_field_24400 = v_t_24399.f[0];
                V v_field_24401 = v_t_24399.f[1];
                V v_x_24402 = v_field_24400;
                V v_y_24403 = v_field_24401;
                heff_drop(v_y_24403);
                V v_x_24418;
                if ((heff_dup(v_x_24402) == NTAG(TAG_True))) {
                  heff_drop(v_x_24402);
                  v_x_24418 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24402);
                  switch (heff_tag_of(v_a_24373)) {
                  case TAG_At: {
                    V v_e1_24404 = heff_dup(heff_field(v_a_24373, 0));
                    switch (heff_tag_of(v_e1_24404)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24404, 0ULL, 2);
                      switch (heff_tag_of(v_a_24373)) {
                      case TAG_At: {
                        v_x_24418 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24373);
                      }
                      break;
                    }
                    case TAG_EReturn: {
                      heff_take_n(v_e1_24404, 0ULL, 1);
                      switch (heff_tag_of(v_a_24373)) {
                      case TAG_At: {
                        v_x_24418 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_a_24373);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24404);
                      HeffT2 v_t_24413 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_24373)));
                      {
                        V v_field_24414 = v_t_24413.f[0];
                        V v_field_24415 = v_t_24413.f[1];
                        V v_x_24416 = v_field_24414;
                        V v_y_24417 = v_field_24415;
                        heff_drop(v_y_24417);
                        v_x_24418 = v_x_24416;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_a_24373);
                  }
                }
                V v_t_24419 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, (V[]){v_c_24372, v_a_24373}), v_sp_24375});
                return ((HeffT2){{v_x_24418, v_t_24419}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24372)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{v_st_240, v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24420 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24422 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24420)) {
          case TAG_At: {
            V v_e1_24423 = heff_dup(heff_field(v_e_24420, 0));
            switch (heff_tag_of(v_e1_24423)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24423, 0ULL, 2);
              switch (heff_tag_of(v_e_24420)) {
              case TAG_At: {
                v_x_24437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24420);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24423, 0ULL, 1);
              switch (heff_tag_of(v_e_24420)) {
              case TAG_At: {
                v_x_24437 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24420);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24423);
              HeffT2 v_t_24432 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24420)));
              {
                V v_field_24433 = v_t_24432.f[0];
                V v_field_24434 = v_t_24432.f[1];
                V v_x_24435 = v_field_24433;
                V v_y_24436 = v_field_24434;
                heff_drop(v_y_24436);
                v_x_24437 = v_x_24435;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24420);
          }
        }
        V v_t_24438 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, (V[]){v_e_24420}), v_sp_24422});
        return ((HeffT2){{v_x_24437, v_t_24438}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24439 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24441 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24456;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24456 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24439)) {
          case TAG_At: {
            V v_e1_24442 = heff_dup(heff_field(v_e_24439, 0));
            switch (heff_tag_of(v_e1_24442)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24442, 0ULL, 2);
              switch (heff_tag_of(v_e_24439)) {
              case TAG_At: {
                v_x_24456 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24439);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24442, 0ULL, 1);
              switch (heff_tag_of(v_e_24439)) {
              case TAG_At: {
                v_x_24456 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24439);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24442);
              HeffT2 v_t_24451 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24439)));
              {
                V v_field_24452 = v_t_24451.f[0];
                V v_field_24453 = v_t_24451.f[1];
                V v_x_24454 = v_field_24452;
                V v_y_24455 = v_field_24453;
                heff_drop(v_y_24455);
                v_x_24456 = v_x_24454;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24439);
          }
        }
        V v_t_24457 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, (V[]){v_e_24439}), v_sp_24441});
        return ((HeffT2){{v_x_24456, v_t_24457}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24458 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24460 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24475;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24475 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_e_24458)) {
          case TAG_At: {
            V v_e1_24461 = heff_dup(heff_field(v_e_24458, 0));
            switch (heff_tag_of(v_e1_24461)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24461, 0ULL, 2);
              switch (heff_tag_of(v_e_24458)) {
              case TAG_At: {
                v_x_24475 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24458);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24461, 0ULL, 1);
              switch (heff_tag_of(v_e_24458)) {
              case TAG_At: {
                v_x_24475 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24458);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24461);
              HeffT2 v_t_24470 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_24458)));
              {
                V v_field_24471 = v_t_24470.f[0];
                V v_field_24472 = v_t_24470.f[1];
                V v_x_24473 = v_field_24471;
                V v_y_24474 = v_field_24472;
                heff_drop(v_y_24474);
                v_x_24475 = v_x_24473;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24458);
          }
        }
        V v_t_24476 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, (V[]){v_e_24458}), v_sp_24460});
        return ((HeffT2){{v_x_24475, v_t_24476}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24477 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24479 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24480 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(v_st_240, v_es_24477));
        {
          V v_field_24481 = v_t_24480.f[0];
          V v_field_24482 = v_t_24480.f[1];
          V v_x_24483 = v_field_24481;
          V v_y_24484 = v_field_24482;
          V v_t_24485 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24484}), v_sp_24479});
          return ((HeffT2){{v_x_24483, v_t_24485}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24486 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24488 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24486)) {
        case TAG_MkTry: {
          V v_err_24489 = heff_field(v_tr_24486, 0);
          V v_body_24490 = heff_field(v_tr_24486, 1);
          V v_c_24491 = heff_field(v_tr_24486, 2);
          V v_ru_24tr_24486_24MkTry = heff_take_reuse_n(v_tr_24486, 7ULL, 3);
          HeffT2 v_t_24492 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_st_240, v_body_24490));
          {
            V v_field_24493 = v_t_24492.f[0];
            V v_field_24494 = v_t_24492.f[1];
            V v_x_24495 = v_field_24493;
            V v_y_24496 = v_field_24494;
            switch (heff_tag_of(v_c_24491)) {
            case TAG_MkCatchArm: {
              V v_b_24497 = heff_field(v_c_24491, 0);
              V v_ss_24498 = heff_field(v_c_24491, 1);
              V v_ru_24c_24491_24MkCatchArm = heff_take_reuse_n(v_c_24491, 3ULL, 2);
              HeffT2 v_t_24499 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24495, v_ss_24498));
              {
                V v_field_24500 = v_t_24499.f[0];
                V v_field_24501 = v_t_24499.f[1];
                V v_x_24502 = v_field_24500;
                V v_y_24503 = v_field_24501;
                V v_t_24504 = heff_tag_at_n(v_ru_24tr_24486_24MkTry, TAG_MkTry, 3, (V[]){v_err_24489, v_y_24496, heff_tag_at_n(v_ru_24c_24491_24MkCatchArm, TAG_MkCatchArm, 2, (V[]){v_b_24497, v_y_24503})});
                V v_t_24505 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_24504}), v_sp_24488});
                return ((HeffT2){{v_x_24502, v_t_24505}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_24491)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24486)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_24506 = heff_field(v_x31_242, 0);
      V v_x_24507 = heff_field(v_x31_242, 1);
      V v_xsp_24508 = heff_field(v_x31_242, 2);
      V v_body_24509 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24511 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24526;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_24526 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_w_24506)) {
          case TAG_At: {
            V v_e1_24512 = heff_dup(heff_field(v_w_24506, 0));
            switch (heff_tag_of(v_e1_24512)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24512, 0ULL, 2);
              switch (heff_tag_of(v_w_24506)) {
              case TAG_At: {
                v_x_24526 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_24506);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_e1_24512, 0ULL, 1);
              switch (heff_tag_of(v_w_24506)) {
              case TAG_At: {
                v_x_24526 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_w_24506);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24512);
              HeffT2 v_t_24521 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_w_24506)));
              {
                V v_field_24522 = v_t_24521.f[0];
                V v_field_24523 = v_t_24521.f[1];
                V v_x_24524 = v_field_24522;
                V v_y_24525 = v_field_24523;
                heff_drop(v_y_24525);
                v_x_24526 = v_x_24524;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_w_24506);
          }
        }
        HeffT2 v_t_24527 = (g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24cpr(v_x_24526, v_body_24509));
        {
          V v_field_24528 = v_t_24527.f[0];
          V v_field_24529 = v_t_24527.f[1];
          V v_x_24530 = v_field_24528;
          V v_y_24531 = v_field_24529;
          V v_t_24532 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, (V[]){v_w_24506, v_x_24507, v_xsp_24508, v_y_24531}), v_sp_24511});
          return ((HeffT2){{v_x_24530, v_t_24532}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_246)));
        }
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(v_a_2411, v_xs_243));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_y_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2415, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_y_2416})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V v_lit_240, V v_cx_241, V v_sp_242) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_241, v_sp_242, v_lit_240);
}
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_242}});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_243}});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_244}});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_245}});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_246}});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})}});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsInferable = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsInferable, TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsType = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsType, TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              heff_take_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2421;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2427 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              heff_take_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2424, v_sp_2425}));
              v_t_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2422, v_t_2427});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str1, 11, "bytesConcat");
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_n_249 = v_field_248;
          if (!heff_intEq_c_lent(v_n_249, MK_INT(0LL), 2)) {
            heff_drop(v_n_249);
            return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          } else {
            heff_drop(v_n_249);
            V v_x1_2410 = (g_list_2eany_24s689038521x519269801(v_segs_242));
            if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
              heff_drop(v_x1_2410);
              V v_t_2411 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_242));
              if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
                heff_drop(v_t_2411);
                V v_r_2412 = v_r_240;
                V v_segs_2413 = heff_dup(v_segs_242);
                V v_sp_2414 = v_sp_243;
                HeffT2 v_t_2415 = ({ V a_0 = v_segs_242; V a_1 = ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(a_0, a_1)); heff_drop(v_segs_242); r_; });
                {
                  V v_field_2417 = v_t_2415.f[1];
                  int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
                  if ((v_tag_2416 == ((int64_t)0ULL))) {
                    heff_drop(v_r_2412);
                    heff_drop(v_segs_2413);
                    V v_s_2418 = v_field_2417;
                    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2418}), v_sp_2414});
                    return ((HeffT1){{v_t_2419}});
                  } else {
                    heff_drop(v_field_2417);
                    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_clo), 1, (V[]){v_r_2412}));
                    V v_m_2424 = heff_rec_n(2, shape_part__run, (V[]){v_t_2420, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0_clo)});
                    V v_xs_2425 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2424, v_segs_2413, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
                    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
                    V v_t_2427 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2426, heff_dup(v_sp_2414)));
                    V v_args_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
                    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str1)}), heff_dup(v_sp_2414)});
                    V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), v_args_2428));
                    V v_f_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2430}), v_sp_2414});
                    return ((HeffT1){{v_f_2431}});
                  }
                }
              } else {
                heff_drop(v_t_2411);
                return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
              }
            } else {
              heff_drop(v_x1_2410);
              return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
            }
          }
        } else {
          heff_drop(v_field_248);
          return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
        }
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0(V self, V *args) {
  V v_s_2421 = args[0];
  V v_sp_2422 = args[1];
  V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2421}), heff_dup(v_sp_2422)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2423}), v_sp_2422});
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x21_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x21_243, 0);
        V v_sp_245 = heff_field(v_x21_243, 1);
        V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x21_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_seg_2410);
          heff_drop_cell(v_ru_24x21_248_24At, 2);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              V v_ru_24x11_2416_24MkPair = heff_take_reuse_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x11_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_241_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = v_t_2421;
          V t_2 = v_acc_242;
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(heff_tag_at_n(v_ru_24x21_248_24At, TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})));
          V v_t_2428;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            v_t_2428 = v_acc_242;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              V v_ru_24x21_2423_24MkPair = heff_take_reuse_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24x21_2423_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2424}), heff_dup(v_sp_2425)});
              V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2426}), v_sp_2425});
              v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_242});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = NTAG(TAG_Nothing);
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428});
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_x2_243 = v_b_241;
    V v_t_2435;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_PiNamed: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_t_246 = heff_field(v_x2_243, 2);
      V v_ru_24x2_243_24PiNamed = heff_take_reuse_n(v_x2_243, 7ULL, 3);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_At: {
        V v_n_247 = heff_field(v_t_246, 0);
        V v_sp_248 = heff_field(v_t_246, 1);
        V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
        v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_246_24At, v_sp_248, v_n_247));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      v_t_2435 = heff_tag_at_n(v_ru_24x2_243_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_244, v_sp_245, v_t_249});
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2410 = heff_field(v_x2_243, 0);
      V v_sp_2411 = heff_field(v_x2_243, 1);
      V v_sp2_2412 = heff_field(v_x2_243, 2);
      V v_t_2413 = heff_field(v_x2_243, 3);
      V v_d_2414 = heff_field(v_x2_243, 4);
      V v_ru_24x2_243_24PiImplicit = heff_take_reuse_n(v_x2_243, 31ULL, 5);
      V v_t_2417;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_n_2415 = heff_field(v_t_2413, 0);
        V v_sp_2416 = heff_field(v_t_2413, 1);
        V v_ru_24t_2413_24At = heff_take_reuse_n(v_t_2413, 3ULL, 2);
        v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2413_24At, v_sp_2416, v_n_2415));
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V v_t_2423;
      switch (heff_tag_of(v_d_2414)) {
      case TAG_Nothing: {
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_d_2414, 0);
        V v_ru_24d_2414_24Just = heff_take_reuse_n(v_d_2414, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_At: {
          V v_n_2419 = heff_field(v_x_2418, 0);
          V v_sp_2420 = heff_field(v_x_2418, 1);
          V v_ru_24x_2418_24At = heff_take_reuse_n(v_x_2418, 3ULL, 2);
          V v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2419));
          v_t_2422 = heff_tag_at_n(v_ru_24x_2418_24At, TAG_At, 2, (V[]){v_t_2421, v_sp_2420});
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        v_t_2423 = heff_tag_at_n(v_ru_24d_2414_24Just, TAG_Just, 1, (V[]){v_t_2422});
        break;
      }
      default: heff_nomatch(v_d_2414);
      }
      v_t_2435 = heff_tag_at_n(v_ru_24x2_243_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2410, v_sp_2411, v_sp2_2412, v_t_2417, v_t_2423});
      break;
    }
    case TAG_PiInstance: {
      V v_x_2424 = heff_field(v_x2_243, 0);
      V v_sp_2425 = heff_field(v_x2_243, 1);
      V v_sp2_2426 = heff_field(v_x2_243, 2);
      V v_t_2427 = heff_field(v_x2_243, 3);
      V v_ru_24x2_243_24PiInstance = heff_take_reuse_n(v_x2_243, 15ULL, 4);
      V v_t_2430;
      switch (heff_tag_of(v_t_2427)) {
      case TAG_At: {
        V v_n_2428 = heff_field(v_t_2427, 0);
        V v_sp_2429 = heff_field(v_t_2427, 1);
        V v_ru_24t_2427_24At = heff_take_reuse_n(v_t_2427, 3ULL, 2);
        v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2427_24At, v_sp_2429, v_n_2428));
        break;
      }
      default: heff_nomatch(v_t_2427);
      }
      v_t_2435 = heff_tag_at_n(v_ru_24x2_243_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2424, v_sp_2425, v_sp2_2426, v_t_2430});
      break;
    }
    case TAG_PiAnon: {
      V v_t_2431 = heff_field(v_x2_243, 0);
      V v_ru_24x2_243_24PiAnon = heff_take_reuse_n(v_x2_243, 1ULL, 1);
      V v_t_2434;
      switch (heff_tag_of(v_t_2431)) {
      case TAG_At: {
        V v_n_2432 = heff_field(v_t_2431, 0);
        V v_sp_2433 = heff_field(v_t_2431, 1);
        V v_ru_24t_2431_24At = heff_take_reuse_n(v_t_2431, 3ULL, 2);
        v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2431_24At, v_sp_2433, v_n_2432));
        break;
      }
      default: heff_nomatch(v_t_2431);
      }
      v_t_2435 = heff_tag_at_n(v_ru_24x2_243_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2434});
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_2438;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_2436 = heff_field(v_cod_242, 0);
      V v_sp_2437 = heff_field(v_cod_242, 1);
      V v_ru_24cod_242_24At = heff_take_reuse_n(v_cod_242, 3ULL, 2);
      v_t_2438 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24cod_242_24At, v_sp_2437, v_n_2436));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_2435, v_t_2438});
  }
  case TAG_TSig: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1992667171x110340492(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_2440});
  }
  case TAG_TSum: {
    V v_vs_2441 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2442 = (g_list_2emap_24s513391942x823299088(v_vs_2441));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2442});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2443 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2446;
    switch (heff_tag_of(v_a_2443)) {
    case TAG_At: {
      V v_n_2444 = heff_field(v_a_2443, 0);
      V v_sp_2445 = heff_field(v_a_2443, 1);
      V v_ru_24a_2443_24At = heff_take_reuse_n(v_a_2443, 3ULL, 2);
      v_t_2446 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2443_24At, v_sp_2445, v_n_2444));
      break;
    }
    default: heff_nomatch(v_a_2443);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2446});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2448 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2452;
    switch (heff_tag_of(v_i_2448)) {
    case TAG_At: {
      V v_n_2449 = heff_field(v_i_2448, 0);
      V v_sp_2450 = heff_field(v_i_2448, 1);
      V v_ru_24i_2448_24At = heff_take_reuse_n(v_i_2448, 3ULL, 2);
      V v_t_2451 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2449));
      v_t_2452 = heff_tag_at_n(v_ru_24i_2448_24At, TAG_At, 2, (V[]){v_t_2451, v_sp_2450});
      break;
    }
    default: heff_nomatch(v_i_2448);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2452});
  }
  case TAG_TChk: {
    V v_c_2453 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2457;
    switch (heff_tag_of(v_c_2453)) {
    case TAG_At: {
      V v_n_2454 = heff_field(v_c_2453, 0);
      V v_sp_2455 = heff_field(v_c_2453, 1);
      V v_ru_24c_2453_24At = heff_take_reuse_n(v_c_2453, 3ULL, 2);
      V v_t_2456 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2454));
      v_t_2457 = heff_tag_at_n(v_ru_24c_2453_24At, TAG_At, 2, (V[]){v_t_2456, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_c_2453);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2457});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V v_tok_240, V v_r_241, V v_h_242, V v_args_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_At: {
    V v_h1_245 = heff_dup(heff_field(v_h_242, 0));
    switch (heff_tag_of(v_h1_245)) {
    case TAG_ETag: {
      V v_t_247 = heff_field(v_h1_245, 0);
      V v_ru_24h1_245_24ETag = heff_take_reuse_n(v_h1_245, 1ULL, 1);
      switch (heff_tag_of(v_h_242)) {
      case TAG_At: {
        V v_tsp_249 = heff_field(v_h_242, 1);
        V v_ru_24h_242_24At = heff_take_reuse_n(v_h_242, 2ULL, 2);
        V v_t_2421 = (g_list_2emap_24tok2(v_ru_24h_242_24At, heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0, 1, 1, (V[]){v_r_241}), v_args_243));
        V v_t_2422 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, v_tsp_249, v_t_2421}), v_sp_244});
        return heff_tag_at_n(v_ru_24h1_245_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2422});
      }
      default: return heff_nomatch(v_h_242);
      }
    }
    case TAG_EWord: {
      V v_h11_2423 = heff_field(v_h1_245, 0);
      V v_ru_24h1_245_24EWord = heff_take_reuse_n(v_h1_245, 1ULL, 1);
      switch (heff_tag_of(v_h11_2423)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_242, 2);
        switch (heff_tag_of(v_args_243)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_241, 2);
          V v_t_2424 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str0), NTAG(TAG_Nothing)});
          V v_t_2425 = heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_244)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_244})});
        }
        case TAG_Cons: {
          V v_a_2426 = heff_field(v_args_243, 0);
          V v_args2_2427 = heff_field(v_args_243, 1);
          V v_ru_24args_243_24Cons = heff_take_reuse_n(v_args_243, 3ULL, 2);
          switch (heff_tag_of(v_args2_2427)) {
          case TAG_Nil: {
            V v_x1_2428 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_a_2426}));
            V v_t_2438;
            switch (heff_tag_of(v_x1_2428)) {
            case TAG_IsInferable: {
              V v_i_2429 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              V v_t_2432;
              switch (heff_tag_of(v_i_2429)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_i_2429);
              }
              v_t_2438 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2433 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              V v_t_2436;
              switch (heff_tag_of(v_c_2433)) {
              case TAG_At: {
                V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
                v_t_2436 = v_s_2435;
                break;
              }
              default: heff_nomatch(v_c_2433);
              }
              v_t_2438 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
              break;
            }
            case TAG_IsType: {
              V v_t_2437 = heff_field(v_x1_2428, 0);
              heff_take_n(v_x1_2428, 1ULL, 1);
              heff_drop_cell(v_tok_240, 2);
              heff_drop_cell(v_ru_24h1_245_24EWord, 1);
              v_t_2438 = v_t_2437;
              break;
            }
            default: heff_nomatch(v_x1_2428);
            }
            V v_t_2439 = heff_tag_at_n(v_ru_24args_243_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2438}), v_sp_244});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2439});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2427, 0ULL, 2);
            heff_drop_rec(v_r_241, 2);
            heff_drop(v_a_2426);
            V v_t_2442 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24tok2_str1), NTAG(TAG_Nothing)});
            V v_t_2443 = heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2442, heff_dup(v_sp_244)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args_243_24Cons, TAG_At, 2, (V[]){v_t_2443, v_sp_244})});
          }
          default: return heff_nomatch(v_args2_2427);
          }
        }
        default: return heff_nomatch(v_args_243);
        }
      }
      default: {
        heff_drop(v_h11_2423);
        V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){v_h_242}));
        V v_t_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2444));
        V v_t_2446 = (g_list_2emap_24s942566919x1152393003(v_r_241, v_args_243));
        V v_t_2447 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2446}), v_sp_244});
        return heff_tag_at_n(v_ru_24h1_245_24EWord, TAG_IsInferable, 1, (V[]){v_t_2447});
      }
      }
    }
    default: {
      heff_drop(v_h1_245);
      V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){v_h_242}));
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2448));
      V v_t_2450 = (g_list_2emap_24s942566919x1152393003(v_r_241, v_args_243));
      V v_t_2451 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2449, v_t_2450}), v_sp_244});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2451});
    }
    }
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf_24tok2(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_lam0(V self, V *args) {
  V v_e_2410 = args[0];
  V v_r_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 2), 1, (V[]){v_e_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_IsInferable: {
    V v_i_2412 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24IsInferable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_i_2412)) {
    case TAG_At: {
      V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
      v_t_2415 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_i_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsInferable, TAG_CInf, 1, (V[]){v_i_2412}), v_t_2415});
  }
  case TAG_IsCheckable: {
    V v_c_2416 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    return v_c_2416;
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_2411, 0);
    V v_ru_24x1_2411_24IsType = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_At: {
      V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
      v_t_2420 = v_s_2419;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsType, TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
  }
  default: return heff_nomatch(v_x1_2411);
  }
}