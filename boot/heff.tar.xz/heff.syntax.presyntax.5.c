// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_IPrim 59489
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_e 319
#define LBL_end 310101
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1660377451x1094399496_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo;
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2elastT(V, V, V);
V g_heff_2esyntax_2epresyntax_2elastT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2eall_24s1687051711x1677682329(V, V);
V g_list_2eall_24s1687051711x1677682329_entry(V self, V *a);
extern Clo g_list_2eall_24s1687051711x1677682329_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2enatBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2enatBytes(V v_k_240, V v_u_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_244 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_245 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_244)), v_acc_242);
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2enatBytes(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_243}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_MkPair: {
      V v_st_246 = heff_field(v_x1_245, 0);
      V v_y_247 = heff_field(v_x1_245, 1);
      heff_take_n(v_x1_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_st_246, v_xs_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_y_2412 = v_field_2410;
        return ((HeffT2){{v_x_2411, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_247, v_y_2412})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_dup(heff_field(v_x3_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_x3_242, 1));
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EBinary: {
      V v_segs_2411 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EBinary = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0, 2, 1, (V[]){v_f_240}), v_st_241, v_segs_2411));
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_x_2428 = v_field_2426;
        V v_y_2429 = v_field_2427;
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EBinary, TAG_EBinary, 1, (V[]){v_y_2429}), v_sp_244});
        return ((HeffT2){{v_x_2428, v_t_2430}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EApp: {
      V v_h_2433 = heff_field(v_x31_243, 0);
      V v_args_2434 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2435 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_h_2433}));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_MkPair: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        V v_y_2437 = heff_field(v_x1_2435, 1);
        V v_ru_24x1_2435_24MkPair = heff_take_reuse_n(v_x1_2435, 3ULL, 2);
        HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_f_240, v_x_2436, v_args_2434));
        {
          V v_field_2439 = v_t_2438.f[0];
          V v_field_2440 = v_t_2438.f[1];
          V v_x_2441 = v_field_2439;
          V v_y_2442 = v_field_2440;
          V v_t_2443 = heff_tag_at_n(v_ru_24x1_2435_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EApp, TAG_EApp, 2, (V[]){v_y_2437, v_y_2442}), v_sp_244});
          return ((HeffT2){{v_x_2441, v_t_2443}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2435)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ENamed: {
      V v_x_2445 = heff_field(v_x31_243, 0);
      V v_e_2446 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ENamed = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2447 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2446}));
      switch (heff_tag_of(v_x1_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x1_2447, 0);
        V v_y_2449 = heff_field(v_x1_2447, 1);
        V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
        V v_t_2450 = heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENamed, TAG_ENamed, 2, (V[]){v_x_2445, v_y_2449}), v_sp_244});
        return ((HeffT2){{v_x_2448, v_t_2450}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2447)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ELam: {
      V v_b_2453 = heff_field(v_x31_243, 0);
      V v_body_2454 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELam = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2455 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_body_2454}));
      switch (heff_tag_of(v_x1_2455)) {
      case TAG_MkPair: {
        V v_x_2456 = heff_field(v_x1_2455, 0);
        V v_y_2457 = heff_field(v_x1_2455, 1);
        V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
        V v_t_2458 = heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELam, TAG_ELam, 2, (V[]){v_b_2453, v_y_2457}), v_sp_244});
        return ((HeffT2){{v_x_2456, v_t_2458}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2455)}});
      }
    }
    case TAG_EAnn: {
      V v_e_2459 = heff_field(v_x31_243, 0);
      V v_t_2460 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EAnn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2461 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2459}));
      switch (heff_tag_of(v_x1_2461)) {
      case TAG_MkPair: {
        V v_x_2462 = heff_field(v_x1_2461, 0);
        V v_y_2463 = heff_field(v_x1_2461, 1);
        V v_ru_24x1_2461_24MkPair = heff_take_reuse_n(v_x1_2461, 3ULL, 2);
        V v_t_2464 = heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAnn, TAG_EAnn, 2, (V[]){v_y_2463, v_t_2460}), v_sp_244});
        return ((HeffT2){{v_x_2462, v_t_2464}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2461)}});
      }
    }
    case TAG_ESpec: {
      V v_a_2465 = heff_field(v_x31_243, 0);
      V v_x_2466 = heff_field(v_x31_243, 1);
      V v_xsp_2467 = heff_field(v_x31_243, 2);
      V v_v_2468 = heff_field(v_x31_243, 3);
      V v_ru_24x31_243_24ESpec = heff_take_reuse_n(v_x31_243, 15ULL, 4);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2469 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2465}));
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_MkPair: {
        V v_x_2470 = heff_field(v_x1_2469, 0);
        V v_y_2471 = heff_field(v_x1_2469, 1);
        V v_ru_24x1_2469_24MkPair = heff_take_reuse_n(v_x1_2469, 3ULL, 2);
        V v_x1_2472 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_2470, v_v_2468}));
        switch (heff_tag_of(v_x1_2472)) {
        case TAG_MkPair: {
          V v_x_2473 = heff_field(v_x1_2472, 0);
          V v_y_2474 = heff_field(v_x1_2472, 1);
          heff_take_n(v_x1_2472, 3ULL, 2);
          V v_t_2475 = heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ESpec, TAG_ESpec, 4, (V[]){v_y_2471, v_x_2466, v_xsp_2467, v_y_2474}), v_sp_244});
          return ((HeffT2){{v_x_2473, v_t_2475}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2472)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2469)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EStruct: {
      V v_fs_2478 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EStruct = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_f_240, v_st_241, v_fs_2478));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_x_2482 = v_field_2480;
        V v_y_2483 = v_field_2481;
        V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EStruct, TAG_EStruct, 1, (V[]){v_y_2483}), v_sp_244});
        return ((HeffT2){{v_x_2482, v_t_2484}});
      }
    }
    case TAG_EUpdate: {
      V v_a_2485 = heff_field(v_x31_243, 0);
      V v_fs_2486 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EUpdate = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_2487 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_a_2485}));
      switch (heff_tag_of(v_x1_2487)) {
      case TAG_MkPair: {
        V v_x_2488 = heff_field(v_x1_2487, 0);
        V v_y_2489 = heff_field(v_x1_2487, 1);
        V v_ru_24x1_2487_24MkPair = heff_take_reuse_n(v_x1_2487, 3ULL, 2);
        HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1, 2, 1, (V[]){v_f_240}), v_x_2488, v_fs_2486));
        {
          V v_field_24101 = v_t_24100.f[0];
          V v_field_24102 = v_t_24100.f[1];
          V v_x_24103 = v_field_24101;
          V v_y_24104 = v_field_24102;
          V v_t_24105 = heff_tag_at_n(v_ru_24x1_2487_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EUpdate, TAG_EUpdate, 2, (V[]){v_y_2489, v_y_24104}), v_sp_244});
          return ((HeffT2){{v_x_24103, v_t_24105}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2487)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24106 = heff_field(v_x31_243, 0);
      V v_alts_24107 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24108 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_s_24106}));
      switch (heff_tag_of(v_x1_24108)) {
      case TAG_MkPair: {
        V v_x_24109 = heff_field(v_x1_24108, 0);
        V v_y_24110 = heff_field(v_x1_24108, 1);
        V v_ru_24x1_24108_24MkPair = heff_take_reuse_n(v_x1_24108, 3ULL, 2);
        HeffT2 v_t_24121 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2, 2, 1, (V[]){v_f_240}), v_x_24109, v_alts_24107));
        {
          V v_field_24122 = v_t_24121.f[0];
          V v_field_24123 = v_t_24121.f[1];
          V v_x_24124 = v_field_24122;
          V v_y_24125 = v_field_24123;
          V v_t_24126 = heff_tag_at_n(v_ru_24x1_24108_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_EMatch, 2, (V[]){v_y_24110, v_y_24125}), v_sp_244});
          return ((HeffT2){{v_x_24124, v_t_24126}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24108)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24127 = heff_field(v_x31_243, 0);
      V v_a_24128 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ELetIn = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24129 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_rhs_24127}));
      switch (heff_tag_of(v_x1_24129)) {
      case TAG_MkPair: {
        V v_x_24130 = heff_field(v_x1_24129, 0);
        V v_y_24131 = heff_field(v_x1_24129, 1);
        V v_ru_24x1_24129_24MkPair = heff_take_reuse_n(v_x1_24129, 3ULL, 2);
        V v_x1_24140;
        switch (heff_tag_of(v_a_24128)) {
        case TAG_At: {
          V v_x31_24132 = heff_field(v_a_24128, 0);
          V v_sp_24133 = heff_field(v_a_24128, 1);
          V v_ru_24a_24128_24At = heff_take_reuse_n(v_a_24128, 3ULL, 2);
          switch (heff_tag_of(v_x31_24132)) {
          case TAG_MkAlt: {
            V v_p_24134 = heff_field(v_x31_24132, 0);
            V v_e_24135 = heff_field(v_x31_24132, 1);
            heff_take_n(v_x31_24132, 3ULL, 2);
            V v_x1_24136 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24130, v_e_24135}));
            switch (heff_tag_of(v_x1_24136)) {
            case TAG_MkPair: {
              V v_x_24137 = heff_field(v_x1_24136, 0);
              V v_y_24138 = heff_field(v_x1_24136, 1);
              heff_take_n(v_x1_24136, 3ULL, 2);
              V v_t_24139 = heff_tag_at_n(v_ru_24a_24128_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24134, v_y_24138}), v_sp_24133});
              v_x1_24140 = heff_tag_at_n(v_ru_24x1_24129_24MkPair, TAG_MkPair, 2, (V[]){v_x_24137, v_t_24139});
              break;
            }
            default: heff_nomatch(v_x1_24136);
            }
            break;
          }
          default: heff_nomatch(v_x31_24132);
          }
          break;
        }
        default: heff_nomatch(v_a_24128);
        }
        switch (heff_tag_of(v_x1_24140)) {
        case TAG_MkPair: {
          V v_x_24141 = heff_field(v_x1_24140, 0);
          V v_y_24142 = heff_field(v_x1_24140, 1);
          V v_ru_24x1_24140_24MkPair = heff_take_reuse_n(v_x1_24140, 3ULL, 2);
          V v_t_24143 = heff_tag_at_n(v_ru_24x1_24140_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ELetIn, TAG_ELetIn, 2, (V[]){v_y_24131, v_y_24142}), v_sp_244});
          return ((HeffT2){{v_x_24141, v_t_24143}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24140)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24129)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24144 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EDo = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      HeffT2 v_t_24145 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1660377451x1094399496_24cpr(v_f_240, v_st_241, v_ss_24144));
      {
        V v_field_24146 = v_t_24145.f[0];
        V v_field_24147 = v_t_24145.f[1];
        V v_x_24148 = v_field_24146;
        V v_y_24149 = v_field_24147;
        V v_t_24150 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EDo, TAG_EDo, 1, (V[]){v_y_24149}), v_sp_244});
        return ((HeffT2){{v_x_24148, v_t_24150}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EAssign: {
      V v_x_24154 = heff_field(v_x31_243, 0);
      V v_xsp_24155 = heff_field(v_x31_243, 1);
      V v_e_24156 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EAssign = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24157 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24156}));
      switch (heff_tag_of(v_x1_24157)) {
      case TAG_MkPair: {
        V v_x_24158 = heff_field(v_x1_24157, 0);
        V v_y_24159 = heff_field(v_x1_24157, 1);
        V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
        V v_t_24160 = heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EAssign, TAG_EAssign, 3, (V[]){v_x_24154, v_xsp_24155, v_y_24159}), v_sp_244});
        return ((HeffT2){{v_x_24158, v_t_24160}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24157)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24161 = heff_field(v_x31_243, 0);
      V v_body_24162 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EWhile = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24163 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24161}));
      switch (heff_tag_of(v_x1_24163)) {
      case TAG_MkPair: {
        V v_x_24164 = heff_field(v_x1_24163, 0);
        V v_y_24165 = heff_field(v_x1_24163, 1);
        V v_ru_24x1_24163_24MkPair = heff_take_reuse_n(v_x1_24163, 3ULL, 2);
        HeffT2 v_t_24166 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1660377451x1094399496_24cpr(v_f_240, v_x_24164, v_body_24162));
        {
          V v_field_24167 = v_t_24166.f[0];
          V v_field_24168 = v_t_24166.f[1];
          V v_x_24169 = v_field_24167;
          V v_y_24170 = v_field_24168;
          V v_t_24171 = heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EWhile, TAG_EWhile, 2, (V[]){v_y_24165, v_y_24170}), v_sp_244});
          return ((HeffT2){{v_x_24169, v_t_24171}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24163)}});
      }
    }
    case TAG_EFor: {
      V v_p_24172 = heff_field(v_x31_243, 0);
      V v_c_24173 = heff_field(v_x31_243, 1);
      V v_body_24174 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24EFor = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24175 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24173}));
      switch (heff_tag_of(v_x1_24175)) {
      case TAG_MkPair: {
        V v_x_24176 = heff_field(v_x1_24175, 0);
        V v_y_24177 = heff_field(v_x1_24175, 1);
        V v_ru_24x1_24175_24MkPair = heff_take_reuse_n(v_x1_24175, 3ULL, 2);
        HeffT2 v_t_24178 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1660377451x1094399496_24cpr(v_f_240, v_x_24176, v_body_24174));
        {
          V v_field_24179 = v_t_24178.f[0];
          V v_field_24180 = v_t_24178.f[1];
          V v_x_24181 = v_field_24179;
          V v_y_24182 = v_field_24180;
          V v_t_24183 = heff_tag_at_n(v_ru_24x1_24175_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EFor, TAG_EFor, 3, (V[]){v_p_24172, v_y_24177, v_y_24182}), v_sp_244});
          return ((HeffT2){{v_x_24181, v_t_24183}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24175)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24184 = heff_field(v_x31_243, 0);
      V v_a_24185 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EIfThen = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24186 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_c_24184}));
      switch (heff_tag_of(v_x1_24186)) {
      case TAG_MkPair: {
        V v_x_24187 = heff_field(v_x1_24186, 0);
        V v_y_24188 = heff_field(v_x1_24186, 1);
        V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
        V v_x1_24189 = heff_tr(heff_call(v_f_240, 2, (V[]){v_x_24187, v_a_24185}));
        switch (heff_tag_of(v_x1_24189)) {
        case TAG_MkPair: {
          V v_x_24190 = heff_field(v_x1_24189, 0);
          V v_y_24191 = heff_field(v_x1_24189, 1);
          heff_take_n(v_x1_24189, 3ULL, 2);
          V v_t_24192 = heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EIfThen, TAG_EIfThen, 2, (V[]){v_y_24188, v_y_24191}), v_sp_244});
          return ((HeffT2){{v_x_24190, v_t_24192}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_24189)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24186)}});
      }
    }
    case TAG_EBreak: {
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EContinue: {
      heff_drop(v_f_240);
      heff_drop(v_sp_244);
      return ((HeffT2){{v_st_241, v_x3_242}});
    }
    case TAG_EReturn: {
      V v_e_24193 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24EReturn = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24194 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24193}));
      switch (heff_tag_of(v_x1_24194)) {
      case TAG_MkPair: {
        V v_x_24195 = heff_field(v_x1_24194, 0);
        V v_y_24196 = heff_field(v_x1_24194, 1);
        V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
        V v_t_24197 = heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24EReturn, TAG_EReturn, 1, (V[]){v_y_24196}), v_sp_244});
        return ((HeffT2){{v_x_24195, v_t_24197}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24194)}});
      }
    }
    case TAG_ENest: {
      V v_e_24198 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ENest = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_tag(v_x3_242, 2);
      V v_x1_24199 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_24198}));
      switch (heff_tag_of(v_x1_24199)) {
      case TAG_MkPair: {
        V v_x_24200 = heff_field(v_x1_24199, 0);
        V v_y_24201 = heff_field(v_x1_24199, 1);
        V v_ru_24x1_24199_24MkPair = heff_take_reuse_n(v_x1_24199, 3ULL, 2);
        V v_t_24202 = heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ENest, TAG_ENest, 1, (V[]){v_y_24201}), v_sp_244});
        return ((HeffT2){{v_x_24200, v_t_24202}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_24199)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_x3_2413 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_At: {
    V v_x31_2414 = heff_field(v_x3_2413, 0);
    V v_sp_2415 = heff_field(v_x3_2413, 1);
    V v_ru_24x3_2413_24At = heff_take_reuse_n(v_x3_2413, 3ULL, 2);
    switch (heff_tag_of(v_x31_2414)) {
    case TAG_MkSegment: {
      V v_v_2416 = heff_field(v_x31_2414, 0);
      V v_ty_2417 = heff_field(v_x31_2414, 1);
      V v_size_2418 = heff_field(v_x31_2414, 2);
      V v_little_2419 = heff_field(v_x31_2414, 3);
      V v_signed_2420 = heff_field(v_x31_2414, 4);
      heff_take_n(v_x31_2414, 31ULL, 5);
      V v_x1_2421 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2412, v_v_2416}));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_field(v_x1_2421, 0);
        V v_y_2423 = heff_field(v_x1_2421, 1);
        V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
        V v_t_2424 = heff_tag_at_n(v_ru_24x3_2413_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_y_2423, v_ty_2417, v_size_2418, v_little_2419, v_signed_2420}), v_sp_2415});
        return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_t_2424});
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
    default: return heff_nomatch(v_x31_2414);
    }
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam1(V self, V *args) {
  V v_st_2490 = args[0];
  V v_x3_2491 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2491)) {
  case TAG_At: {
    V v_x31_2492 = heff_field(v_x3_2491, 0);
    V v_sp_2493 = heff_field(v_x3_2491, 1);
    V v_ru_24x3_2491_24At = heff_take_reuse_n(v_x3_2491, 3ULL, 2);
    switch (heff_tag_of(v_x31_2492)) {
    case TAG_SetPath: {
      V v_path_2494 = heff_field(v_x31_2492, 0);
      V v_e_2495 = heff_field(v_x31_2492, 1);
      V v_ru_24x31_2492_24SetPath = heff_take_reuse_n(v_x31_2492, 3ULL, 2);
      V v_x1_2496 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_2490, v_e_2495}));
      switch (heff_tag_of(v_x1_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x1_2496, 0);
        V v_y_2498 = heff_field(v_x1_2496, 1);
        heff_take_n(v_x1_2496, 3ULL, 2);
        V v_t_2499 = heff_tag_at_n(v_ru_24x3_2491_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_path_2494, v_y_2498}), v_sp_2493});
        return heff_tag_at_n(v_ru_24x31_2492_24SetPath, TAG_MkPair, 2, (V[]){v_x_2497, v_t_2499});
      }
      default: return heff_nomatch(v_x1_2496);
      }
    }
    default: return heff_nomatch(v_x31_2492);
    }
  }
  default: return heff_nomatch(v_x3_2491);
  }
}
V g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr_lam2(V self, V *args) {
  V v_st_24111 = args[0];
  V v_x3_24112 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24112)) {
  case TAG_At: {
    V v_x31_24113 = heff_field(v_x3_24112, 0);
    V v_sp_24114 = heff_field(v_x3_24112, 1);
    V v_ru_24x3_24112_24At = heff_take_reuse_n(v_x3_24112, 3ULL, 2);
    switch (heff_tag_of(v_x31_24113)) {
    case TAG_MkAlt: {
      V v_p_24115 = heff_field(v_x31_24113, 0);
      V v_e_24116 = heff_field(v_x31_24113, 1);
      V v_ru_24x31_24113_24MkAlt = heff_take_reuse_n(v_x31_24113, 3ULL, 2);
      V v_x1_24117 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_24111, v_e_24116}));
      switch (heff_tag_of(v_x1_24117)) {
      case TAG_MkPair: {
        V v_x_24118 = heff_field(v_x1_24117, 0);
        V v_y_24119 = heff_field(v_x1_24117, 1);
        heff_take_n(v_x1_24117, 3ULL, 2);
        V v_t_24120 = heff_tag_at_n(v_ru_24x3_24112_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24115, v_y_24119}), v_sp_24114});
        return heff_tag_at_n(v_ru_24x31_24113_24MkAlt, TAG_MkPair, 2, (V[]){v_x_24118, v_t_24120});
      }
      default: return heff_nomatch(v_x1_24117);
      }
    }
    default: return heff_nomatch(v_x31_24113);
    }
  }
  default: return heff_nomatch(v_x3_24112);
  }
}
Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF(V v_t_240, V v_cx_241, V v_x3_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return (g_heff_2esyntax_2epresyntax_2eendOf(heff_dup(v_cx_241), heff_get_n(v_cx_241, 3, 4), v_end_243));
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_243)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT(v_t_240, v_cx_241, heff_dup(v_s_244)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_244), heff_dup(v_x32_245), v_end_243));
      }
      default: return heff_nomatch(v_end_243);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT(v_t_240, v_cx_241, heff_dup(v_s_244), heff_dup(v_x32_245), v_end_243));
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2estmtsF(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_242}});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_243}});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_244}});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_245}});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_246}});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_241)})});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_241})}});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm(V v_r_240, V v_v_241, V v_sp_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_241}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_IsInferable: {
    V v_i_244 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsInferable = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    break;
  }
  case TAG_IsCheckable: {
    V v_c_248 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_t_2413 = v_c_248;
    break;
  }
  case TAG_IsType: {
    V v_t_249 = heff_field(v_x1_243, 0);
    V v_ru_24x1_243_24IsType = heff_take_reuse_n(v_x1_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_t_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_243_24IsType, TAG_CType, 1, (V[]){v_t_249}), v_t_2412});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2414));
  V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_str0)}), heff_dup(v_sp_242)});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_242)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts(V v_m_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_m_240, 2);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      heff_take_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tr(heff_call(heff_get_n(v_m_240, 1, 2), 2, (V[]){v_s_245, v_sp_246}));
        return heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_Cons, 2, (V[]){v_t_247, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_rest_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2410);
          V v_s_2416 = v_field_2414;
          V v_t_2422;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){v_s_2416, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2417 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_MkPair: {
              V v_s0_2418 = heff_field(v_x11_2417, 0);
              V v_sp0_2419 = heff_field(v_x11_2417, 1);
              heff_take_n(v_x11_2417, 3ULL, 2);
              V v_t_2420 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2421 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2418, v_s_2416), v_t_2420});
              v_t_2422 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
              break;
            }
            default: heff_nomatch(v_x11_2417);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = v_t_2422;
          V t_3 = v_acc_243;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})}));
          V v_t_2428;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2428 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2424 = heff_field(v_run_242, 0);
            heff_take_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2424)) {
            case TAG_MkPair: {
              V v_s_2425 = heff_field(v_x21_2424, 0);
              V v_sp_2426 = heff_field(v_x21_2424, 1);
              heff_take_n(v_x21_2424, 3ULL, 2);
              V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 1)), 2, (V[]){v_s_2425, v_sp_2426}));
              v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2424);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_m_240;
          V t_1 = v_rest_249;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2423, v_t_2428});
          v_m_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0, 0, "");

HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    v_t_2412 = NTAG(TAG_True);
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_2412 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_245, MK_INT(0LL)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        v_t_2412 = heff_bool(((v_tag_247 == ((int64_t)0ULL)) ? ({ V v_n_2410 = heff_dup(v_field_248); int c_ = !heff_intEq_c_lent(v_n_2410, MK_INT(0LL), 2); heff_drop(v_n_2410); c_; }) : 1));
        heff_drop(v_field_248);
      }
    }
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_False); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  } else {
    heff_drop(v_t_2412);
    V v_x1_2413 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
      heff_drop(v_x1_2413);
      return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    } else {
      heff_drop(v_x1_2413);
      V v_t_2414 = (g_list_2eall_24s1687051711x1677682329(MK_INT(0LL), v_segs_242));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_242, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0)));
        HEFF_LAST return g_heff_2esyntax_2epresyntax_2ebytesBinary_24cpr(v_r_240, v_segs_242, v_sp_243, v_t_2415);
      } else {
        heff_drop(v_t_2414);
        return ({ V a_0 = heff_dup(v_r_240); V a_1 = v_r_240; V a_2 = v_segs_242; V a_3 = v_sp_243; V b_4 = NTAG(TAG_True); HeffT1 r_ = (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str0, 9, "bitsOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str1, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str2, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str3, 17, "prelude.bitsSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str4, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str5, 11, "bitsOfBytes");
Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(V v_seg_240) {
top: ;
  switch (heff_tag_of(v_seg_240)) {
  case TAG_At: {
    V v_seg1_241 = heff_dup(heff_field(v_seg_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_seg_240, 1));
    switch (heff_tag_of(v_seg1_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_seg1_241, 0);
      V v_seg12_244 = heff_field(v_seg1_241, 1);
      V v_size_245 = heff_field(v_seg1_241, 2);
      V v_little_246 = heff_field(v_seg1_241, 3);
      V v_signed_247 = heff_field(v_seg1_241, 4);
      heff_take_n(v_seg1_241, 31ULL, 5);
      switch (heff_tag_of(v_seg12_244)) {
      case TAG_SegmentInteger: {
        heff_drop_tag(v_seg_240, 2);
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_2434 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
        V v_sp_2438;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_2439 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2438), v_args_2435));
        V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str1)}), heff_dup(v_sp_2438)});
        V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2440, v_t_2439}), heff_dup(v_sp_2438)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2441}), v_sp_2438});
      }
      case TAG_SegmentBits: {
        heff_drop_tag(v_seg_240, 2);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2442 = heff_field(v_v_243, 0);
            V v_sp_2443 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2444 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2442)));
            {
              V v_field_2446 = v_t_2444.f[1];
              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
              if ((v_tag_2445 == ((int64_t)0ULL))) {
                heff_drop(v_e_2442);
                V v_segs_2448 = v_field_2446;
                HeffT2 v_t_2449 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_2448; V a_2 = v_sp_2443; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_2451 = v_t_2449.f[1];
                  int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                  if ((v_tag_2450 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2453 = v_field_2451;
                    return v_a_2453;
                  } else {
                    if ((v_tag_2450 == ((int64_t)1ULL))) {
                      V v_a_2455 = v_field_2451;
                      V v_t_2458;
                      switch (heff_tag_of(v_a_2455)) {
                      case TAG_At: {
                        V v_a_2457 = heff_dup(heff_field(v_a_2455, 1));
                        v_t_2458 = v_a_2457;
                        break;
                      }
                      default: heff_nomatch(v_a_2455);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2455}), v_t_2458});
                    } else {
                      V v_a_2459 = v_field_2451;
                      V v_t_2462;
                      switch (heff_tag_of(v_a_2459)) {
                      case TAG_At: {
                        V v_a_2461 = heff_dup(heff_field(v_a_2459, 1));
                        v_t_2462 = v_a_2461;
                        break;
                      }
                      default: heff_nomatch(v_a_2459);
                      }
                      return heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2459}), v_t_2462});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2446);
                HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2442, v_sp_2443})));
                {
                  V v_field_2465 = v_t_2463.f[1];
                  int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                  if ((v_tag_2464 == ((int64_t)0ULL))) {
                    V v_c_2467 = v_field_2465;
                    return v_c_2467;
                  } else {
                    if ((v_tag_2464 == ((int64_t)1ULL))) {
                      V v_i_2469 = v_field_2465;
                      V v_t_2472;
                      switch (heff_tag_of(v_i_2469)) {
                      case TAG_At: {
                        V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
                        v_t_2472 = v_s_2471;
                        break;
                      }
                      default: heff_nomatch(v_i_2469);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2469}), v_t_2472});
                    } else {
                      V v_t_2473 = v_field_2465;
                      V v_t_2476;
                      switch (heff_tag_of(v_t_2473)) {
                      case TAG_At: {
                        V v_s_2475 = heff_dup(heff_field(v_t_2473, 1));
                        v_t_2476 = v_s_2475;
                        break;
                      }
                      default: heff_nomatch(v_t_2473);
                      }
                      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2473}), v_t_2476});
                    }
                  }
                }
              }
            }
          }
          default: return heff_nomatch(v_v_243);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2478 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24114;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_2479 = heff_field(v_v_243, 0);
            V v_sp_2480 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_2481 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_2479)));
            {
              V v_field_2483 = v_t_2481.f[1];
              int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
              if ((v_tag_2482 == ((int64_t)0ULL))) {
                heff_drop(v_e_2479);
                V v_segs_2485 = v_field_2483;
                HeffT2 v_t_2486 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_2485; V a_2 = v_sp_2480; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_2488 = v_t_2486.f[1];
                  int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                  if ((v_tag_2487 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_2490 = v_field_2488;
                    v_t_24114 = v_a_2490;
                  } else {
                    if ((v_tag_2487 == ((int64_t)1ULL))) {
                      V v_a_2492 = v_field_2488;
                      V v_t_2495;
                      switch (heff_tag_of(v_a_2492)) {
                      case TAG_At: {
                        V v_a_2494 = heff_dup(heff_field(v_a_2492, 1));
                        v_t_2495 = v_a_2494;
                        break;
                      }
                      default: heff_nomatch(v_a_2492);
                      }
                      v_t_24114 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_2492}), v_t_2495});
                    } else {
                      V v_a_2496 = v_field_2488;
                      V v_t_2499;
                      switch (heff_tag_of(v_a_2496)) {
                      case TAG_At: {
                        V v_a_2498 = heff_dup(heff_field(v_a_2496, 1));
                        v_t_2499 = v_a_2498;
                        break;
                      }
                      default: heff_nomatch(v_a_2496);
                      }
                      v_t_24114 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2496}), v_t_2499});
                    }
                  }
                }
              } else {
                heff_drop(v_field_2483);
                HeffT2 v_t_24100 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_2479, v_sp_2480})));
                {
                  V v_field_24102 = v_t_24100.f[1];
                  int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                  if ((v_tag_24101 == ((int64_t)0ULL))) {
                    V v_c_24104 = v_field_24102;
                    v_t_24114 = v_c_24104;
                  } else {
                    if ((v_tag_24101 == ((int64_t)1ULL))) {
                      V v_i_24106 = v_field_24102;
                      V v_t_24109;
                      switch (heff_tag_of(v_i_24106)) {
                      case TAG_At: {
                        V v_s_24108 = heff_dup(heff_field(v_i_24106, 1));
                        v_t_24109 = v_s_24108;
                        break;
                      }
                      default: heff_nomatch(v_i_24106);
                      }
                      v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24106}), v_t_24109});
                    } else {
                      V v_t_24110 = v_field_24102;
                      V v_t_24113;
                      switch (heff_tag_of(v_t_24110)) {
                      case TAG_At: {
                        V v_s_24112 = heff_dup(heff_field(v_t_24110, 1));
                        v_t_24113 = v_s_24112;
                        break;
                      }
                      default: heff_nomatch(v_t_24110);
                      }
                      v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24110}), v_t_24113});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, NTAG(TAG_Nil)});
          V v_args_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_24115});
          V v_t_24117 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24116));
          V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str2)}), heff_dup(v_sp_242)});
          V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24118, v_t_24117}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24119}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_24123 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(0LL), heff_dup(v_sp_242)));
          V v_t_24159;
          switch (heff_tag_of(v_v_243)) {
          case TAG_At: {
            V v_e_24124 = heff_field(v_v_243, 0);
            V v_sp_24125 = heff_field(v_v_243, 1);
            V v_ru_24v_243_24At = heff_take_reuse_n(v_v_243, 3ULL, 2);
            HeffT2 v_t_24126 = (g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(heff_dup(v_e_24124)));
            {
              V v_field_24128 = v_t_24126.f[1];
              int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
              if ((v_tag_24127 == ((int64_t)0ULL))) {
                heff_drop(v_e_24124);
                V v_segs_24130 = v_field_24128;
                HeffT2 v_t_24131 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_segs_24130; V a_2 = v_sp_24125; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
                {
                  V v_field_24133 = v_t_24131.f[1];
                  int64_t v_tag_24132 = ((int64_t)v_t_24131.f[0]);
                  if ((v_tag_24132 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24v_243_24At, 2);
                    V v_a_24135 = v_field_24133;
                    v_t_24159 = v_a_24135;
                  } else {
                    if ((v_tag_24132 == ((int64_t)1ULL))) {
                      V v_a_24137 = v_field_24133;
                      V v_t_24140;
                      switch (heff_tag_of(v_a_24137)) {
                      case TAG_At: {
                        V v_a_24139 = heff_dup(heff_field(v_a_24137, 1));
                        v_t_24140 = v_a_24139;
                        break;
                      }
                      default: heff_nomatch(v_a_24137);
                      }
                      v_t_24159 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_24137}), v_t_24140});
                    } else {
                      V v_a_24141 = v_field_24133;
                      V v_t_24144;
                      switch (heff_tag_of(v_a_24141)) {
                      case TAG_At: {
                        V v_a_24143 = heff_dup(heff_field(v_a_24141, 1));
                        v_t_24144 = v_a_24143;
                        break;
                      }
                      default: heff_nomatch(v_a_24141);
                      }
                      v_t_24159 = heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_24141}), v_t_24144});
                    }
                  }
                }
              } else {
                heff_drop(v_field_24128);
                HeffT2 v_t_24145 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(heff_tag_at_n(v_ru_24v_243_24At, TAG_At, 2, (V[]){v_e_24124, v_sp_24125})));
                {
                  V v_field_24147 = v_t_24145.f[1];
                  int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
                  if ((v_tag_24146 == ((int64_t)0ULL))) {
                    V v_c_24149 = v_field_24147;
                    v_t_24159 = v_c_24149;
                  } else {
                    if ((v_tag_24146 == ((int64_t)1ULL))) {
                      V v_i_24151 = v_field_24147;
                      V v_t_24154;
                      switch (heff_tag_of(v_i_24151)) {
                      case TAG_At: {
                        V v_s_24153 = heff_dup(heff_field(v_i_24151, 1));
                        v_t_24154 = v_s_24153;
                        break;
                      }
                      default: heff_nomatch(v_i_24151);
                      }
                      v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24151}), v_t_24154});
                    } else {
                      V v_t_24155 = v_field_24147;
                      V v_t_24158;
                      switch (heff_tag_of(v_t_24155)) {
                      case TAG_At: {
                        V v_s_24157 = heff_dup(heff_field(v_t_24155, 1));
                        v_t_24158 = v_s_24157;
                        break;
                      }
                      default: heff_nomatch(v_t_24155);
                      }
                      v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24155}), v_t_24158});
                    }
                  }
                }
              }
            }
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_24160 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24159, NTAG(TAG_Nil)});
          V v_args_24161 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, v_t_24160});
          V v_t_24162 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24161));
          V v_t_24163 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str3)}), heff_dup(v_sp_242)});
          V v_t_24164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24163, v_t_24162}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24164}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentFloat: {
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
        V v_sp_24169;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24168 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24170 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24169), v_args_24166));
        V v_t_24171 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str4)}), heff_dup(v_sp_24169)});
        V v_t_24172 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24171, v_t_24170}), heff_dup(v_sp_24169)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24172}), v_sp_24169});
      }
      case TAG_SegmentUtf: {
        V v_ru_24seg12_244_24SegmentUtf = heff_take_reuse_n(v_seg12_244, 0ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_v_243);
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_24174 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s451350199x164887522(heff_dup(v_seg_240)));
        V v_args_24175 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24174, NTAG(TAG_Nil)});
        V v_sp_24178;
        switch (heff_tag_of(v_seg_240)) {
        case TAG_At: {
          V v_s_24177 = heff_field(v_seg_240, 1);
          heff_take_n(v_seg_240, 2ULL, 2);
          v_sp_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_seg_240);
        }
        V v_t_24179 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24178), v_args_24175));
        V v_t_24180 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24seg12_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_str5)}), heff_dup(v_sp_24178)});
        V v_t_24181 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24180, v_t_24179}), heff_dup(v_sp_24178)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24181}), v_sp_24178});
      }
      default: return heff_nomatch(v_seg12_244);
      }
    }
    default: return heff_nomatch(v_seg1_241);
    }
  }
  default: return heff_nomatch(v_seg_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x21_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x21_243, 0);
        V v_sp_245 = heff_field(v_x21_243, 1);
        V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x21_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_seg_2410);
          heff_drop_cell(v_ru_24x21_248_24At, 2);
          V v_s_2416 = v_field_2414;
          V v_t_2422;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2416, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2417 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_MkPair: {
              V v_s0_2418 = heff_field(v_x11_2417, 0);
              V v_sp0_2419 = heff_field(v_x11_2417, 1);
              V v_ru_24x11_2417_24MkPair = heff_take_reuse_n(v_x11_2417, 3ULL, 2);
              V v_t_2420 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2421 = heff_tag_at_n(v_ru_24x11_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2418, v_s_2416), v_t_2420});
              v_t_2422 = heff_tag_at_n(v_ru_24run_241_24Just, TAG_Just, 1, (V[]){v_t_2421});
              break;
            }
            default: heff_nomatch(v_x11_2417);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = v_t_2422;
          V t_2 = v_acc_242;
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(heff_tag_at_n(v_ru_24x21_248_24At, TAG_At, 2, (V[]){v_seg_2410, v_sp_2411})));
          V v_t_2429;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            v_t_2429 = v_acc_242;
            break;
          }
          case TAG_Just: {
            V v_x21_2424 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x21_2424)) {
            case TAG_MkPair: {
              V v_s_2425 = heff_field(v_x21_2424, 0);
              V v_sp_2426 = heff_field(v_x21_2424, 1);
              V v_ru_24x21_2424_24MkPair = heff_take_reuse_n(v_x21_2424, 3ULL, 2);
              V v_t_2427 = heff_tag_at_n(v_ru_24x21_2424_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2425}), heff_dup(v_sp_2426)});
              V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2427}), v_sp_2426});
              v_t_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_acc_242});
              break;
            }
            default: heff_nomatch(v_x21_2424);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = NTAG(TAG_Nothing);
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2429});
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      V v_t_246 = (g_list_2emap_24s1887874170x1747433177(v_args_245));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, v_t_246}), v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_247));
      V v_t_2422;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = v_field_2410;
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            V v_i_2417 = v_field_2410;
            V v_t_2420;
            switch (heff_tag_of(v_i_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_i_2417);
            }
            v_t_2422 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2417}), v_t_2420});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2421 = v_field_2410;
            v_t_2422 = v_t_2421;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2422}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s222465968x1390325533(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_249));
        v_t_2412 = heff_tag_at_n(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      heff_take_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      heff_take_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_248 = (g_list_2emap_24s1992667171x110340492(v_fs_247));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_248});
  }
  case TAG_TSum: {
    V v_vs_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2410 = (g_list_2emap_24s513391942x823299088(v_vs_249));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2410});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2411 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_a_2411, 0);
      V v_sp_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2414});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2416 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_i_2416)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_i_2416, 0);
      V v_sp_2418 = heff_field(v_i_2416, 1);
      V v_ru_24i_2416_24At = heff_take_reuse_n(v_i_2416, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24i_2416_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_i_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2420});
  }
  case TAG_TChk: {
    V v_c_2421 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2425;
    switch (heff_tag_of(v_c_2421)) {
    case TAG_At: {
      V v_n_2422 = heff_field(v_c_2421, 0);
      V v_sp_2423 = heff_field(v_c_2421, 1);
      V v_ru_24c_2421_24At = heff_take_reuse_n(v_c_2421, 3ULL, 2);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2422));
      v_t_2425 = heff_tag_at_n(v_ru_24c_2421_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_2423});
      break;
    }
    default: heff_nomatch(v_c_2421);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2425});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}