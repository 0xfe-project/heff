// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_go 10063
#define LBL_key 315609
static uint32_t shape_go[] = {LBL_go};
V g_heff_2earity_2earityOne(V, V);
V g_heff_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2earity_2earityOne_clo;
V g_heff_2earity_2ecallOf(V, V, V, V);
V g_heff_2earity_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2earity_2ecallOf_clo;
V g_heff_2earity_2edropA(V, V);
V g_heff_2earity_2edropA_entry(V self, V *a);
extern Clo g_heff_2earity_2edropA_clo;
V g_heff_2earity_2esatGo(V, V, V);
V g_heff_2earity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2earity_2esatGo_clo;
V g_heff_2earity_2esatOf(V);
V g_heff_2earity_2esatOf_entry(V self, V *a);
extern Clo g_heff_2earity_2esatOf_clo;
V g_heff_2earity_2etakeA(V, V);
V g_heff_2earity_2etakeA_entry(V self, V *a);
extern Clo g_heff_2earity_2etakeA_clo;
V g_heff_2eir_2espine(V);
V g_heff_2eir_2espine_entry(V self, V *a);
extern Clo g_heff_2eir_2espine_clo;
V g_heff_2eprims_2eallPrims_get(void);
V g_heff_2eprims_2eprimArityGo(V, V);
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2eprims_2eprimArityGo_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
Clo g_heff_2earity_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2earityOne_entry, 2, 0};

V g_heff_2earity_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get(v_d_241, LBL_key), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2earity_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2earity_2earityOne(a[0], a[1]);
}
Clo g_heff_2earity_2etakeA_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2etakeA_entry, 2, 0};

V g_heff_2earity_2etakeA(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2earity_2etakeA(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2earity_2etakeA_entry(V self, V *a) {
  (void)self;
  return g_heff_2earity_2etakeA(a[0], a[1]);
}
Clo g_heff_2earity_2edropA_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2edropA_entry, 2, 0};

V g_heff_2earity_2edropA(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2earity_2edropA_entry(V self, V *a) {
  (void)self;
  return g_heff_2earity_2edropA(a[0], a[1]);
}
Clo g_heff_2earity_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2ecallOf_entry, 4, 0};

V g_heff_2earity_2ecallOf(V v_r_240, V v_ar_241, V v_h_242, V v_as_243) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_EVar: {
    V v_t_245 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_245, v_as_243});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_dup(heff_field(v_h_242, 0));
    V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_246), v_ar_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_g_246);
      V v_t_248 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
      return heff_tag(TAG_EApp, 2, (V[]){v_t_248, v_as_243});
    }
    case TAG_Just: {
      V v_n_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_a_2410 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
      V v_t_2411 = heff_intLe(heff_dup(v_n_249), v_a_2410);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop_tag(v_h_242, 1);
        V v_f_2412 = heff_tag(TAG_ECall, 2, (V[]){v_g_246, (g_heff_2earity_2etakeA(heff_dup(v_n_249), heff_dup(v_as_243)))});
        V v_as_2413 = (g_heff_2earity_2edropA(v_n_249, v_as_243));
        V v_t_2414 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_2413));
        V v_t_2415 = heff_intEq(v_t_2414, MK_INT(0LL));
        switch (heff_tag_of(v_t_2415)) {
        case TAG_True: {
          heff_drop(v_as_2413);
          return v_f_2412;
        }
        case TAG_False: {
          return heff_tag(TAG_EApp, 2, (V[]){v_f_2412, v_as_2413});
        }
        default: return heff_nomatch(v_t_2415);
        }
      }
      case TAG_False: {
        heff_drop(v_g_246);
        heff_drop(v_n_249);
        V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
        return heff_tag(TAG_EApp, 2, (V[]){v_t_2416, v_as_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_ELam: {
    V v_t_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2419, v_as_243});
  }
  case TAG_EApp: {
    V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2422, v_as_243});
  }
  case TAG_ELet: {
    V v_t_2426 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2426, v_as_243});
  }
  case TAG_ERecord: {
    V v_t_2428 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2428, v_as_243});
  }
  case TAG_EProj: {
    V v_t_2431 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2431, v_as_243});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2434, v_as_243});
  }
  case TAG_EMatch: {
    V v_t_2437 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2437, v_as_243});
  }
  case TAG_EPrim: {
    V v_p_2438 = heff_dup(heff_field(v_h_242, 0));
    V v_t_2439 = ({ V a_0 = heff_dup(v_p_2438); V b_1 = heff_dup(g_heff_2eprims_2eallPrims_get()); V r_ = (g_heff_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2439)) {
    case TAG_Nothing: {
      heff_drop(v_p_2438);
      V v_t_2440 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
      return heff_tag(TAG_EApp, 2, (V[]){v_t_2440, v_as_243});
    }
    case TAG_Just: {
      V v_n_2441 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      V v_a_2442 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_243));
      V v_t_2443 = heff_intLe(heff_dup(v_n_2441), v_a_2442);
      switch (heff_tag_of(v_t_2443)) {
      case TAG_True: {
        heff_drop(v_r_240);
        heff_drop_tag(v_h_242, 1);
        V v_f_2444 = heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2438, (g_heff_2earity_2etakeA(heff_dup(v_n_2441), heff_dup(v_as_243)))});
        V v_as_2445 = (g_heff_2earity_2edropA(v_n_2441, v_as_243));
        V v_t_2446 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_as_2445));
        V v_t_2447 = heff_intEq(v_t_2446, MK_INT(0LL));
        switch (heff_tag_of(v_t_2447)) {
        case TAG_True: {
          heff_drop(v_as_2445);
          return v_f_2444;
        }
        case TAG_False: {
          return heff_tag(TAG_EApp, 2, (V[]){v_f_2444, v_as_2445});
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      case TAG_False: {
        heff_drop(v_p_2438);
        heff_drop(v_n_2441);
        V v_t_2448 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
        return heff_tag(TAG_EApp, 2, (V[]){v_t_2448, v_as_243});
      }
      default: return heff_nomatch(v_t_2443);
      }
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2451 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2451, v_as_243});
  }
  case TAG_ECall: {
    V v_t_2454 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2454, v_as_243});
  }
  case TAG_EInt: {
    V v_t_2456 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2456, v_as_243});
  }
  case TAG_EFloat: {
    V v_t_2458 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2458, v_as_243});
  }
  case TAG_EStr: {
    V v_t_2460 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2460, v_as_243});
  }
  case TAG_EFixed: {
    V v_t_2463 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2463, v_as_243});
  }
  case TAG_EFloat32: {
    V v_t_2465 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2465, v_as_243});
  }
  case TAG_EAbandon: {
    V v_t_2466 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2466, v_as_243});
  }
  case TAG_EFix: {
    V v_t_2469 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_h_242}));
    return heff_tag(TAG_EApp, 2, (V[]){v_t_2469, v_as_243});
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2earity_2ecallOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2earity_2ecallOf(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2earity_2esatGo_lam0(V self, V *args);
V g_heff_2earity_2esatGo_lam1(V self, V *args);
V g_heff_2earity_2esatGo_lam2(V self, V *args);
V g_heff_2earity_2esatGo_lam3(V self, V *args);
V g_heff_2earity_2esatGo_lam4(V self, V *args);
V g_heff_2earity_2esatGo_lam5(V self, V *args);
Clo g_heff_2earity_2esatGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2esatGo_entry, 3, 0};

V g_heff_2earity_2esatGo(V v_r_240, V v_ar_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EGlobal: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_b_246}));
    return heff_tag_at(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_t_247});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_as0_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2eir_2espine(heff_tag_at(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_248, v_as0_249})));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_h_2411 = heff_field(v_t_2410, 0);
      V v_as_2412 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      V v_t_2414 = (g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2412));
      return (g_heff_2earity_2ecallOf(v_r_240, v_ar_241, v_h_2411, v_t_2414));
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_242, 0);
    V v_a_2416 = heff_field(v_e_242, 1);
    V v_b_2417 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_go), 1, (V[]){v_a_2416}));
    V v_t_2419 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_b_2417}));
    return heff_tag_at(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, v_t_2419});
  }
  case TAG_ERecord: {
    V v_fs_2420 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    return heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam1, 1, 1, (V[]){v_r_240}), v_fs_2420))});
  }
  case TAG_EProj: {
    V v_e2_2425 = heff_field(v_e_242, 0);
    V v_l_2426 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_e2_2425}));
    return heff_tag_at(v_ru_24e_242_24EProj, TAG_EProj, 2, (V[]){v_t_2427, v_l_2426});
  }
  case TAG_ETag: {
    V v_t_2428 = heff_field(v_e_242, 0);
    V v_as_2429 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at(v_ru_24e_242_24ETag, TAG_ETag, 2, (V[]){v_t_2428, (g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam2, 1, 1, (V[]){v_r_240}), v_as_2429))});
  }
  case TAG_EMatch: {
    V v_s_2431 = heff_field(v_e_242, 0);
    V v_arms_2432 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_go), 1, (V[]){v_s_2431}));
    return heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2433, (g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam3, 1, 1, (V[]){v_r_240}), v_arms_2432))});
  }
  case TAG_EPrim: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2440 = heff_field(v_e_242, 0);
    V v_as_2441 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2440, (g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam4, 1, 1, (V[]){v_r_240}), v_as_2441))});
  }
  case TAG_ECall: {
    V v_g_2443 = heff_field(v_e_242, 0);
    V v_as_2444 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2443, (g_prelude_2emap(heff_clo(g_heff_2earity_2esatGo_lam5, 1, 1, (V[]){v_r_240}), v_as_2444))});
  }
  case TAG_EInt: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  case TAG_EFix: {
    heff_drop(v_r_240);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2earity_2esatGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2earity_2esatGo(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2earity_2esatGo_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_go);
  args[0] = v_a_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2earity_2esatGo_lam1(V self, V *args) {
  V v_p_2421 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_l_2422 = heff_field(v_p_2421, 0);
    V v_e2_2423 = heff_field(v_p_2421, 1);
    V v_ru_24p_2421_24MkPair = heff_take_reuse_n(v_p_2421, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_e2_2423}));
    return heff_tag_at(v_ru_24p_2421_24MkPair, TAG_MkPair, 2, (V[]){v_l_2422, v_t_2424});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_heff_2earity_2esatGo_lam2(V self, V *args) {
  V v_a_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_go);
  args[0] = v_a_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2earity_2esatGo_lam3(V self, V *args) {
  V v_a_2434 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2434)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_a_2434, 0);
    V v_vs_2436 = heff_field(v_a_2434, 1);
    V v_b_2437 = heff_field(v_a_2434, 2);
    V v_ru_24a_2434_24MkArm = heff_take_reuse_n(v_a_2434, 7ULL, 3);
    V v_t_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_go), 1, (V[]){v_b_2437}));
    return heff_tag_at(v_ru_24a_2434_24MkArm, TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_t_2438});
  }
  default: return heff_nomatch(v_a_2434);
  }
}
V g_heff_2earity_2esatGo_lam4(V self, V *args) {
  V v_a_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_go);
  args[0] = v_a_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2earity_2esatGo_lam5(V self, V *args) {
  V v_a_2445 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_r_240, LBL_go);
  args[0] = v_a_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2earity_2esatOf_lam0(V self, V *args);
Clo g_heff_2earity_2esatOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2earity_2esatOf_entry, 1, 0};

V g_heff_2earity_2esatOf(V v_ar_240) {
top: ;
  return heff_rec(1, shape_go, (V[]){heff_clo(g_heff_2earity_2esatOf_lam0, 1, 1, (V[]){heff_dup(v_ar_240)})});
}
V g_heff_2earity_2esatOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2earity_2esatOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2earity_2esatOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_ar_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2earity_2esatOf(v_ar_240));
  return ({ V a_0 = v_t_242; V a_1 = v_ar_240; V a_2 = v_e_241; V r_ = (g_heff_2earity_2esatGo(a_0, a_1, a_2)); heff_drop(v_ar_240); r_; });
}