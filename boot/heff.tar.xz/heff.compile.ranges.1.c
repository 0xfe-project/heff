// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_MkSeen 11336
#define TAG_MkSeenVals 17452
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_consts 592362651
#define LBL_dirty 296951788
#define LBL_fix 310927
#define LBL_gathered 1327153563
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marking 1071112247
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
static uint32_t shape_byKey__callers__callersOf__ints[] = {LBL_byKey, LBL_callers, LBL_callersOf, LBL_ints};
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_ranges__tests[] = {LBL_ranges, LBL_tests};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eranges_2eabsorb(V, V, V);
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorb_clo;
V g_heff_2ecompile_2eranges_2eandR(V, V);
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eandR_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2earityOne(V, V);
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earityOne_clo;
V g_heff_2ecompile_2eranges_2earmSeen(V, V);
V g_heff_2ecompile_2eranges_2earmSeen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earmSeen_clo;
V g_heff_2ecompile_2eranges_2earmSeen_24tok2(V, V, V);
V g_heff_2ecompile_2eranges_2earmSeen_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earmSeen_24tok2_clo;
V g_heff_2ecompile_2eranges_2ecalledIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecalledIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecalledIn_clo;
V g_heff_2ecompile_2eranges_2econdRefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdRefine_clo;
V g_heff_2ecompile_2eranges_2ecorners(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_clo;
V g_heff_2ecompile_2eranges_2ecorners_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_24tok1_clo;
V g_heff_2ecompile_2eranges_2edivPositive(V, V, V);
V g_heff_2ecompile_2eranges_2edivPositive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2edivPositive_clo;
V g_heff_2ecompile_2eranges_2edivPositive_24tok1(V, V, V, V);
V g_heff_2ecompile_2eranges_2edivPositive_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2edivPositive_24tok1_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2egatherArms(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherArms_clo;
V g_heff_2ecompile_2eranges_2egatherCond(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherCond_clo;
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
V g_heff_2ecompile_2eranges_2egatherGo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egivenFrom_clo;
V g_heff_2ecompile_2eranges_2ehighMeet(V, V);
V g_heff_2ecompile_2eranges_2ehighMeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ehighMeet_clo;
V g_heff_2ecompile_2eranges_2eintOps_get(void);
V g_heff_2ecompile_2eranges_2eisComparison(V);
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisComparison_clo;
V g_heff_2ecompile_2eranges_2emarked(V, V, V, V);
V g_heff_2ecompile_2eranges_2emarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarked_clo;
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2emodR(V, V);
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emodR_clo;
V g_heff_2ecompile_2eranges_2emulR(V, V);
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emulR_clo;
V g_heff_2ecompile_2eranges_2enamesW(V, V);
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enamesW_clo;
V g_heff_2ecompile_2eranges_2enatural(V);
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enatural_clo;
V g_heff_2ecompile_2eranges_2enonZero(V);
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enonZero_clo;
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2eranges_2erangeProgram(V);
V g_heff_2ecompile_2eranges_2erangeProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeProgram_clo;
V g_heff_2ecompile_2eranges_2erangedFns(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedFns_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedFns_clo;
V g_heff_2ecompile_2eranges_2erangedIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedIn_clo;
V g_heff_2ecompile_2eranges_2erangedScans(V, V, V);
V g_heff_2ecompile_2eranges_2erangedScans_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedScans_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2erootTo_24tok1(V, V, V, V);
V g_heff_2ecompile_2eranges_2erootTo_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootTo_24tok1_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2escopeOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2escopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escopeOne_clo;
V g_heff_2ecompile_2eranges_2estartParams(V, V);
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2estartParams_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok1_clo;
V g_heff_2ecompile_2eranges_2ewalkCond(V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_clo;
V g_heff_2ecompile_2eranges_2ewalkCond_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_24dps_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewiden_clo;
V g_heff_2ecompile_2eranges_2ewidenHigh(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenHigh_clo;
V g_heff_2ecompile_2eranges_2ewidenLow(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenLow_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2eranges_2ewithTest(V, V, V);
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithTest_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s326537207x242980421(V, V);
V g_list_2efoldl_24s326537207x242980421_entry(V self, V *a);
extern Clo g_list_2efoldl_24s326537207x242980421_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s92926977x826280221(V, V, V);
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a);
extern Clo g_list_2efoldl_24s92926977x826280221_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2emapValues_24s471823439x1830654496(V);
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str0, 11, "wordToFloat");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str1, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str3, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str4, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str5, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str6, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str7, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str8, 7, "wordRem");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str9, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str10, 8, "wordQuot");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str11, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str12, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str13, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str14, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str15, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str16, 7, "wordMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str17, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str18, 7, "wordSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str19, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str20, 7, "wordAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str21, 6, "intAdd");

static V g_heff_2ecompile_2eranges_2ewordPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2ewordPrims_st;
static V g_heff_2ecompile_2eranges_2ewordPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str0), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str2), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str4), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str6), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str8), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str10), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str12), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str14), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str16), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str18), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str19)}), v_t_248});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str20), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str21)}), v_t_249});
}
V g_heff_2ecompile_2eranges_2ewordPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2ewordPrims_st)) return g_heff_2ecompile_2eranges_2ewordPrims_val;
  return heff_global(&g_heff_2ecompile_2eranges_2ewordPrims_val, &g_heff_2ecompile_2eranges_2ewordPrims_st, g_heff_2ecompile_2eranges_2ewordPrims_init);
}

static V g_heff_2ecompile_2eranges_2eanyRange_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eanyRange_st;
static V g_heff_2ecompile_2eranges_2eanyRange_init(void) {
  return heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2ecompile_2eranges_2eanyRange_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eanyRange_st)) return g_heff_2ecompile_2eranges_2eanyRange_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eanyRange_val, &g_heff_2ecompile_2eranges_2eanyRange_st, g_heff_2ecompile_2eranges_2eanyRange_init);
}
Clo g_heff_2ecompile_2eranges_2erangeEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangeEq_entry, 2, 0};

V g_heff_2ecompile_2eranges_2erangeEq(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_True);
    }
    case TAG_Within: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  case TAG_Within: {
    V v_a_244 = heff_field(v_r_240, 0);
    V v_b_245 = heff_field(v_r_240, 1);
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_c_246 = heff_field(v_s_241, 0);
      V v_d_247 = heff_field(v_s_241, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_c_246)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_b_245)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_d_247)) {
            case TAG_Nothing: {
              return NTAG(TAG_True);
            }
            case TAG_Just: {
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_d_247);
            }
          }
          case TAG_Just: {
            V v_a_249 = heff_field(v_b_245, 0);
            switch (heff_tag_of(v_d_247)) {
            case TAG_Nothing: {
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2410 = heff_field(v_d_247, 0);
              V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_a_249, v_b_2410, 0));
              return v_ret_24bool;
            }
            default: return heff_nomatch(v_d_247);
            }
          }
          default: return heff_nomatch(v_b_245);
          }
        }
        case TAG_Just: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c_246);
        }
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_c_246)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_b_2413 = heff_field(v_c_246, 0);
          if (heff_intEq_c_lent(v_a_2412, v_b_2413, 0)) {
            switch (heff_tag_of(v_b_245)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_d_247)) {
              case TAG_Nothing: {
                return NTAG(TAG_True);
              }
              case TAG_Just: {
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_d_247);
              }
            }
            case TAG_Just: {
              V v_a_2415 = heff_field(v_b_245, 0);
              switch (heff_tag_of(v_d_247)) {
              case TAG_Nothing: {
                return NTAG(TAG_False);
              }
              case TAG_Just: {
                V v_b_2416 = heff_field(v_d_247, 0);
                V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_a_2415, v_b_2416, 0));
                return v_ret_24bool;
              }
              default: return heff_nomatch(v_d_247);
              }
            }
            default: return heff_nomatch(v_b_245);
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_c_246);
        }
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2erangeEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2ehighMeet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ehighMeet_entry, 2, 0};

V g_heff_2ecompile_2eranges_2ehighMeet(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return v_x2_241;
  }
  case TAG_Just: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_a_242});
    }
    case TAG_Just: {
      V v_b_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_t_244;
      if (heff_intLt_c_lent(v_a_242, v_b_243, 0)) {
        heff_drop(v_b_243);
        v_t_244 = v_a_242;
      } else {
        heff_drop(v_a_242);
        v_t_244 = v_b_243;
      }
      return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_t_244});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ehighMeet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ehighMeet(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2ecorners_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecorners_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ecorners(V v_a_240, V v_b_241, V v_c_242, V v_d_243) {
top: ;
  V v_a_244;
  if (heff_intLt_c_lent(v_a_240, v_b_241, 0)) {
    v_a_244 = heff_dup(v_a_240);
  } else {
    v_a_244 = heff_dup(v_b_241);
  }
  V v_b_245;
  if (heff_intLt_c_lent(v_c_242, v_d_243, 0)) {
    v_b_245 = heff_dup(v_c_242);
  } else {
    v_b_245 = heff_dup(v_d_243);
  }
  V v_t_246;
  if (heff_intLt_c_lent(v_a_244, v_b_245, 0)) {
    heff_drop(v_b_245);
    v_t_246 = v_a_244;
  } else {
    heff_drop(v_a_244);
    v_t_246 = v_b_245;
  }
  V v_a_247;
  if (heff_intLt_c_lent(v_a_240, v_b_241, 0)) {
    heff_drop(v_a_240);
    v_a_247 = v_b_241;
  } else {
    heff_drop(v_b_241);
    v_a_247 = v_a_240;
  }
  V v_b_248;
  if (heff_intLt_c_lent(v_c_242, v_d_243, 0)) {
    heff_drop(v_c_242);
    v_b_248 = v_d_243;
  } else {
    heff_drop(v_d_243);
    v_b_248 = v_c_242;
  }
  V v_t_249;
  if (heff_intLt_c_lent(v_a_247, v_b_248, 0)) {
    heff_drop(v_a_247);
    v_t_249 = v_b_248;
  } else {
    heff_drop(v_b_248);
    v_t_249 = v_a_247;
  }
  return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_246}), heff_tag_n(TAG_Just, 1, (V[]){v_t_249})});
}
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecorners(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2edivPositive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2edivPositive_entry, 3, 0};

V g_heff_2ecompile_2eranges_2edivPositive(V v_lb_240, V v_hb_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    heff_drop(v_lb_240);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_r1_243 = heff_field(v_r_242, 0);
    V v_r2_244 = heff_field(v_r_242, 1);
    V v_ru_24r_242_24Within = heff_take_reuse_n(v_r_242, 3ULL, 2);
    switch (heff_tag_of(v_r1_243)) {
    case TAG_Nothing: {
      heff_drop(v_lb_240);
      heff_drop(v_r2_244);
      heff_drop_cell(v_ru_24r_242_24Within, 2);
      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_r1_243, 0);
      heff_take_n(v_r1_243, 1ULL, 1);
      switch (heff_tag_of(v_r2_244)) {
      case TAG_Nothing: {
        heff_drop(v_lb_240);
        heff_drop_cell(v_ru_24r_242_24Within, 2);
        heff_drop(v_x_245);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_y_246 = heff_field(v_r2_244, 0);
        heff_take_n(v_r2_244, 1ULL, 1);
        V v_t_248;
        switch (heff_tag_of(v_hb_241)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_245, 1)) {
            heff_drop(v_x_245);
            v_t_248 = MK_INT(0LL);
          } else {
            v_t_248 = heff_intDiv(v_x_245, heff_dup(v_lb_240));
          }
          break;
        }
        case TAG_Just: {
          V v_hb_247 = heff_field(v_hb_241, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_245, 1)) {
            v_t_248 = heff_intDiv(v_x_245, heff_dup(v_hb_247));
          } else {
            v_t_248 = heff_intDiv(v_x_245, heff_dup(v_lb_240));
          }
          break;
        }
        default: heff_nomatch(v_hb_241);
        }
        V v_t_2410;
        switch (heff_tag_of(v_hb_241)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
            v_t_2410 = heff_intDiv(v_y_246, v_lb_240);
          } else {
            heff_drop(v_lb_240);
            heff_drop(v_y_246);
            v_t_2410 = MK_INT(-1LL);
          }
          break;
        }
        case TAG_Just: {
          V v_hb_249 = heff_field(v_hb_241, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
            v_t_2410 = heff_intDiv(v_y_246, v_lb_240);
          } else {
            heff_drop(v_lb_240);
            v_t_2410 = heff_intDiv(v_y_246, heff_dup(v_hb_249));
          }
          break;
        }
        default: heff_nomatch(v_hb_241);
        }
        return heff_tag_at_n(v_ru_24r_242_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_248}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410})});
      }
      default: return heff_nomatch(v_r2_244);
      }
    }
    default: return heff_nomatch(v_r1_243);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2edivPositive_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2edivPositive(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str5, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str6, 7, "wordAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str7, 7, "wordSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str8, 7, "wordMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str9, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str10, 8, "wordQuot");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str11, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str12, 7, "wordRem");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str13, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str14, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str15, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str16, 9, "strByteAt");
Clo g_heff_2ecompile_2eranges_2eprimRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eprimRange_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eprimRange(V v_p_240, V v_rs_241) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str0), 2)) {
    HeffT3 v_t_242 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      HeffT3 v_t_246 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
      {
        V v_field_248 = v_t_246.f[1];
        V v_field_249 = v_t_246.f[2];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        V v_t_2412;
        if ((v_tag_243 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_244;
          V v_x12_2411 = v_field_245;
          heff_drop(v_x12_2411);
          v_t_2412 = v_x_2410;
        } else {
          heff_drop(v_field_244);
          heff_drop(v_field_245);
          v_t_2412 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Unreached: {
          heff_drop(v_field_248);
          heff_drop(v_field_249);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_a_2413 = heff_field(v_t_2412, 0);
          V v_b_2414 = heff_field(v_t_2412, 1);
          V v_ru_24t_2412_24Within = heff_take_reuse_n(v_t_2412, 3ULL, 2);
          V v_t_2417;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_248;
            V v_x12_2416 = v_field_249;
            heff_drop(v_x12_2416);
            v_t_2417 = v_x_2415;
          } else {
            heff_drop(v_field_248);
            heff_drop(v_field_249);
            v_t_2417 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          switch (heff_tag_of(v_t_2417)) {
          case TAG_Unreached: {
            heff_drop(v_a_2413);
            heff_drop(v_b_2414);
            heff_drop_cell(v_ru_24t_2412_24Within, 2);
            return NTAG(TAG_Unreached);
          }
          case TAG_Within: {
            V v_c_2418 = heff_field(v_t_2417, 0);
            V v_d_2419 = heff_field(v_t_2417, 1);
            heff_take_n(v_t_2417, 3ULL, 2);
            V v_t_2422;
            switch (heff_tag_of(v_a_2413)) {
            case TAG_Nothing: {
              heff_drop(v_c_2418);
              v_t_2422 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_a_2420 = heff_field(v_a_2413, 0);
              V v_ru_24a_2413_24Just = heff_take_reuse_n(v_a_2413, 1ULL, 1);
              switch (heff_tag_of(v_c_2418)) {
              case TAG_Nothing: {
                heff_drop(v_a_2420);
                heff_drop_cell(v_ru_24a_2413_24Just, 1);
                v_t_2422 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_b_2421 = heff_field(v_c_2418, 0);
                heff_take_n(v_c_2418, 1ULL, 1);
                v_t_2422 = heff_tag_at_n(v_ru_24a_2413_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2420, v_b_2421)});
                break;
              }
              default: heff_nomatch(v_c_2418);
              }
              break;
            }
            default: heff_nomatch(v_a_2413);
            }
            V v_t_2425;
            switch (heff_tag_of(v_b_2414)) {
            case TAG_Nothing: {
              heff_drop(v_d_2419);
              v_t_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_a_2423 = heff_field(v_b_2414, 0);
              V v_ru_24b_2414_24Just = heff_take_reuse_n(v_b_2414, 1ULL, 1);
              switch (heff_tag_of(v_d_2419)) {
              case TAG_Nothing: {
                heff_drop(v_a_2423);
                heff_drop_cell(v_ru_24b_2414_24Just, 1);
                v_t_2425 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_b_2424 = heff_field(v_d_2419, 0);
                heff_take_n(v_d_2419, 1ULL, 1);
                v_t_2425 = heff_tag_at_n(v_ru_24b_2414_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2423, v_b_2424)});
                break;
              }
              default: heff_nomatch(v_d_2419);
              }
              break;
            }
            default: heff_nomatch(v_b_2414);
            }
            return heff_tag_at_n(v_ru_24t_2412_24Within, TAG_Within, 2, (V[]){v_t_2422, v_t_2425});
          }
          default: return heff_nomatch(v_t_2417);
          }
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
    }
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str1), 2)) {
      HeffT3 v_t_2426 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
      {
        V v_field_2428 = v_t_2426.f[1];
        V v_field_2429 = v_t_2426.f[2];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        HeffT3 v_t_2430 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
        {
          V v_field_2432 = v_t_2430.f[1];
          V v_field_2433 = v_t_2430.f[2];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          V v_t_2436;
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_x_2434 = v_field_2428;
            V v_x12_2435 = v_field_2429;
            heff_drop(v_x12_2435);
            v_t_2436 = v_x_2434;
          } else {
            heff_drop(v_field_2428);
            heff_drop(v_field_2429);
            v_t_2436 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          switch (heff_tag_of(v_t_2436)) {
          case TAG_Unreached: {
            heff_drop(v_field_2432);
            heff_drop(v_field_2433);
            return NTAG(TAG_Unreached);
          }
          case TAG_Within: {
            V v_a_2437 = heff_field(v_t_2436, 0);
            V v_b_2438 = heff_field(v_t_2436, 1);
            V v_ru_24t_2436_24Within = heff_take_reuse_n(v_t_2436, 3ULL, 2);
            V v_t_2441;
            if ((v_tag_2431 == ((int64_t)0ULL))) {
              V v_x_2439 = v_field_2432;
              V v_x12_2440 = v_field_2433;
              heff_drop(v_x12_2440);
              v_t_2441 = v_x_2439;
            } else {
              heff_drop(v_field_2432);
              heff_drop(v_field_2433);
              v_t_2441 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            switch (heff_tag_of(v_t_2441)) {
            case TAG_Unreached: {
              heff_drop(v_a_2437);
              heff_drop(v_b_2438);
              heff_drop_cell(v_ru_24t_2436_24Within, 2);
              return NTAG(TAG_Unreached);
            }
            case TAG_Within: {
              V v_c_2442 = heff_field(v_t_2441, 0);
              V v_d_2443 = heff_field(v_t_2441, 1);
              heff_take_n(v_t_2441, 3ULL, 2);
              V v_t_2446;
              switch (heff_tag_of(v_a_2437)) {
              case TAG_Nothing: {
                heff_drop(v_d_2443);
                v_t_2446 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_a_2444 = heff_field(v_a_2437, 0);
                V v_ru_24a_2437_24Just = heff_take_reuse_n(v_a_2437, 1ULL, 1);
                switch (heff_tag_of(v_d_2443)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2444);
                  heff_drop_cell(v_ru_24a_2437_24Just, 1);
                  v_t_2446 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_b_2445 = heff_field(v_d_2443, 0);
                  heff_take_n(v_d_2443, 1ULL, 1);
                  v_t_2446 = heff_tag_at_n(v_ru_24a_2437_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_2444, v_b_2445)});
                  break;
                }
                default: heff_nomatch(v_d_2443);
                }
                break;
              }
              default: heff_nomatch(v_a_2437);
              }
              V v_t_2449;
              switch (heff_tag_of(v_b_2438)) {
              case TAG_Nothing: {
                heff_drop(v_c_2442);
                v_t_2449 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_a_2447 = heff_field(v_b_2438, 0);
                V v_ru_24b_2438_24Just = heff_take_reuse_n(v_b_2438, 1ULL, 1);
                switch (heff_tag_of(v_c_2442)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2447);
                  heff_drop_cell(v_ru_24b_2438_24Just, 1);
                  v_t_2449 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_b_2448 = heff_field(v_c_2442, 0);
                  heff_take_n(v_c_2442, 1ULL, 1);
                  v_t_2449 = heff_tag_at_n(v_ru_24b_2438_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_2447, v_b_2448)});
                  break;
                }
                default: heff_nomatch(v_c_2442);
                }
                break;
              }
              default: heff_nomatch(v_b_2438);
              }
              return heff_tag_at_n(v_ru_24t_2436_24Within, TAG_Within, 2, (V[]){v_t_2446, v_t_2449});
            }
            default: return heff_nomatch(v_t_2441);
            }
          }
          default: return heff_nomatch(v_t_2436);
          }
        }
      }
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str2), 2)) {
        HeffT3 v_t_2450 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
        V v_t_2456;
        {
          V v_field_2452 = v_t_2450.f[1];
          V v_field_2453 = v_t_2450.f[2];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            V v_x_2454 = v_field_2452;
            V v_x12_2455 = v_field_2453;
            heff_drop(v_x12_2455);
            v_t_2456 = v_x_2454;
          } else {
            heff_drop(v_field_2452);
            heff_drop(v_field_2453);
            v_t_2456 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        HeffT3 v_t_2457 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
        V v_t_2463;
        {
          V v_field_2459 = v_t_2457.f[1];
          V v_field_2460 = v_t_2457.f[2];
          int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
          if ((v_tag_2458 == ((int64_t)0ULL))) {
            V v_x_2461 = v_field_2459;
            V v_x12_2462 = v_field_2460;
            heff_drop(v_x12_2462);
            v_t_2463 = v_x_2461;
          } else {
            heff_drop(v_field_2459);
            heff_drop(v_field_2460);
            v_t_2463 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        HEFF_LAST return g_heff_2ecompile_2eranges_2emulR(v_t_2456, v_t_2463);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str3), 2)) {
          HeffT3 v_t_2464 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
          {
            V v_field_2466 = v_t_2464.f[1];
            V v_field_2467 = v_t_2464.f[2];
            int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
            HeffT3 v_t_2468 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
            {
              V v_field_2470 = v_t_2468.f[1];
              V v_field_2471 = v_t_2468.f[2];
              int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
              V v_t_2474;
              if ((v_tag_2469 == ((int64_t)0ULL))) {
                V v_x_2472 = v_field_2470;
                V v_x12_2473 = v_field_2471;
                heff_drop(v_x12_2473);
                v_t_2474 = v_x_2472;
              } else {
                heff_drop(v_field_2470);
                heff_drop(v_field_2471);
                v_t_2474 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              switch (heff_tag_of(v_t_2474)) {
              case TAG_Unreached: {
                heff_drop(v_field_2466);
                heff_drop(v_field_2467);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Within: {
                V v_b1_2475 = heff_field(v_t_2474, 0);
                V v_hb_2476 = heff_field(v_t_2474, 1);
                heff_take_n(v_t_2474, 3ULL, 2);
                switch (heff_tag_of(v_b1_2475)) {
                case TAG_Nothing: {
                  heff_drop(v_field_2466);
                  heff_drop(v_field_2467);
                  heff_drop(v_hb_2476);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
                case TAG_Just: {
                  V v_lb_2477 = heff_field(v_b1_2475, 0);
                  V v_ru_24b1_2475_24Just = heff_take_reuse_n(v_b1_2475, 1ULL, 1);
                  if (heff_intLt_c_lent(MK_INT(0LL), v_lb_2477, 1)) {
                    V v_t_2480;
                    if ((v_tag_2465 == ((int64_t)0ULL))) {
                      V v_x_2478 = v_field_2466;
                      V v_x12_2479 = v_field_2467;
                      heff_drop(v_x12_2479);
                      v_t_2480 = v_x_2478;
                    } else {
                      heff_drop(v_field_2466);
                      heff_drop(v_field_2467);
                      v_t_2480 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                    return ({ V a_0 = v_ru_24b1_2475_24Just; V a_1 = v_lb_2477; V a_2 = v_hb_2476; V a_3 = v_t_2480; V r_ = (g_heff_2ecompile_2eranges_2edivPositive_24tok1(a_0, a_1, a_2, a_3)); heff_drop(v_hb_2476); r_; });
                  } else {
                    heff_drop(v_field_2466);
                    heff_drop(v_field_2467);
                    heff_drop(v_hb_2476);
                    heff_drop(v_lb_2477);
                    heff_drop_cell(v_ru_24b1_2475_24Just, 1);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                }
                default: return heff_nomatch(v_b1_2475);
                }
              }
              default: return heff_nomatch(v_t_2474);
              }
            }
          }
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str4), 2)) {
            HeffT3 v_t_2481 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
            V v_t_2487;
            {
              V v_field_2483 = v_t_2481.f[1];
              V v_field_2484 = v_t_2481.f[2];
              int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
              if ((v_tag_2482 == ((int64_t)0ULL))) {
                V v_x_2485 = v_field_2483;
                V v_x12_2486 = v_field_2484;
                heff_drop(v_x12_2486);
                v_t_2487 = v_x_2485;
              } else {
                heff_drop(v_field_2483);
                heff_drop(v_field_2484);
                v_t_2487 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            HeffT3 v_t_2488 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
            V v_t_2494;
            {
              V v_field_2490 = v_t_2488.f[1];
              V v_field_2491 = v_t_2488.f[2];
              int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
              if ((v_tag_2489 == ((int64_t)0ULL))) {
                V v_x_2492 = v_field_2490;
                V v_x12_2493 = v_field_2491;
                heff_drop(v_x12_2493);
                v_t_2494 = v_x_2492;
              } else {
                heff_drop(v_field_2490);
                heff_drop(v_field_2491);
                v_t_2494 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            return ({ V a_0 = v_t_2487; V a_1 = v_t_2494; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_2487); r_; });
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str5), 2)) {
              HeffT3 v_t_2495 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
              V v_t_24101;
              {
                V v_field_2497 = v_t_2495.f[1];
                V v_field_2498 = v_t_2495.f[2];
                int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
                if ((v_tag_2496 == ((int64_t)0ULL))) {
                  V v_x_2499 = v_field_2497;
                  V v_x12_24100 = v_field_2498;
                  heff_drop(v_x12_24100);
                  v_t_24101 = v_x_2499;
                } else {
                  heff_drop(v_field_2497);
                  heff_drop(v_field_2498);
                  v_t_24101 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              HeffT3 v_t_24102 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
              V v_t_24108;
              {
                V v_field_24104 = v_t_24102.f[1];
                V v_field_24105 = v_t_24102.f[2];
                int64_t v_tag_24103 = ((int64_t)v_t_24102.f[0]);
                if ((v_tag_24103 == ((int64_t)0ULL))) {
                  V v_x_24106 = v_field_24104;
                  V v_x12_24107 = v_field_24105;
                  heff_drop(v_x12_24107);
                  v_t_24108 = v_x_24106;
                } else {
                  heff_drop(v_field_24104);
                  heff_drop(v_field_24105);
                  v_t_24108 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              HEFF_LAST return g_heff_2ecompile_2eranges_2eandR(v_t_24101, v_t_24108);
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str6), 2)) {
                HeffT3 v_t_24109 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                {
                  V v_field_24111 = v_t_24109.f[1];
                  V v_field_24112 = v_t_24109.f[2];
                  int64_t v_tag_24110 = ((int64_t)v_t_24109.f[0]);
                  HeffT3 v_t_24113 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                  {
                    V v_field_24115 = v_t_24113.f[1];
                    V v_field_24116 = v_t_24113.f[2];
                    int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
                    V v_t_24119;
                    if ((v_tag_24110 == ((int64_t)0ULL))) {
                      V v_x_24117 = v_field_24111;
                      V v_x12_24118 = v_field_24112;
                      heff_drop(v_x12_24118);
                      v_t_24119 = v_x_24117;
                    } else {
                      heff_drop(v_field_24111);
                      heff_drop(v_field_24112);
                      v_t_24119 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                    switch (heff_tag_of(v_t_24119)) {
                    case TAG_Unreached: {
                      heff_drop(v_field_24115);
                      heff_drop(v_field_24116);
                      return NTAG(TAG_Unreached);
                    }
                    case TAG_Within: {
                      V v_a_24120 = heff_field(v_t_24119, 0);
                      V v_b_24121 = heff_field(v_t_24119, 1);
                      V v_ru_24t_24119_24Within = heff_take_reuse_n(v_t_24119, 3ULL, 2);
                      V v_t_24124;
                      if ((v_tag_24114 == ((int64_t)0ULL))) {
                        V v_x_24122 = v_field_24115;
                        V v_x12_24123 = v_field_24116;
                        heff_drop(v_x12_24123);
                        v_t_24124 = v_x_24122;
                      } else {
                        heff_drop(v_field_24115);
                        heff_drop(v_field_24116);
                        v_t_24124 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                      switch (heff_tag_of(v_t_24124)) {
                      case TAG_Unreached: {
                        heff_drop(v_a_24120);
                        heff_drop(v_b_24121);
                        heff_drop_cell(v_ru_24t_24119_24Within, 2);
                        return NTAG(TAG_Unreached);
                      }
                      case TAG_Within: {
                        V v_c_24125 = heff_field(v_t_24124, 0);
                        V v_d_24126 = heff_field(v_t_24124, 1);
                        heff_take_n(v_t_24124, 3ULL, 2);
                        V v_t_24129;
                        switch (heff_tag_of(v_a_24120)) {
                        case TAG_Nothing: {
                          heff_drop(v_c_24125);
                          v_t_24129 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_a_24127 = heff_field(v_a_24120, 0);
                          V v_ru_24a_24120_24Just = heff_take_reuse_n(v_a_24120, 1ULL, 1);
                          switch (heff_tag_of(v_c_24125)) {
                          case TAG_Nothing: {
                            heff_drop(v_a_24127);
                            heff_drop_cell(v_ru_24a_24120_24Just, 1);
                            v_t_24129 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_b_24128 = heff_field(v_c_24125, 0);
                            heff_take_n(v_c_24125, 1ULL, 1);
                            v_t_24129 = heff_tag_at_n(v_ru_24a_24120_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24127, v_b_24128)});
                            break;
                          }
                          default: heff_nomatch(v_c_24125);
                          }
                          break;
                        }
                        default: heff_nomatch(v_a_24120);
                        }
                        V v_t_24132;
                        switch (heff_tag_of(v_b_24121)) {
                        case TAG_Nothing: {
                          heff_drop(v_d_24126);
                          v_t_24132 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_a_24130 = heff_field(v_b_24121, 0);
                          V v_ru_24b_24121_24Just = heff_take_reuse_n(v_b_24121, 1ULL, 1);
                          switch (heff_tag_of(v_d_24126)) {
                          case TAG_Nothing: {
                            heff_drop(v_a_24130);
                            heff_drop_cell(v_ru_24b_24121_24Just, 1);
                            v_t_24132 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_b_24131 = heff_field(v_d_24126, 0);
                            heff_take_n(v_d_24126, 1ULL, 1);
                            v_t_24132 = heff_tag_at_n(v_ru_24b_24121_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24130, v_b_24131)});
                            break;
                          }
                          default: heff_nomatch(v_d_24126);
                          }
                          break;
                        }
                        default: heff_nomatch(v_b_24121);
                        }
                        return heff_tag_at_n(v_ru_24t_24119_24Within, TAG_Within, 2, (V[]){v_t_24129, v_t_24132});
                      }
                      default: return heff_nomatch(v_t_24124);
                      }
                    }
                    default: return heff_nomatch(v_t_24119);
                    }
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str7), 2)) {
                  HeffT3 v_t_24133 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                  {
                    V v_field_24135 = v_t_24133.f[1];
                    V v_field_24136 = v_t_24133.f[2];
                    int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                    HeffT3 v_t_24137 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                    {
                      V v_field_24139 = v_t_24137.f[1];
                      V v_field_24140 = v_t_24137.f[2];
                      int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
                      V v_t_24143;
                      if ((v_tag_24134 == ((int64_t)0ULL))) {
                        V v_x_24141 = v_field_24135;
                        V v_x12_24142 = v_field_24136;
                        heff_drop(v_x12_24142);
                        v_t_24143 = v_x_24141;
                      } else {
                        heff_drop(v_field_24135);
                        heff_drop(v_field_24136);
                        v_t_24143 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                      switch (heff_tag_of(v_t_24143)) {
                      case TAG_Unreached: {
                        heff_drop(v_field_24139);
                        heff_drop(v_field_24140);
                        return NTAG(TAG_Unreached);
                      }
                      case TAG_Within: {
                        V v_a_24144 = heff_field(v_t_24143, 0);
                        V v_b_24145 = heff_field(v_t_24143, 1);
                        V v_ru_24t_24143_24Within = heff_take_reuse_n(v_t_24143, 3ULL, 2);
                        V v_t_24148;
                        if ((v_tag_24138 == ((int64_t)0ULL))) {
                          V v_x_24146 = v_field_24139;
                          V v_x12_24147 = v_field_24140;
                          heff_drop(v_x12_24147);
                          v_t_24148 = v_x_24146;
                        } else {
                          heff_drop(v_field_24139);
                          heff_drop(v_field_24140);
                          v_t_24148 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                        }
                        switch (heff_tag_of(v_t_24148)) {
                        case TAG_Unreached: {
                          heff_drop(v_a_24144);
                          heff_drop(v_b_24145);
                          heff_drop_cell(v_ru_24t_24143_24Within, 2);
                          return NTAG(TAG_Unreached);
                        }
                        case TAG_Within: {
                          V v_c_24149 = heff_field(v_t_24148, 0);
                          V v_d_24150 = heff_field(v_t_24148, 1);
                          heff_take_n(v_t_24148, 3ULL, 2);
                          V v_t_24153;
                          switch (heff_tag_of(v_a_24144)) {
                          case TAG_Nothing: {
                            heff_drop(v_d_24150);
                            v_t_24153 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_a_24151 = heff_field(v_a_24144, 0);
                            V v_ru_24a_24144_24Just = heff_take_reuse_n(v_a_24144, 1ULL, 1);
                            switch (heff_tag_of(v_d_24150)) {
                            case TAG_Nothing: {
                              heff_drop(v_a_24151);
                              heff_drop_cell(v_ru_24a_24144_24Just, 1);
                              v_t_24153 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_b_24152 = heff_field(v_d_24150, 0);
                              heff_take_n(v_d_24150, 1ULL, 1);
                              v_t_24153 = heff_tag_at_n(v_ru_24a_24144_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_24151, v_b_24152)});
                              break;
                            }
                            default: heff_nomatch(v_d_24150);
                            }
                            break;
                          }
                          default: heff_nomatch(v_a_24144);
                          }
                          V v_t_24156;
                          switch (heff_tag_of(v_b_24145)) {
                          case TAG_Nothing: {
                            heff_drop(v_c_24149);
                            v_t_24156 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_a_24154 = heff_field(v_b_24145, 0);
                            V v_ru_24b_24145_24Just = heff_take_reuse_n(v_b_24145, 1ULL, 1);
                            switch (heff_tag_of(v_c_24149)) {
                            case TAG_Nothing: {
                              heff_drop(v_a_24154);
                              heff_drop_cell(v_ru_24b_24145_24Just, 1);
                              v_t_24156 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_b_24155 = heff_field(v_c_24149, 0);
                              heff_take_n(v_c_24149, 1ULL, 1);
                              v_t_24156 = heff_tag_at_n(v_ru_24b_24145_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_24154, v_b_24155)});
                              break;
                            }
                            default: heff_nomatch(v_c_24149);
                            }
                            break;
                          }
                          default: heff_nomatch(v_b_24145);
                          }
                          return heff_tag_at_n(v_ru_24t_24143_24Within, TAG_Within, 2, (V[]){v_t_24153, v_t_24156});
                        }
                        default: return heff_nomatch(v_t_24148);
                        }
                      }
                      default: return heff_nomatch(v_t_24143);
                      }
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str8), 2)) {
                    HeffT3 v_t_24157 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                    V v_t_24163;
                    {
                      V v_field_24159 = v_t_24157.f[1];
                      V v_field_24160 = v_t_24157.f[2];
                      int64_t v_tag_24158 = ((int64_t)v_t_24157.f[0]);
                      if ((v_tag_24158 == ((int64_t)0ULL))) {
                        V v_x_24161 = v_field_24159;
                        V v_x12_24162 = v_field_24160;
                        heff_drop(v_x12_24162);
                        v_t_24163 = v_x_24161;
                      } else {
                        heff_drop(v_field_24159);
                        heff_drop(v_field_24160);
                        v_t_24163 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                    }
                    HeffT3 v_t_24164 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                    V v_t_24170;
                    {
                      V v_field_24166 = v_t_24164.f[1];
                      V v_field_24167 = v_t_24164.f[2];
                      int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
                      if ((v_tag_24165 == ((int64_t)0ULL))) {
                        V v_x_24168 = v_field_24166;
                        V v_x12_24169 = v_field_24167;
                        heff_drop(v_x12_24169);
                        v_t_24170 = v_x_24168;
                      } else {
                        heff_drop(v_field_24166);
                        heff_drop(v_field_24167);
                        v_t_24170 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                    }
                    HEFF_LAST return g_heff_2ecompile_2eranges_2emulR(v_t_24163, v_t_24170);
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str9), 2)) {
                      HeffT3 v_t_24171 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                      {
                        V v_field_24173 = v_t_24171.f[1];
                        V v_field_24174 = v_t_24171.f[2];
                        int64_t v_tag_24172 = ((int64_t)v_t_24171.f[0]);
                        HeffT3 v_t_24175 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                        {
                          V v_field_24177 = v_t_24175.f[1];
                          V v_field_24178 = v_t_24175.f[2];
                          int64_t v_tag_24176 = ((int64_t)v_t_24175.f[0]);
                          V v_t_24181;
                          if ((v_tag_24176 == ((int64_t)0ULL))) {
                            V v_x_24179 = v_field_24177;
                            V v_x12_24180 = v_field_24178;
                            heff_drop(v_x12_24180);
                            v_t_24181 = v_x_24179;
                          } else {
                            heff_drop(v_field_24177);
                            heff_drop(v_field_24178);
                            v_t_24181 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                          }
                          switch (heff_tag_of(v_t_24181)) {
                          case TAG_Unreached: {
                            heff_drop(v_field_24173);
                            heff_drop(v_field_24174);
                            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                          }
                          case TAG_Within: {
                            V v_b1_24182 = heff_field(v_t_24181, 0);
                            V v_hb_24183 = heff_field(v_t_24181, 1);
                            heff_take_n(v_t_24181, 3ULL, 2);
                            switch (heff_tag_of(v_b1_24182)) {
                            case TAG_Nothing: {
                              heff_drop(v_field_24173);
                              heff_drop(v_field_24174);
                              heff_drop(v_hb_24183);
                              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            case TAG_Just: {
                              V v_lb_24184 = heff_field(v_b1_24182, 0);
                              V v_ru_24b1_24182_24Just = heff_take_reuse_n(v_b1_24182, 1ULL, 1);
                              if (heff_intLt_c_lent(MK_INT(0LL), v_lb_24184, 1)) {
                                V v_t_24187;
                                if ((v_tag_24172 == ((int64_t)0ULL))) {
                                  V v_x_24185 = v_field_24173;
                                  V v_x12_24186 = v_field_24174;
                                  heff_drop(v_x12_24186);
                                  v_t_24187 = v_x_24185;
                                } else {
                                  heff_drop(v_field_24173);
                                  heff_drop(v_field_24174);
                                  v_t_24187 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                }
                                return ({ V a_0 = v_ru_24b1_24182_24Just; V a_1 = v_lb_24184; V a_2 = v_hb_24183; V a_3 = v_t_24187; V r_ = (g_heff_2ecompile_2eranges_2edivPositive_24tok1(a_0, a_1, a_2, a_3)); heff_drop(v_hb_24183); r_; });
                              } else {
                                heff_drop(v_field_24173);
                                heff_drop(v_field_24174);
                                heff_drop(v_hb_24183);
                                heff_drop(v_lb_24184);
                                heff_drop_cell(v_ru_24b1_24182_24Just, 1);
                                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            default: return heff_nomatch(v_b1_24182);
                            }
                          }
                          default: return heff_nomatch(v_t_24181);
                          }
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str10), 2)) {
                        HeffT3 v_t_24188 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                        {
                          V v_field_24190 = v_t_24188.f[1];
                          V v_field_24191 = v_t_24188.f[2];
                          int64_t v_tag_24189 = ((int64_t)v_t_24188.f[0]);
                          HeffT3 v_t_24192 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                          {
                            V v_field_24194 = v_t_24192.f[1];
                            V v_field_24195 = v_t_24192.f[2];
                            int64_t v_tag_24193 = ((int64_t)v_t_24192.f[0]);
                            V v_t_24198;
                            if ((v_tag_24193 == ((int64_t)0ULL))) {
                              V v_x_24196 = v_field_24194;
                              V v_x12_24197 = v_field_24195;
                              heff_drop(v_x12_24197);
                              v_t_24198 = v_x_24196;
                            } else {
                              heff_drop(v_field_24194);
                              heff_drop(v_field_24195);
                              v_t_24198 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            switch (heff_tag_of(v_t_24198)) {
                            case TAG_Unreached: {
                              heff_drop(v_field_24190);
                              heff_drop(v_field_24191);
                              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            case TAG_Within: {
                              V v_b1_24199 = heff_field(v_t_24198, 0);
                              V v_hb_24200 = heff_field(v_t_24198, 1);
                              heff_take_n(v_t_24198, 3ULL, 2);
                              switch (heff_tag_of(v_b1_24199)) {
                              case TAG_Nothing: {
                                heff_drop(v_field_24190);
                                heff_drop(v_field_24191);
                                heff_drop(v_hb_24200);
                                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                              case TAG_Just: {
                                V v_lb_24201 = heff_field(v_b1_24199, 0);
                                V v_ru_24b1_24199_24Just = heff_take_reuse_n(v_b1_24199, 1ULL, 1);
                                if (heff_intLt_c_lent(MK_INT(0LL), v_lb_24201, 1)) {
                                  V v_t_24204;
                                  if ((v_tag_24189 == ((int64_t)0ULL))) {
                                    V v_x_24202 = v_field_24190;
                                    V v_x12_24203 = v_field_24191;
                                    heff_drop(v_x12_24203);
                                    v_t_24204 = v_x_24202;
                                  } else {
                                    heff_drop(v_field_24190);
                                    heff_drop(v_field_24191);
                                    v_t_24204 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                  }
                                  return ({ V a_0 = v_ru_24b1_24199_24Just; V a_1 = v_lb_24201; V a_2 = v_hb_24200; V a_3 = v_t_24204; V r_ = (g_heff_2ecompile_2eranges_2edivPositive_24tok1(a_0, a_1, a_2, a_3)); heff_drop(v_hb_24200); r_; });
                                } else {
                                  heff_drop(v_field_24190);
                                  heff_drop(v_field_24191);
                                  heff_drop(v_hb_24200);
                                  heff_drop(v_lb_24201);
                                  heff_drop_cell(v_ru_24b1_24199_24Just, 1);
                                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                }
                              }
                              default: return heff_nomatch(v_b1_24199);
                              }
                            }
                            default: return heff_nomatch(v_t_24198);
                            }
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str11), 2)) {
                          HeffT3 v_t_24205 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                          V v_t_24211;
                          {
                            V v_field_24207 = v_t_24205.f[1];
                            V v_field_24208 = v_t_24205.f[2];
                            int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
                            if ((v_tag_24206 == ((int64_t)0ULL))) {
                              V v_x_24209 = v_field_24207;
                              V v_x12_24210 = v_field_24208;
                              heff_drop(v_x12_24210);
                              v_t_24211 = v_x_24209;
                            } else {
                              heff_drop(v_field_24207);
                              heff_drop(v_field_24208);
                              v_t_24211 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                          }
                          HeffT3 v_t_24212 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                          V v_t_24218;
                          {
                            V v_field_24214 = v_t_24212.f[1];
                            V v_field_24215 = v_t_24212.f[2];
                            int64_t v_tag_24213 = ((int64_t)v_t_24212.f[0]);
                            if ((v_tag_24213 == ((int64_t)0ULL))) {
                              V v_x_24216 = v_field_24214;
                              V v_x12_24217 = v_field_24215;
                              heff_drop(v_x12_24217);
                              v_t_24218 = v_x_24216;
                            } else {
                              heff_drop(v_field_24214);
                              heff_drop(v_field_24215);
                              v_t_24218 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                          }
                          return ({ V a_0 = v_t_24211; V a_1 = v_t_24218; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_24211); r_; });
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str12), 2)) {
                            HeffT3 v_t_24219 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                            V v_t_24225;
                            {
                              V v_field_24221 = v_t_24219.f[1];
                              V v_field_24222 = v_t_24219.f[2];
                              int64_t v_tag_24220 = ((int64_t)v_t_24219.f[0]);
                              if ((v_tag_24220 == ((int64_t)0ULL))) {
                                V v_x_24223 = v_field_24221;
                                V v_x12_24224 = v_field_24222;
                                heff_drop(v_x12_24224);
                                v_t_24225 = v_x_24223;
                              } else {
                                heff_drop(v_field_24221);
                                heff_drop(v_field_24222);
                                v_t_24225 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            HeffT3 v_t_24226 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                            V v_t_24232;
                            {
                              V v_field_24228 = v_t_24226.f[1];
                              V v_field_24229 = v_t_24226.f[2];
                              int64_t v_tag_24227 = ((int64_t)v_t_24226.f[0]);
                              if ((v_tag_24227 == ((int64_t)0ULL))) {
                                V v_x_24230 = v_field_24228;
                                V v_x12_24231 = v_field_24229;
                                heff_drop(v_x12_24231);
                                v_t_24232 = v_x_24230;
                              } else {
                                heff_drop(v_field_24228);
                                heff_drop(v_field_24229);
                                v_t_24232 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            return ({ V a_0 = v_t_24225; V a_1 = v_t_24232; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_24225); r_; });
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str13), 2)) {
                              return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str14), 2)) {
                                return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str15), 2)) {
                                  return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str16), 2)) {
                                    return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(-1LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(255LL)})});
                                  } else {
                                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2eprimRange(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2enonZero_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enonZero_entry, 1, 0};

V g_heff_2ecompile_2eranges_2enonZero(V v_r_240) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    switch (heff_tag_of(v_r_240)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_hi_242 = heff_field(v_r_240, 1);
      switch (heff_tag_of(v_hi_242)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_a_243 = heff_field(v_hi_242, 0);
        V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_a_243, MK_INT(0LL), 2));
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_hi_242);
      }
    }
    default: return heff_nomatch(v_r_240);
    }
  }
  case TAG_Within: {
    V v_lo_244 = heff_field(v_r_240, 0);
    switch (heff_tag_of(v_lo_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_r_240)) {
      case TAG_Unreached: {
        return NTAG(TAG_False);
      }
      case TAG_Within: {
        V v_hi_247 = heff_field(v_r_240, 1);
        switch (heff_tag_of(v_hi_247)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_a_248 = heff_field(v_hi_247, 0);
          V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_a_248, MK_INT(0LL), 2));
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_hi_247);
        }
      }
      default: return heff_nomatch(v_r_240);
      }
    }
    case TAG_Just: {
      V v_a_249 = heff_field(v_lo_244, 0);
      if (heff_intLt_c_lent(MK_INT(0LL), v_a_249, 1)) {
        return NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_r_240)) {
        case TAG_Unreached: {
          return NTAG(TAG_False);
        }
        case TAG_Within: {
          V v_hi_2411 = heff_field(v_r_240, 1);
          switch (heff_tag_of(v_hi_2411)) {
          case TAG_Nothing: {
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            V v_a_2412 = heff_field(v_hi_2411, 0);
            V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_a_2412, MK_INT(0LL), 2));
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_hi_2411);
          }
        }
        default: return heff_nomatch(v_r_240);
        }
      }
    }
    default: return heff_nomatch(v_lo_244);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2enonZero(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2enatural_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enatural_entry, 1, 0};

V g_heff_2ecompile_2eranges_2enatural(V v_rs_240) {
top: ;
  HeffT3 v_t_241 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    V v_t_247;
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_243;
      V v_x12_246 = v_field_244;
      heff_drop(v_x12_246);
      v_t_247 = v_x_245;
    } else {
      heff_drop(v_field_243);
      heff_drop(v_field_244);
      v_t_247 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_lo_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 2);
      switch (heff_tag_of(v_lo_248)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_lo_248, 0);
        heff_take_n(v_lo_248, 1ULL, 1);
        if (heff_intLe_c(MK_INT(0LL), v_a_2410)) {
          HeffT3 v_t_2411 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_240));
          {
            V v_field_2413 = v_t_2411.f[1];
            V v_field_2414 = v_t_2411.f[2];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            V v_t_2417;
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x_2415 = v_field_2413;
              V v_x12_2416 = v_field_2414;
              heff_drop(v_x12_2416);
              v_t_2417 = v_x_2415;
            } else {
              heff_drop(v_field_2413);
              heff_drop(v_field_2414);
              v_t_2417 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            switch (heff_tag_of(v_t_2417)) {
            case TAG_Unreached: {
              return NTAG(TAG_False);
            }
            case TAG_Within: {
              V v_lo_2418 = heff_field(v_t_2417, 0);
              heff_take_n(v_t_2417, 1ULL, 2);
              switch (heff_tag_of(v_lo_2418)) {
              case TAG_Nothing: {
                return NTAG(TAG_False);
              }
              case TAG_Just: {
                V v_a_2420 = heff_field(v_lo_2418, 0);
                heff_take_n(v_lo_2418, 1ULL, 1);
                V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_a_2420, 1));
                heff_drop(v_a_2420);
                return v_ret_24bool;
              }
              default: return heff_nomatch(v_lo_2418);
              }
            }
            default: return heff_nomatch(v_t_2417);
            }
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_lo_248);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2enatural(a0); heff_drop(a0); return r;
}

static V g_heff_2ecompile_2eranges_2eemptyEnv_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptyEnv_st;
static V g_heff_2ecompile_2eranges_2eemptyEnv_init(void) {
  return heff_rec_n(2, shape_ranges__tests, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptyEnv_st)) return g_heff_2ecompile_2eranges_2eemptyEnv_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptyEnv_val, &g_heff_2ecompile_2eranges_2eemptyEnv_st, g_heff_2ecompile_2eranges_2eemptyEnv_init);
}
Clo g_heff_2ecompile_2eranges_2ewithTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewithTest_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewithTest(V v_env_240, V v_x_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EApp: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ELet: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ETag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_242, 0);
    V v_e2_2425 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e2_2425)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop(v_p_2424);
      return v_env_240;
    }
    case TAG_Cons: {
      V v_a_2426 = heff_field(v_e2_2425, 0);
      V v_e22_2427 = heff_field(v_e2_2425, 1);
      heff_take_n(v_e2_2425, 3ULL, 2);
      switch (heff_tag_of(v_e22_2427)) {
      case TAG_Nil: {
        heff_drop(v_x_241);
        heff_drop(v_p_2424);
        heff_drop(v_a_2426);
        return v_env_240;
      }
      case TAG_Cons: {
        V v_b_2428 = heff_field(v_e22_2427, 0);
        V v_e222_2429 = heff_field(v_e22_2427, 1);
        heff_take_n(v_e22_2427, 3ULL, 2);
        switch (heff_tag_of(v_e222_2429)) {
        case TAG_Nil: {
          V v_t_2430 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_2424)));
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop(v_t_2430);
            V v_t_2431 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 1), v_x_241, heff_tag_n(TAG_MkTest, 3, (V[]){v_p_2424, v_a_2426, v_b_2428})));
            return ({ V rv_1 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_env_240, 1ULL, 2, shape_ranges__tests, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          } else {
            heff_drop(v_x_241);
            heff_drop(v_p_2424);
            heff_drop(v_a_2426);
            heff_drop(v_b_2428);
            heff_drop(v_t_2430);
            return v_env_240;
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2429, 0ULL, 2);
          heff_drop(v_x_241);
          heff_drop(v_p_2424);
          heff_drop(v_a_2426);
          heff_drop(v_b_2428);
          return v_env_240;
        }
        default: return heff_nomatch(v_e222_2429);
        }
      }
      default: return heff_nomatch(v_e22_2427);
      }
    }
    default: return heff_nomatch(v_e2_2425);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EBool: {
    V v_e1_2443 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    switch (heff_tag_of(v_e1_2443)) {
    case TAG_CTrue: {
      heff_drop(v_x_241);
      return v_env_240;
    }
    case TAG_CFalse: {
      heff_drop(v_x_241);
      return v_env_240;
    }
    case TAG_CRel: {
      V v_p_2444 = heff_field(v_e1_2443, 0);
      V v_a_2445 = heff_field(v_e1_2443, 1);
      V v_b_2446 = heff_field(v_e1_2443, 2);
      heff_take_n(v_e1_2443, 7ULL, 3);
      V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2446, NTAG(TAG_Nil)});
      V v_t_2448 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2445, v_t_2447})});
      V t_0 = v_env_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2448;
      v_env_240 = t_0;
      v_x_241 = t_1;
      v_e_242 = t_2;
      goto top;
    }
    case TAG_CTest: {
      heff_take_n(v_e1_2443, 0ULL, 1);
      heff_drop(v_x_241);
      return v_env_240;
    }
    case TAG_CNot: {
      heff_take_n(v_e1_2443, 0ULL, 1);
      heff_drop(v_x_241);
      return v_env_240;
    }
    case TAG_CIf: {
      heff_take_n(v_e1_2443, 0ULL, 3);
      heff_drop(v_x_241);
      return v_env_240;
    }
    default: return heff_nomatch(v_e1_2443);
    }
  }
  case TAG_ESet: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EValues: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_x_241);
    return v_env_240;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewithTest(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_str1, 5, "False");
V g_heff_2ecompile_2eranges_2egatherArms_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2egatherArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherArms_entry, 6, 0};

V g_heff_2ecompile_2eranges_2egatherArms(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_st_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){NTAG(TAG_Unreached), v_st_244});
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkArm: {
      V v_tag_248 = heff_field(v_x61_246, 0);
      V v_b_2410 = heff_field(v_x61_246, 2);
      V v_t_2412;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        v_t_2412 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_k_2411 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_str0), 2)) {
          v_t_2412 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), heff_dup(v_k_2411), NTAG(TAG_True)));
        } else {
          if (heff_strEq_c_lent(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_str1), 2)) {
            v_t_2412 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), heff_dup(v_k_2411), NTAG(TAG_False)));
          } else {
            v_t_2412 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_t_2413 = heff_tr(heff_call(heff_dup(v_go_241), 3, (V[]){v_t_2412, v_st_244, heff_dup(v_b_2410)}));
      return (g_heff_2ecompile_2eranges_2earmSeen(v_t_2413, heff_clo_n(g_heff_2ecompile_2eranges_2egatherArms_lam0, 1, 5, (V[]){v_c_240, v_go_241, v_env_242, heff_dup(v_t_243), heff_dup(v_rest_247)})));
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eranges_2egatherArms_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ecompile_2eranges_2egatherArms(a[0], a[1], a[2], a3, a[4], a5); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eranges_2egatherArms_lam0(V self, V *args) {
  V v_st1_2414 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_go_241 = heff_env(self)[1];
  V v_env_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_c_240; V a_1 = v_go_241; V a_2 = v_env_242; V a_3 = v_t_243; V a_4 = v_st1_2414; V a_5 = v_rest_247; V r_ = (g_heff_2ecompile_2eranges_2egatherArms(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_243); heff_drop(v_rest_247); r_; });
}
V g_heff_2ecompile_2eranges_2egatherGo_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2egatherGo_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2egatherGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eranges_2egatherGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherGo_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egatherGo(V v_c_240, V v_env_241, V v_st_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_244); r_; });
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return heff_tag_n(TAG_MkSeen, 2, (V[]){v_t_249, v_st_242});
  }
  case TAG_EGlobal: {
    V v_g_2410 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EGlobal = heff_take_reuse_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_2410); r_; });
    V v_t_2415;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        v_t_2415 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EGlobal, TAG_Just, 1, (V[]){heff_dup(v_x_2414)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2414})});
      } else {
        heff_drop_cell(v_ru_24e_243_24EGlobal, 1);
        heff_drop(v_field_2413);
        v_t_2415 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return heff_tag_n(TAG_MkSeen, 2, (V[]){v_t_2415, v_st_242});
  }
  case TAG_ELam: {
    V v_b_2417 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 2ULL, 2);
    V v_x1_2418 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, v_env_241, v_st_242, v_b_2417));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_MkSeen: {
      V v_st_2420 = heff_field(v_x1_2418, 1);
      heff_take_n(v_x1_2418, 2ULL, 2);
      return heff_tag_at_n(v_ru_24e_243_24ELam, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2420});
    }
    case TAG_MkSeenVals: {
      V v_st_2422 = heff_field(v_x1_2418, 1);
      heff_take_n(v_x1_2418, 2ULL, 2);
      return heff_tag_at_n(v_ru_24e_243_24ELam, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2422});
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2423 = heff_field(v_e_243, 0);
    V v_args_2424 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2426 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2425, v_env_241, v_st_242, heff_tag_at_n(v_ru_24e_243_24EApp, TAG_Cons, 2, (V[]){v_f_2423, v_args_2424})));
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_rs_2429 = v_field_2427;
      heff_drop(v_rs_2429);
      V v_st_2430 = v_field_2428;
      return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2430});
    }
  }
  case TAG_ELet: {
    V v_x_2431 = heff_field(v_e_243, 0);
    V v_a_2432 = heff_field(v_e_243, 1);
    V v_b_2433 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_x1_2434 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(heff_dup(v_c_240), heff_dup(v_env_241), v_st_242, heff_dup(v_a_2432)));
    V v_k_2439 = heff_clo_n(g_heff_2ecompile_2eranges_2egatherGo_lam0, 2, 5, (V[]){v_env_241, v_x_2431, v_a_2432, v_c_240, v_b_2433});
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_MkSeen: {
      V v_r_2440 = heff_field(v_x1_2434, 0);
      V v_st_2441 = heff_field(v_x1_2434, 1);
      heff_take_n(v_x1_2434, 3ULL, 2);
      return heff_tail(v_k_2439, 2, (V[]){v_r_2440, v_st_2441});
    }
    case TAG_MkSeenVals: {
      V v_st_2443 = heff_field(v_x1_2434, 1);
      heff_take_n(v_x1_2434, 2ULL, 2);
      return heff_tail(v_k_2439, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2443});
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  case TAG_ERecord: {
    V v_fs_2444 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 1ULL, 2);
    V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    V v_t_2447 = (g_list_2emap_24s1173914895x100384474(v_fs_2444));
    HeffT2 v_t_2448 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2446, v_env_241, v_st_242, v_t_2447));
    {
      V v_field_2449 = v_t_2448.f[0];
      V v_field_2450 = v_t_2448.f[1];
      V v_rs_2451 = v_field_2449;
      heff_drop(v_rs_2451);
      V v_st_2452 = v_field_2450;
      return heff_tag_at_n(v_ru_24e_243_24ERecord, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2452});
    }
  }
  case TAG_EProj: {
    V v_a_2453 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 4);
    V v_x1_2457 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(v_c_240, v_env_241, v_st_242, v_a_2453));
    switch (heff_tag_of(v_x1_2457)) {
    case TAG_MkSeen: {
      V v_st_2459 = heff_field(v_x1_2457, 1);
      V v_ru_24x1_2457_24MkSeen = heff_take_reuse_n(v_x1_2457, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2457_24MkSeen, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2459});
    }
    case TAG_MkSeenVals: {
      V v_st_2461 = heff_field(v_x1_2457, 1);
      V v_ru_24x1_2457_24MkSeenVals = heff_take_reuse_n(v_x1_2457, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2457_24MkSeenVals, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2461});
    }
    default: return heff_nomatch(v_x1_2457);
    }
  }
  case TAG_ETag: {
    V v_args_2463 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 3);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2466 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2465, v_env_241, v_st_242, v_args_2463));
    {
      V v_field_2467 = v_t_2466.f[0];
      V v_field_2468 = v_t_2466.f[1];
      V v_rs_2469 = v_field_2467;
      heff_drop(v_rs_2469);
      V v_st_2470 = v_field_2468;
      return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2470});
    }
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_e_243, 0);
    V v_arms_2472 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_x1_2473 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(heff_dup(v_c_240), heff_dup(v_env_241), v_st_242, heff_dup(v_s_2471)));
    V v_k_2480 = heff_clo_n(g_heff_2ecompile_2eranges_2egatherGo_lam1, 2, 4, (V[]){v_c_240, v_env_241, v_s_2471, v_arms_2472});
    switch (heff_tag_of(v_x1_2473)) {
    case TAG_MkSeen: {
      V v_r_2481 = heff_field(v_x1_2473, 0);
      V v_st_2482 = heff_field(v_x1_2473, 1);
      heff_take_n(v_x1_2473, 3ULL, 2);
      return heff_tail(v_k_2480, 2, (V[]){v_r_2481, v_st_2482});
    }
    case TAG_MkSeenVals: {
      V v_st_2484 = heff_field(v_x1_2473, 1);
      heff_take_n(v_x1_2473, 2ULL, 2);
      return heff_tail(v_k_2480, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2484});
    }
    default: return heff_nomatch(v_x1_2473);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EPrimCall: {
    V v_p_2486 = heff_field(v_e_243, 0);
    V v_args_2487 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2489 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2488, v_env_241, v_st_242, v_args_2487));
    {
      V v_field_2490 = v_t_2489.f[0];
      V v_field_2491 = v_t_2489.f[1];
      V v_rs_2492 = v_field_2490;
      V v_st_2493 = v_field_2491;
      V v_t_2494 = ({ V a_0 = v_p_2486; V a_1 = v_rs_2492; V r_ = (g_heff_2ecompile_2eranges_2eprimRange(a_0, a_1)); heff_drop(v_p_2486); heff_drop(v_rs_2492); r_; });
      return heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_MkSeen, 2, (V[]){v_t_2494, v_st_2493});
    }
  }
  case TAG_ECall: {
    V v_g_2495 = heff_field(v_e_243, 0);
    V v_args_2496 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    HeffT2 v_t_2498 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_2497, v_env_241, v_st_242, v_args_2496));
    {
      V v_field_2499 = v_t_2498.f[0];
      V v_field_24100 = v_t_2498.f[1];
      V v_rs_24101 = v_field_2499;
      V v_st_24102 = v_field_24100;
      V v_t_24103 = (g_heff_2ecompile_2eranges_2ecalledIn(v_c_240, v_g_2495, v_rs_24101, v_st_24102));
      return heff_tag_at_n(v_ru_24e_243_24ECall, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_24103});
    }
  }
  case TAG_EInt: {
    V v_n_24104 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EInt = heff_take_reuse_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    V v_t_24105 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24EInt, TAG_Just, 1, (V[]){heff_dup(v_n_24104)}), heff_tag_n(TAG_Just, 1, (V[]){v_n_24104})});
    return heff_tag_n(TAG_MkSeen, 2, (V[]){v_t_24105, v_st_242});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EStr: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EFixed: {
    V v_ru_24e_243_24EFixed = heff_take_reuse_n(v_e_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_at_n(v_ru_24e_243_24EFixed, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkSeen, 2, (V[]){NTAG(TAG_Unreached), v_st_242});
  }
  case TAG_EBool: {
    V v_k_24112 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_24113 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    V v_t_24114 = (g_heff_2ecompile_2eranges_2egatherCond(v_c_240, v_t_24113, v_env_241, v_st_242, v_k_24112));
    return heff_tag_n(TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_24114});
  }
  case TAG_ESet: {
    V v_xs_24115 = heff_field(v_e_243, 0);
    V v_a_24116 = heff_field(v_e_243, 1);
    V v_b_24117 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_x1_24118 = heff_tr(g_heff_2ecompile_2eranges_2egatherGo(heff_dup(v_c_240), heff_dup(v_env_241), v_st_242, v_a_24116));
    V v_k_24123 = heff_clo_n(g_heff_2ecompile_2eranges_2egatherGo_lam2, 2, 4, (V[]){v_xs_24115, v_env_241, v_c_240, v_b_24117});
    switch (heff_tag_of(v_x1_24118)) {
    case TAG_MkSeen: {
      V v_st_24125 = heff_field(v_x1_24118, 1);
      heff_take_n(v_x1_24118, 2ULL, 2);
      return heff_tail(v_k_24123, 2, (V[]){NTAG(TAG_Nil), v_st_24125});
    }
    case TAG_MkSeenVals: {
      V v_rs_24126 = heff_field(v_x1_24118, 0);
      V v_st_24127 = heff_field(v_x1_24118, 1);
      heff_take_n(v_x1_24118, 3ULL, 2);
      return heff_tail(v_k_24123, 2, (V[]){v_rs_24126, v_st_24127});
    }
    default: return heff_nomatch(v_x1_24118);
    }
  }
  case TAG_EValues: {
    V v_es_24128 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_24130 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_t_24129, v_env_241, v_st_242, v_es_24128));
    {
      V v_field_24131 = v_t_24130.f[0];
      V v_field_24132 = v_t_24130.f[1];
      V v_rs_24133 = v_field_24131;
      V v_st_24134 = v_field_24132;
      return heff_tag_n(TAG_MkSeenVals, 2, (V[]){v_rs_24133, v_st_24134});
    }
  }
  case TAG_EFix: {
    V v_ru_24e_243_24EFix = heff_take_reuse_n(v_e_243, 0ULL, 2);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return heff_tag_at_n(v_ru_24e_243_24EFix, TAG_MkSeen, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_242});
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egatherGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2egatherGo_lam0(V self, V *args) {
  V v_ra_2435 = args[0];
  V v_st1_2436 = args[1];
  V v_env_241 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  V v_a_2432 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_b_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, heff_dup(v_x_2431), v_ra_2435));
  V v_t_2438 = (g_heff_2ecompile_2eranges_2ewithTest(v_t_2437, v_x_2431, v_a_2432));
  return (g_heff_2ecompile_2eranges_2egatherGo(v_c_240, v_t_2438, v_st1_2436, v_b_2433));
}
V g_heff_2ecompile_2eranges_2egatherGo_lam1(V self, V *args) {
  V v_x_2474 = args[0];
  V v_st1_2475 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_s_2471 = heff_env(self)[2];
  V v_arms_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2474);
  V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2egatherGo_clo), 1, (V[]){heff_dup(v_c_240)}));
  V v_t_2477 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), heff_dup(v_s_2471)));
  V v_t_2478 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), v_s_2471));
  V v_t_2479 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_env_241); V a_2 = v_t_2478; V a_3 = v_st1_2475; V r_ = (g_heff_2ecompile_2eranges_2emarked(a_0, a_1, a_2, a_3)); heff_drop(v_t_2478); r_; });
  return ({ V a_0 = v_c_240; V a_1 = v_t_2476; V a_2 = v_env_241; V a_3 = v_t_2477; V a_4 = v_t_2479; V a_5 = v_arms_2472; V r_ = (g_heff_2ecompile_2eranges_2egatherArms(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2477); heff_drop(v_arms_2472); r_; });
}
V g_heff_2ecompile_2eranges_2egatherGo_lam2(V self, V *args) {
  V v_rs_24119 = args[0];
  V v_st1_24120 = args[1];
  V v_xs_24115 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_b_24117 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24121 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_24115, v_rs_24119));
  V v_t_24122 = ({ V a_0 = v_env_241; V a_1 = v_t_24121; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_24121); r_; });
  return (g_heff_2ecompile_2eranges_2egatherGo(v_c_240, v_t_24122, v_st1_24120, v_b_24117));
}
Clo g_heff_2ecompile_2eranges_2ewalkCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkCond_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ewalkCond(V v_c_240, V v_go_241, V v_env_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_CTrue: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return v_x4_243;
  }
  case TAG_CFalse: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return v_x4_243;
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_a_245 = heff_field(v_x4_243, 1);
    V v_b_246 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CRel = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_240);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_246), NTAG(TAG_Nil)});
    HeffT2 v_t_248 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_go_241, v_env_242, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), v_t_247})));
    V v_t_2425;
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_rs_2411 = v_field_249;
      V v_es_2412 = v_field_2410;
      switch (heff_tag_of(v_es_2412)) {
      case TAG_Nil: {
        heff_drop(v_rs_2411);
        v_t_2425 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_244, v_a_245, v_b_246})});
        break;
      }
      case TAG_Cons: {
        V v_a2_2413 = heff_field(v_es_2412, 0);
        V v_it2_2414 = heff_field(v_es_2412, 1);
        heff_take_n(v_es_2412, 3ULL, 2);
        switch (heff_tag_of(v_it2_2414)) {
        case TAG_Nil: {
          heff_drop(v_rs_2411);
          heff_drop(v_a2_2413);
          v_t_2425 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_244, v_a_245, v_b_246})});
          break;
        }
        case TAG_Cons: {
          V v_b2_2415 = heff_field(v_it2_2414, 0);
          V v_it22_2416 = heff_field(v_it2_2414, 1);
          heff_take_n(v_it2_2414, 3ULL, 2);
          switch (heff_tag_of(v_it22_2416)) {
          case TAG_Nil: {
            heff_drop(v_a_245);
            heff_drop(v_b_246);
            HeffT2 v_t_2417 = ({ V a_0 = v_p_244; V a_1 = v_rs_2411; V a_2 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()); HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewordOf_24cpr(a_0, a_1, a_2)); heff_drop(v_rs_2411); r_; });
            V v_t_2421;
            {
              V v_field_2419 = v_t_2417.f[1];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                heff_drop(v_p_244);
                V v_x_2420 = v_field_2419;
                v_t_2421 = v_x_2420;
              } else {
                heff_drop(v_field_2419);
                v_t_2421 = v_p_244;
              }
            }
            V v_t_2422 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_t_2421, v_a2_2413, v_b2_2415})});
            v_t_2425 = v_t_2422;
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_2416, 0ULL, 2);
            heff_drop(v_rs_2411);
            heff_drop(v_a2_2413);
            heff_drop(v_b2_2415);
            v_t_2425 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_244, v_a_245, v_b_246})});
            break;
          }
          default: heff_nomatch(v_it22_2416);
          }
          break;
        }
        default: heff_nomatch(v_it2_2414);
        }
        break;
      }
      default: heff_nomatch(v_es_2412);
      }
    }
    return (g_heff_2ecompile_2eir_2econdOf(v_t_2425));
  }
  case TAG_CTest: {
    V v_e_2426 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CTest = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_240);
    V v_x1_2427 = heff_tr(heff_call(v_go_241, 2, (V[]){v_env_242, v_e_2426}));
    V v_t_2432;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_MkRes: {
      V v_e_2429 = heff_field(v_x1_2427, 1);
      heff_take_n(v_x1_2427, 2ULL, 2);
      v_t_2432 = v_e_2429;
      break;
    }
    case TAG_MkResVals: {
      V v_e_2431 = heff_field(v_x1_2427, 1);
      heff_take_n(v_x1_2427, 2ULL, 2);
      v_t_2432 = v_e_2431;
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    return heff_tag_at_n(v_ru_24x4_243_24CTest, TAG_CTest, 1, (V[]){v_t_2432});
  }
  case TAG_CNot: {
    V v_k_2433 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CNot = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_cell_2434 = heff_tag_at_n(v_ru_24x4_243_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2435 = (g_heff_2ecompile_2eranges_2ewalkCond_24dps(v_c_240, v_go_241, v_env_242, v_k_2433, heff_dup(v_cell_2434), MK_INT(0LL)));
    heff_drop(v_u_2435);
    return v_cell_2434;
  }
  case TAG_CIf: {
    V v_a_2436 = heff_field(v_x4_243, 0);
    V v_b_2437 = heff_field(v_x4_243, 1);
    V v_k_2438 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2439 = (g_heff_2ecompile_2eranges_2ewalkCond(heff_dup(v_c_240), heff_dup(v_go_241), heff_dup(v_env_242), heff_dup(v_a_2436)));
    V v_t_2440 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), heff_dup(v_a_2436), NTAG(TAG_True)));
    V v_t_2441 = (g_heff_2ecompile_2eranges_2ewalkCond(heff_dup(v_c_240), heff_dup(v_go_241), v_t_2440, v_b_2437));
    V v_cell_2442 = heff_tag_at_n(v_ru_24x4_243_24CIf, TAG_CIf, 3, (V[]){v_t_2439, v_t_2441, heff_hole()});
    V v_t_2443 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), v_env_242, v_a_2436, NTAG(TAG_False)));
    V v_u_2444 = (g_heff_2ecompile_2eranges_2ewalkCond_24dps(v_c_240, v_go_241, v_t_2443, v_k_2438, heff_dup(v_cell_2442), MK_INT(2LL)));
    heff_drop(v_u_2444);
    return v_cell_2442;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2ewalkCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewalkCond(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 2);
    V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_t_248));
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2ewidenHigh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewidenHigh_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewidenHigh(V v_x1_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Nothing: {
      return v_x3_242;
    }
    case TAG_Just: {
      V v_b_243 = heff_field(v_b_241, 0);
      heff_take_n(v_b_241, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nothing: {
        heff_drop(v_b_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_d_244 = heff_dup(heff_field(v_x3_242, 0));
        if (heff_intLt_c(v_b_243, v_d_244)) {
          heff_drop_tag(v_x3_242, 1);
          return NTAG(TAG_Nothing);
        } else {
          return v_x3_242;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_Just: {
    V v_ms_245 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_ms_245);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      switch (heff_tag_of(v_b_241)) {
      case TAG_Nothing: {
        return v_x3_242;
      }
      case TAG_Just: {
        V v_b_246 = heff_field(v_b_241, 0);
        heff_take_n(v_b_241, 1ULL, 1);
        switch (heff_tag_of(v_x3_242)) {
        case TAG_Nothing: {
          heff_drop(v_b_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_d_247 = heff_dup(heff_field(v_x3_242, 0));
          if (heff_intLt_c(v_b_246, v_d_247)) {
            heff_drop_tag(v_x3_242, 1);
            return NTAG(TAG_Nothing);
          } else {
            return v_x3_242;
          }
        }
        default: return heff_nomatch(v_x3_242);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_Just: {
      V v_d_248 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      switch (heff_tag_of(v_b_241)) {
      case TAG_Nothing: {
        heff_drop(v_ms_245);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_d_248});
      }
      case TAG_Just: {
        V v_b_249 = heff_field(v_b_241, 0);
        heff_take_n(v_b_241, 1ULL, 1);
        if (heff_intLt_c_lent(v_b_249, v_d_248, 1)) {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          V v_t_2410 = ({ V a_0 = v_ms_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_ms_245); r_; });
          return ({ V a_0 = v_d_248; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2410; V r_ = (g_list_2efoldl_24s92926977x826280221(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
        } else {
          heff_drop(v_ms_245);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_d_248});
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ewidenHigh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewidenHigh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2ewiden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewiden_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewiden(V v_ms_240, V v_o_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_Unreached: {
    heff_drop(v_ms_240);
    return v_n_242;
  }
  case TAG_Within: {
    V v_a_243 = heff_field(v_o_241, 0);
    V v_b_244 = heff_field(v_o_241, 1);
    V v_ru_24o_241_24Within = heff_take_reuse_n(v_o_241, 3ULL, 2);
    switch (heff_tag_of(v_n_242)) {
    case TAG_Unreached: {
      heff_drop(v_ms_240);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24o_241_24Within, 2);
      return v_n_242;
    }
    case TAG_Within: {
      V v_c_245 = heff_field(v_n_242, 0);
      V v_d_246 = heff_field(v_n_242, 1);
      heff_take_n(v_n_242, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eranges_2ewidenLow(heff_dup(v_ms_240), v_a_243, v_c_245));
      V v_t_248 = (g_heff_2ecompile_2eranges_2ewidenHigh(v_ms_240, v_b_244, v_d_246));
      return heff_tag_at_n(v_ru_24o_241_24Within, TAG_Within, 2, (V[]){v_t_247, v_t_248});
    }
    default: return heff_nomatch(v_n_242);
    }
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eranges_2ewiden_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewiden(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str0, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str1, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str2, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str3, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str4, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str5, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str6, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str7, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str8, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str9, 6, "intAdd");

static V g_heff_2ecompile_2eranges_2eintOps_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eintOps_st;
static V g_heff_2ecompile_2eranges_2eintOps_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str9), v_t_244});
}
V g_heff_2ecompile_2eranges_2eintOps_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eintOps_st)) return g_heff_2ecompile_2eranges_2eintOps_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eintOps_val, &g_heff_2ecompile_2eranges_2eintOps_st, g_heff_2ecompile_2eranges_2eintOps_init);
}
Clo g_heff_2ecompile_2eranges_2enamesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enamesW_entry, 2, 0};

V g_heff_2ecompile_2eranges_2enamesW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_245 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_x_244, NTAG(TAG_MkUnit)));
      V t_0 = v_t_245;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2416, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2427, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2428;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2enamesW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2egivenFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egivenFrom_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egivenFrom(V v_g_240, V v_i_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_args_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_g_240), heff_dup(v_i_241)}), v_x_246});
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      heff_take_n(v_x41_244, 0ULL, 4);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBool: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ESet: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EValues: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egivenFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2eroundOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2eroundOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eroundOf_entry, 4, 0};

V g_heff_2ecompile_2eranges_2eroundOf(V v_consts_240, V v_sc_241, V v_s0_242, V v_keys_243) {
top: ;
  V v_fix_244 = heff_take_field(v_s0_242, 0);
  V v_gathered_245 = heff_get_n(v_s0_242, 2, 3);
  V v_byKey_246 = heff_take_field(v_sc_241, 0);
  V v_callers_247 = heff_get_n(v_sc_241, 1, 4);
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2eroundOf_lam0, 2, 3, (V[]){v_byKey_246, v_callers_247, v_consts_240}), heff_rec_n(3, shape_fix__dirty__gathered, (V[]){v_fix_244, heff_dup(g_std_2emap_2eempty_get()), v_gathered_245}), v_keys_243));
}
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2eroundOf(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2eroundOf_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_k_249 = args[1];
  V v_byKey_246 = heff_env(self)[0];
  V v_callers_247 = heff_env(self)[1];
  V v_consts_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = ({ V a_0 = v_byKey_246; V a_1 = v_k_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_byKey_246); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_d_2413 = v_field_2412;
      HeffT2 v_t_2414 = ({ V a_0 = v_callers_247; V a_1 = v_k_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_callers_247); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x_2417 = v_field_2416;
          heff_drop(v_x_2417);
          V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_s_248, 0)), 0, 3);
          HeffT2 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_k_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
          V v_t_2425;
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_248, 0)), 0, 3);
            V v_t_2424 = heff_bool(((v_tag_2420 == ((int64_t)0ULL)) && ({ V v_x_2423 = heff_dup(v_field_2421); int c_ = 1; heff_drop(v_x_2423); c_; })));
            heff_drop(v_field_2421);
            v_t_2425 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_t_2422, v_consts_240, v_t_2424});
          }
          V v_t_2426 = (g_heff_2ecompile_2eranges_2egatherDef(v_t_2425, v_d_2413));
          return (g_heff_2ecompile_2eranges_2eabsorb(v_k_249, v_s_248, v_t_2426));
        } else {
          heff_drop(v_k_249);
          heff_drop(v_consts_240);
          heff_drop(v_d_2413);
          heff_drop(v_field_2416);
          return v_s_248;
        }
      }
    } else {
      heff_drop(v_k_249);
      heff_drop(v_callers_247);
      heff_drop(v_consts_240);
      heff_drop(v_field_2412);
      return v_s_248;
    }
  }
}
V g_heff_2ecompile_2eranges_2erangedFns_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangedFns_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedFns_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erangedFns(V v_consts_240, V v_defs_241, V v_scans_242, V v_params_243) {
top: ;
  V v_t_2411 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2erangedFns_lam0, 2, 2, (V[]){heff_dup(v_scans_242), heff_dup(v_params_243)}), heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), v_defs_241));
  HEFF_LAST return g_heff_2ecompile_2eranges_2erangedIn(v_consts_240, v_defs_241, v_params_243, v_t_2411);
}
V g_heff_2ecompile_2eranges_2erangedFns_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2erangedFns(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2erangedFns_lam0(V self, V *args) {
  V v_sc_244 = args[0];
  V v_d_245 = args[1];
  V v_scans_242 = heff_env(self)[0];
  V v_params_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_scans_242; V a_1 = heff_rfield(v_d_245, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_scans_242); r_; });
  V v_t_2410;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_248);
      v_t_2410 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
    }
  }
  return ({ V a_0 = v_params_243; V a_1 = v_sc_244; V a_2 = v_d_245; V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2eranges_2escopeOne(a_0, a_1, a_2, a_3)); heff_drop(v_params_243); r_; });
}
Clo g_heff_2ecompile_2eranges_2erangedScans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedScans_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erangedScans(V v_consts_240, V v_defs_241, V v_scans_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_scans_242, NTAG(TAG_Nil)));
  V v_esc_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s326537207x242980421(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_fns_245 = ({ V a_0 = v_esc_244; V a_1 = v_scans_242; V a_2 = heff_dup(g_std_2emap_2eempty_get()); V a_3 = v_defs_241; V r_ = (g_list_2efoldl_24s26403090x581733227(a_0, a_1, a_2, a_3)); heff_drop(v_esc_244); r_; });
  V v_t_246 = (g_std_2emap_2etoListOnto(v_fns_245, NTAG(TAG_Nil)));
  V v_t_247 = (g_list_2ekeepIf_24s1606737509x658906972(v_t_246));
  V v_t_248 = (g_std_2emap_2emapValues_24s471823439x1830654496(heff_dup(v_fns_245)));
  V v_t_249 = ({ V a_0 = v_t_247; V a_1 = MK_INT(64LL); V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eranges_2emattering(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2410 = ({ V a_0 = v_fns_245; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2estartParams(a_0, a_1)); heff_drop(v_fns_245); heff_drop(v_t_249); r_; });
  return (g_heff_2ecompile_2eranges_2erangedFns(v_consts_240, v_defs_241, v_scans_242, v_t_2410));
}
V g_heff_2ecompile_2eranges_2erangedScans_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2erangedScans(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2erangeProgram_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangeProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangeProgram_entry, 1, 0};

V g_heff_2ecompile_2eranges_2erangeProgram(V v_defs_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1068175575x1869083571(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_ar_242 = (g_list_2efoldl_24s1810610888x1691479932(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_t_249 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2erangeProgram_lam0, 2, 1, (V[]){v_ar_242}), heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  return ({ V a_0 = v_t_241; V a_1 = v_defs_240; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2erangedScans(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eranges_2erangeProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erangeProgram(a[0]);
}
V g_heff_2ecompile_2eranges_2erangeProgram_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_d_244 = args[1];
  V v_ar_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_245 = heff_take_field(v_d_244, 0);
  V v_body_246 = heff_get_n(v_d_244, 2, 3);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_body_246, NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = v_ar_242; V a_1 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get()); V a_2 = v_t_247; V r_ = (g_heff_2ecompile_2eranges_2escanW(a_0, a_1, a_2)); heff_drop(v_ar_242); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_243, v_key_245, v_t_248));
}
Clo g_heff_2ecompile_2eranges_2ecorners_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecorners_24tok1_entry, 5, 0};

V g_heff_2ecompile_2eranges_2ecorners_24tok1(V v_tok_240, V v_a_241, V v_b_242, V v_c_243, V v_d_244) {
top: ;
  V v_a_245;
  if (heff_intLt_c_lent(v_a_241, v_b_242, 0)) {
    v_a_245 = heff_dup(v_a_241);
  } else {
    v_a_245 = heff_dup(v_b_242);
  }
  V v_b_246;
  if (heff_intLt_c_lent(v_c_243, v_d_244, 0)) {
    v_b_246 = heff_dup(v_c_243);
  } else {
    v_b_246 = heff_dup(v_d_244);
  }
  V v_t_247;
  if (heff_intLt_c_lent(v_a_245, v_b_246, 0)) {
    heff_drop(v_b_246);
    v_t_247 = v_a_245;
  } else {
    heff_drop(v_a_245);
    v_t_247 = v_b_246;
  }
  V v_a_248;
  if (heff_intLt_c_lent(v_a_241, v_b_242, 0)) {
    heff_drop(v_a_241);
    v_a_248 = v_b_242;
  } else {
    heff_drop(v_b_242);
    v_a_248 = v_a_241;
  }
  V v_b_249;
  if (heff_intLt_c_lent(v_c_243, v_d_244, 0)) {
    heff_drop(v_c_243);
    v_b_249 = v_d_244;
  } else {
    heff_drop(v_d_244);
    v_b_249 = v_c_243;
  }
  V v_t_2410;
  if (heff_intLt_c_lent(v_a_248, v_b_249, 0)) {
    heff_drop(v_a_248);
    v_t_2410 = v_b_249;
  } else {
    heff_drop(v_b_249);
    v_t_2410 = v_a_248;
  }
  return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_247}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2410})});
}
V g_heff_2ecompile_2eranges_2ecorners_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecorners_24tok1(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2eranges_2erootTo_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootTo_24tok1_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erootTo_24tok1(V v_tok_240, V v_env_241, V v_x_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_x_242);
    return v_env_241;
  }
  case TAG_Just: {
    V v_h_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_h_244, 1)) {
      HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_241, 0), v_x_242));
      V v_t_249;
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x_248 = v_field_247;
          v_t_249 = v_x_248;
        } else {
          heff_drop(v_field_247);
          v_t_249 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      V v_t_2410;
      if (heff_intLt_c_lent(v_h_244, MK_INT(2LL), 2)) {
        v_t_2410 = heff_dup(v_h_244);
      } else {
        v_t_2410 = heff_intAdd(heff_intDiv(heff_dup(v_h_244), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2411 = (g_heff_2ecompile_2eranges_2erootGo(heff_dup(v_h_244), MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_t_2411)});
      V v_t_2413;
      if (heff_intLt_c_lent(v_h_244, MK_INT(2LL), 2)) {
        v_t_2413 = heff_dup(v_h_244);
      } else {
        v_t_2413 = heff_intAdd(heff_intDiv(heff_dup(v_h_244), MK_INT(2LL)), MK_INT(1LL));
      }
      V v_t_2414 = (g_heff_2ecompile_2eranges_2erootGo(v_h_244, MK_INT(0LL), v_t_2413));
      V v_t_2415 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2412, heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2414})});
      V v_t_2416 = (g_heff_2ecompile_2eranges_2emeet(v_t_249, v_t_2415));
      return (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, v_x_242, v_t_2416));
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_h_244);
      heff_drop_cell(v_ru_24x3_243_24Just, 1);
      return v_env_241;
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eranges_2erootTo_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootTo_24tok1(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimHigh_24tok1_entry, 3, 0};

V g_heff_2ecompile_2eranges_2etrimHigh_24tok1(V v_tok_240, V v_v_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_v_241);
    return v_r_242;
  }
  case TAG_Within: {
    V v_r2_244 = heff_dup(heff_field(v_r_242, 1));
    switch (heff_tag_of(v_r2_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_v_241);
      return v_r_242;
    }
    case TAG_Just: {
      V v_hi_245 = heff_field(v_r2_244, 0);
      V v_ru_24r2_244_24Just = heff_take_reuse_n(v_r2_244, 1ULL, 1);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Within: {
        V v_lo_246 = heff_field(v_r_242, 0);
        V v_ru_24r_242_24Within = heff_take_reuse_n(v_r_242, 1ULL, 2);
        if (heff_intEq_c_lent(v_hi_245, v_v_241, 0)) {
          heff_drop(v_hi_245);
          V v_t_248 = heff_intSub(v_v_241, MK_INT(1LL));
          switch (heff_tag_of(v_lo_246)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24r2_244_24Just, 1);
            return heff_tag_at_n(v_ru_24r_242_24Within, TAG_Within, 2, (V[]){v_lo_246, heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_248})});
          }
          case TAG_Just: {
            V v_lo_249 = heff_field(v_lo_246, 0);
            heff_take_n(v_lo_246, 1ULL, 1);
            if (heff_intLt_c_lent(v_t_248, v_lo_249, 0)) {
              heff_drop_cell(v_tok_240, 1);
              heff_drop_cell(v_ru_24r2_244_24Just, 1);
              heff_drop_cell(v_ru_24r_242_24Within, 2);
              heff_drop(v_t_248);
              heff_drop(v_lo_249);
              return NTAG(TAG_Unreached);
            } else {
              return heff_tag_at_n(v_ru_24r_242_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_lo_249}), heff_tag_at_n(v_ru_24r2_244_24Just, TAG_Just, 1, (V[]){v_t_248})});
            }
          }
          default: return heff_nomatch(v_lo_246);
          }
        } else {
          heff_drop(v_v_241);
          heff_drop_cell(v_ru_24r2_244_24Just, 1);
          return heff_tag_at_n(v_ru_24r_242_24Within, TAG_Within, 2, (V[]){v_lo_246, heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_hi_245})});
        }
      }
      default: return heff_nomatch(v_r_242);
      }
    }
    default: return heff_nomatch(v_r2_244);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimHigh_24tok1(a[0], a[1], a[2]);
}