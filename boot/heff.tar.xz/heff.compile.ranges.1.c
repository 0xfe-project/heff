// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkSeen 11336
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_consts 592362651
#define LBL_dirty 296951788
#define LBL_fix 310927
#define LBL_gathered 1327153563
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marking 1071112247
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
static uint32_t shape_byKey__callers__callersOf__ints[] = {LBL_byKey, LBL_callers, LBL_callersOf, LBL_ints};
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_ranges__tests[] = {LBL_ranges, LBL_tests};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eranges_2eabsorb(V, V, V);
V g_heff_2ecompile_2eranges_2eabsorb_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorb_clo;
V g_heff_2ecompile_2eranges_2eandR(V, V);
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eandR_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2earityOne(V, V);
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2earityOne_clo;
V g_heff_2ecompile_2eranges_2ecorners(V, V, V, V);
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ecorners_clo;
V g_heff_2ecompile_2eranges_2edivPositive(V, V, V);
V g_heff_2ecompile_2eranges_2edivPositive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2edivPositive_clo;
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
V g_heff_2ecompile_2eranges_2egatherGo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherGo_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egivenFrom_clo;
V g_heff_2ecompile_2eranges_2ehighMeet(V, V);
V g_heff_2ecompile_2eranges_2ehighMeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ehighMeet_clo;
V g_heff_2ecompile_2eranges_2eintOps_get(void);
V g_heff_2ecompile_2eranges_2eisComparison(V);
V g_heff_2ecompile_2eranges_2eisComparison_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisComparison_clo;
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2emodR(V, V);
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emodR_clo;
V g_heff_2ecompile_2eranges_2emulR(V, V);
V g_heff_2ecompile_2eranges_2emulR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emulR_clo;
V g_heff_2ecompile_2eranges_2enamesW(V, V);
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enamesW_clo;
V g_heff_2ecompile_2eranges_2enatural(V);
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enatural_clo;
V g_heff_2ecompile_2eranges_2enonZero(V);
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enonZero_clo;
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2eranges_2erangeProgram(V);
V g_heff_2ecompile_2eranges_2erangeProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeProgram_clo;
V g_heff_2ecompile_2eranges_2erangedFns(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedFns_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedFns_clo;
V g_heff_2ecompile_2eranges_2erangedIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedIn_clo;
V g_heff_2ecompile_2eranges_2erangedScans(V, V, V);
V g_heff_2ecompile_2eranges_2erangedScans_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedScans_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2escopeOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2escopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escopeOne_clo;
V g_heff_2ecompile_2eranges_2estartParams(V, V);
V g_heff_2ecompile_2eranges_2estartParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2estartParams_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkGo_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewiden_clo;
V g_heff_2ecompile_2eranges_2ewidenHigh(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenHigh_clo;
V g_heff_2ecompile_2eranges_2ewidenLow(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenLow_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2eranges_2ewithTest(V, V, V);
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithTest_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1068175575x1869083571(V, V);
V g_list_2efoldl_24s1068175575x1869083571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1068175575x1869083571_clo;
V g_list_2efoldl_24s1719254312x1333482082(V, V, V);
V g_list_2efoldl_24s1719254312x1333482082_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1719254312x1333482082_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s326537207x242980421(V, V);
V g_list_2efoldl_24s326537207x242980421_entry(V self, V *a);
extern Clo g_list_2efoldl_24s326537207x242980421_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1606737509x658906972(V);
V g_list_2ekeepIf_24s1606737509x658906972_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2emapValues_24s471823439x1830654496(V);
V g_std_2emap_2emapValues_24s471823439x1830654496_entry(V self, V *a);
extern Clo g_std_2emap_2emapValues_24s471823439x1830654496_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str0, 11, "wordToFloat");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str1, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str3, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str4, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str5, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str6, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str7, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str8, 7, "wordRem");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str9, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str10, 8, "wordQuot");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str11, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str12, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str13, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str14, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str15, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str16, 7, "wordMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str17, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str18, 7, "wordSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str19, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str20, 7, "wordAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordPrims_str21, 6, "intAdd");

static V g_heff_2ecompile_2eranges_2ewordPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2ewordPrims_st;
static V g_heff_2ecompile_2eranges_2ewordPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str0), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str2), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str4), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str6), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str8), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str10), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str12), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str14), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str16), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str18), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str19)}), v_t_248});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2ewordPrims_str20), ((V)&g_heff_2ecompile_2eranges_2ewordPrims_str21)}), v_t_249});
}
V g_heff_2ecompile_2eranges_2ewordPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2ewordPrims_st)) return g_heff_2ecompile_2eranges_2ewordPrims_val;
  return heff_global(&g_heff_2ecompile_2eranges_2ewordPrims_val, &g_heff_2ecompile_2eranges_2ewordPrims_st, g_heff_2ecompile_2eranges_2ewordPrims_init);
}

static V g_heff_2ecompile_2eranges_2eanyRange_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eanyRange_st;
static V g_heff_2ecompile_2eranges_2eanyRange_init(void) {
  return heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2ecompile_2eranges_2eanyRange_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eanyRange_st)) return g_heff_2ecompile_2eranges_2eanyRange_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eanyRange_val, &g_heff_2ecompile_2eranges_2eanyRange_st, g_heff_2ecompile_2eranges_2eanyRange_init);
}
Clo g_heff_2ecompile_2eranges_2erangeEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangeEq_entry, 2, 0};

V g_heff_2ecompile_2eranges_2erangeEq(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_True);
    }
    case TAG_Within: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  case TAG_Within: {
    V v_a_244 = heff_field(v_r_240, 0);
    V v_b_245 = heff_field(v_r_240, 1);
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_c_246 = heff_field(v_s_241, 0);
      V v_d_247 = heff_field(v_s_241, 1);
      switch (heff_tag_of(v_a_244)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_c_246)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_b_245)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_d_247)) {
            case TAG_Nothing: {
              return NTAG(TAG_True);
            }
            case TAG_Just: {
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_d_247);
            }
          }
          case TAG_Just: {
            V v_a_249 = heff_field(v_b_245, 0);
            switch (heff_tag_of(v_d_247)) {
            case TAG_Nothing: {
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2410 = heff_field(v_d_247, 0);
              return heff_intEq_lent(v_a_249, v_b_2410, 0);
            }
            default: return heff_nomatch(v_d_247);
            }
          }
          default: return heff_nomatch(v_b_245);
          }
        }
        case TAG_Just: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c_246);
        }
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_c_246)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_b_2413 = heff_field(v_c_246, 0);
          if (heff_intEq_c_lent(v_a_2412, v_b_2413, 0)) {
            switch (heff_tag_of(v_b_245)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_d_247)) {
              case TAG_Nothing: {
                return NTAG(TAG_True);
              }
              case TAG_Just: {
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_d_247);
              }
            }
            case TAG_Just: {
              V v_a_2416 = heff_field(v_b_245, 0);
              switch (heff_tag_of(v_d_247)) {
              case TAG_Nothing: {
                return NTAG(TAG_False);
              }
              case TAG_Just: {
                V v_b_2417 = heff_field(v_d_247, 0);
                return heff_intEq_lent(v_a_2416, v_b_2417, 0);
              }
              default: return heff_nomatch(v_d_247);
              }
            }
            default: return heff_nomatch(v_b_245);
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_c_246);
        }
      }
      default: return heff_nomatch(v_a_244);
      }
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2erangeEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2ehighMeet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ehighMeet_entry, 2, 0};

V g_heff_2ecompile_2eranges_2ehighMeet(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return v_x2_241;
  }
  case TAG_Just: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_a_242});
    }
    case TAG_Just: {
      V v_b_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_t_245;
      if (heff_intLt_c_lent(v_a_242, v_b_243, 0)) {
        heff_drop(v_b_243);
        v_t_245 = v_a_242;
      } else {
        heff_drop(v_a_242);
        v_t_245 = v_b_243;
      }
      return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_t_245});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ehighMeet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ehighMeet(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2ecorners_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ecorners_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ecorners(V v_a_240, V v_b_241, V v_c_242, V v_d_243) {
top: ;
  V v_a_245;
  if (heff_intLt_c_lent(v_a_240, v_b_241, 0)) {
    v_a_245 = heff_dup(v_a_240);
  } else {
    v_a_245 = heff_dup(v_b_241);
  }
  V v_b_247;
  if (heff_intLt_c_lent(v_c_242, v_d_243, 0)) {
    v_b_247 = heff_dup(v_c_242);
  } else {
    v_b_247 = heff_dup(v_d_243);
  }
  V v_t_249;
  if (heff_intLt_c_lent(v_a_245, v_b_247, 0)) {
    heff_drop(v_b_247);
    v_t_249 = v_a_245;
  } else {
    heff_drop(v_a_245);
    v_t_249 = v_b_247;
  }
  V v_a_2411;
  if (heff_intLt_c_lent(v_a_240, v_b_241, 0)) {
    heff_drop(v_a_240);
    v_a_2411 = v_b_241;
  } else {
    heff_drop(v_b_241);
    v_a_2411 = v_a_240;
  }
  V v_b_2413;
  if (heff_intLt_c_lent(v_c_242, v_d_243, 0)) {
    heff_drop(v_c_242);
    v_b_2413 = v_d_243;
  } else {
    heff_drop(v_d_243);
    v_b_2413 = v_c_242;
  }
  V v_t_2415;
  if (heff_intLt_c_lent(v_a_2411, v_b_2413, 0)) {
    heff_drop(v_a_2411);
    v_t_2415 = v_b_2413;
  } else {
    heff_drop(v_b_2413);
    v_t_2415 = v_a_2411;
  }
  return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_249}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2415})});
}
V g_heff_2ecompile_2eranges_2ecorners_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ecorners(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eranges_2edivPositive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2edivPositive_entry, 3, 0};

V g_heff_2ecompile_2eranges_2edivPositive(V v_lb_240, V v_hb_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Unreached: {
    heff_drop(v_lb_240);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_r1_243 = heff_field(v_r_242, 0);
    V v_r2_244 = heff_field(v_r_242, 1);
    V v_ru_24r_242_24Within = heff_take_reuse_n(v_r_242, 3ULL, 2);
    switch (heff_tag_of(v_r1_243)) {
    case TAG_Nothing: {
      heff_drop(v_lb_240);
      heff_drop(v_r2_244);
      heff_drop_cell(v_ru_24r_242_24Within, 2);
      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_r1_243, 0);
      heff_take_n(v_r1_243, 1ULL, 1);
      switch (heff_tag_of(v_r2_244)) {
      case TAG_Nothing: {
        heff_drop(v_lb_240);
        heff_drop_cell(v_ru_24r_242_24Within, 2);
        heff_drop(v_x_245);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_y_246 = heff_field(v_r2_244, 0);
        heff_take_n(v_r2_244, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_hb_241)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_245, 1)) {
            heff_drop(v_x_245);
            v_t_2410 = MK_INT(0LL);
          } else {
            v_t_2410 = heff_intDiv(v_x_245, heff_dup(v_lb_240));
          }
          break;
        }
        case TAG_Just: {
          V v_hb_248 = heff_field(v_hb_241, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_245, 1)) {
            v_t_2410 = heff_intDiv(v_x_245, heff_dup(v_hb_248));
          } else {
            v_t_2410 = heff_intDiv(v_x_245, heff_dup(v_lb_240));
          }
          break;
        }
        default: heff_nomatch(v_hb_241);
        }
        V v_t_2414;
        switch (heff_tag_of(v_hb_241)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
            v_t_2414 = heff_intDiv(v_y_246, v_lb_240);
          } else {
            heff_drop(v_lb_240);
            heff_drop(v_y_246);
            v_t_2414 = MK_INT(-1LL);
          }
          break;
        }
        case TAG_Just: {
          V v_hb_2412 = heff_field(v_hb_241, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
            v_t_2414 = heff_intDiv(v_y_246, v_lb_240);
          } else {
            heff_drop(v_lb_240);
            v_t_2414 = heff_intDiv(v_y_246, heff_dup(v_hb_2412));
          }
          break;
        }
        default: heff_nomatch(v_hb_241);
        }
        return heff_tag_at_n(v_ru_24r_242_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2410}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2414})});
      }
      default: return heff_nomatch(v_r2_244);
      }
    }
    default: return heff_nomatch(v_r1_243);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2eranges_2edivPositive_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2edivPositive(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str5, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str6, 7, "wordAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str7, 7, "wordSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str8, 7, "wordMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str9, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str10, 8, "wordQuot");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str11, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str12, 7, "wordRem");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str13, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str14, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str15, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2eranges_2eprimRange_str16, 9, "strByteAt");
Clo g_heff_2ecompile_2eranges_2eprimRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eprimRange_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eprimRange(V v_p_240, V v_rs_241) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str0), 2)) {
    HeffT3 v_t_243 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT3 v_t_247 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
      {
        V v_field_249 = v_t_247.f[1];
        V v_field_2410 = v_t_247.f[2];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_245;
          V v_x12_2413 = v_field_246;
          heff_drop(v_x12_2413);
          v_t_2414 = v_x_2412;
        } else {
          heff_drop(v_field_245);
          heff_drop(v_field_246);
          v_t_2414 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Unreached: {
          heff_drop(v_field_249);
          heff_drop(v_field_2410);
          return NTAG(TAG_Unreached);
        }
        case TAG_Within: {
          V v_a_2415 = heff_field(v_t_2414, 0);
          V v_b_2416 = heff_field(v_t_2414, 1);
          V v_ru_24t_2414_24Within = heff_take_reuse_n(v_t_2414, 3ULL, 2);
          V v_t_2420;
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x_2418 = v_field_249;
            V v_x12_2419 = v_field_2410;
            heff_drop(v_x12_2419);
            v_t_2420 = v_x_2418;
          } else {
            heff_drop(v_field_249);
            heff_drop(v_field_2410);
            v_t_2420 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Unreached: {
            heff_drop(v_a_2415);
            heff_drop(v_b_2416);
            heff_drop_cell(v_ru_24t_2414_24Within, 2);
            return NTAG(TAG_Unreached);
          }
          case TAG_Within: {
            V v_c_2421 = heff_field(v_t_2420, 0);
            V v_d_2422 = heff_field(v_t_2420, 1);
            heff_take_n(v_t_2420, 3ULL, 2);
            V v_t_2425;
            switch (heff_tag_of(v_a_2415)) {
            case TAG_Nothing: {
              heff_drop(v_c_2421);
              v_t_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_a_2423 = heff_field(v_a_2415, 0);
              V v_ru_24a_2415_24Just = heff_take_reuse_n(v_a_2415, 1ULL, 1);
              switch (heff_tag_of(v_c_2421)) {
              case TAG_Nothing: {
                heff_drop(v_a_2423);
                heff_drop_cell(v_ru_24a_2415_24Just, 1);
                v_t_2425 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_b_2424 = heff_field(v_c_2421, 0);
                heff_take_n(v_c_2421, 1ULL, 1);
                v_t_2425 = heff_tag_at_n(v_ru_24a_2415_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2423, v_b_2424)});
                break;
              }
              default: heff_nomatch(v_c_2421);
              }
              break;
            }
            default: heff_nomatch(v_a_2415);
            }
            V v_t_2428;
            switch (heff_tag_of(v_b_2416)) {
            case TAG_Nothing: {
              heff_drop(v_d_2422);
              v_t_2428 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_a_2426 = heff_field(v_b_2416, 0);
              V v_ru_24b_2416_24Just = heff_take_reuse_n(v_b_2416, 1ULL, 1);
              switch (heff_tag_of(v_d_2422)) {
              case TAG_Nothing: {
                heff_drop(v_a_2426);
                heff_drop_cell(v_ru_24b_2416_24Just, 1);
                v_t_2428 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_b_2427 = heff_field(v_d_2422, 0);
                heff_take_n(v_d_2422, 1ULL, 1);
                v_t_2428 = heff_tag_at_n(v_ru_24b_2416_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2426, v_b_2427)});
                break;
              }
              default: heff_nomatch(v_d_2422);
              }
              break;
            }
            default: heff_nomatch(v_b_2416);
            }
            return heff_tag_at_n(v_ru_24t_2414_24Within, TAG_Within, 2, (V[]){v_t_2425, v_t_2428});
          }
          default: return heff_nomatch(v_t_2420);
          }
        }
        default: return heff_nomatch(v_t_2414);
        }
      }
    }
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str1), 2)) {
      HeffT3 v_t_2430 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
      {
        V v_field_2432 = v_t_2430.f[1];
        V v_field_2433 = v_t_2430.f[2];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        HeffT3 v_t_2434 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
        {
          V v_field_2436 = v_t_2434.f[1];
          V v_field_2437 = v_t_2434.f[2];
          int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
          V v_t_2441;
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_x_2439 = v_field_2432;
            V v_x12_2440 = v_field_2433;
            heff_drop(v_x12_2440);
            v_t_2441 = v_x_2439;
          } else {
            heff_drop(v_field_2432);
            heff_drop(v_field_2433);
            v_t_2441 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          switch (heff_tag_of(v_t_2441)) {
          case TAG_Unreached: {
            heff_drop(v_field_2436);
            heff_drop(v_field_2437);
            return NTAG(TAG_Unreached);
          }
          case TAG_Within: {
            V v_a_2442 = heff_field(v_t_2441, 0);
            V v_b_2443 = heff_field(v_t_2441, 1);
            V v_ru_24t_2441_24Within = heff_take_reuse_n(v_t_2441, 3ULL, 2);
            V v_t_2447;
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              V v_x_2445 = v_field_2436;
              V v_x12_2446 = v_field_2437;
              heff_drop(v_x12_2446);
              v_t_2447 = v_x_2445;
            } else {
              heff_drop(v_field_2436);
              heff_drop(v_field_2437);
              v_t_2447 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            switch (heff_tag_of(v_t_2447)) {
            case TAG_Unreached: {
              heff_drop(v_a_2442);
              heff_drop(v_b_2443);
              heff_drop_cell(v_ru_24t_2441_24Within, 2);
              return NTAG(TAG_Unreached);
            }
            case TAG_Within: {
              V v_c_2448 = heff_field(v_t_2447, 0);
              V v_d_2449 = heff_field(v_t_2447, 1);
              heff_take_n(v_t_2447, 3ULL, 2);
              V v_t_2452;
              switch (heff_tag_of(v_a_2442)) {
              case TAG_Nothing: {
                heff_drop(v_d_2449);
                v_t_2452 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_a_2450 = heff_field(v_a_2442, 0);
                V v_ru_24a_2442_24Just = heff_take_reuse_n(v_a_2442, 1ULL, 1);
                switch (heff_tag_of(v_d_2449)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2450);
                  heff_drop_cell(v_ru_24a_2442_24Just, 1);
                  v_t_2452 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_b_2451 = heff_field(v_d_2449, 0);
                  heff_take_n(v_d_2449, 1ULL, 1);
                  v_t_2452 = heff_tag_at_n(v_ru_24a_2442_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_2450, v_b_2451)});
                  break;
                }
                default: heff_nomatch(v_d_2449);
                }
                break;
              }
              default: heff_nomatch(v_a_2442);
              }
              V v_t_2455;
              switch (heff_tag_of(v_b_2443)) {
              case TAG_Nothing: {
                heff_drop(v_c_2448);
                v_t_2455 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_a_2453 = heff_field(v_b_2443, 0);
                V v_ru_24b_2443_24Just = heff_take_reuse_n(v_b_2443, 1ULL, 1);
                switch (heff_tag_of(v_c_2448)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2453);
                  heff_drop_cell(v_ru_24b_2443_24Just, 1);
                  v_t_2455 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_b_2454 = heff_field(v_c_2448, 0);
                  heff_take_n(v_c_2448, 1ULL, 1);
                  v_t_2455 = heff_tag_at_n(v_ru_24b_2443_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_2453, v_b_2454)});
                  break;
                }
                default: heff_nomatch(v_c_2448);
                }
                break;
              }
              default: heff_nomatch(v_b_2443);
              }
              return heff_tag_at_n(v_ru_24t_2441_24Within, TAG_Within, 2, (V[]){v_t_2452, v_t_2455});
            }
            default: return heff_nomatch(v_t_2447);
            }
          }
          default: return heff_nomatch(v_t_2441);
          }
        }
      }
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str2), 2)) {
        HeffT3 v_t_2457 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
        V v_t_2464;
        {
          V v_field_2459 = v_t_2457.f[1];
          V v_field_2460 = v_t_2457.f[2];
          int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
          if ((v_tag_2458 == ((int64_t)0ULL))) {
            V v_x_2462 = v_field_2459;
            V v_x12_2463 = v_field_2460;
            heff_drop(v_x12_2463);
            v_t_2464 = v_x_2462;
          } else {
            heff_drop(v_field_2459);
            heff_drop(v_field_2460);
            v_t_2464 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        HeffT3 v_t_2465 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
        V v_t_2472;
        {
          V v_field_2467 = v_t_2465.f[1];
          V v_field_2468 = v_t_2465.f[2];
          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
          if ((v_tag_2466 == ((int64_t)0ULL))) {
            V v_x_2470 = v_field_2467;
            V v_x12_2471 = v_field_2468;
            heff_drop(v_x12_2471);
            v_t_2472 = v_x_2470;
          } else {
            heff_drop(v_field_2467);
            heff_drop(v_field_2468);
            v_t_2472 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        HEFF_LAST return g_heff_2ecompile_2eranges_2emulR(v_t_2464, v_t_2472);
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str3), 2)) {
          HeffT3 v_t_2474 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
          {
            V v_field_2476 = v_t_2474.f[1];
            V v_field_2477 = v_t_2474.f[2];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            HeffT3 v_t_2478 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
            {
              V v_field_2480 = v_t_2478.f[1];
              V v_field_2481 = v_t_2478.f[2];
              int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
              V v_t_2485;
              if ((v_tag_2479 == ((int64_t)0ULL))) {
                V v_x_2483 = v_field_2480;
                V v_x12_2484 = v_field_2481;
                heff_drop(v_x12_2484);
                v_t_2485 = v_x_2483;
              } else {
                heff_drop(v_field_2480);
                heff_drop(v_field_2481);
                v_t_2485 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              switch (heff_tag_of(v_t_2485)) {
              case TAG_Unreached: {
                heff_drop(v_field_2476);
                heff_drop(v_field_2477);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              case TAG_Within: {
                V v_b1_2486 = heff_field(v_t_2485, 0);
                V v_hb_2487 = heff_field(v_t_2485, 1);
                heff_take_n(v_t_2485, 3ULL, 2);
                switch (heff_tag_of(v_b1_2486)) {
                case TAG_Nothing: {
                  heff_drop(v_field_2476);
                  heff_drop(v_field_2477);
                  heff_drop(v_hb_2487);
                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
                case TAG_Just: {
                  V v_lb_2488 = heff_field(v_b1_2486, 0);
                  heff_take_n(v_b1_2486, 1ULL, 1);
                  if (heff_intLt_c_lent(MK_INT(0LL), v_lb_2488, 1)) {
                    V v_t_2493;
                    if ((v_tag_2475 == ((int64_t)0ULL))) {
                      V v_x_2491 = v_field_2476;
                      V v_x12_2492 = v_field_2477;
                      heff_drop(v_x12_2492);
                      v_t_2493 = v_x_2491;
                    } else {
                      heff_drop(v_field_2476);
                      heff_drop(v_field_2477);
                      v_t_2493 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                    return ({ V a_0 = v_lb_2488; V a_1 = v_hb_2487; V a_2 = v_t_2493; V r_ = (g_heff_2ecompile_2eranges_2edivPositive(a_0, a_1, a_2)); heff_drop(v_hb_2487); r_; });
                  } else {
                    heff_drop(v_field_2476);
                    heff_drop(v_field_2477);
                    heff_drop(v_hb_2487);
                    heff_drop(v_lb_2488);
                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                  }
                }
                default: return heff_nomatch(v_b1_2486);
                }
              }
              default: return heff_nomatch(v_t_2485);
              }
            }
          }
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str4), 2)) {
            HeffT3 v_t_2495 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
            V v_t_24102;
            {
              V v_field_2497 = v_t_2495.f[1];
              V v_field_2498 = v_t_2495.f[2];
              int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
              if ((v_tag_2496 == ((int64_t)0ULL))) {
                V v_x_24100 = v_field_2497;
                V v_x12_24101 = v_field_2498;
                heff_drop(v_x12_24101);
                v_t_24102 = v_x_24100;
              } else {
                heff_drop(v_field_2497);
                heff_drop(v_field_2498);
                v_t_24102 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            HeffT3 v_t_24103 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
            V v_t_24110;
            {
              V v_field_24105 = v_t_24103.f[1];
              V v_field_24106 = v_t_24103.f[2];
              int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
              if ((v_tag_24104 == ((int64_t)0ULL))) {
                V v_x_24108 = v_field_24105;
                V v_x12_24109 = v_field_24106;
                heff_drop(v_x12_24109);
                v_t_24110 = v_x_24108;
              } else {
                heff_drop(v_field_24105);
                heff_drop(v_field_24106);
                v_t_24110 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            return ({ V a_0 = v_t_24102; V a_1 = v_t_24110; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_24102); r_; });
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str5), 2)) {
              HeffT3 v_t_24112 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
              V v_t_24119;
              {
                V v_field_24114 = v_t_24112.f[1];
                V v_field_24115 = v_t_24112.f[2];
                int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
                if ((v_tag_24113 == ((int64_t)0ULL))) {
                  V v_x_24117 = v_field_24114;
                  V v_x12_24118 = v_field_24115;
                  heff_drop(v_x12_24118);
                  v_t_24119 = v_x_24117;
                } else {
                  heff_drop(v_field_24114);
                  heff_drop(v_field_24115);
                  v_t_24119 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              HeffT3 v_t_24120 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
              V v_t_24127;
              {
                V v_field_24122 = v_t_24120.f[1];
                V v_field_24123 = v_t_24120.f[2];
                int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
                if ((v_tag_24121 == ((int64_t)0ULL))) {
                  V v_x_24125 = v_field_24122;
                  V v_x12_24126 = v_field_24123;
                  heff_drop(v_x12_24126);
                  v_t_24127 = v_x_24125;
                } else {
                  heff_drop(v_field_24122);
                  heff_drop(v_field_24123);
                  v_t_24127 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              HEFF_LAST return g_heff_2ecompile_2eranges_2eandR(v_t_24119, v_t_24127);
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str6), 2)) {
                HeffT3 v_t_24129 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                {
                  V v_field_24131 = v_t_24129.f[1];
                  V v_field_24132 = v_t_24129.f[2];
                  int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
                  HeffT3 v_t_24133 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                  {
                    V v_field_24135 = v_t_24133.f[1];
                    V v_field_24136 = v_t_24133.f[2];
                    int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                    V v_t_24140;
                    if ((v_tag_24130 == ((int64_t)0ULL))) {
                      V v_x_24138 = v_field_24131;
                      V v_x12_24139 = v_field_24132;
                      heff_drop(v_x12_24139);
                      v_t_24140 = v_x_24138;
                    } else {
                      heff_drop(v_field_24131);
                      heff_drop(v_field_24132);
                      v_t_24140 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                    }
                    switch (heff_tag_of(v_t_24140)) {
                    case TAG_Unreached: {
                      heff_drop(v_field_24135);
                      heff_drop(v_field_24136);
                      return NTAG(TAG_Unreached);
                    }
                    case TAG_Within: {
                      V v_a_24141 = heff_field(v_t_24140, 0);
                      V v_b_24142 = heff_field(v_t_24140, 1);
                      V v_ru_24t_24140_24Within = heff_take_reuse_n(v_t_24140, 3ULL, 2);
                      V v_t_24146;
                      if ((v_tag_24134 == ((int64_t)0ULL))) {
                        V v_x_24144 = v_field_24135;
                        V v_x12_24145 = v_field_24136;
                        heff_drop(v_x12_24145);
                        v_t_24146 = v_x_24144;
                      } else {
                        heff_drop(v_field_24135);
                        heff_drop(v_field_24136);
                        v_t_24146 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                      switch (heff_tag_of(v_t_24146)) {
                      case TAG_Unreached: {
                        heff_drop(v_a_24141);
                        heff_drop(v_b_24142);
                        heff_drop_cell(v_ru_24t_24140_24Within, 2);
                        return NTAG(TAG_Unreached);
                      }
                      case TAG_Within: {
                        V v_c_24147 = heff_field(v_t_24146, 0);
                        V v_d_24148 = heff_field(v_t_24146, 1);
                        heff_take_n(v_t_24146, 3ULL, 2);
                        V v_t_24151;
                        switch (heff_tag_of(v_a_24141)) {
                        case TAG_Nothing: {
                          heff_drop(v_c_24147);
                          v_t_24151 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_a_24149 = heff_field(v_a_24141, 0);
                          V v_ru_24a_24141_24Just = heff_take_reuse_n(v_a_24141, 1ULL, 1);
                          switch (heff_tag_of(v_c_24147)) {
                          case TAG_Nothing: {
                            heff_drop(v_a_24149);
                            heff_drop_cell(v_ru_24a_24141_24Just, 1);
                            v_t_24151 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_b_24150 = heff_field(v_c_24147, 0);
                            heff_take_n(v_c_24147, 1ULL, 1);
                            v_t_24151 = heff_tag_at_n(v_ru_24a_24141_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24149, v_b_24150)});
                            break;
                          }
                          default: heff_nomatch(v_c_24147);
                          }
                          break;
                        }
                        default: heff_nomatch(v_a_24141);
                        }
                        V v_t_24154;
                        switch (heff_tag_of(v_b_24142)) {
                        case TAG_Nothing: {
                          heff_drop(v_d_24148);
                          v_t_24154 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_a_24152 = heff_field(v_b_24142, 0);
                          V v_ru_24b_24142_24Just = heff_take_reuse_n(v_b_24142, 1ULL, 1);
                          switch (heff_tag_of(v_d_24148)) {
                          case TAG_Nothing: {
                            heff_drop(v_a_24152);
                            heff_drop_cell(v_ru_24b_24142_24Just, 1);
                            v_t_24154 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_b_24153 = heff_field(v_d_24148, 0);
                            heff_take_n(v_d_24148, 1ULL, 1);
                            v_t_24154 = heff_tag_at_n(v_ru_24b_24142_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_24152, v_b_24153)});
                            break;
                          }
                          default: heff_nomatch(v_d_24148);
                          }
                          break;
                        }
                        default: heff_nomatch(v_b_24142);
                        }
                        return heff_tag_at_n(v_ru_24t_24140_24Within, TAG_Within, 2, (V[]){v_t_24151, v_t_24154});
                      }
                      default: return heff_nomatch(v_t_24146);
                      }
                    }
                    default: return heff_nomatch(v_t_24140);
                    }
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str7), 2)) {
                  HeffT3 v_t_24156 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                  {
                    V v_field_24158 = v_t_24156.f[1];
                    V v_field_24159 = v_t_24156.f[2];
                    int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
                    HeffT3 v_t_24160 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                    {
                      V v_field_24162 = v_t_24160.f[1];
                      V v_field_24163 = v_t_24160.f[2];
                      int64_t v_tag_24161 = ((int64_t)v_t_24160.f[0]);
                      V v_t_24167;
                      if ((v_tag_24157 == ((int64_t)0ULL))) {
                        V v_x_24165 = v_field_24158;
                        V v_x12_24166 = v_field_24159;
                        heff_drop(v_x12_24166);
                        v_t_24167 = v_x_24165;
                      } else {
                        heff_drop(v_field_24158);
                        heff_drop(v_field_24159);
                        v_t_24167 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                      switch (heff_tag_of(v_t_24167)) {
                      case TAG_Unreached: {
                        heff_drop(v_field_24162);
                        heff_drop(v_field_24163);
                        return NTAG(TAG_Unreached);
                      }
                      case TAG_Within: {
                        V v_a_24168 = heff_field(v_t_24167, 0);
                        V v_b_24169 = heff_field(v_t_24167, 1);
                        V v_ru_24t_24167_24Within = heff_take_reuse_n(v_t_24167, 3ULL, 2);
                        V v_t_24173;
                        if ((v_tag_24161 == ((int64_t)0ULL))) {
                          V v_x_24171 = v_field_24162;
                          V v_x12_24172 = v_field_24163;
                          heff_drop(v_x12_24172);
                          v_t_24173 = v_x_24171;
                        } else {
                          heff_drop(v_field_24162);
                          heff_drop(v_field_24163);
                          v_t_24173 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                        }
                        switch (heff_tag_of(v_t_24173)) {
                        case TAG_Unreached: {
                          heff_drop(v_a_24168);
                          heff_drop(v_b_24169);
                          heff_drop_cell(v_ru_24t_24167_24Within, 2);
                          return NTAG(TAG_Unreached);
                        }
                        case TAG_Within: {
                          V v_c_24174 = heff_field(v_t_24173, 0);
                          V v_d_24175 = heff_field(v_t_24173, 1);
                          heff_take_n(v_t_24173, 3ULL, 2);
                          V v_t_24178;
                          switch (heff_tag_of(v_a_24168)) {
                          case TAG_Nothing: {
                            heff_drop(v_d_24175);
                            v_t_24178 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_a_24176 = heff_field(v_a_24168, 0);
                            V v_ru_24a_24168_24Just = heff_take_reuse_n(v_a_24168, 1ULL, 1);
                            switch (heff_tag_of(v_d_24175)) {
                            case TAG_Nothing: {
                              heff_drop(v_a_24176);
                              heff_drop_cell(v_ru_24a_24168_24Just, 1);
                              v_t_24178 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_b_24177 = heff_field(v_d_24175, 0);
                              heff_take_n(v_d_24175, 1ULL, 1);
                              v_t_24178 = heff_tag_at_n(v_ru_24a_24168_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_24176, v_b_24177)});
                              break;
                            }
                            default: heff_nomatch(v_d_24175);
                            }
                            break;
                          }
                          default: heff_nomatch(v_a_24168);
                          }
                          V v_t_24181;
                          switch (heff_tag_of(v_b_24169)) {
                          case TAG_Nothing: {
                            heff_drop(v_c_24174);
                            v_t_24181 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_a_24179 = heff_field(v_b_24169, 0);
                            V v_ru_24b_24169_24Just = heff_take_reuse_n(v_b_24169, 1ULL, 1);
                            switch (heff_tag_of(v_c_24174)) {
                            case TAG_Nothing: {
                              heff_drop(v_a_24179);
                              heff_drop_cell(v_ru_24b_24169_24Just, 1);
                              v_t_24181 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_b_24180 = heff_field(v_c_24174, 0);
                              heff_take_n(v_c_24174, 1ULL, 1);
                              v_t_24181 = heff_tag_at_n(v_ru_24b_24169_24Just, TAG_Just, 1, (V[]){heff_intSub(v_a_24179, v_b_24180)});
                              break;
                            }
                            default: heff_nomatch(v_c_24174);
                            }
                            break;
                          }
                          default: heff_nomatch(v_b_24169);
                          }
                          return heff_tag_at_n(v_ru_24t_24167_24Within, TAG_Within, 2, (V[]){v_t_24178, v_t_24181});
                        }
                        default: return heff_nomatch(v_t_24173);
                        }
                      }
                      default: return heff_nomatch(v_t_24167);
                      }
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str8), 2)) {
                    HeffT3 v_t_24183 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                    V v_t_24190;
                    {
                      V v_field_24185 = v_t_24183.f[1];
                      V v_field_24186 = v_t_24183.f[2];
                      int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
                      if ((v_tag_24184 == ((int64_t)0ULL))) {
                        V v_x_24188 = v_field_24185;
                        V v_x12_24189 = v_field_24186;
                        heff_drop(v_x12_24189);
                        v_t_24190 = v_x_24188;
                      } else {
                        heff_drop(v_field_24185);
                        heff_drop(v_field_24186);
                        v_t_24190 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                    }
                    HeffT3 v_t_24191 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                    V v_t_24198;
                    {
                      V v_field_24193 = v_t_24191.f[1];
                      V v_field_24194 = v_t_24191.f[2];
                      int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                      if ((v_tag_24192 == ((int64_t)0ULL))) {
                        V v_x_24196 = v_field_24193;
                        V v_x12_24197 = v_field_24194;
                        heff_drop(v_x12_24197);
                        v_t_24198 = v_x_24196;
                      } else {
                        heff_drop(v_field_24193);
                        heff_drop(v_field_24194);
                        v_t_24198 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                    }
                    HEFF_LAST return g_heff_2ecompile_2eranges_2emulR(v_t_24190, v_t_24198);
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str9), 2)) {
                      HeffT3 v_t_24200 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                      {
                        V v_field_24202 = v_t_24200.f[1];
                        V v_field_24203 = v_t_24200.f[2];
                        int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
                        HeffT3 v_t_24204 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                        {
                          V v_field_24206 = v_t_24204.f[1];
                          V v_field_24207 = v_t_24204.f[2];
                          int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
                          V v_t_24211;
                          if ((v_tag_24205 == ((int64_t)0ULL))) {
                            V v_x_24209 = v_field_24206;
                            V v_x12_24210 = v_field_24207;
                            heff_drop(v_x12_24210);
                            v_t_24211 = v_x_24209;
                          } else {
                            heff_drop(v_field_24206);
                            heff_drop(v_field_24207);
                            v_t_24211 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                          }
                          switch (heff_tag_of(v_t_24211)) {
                          case TAG_Unreached: {
                            heff_drop(v_field_24202);
                            heff_drop(v_field_24203);
                            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                          }
                          case TAG_Within: {
                            V v_b1_24212 = heff_field(v_t_24211, 0);
                            V v_hb_24213 = heff_field(v_t_24211, 1);
                            heff_take_n(v_t_24211, 3ULL, 2);
                            switch (heff_tag_of(v_b1_24212)) {
                            case TAG_Nothing: {
                              heff_drop(v_field_24202);
                              heff_drop(v_field_24203);
                              heff_drop(v_hb_24213);
                              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            case TAG_Just: {
                              V v_lb_24214 = heff_field(v_b1_24212, 0);
                              heff_take_n(v_b1_24212, 1ULL, 1);
                              if (heff_intLt_c_lent(MK_INT(0LL), v_lb_24214, 1)) {
                                V v_t_24219;
                                if ((v_tag_24201 == ((int64_t)0ULL))) {
                                  V v_x_24217 = v_field_24202;
                                  V v_x12_24218 = v_field_24203;
                                  heff_drop(v_x12_24218);
                                  v_t_24219 = v_x_24217;
                                } else {
                                  heff_drop(v_field_24202);
                                  heff_drop(v_field_24203);
                                  v_t_24219 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                }
                                return ({ V a_0 = v_lb_24214; V a_1 = v_hb_24213; V a_2 = v_t_24219; V r_ = (g_heff_2ecompile_2eranges_2edivPositive(a_0, a_1, a_2)); heff_drop(v_hb_24213); r_; });
                              } else {
                                heff_drop(v_field_24202);
                                heff_drop(v_field_24203);
                                heff_drop(v_hb_24213);
                                heff_drop(v_lb_24214);
                                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            default: return heff_nomatch(v_b1_24212);
                            }
                          }
                          default: return heff_nomatch(v_t_24211);
                          }
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str10), 2)) {
                        HeffT3 v_t_24221 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                        {
                          V v_field_24223 = v_t_24221.f[1];
                          V v_field_24224 = v_t_24221.f[2];
                          int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
                          HeffT3 v_t_24225 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                          {
                            V v_field_24227 = v_t_24225.f[1];
                            V v_field_24228 = v_t_24225.f[2];
                            int64_t v_tag_24226 = ((int64_t)v_t_24225.f[0]);
                            V v_t_24232;
                            if ((v_tag_24226 == ((int64_t)0ULL))) {
                              V v_x_24230 = v_field_24227;
                              V v_x12_24231 = v_field_24228;
                              heff_drop(v_x12_24231);
                              v_t_24232 = v_x_24230;
                            } else {
                              heff_drop(v_field_24227);
                              heff_drop(v_field_24228);
                              v_t_24232 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            switch (heff_tag_of(v_t_24232)) {
                            case TAG_Unreached: {
                              heff_drop(v_field_24223);
                              heff_drop(v_field_24224);
                              return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                            case TAG_Within: {
                              V v_b1_24233 = heff_field(v_t_24232, 0);
                              V v_hb_24234 = heff_field(v_t_24232, 1);
                              heff_take_n(v_t_24232, 3ULL, 2);
                              switch (heff_tag_of(v_b1_24233)) {
                              case TAG_Nothing: {
                                heff_drop(v_field_24223);
                                heff_drop(v_field_24224);
                                heff_drop(v_hb_24234);
                                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                              case TAG_Just: {
                                V v_lb_24235 = heff_field(v_b1_24233, 0);
                                heff_take_n(v_b1_24233, 1ULL, 1);
                                if (heff_intLt_c_lent(MK_INT(0LL), v_lb_24235, 1)) {
                                  V v_t_24240;
                                  if ((v_tag_24222 == ((int64_t)0ULL))) {
                                    V v_x_24238 = v_field_24223;
                                    V v_x12_24239 = v_field_24224;
                                    heff_drop(v_x12_24239);
                                    v_t_24240 = v_x_24238;
                                  } else {
                                    heff_drop(v_field_24223);
                                    heff_drop(v_field_24224);
                                    v_t_24240 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                  }
                                  return ({ V a_0 = v_lb_24235; V a_1 = v_hb_24234; V a_2 = v_t_24240; V r_ = (g_heff_2ecompile_2eranges_2edivPositive(a_0, a_1, a_2)); heff_drop(v_hb_24234); r_; });
                                } else {
                                  heff_drop(v_field_24223);
                                  heff_drop(v_field_24224);
                                  heff_drop(v_hb_24234);
                                  heff_drop(v_lb_24235);
                                  return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                }
                              }
                              default: return heff_nomatch(v_b1_24233);
                              }
                            }
                            default: return heff_nomatch(v_t_24232);
                            }
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str11), 2)) {
                          HeffT3 v_t_24242 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                          V v_t_24249;
                          {
                            V v_field_24244 = v_t_24242.f[1];
                            V v_field_24245 = v_t_24242.f[2];
                            int64_t v_tag_24243 = ((int64_t)v_t_24242.f[0]);
                            if ((v_tag_24243 == ((int64_t)0ULL))) {
                              V v_x_24247 = v_field_24244;
                              V v_x12_24248 = v_field_24245;
                              heff_drop(v_x12_24248);
                              v_t_24249 = v_x_24247;
                            } else {
                              heff_drop(v_field_24244);
                              heff_drop(v_field_24245);
                              v_t_24249 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                          }
                          HeffT3 v_t_24250 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                          V v_t_24257;
                          {
                            V v_field_24252 = v_t_24250.f[1];
                            V v_field_24253 = v_t_24250.f[2];
                            int64_t v_tag_24251 = ((int64_t)v_t_24250.f[0]);
                            if ((v_tag_24251 == ((int64_t)0ULL))) {
                              V v_x_24255 = v_field_24252;
                              V v_x12_24256 = v_field_24253;
                              heff_drop(v_x12_24256);
                              v_t_24257 = v_x_24255;
                            } else {
                              heff_drop(v_field_24252);
                              heff_drop(v_field_24253);
                              v_t_24257 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                            }
                          }
                          return ({ V a_0 = v_t_24249; V a_1 = v_t_24257; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_24249); r_; });
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str12), 2)) {
                            HeffT3 v_t_24259 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_241));
                            V v_t_24266;
                            {
                              V v_field_24261 = v_t_24259.f[1];
                              V v_field_24262 = v_t_24259.f[2];
                              int64_t v_tag_24260 = ((int64_t)v_t_24259.f[0]);
                              if ((v_tag_24260 == ((int64_t)0ULL))) {
                                V v_x_24264 = v_field_24261;
                                V v_x12_24265 = v_field_24262;
                                heff_drop(v_x12_24265);
                                v_t_24266 = v_x_24264;
                              } else {
                                heff_drop(v_field_24261);
                                heff_drop(v_field_24262);
                                v_t_24266 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            HeffT3 v_t_24267 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                            V v_t_24274;
                            {
                              V v_field_24269 = v_t_24267.f[1];
                              V v_field_24270 = v_t_24267.f[2];
                              int64_t v_tag_24268 = ((int64_t)v_t_24267.f[0]);
                              if ((v_tag_24268 == ((int64_t)0ULL))) {
                                V v_x_24272 = v_field_24269;
                                V v_x12_24273 = v_field_24270;
                                heff_drop(v_x12_24273);
                                v_t_24274 = v_x_24272;
                              } else {
                                heff_drop(v_field_24269);
                                heff_drop(v_field_24270);
                                v_t_24274 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                              }
                            }
                            return ({ V a_0 = v_t_24266; V a_1 = v_t_24274; V r_ = (g_heff_2ecompile_2eranges_2emodR(a_0, a_1)); heff_drop(v_t_24266); r_; });
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str13), 2)) {
                              return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str14), 2)) {
                                return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str15), 2)) {
                                  return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(4611686018427387903LL)})});
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2eprimRange_str16), 2)) {
                                    return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(-1LL)}), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(255LL)})});
                                  } else {
                                    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2eprimRange(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2enonZero_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enonZero_entry, 1, 0};

V g_heff_2ecompile_2eranges_2enonZero(V v_r_240) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    switch (heff_tag_of(v_r_240)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_hi_242 = heff_field(v_r_240, 1);
      switch (heff_tag_of(v_hi_242)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_a_243 = heff_field(v_hi_242, 0);
        return heff_intLt_lent(v_a_243, MK_INT(0LL), 2);
      }
      default: return heff_nomatch(v_hi_242);
      }
    }
    default: return heff_nomatch(v_r_240);
    }
  }
  case TAG_Within: {
    V v_lo_244 = heff_field(v_r_240, 0);
    switch (heff_tag_of(v_lo_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_r_240)) {
      case TAG_Unreached: {
        return NTAG(TAG_False);
      }
      case TAG_Within: {
        V v_hi_247 = heff_field(v_r_240, 1);
        switch (heff_tag_of(v_hi_247)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_a_248 = heff_field(v_hi_247, 0);
          return heff_intLt_lent(v_a_248, MK_INT(0LL), 2);
        }
        default: return heff_nomatch(v_hi_247);
        }
      }
      default: return heff_nomatch(v_r_240);
      }
    }
    case TAG_Just: {
      V v_a_249 = heff_field(v_lo_244, 0);
      if (heff_intLt_c_lent(MK_INT(0LL), v_a_249, 1)) {
        return NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_r_240)) {
        case TAG_Unreached: {
          return NTAG(TAG_False);
        }
        case TAG_Within: {
          V v_hi_2412 = heff_field(v_r_240, 1);
          switch (heff_tag_of(v_hi_2412)) {
          case TAG_Nothing: {
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            V v_a_2413 = heff_field(v_hi_2412, 0);
            return heff_intLt_lent(v_a_2413, MK_INT(0LL), 2);
          }
          default: return heff_nomatch(v_hi_2412);
          }
        }
        default: return heff_nomatch(v_r_240);
        }
      }
    }
    default: return heff_nomatch(v_lo_244);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2enonZero(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2enatural_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enatural_entry, 1, 0};

V g_heff_2ecompile_2eranges_2enatural(V v_rs_240) {
top: ;
  HeffT3 v_t_241 = (g_list_2edrop_24cpr(MK_INT(0LL), v_rs_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    V v_t_248;
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_243;
      V v_x12_247 = v_field_244;
      heff_drop(v_x12_247);
      v_t_248 = v_x_246;
    } else {
      heff_drop(v_field_243);
      heff_drop(v_field_244);
      v_t_248 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_lo_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 2);
      switch (heff_tag_of(v_lo_249)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_lo_249, 0);
        heff_take_n(v_lo_249, 1ULL, 1);
        if (heff_intLe_c(MK_INT(0LL), v_a_2411)) {
          HeffT3 v_t_2413 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_240));
          {
            V v_field_2415 = v_t_2413.f[1];
            V v_field_2416 = v_t_2413.f[2];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            V v_t_2420;
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2415;
              V v_x12_2419 = v_field_2416;
              heff_drop(v_x12_2419);
              v_t_2420 = v_x_2418;
            } else {
              heff_drop(v_field_2415);
              heff_drop(v_field_2416);
              v_t_2420 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
            }
            switch (heff_tag_of(v_t_2420)) {
            case TAG_Unreached: {
              return NTAG(TAG_False);
            }
            case TAG_Within: {
              V v_lo_2421 = heff_field(v_t_2420, 0);
              heff_take_n(v_t_2420, 1ULL, 2);
              switch (heff_tag_of(v_lo_2421)) {
              case TAG_Nothing: {
                return NTAG(TAG_False);
              }
              case TAG_Just: {
                V v_a_2423 = heff_field(v_lo_2421, 0);
                heff_take_n(v_lo_2421, 1ULL, 1);
                return heff_intLt(MK_INT(0LL), v_a_2423);
              }
              default: return heff_nomatch(v_lo_2421);
              }
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_lo_249);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2enatural(a0); heff_drop(a0); return r;
}

static V g_heff_2ecompile_2eranges_2eemptyEnv_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptyEnv_st;
static V g_heff_2ecompile_2eranges_2eemptyEnv_init(void) {
  return heff_rec_n(2, shape_ranges__tests, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptyEnv_st)) return g_heff_2ecompile_2eranges_2eemptyEnv_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptyEnv_val, &g_heff_2ecompile_2eranges_2eemptyEnv_st, g_heff_2ecompile_2eranges_2eemptyEnv_init);
}
Clo g_heff_2ecompile_2eranges_2ewithTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewithTest_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewithTest(V v_env_240, V v_x_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EGlobal: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ELam: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EApp: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ELet: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ERecord: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EProj: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_ETag: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EMatch: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EPrim: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_242, 0);
    V v_e2_2425 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e2_2425)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      return v_env_240;
    }
    case TAG_Cons: {
      V v_a_2426 = heff_field(v_e2_2425, 0);
      V v_e22_2427 = heff_field(v_e2_2425, 1);
      switch (heff_tag_of(v_e22_2427)) {
      case TAG_Nil: {
        heff_drop(v_x_241);
        return v_env_240;
      }
      case TAG_Cons: {
        V v_b_2428 = heff_field(v_e22_2427, 0);
        V v_e222_2429 = heff_field(v_e22_2427, 1);
        switch (heff_tag_of(v_e222_2429)) {
        case TAG_Nil: {
          V v_t_2430 = (g_heff_2ecompile_2eranges_2eisComparison(heff_dup(v_p_2424)));
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop(v_t_2430);
            V v_t_2431 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 1), v_x_241, heff_tag_n(TAG_MkTest, 3, (V[]){heff_dup(v_p_2424), heff_dup(v_a_2426), heff_dup(v_b_2428)})));
            return ({ V rv_1 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_env_240, 1ULL, 2, shape_ranges__tests, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          } else {
            heff_drop(v_x_241);
            heff_drop(v_t_2430);
            return v_env_240;
          }
        }
        case TAG_Cons: {
          heff_drop(v_x_241);
          return v_env_240;
        }
        default: return heff_nomatch(v_e222_2429);
        }
      }
      default: return heff_nomatch(v_e22_2427);
      }
    }
    default: return heff_nomatch(v_e2_2425);
    }
  }
  case TAG_ECall: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EInt: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFloat: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EStr: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EBytes: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFixed: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFloat32: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  case TAG_EFix: {
    heff_drop(v_x_241);
    return v_env_240;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2ewithTest(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eranges_2egatherGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherGo_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egatherGo(V v_c_240, V v_env_241, V v_st_242, V v_e_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eranges_2egatherGo_24cpr(v_c_240, v_env_241, v_st_242, v_e_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkSeen, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eranges_2egatherGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egatherGo(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2eranges_2ewalkGo_24cpr(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_f_249;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        v_f_249 = v_x_248;
      } else {
        heff_drop(v_field_246);
        v_f_249 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return ((HeffT2){{v_f_249, heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_x_243})}});
  }
  case TAG_EGlobal: {
    V v_g_2410 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_c_240, 1, 3); V a_1 = v_g_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_f_2416;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2413;
        v_f_2416 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2415)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2415})});
      } else {
        heff_drop(v_field_2413);
        v_f_2416 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
    }
    return ((HeffT2){{v_f_2416, heff_tag_at_n(v_ru_24e_242_24EGlobal, TAG_EGlobal, 1, (V[]){v_g_2410})}});
  }
  case TAG_ELam: {
    V v_xs_2417 = heff_field(v_e_242, 0);
    V v_b_2418 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2419 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, v_env_241, v_b_2418));
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_field_2421 = v_t_2419.f[1];
      V v_r_2422 = v_field_2420;
      heff_drop(v_r_2422);
      V v_e_2423 = v_field_2421;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_2417, v_e_2423})}});
    }
  }
  case TAG_EApp: {
    V v_f_2424 = heff_field(v_e_242, 0);
    V v_args_2425 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2427 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2426, v_env_241, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_2424), v_args_2425})));
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_rs_2430 = v_field_2428;
      heff_drop(v_rs_2430);
      V v_es_2431 = v_field_2429;
      V v_f_2434;
      switch (heff_tag_of(v_es_2431)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24e_242_24EApp, 2);
        v_f_2434 = v_f_2424;
        break;
      }
      case TAG_Cons: {
        V v_g_2432 = heff_field(v_es_2431, 0);
        V v_args_2433 = heff_field(v_es_2431, 1);
        heff_take_n(v_es_2431, 3ULL, 2);
        heff_drop(v_f_2424);
        v_f_2434 = heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_g_2432, v_args_2433});
        break;
      }
      default: heff_nomatch(v_es_2431);
      }
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_f_2434}});
    }
  }
  case TAG_ELet: {
    V v_x_2435 = heff_field(v_e_242, 0);
    V v_a_2436 = heff_field(v_e_242, 1);
    V v_b_2437 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2438 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_a_2436)));
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_r_2441 = v_field_2439;
      V v_e_2442 = v_field_2440;
      V v_t_2443 = (g_heff_2ecompile_2eranges_2ewithRange(v_env_241, heff_dup(v_x_2435), v_r_2441));
      V v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = heff_dup(v_x_2435); V a_2 = v_a_2436; V r_ = (g_heff_2ecompile_2eranges_2ewithTest(a_0, a_1, a_2)); heff_drop(v_a_2436); r_; });
      HeffT2 v_t_2445 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, v_t_2444, v_b_2437));
      {
        V v_field_2446 = v_t_2445.f[0];
        V v_field_2447 = v_t_2445.f[1];
        V v_r_2448 = v_field_2446;
        V v_e_2449 = v_field_2447;
        return ((HeffT2){{v_r_2448, heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2435, v_e_2442, v_e_2449})}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2450 = heff_field(v_e_242, 0);
    V v_ts_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    V v_t_2453 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2450)));
    HeffT2 v_t_2454 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2452, v_env_241, v_t_2453));
    {
      V v_field_2455 = v_t_2454.f[0];
      V v_field_2456 = v_t_2454.f[1];
      V v_rs_2457 = v_field_2455;
      heff_drop(v_rs_2457);
      V v_es_2458 = v_field_2456;
      V v_t_2459 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2450, v_es_2458));
      V v_f_2460 = heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2459, v_ts_2451});
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_f_2460}});
    }
  }
  case TAG_EProj: {
    V v_a_2461 = heff_field(v_e_242, 0);
    V v_l_2462 = heff_field(v_e_242, 1);
    V v_sh_2463 = heff_field(v_e_242, 2);
    V v_t_2464 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    HeffT2 v_t_2465 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, v_env_241, v_a_2461));
    {
      V v_field_2466 = v_t_2465.f[0];
      V v_field_2467 = v_t_2465.f[1];
      V v_r_2468 = v_field_2466;
      heff_drop(v_r_2468);
      V v_e_2469 = v_field_2467;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_2469, v_l_2462, v_sh_2463, v_t_2464})}});
    }
  }
  case TAG_ETag: {
    V v_t_2470 = heff_field(v_e_242, 0);
    V v_args_2471 = heff_field(v_e_242, 1);
    V v_ts_2472 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2474 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2473, v_env_241, v_args_2471));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_rs_2477 = v_field_2475;
      heff_drop(v_rs_2477);
      V v_es_2478 = v_field_2476;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2470, v_es_2478, v_ts_2472})}});
    }
  }
  case TAG_EMatch: {
    V v_s_2479 = heff_field(v_e_242, 0);
    V v_arms_2480 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2481 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(heff_dup(v_c_240), heff_dup(v_env_241), heff_dup(v_s_2479)));
    {
      V v_field_2482 = v_t_2481.f[0];
      V v_field_2483 = v_t_2481.f[1];
      V v_r_2484 = v_field_2482;
      heff_drop(v_r_2484);
      V v_e_2485 = v_field_2483;
      V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
      V v_t_2487 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), v_s_2479));
      HeffT2 v_t_2488 = ({ V a_0 = v_c_240; V a_1 = v_t_2486; V a_2 = v_env_241; V a_3 = v_t_2487; V a_4 = v_arms_2480; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2487); r_; });
      {
        V v_field_2489 = v_t_2488.f[0];
        V v_field_2490 = v_t_2488.f[1];
        V v_r_2491 = v_field_2489;
        V v_arms_2492 = v_field_2490;
        return ((HeffT2){{v_r_2491, heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_e_2485, v_arms_2492})}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EPrimCall: {
    V v_p_2494 = heff_field(v_e_242, 0);
    V v_args_2495 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_2497 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_2496, v_env_241, v_args_2495));
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_field_2499 = v_t_2497.f[1];
      V v_rs_24100 = v_field_2498;
      V v_es_24101 = v_field_2499;
      V v_f_24102 = (g_heff_2ecompile_2eranges_2eprimRange(v_p_2494, v_rs_24100));
      V v_t_24103 = (g_heff_2ecompile_2eranges_2eprimRange(v_p_2494, v_rs_24100));
      HeffT2 v_t_24104 = ({ V a_0 = v_p_2494; V a_1 = v_rs_24100; V a_2 = v_t_24103; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewordOf_24cpr(a_0, a_1, a_2)); heff_drop(v_rs_24100); r_; });
      V v_t_24109;
      {
        V v_field_24106 = v_t_24104.f[1];
        int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
        if ((v_tag_24105 == ((int64_t)0ULL))) {
          heff_drop(v_p_2494);
          V v_x_24108 = v_field_24106;
          v_t_24109 = v_x_24108;
        } else {
          heff_drop(v_field_24106);
          v_t_24109 = v_p_2494;
        }
      }
      V v_f_24110 = heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_t_24109, v_es_24101});
      return ((HeffT2){{v_f_24102, v_f_24110}});
    }
  }
  case TAG_ECall: {
    V v_g_24111 = heff_field(v_e_242, 0);
    V v_args_24112 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_24113 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){v_c_240}));
    HeffT2 v_t_24114 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_t_24113, v_env_241, v_args_24112));
    {
      V v_field_24115 = v_t_24114.f[0];
      V v_field_24116 = v_t_24114.f[1];
      V v_rs_24117 = v_field_24115;
      heff_drop(v_rs_24117);
      V v_es_24118 = v_field_24116;
      return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_24111, v_es_24118})}});
    }
  }
  case TAG_EInt: {
    V v_n_24119 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EInt = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    V v_t_24120 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_24119)}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_24119)})});
    return ((HeffT2){{v_t_24120, heff_tag_at_n(v_ru_24e_242_24EInt, TAG_EInt, 1, (V[]){v_n_24119})}});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EStr: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  case TAG_EFix: {
    heff_drop_rec(v_c_240, 3);
    heff_drop_rec(v_env_241, 2);
    return ((HeffT2){{heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2eranges_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, heff_get_n(v_d_241, 0, 3), v_t_247));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eranges_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2ewidenHigh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewidenHigh_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewidenHigh(V v_x1_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Nothing: {
      return v_x3_242;
    }
    case TAG_Just: {
      V v_b_243 = heff_field(v_b_241, 0);
      heff_take_n(v_b_241, 1ULL, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nothing: {
        heff_drop(v_b_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_d_244 = heff_dup(heff_field(v_x3_242, 0));
        if (heff_intLt_c(v_b_243, v_d_244)) {
          heff_drop_tag(v_x3_242, 1);
          return NTAG(TAG_Nothing);
        } else {
          return v_x3_242;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_Just: {
    V v_ms_246 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_ms_246);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      switch (heff_tag_of(v_b_241)) {
      case TAG_Nothing: {
        return v_x3_242;
      }
      case TAG_Just: {
        V v_b_247 = heff_field(v_b_241, 0);
        heff_take_n(v_b_241, 1ULL, 1);
        switch (heff_tag_of(v_x3_242)) {
        case TAG_Nothing: {
          heff_drop(v_b_247);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_d_248 = heff_dup(heff_field(v_x3_242, 0));
          if (heff_intLt_c(v_b_247, v_d_248)) {
            heff_drop_tag(v_x3_242, 1);
            return NTAG(TAG_Nothing);
          } else {
            return v_x3_242;
          }
        }
        default: return heff_nomatch(v_x3_242);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      switch (heff_tag_of(v_b_241)) {
      case TAG_Nothing: {
        heff_drop(v_ms_246);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_d_2410});
      }
      case TAG_Just: {
        V v_b_2411 = heff_field(v_b_241, 0);
        heff_take_n(v_b_241, 1ULL, 1);
        if (heff_intLt_c_lent(v_b_2411, v_d_2410, 1)) {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          V v_t_2413 = ({ V a_0 = v_ms_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_ms_246); r_; });
          return ({ V a_0 = v_d_2410; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2413; V r_ = (g_list_2efoldl_24s1719254312x1333482082(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
        } else {
          heff_drop(v_ms_246);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_d_2410});
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eranges_2ewidenHigh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewidenHigh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2ewiden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewiden_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewiden(V v_ms_240, V v_o_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_Unreached: {
    heff_drop(v_ms_240);
    return v_n_242;
  }
  case TAG_Within: {
    V v_a_243 = heff_field(v_o_241, 0);
    V v_b_244 = heff_field(v_o_241, 1);
    V v_ru_24o_241_24Within = heff_take_reuse_n(v_o_241, 3ULL, 2);
    switch (heff_tag_of(v_n_242)) {
    case TAG_Unreached: {
      heff_drop(v_ms_240);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24o_241_24Within, 2);
      return v_n_242;
    }
    case TAG_Within: {
      V v_c_245 = heff_field(v_n_242, 0);
      V v_d_246 = heff_field(v_n_242, 1);
      heff_take_n(v_n_242, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eranges_2ewidenLow(heff_dup(v_ms_240), v_a_243, v_c_245));
      V v_t_248 = (g_heff_2ecompile_2eranges_2ewidenHigh(v_ms_240, v_b_244, v_d_246));
      return heff_tag_at_n(v_ru_24o_241_24Within, TAG_Within, 2, (V[]){v_t_247, v_t_248});
    }
    default: return heff_nomatch(v_n_242);
    }
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eranges_2ewiden_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewiden(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str0, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str1, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str2, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str3, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str4, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str5, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str6, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str7, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str8, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2eintOps_str9, 6, "intAdd");

static V g_heff_2ecompile_2eranges_2eintOps_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eintOps_st;
static V g_heff_2ecompile_2eranges_2eintOps_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eranges_2eintOps_str9), v_t_244});
}
V g_heff_2ecompile_2eranges_2eintOps_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eintOps_st)) return g_heff_2ecompile_2eranges_2eintOps_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eintOps_val, &g_heff_2ecompile_2eranges_2eintOps_st, g_heff_2ecompile_2eranges_2eintOps_init);
}
Clo g_heff_2ecompile_2eranges_2enamesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enamesW_entry, 2, 0};

V g_heff_2ecompile_2eranges_2enamesW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_245 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_x_244, NTAG(TAG_MkUnit)));
      V t_0 = v_t_245;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2416, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI(v_args_2427, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2428;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2enamesW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2egivenFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egivenFrom_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egivenFrom(V v_g_240, V v_i_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_args_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_g_240), heff_dup(v_i_241)}), v_x_246});
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      heff_take_n(v_x41_244, 0ULL, 4);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      heff_take_n(v_x41_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_acc_242;
      V t_3 = v_args_245;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egivenFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2eroundOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2eroundOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eroundOf_entry, 4, 0};

V g_heff_2ecompile_2eranges_2eroundOf(V v_consts_240, V v_sc_241, V v_s0_242, V v_keys_243) {
top: ;
  V v_t_244 = ({ V rv_1 = heff_dup(g_std_2emap_2eempty_get()); V rr_ = heff_rec_reuse_nf(v_s0_242, 5ULL, 3, shape_fix__dirty__gathered, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2eroundOf_lam0, 2, 2, (V[]){v_sc_241, v_consts_240}), v_t_244, v_keys_243));
}
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2eroundOf(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2eroundOf_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_k_246 = args[1];
  V v_sc_241 = heff_env(self)[0];
  V v_consts_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_sc_241, 0), v_k_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_d_2411 = v_field_249;
      HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2416 = v_field_2414;
          heff_drop(v_x_2416);
          V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_s_245, 0)), 0, 3);
          HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_k_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
          V v_t_2425;
          {
            V v_field_2420 = v_t_2418.f[1];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_s_245, 0)), 0, 3);
            V v_t_2424 = heff_bool(((v_tag_2419 == ((int64_t)0ULL)) && ({ V v_x_2423 = heff_dup(v_field_2420); int c_ = 1; heff_drop(v_x_2423); c_; })));
            heff_drop(v_field_2420);
            v_t_2425 = heff_rec_n(3, shape_params__consts__marking, (V[]){v_t_2421, v_consts_240, v_t_2424});
          }
          V v_t_2426 = (g_heff_2ecompile_2eranges_2egatherDef(v_t_2425, v_d_2411));
          return (g_heff_2ecompile_2eranges_2eabsorb(v_k_246, v_s_245, v_t_2426));
        } else {
          heff_drop(v_k_246);
          heff_drop(v_consts_240);
          heff_drop(v_d_2411);
          heff_drop(v_field_2414);
          return v_s_245;
        }
      }
    } else {
      heff_drop(v_k_246);
      heff_drop_rec(v_sc_241, 4);
      heff_drop(v_consts_240);
      heff_drop(v_field_249);
      return v_s_245;
    }
  }
}
V g_heff_2ecompile_2eranges_2erangedFns_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangedFns_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedFns_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erangedFns(V v_consts_240, V v_defs_241, V v_scans_242, V v_params_243) {
top: ;
  V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2erangedFns_lam0, 2, 2, (V[]){heff_dup(v_scans_242), heff_dup(v_params_243)}), heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), v_defs_241));
  HEFF_LAST return g_heff_2ecompile_2eranges_2erangedIn(v_consts_240, v_defs_241, v_params_243, v_t_2412);
}
V g_heff_2ecompile_2eranges_2erangedFns_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2erangedFns(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2erangedFns_lam0(V self, V *args) {
  V v_sc_244 = args[0];
  V v_d_245 = args[1];
  V v_scans_242 = heff_env(self)[0];
  V v_params_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_scans_242; V a_1 = heff_rfield(v_d_245, 0); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_scans_242); r_; });
  V v_t_2411;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_248;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_248);
      v_t_2411 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
    }
  }
  return ({ V a_0 = v_params_243; V a_1 = v_sc_244; V a_2 = v_d_245; V a_3 = v_t_2411; V r_ = (g_heff_2ecompile_2eranges_2escopeOne(a_0, a_1, a_2, a_3)); heff_drop(v_params_243); r_; });
}
Clo g_heff_2ecompile_2eranges_2erangedScans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedScans_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erangedScans(V v_consts_240, V v_defs_241, V v_scans_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_scans_242, NTAG(TAG_Nil)));
  V v_esc_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s326537207x242980421(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_fns_245 = ({ V a_0 = v_esc_244; V a_1 = v_scans_242; V a_2 = heff_dup(g_std_2emap_2eempty_get()); V a_3 = v_defs_241; V r_ = (g_list_2efoldl_24s26403090x581733227(a_0, a_1, a_2, a_3)); heff_drop(v_esc_244); r_; });
  V v_t_246 = (g_std_2emap_2etoListOnto(v_fns_245, NTAG(TAG_Nil)));
  V v_t_247 = (g_list_2ekeepIf_24s1606737509x658906972(v_t_246));
  V v_t_248 = (g_std_2emap_2emapValues_24s471823439x1830654496(heff_dup(v_fns_245)));
  V v_t_249 = ({ V a_0 = v_t_247; V a_1 = MK_INT(64LL); V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eranges_2emattering(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2410 = ({ V a_0 = v_fns_245; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2estartParams(a_0, a_1)); heff_drop(v_fns_245); heff_drop(v_t_249); r_; });
  return (g_heff_2ecompile_2eranges_2erangedFns(v_consts_240, v_defs_241, v_scans_242, v_t_2410));
}
V g_heff_2ecompile_2eranges_2erangedScans_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2erangedScans(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2erangeProgram_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangeProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangeProgram_entry, 1, 0};

V g_heff_2ecompile_2eranges_2erangeProgram(V v_defs_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1068175575x1869083571(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_ar_242 = (g_list_2efoldl_24s1810610888x1691479932(heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2erangeProgram_lam0, 2, 1, (V[]){v_ar_242}), heff_dup(g_std_2emap_2eempty_get()), v_defs_240));
  return ({ V a_0 = v_t_241; V a_1 = v_defs_240; V a_2 = v_t_247; V r_ = (g_heff_2ecompile_2eranges_2erangedScans(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
}
V g_heff_2ecompile_2eranges_2erangeProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erangeProgram(a[0]);
}
V g_heff_2ecompile_2eranges_2erangeProgram_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_d_244 = args[1];
  V v_ar_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_244, 2), NTAG(TAG_Nil)});
  V v_t_246 = ({ V a_0 = v_ar_242; V a_1 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get()); V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2eranges_2escanW(a_0, a_1, a_2)); heff_drop(v_ar_242); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_243, heff_get_n(v_d_244, 0, 3), v_t_246));
}