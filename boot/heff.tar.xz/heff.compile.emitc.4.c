// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_ctype 296362551
#define LBL_ems 310085
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_workers 1757018875
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2egetterOf(V, V);
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egetterOf_clo;
V g_heff_2ecompile_2eemitc_2egivesUp(V, V);
V g_heff_2ecompile_2eemitc_2egivesUp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivesUp_clo;
V g_heff_2ecompile_2eemitc_2eglobalGet(V, V);
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elendingPrims_get(void);
V g_heff_2ecompile_2eemitc_2elentOperand(V, V);
V g_heff_2ecompile_2eemitc_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentOperand_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2elibmNames_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2erelU(V, V);
V g_heff_2ecompile_2eemitc_2erelU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelU_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etakeLines(V, V);
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeLines_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_list_2eall_24s1909236649x7702533(V);
V g_list_2eall_24s1909236649x7702533_entry(V self, V *a);
extern Clo g_list_2eall_24s1909236649x7702533_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1177057410x67789151(V, V);
V g_list_2eany_24s1177057410x67789151_entry(V self, V *a);
extern Clo g_list_2eany_24s1177057410x67789151_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24f316845240x1272469554(V, V, V, V);
V g_list_2efoldl_24f316845240x1272469554_entry(V self, V *a);
extern Clo g_list_2efoldl_24f316845240x1272469554_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s96111113x2107485159(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s96111113x2107485159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96111113x2107485159_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1382928954x1260344933(V, V, V);
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s353858844x950951807(V, V, V, V);
V g_list_2emap_24s353858844x950951807_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s588563787x236154271(V, V, V, V);
V g_list_2emap_24s588563787x236154271_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eshowInt_get(void);
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2415));
    V v_x2_2420 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_ls_2417, v_ls2_2422));
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, v_t_2423});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2424 = heff_field(v_x1_240, 0);
    V v_l_2425 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2428 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2424));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_ts_2429 = heff_field(v_x2_2428, 0);
      V v_ls2_2430 = heff_field(v_x2_2428, 1);
      V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_2425, NTAG(TAG_Nil)});
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ls2_2430));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2429, v_t_2432});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  case TAG_ETag: {
    V v_t_2433 = heff_field(v_x1_240, 0);
    V v_as_2434 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2434));
    V v_x2_2438 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2436, v_t_2437));
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_MkPair: {
      V v_ts2_2439 = heff_field(v_x2_2438, 0);
      V v_ls_2440 = heff_field(v_x2_2438, 1);
      V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2441, v_ts2_2439));
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_t_2442, v_ls_2440});
    }
    default: return heff_nomatch(v_x2_2438);
    }
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_x1_240, 0);
    V v_arms_2444 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2445 = (g_list_2emap_24s1009200955x251267316(heff_dup(v_arms_2444)));
    V v_t_2446 = (g_list_2emap_24s60612435x257154841(v_arms_2444));
    V v_es_2447 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2443, v_t_2446});
    V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2447));
    V v_x2_2450 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2448, v_t_2449));
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_MkPair: {
      V v_ts2_2451 = heff_field(v_x2_2450, 0);
      V v_ls_2452 = heff_field(v_x2_2450, 1);
      V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
      V v_t_2453 = (g_prelude_2e_2b_2b(v_ts_2445, v_ts2_2451));
      return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_t_2453, v_ls_2452});
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2457 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2456));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2457, v_t_2458));
  }
  case TAG_ECall: {
    V v_as_2460 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2461 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2460));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2461, v_t_2462));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength_lent(v_text_240, 0))) {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt_lent(v_text_240, v_i_242, 0)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_244);
      if (heff_intEq_c(heff_strByteAt_lent(v_text_240, v_i_242, 0), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 5, "((V)&");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str1)));
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), v_t_244);
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_247 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str2), v_t_247));
  V v_t_249 = heff_intShow(heff_strLength_lent(v_str_241, 0));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str6), heff_strAppend(v_t_249, v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str7), heff_strAppend(v_t_248, v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_mac_240, v_t_2413)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_246; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str8), v_t_245), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str0, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str1, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str2, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str3, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str4, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str5, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str6, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str7, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str8, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str9, 3, "log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str10, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str11, 3, "exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str12, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str13, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str14, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str15, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str16, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str17, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str18, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str19, 3, "tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str20, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str21, 3, "cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str22, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str23, 3, "sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str24, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str25, 4, "sqrt");

static V g_heff_2ecompile_2eemitc_2elibmNames_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elibmNames_st;
static V g_heff_2ecompile_2eemitc_2elibmNames_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str0), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str2), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str4), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str6), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str8), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str10), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str12), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str14), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str16), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str18), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str19)}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str20), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str21)}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str22), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str23)}), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str24), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str25)}), v_t_2411});
}
V g_heff_2ecompile_2eemitc_2elibmNames_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elibmNames_st)) return g_heff_2ecompile_2eemitc_2elibmNames_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elibmNames_val, &g_heff_2ecompile_2eemitc_2elibmNames_st, g_heff_2ecompile_2eemitc_2elibmNames_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str0, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str1, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str2, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str3, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str4, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str5, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str6, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str7, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str8, 8, "strSlice");

static V g_heff_2ecompile_2eemitc_2elendingPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elendingPrims_st;
static V g_heff_2ecompile_2eemitc_2elendingPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str8), v_t_243})});
}
V g_heff_2ecompile_2eemitc_2elendingPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elendingPrims_st)) return g_heff_2ecompile_2eemitc_2elendingPrims_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elendingPrims_val, &g_heff_2ecompile_2eemitc_2elendingPrims_st, g_heff_2ecompile_2eemitc_2elendingPrims_init);
}
Clo g_heff_2ecompile_2eemitc_2egivesUp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2egivesUp_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2egivesUp(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_y_242 = heff_field(v_x2_241, 0);
    return heff_strEq_lent(v_x_240, v_y_242, 1);
  }
  case TAG_RDup: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RClo: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2egivesUp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2egivesUp(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 2, "_c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str65, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str66, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str67, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str68, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str69, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str70, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str71, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str72, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str73, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str74, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str75, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str76, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str77, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str78, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str79, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str80, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str81, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str82, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str83, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str84, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str85, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str86, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str87, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str88, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str89, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str90, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str91, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str93, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str94, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str95, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str96, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str97, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str98, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str99, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str100, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str101, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str102, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str103, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str104, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str105, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str106, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str107, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str108, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str109, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str110, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str111, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str112, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str113, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str114, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str115, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str116, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str117, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str118, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str119, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str120, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str121, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str122, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str123, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str124, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str125, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str126, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str127, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str128, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str129, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str130, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str131, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str132, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str133, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str134, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str135, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str136, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str138, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str140, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str141, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str142, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str143, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str144, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str145, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str146, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str147, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str148, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str149, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str150, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str151, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str152, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str153, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str154, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str155, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str156, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str157, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str158, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str159, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str160, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str161, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str162, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str163, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str164, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str165, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str166, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str167, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str168, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str169, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str170, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str171, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str172, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str173, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str174, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str175, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str176, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str177, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str178, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str179, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str180, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str182, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str183, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str184, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str185, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str186, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str187, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str188, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str189, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str190, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str191, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str192, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str193, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str194, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str195, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str196, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str197, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str198, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str199, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str200, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str201, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str202, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str203, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str204, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str205, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str206, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str207, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str208, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str209, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str210, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str211, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str212, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str213, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str214, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str215, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str216, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str217, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str218, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str219, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str220, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str221, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str222, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str223, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str224, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str225, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str226, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str227, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str228, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str229, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str230, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str231, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str232, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str233, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str234, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str235, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str236, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str238, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str239, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str240, 6, "c_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str241, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str242, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str243, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str244, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str245, 3, "({ ");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_p_244); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_249;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eall_24s1909236649x7702533(v_es_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2elentOperand_clo), 1, (V[]){heff_dup(v_es_245)}));
        v_t_249 = (g_list_2eany(v_t_248, v_es_245));
      } else {
        heff_drop(v_t_247);
        v_t_249 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_246);
      v_t_249 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_244, ((V)&g_heff_2ecompile_2eemitc_2etestC_str2), v_es_245));
    } else {
      heff_drop(v_t_249);
      V v_m_2410 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_245));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_2410, v_p_244});
    }
  }
  case TAG_CondRelU: {
    V v_p_2420 = heff_field(v_x2_241, 0);
    V v_es_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2422 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_2421));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2422, v_p_2420});
  }
  case TAG_CondBool: {
    V v_e_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2429 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2428}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2429});
  }
  case TAG_CondNot: {
    V v_c_2435 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2436 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2435));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2436});
  }
  case TAG_CondIf: {
    V v_a_2441 = heff_field(v_x2_241, 0);
    V v_b_2442 = heff_field(v_x2_241, 1);
    V v_x23_2443 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2443)) {
    case TAG_CondTrue: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_2444 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2444, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_2455 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 4, (V[]){v_m_2455, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_2473 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2473, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_2491 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 4, (V[]){v_m_2491, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24108 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam10, 1, 4, (V[]){v_m_24108, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24125 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam11, 1, 4, (V[]){v_m_24125, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24144 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam12, 1, 4, (V[]){v_m_24144, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24164 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam13, 1, 4, (V[]){v_m_24164, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondFalse: {
      V v_m_24180 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam14, 1, 3, (V[]){v_m_24180, v_k_240, v_b_2442});
    }
    case TAG_CondRel: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24193 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam15, 1, 3, (V[]){v_m_24193, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24204 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam16, 1, 4, (V[]){v_m_24204, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24222 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam17, 1, 4, (V[]){v_m_24222, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24240 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam18, 1, 4, (V[]){v_m_24240, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24257 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam19, 1, 4, (V[]){v_m_24257, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24274 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam20, 1, 4, (V[]){v_m_24274, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24293 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam21, 1, 4, (V[]){v_m_24293, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24313 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam22, 1, 4, (V[]){v_m_24313, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondRelU: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24331 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam23, 1, 3, (V[]){v_m_24331, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24342 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam24, 1, 4, (V[]){v_m_24342, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24360 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam25, 1, 4, (V[]){v_m_24360, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24378 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam26, 1, 4, (V[]){v_m_24378, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24395 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam27, 1, 4, (V[]){v_m_24395, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24412 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam28, 1, 4, (V[]){v_m_24412, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24431 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam29, 1, 4, (V[]){v_m_24431, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24451 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam30, 1, 4, (V[]){v_m_24451, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondBool: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24468 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam31, 1, 3, (V[]){v_m_24468, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24479 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam32, 1, 4, (V[]){v_m_24479, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24497 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam33, 1, 4, (V[]){v_m_24497, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24515 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam34, 1, 4, (V[]){v_m_24515, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24532 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam35, 1, 4, (V[]){v_m_24532, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24549 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam36, 1, 4, (V[]){v_m_24549, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24568 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam37, 1, 4, (V[]){v_m_24568, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24588 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam38, 1, 4, (V[]){v_m_24588, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondNot: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24605 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam39, 1, 3, (V[]){v_m_24605, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24616 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam40, 1, 4, (V[]){v_m_24616, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24634 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam41, 1, 4, (V[]){v_m_24634, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24652 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam42, 1, 4, (V[]){v_m_24652, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24669 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam43, 1, 4, (V[]){v_m_24669, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24686 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam44, 1, 4, (V[]){v_m_24686, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24705 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam45, 1, 4, (V[]){v_m_24705, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24725 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam46, 1, 4, (V[]){v_m_24725, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondIf: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24744 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam47, 1, 3, (V[]){v_m_24744, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24755 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam48, 1, 4, (V[]){v_m_24755, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24773 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam49, 1, 4, (V[]){v_m_24773, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24791 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam50, 1, 4, (V[]){v_m_24791, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24808 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam51, 1, 4, (V[]){v_m_24808, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24825 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam52, 1, 4, (V[]){v_m_24825, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24844 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam53, 1, 4, (V[]){v_m_24844, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_24864 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam54, 1, 4, (V[]){v_m_24864, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    case TAG_CondLet: {
      switch (heff_tag_of(v_b_2442)) {
      case TAG_CondTrue: {
        V v_m_24884 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam55, 1, 3, (V[]){v_m_24884, v_k_240, v_x23_2443});
      }
      case TAG_CondFalse: {
        V v_m_24895 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam56, 1, 4, (V[]){v_m_24895, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRel: {
        V v_m_24913 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam57, 1, 4, (V[]){v_m_24913, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondRelU: {
        V v_m_24931 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam58, 1, 4, (V[]){v_m_24931, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondBool: {
        V v_m_24948 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam59, 1, 4, (V[]){v_m_24948, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondNot: {
        V v_m_24965 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam60, 1, 4, (V[]){v_m_24965, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondIf: {
        V v_m_24984 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam61, 1, 4, (V[]){v_m_24984, v_k_240, v_b_2442, v_x23_2443});
      }
      case TAG_CondLet: {
        V v_m_241004 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2441));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam62, 1, 4, (V[]){v_m_241004, v_k_240, v_b_2442, v_x23_2443});
      }
      default: return heff_nomatch(v_b_2442);
      }
    }
    default: return heff_nomatch(v_x23_2443);
    }
  }
  case TAG_CondLet: {
    V v_x_241020 = heff_field(v_x2_241, 0);
    V v_e_241021 = heff_field(v_x2_241, 1);
    V v_c_241022 = heff_field(v_x2_241, 2);
    V v_drops_241023 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_241024 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_241021}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam63, 1, 5, (V[]){v_m_241024, v_k_240, v_c_241022, v_x_241020, v_drops_241023});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etestC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x_2413, 0);
      V v_xs_2416 = heff_field(v_x_2413, 1);
      heff_take_n(v_x_2413, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str5), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2etestC_str6)));
    V v_x_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str7), v_p_244), v_t_2418);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_p_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_x_2427 = (g_heff_2ecompile_2eemitc_2erelU(v_p_2420, v_x_2425));
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str8), heff_strAppend(v_x_2432, ((V)&g_heff_2ecompile_2eemitc_2etestC_str9)));
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2434, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str10), v_x_2439), v_s_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    V v_m_2449 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_2450 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_s_2448}));
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_field(v_x2_2450, 0);
      V v_s_2452 = heff_field(v_x2_2450, 1);
      heff_take_n(v_x2_2450, 3ULL, 2);
      V v_t_2453 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str11), heff_strAppend(v_x_2451, ((V)&g_heff_2ecompile_2eemitc_2etestC_str12)));
      V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str13), heff_strAppend(v_x_2447, v_t_2453));
      return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){v_t_2454, v_s_2452});
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    V v_m_2460 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_s_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      V v_m_2464 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_s_2463}));
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_MkPair: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        V v_s_2467 = heff_field(v_x2_2465, 1);
        heff_take_n(v_x2_2465, 3ULL, 2);
        V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str14), heff_strAppend(v_x_2466, ((V)&g_heff_2ecompile_2eemitc_2etestC_str15)));
        V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str16), heff_strAppend(v_x_2462, v_t_2468));
        V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str17), heff_strAppend(v_x_2458, v_t_2469));
        return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){v_t_2470, v_s_2467});
      }
      default: return heff_nomatch(v_x2_2465);
      }
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_m_2478 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2479)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_field(v_x2_2479, 0);
      V v_s_2481 = heff_field(v_x2_2479, 1);
      heff_take_n(v_x2_2479, 3ULL, 2);
      V v_m_2482 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_2483 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2481}));
      switch (heff_tag_of(v_x2_2483)) {
      case TAG_MkPair: {
        V v_x_2484 = heff_field(v_x2_2483, 0);
        V v_s_2485 = heff_field(v_x2_2483, 1);
        heff_take_n(v_x2_2483, 3ULL, 2);
        V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str18), heff_strAppend(v_x_2484, ((V)&g_heff_2ecompile_2eemitc_2etestC_str19)));
        V v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str20), heff_strAppend(v_x_2480, v_t_2486));
        V v_t_2488 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str21), heff_strAppend(v_x_2476, v_t_2487));
        return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){v_t_2488, v_s_2485});
      }
      default: return heff_nomatch(v_x2_2483);
      }
    }
    default: return heff_nomatch(v_x2_2479);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_m_2496 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2495}));
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_s_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      V v_m_24100 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24101 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_s_2499}));
      switch (heff_tag_of(v_x2_24101)) {
      case TAG_MkPair: {
        V v_x_24102 = heff_field(v_x2_24101, 0);
        V v_s_24103 = heff_field(v_x2_24101, 1);
        heff_take_n(v_x2_24101, 3ULL, 2);
        V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str22), heff_strAppend(v_x_24102, ((V)&g_heff_2ecompile_2eemitc_2etestC_str23)));
        V v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str24), heff_strAppend(v_x_2498, v_t_24104));
        V v_t_24106 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str25), heff_strAppend(v_x_2494, v_t_24105));
        return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_t_24106, v_s_24103});
      }
      default: return heff_nomatch(v_x2_24101);
      }
    }
    default: return heff_nomatch(v_x2_2497);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args) {
  V v_s_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24110 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_s_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_s_24112 = heff_field(v_x2_24110, 1);
    V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
    V v_m_24113 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_s_24112}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      heff_take_n(v_x2_24114, 3ULL, 2);
      V v_m_24117 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24118 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_s_24116}));
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_MkPair: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        V v_s_24120 = heff_field(v_x2_24118, 1);
        heff_take_n(v_x2_24118, 3ULL, 2);
        V v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str26), heff_strAppend(v_x_24119, ((V)&g_heff_2ecompile_2eemitc_2etestC_str27)));
        V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str28), heff_strAppend(v_x_24115, v_t_24121));
        V v_t_24123 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str29), heff_strAppend(v_x_24111, v_t_24122));
        return heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_MkPair, 2, (V[]){v_t_24123, v_s_24120});
      }
      default: return heff_nomatch(v_x2_24118);
      }
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_m_24130 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_s_24129}));
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_s_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      V v_m_24134 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24135 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24133}));
      switch (heff_tag_of(v_x2_24135)) {
      case TAG_MkPair: {
        V v_x_24136 = heff_field(v_x2_24135, 0);
        V v_s_24137 = heff_field(v_x2_24135, 1);
        heff_take_n(v_x2_24135, 3ULL, 2);
        V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str30), heff_strAppend(v_x_24136, ((V)&g_heff_2ecompile_2eemitc_2etestC_str31)));
        V v_t_24139 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str32), heff_strAppend(v_x_24132, v_t_24138));
        V v_t_24140 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str33), heff_strAppend(v_x_24128, v_t_24139));
        return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){v_t_24140, v_s_24137});
      }
      default: return heff_nomatch(v_x2_24135);
      }
    }
    default: return heff_nomatch(v_x2_24131);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    V v_m_24149 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24150 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24148}));
    switch (heff_tag_of(v_x2_24150)) {
    case TAG_MkPair: {
      V v_x_24151 = heff_field(v_x2_24150, 0);
      V v_s_24152 = heff_field(v_x2_24150, 1);
      heff_take_n(v_x2_24150, 3ULL, 2);
      V v_m_24153 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24154 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_s_24152}));
      switch (heff_tag_of(v_x2_24154)) {
      case TAG_MkPair: {
        V v_x_24155 = heff_field(v_x2_24154, 0);
        V v_s_24156 = heff_field(v_x2_24154, 1);
        heff_take_n(v_x2_24154, 3ULL, 2);
        V v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str34), heff_strAppend(v_x_24155, ((V)&g_heff_2ecompile_2eemitc_2etestC_str35)));
        V v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str36), heff_strAppend(v_x_24151, v_t_24157));
        V v_t_24159 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), heff_strAppend(v_x_24147, v_t_24158));
        return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){v_t_24159, v_s_24156});
      }
      default: return heff_nomatch(v_x2_24154);
      }
    }
    default: return heff_nomatch(v_x2_24150);
    }
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args) {
  V v_s_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_s_24165}));
  switch (heff_tag_of(v_x2_24166)) {
  case TAG_MkPair: {
    V v_x_24167 = heff_field(v_x2_24166, 0);
    V v_s_24168 = heff_field(v_x2_24166, 1);
    V v_ru_24x2_24166_24MkPair = heff_take_reuse_n(v_x2_24166, 3ULL, 2);
    V v_m_24169 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_s_24168}));
    switch (heff_tag_of(v_x2_24170)) {
    case TAG_MkPair: {
      V v_x_24171 = heff_field(v_x2_24170, 0);
      V v_s_24172 = heff_field(v_x2_24170, 1);
      heff_take_n(v_x2_24170, 3ULL, 2);
      V v_m_24173 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24174 = heff_tr(heff_call(v_m_24173, 1, (V[]){v_s_24172}));
      switch (heff_tag_of(v_x2_24174)) {
      case TAG_MkPair: {
        V v_x_24175 = heff_field(v_x2_24174, 0);
        V v_s_24176 = heff_field(v_x2_24174, 1);
        heff_take_n(v_x2_24174, 3ULL, 2);
        V v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str38), heff_strAppend(v_x_24175, ((V)&g_heff_2ecompile_2eemitc_2etestC_str39)));
        V v_t_24178 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), heff_strAppend(v_x_24171, v_t_24177));
        V v_t_24179 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str41), heff_strAppend(v_x_24167, v_t_24178));
        return heff_tag_at_n(v_ru_24x2_24166_24MkPair, TAG_MkPair, 2, (V[]){v_t_24179, v_s_24176});
      }
      default: return heff_nomatch(v_x2_24174);
      }
    }
    default: return heff_nomatch(v_x2_24170);
    }
  }
  default: return heff_nomatch(v_x2_24166);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args) {
  V v_s_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_s_24181}));
  switch (heff_tag_of(v_x2_24182)) {
  case TAG_MkPair: {
    V v_x_24183 = heff_field(v_x2_24182, 0);
    V v_s_24184 = heff_field(v_x2_24182, 1);
    V v_ru_24x2_24182_24MkPair = heff_take_reuse_n(v_x2_24182, 3ULL, 2);
    V v_m_24185 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2442));
    V v_x2_24186 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_s_24184}));
    switch (heff_tag_of(v_x2_24186)) {
    case TAG_MkPair: {
      V v_x_24187 = heff_field(v_x2_24186, 0);
      V v_s_24188 = heff_field(v_x2_24186, 1);
      heff_take_n(v_x2_24186, 3ULL, 2);
      V v_t_24189 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str42), heff_strAppend(v_x_24187, ((V)&g_heff_2ecompile_2eemitc_2etestC_str43)));
      V v_t_24190 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str44), heff_strAppend(v_x_24183, v_t_24189));
      return heff_tag_at_n(v_ru_24x2_24182_24MkPair, TAG_MkPair, 2, (V[]){v_t_24190, v_s_24188});
    }
    default: return heff_nomatch(v_x2_24186);
    }
  }
  default: return heff_nomatch(v_x2_24182);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args) {
  V v_s_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_s_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_s_24197 = heff_field(v_x2_24195, 1);
    V v_ru_24x2_24195_24MkPair = heff_take_reuse_n(v_x2_24195, 3ULL, 2);
    V v_m_24198 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24199 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_s_24197}));
    switch (heff_tag_of(v_x2_24199)) {
    case TAG_MkPair: {
      V v_x_24200 = heff_field(v_x2_24199, 0);
      V v_s_24201 = heff_field(v_x2_24199, 1);
      heff_take_n(v_x2_24199, 3ULL, 2);
      V v_t_24202 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str45), heff_strAppend(v_x_24200, ((V)&g_heff_2ecompile_2eemitc_2etestC_str46)));
      V v_t_24203 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str47), heff_strAppend(v_x_24196, v_t_24202));
      return heff_tag_at_n(v_ru_24x2_24195_24MkPair, TAG_MkPair, 2, (V[]){v_t_24203, v_s_24201});
    }
    default: return heff_nomatch(v_x2_24199);
    }
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
    V v_m_24209 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24210 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_s_24208}));
    switch (heff_tag_of(v_x2_24210)) {
    case TAG_MkPair: {
      V v_x_24211 = heff_field(v_x2_24210, 0);
      V v_s_24212 = heff_field(v_x2_24210, 1);
      heff_take_n(v_x2_24210, 3ULL, 2);
      V v_m_24213 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24214 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_s_24212}));
      switch (heff_tag_of(v_x2_24214)) {
      case TAG_MkPair: {
        V v_x_24215 = heff_field(v_x2_24214, 0);
        V v_s_24216 = heff_field(v_x2_24214, 1);
        heff_take_n(v_x2_24214, 3ULL, 2);
        V v_t_24217 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str48), heff_strAppend(v_x_24215, ((V)&g_heff_2ecompile_2eemitc_2etestC_str49)));
        V v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str50), heff_strAppend(v_x_24211, v_t_24217));
        V v_t_24219 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str51), heff_strAppend(v_x_24207, v_t_24218));
        return heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_MkPair, 2, (V[]){v_t_24219, v_s_24216});
      }
      default: return heff_nomatch(v_x2_24214);
      }
    }
    default: return heff_nomatch(v_x2_24210);
    }
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args) {
  V v_s_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24224 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_s_24223}));
  switch (heff_tag_of(v_x2_24224)) {
  case TAG_MkPair: {
    V v_x_24225 = heff_field(v_x2_24224, 0);
    V v_s_24226 = heff_field(v_x2_24224, 1);
    V v_ru_24x2_24224_24MkPair = heff_take_reuse_n(v_x2_24224, 3ULL, 2);
    V v_m_24227 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24228 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_s_24226}));
    switch (heff_tag_of(v_x2_24228)) {
    case TAG_MkPair: {
      V v_x_24229 = heff_field(v_x2_24228, 0);
      V v_s_24230 = heff_field(v_x2_24228, 1);
      heff_take_n(v_x2_24228, 3ULL, 2);
      V v_m_24231 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24232 = heff_tr(heff_call(v_m_24231, 1, (V[]){v_s_24230}));
      switch (heff_tag_of(v_x2_24232)) {
      case TAG_MkPair: {
        V v_x_24233 = heff_field(v_x2_24232, 0);
        V v_s_24234 = heff_field(v_x2_24232, 1);
        heff_take_n(v_x2_24232, 3ULL, 2);
        V v_t_24235 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str52), heff_strAppend(v_x_24233, ((V)&g_heff_2ecompile_2eemitc_2etestC_str53)));
        V v_t_24236 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str54), heff_strAppend(v_x_24229, v_t_24235));
        V v_t_24237 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str55), heff_strAppend(v_x_24225, v_t_24236));
        return heff_tag_at_n(v_ru_24x2_24224_24MkPair, TAG_MkPair, 2, (V[]){v_t_24237, v_s_24234});
      }
      default: return heff_nomatch(v_x2_24232);
      }
    }
    default: return heff_nomatch(v_x2_24228);
    }
  }
  default: return heff_nomatch(v_x2_24224);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args) {
  V v_s_24241 = args[0];
  V v_m_24240 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24242 = heff_tr(heff_call(v_m_24240, 1, (V[]){v_s_24241}));
  switch (heff_tag_of(v_x2_24242)) {
  case TAG_MkPair: {
    V v_x_24243 = heff_field(v_x2_24242, 0);
    V v_s_24244 = heff_field(v_x2_24242, 1);
    V v_ru_24x2_24242_24MkPair = heff_take_reuse_n(v_x2_24242, 3ULL, 2);
    V v_m_24245 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24246 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_s_24244}));
    switch (heff_tag_of(v_x2_24246)) {
    case TAG_MkPair: {
      V v_x_24247 = heff_field(v_x2_24246, 0);
      V v_s_24248 = heff_field(v_x2_24246, 1);
      heff_take_n(v_x2_24246, 3ULL, 2);
      V v_m_24249 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24250 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_s_24248}));
      switch (heff_tag_of(v_x2_24250)) {
      case TAG_MkPair: {
        V v_x_24251 = heff_field(v_x2_24250, 0);
        V v_s_24252 = heff_field(v_x2_24250, 1);
        heff_take_n(v_x2_24250, 3ULL, 2);
        V v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str56), heff_strAppend(v_x_24251, ((V)&g_heff_2ecompile_2eemitc_2etestC_str57)));
        V v_t_24254 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str58), heff_strAppend(v_x_24247, v_t_24253));
        V v_t_24255 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str59), heff_strAppend(v_x_24243, v_t_24254));
        return heff_tag_at_n(v_ru_24x2_24242_24MkPair, TAG_MkPair, 2, (V[]){v_t_24255, v_s_24252});
      }
      default: return heff_nomatch(v_x2_24250);
      }
    }
    default: return heff_nomatch(v_x2_24246);
    }
  }
  default: return heff_nomatch(v_x2_24242);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args) {
  V v_s_24258 = args[0];
  V v_m_24257 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24259 = heff_tr(heff_call(v_m_24257, 1, (V[]){v_s_24258}));
  switch (heff_tag_of(v_x2_24259)) {
  case TAG_MkPair: {
    V v_x_24260 = heff_field(v_x2_24259, 0);
    V v_s_24261 = heff_field(v_x2_24259, 1);
    V v_ru_24x2_24259_24MkPair = heff_take_reuse_n(v_x2_24259, 3ULL, 2);
    V v_m_24262 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24263 = heff_tr(heff_call(v_m_24262, 1, (V[]){v_s_24261}));
    switch (heff_tag_of(v_x2_24263)) {
    case TAG_MkPair: {
      V v_x_24264 = heff_field(v_x2_24263, 0);
      V v_s_24265 = heff_field(v_x2_24263, 1);
      heff_take_n(v_x2_24263, 3ULL, 2);
      V v_m_24266 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24267 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_s_24265}));
      switch (heff_tag_of(v_x2_24267)) {
      case TAG_MkPair: {
        V v_x_24268 = heff_field(v_x2_24267, 0);
        V v_s_24269 = heff_field(v_x2_24267, 1);
        heff_take_n(v_x2_24267, 3ULL, 2);
        V v_t_24270 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str60), heff_strAppend(v_x_24268, ((V)&g_heff_2ecompile_2eemitc_2etestC_str61)));
        V v_t_24271 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str62), heff_strAppend(v_x_24264, v_t_24270));
        V v_t_24272 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str63), heff_strAppend(v_x_24260, v_t_24271));
        return heff_tag_at_n(v_ru_24x2_24259_24MkPair, TAG_MkPair, 2, (V[]){v_t_24272, v_s_24269});
      }
      default: return heff_nomatch(v_x2_24267);
      }
    }
    default: return heff_nomatch(v_x2_24263);
    }
  }
  default: return heff_nomatch(v_x2_24259);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args) {
  V v_s_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24276 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_s_24275}));
  switch (heff_tag_of(v_x2_24276)) {
  case TAG_MkPair: {
    V v_x_24277 = heff_field(v_x2_24276, 0);
    V v_s_24278 = heff_field(v_x2_24276, 1);
    V v_ru_24x2_24276_24MkPair = heff_take_reuse_n(v_x2_24276, 3ULL, 2);
    V v_m_24279 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24280 = heff_tr(heff_call(v_m_24279, 1, (V[]){v_s_24278}));
    switch (heff_tag_of(v_x2_24280)) {
    case TAG_MkPair: {
      V v_x_24281 = heff_field(v_x2_24280, 0);
      V v_s_24282 = heff_field(v_x2_24280, 1);
      heff_take_n(v_x2_24280, 3ULL, 2);
      V v_m_24283 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24284 = heff_tr(heff_call(v_m_24283, 1, (V[]){v_s_24282}));
      switch (heff_tag_of(v_x2_24284)) {
      case TAG_MkPair: {
        V v_x_24285 = heff_field(v_x2_24284, 0);
        V v_s_24286 = heff_field(v_x2_24284, 1);
        heff_take_n(v_x2_24284, 3ULL, 2);
        V v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str64), heff_strAppend(v_x_24285, ((V)&g_heff_2ecompile_2eemitc_2etestC_str65)));
        V v_t_24288 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str66), heff_strAppend(v_x_24281, v_t_24287));
        V v_t_24289 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str67), heff_strAppend(v_x_24277, v_t_24288));
        return heff_tag_at_n(v_ru_24x2_24276_24MkPair, TAG_MkPair, 2, (V[]){v_t_24289, v_s_24286});
      }
      default: return heff_nomatch(v_x2_24284);
      }
    }
    default: return heff_nomatch(v_x2_24280);
    }
  }
  default: return heff_nomatch(v_x2_24276);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args) {
  V v_s_24294 = args[0];
  V v_m_24293 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24295 = heff_tr(heff_call(v_m_24293, 1, (V[]){v_s_24294}));
  switch (heff_tag_of(v_x2_24295)) {
  case TAG_MkPair: {
    V v_x_24296 = heff_field(v_x2_24295, 0);
    V v_s_24297 = heff_field(v_x2_24295, 1);
    V v_ru_24x2_24295_24MkPair = heff_take_reuse_n(v_x2_24295, 3ULL, 2);
    V v_m_24298 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24299 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_s_24297}));
    switch (heff_tag_of(v_x2_24299)) {
    case TAG_MkPair: {
      V v_x_24300 = heff_field(v_x2_24299, 0);
      V v_s_24301 = heff_field(v_x2_24299, 1);
      heff_take_n(v_x2_24299, 3ULL, 2);
      V v_m_24302 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24303 = heff_tr(heff_call(v_m_24302, 1, (V[]){v_s_24301}));
      switch (heff_tag_of(v_x2_24303)) {
      case TAG_MkPair: {
        V v_x_24304 = heff_field(v_x2_24303, 0);
        V v_s_24305 = heff_field(v_x2_24303, 1);
        heff_take_n(v_x2_24303, 3ULL, 2);
        V v_t_24306 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str68), heff_strAppend(v_x_24304, ((V)&g_heff_2ecompile_2eemitc_2etestC_str69)));
        V v_t_24307 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str70), heff_strAppend(v_x_24300, v_t_24306));
        V v_t_24308 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str71), heff_strAppend(v_x_24296, v_t_24307));
        return heff_tag_at_n(v_ru_24x2_24295_24MkPair, TAG_MkPair, 2, (V[]){v_t_24308, v_s_24305});
      }
      default: return heff_nomatch(v_x2_24303);
      }
    }
    default: return heff_nomatch(v_x2_24299);
    }
  }
  default: return heff_nomatch(v_x2_24295);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args) {
  V v_s_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_s_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_MkPair: {
    V v_x_24316 = heff_field(v_x2_24315, 0);
    V v_s_24317 = heff_field(v_x2_24315, 1);
    V v_ru_24x2_24315_24MkPair = heff_take_reuse_n(v_x2_24315, 3ULL, 2);
    V v_m_24318 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24319 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_s_24317}));
    switch (heff_tag_of(v_x2_24319)) {
    case TAG_MkPair: {
      V v_x_24320 = heff_field(v_x2_24319, 0);
      V v_s_24321 = heff_field(v_x2_24319, 1);
      heff_take_n(v_x2_24319, 3ULL, 2);
      V v_m_24322 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24323 = heff_tr(heff_call(v_m_24322, 1, (V[]){v_s_24321}));
      switch (heff_tag_of(v_x2_24323)) {
      case TAG_MkPair: {
        V v_x_24324 = heff_field(v_x2_24323, 0);
        V v_s_24325 = heff_field(v_x2_24323, 1);
        heff_take_n(v_x2_24323, 3ULL, 2);
        V v_t_24326 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str72), heff_strAppend(v_x_24324, ((V)&g_heff_2ecompile_2eemitc_2etestC_str73)));
        V v_t_24327 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str74), heff_strAppend(v_x_24320, v_t_24326));
        V v_t_24328 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str75), heff_strAppend(v_x_24316, v_t_24327));
        return heff_tag_at_n(v_ru_24x2_24315_24MkPair, TAG_MkPair, 2, (V[]){v_t_24328, v_s_24325});
      }
      default: return heff_nomatch(v_x2_24323);
      }
    }
    default: return heff_nomatch(v_x2_24319);
    }
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args) {
  V v_s_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24333 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_s_24332}));
  switch (heff_tag_of(v_x2_24333)) {
  case TAG_MkPair: {
    V v_x_24334 = heff_field(v_x2_24333, 0);
    V v_s_24335 = heff_field(v_x2_24333, 1);
    V v_ru_24x2_24333_24MkPair = heff_take_reuse_n(v_x2_24333, 3ULL, 2);
    V v_m_24336 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24337 = heff_tr(heff_call(v_m_24336, 1, (V[]){v_s_24335}));
    switch (heff_tag_of(v_x2_24337)) {
    case TAG_MkPair: {
      V v_x_24338 = heff_field(v_x2_24337, 0);
      V v_s_24339 = heff_field(v_x2_24337, 1);
      heff_take_n(v_x2_24337, 3ULL, 2);
      V v_t_24340 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str76), heff_strAppend(v_x_24338, ((V)&g_heff_2ecompile_2eemitc_2etestC_str77)));
      V v_t_24341 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str78), heff_strAppend(v_x_24334, v_t_24340));
      return heff_tag_at_n(v_ru_24x2_24333_24MkPair, TAG_MkPair, 2, (V[]){v_t_24341, v_s_24339});
    }
    default: return heff_nomatch(v_x2_24337);
    }
  }
  default: return heff_nomatch(v_x2_24333);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args) {
  V v_s_24343 = args[0];
  V v_m_24342 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24344 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_s_24343}));
  switch (heff_tag_of(v_x2_24344)) {
  case TAG_MkPair: {
    V v_x_24345 = heff_field(v_x2_24344, 0);
    V v_s_24346 = heff_field(v_x2_24344, 1);
    V v_ru_24x2_24344_24MkPair = heff_take_reuse_n(v_x2_24344, 3ULL, 2);
    V v_m_24347 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24348 = heff_tr(heff_call(v_m_24347, 1, (V[]){v_s_24346}));
    switch (heff_tag_of(v_x2_24348)) {
    case TAG_MkPair: {
      V v_x_24349 = heff_field(v_x2_24348, 0);
      V v_s_24350 = heff_field(v_x2_24348, 1);
      heff_take_n(v_x2_24348, 3ULL, 2);
      V v_m_24351 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24352 = heff_tr(heff_call(v_m_24351, 1, (V[]){v_s_24350}));
      switch (heff_tag_of(v_x2_24352)) {
      case TAG_MkPair: {
        V v_x_24353 = heff_field(v_x2_24352, 0);
        V v_s_24354 = heff_field(v_x2_24352, 1);
        heff_take_n(v_x2_24352, 3ULL, 2);
        V v_t_24355 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str79), heff_strAppend(v_x_24353, ((V)&g_heff_2ecompile_2eemitc_2etestC_str80)));
        V v_t_24356 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str81), heff_strAppend(v_x_24349, v_t_24355));
        V v_t_24357 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str82), heff_strAppend(v_x_24345, v_t_24356));
        return heff_tag_at_n(v_ru_24x2_24344_24MkPair, TAG_MkPair, 2, (V[]){v_t_24357, v_s_24354});
      }
      default: return heff_nomatch(v_x2_24352);
      }
    }
    default: return heff_nomatch(v_x2_24348);
    }
  }
  default: return heff_nomatch(v_x2_24344);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args) {
  V v_s_24361 = args[0];
  V v_m_24360 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24362 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_s_24361}));
  switch (heff_tag_of(v_x2_24362)) {
  case TAG_MkPair: {
    V v_x_24363 = heff_field(v_x2_24362, 0);
    V v_s_24364 = heff_field(v_x2_24362, 1);
    V v_ru_24x2_24362_24MkPair = heff_take_reuse_n(v_x2_24362, 3ULL, 2);
    V v_m_24365 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24366 = heff_tr(heff_call(v_m_24365, 1, (V[]){v_s_24364}));
    switch (heff_tag_of(v_x2_24366)) {
    case TAG_MkPair: {
      V v_x_24367 = heff_field(v_x2_24366, 0);
      V v_s_24368 = heff_field(v_x2_24366, 1);
      heff_take_n(v_x2_24366, 3ULL, 2);
      V v_m_24369 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24370 = heff_tr(heff_call(v_m_24369, 1, (V[]){v_s_24368}));
      switch (heff_tag_of(v_x2_24370)) {
      case TAG_MkPair: {
        V v_x_24371 = heff_field(v_x2_24370, 0);
        V v_s_24372 = heff_field(v_x2_24370, 1);
        heff_take_n(v_x2_24370, 3ULL, 2);
        V v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str83), heff_strAppend(v_x_24371, ((V)&g_heff_2ecompile_2eemitc_2etestC_str84)));
        V v_t_24374 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str85), heff_strAppend(v_x_24367, v_t_24373));
        V v_t_24375 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str86), heff_strAppend(v_x_24363, v_t_24374));
        return heff_tag_at_n(v_ru_24x2_24362_24MkPair, TAG_MkPair, 2, (V[]){v_t_24375, v_s_24372});
      }
      default: return heff_nomatch(v_x2_24370);
      }
    }
    default: return heff_nomatch(v_x2_24366);
    }
  }
  default: return heff_nomatch(v_x2_24362);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args) {
  V v_s_24379 = args[0];
  V v_m_24378 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24380 = heff_tr(heff_call(v_m_24378, 1, (V[]){v_s_24379}));
  switch (heff_tag_of(v_x2_24380)) {
  case TAG_MkPair: {
    V v_x_24381 = heff_field(v_x2_24380, 0);
    V v_s_24382 = heff_field(v_x2_24380, 1);
    V v_ru_24x2_24380_24MkPair = heff_take_reuse_n(v_x2_24380, 3ULL, 2);
    V v_m_24383 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24384 = heff_tr(heff_call(v_m_24383, 1, (V[]){v_s_24382}));
    switch (heff_tag_of(v_x2_24384)) {
    case TAG_MkPair: {
      V v_x_24385 = heff_field(v_x2_24384, 0);
      V v_s_24386 = heff_field(v_x2_24384, 1);
      heff_take_n(v_x2_24384, 3ULL, 2);
      V v_m_24387 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24388 = heff_tr(heff_call(v_m_24387, 1, (V[]){v_s_24386}));
      switch (heff_tag_of(v_x2_24388)) {
      case TAG_MkPair: {
        V v_x_24389 = heff_field(v_x2_24388, 0);
        V v_s_24390 = heff_field(v_x2_24388, 1);
        heff_take_n(v_x2_24388, 3ULL, 2);
        V v_t_24391 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str87), heff_strAppend(v_x_24389, ((V)&g_heff_2ecompile_2eemitc_2etestC_str88)));
        V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str89), heff_strAppend(v_x_24385, v_t_24391));
        V v_t_24393 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str90), heff_strAppend(v_x_24381, v_t_24392));
        return heff_tag_at_n(v_ru_24x2_24380_24MkPair, TAG_MkPair, 2, (V[]){v_t_24393, v_s_24390});
      }
      default: return heff_nomatch(v_x2_24388);
      }
    }
    default: return heff_nomatch(v_x2_24384);
    }
  }
  default: return heff_nomatch(v_x2_24380);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args) {
  V v_s_24396 = args[0];
  V v_m_24395 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24397 = heff_tr(heff_call(v_m_24395, 1, (V[]){v_s_24396}));
  switch (heff_tag_of(v_x2_24397)) {
  case TAG_MkPair: {
    V v_x_24398 = heff_field(v_x2_24397, 0);
    V v_s_24399 = heff_field(v_x2_24397, 1);
    V v_ru_24x2_24397_24MkPair = heff_take_reuse_n(v_x2_24397, 3ULL, 2);
    V v_m_24400 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24401 = heff_tr(heff_call(v_m_24400, 1, (V[]){v_s_24399}));
    switch (heff_tag_of(v_x2_24401)) {
    case TAG_MkPair: {
      V v_x_24402 = heff_field(v_x2_24401, 0);
      V v_s_24403 = heff_field(v_x2_24401, 1);
      heff_take_n(v_x2_24401, 3ULL, 2);
      V v_m_24404 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24405 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_s_24403}));
      switch (heff_tag_of(v_x2_24405)) {
      case TAG_MkPair: {
        V v_x_24406 = heff_field(v_x2_24405, 0);
        V v_s_24407 = heff_field(v_x2_24405, 1);
        heff_take_n(v_x2_24405, 3ULL, 2);
        V v_t_24408 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str91), heff_strAppend(v_x_24406, ((V)&g_heff_2ecompile_2eemitc_2etestC_str92)));
        V v_t_24409 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str93), heff_strAppend(v_x_24402, v_t_24408));
        V v_t_24410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str94), heff_strAppend(v_x_24398, v_t_24409));
        return heff_tag_at_n(v_ru_24x2_24397_24MkPair, TAG_MkPair, 2, (V[]){v_t_24410, v_s_24407});
      }
      default: return heff_nomatch(v_x2_24405);
      }
    }
    default: return heff_nomatch(v_x2_24401);
    }
  }
  default: return heff_nomatch(v_x2_24397);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args) {
  V v_s_24413 = args[0];
  V v_m_24412 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24414 = heff_tr(heff_call(v_m_24412, 1, (V[]){v_s_24413}));
  switch (heff_tag_of(v_x2_24414)) {
  case TAG_MkPair: {
    V v_x_24415 = heff_field(v_x2_24414, 0);
    V v_s_24416 = heff_field(v_x2_24414, 1);
    V v_ru_24x2_24414_24MkPair = heff_take_reuse_n(v_x2_24414, 3ULL, 2);
    V v_m_24417 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24418 = heff_tr(heff_call(v_m_24417, 1, (V[]){v_s_24416}));
    switch (heff_tag_of(v_x2_24418)) {
    case TAG_MkPair: {
      V v_x_24419 = heff_field(v_x2_24418, 0);
      V v_s_24420 = heff_field(v_x2_24418, 1);
      heff_take_n(v_x2_24418, 3ULL, 2);
      V v_m_24421 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24422 = heff_tr(heff_call(v_m_24421, 1, (V[]){v_s_24420}));
      switch (heff_tag_of(v_x2_24422)) {
      case TAG_MkPair: {
        V v_x_24423 = heff_field(v_x2_24422, 0);
        V v_s_24424 = heff_field(v_x2_24422, 1);
        heff_take_n(v_x2_24422, 3ULL, 2);
        V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str95), heff_strAppend(v_x_24423, ((V)&g_heff_2ecompile_2eemitc_2etestC_str96)));
        V v_t_24426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str97), heff_strAppend(v_x_24419, v_t_24425));
        V v_t_24427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str98), heff_strAppend(v_x_24415, v_t_24426));
        return heff_tag_at_n(v_ru_24x2_24414_24MkPair, TAG_MkPair, 2, (V[]){v_t_24427, v_s_24424});
      }
      default: return heff_nomatch(v_x2_24422);
      }
    }
    default: return heff_nomatch(v_x2_24418);
    }
  }
  default: return heff_nomatch(v_x2_24414);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args) {
  V v_s_24432 = args[0];
  V v_m_24431 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24433 = heff_tr(heff_call(v_m_24431, 1, (V[]){v_s_24432}));
  switch (heff_tag_of(v_x2_24433)) {
  case TAG_MkPair: {
    V v_x_24434 = heff_field(v_x2_24433, 0);
    V v_s_24435 = heff_field(v_x2_24433, 1);
    V v_ru_24x2_24433_24MkPair = heff_take_reuse_n(v_x2_24433, 3ULL, 2);
    V v_m_24436 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24437 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_s_24435}));
    switch (heff_tag_of(v_x2_24437)) {
    case TAG_MkPair: {
      V v_x_24438 = heff_field(v_x2_24437, 0);
      V v_s_24439 = heff_field(v_x2_24437, 1);
      heff_take_n(v_x2_24437, 3ULL, 2);
      V v_m_24440 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24441 = heff_tr(heff_call(v_m_24440, 1, (V[]){v_s_24439}));
      switch (heff_tag_of(v_x2_24441)) {
      case TAG_MkPair: {
        V v_x_24442 = heff_field(v_x2_24441, 0);
        V v_s_24443 = heff_field(v_x2_24441, 1);
        heff_take_n(v_x2_24441, 3ULL, 2);
        V v_t_24444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str99), heff_strAppend(v_x_24442, ((V)&g_heff_2ecompile_2eemitc_2etestC_str100)));
        V v_t_24445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str101), heff_strAppend(v_x_24438, v_t_24444));
        V v_t_24446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str102), heff_strAppend(v_x_24434, v_t_24445));
        return heff_tag_at_n(v_ru_24x2_24433_24MkPair, TAG_MkPair, 2, (V[]){v_t_24446, v_s_24443});
      }
      default: return heff_nomatch(v_x2_24441);
      }
    }
    default: return heff_nomatch(v_x2_24437);
    }
  }
  default: return heff_nomatch(v_x2_24433);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args) {
  V v_s_24452 = args[0];
  V v_m_24451 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24453 = heff_tr(heff_call(v_m_24451, 1, (V[]){v_s_24452}));
  switch (heff_tag_of(v_x2_24453)) {
  case TAG_MkPair: {
    V v_x_24454 = heff_field(v_x2_24453, 0);
    V v_s_24455 = heff_field(v_x2_24453, 1);
    V v_ru_24x2_24453_24MkPair = heff_take_reuse_n(v_x2_24453, 3ULL, 2);
    V v_m_24456 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24457 = heff_tr(heff_call(v_m_24456, 1, (V[]){v_s_24455}));
    switch (heff_tag_of(v_x2_24457)) {
    case TAG_MkPair: {
      V v_x_24458 = heff_field(v_x2_24457, 0);
      V v_s_24459 = heff_field(v_x2_24457, 1);
      heff_take_n(v_x2_24457, 3ULL, 2);
      V v_m_24460 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24461 = heff_tr(heff_call(v_m_24460, 1, (V[]){v_s_24459}));
      switch (heff_tag_of(v_x2_24461)) {
      case TAG_MkPair: {
        V v_x_24462 = heff_field(v_x2_24461, 0);
        V v_s_24463 = heff_field(v_x2_24461, 1);
        heff_take_n(v_x2_24461, 3ULL, 2);
        V v_t_24464 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str103), heff_strAppend(v_x_24462, ((V)&g_heff_2ecompile_2eemitc_2etestC_str104)));
        V v_t_24465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str105), heff_strAppend(v_x_24458, v_t_24464));
        V v_t_24466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str106), heff_strAppend(v_x_24454, v_t_24465));
        return heff_tag_at_n(v_ru_24x2_24453_24MkPair, TAG_MkPair, 2, (V[]){v_t_24466, v_s_24463});
      }
      default: return heff_nomatch(v_x2_24461);
      }
    }
    default: return heff_nomatch(v_x2_24457);
    }
  }
  default: return heff_nomatch(v_x2_24453);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args) {
  V v_s_24469 = args[0];
  V v_m_24468 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24470 = heff_tr(heff_call(v_m_24468, 1, (V[]){v_s_24469}));
  switch (heff_tag_of(v_x2_24470)) {
  case TAG_MkPair: {
    V v_x_24471 = heff_field(v_x2_24470, 0);
    V v_s_24472 = heff_field(v_x2_24470, 1);
    V v_ru_24x2_24470_24MkPair = heff_take_reuse_n(v_x2_24470, 3ULL, 2);
    V v_m_24473 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24474 = heff_tr(heff_call(v_m_24473, 1, (V[]){v_s_24472}));
    switch (heff_tag_of(v_x2_24474)) {
    case TAG_MkPair: {
      V v_x_24475 = heff_field(v_x2_24474, 0);
      V v_s_24476 = heff_field(v_x2_24474, 1);
      heff_take_n(v_x2_24474, 3ULL, 2);
      V v_t_24477 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str107), heff_strAppend(v_x_24475, ((V)&g_heff_2ecompile_2eemitc_2etestC_str108)));
      V v_t_24478 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str109), heff_strAppend(v_x_24471, v_t_24477));
      return heff_tag_at_n(v_ru_24x2_24470_24MkPair, TAG_MkPair, 2, (V[]){v_t_24478, v_s_24476});
    }
    default: return heff_nomatch(v_x2_24474);
    }
  }
  default: return heff_nomatch(v_x2_24470);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args) {
  V v_s_24480 = args[0];
  V v_m_24479 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24481 = heff_tr(heff_call(v_m_24479, 1, (V[]){v_s_24480}));
  switch (heff_tag_of(v_x2_24481)) {
  case TAG_MkPair: {
    V v_x_24482 = heff_field(v_x2_24481, 0);
    V v_s_24483 = heff_field(v_x2_24481, 1);
    V v_ru_24x2_24481_24MkPair = heff_take_reuse_n(v_x2_24481, 3ULL, 2);
    V v_m_24484 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24485 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_s_24483}));
    switch (heff_tag_of(v_x2_24485)) {
    case TAG_MkPair: {
      V v_x_24486 = heff_field(v_x2_24485, 0);
      V v_s_24487 = heff_field(v_x2_24485, 1);
      heff_take_n(v_x2_24485, 3ULL, 2);
      V v_m_24488 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24489 = heff_tr(heff_call(v_m_24488, 1, (V[]){v_s_24487}));
      switch (heff_tag_of(v_x2_24489)) {
      case TAG_MkPair: {
        V v_x_24490 = heff_field(v_x2_24489, 0);
        V v_s_24491 = heff_field(v_x2_24489, 1);
        heff_take_n(v_x2_24489, 3ULL, 2);
        V v_t_24492 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str110), heff_strAppend(v_x_24490, ((V)&g_heff_2ecompile_2eemitc_2etestC_str111)));
        V v_t_24493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str112), heff_strAppend(v_x_24486, v_t_24492));
        V v_t_24494 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str113), heff_strAppend(v_x_24482, v_t_24493));
        return heff_tag_at_n(v_ru_24x2_24481_24MkPair, TAG_MkPair, 2, (V[]){v_t_24494, v_s_24491});
      }
      default: return heff_nomatch(v_x2_24489);
      }
    }
    default: return heff_nomatch(v_x2_24485);
    }
  }
  default: return heff_nomatch(v_x2_24481);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args) {
  V v_s_24498 = args[0];
  V v_m_24497 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24499 = heff_tr(heff_call(v_m_24497, 1, (V[]){v_s_24498}));
  switch (heff_tag_of(v_x2_24499)) {
  case TAG_MkPair: {
    V v_x_24500 = heff_field(v_x2_24499, 0);
    V v_s_24501 = heff_field(v_x2_24499, 1);
    V v_ru_24x2_24499_24MkPair = heff_take_reuse_n(v_x2_24499, 3ULL, 2);
    V v_m_24502 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24503 = heff_tr(heff_call(v_m_24502, 1, (V[]){v_s_24501}));
    switch (heff_tag_of(v_x2_24503)) {
    case TAG_MkPair: {
      V v_x_24504 = heff_field(v_x2_24503, 0);
      V v_s_24505 = heff_field(v_x2_24503, 1);
      heff_take_n(v_x2_24503, 3ULL, 2);
      V v_m_24506 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24507 = heff_tr(heff_call(v_m_24506, 1, (V[]){v_s_24505}));
      switch (heff_tag_of(v_x2_24507)) {
      case TAG_MkPair: {
        V v_x_24508 = heff_field(v_x2_24507, 0);
        V v_s_24509 = heff_field(v_x2_24507, 1);
        heff_take_n(v_x2_24507, 3ULL, 2);
        V v_t_24510 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str114), heff_strAppend(v_x_24508, ((V)&g_heff_2ecompile_2eemitc_2etestC_str115)));
        V v_t_24511 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str116), heff_strAppend(v_x_24504, v_t_24510));
        V v_t_24512 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str117), heff_strAppend(v_x_24500, v_t_24511));
        return heff_tag_at_n(v_ru_24x2_24499_24MkPair, TAG_MkPair, 2, (V[]){v_t_24512, v_s_24509});
      }
      default: return heff_nomatch(v_x2_24507);
      }
    }
    default: return heff_nomatch(v_x2_24503);
    }
  }
  default: return heff_nomatch(v_x2_24499);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args) {
  V v_s_24516 = args[0];
  V v_m_24515 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24517 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_s_24516}));
  switch (heff_tag_of(v_x2_24517)) {
  case TAG_MkPair: {
    V v_x_24518 = heff_field(v_x2_24517, 0);
    V v_s_24519 = heff_field(v_x2_24517, 1);
    V v_ru_24x2_24517_24MkPair = heff_take_reuse_n(v_x2_24517, 3ULL, 2);
    V v_m_24520 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24521 = heff_tr(heff_call(v_m_24520, 1, (V[]){v_s_24519}));
    switch (heff_tag_of(v_x2_24521)) {
    case TAG_MkPair: {
      V v_x_24522 = heff_field(v_x2_24521, 0);
      V v_s_24523 = heff_field(v_x2_24521, 1);
      heff_take_n(v_x2_24521, 3ULL, 2);
      V v_m_24524 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24525 = heff_tr(heff_call(v_m_24524, 1, (V[]){v_s_24523}));
      switch (heff_tag_of(v_x2_24525)) {
      case TAG_MkPair: {
        V v_x_24526 = heff_field(v_x2_24525, 0);
        V v_s_24527 = heff_field(v_x2_24525, 1);
        heff_take_n(v_x2_24525, 3ULL, 2);
        V v_t_24528 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str118), heff_strAppend(v_x_24526, ((V)&g_heff_2ecompile_2eemitc_2etestC_str119)));
        V v_t_24529 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str120), heff_strAppend(v_x_24522, v_t_24528));
        V v_t_24530 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str121), heff_strAppend(v_x_24518, v_t_24529));
        return heff_tag_at_n(v_ru_24x2_24517_24MkPair, TAG_MkPair, 2, (V[]){v_t_24530, v_s_24527});
      }
      default: return heff_nomatch(v_x2_24525);
      }
    }
    default: return heff_nomatch(v_x2_24521);
    }
  }
  default: return heff_nomatch(v_x2_24517);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args) {
  V v_s_24533 = args[0];
  V v_m_24532 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24534 = heff_tr(heff_call(v_m_24532, 1, (V[]){v_s_24533}));
  switch (heff_tag_of(v_x2_24534)) {
  case TAG_MkPair: {
    V v_x_24535 = heff_field(v_x2_24534, 0);
    V v_s_24536 = heff_field(v_x2_24534, 1);
    V v_ru_24x2_24534_24MkPair = heff_take_reuse_n(v_x2_24534, 3ULL, 2);
    V v_m_24537 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24538 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_s_24536}));
    switch (heff_tag_of(v_x2_24538)) {
    case TAG_MkPair: {
      V v_x_24539 = heff_field(v_x2_24538, 0);
      V v_s_24540 = heff_field(v_x2_24538, 1);
      heff_take_n(v_x2_24538, 3ULL, 2);
      V v_m_24541 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24542 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_s_24540}));
      switch (heff_tag_of(v_x2_24542)) {
      case TAG_MkPair: {
        V v_x_24543 = heff_field(v_x2_24542, 0);
        V v_s_24544 = heff_field(v_x2_24542, 1);
        heff_take_n(v_x2_24542, 3ULL, 2);
        V v_t_24545 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str122), heff_strAppend(v_x_24543, ((V)&g_heff_2ecompile_2eemitc_2etestC_str123)));
        V v_t_24546 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str124), heff_strAppend(v_x_24539, v_t_24545));
        V v_t_24547 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str125), heff_strAppend(v_x_24535, v_t_24546));
        return heff_tag_at_n(v_ru_24x2_24534_24MkPair, TAG_MkPair, 2, (V[]){v_t_24547, v_s_24544});
      }
      default: return heff_nomatch(v_x2_24542);
      }
    }
    default: return heff_nomatch(v_x2_24538);
    }
  }
  default: return heff_nomatch(v_x2_24534);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args) {
  V v_s_24550 = args[0];
  V v_m_24549 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24551 = heff_tr(heff_call(v_m_24549, 1, (V[]){v_s_24550}));
  switch (heff_tag_of(v_x2_24551)) {
  case TAG_MkPair: {
    V v_x_24552 = heff_field(v_x2_24551, 0);
    V v_s_24553 = heff_field(v_x2_24551, 1);
    V v_ru_24x2_24551_24MkPair = heff_take_reuse_n(v_x2_24551, 3ULL, 2);
    V v_m_24554 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24555 = heff_tr(heff_call(v_m_24554, 1, (V[]){v_s_24553}));
    switch (heff_tag_of(v_x2_24555)) {
    case TAG_MkPair: {
      V v_x_24556 = heff_field(v_x2_24555, 0);
      V v_s_24557 = heff_field(v_x2_24555, 1);
      heff_take_n(v_x2_24555, 3ULL, 2);
      V v_m_24558 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24559 = heff_tr(heff_call(v_m_24558, 1, (V[]){v_s_24557}));
      switch (heff_tag_of(v_x2_24559)) {
      case TAG_MkPair: {
        V v_x_24560 = heff_field(v_x2_24559, 0);
        V v_s_24561 = heff_field(v_x2_24559, 1);
        heff_take_n(v_x2_24559, 3ULL, 2);
        V v_t_24562 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str126), heff_strAppend(v_x_24560, ((V)&g_heff_2ecompile_2eemitc_2etestC_str127)));
        V v_t_24563 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str128), heff_strAppend(v_x_24556, v_t_24562));
        V v_t_24564 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str129), heff_strAppend(v_x_24552, v_t_24563));
        return heff_tag_at_n(v_ru_24x2_24551_24MkPair, TAG_MkPair, 2, (V[]){v_t_24564, v_s_24561});
      }
      default: return heff_nomatch(v_x2_24559);
      }
    }
    default: return heff_nomatch(v_x2_24555);
    }
  }
  default: return heff_nomatch(v_x2_24551);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args) {
  V v_s_24569 = args[0];
  V v_m_24568 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24570 = heff_tr(heff_call(v_m_24568, 1, (V[]){v_s_24569}));
  switch (heff_tag_of(v_x2_24570)) {
  case TAG_MkPair: {
    V v_x_24571 = heff_field(v_x2_24570, 0);
    V v_s_24572 = heff_field(v_x2_24570, 1);
    V v_ru_24x2_24570_24MkPair = heff_take_reuse_n(v_x2_24570, 3ULL, 2);
    V v_m_24573 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24574 = heff_tr(heff_call(v_m_24573, 1, (V[]){v_s_24572}));
    switch (heff_tag_of(v_x2_24574)) {
    case TAG_MkPair: {
      V v_x_24575 = heff_field(v_x2_24574, 0);
      V v_s_24576 = heff_field(v_x2_24574, 1);
      heff_take_n(v_x2_24574, 3ULL, 2);
      V v_m_24577 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24578 = heff_tr(heff_call(v_m_24577, 1, (V[]){v_s_24576}));
      switch (heff_tag_of(v_x2_24578)) {
      case TAG_MkPair: {
        V v_x_24579 = heff_field(v_x2_24578, 0);
        V v_s_24580 = heff_field(v_x2_24578, 1);
        heff_take_n(v_x2_24578, 3ULL, 2);
        V v_t_24581 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str130), heff_strAppend(v_x_24579, ((V)&g_heff_2ecompile_2eemitc_2etestC_str131)));
        V v_t_24582 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str132), heff_strAppend(v_x_24575, v_t_24581));
        V v_t_24583 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str133), heff_strAppend(v_x_24571, v_t_24582));
        return heff_tag_at_n(v_ru_24x2_24570_24MkPair, TAG_MkPair, 2, (V[]){v_t_24583, v_s_24580});
      }
      default: return heff_nomatch(v_x2_24578);
      }
    }
    default: return heff_nomatch(v_x2_24574);
    }
  }
  default: return heff_nomatch(v_x2_24570);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args) {
  V v_s_24589 = args[0];
  V v_m_24588 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24590 = heff_tr(heff_call(v_m_24588, 1, (V[]){v_s_24589}));
  switch (heff_tag_of(v_x2_24590)) {
  case TAG_MkPair: {
    V v_x_24591 = heff_field(v_x2_24590, 0);
    V v_s_24592 = heff_field(v_x2_24590, 1);
    V v_ru_24x2_24590_24MkPair = heff_take_reuse_n(v_x2_24590, 3ULL, 2);
    V v_m_24593 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24594 = heff_tr(heff_call(v_m_24593, 1, (V[]){v_s_24592}));
    switch (heff_tag_of(v_x2_24594)) {
    case TAG_MkPair: {
      V v_x_24595 = heff_field(v_x2_24594, 0);
      V v_s_24596 = heff_field(v_x2_24594, 1);
      heff_take_n(v_x2_24594, 3ULL, 2);
      V v_m_24597 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24598 = heff_tr(heff_call(v_m_24597, 1, (V[]){v_s_24596}));
      switch (heff_tag_of(v_x2_24598)) {
      case TAG_MkPair: {
        V v_x_24599 = heff_field(v_x2_24598, 0);
        V v_s_24600 = heff_field(v_x2_24598, 1);
        heff_take_n(v_x2_24598, 3ULL, 2);
        V v_t_24601 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str134), heff_strAppend(v_x_24599, ((V)&g_heff_2ecompile_2eemitc_2etestC_str135)));
        V v_t_24602 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str136), heff_strAppend(v_x_24595, v_t_24601));
        V v_t_24603 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str137), heff_strAppend(v_x_24591, v_t_24602));
        return heff_tag_at_n(v_ru_24x2_24590_24MkPair, TAG_MkPair, 2, (V[]){v_t_24603, v_s_24600});
      }
      default: return heff_nomatch(v_x2_24598);
      }
    }
    default: return heff_nomatch(v_x2_24594);
    }
  }
  default: return heff_nomatch(v_x2_24590);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args) {
  V v_s_24606 = args[0];
  V v_m_24605 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24607 = heff_tr(heff_call(v_m_24605, 1, (V[]){v_s_24606}));
  switch (heff_tag_of(v_x2_24607)) {
  case TAG_MkPair: {
    V v_x_24608 = heff_field(v_x2_24607, 0);
    V v_s_24609 = heff_field(v_x2_24607, 1);
    V v_ru_24x2_24607_24MkPair = heff_take_reuse_n(v_x2_24607, 3ULL, 2);
    V v_m_24610 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24611 = heff_tr(heff_call(v_m_24610, 1, (V[]){v_s_24609}));
    switch (heff_tag_of(v_x2_24611)) {
    case TAG_MkPair: {
      V v_x_24612 = heff_field(v_x2_24611, 0);
      V v_s_24613 = heff_field(v_x2_24611, 1);
      heff_take_n(v_x2_24611, 3ULL, 2);
      V v_t_24614 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str138), heff_strAppend(v_x_24612, ((V)&g_heff_2ecompile_2eemitc_2etestC_str139)));
      V v_t_24615 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str140), heff_strAppend(v_x_24608, v_t_24614));
      return heff_tag_at_n(v_ru_24x2_24607_24MkPair, TAG_MkPair, 2, (V[]){v_t_24615, v_s_24613});
    }
    default: return heff_nomatch(v_x2_24611);
    }
  }
  default: return heff_nomatch(v_x2_24607);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args) {
  V v_s_24617 = args[0];
  V v_m_24616 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24618 = heff_tr(heff_call(v_m_24616, 1, (V[]){v_s_24617}));
  switch (heff_tag_of(v_x2_24618)) {
  case TAG_MkPair: {
    V v_x_24619 = heff_field(v_x2_24618, 0);
    V v_s_24620 = heff_field(v_x2_24618, 1);
    V v_ru_24x2_24618_24MkPair = heff_take_reuse_n(v_x2_24618, 3ULL, 2);
    V v_m_24621 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24622 = heff_tr(heff_call(v_m_24621, 1, (V[]){v_s_24620}));
    switch (heff_tag_of(v_x2_24622)) {
    case TAG_MkPair: {
      V v_x_24623 = heff_field(v_x2_24622, 0);
      V v_s_24624 = heff_field(v_x2_24622, 1);
      heff_take_n(v_x2_24622, 3ULL, 2);
      V v_m_24625 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24626 = heff_tr(heff_call(v_m_24625, 1, (V[]){v_s_24624}));
      switch (heff_tag_of(v_x2_24626)) {
      case TAG_MkPair: {
        V v_x_24627 = heff_field(v_x2_24626, 0);
        V v_s_24628 = heff_field(v_x2_24626, 1);
        heff_take_n(v_x2_24626, 3ULL, 2);
        V v_t_24629 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str141), heff_strAppend(v_x_24627, ((V)&g_heff_2ecompile_2eemitc_2etestC_str142)));
        V v_t_24630 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str143), heff_strAppend(v_x_24623, v_t_24629));
        V v_t_24631 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str144), heff_strAppend(v_x_24619, v_t_24630));
        return heff_tag_at_n(v_ru_24x2_24618_24MkPair, TAG_MkPair, 2, (V[]){v_t_24631, v_s_24628});
      }
      default: return heff_nomatch(v_x2_24626);
      }
    }
    default: return heff_nomatch(v_x2_24622);
    }
  }
  default: return heff_nomatch(v_x2_24618);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args) {
  V v_s_24635 = args[0];
  V v_m_24634 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24636 = heff_tr(heff_call(v_m_24634, 1, (V[]){v_s_24635}));
  switch (heff_tag_of(v_x2_24636)) {
  case TAG_MkPair: {
    V v_x_24637 = heff_field(v_x2_24636, 0);
    V v_s_24638 = heff_field(v_x2_24636, 1);
    V v_ru_24x2_24636_24MkPair = heff_take_reuse_n(v_x2_24636, 3ULL, 2);
    V v_m_24639 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24640 = heff_tr(heff_call(v_m_24639, 1, (V[]){v_s_24638}));
    switch (heff_tag_of(v_x2_24640)) {
    case TAG_MkPair: {
      V v_x_24641 = heff_field(v_x2_24640, 0);
      V v_s_24642 = heff_field(v_x2_24640, 1);
      heff_take_n(v_x2_24640, 3ULL, 2);
      V v_m_24643 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24644 = heff_tr(heff_call(v_m_24643, 1, (V[]){v_s_24642}));
      switch (heff_tag_of(v_x2_24644)) {
      case TAG_MkPair: {
        V v_x_24645 = heff_field(v_x2_24644, 0);
        V v_s_24646 = heff_field(v_x2_24644, 1);
        heff_take_n(v_x2_24644, 3ULL, 2);
        V v_t_24647 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str145), heff_strAppend(v_x_24645, ((V)&g_heff_2ecompile_2eemitc_2etestC_str146)));
        V v_t_24648 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str147), heff_strAppend(v_x_24641, v_t_24647));
        V v_t_24649 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str148), heff_strAppend(v_x_24637, v_t_24648));
        return heff_tag_at_n(v_ru_24x2_24636_24MkPair, TAG_MkPair, 2, (V[]){v_t_24649, v_s_24646});
      }
      default: return heff_nomatch(v_x2_24644);
      }
    }
    default: return heff_nomatch(v_x2_24640);
    }
  }
  default: return heff_nomatch(v_x2_24636);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args) {
  V v_s_24653 = args[0];
  V v_m_24652 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24654 = heff_tr(heff_call(v_m_24652, 1, (V[]){v_s_24653}));
  switch (heff_tag_of(v_x2_24654)) {
  case TAG_MkPair: {
    V v_x_24655 = heff_field(v_x2_24654, 0);
    V v_s_24656 = heff_field(v_x2_24654, 1);
    V v_ru_24x2_24654_24MkPair = heff_take_reuse_n(v_x2_24654, 3ULL, 2);
    V v_m_24657 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24658 = heff_tr(heff_call(v_m_24657, 1, (V[]){v_s_24656}));
    switch (heff_tag_of(v_x2_24658)) {
    case TAG_MkPair: {
      V v_x_24659 = heff_field(v_x2_24658, 0);
      V v_s_24660 = heff_field(v_x2_24658, 1);
      heff_take_n(v_x2_24658, 3ULL, 2);
      V v_m_24661 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24662 = heff_tr(heff_call(v_m_24661, 1, (V[]){v_s_24660}));
      switch (heff_tag_of(v_x2_24662)) {
      case TAG_MkPair: {
        V v_x_24663 = heff_field(v_x2_24662, 0);
        V v_s_24664 = heff_field(v_x2_24662, 1);
        heff_take_n(v_x2_24662, 3ULL, 2);
        V v_t_24665 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str149), heff_strAppend(v_x_24663, ((V)&g_heff_2ecompile_2eemitc_2etestC_str150)));
        V v_t_24666 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str151), heff_strAppend(v_x_24659, v_t_24665));
        V v_t_24667 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str152), heff_strAppend(v_x_24655, v_t_24666));
        return heff_tag_at_n(v_ru_24x2_24654_24MkPair, TAG_MkPair, 2, (V[]){v_t_24667, v_s_24664});
      }
      default: return heff_nomatch(v_x2_24662);
      }
    }
    default: return heff_nomatch(v_x2_24658);
    }
  }
  default: return heff_nomatch(v_x2_24654);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args) {
  V v_s_24670 = args[0];
  V v_m_24669 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24671 = heff_tr(heff_call(v_m_24669, 1, (V[]){v_s_24670}));
  switch (heff_tag_of(v_x2_24671)) {
  case TAG_MkPair: {
    V v_x_24672 = heff_field(v_x2_24671, 0);
    V v_s_24673 = heff_field(v_x2_24671, 1);
    V v_ru_24x2_24671_24MkPair = heff_take_reuse_n(v_x2_24671, 3ULL, 2);
    V v_m_24674 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24675 = heff_tr(heff_call(v_m_24674, 1, (V[]){v_s_24673}));
    switch (heff_tag_of(v_x2_24675)) {
    case TAG_MkPair: {
      V v_x_24676 = heff_field(v_x2_24675, 0);
      V v_s_24677 = heff_field(v_x2_24675, 1);
      heff_take_n(v_x2_24675, 3ULL, 2);
      V v_m_24678 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24679 = heff_tr(heff_call(v_m_24678, 1, (V[]){v_s_24677}));
      switch (heff_tag_of(v_x2_24679)) {
      case TAG_MkPair: {
        V v_x_24680 = heff_field(v_x2_24679, 0);
        V v_s_24681 = heff_field(v_x2_24679, 1);
        heff_take_n(v_x2_24679, 3ULL, 2);
        V v_t_24682 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str153), heff_strAppend(v_x_24680, ((V)&g_heff_2ecompile_2eemitc_2etestC_str154)));
        V v_t_24683 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str155), heff_strAppend(v_x_24676, v_t_24682));
        V v_t_24684 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str156), heff_strAppend(v_x_24672, v_t_24683));
        return heff_tag_at_n(v_ru_24x2_24671_24MkPair, TAG_MkPair, 2, (V[]){v_t_24684, v_s_24681});
      }
      default: return heff_nomatch(v_x2_24679);
      }
    }
    default: return heff_nomatch(v_x2_24675);
    }
  }
  default: return heff_nomatch(v_x2_24671);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args) {
  V v_s_24687 = args[0];
  V v_m_24686 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24688 = heff_tr(heff_call(v_m_24686, 1, (V[]){v_s_24687}));
  switch (heff_tag_of(v_x2_24688)) {
  case TAG_MkPair: {
    V v_x_24689 = heff_field(v_x2_24688, 0);
    V v_s_24690 = heff_field(v_x2_24688, 1);
    V v_ru_24x2_24688_24MkPair = heff_take_reuse_n(v_x2_24688, 3ULL, 2);
    V v_m_24691 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24692 = heff_tr(heff_call(v_m_24691, 1, (V[]){v_s_24690}));
    switch (heff_tag_of(v_x2_24692)) {
    case TAG_MkPair: {
      V v_x_24693 = heff_field(v_x2_24692, 0);
      V v_s_24694 = heff_field(v_x2_24692, 1);
      heff_take_n(v_x2_24692, 3ULL, 2);
      V v_m_24695 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24696 = heff_tr(heff_call(v_m_24695, 1, (V[]){v_s_24694}));
      switch (heff_tag_of(v_x2_24696)) {
      case TAG_MkPair: {
        V v_x_24697 = heff_field(v_x2_24696, 0);
        V v_s_24698 = heff_field(v_x2_24696, 1);
        heff_take_n(v_x2_24696, 3ULL, 2);
        V v_t_24699 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str157), heff_strAppend(v_x_24697, ((V)&g_heff_2ecompile_2eemitc_2etestC_str158)));
        V v_t_24700 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str159), heff_strAppend(v_x_24693, v_t_24699));
        V v_t_24701 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str160), heff_strAppend(v_x_24689, v_t_24700));
        return heff_tag_at_n(v_ru_24x2_24688_24MkPair, TAG_MkPair, 2, (V[]){v_t_24701, v_s_24698});
      }
      default: return heff_nomatch(v_x2_24696);
      }
    }
    default: return heff_nomatch(v_x2_24692);
    }
  }
  default: return heff_nomatch(v_x2_24688);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args) {
  V v_s_24706 = args[0];
  V v_m_24705 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24707 = heff_tr(heff_call(v_m_24705, 1, (V[]){v_s_24706}));
  switch (heff_tag_of(v_x2_24707)) {
  case TAG_MkPair: {
    V v_x_24708 = heff_field(v_x2_24707, 0);
    V v_s_24709 = heff_field(v_x2_24707, 1);
    V v_ru_24x2_24707_24MkPair = heff_take_reuse_n(v_x2_24707, 3ULL, 2);
    V v_m_24710 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24711 = heff_tr(heff_call(v_m_24710, 1, (V[]){v_s_24709}));
    switch (heff_tag_of(v_x2_24711)) {
    case TAG_MkPair: {
      V v_x_24712 = heff_field(v_x2_24711, 0);
      V v_s_24713 = heff_field(v_x2_24711, 1);
      heff_take_n(v_x2_24711, 3ULL, 2);
      V v_m_24714 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24715 = heff_tr(heff_call(v_m_24714, 1, (V[]){v_s_24713}));
      switch (heff_tag_of(v_x2_24715)) {
      case TAG_MkPair: {
        V v_x_24716 = heff_field(v_x2_24715, 0);
        V v_s_24717 = heff_field(v_x2_24715, 1);
        heff_take_n(v_x2_24715, 3ULL, 2);
        V v_t_24718 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str161), heff_strAppend(v_x_24716, ((V)&g_heff_2ecompile_2eemitc_2etestC_str162)));
        V v_t_24719 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str163), heff_strAppend(v_x_24712, v_t_24718));
        V v_t_24720 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str164), heff_strAppend(v_x_24708, v_t_24719));
        return heff_tag_at_n(v_ru_24x2_24707_24MkPair, TAG_MkPair, 2, (V[]){v_t_24720, v_s_24717});
      }
      default: return heff_nomatch(v_x2_24715);
      }
    }
    default: return heff_nomatch(v_x2_24711);
    }
  }
  default: return heff_nomatch(v_x2_24707);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args) {
  V v_s_24726 = args[0];
  V v_m_24725 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24727 = heff_tr(heff_call(v_m_24725, 1, (V[]){v_s_24726}));
  switch (heff_tag_of(v_x2_24727)) {
  case TAG_MkPair: {
    V v_x_24728 = heff_field(v_x2_24727, 0);
    V v_s_24729 = heff_field(v_x2_24727, 1);
    V v_ru_24x2_24727_24MkPair = heff_take_reuse_n(v_x2_24727, 3ULL, 2);
    V v_m_24730 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24731 = heff_tr(heff_call(v_m_24730, 1, (V[]){v_s_24729}));
    switch (heff_tag_of(v_x2_24731)) {
    case TAG_MkPair: {
      V v_x_24732 = heff_field(v_x2_24731, 0);
      V v_s_24733 = heff_field(v_x2_24731, 1);
      heff_take_n(v_x2_24731, 3ULL, 2);
      V v_m_24734 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24735 = heff_tr(heff_call(v_m_24734, 1, (V[]){v_s_24733}));
      switch (heff_tag_of(v_x2_24735)) {
      case TAG_MkPair: {
        V v_x_24736 = heff_field(v_x2_24735, 0);
        V v_s_24737 = heff_field(v_x2_24735, 1);
        heff_take_n(v_x2_24735, 3ULL, 2);
        V v_t_24738 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str165), heff_strAppend(v_x_24736, ((V)&g_heff_2ecompile_2eemitc_2etestC_str166)));
        V v_t_24739 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str167), heff_strAppend(v_x_24732, v_t_24738));
        V v_t_24740 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str168), heff_strAppend(v_x_24728, v_t_24739));
        return heff_tag_at_n(v_ru_24x2_24727_24MkPair, TAG_MkPair, 2, (V[]){v_t_24740, v_s_24737});
      }
      default: return heff_nomatch(v_x2_24735);
      }
    }
    default: return heff_nomatch(v_x2_24731);
    }
  }
  default: return heff_nomatch(v_x2_24727);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args) {
  V v_s_24745 = args[0];
  V v_m_24744 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24746 = heff_tr(heff_call(v_m_24744, 1, (V[]){v_s_24745}));
  switch (heff_tag_of(v_x2_24746)) {
  case TAG_MkPair: {
    V v_x_24747 = heff_field(v_x2_24746, 0);
    V v_s_24748 = heff_field(v_x2_24746, 1);
    V v_ru_24x2_24746_24MkPair = heff_take_reuse_n(v_x2_24746, 3ULL, 2);
    V v_m_24749 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24750 = heff_tr(heff_call(v_m_24749, 1, (V[]){v_s_24748}));
    switch (heff_tag_of(v_x2_24750)) {
    case TAG_MkPair: {
      V v_x_24751 = heff_field(v_x2_24750, 0);
      V v_s_24752 = heff_field(v_x2_24750, 1);
      heff_take_n(v_x2_24750, 3ULL, 2);
      V v_t_24753 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str169), heff_strAppend(v_x_24751, ((V)&g_heff_2ecompile_2eemitc_2etestC_str170)));
      V v_t_24754 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str171), heff_strAppend(v_x_24747, v_t_24753));
      return heff_tag_at_n(v_ru_24x2_24746_24MkPair, TAG_MkPair, 2, (V[]){v_t_24754, v_s_24752});
    }
    default: return heff_nomatch(v_x2_24750);
    }
  }
  default: return heff_nomatch(v_x2_24746);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args) {
  V v_s_24756 = args[0];
  V v_m_24755 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24757 = heff_tr(heff_call(v_m_24755, 1, (V[]){v_s_24756}));
  switch (heff_tag_of(v_x2_24757)) {
  case TAG_MkPair: {
    V v_x_24758 = heff_field(v_x2_24757, 0);
    V v_s_24759 = heff_field(v_x2_24757, 1);
    V v_ru_24x2_24757_24MkPair = heff_take_reuse_n(v_x2_24757, 3ULL, 2);
    V v_m_24760 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24761 = heff_tr(heff_call(v_m_24760, 1, (V[]){v_s_24759}));
    switch (heff_tag_of(v_x2_24761)) {
    case TAG_MkPair: {
      V v_x_24762 = heff_field(v_x2_24761, 0);
      V v_s_24763 = heff_field(v_x2_24761, 1);
      heff_take_n(v_x2_24761, 3ULL, 2);
      V v_m_24764 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24765 = heff_tr(heff_call(v_m_24764, 1, (V[]){v_s_24763}));
      switch (heff_tag_of(v_x2_24765)) {
      case TAG_MkPair: {
        V v_x_24766 = heff_field(v_x2_24765, 0);
        V v_s_24767 = heff_field(v_x2_24765, 1);
        heff_take_n(v_x2_24765, 3ULL, 2);
        V v_t_24768 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str172), heff_strAppend(v_x_24766, ((V)&g_heff_2ecompile_2eemitc_2etestC_str173)));
        V v_t_24769 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str174), heff_strAppend(v_x_24762, v_t_24768));
        V v_t_24770 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str175), heff_strAppend(v_x_24758, v_t_24769));
        return heff_tag_at_n(v_ru_24x2_24757_24MkPair, TAG_MkPair, 2, (V[]){v_t_24770, v_s_24767});
      }
      default: return heff_nomatch(v_x2_24765);
      }
    }
    default: return heff_nomatch(v_x2_24761);
    }
  }
  default: return heff_nomatch(v_x2_24757);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args) {
  V v_s_24774 = args[0];
  V v_m_24773 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24775 = heff_tr(heff_call(v_m_24773, 1, (V[]){v_s_24774}));
  switch (heff_tag_of(v_x2_24775)) {
  case TAG_MkPair: {
    V v_x_24776 = heff_field(v_x2_24775, 0);
    V v_s_24777 = heff_field(v_x2_24775, 1);
    V v_ru_24x2_24775_24MkPair = heff_take_reuse_n(v_x2_24775, 3ULL, 2);
    V v_m_24778 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24779 = heff_tr(heff_call(v_m_24778, 1, (V[]){v_s_24777}));
    switch (heff_tag_of(v_x2_24779)) {
    case TAG_MkPair: {
      V v_x_24780 = heff_field(v_x2_24779, 0);
      V v_s_24781 = heff_field(v_x2_24779, 1);
      heff_take_n(v_x2_24779, 3ULL, 2);
      V v_m_24782 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24783 = heff_tr(heff_call(v_m_24782, 1, (V[]){v_s_24781}));
      switch (heff_tag_of(v_x2_24783)) {
      case TAG_MkPair: {
        V v_x_24784 = heff_field(v_x2_24783, 0);
        V v_s_24785 = heff_field(v_x2_24783, 1);
        heff_take_n(v_x2_24783, 3ULL, 2);
        V v_t_24786 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str176), heff_strAppend(v_x_24784, ((V)&g_heff_2ecompile_2eemitc_2etestC_str177)));
        V v_t_24787 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str178), heff_strAppend(v_x_24780, v_t_24786));
        V v_t_24788 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str179), heff_strAppend(v_x_24776, v_t_24787));
        return heff_tag_at_n(v_ru_24x2_24775_24MkPair, TAG_MkPair, 2, (V[]){v_t_24788, v_s_24785});
      }
      default: return heff_nomatch(v_x2_24783);
      }
    }
    default: return heff_nomatch(v_x2_24779);
    }
  }
  default: return heff_nomatch(v_x2_24775);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args) {
  V v_s_24792 = args[0];
  V v_m_24791 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24793 = heff_tr(heff_call(v_m_24791, 1, (V[]){v_s_24792}));
  switch (heff_tag_of(v_x2_24793)) {
  case TAG_MkPair: {
    V v_x_24794 = heff_field(v_x2_24793, 0);
    V v_s_24795 = heff_field(v_x2_24793, 1);
    V v_ru_24x2_24793_24MkPair = heff_take_reuse_n(v_x2_24793, 3ULL, 2);
    V v_m_24796 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24797 = heff_tr(heff_call(v_m_24796, 1, (V[]){v_s_24795}));
    switch (heff_tag_of(v_x2_24797)) {
    case TAG_MkPair: {
      V v_x_24798 = heff_field(v_x2_24797, 0);
      V v_s_24799 = heff_field(v_x2_24797, 1);
      heff_take_n(v_x2_24797, 3ULL, 2);
      V v_m_24800 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24801 = heff_tr(heff_call(v_m_24800, 1, (V[]){v_s_24799}));
      switch (heff_tag_of(v_x2_24801)) {
      case TAG_MkPair: {
        V v_x_24802 = heff_field(v_x2_24801, 0);
        V v_s_24803 = heff_field(v_x2_24801, 1);
        heff_take_n(v_x2_24801, 3ULL, 2);
        V v_t_24804 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str180), heff_strAppend(v_x_24802, ((V)&g_heff_2ecompile_2eemitc_2etestC_str181)));
        V v_t_24805 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str182), heff_strAppend(v_x_24798, v_t_24804));
        V v_t_24806 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str183), heff_strAppend(v_x_24794, v_t_24805));
        return heff_tag_at_n(v_ru_24x2_24793_24MkPair, TAG_MkPair, 2, (V[]){v_t_24806, v_s_24803});
      }
      default: return heff_nomatch(v_x2_24801);
      }
    }
    default: return heff_nomatch(v_x2_24797);
    }
  }
  default: return heff_nomatch(v_x2_24793);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args) {
  V v_s_24809 = args[0];
  V v_m_24808 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24810 = heff_tr(heff_call(v_m_24808, 1, (V[]){v_s_24809}));
  switch (heff_tag_of(v_x2_24810)) {
  case TAG_MkPair: {
    V v_x_24811 = heff_field(v_x2_24810, 0);
    V v_s_24812 = heff_field(v_x2_24810, 1);
    V v_ru_24x2_24810_24MkPair = heff_take_reuse_n(v_x2_24810, 3ULL, 2);
    V v_m_24813 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24814 = heff_tr(heff_call(v_m_24813, 1, (V[]){v_s_24812}));
    switch (heff_tag_of(v_x2_24814)) {
    case TAG_MkPair: {
      V v_x_24815 = heff_field(v_x2_24814, 0);
      V v_s_24816 = heff_field(v_x2_24814, 1);
      heff_take_n(v_x2_24814, 3ULL, 2);
      V v_m_24817 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24818 = heff_tr(heff_call(v_m_24817, 1, (V[]){v_s_24816}));
      switch (heff_tag_of(v_x2_24818)) {
      case TAG_MkPair: {
        V v_x_24819 = heff_field(v_x2_24818, 0);
        V v_s_24820 = heff_field(v_x2_24818, 1);
        heff_take_n(v_x2_24818, 3ULL, 2);
        V v_t_24821 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str184), heff_strAppend(v_x_24819, ((V)&g_heff_2ecompile_2eemitc_2etestC_str185)));
        V v_t_24822 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str186), heff_strAppend(v_x_24815, v_t_24821));
        V v_t_24823 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str187), heff_strAppend(v_x_24811, v_t_24822));
        return heff_tag_at_n(v_ru_24x2_24810_24MkPair, TAG_MkPair, 2, (V[]){v_t_24823, v_s_24820});
      }
      default: return heff_nomatch(v_x2_24818);
      }
    }
    default: return heff_nomatch(v_x2_24814);
    }
  }
  default: return heff_nomatch(v_x2_24810);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args) {
  V v_s_24826 = args[0];
  V v_m_24825 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24827 = heff_tr(heff_call(v_m_24825, 1, (V[]){v_s_24826}));
  switch (heff_tag_of(v_x2_24827)) {
  case TAG_MkPair: {
    V v_x_24828 = heff_field(v_x2_24827, 0);
    V v_s_24829 = heff_field(v_x2_24827, 1);
    V v_ru_24x2_24827_24MkPair = heff_take_reuse_n(v_x2_24827, 3ULL, 2);
    V v_m_24830 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24831 = heff_tr(heff_call(v_m_24830, 1, (V[]){v_s_24829}));
    switch (heff_tag_of(v_x2_24831)) {
    case TAG_MkPair: {
      V v_x_24832 = heff_field(v_x2_24831, 0);
      V v_s_24833 = heff_field(v_x2_24831, 1);
      heff_take_n(v_x2_24831, 3ULL, 2);
      V v_m_24834 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24835 = heff_tr(heff_call(v_m_24834, 1, (V[]){v_s_24833}));
      switch (heff_tag_of(v_x2_24835)) {
      case TAG_MkPair: {
        V v_x_24836 = heff_field(v_x2_24835, 0);
        V v_s_24837 = heff_field(v_x2_24835, 1);
        heff_take_n(v_x2_24835, 3ULL, 2);
        V v_t_24838 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str188), heff_strAppend(v_x_24836, ((V)&g_heff_2ecompile_2eemitc_2etestC_str189)));
        V v_t_24839 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str190), heff_strAppend(v_x_24832, v_t_24838));
        V v_t_24840 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str191), heff_strAppend(v_x_24828, v_t_24839));
        return heff_tag_at_n(v_ru_24x2_24827_24MkPair, TAG_MkPair, 2, (V[]){v_t_24840, v_s_24837});
      }
      default: return heff_nomatch(v_x2_24835);
      }
    }
    default: return heff_nomatch(v_x2_24831);
    }
  }
  default: return heff_nomatch(v_x2_24827);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args) {
  V v_s_24845 = args[0];
  V v_m_24844 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24846 = heff_tr(heff_call(v_m_24844, 1, (V[]){v_s_24845}));
  switch (heff_tag_of(v_x2_24846)) {
  case TAG_MkPair: {
    V v_x_24847 = heff_field(v_x2_24846, 0);
    V v_s_24848 = heff_field(v_x2_24846, 1);
    V v_ru_24x2_24846_24MkPair = heff_take_reuse_n(v_x2_24846, 3ULL, 2);
    V v_m_24849 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24850 = heff_tr(heff_call(v_m_24849, 1, (V[]){v_s_24848}));
    switch (heff_tag_of(v_x2_24850)) {
    case TAG_MkPair: {
      V v_x_24851 = heff_field(v_x2_24850, 0);
      V v_s_24852 = heff_field(v_x2_24850, 1);
      heff_take_n(v_x2_24850, 3ULL, 2);
      V v_m_24853 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24854 = heff_tr(heff_call(v_m_24853, 1, (V[]){v_s_24852}));
      switch (heff_tag_of(v_x2_24854)) {
      case TAG_MkPair: {
        V v_x_24855 = heff_field(v_x2_24854, 0);
        V v_s_24856 = heff_field(v_x2_24854, 1);
        heff_take_n(v_x2_24854, 3ULL, 2);
        V v_t_24857 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str192), heff_strAppend(v_x_24855, ((V)&g_heff_2ecompile_2eemitc_2etestC_str193)));
        V v_t_24858 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str194), heff_strAppend(v_x_24851, v_t_24857));
        V v_t_24859 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str195), heff_strAppend(v_x_24847, v_t_24858));
        return heff_tag_at_n(v_ru_24x2_24846_24MkPair, TAG_MkPair, 2, (V[]){v_t_24859, v_s_24856});
      }
      default: return heff_nomatch(v_x2_24854);
      }
    }
    default: return heff_nomatch(v_x2_24850);
    }
  }
  default: return heff_nomatch(v_x2_24846);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args) {
  V v_s_24865 = args[0];
  V v_m_24864 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24866 = heff_tr(heff_call(v_m_24864, 1, (V[]){v_s_24865}));
  switch (heff_tag_of(v_x2_24866)) {
  case TAG_MkPair: {
    V v_x_24867 = heff_field(v_x2_24866, 0);
    V v_s_24868 = heff_field(v_x2_24866, 1);
    V v_ru_24x2_24866_24MkPair = heff_take_reuse_n(v_x2_24866, 3ULL, 2);
    V v_m_24869 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24870 = heff_tr(heff_call(v_m_24869, 1, (V[]){v_s_24868}));
    switch (heff_tag_of(v_x2_24870)) {
    case TAG_MkPair: {
      V v_x_24871 = heff_field(v_x2_24870, 0);
      V v_s_24872 = heff_field(v_x2_24870, 1);
      heff_take_n(v_x2_24870, 3ULL, 2);
      V v_m_24873 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24874 = heff_tr(heff_call(v_m_24873, 1, (V[]){v_s_24872}));
      switch (heff_tag_of(v_x2_24874)) {
      case TAG_MkPair: {
        V v_x_24875 = heff_field(v_x2_24874, 0);
        V v_s_24876 = heff_field(v_x2_24874, 1);
        heff_take_n(v_x2_24874, 3ULL, 2);
        V v_t_24877 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str196), heff_strAppend(v_x_24875, ((V)&g_heff_2ecompile_2eemitc_2etestC_str197)));
        V v_t_24878 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str198), heff_strAppend(v_x_24871, v_t_24877));
        V v_t_24879 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str199), heff_strAppend(v_x_24867, v_t_24878));
        return heff_tag_at_n(v_ru_24x2_24866_24MkPair, TAG_MkPair, 2, (V[]){v_t_24879, v_s_24876});
      }
      default: return heff_nomatch(v_x2_24874);
      }
    }
    default: return heff_nomatch(v_x2_24870);
    }
  }
  default: return heff_nomatch(v_x2_24866);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args) {
  V v_s_24885 = args[0];
  V v_m_24884 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24886 = heff_tr(heff_call(v_m_24884, 1, (V[]){v_s_24885}));
  switch (heff_tag_of(v_x2_24886)) {
  case TAG_MkPair: {
    V v_x_24887 = heff_field(v_x2_24886, 0);
    V v_s_24888 = heff_field(v_x2_24886, 1);
    V v_ru_24x2_24886_24MkPair = heff_take_reuse_n(v_x2_24886, 3ULL, 2);
    V v_m_24889 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
    V v_x2_24890 = heff_tr(heff_call(v_m_24889, 1, (V[]){v_s_24888}));
    switch (heff_tag_of(v_x2_24890)) {
    case TAG_MkPair: {
      V v_x_24891 = heff_field(v_x2_24890, 0);
      V v_s_24892 = heff_field(v_x2_24890, 1);
      heff_take_n(v_x2_24890, 3ULL, 2);
      V v_t_24893 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str200), heff_strAppend(v_x_24891, ((V)&g_heff_2ecompile_2eemitc_2etestC_str201)));
      V v_t_24894 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str202), heff_strAppend(v_x_24887, v_t_24893));
      return heff_tag_at_n(v_ru_24x2_24886_24MkPair, TAG_MkPair, 2, (V[]){v_t_24894, v_s_24892});
    }
    default: return heff_nomatch(v_x2_24890);
    }
  }
  default: return heff_nomatch(v_x2_24886);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args) {
  V v_s_24896 = args[0];
  V v_m_24895 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24897 = heff_tr(heff_call(v_m_24895, 1, (V[]){v_s_24896}));
  switch (heff_tag_of(v_x2_24897)) {
  case TAG_MkPair: {
    V v_x_24898 = heff_field(v_x2_24897, 0);
    V v_s_24899 = heff_field(v_x2_24897, 1);
    V v_ru_24x2_24897_24MkPair = heff_take_reuse_n(v_x2_24897, 3ULL, 2);
    V v_m_24900 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24901 = heff_tr(heff_call(v_m_24900, 1, (V[]){v_s_24899}));
    switch (heff_tag_of(v_x2_24901)) {
    case TAG_MkPair: {
      V v_x_24902 = heff_field(v_x2_24901, 0);
      V v_s_24903 = heff_field(v_x2_24901, 1);
      heff_take_n(v_x2_24901, 3ULL, 2);
      V v_m_24904 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24905 = heff_tr(heff_call(v_m_24904, 1, (V[]){v_s_24903}));
      switch (heff_tag_of(v_x2_24905)) {
      case TAG_MkPair: {
        V v_x_24906 = heff_field(v_x2_24905, 0);
        V v_s_24907 = heff_field(v_x2_24905, 1);
        heff_take_n(v_x2_24905, 3ULL, 2);
        V v_t_24908 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str203), heff_strAppend(v_x_24906, ((V)&g_heff_2ecompile_2eemitc_2etestC_str204)));
        V v_t_24909 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str205), heff_strAppend(v_x_24902, v_t_24908));
        V v_t_24910 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str206), heff_strAppend(v_x_24898, v_t_24909));
        return heff_tag_at_n(v_ru_24x2_24897_24MkPair, TAG_MkPair, 2, (V[]){v_t_24910, v_s_24907});
      }
      default: return heff_nomatch(v_x2_24905);
      }
    }
    default: return heff_nomatch(v_x2_24901);
    }
  }
  default: return heff_nomatch(v_x2_24897);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args) {
  V v_s_24914 = args[0];
  V v_m_24913 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24915 = heff_tr(heff_call(v_m_24913, 1, (V[]){v_s_24914}));
  switch (heff_tag_of(v_x2_24915)) {
  case TAG_MkPair: {
    V v_x_24916 = heff_field(v_x2_24915, 0);
    V v_s_24917 = heff_field(v_x2_24915, 1);
    V v_ru_24x2_24915_24MkPair = heff_take_reuse_n(v_x2_24915, 3ULL, 2);
    V v_m_24918 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24919 = heff_tr(heff_call(v_m_24918, 1, (V[]){v_s_24917}));
    switch (heff_tag_of(v_x2_24919)) {
    case TAG_MkPair: {
      V v_x_24920 = heff_field(v_x2_24919, 0);
      V v_s_24921 = heff_field(v_x2_24919, 1);
      heff_take_n(v_x2_24919, 3ULL, 2);
      V v_m_24922 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24923 = heff_tr(heff_call(v_m_24922, 1, (V[]){v_s_24921}));
      switch (heff_tag_of(v_x2_24923)) {
      case TAG_MkPair: {
        V v_x_24924 = heff_field(v_x2_24923, 0);
        V v_s_24925 = heff_field(v_x2_24923, 1);
        heff_take_n(v_x2_24923, 3ULL, 2);
        V v_t_24926 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str207), heff_strAppend(v_x_24924, ((V)&g_heff_2ecompile_2eemitc_2etestC_str208)));
        V v_t_24927 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str209), heff_strAppend(v_x_24920, v_t_24926));
        V v_t_24928 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str210), heff_strAppend(v_x_24916, v_t_24927));
        return heff_tag_at_n(v_ru_24x2_24915_24MkPair, TAG_MkPair, 2, (V[]){v_t_24928, v_s_24925});
      }
      default: return heff_nomatch(v_x2_24923);
      }
    }
    default: return heff_nomatch(v_x2_24919);
    }
  }
  default: return heff_nomatch(v_x2_24915);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args) {
  V v_s_24932 = args[0];
  V v_m_24931 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24933 = heff_tr(heff_call(v_m_24931, 1, (V[]){v_s_24932}));
  switch (heff_tag_of(v_x2_24933)) {
  case TAG_MkPair: {
    V v_x_24934 = heff_field(v_x2_24933, 0);
    V v_s_24935 = heff_field(v_x2_24933, 1);
    V v_ru_24x2_24933_24MkPair = heff_take_reuse_n(v_x2_24933, 3ULL, 2);
    V v_m_24936 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24937 = heff_tr(heff_call(v_m_24936, 1, (V[]){v_s_24935}));
    switch (heff_tag_of(v_x2_24937)) {
    case TAG_MkPair: {
      V v_x_24938 = heff_field(v_x2_24937, 0);
      V v_s_24939 = heff_field(v_x2_24937, 1);
      heff_take_n(v_x2_24937, 3ULL, 2);
      V v_m_24940 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24941 = heff_tr(heff_call(v_m_24940, 1, (V[]){v_s_24939}));
      switch (heff_tag_of(v_x2_24941)) {
      case TAG_MkPair: {
        V v_x_24942 = heff_field(v_x2_24941, 0);
        V v_s_24943 = heff_field(v_x2_24941, 1);
        heff_take_n(v_x2_24941, 3ULL, 2);
        V v_t_24944 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str211), heff_strAppend(v_x_24942, ((V)&g_heff_2ecompile_2eemitc_2etestC_str212)));
        V v_t_24945 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str213), heff_strAppend(v_x_24938, v_t_24944));
        V v_t_24946 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str214), heff_strAppend(v_x_24934, v_t_24945));
        return heff_tag_at_n(v_ru_24x2_24933_24MkPair, TAG_MkPair, 2, (V[]){v_t_24946, v_s_24943});
      }
      default: return heff_nomatch(v_x2_24941);
      }
    }
    default: return heff_nomatch(v_x2_24937);
    }
  }
  default: return heff_nomatch(v_x2_24933);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args) {
  V v_s_24949 = args[0];
  V v_m_24948 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24950 = heff_tr(heff_call(v_m_24948, 1, (V[]){v_s_24949}));
  switch (heff_tag_of(v_x2_24950)) {
  case TAG_MkPair: {
    V v_x_24951 = heff_field(v_x2_24950, 0);
    V v_s_24952 = heff_field(v_x2_24950, 1);
    V v_ru_24x2_24950_24MkPair = heff_take_reuse_n(v_x2_24950, 3ULL, 2);
    V v_m_24953 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24954 = heff_tr(heff_call(v_m_24953, 1, (V[]){v_s_24952}));
    switch (heff_tag_of(v_x2_24954)) {
    case TAG_MkPair: {
      V v_x_24955 = heff_field(v_x2_24954, 0);
      V v_s_24956 = heff_field(v_x2_24954, 1);
      heff_take_n(v_x2_24954, 3ULL, 2);
      V v_m_24957 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24958 = heff_tr(heff_call(v_m_24957, 1, (V[]){v_s_24956}));
      switch (heff_tag_of(v_x2_24958)) {
      case TAG_MkPair: {
        V v_x_24959 = heff_field(v_x2_24958, 0);
        V v_s_24960 = heff_field(v_x2_24958, 1);
        heff_take_n(v_x2_24958, 3ULL, 2);
        V v_t_24961 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str215), heff_strAppend(v_x_24959, ((V)&g_heff_2ecompile_2eemitc_2etestC_str216)));
        V v_t_24962 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str217), heff_strAppend(v_x_24955, v_t_24961));
        V v_t_24963 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str218), heff_strAppend(v_x_24951, v_t_24962));
        return heff_tag_at_n(v_ru_24x2_24950_24MkPair, TAG_MkPair, 2, (V[]){v_t_24963, v_s_24960});
      }
      default: return heff_nomatch(v_x2_24958);
      }
    }
    default: return heff_nomatch(v_x2_24954);
    }
  }
  default: return heff_nomatch(v_x2_24950);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args) {
  V v_s_24966 = args[0];
  V v_m_24965 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24967 = heff_tr(heff_call(v_m_24965, 1, (V[]){v_s_24966}));
  switch (heff_tag_of(v_x2_24967)) {
  case TAG_MkPair: {
    V v_x_24968 = heff_field(v_x2_24967, 0);
    V v_s_24969 = heff_field(v_x2_24967, 1);
    V v_ru_24x2_24967_24MkPair = heff_take_reuse_n(v_x2_24967, 3ULL, 2);
    V v_m_24970 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24971 = heff_tr(heff_call(v_m_24970, 1, (V[]){v_s_24969}));
    switch (heff_tag_of(v_x2_24971)) {
    case TAG_MkPair: {
      V v_x_24972 = heff_field(v_x2_24971, 0);
      V v_s_24973 = heff_field(v_x2_24971, 1);
      heff_take_n(v_x2_24971, 3ULL, 2);
      V v_m_24974 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24975 = heff_tr(heff_call(v_m_24974, 1, (V[]){v_s_24973}));
      switch (heff_tag_of(v_x2_24975)) {
      case TAG_MkPair: {
        V v_x_24976 = heff_field(v_x2_24975, 0);
        V v_s_24977 = heff_field(v_x2_24975, 1);
        heff_take_n(v_x2_24975, 3ULL, 2);
        V v_t_24978 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str219), heff_strAppend(v_x_24976, ((V)&g_heff_2ecompile_2eemitc_2etestC_str220)));
        V v_t_24979 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str221), heff_strAppend(v_x_24972, v_t_24978));
        V v_t_24980 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str222), heff_strAppend(v_x_24968, v_t_24979));
        return heff_tag_at_n(v_ru_24x2_24967_24MkPair, TAG_MkPair, 2, (V[]){v_t_24980, v_s_24977});
      }
      default: return heff_nomatch(v_x2_24975);
      }
    }
    default: return heff_nomatch(v_x2_24971);
    }
  }
  default: return heff_nomatch(v_x2_24967);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args) {
  V v_s_24985 = args[0];
  V v_m_24984 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24986 = heff_tr(heff_call(v_m_24984, 1, (V[]){v_s_24985}));
  switch (heff_tag_of(v_x2_24986)) {
  case TAG_MkPair: {
    V v_x_24987 = heff_field(v_x2_24986, 0);
    V v_s_24988 = heff_field(v_x2_24986, 1);
    V v_ru_24x2_24986_24MkPair = heff_take_reuse_n(v_x2_24986, 3ULL, 2);
    V v_m_24989 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_24990 = heff_tr(heff_call(v_m_24989, 1, (V[]){v_s_24988}));
    switch (heff_tag_of(v_x2_24990)) {
    case TAG_MkPair: {
      V v_x_24991 = heff_field(v_x2_24990, 0);
      V v_s_24992 = heff_field(v_x2_24990, 1);
      heff_take_n(v_x2_24990, 3ULL, 2);
      V v_m_24993 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_24994 = heff_tr(heff_call(v_m_24993, 1, (V[]){v_s_24992}));
      switch (heff_tag_of(v_x2_24994)) {
      case TAG_MkPair: {
        V v_x_24995 = heff_field(v_x2_24994, 0);
        V v_s_24996 = heff_field(v_x2_24994, 1);
        heff_take_n(v_x2_24994, 3ULL, 2);
        V v_t_24997 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str223), heff_strAppend(v_x_24995, ((V)&g_heff_2ecompile_2eemitc_2etestC_str224)));
        V v_t_24998 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str225), heff_strAppend(v_x_24991, v_t_24997));
        V v_t_24999 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str226), heff_strAppend(v_x_24987, v_t_24998));
        return heff_tag_at_n(v_ru_24x2_24986_24MkPair, TAG_MkPair, 2, (V[]){v_t_24999, v_s_24996});
      }
      default: return heff_nomatch(v_x2_24994);
      }
    }
    default: return heff_nomatch(v_x2_24990);
    }
  }
  default: return heff_nomatch(v_x2_24986);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args) {
  V v_s_241005 = args[0];
  V v_m_241004 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2442 = heff_env(self)[2];
  V v_x23_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_241006 = heff_tr(heff_call(v_m_241004, 1, (V[]){v_s_241005}));
  switch (heff_tag_of(v_x2_241006)) {
  case TAG_MkPair: {
    V v_x_241007 = heff_field(v_x2_241006, 0);
    V v_s_241008 = heff_field(v_x2_241006, 1);
    V v_ru_24x2_241006_24MkPair = heff_take_reuse_n(v_x2_241006, 3ULL, 2);
    V v_m_241009 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2442));
    V v_x2_241010 = heff_tr(heff_call(v_m_241009, 1, (V[]){v_s_241008}));
    switch (heff_tag_of(v_x2_241010)) {
    case TAG_MkPair: {
      V v_x_241011 = heff_field(v_x2_241010, 0);
      V v_s_241012 = heff_field(v_x2_241010, 1);
      heff_take_n(v_x2_241010, 3ULL, 2);
      V v_m_241013 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2443));
      V v_x2_241014 = heff_tr(heff_call(v_m_241013, 1, (V[]){v_s_241012}));
      switch (heff_tag_of(v_x2_241014)) {
      case TAG_MkPair: {
        V v_x_241015 = heff_field(v_x2_241014, 0);
        V v_s_241016 = heff_field(v_x2_241014, 1);
        heff_take_n(v_x2_241014, 3ULL, 2);
        V v_t_241017 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str227), heff_strAppend(v_x_241015, ((V)&g_heff_2ecompile_2eemitc_2etestC_str228)));
        V v_t_241018 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str229), heff_strAppend(v_x_241011, v_t_241017));
        V v_t_241019 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str230), heff_strAppend(v_x_241007, v_t_241018));
        return heff_tag_at_n(v_ru_24x2_241006_24MkPair, TAG_MkPair, 2, (V[]){v_t_241019, v_s_241016});
      }
      default: return heff_nomatch(v_x2_241014);
      }
    }
    default: return heff_nomatch(v_x2_241010);
    }
  }
  default: return heff_nomatch(v_x2_241006);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args) {
  V v_s_241025 = args[0];
  V v_m_241024 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_241022 = heff_env(self)[2];
  V v_x_241020 = heff_env(self)[3];
  V v_drops_241023 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_241026 = heff_tr(heff_call(v_m_241024, 1, (V[]){v_s_241025}));
  switch (heff_tag_of(v_x2_241026)) {
  case TAG_MkPair: {
    V v_x_241027 = heff_field(v_x2_241026, 0);
    V v_s_241028 = heff_field(v_x2_241026, 1);
    V v_ru_24x2_241026_24MkPair = heff_take_reuse_n(v_x2_241026, 3ULL, 2);
    V v_m_241029 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_241022));
    V v_x2_241030 = heff_tr(heff_call(v_m_241029, 1, (V[]){v_s_241028}));
    switch (heff_tag_of(v_x2_241030)) {
    case TAG_MkPair: {
      V v_x_241031 = heff_field(v_x2_241030, 0);
      V v_s_241032 = heff_field(v_x2_241030, 1);
      heff_take_n(v_x2_241030, 3ULL, 2);
      V v_t_241033 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_241020)}));
      V v_t_241034 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241020, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str231)));
      V v_x2_241035 = (g_list_2emap_24s456133444x1904936646(((V)&g_heff_2ecompile_2eemitc_2etestC_str232), ((V)&g_heff_2ecompile_2eemitc_2etestC_str233), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str234), ((V)&g_heff_2ecompile_2eemitc_2etestC_str235), ((V)&g_heff_2ecompile_2eemitc_2etestC_str236), v_drops_241023));
      V v_t_241038;
      switch (heff_tag_of(v_x2_241035)) {
      case TAG_Nil: {
        v_t_241038 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str237);
        break;
      }
      case TAG_Cons: {
        V v_x_241036 = heff_field(v_x2_241035, 0);
        V v_xs_241037 = heff_field(v_x2_241035, 1);
        heff_take_n(v_x2_241035, 3ULL, 2);
        v_t_241038 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str238); V a_1 = v_x_241036; V a_2 = v_xs_241037; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_241037); r_; });
        break;
      }
      default: heff_nomatch(v_x2_241035);
      }
      V v_t_241039 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str239), heff_strAppend(v_t_241038, ((V)&g_heff_2ecompile_2eemitc_2etestC_str240)));
      V v_t_241040 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str241), heff_strAppend(v_x_241031, v_t_241039));
      V v_t_241041 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str242), heff_strAppend(v_x_241027, v_t_241040));
      V v_t_241042 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str243), v_t_241034), v_t_241041);
      V v_t_241043 = heff_strAppend(v_t_241033, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str244), v_t_241042));
      V v_x_241044 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str245), v_t_241043);
      return heff_tag_at_n(v_ru_24x2_241026_24MkPair, TAG_MkPair, 2, (V[]){v_x_241044, v_s_241032});
    }
    default: return heff_nomatch(v_x2_241030);
    }
  }
  default: return heff_nomatch(v_x2_241026);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str1, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str2, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str3, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str4, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str5, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str6, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str12, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2eflatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eflatLine_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eflatLine(V v_k_240, V v_sv_241, V v_sure_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_v_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str0)));
      V v_t_2410 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_i_246), v_sure_242));
      V v_t_2412;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        switch (heff_tag_of(v_r_247)) {
        case TAG_RepV: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str1);
          break;
        }
        case TAG_RepFix: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str2);
          break;
        }
        case TAG_RepF64: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str3);
          break;
        }
        default: heff_nomatch(v_r_247);
        }
      } else {
        heff_drop(v_t_2410);
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str4);
      }
      V v_t_2414;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str5);
        break;
      }
      case TAG_RepFix: {
        V v_w_2413 = heff_field(v_r_247, 0);
        v_t_2414 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_2413));
        break;
      }
      case TAG_RepF64: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str6);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2415 = heff_strAppend(heff_intShow(heff_dup(v_i_246)), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str7));
      V v_t_2416 = heff_strAppend(v_sv_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str8), v_t_2415));
      V v_t_2417 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str9), v_t_2416));
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str10), v_t_249), heff_strAppend(v_t_2412, v_t_2417));
      V v_t_2419 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str11), v_t_2418));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str12), v_t_2419);
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eflatLine(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_sure_246 = heff_field(v_x3_242, 3);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_leaves_2410 = heff_field(v_x3_242, 7);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 10, (V[]){v_m_2411, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_247), heff_dup(v_fields_244), v_k_240, heff_dup(v_sure_246), heff_dup(v_flats_245), heff_dup(v_take_248), heff_dup(v_leaves_2410)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_247 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_sure_246 = heff_env(self)[6];
  V v_flats_245 = heff_env(self)[7];
  V v_take_248 = heff_env(self)[8];
  V v_leaves_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2earmF_str0)));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str1), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2earmF_str2));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2417), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2efieldLine_clo), 2, (V[]){heff_dup(v_sv_241), v_plain_247}));
    V v_t_2420 = (g_list_2emap(v_t_2419, v_fields_244));
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eflatLine_clo), 3, (V[]){v_k_240, heff_dup(v_sv_241), v_sure_246}));
    V v_t_2422 = (g_list_2emap(v_t_2421, v_flats_245));
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
    V v_t_2424 = ({ V a_0 = v_sv_241; V a_1 = v_take_248; V r_ = (g_heff_2ecompile_2eemitc_2etakeLines(a_0, a_1)); heff_drop(v_take_248); r_; });
    V v_t_2425 = (g_list_2emap_24f1217399696x462307458(((V)&g_heff_2ecompile_2eemitc_2earmF_str4), v_t_2424, v_x_2414));
    V v_t_2426;
    if ((heff_dup(v_leaves_2410) == NTAG(TAG_True))) {
      heff_drop(v_leaves_2410);
      v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str5), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_2410);
      v_t_2426 = NTAG(TAG_Nil);
    }
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str6), NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2427));
    V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2428));
    V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2429));
    V v_x_2431 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2430));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
  return heff_strAppend(v_t_245, v_t_247);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 10, " return r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 2, "  ");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_bi_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_x2_247 = (g_list_2emap_24f1293205645x619162872(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7), v_t_246), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8), v_t_2412);
  } else {
    heff_drop(v_t_245);
    V v_x2_2413 = (g_list_2emap_24s353858844x950951807(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14)));
    V v_t_2418 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2422 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2418));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_x2_2426 = (g_list_2emap_24s1382928954x1260344933(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), v_bi_241));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26), heff_strAppend(v_t_2425, v_t_2430));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27), v_t_2417), v_t_2431);
    V v_t_2433 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28), v_t_2432));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29), v_t_2433);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = ({ V a_0 = heff_dup(v_i_2419); V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), heff_intShow(v_i_2419));
  } else {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_strAppend(heff_intShow(v_i_2419), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17), v_t_2421);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 22, "static const HeffName ");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s588563787x236154271(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7)));
  V v_t_2411 = heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8), v_t_2410));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9), v_t_2411), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str3, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str4, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str5, 14, "static V gget_");
Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 0, 7);
    V v_x3_245 = ({ V a_0 = heff_dup(v_key_243); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str0)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str1)));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str3));
      V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str4), v_t_249));
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str5), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalGet(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 42, "static const Global heff_globals_arr[] = {");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), heff_rfield(v_ce_242, 0)));
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), heff_rfield(v_ce_242, 1)));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2419));
  V v_t_2432;
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2429);
  }
  V v_x1_2437 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2437, 0ULL, 2);
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9);
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_t_2441 = heff_strAppend(v_t_2432, heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10)));
  V v_t_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f316845240x1272469554(a_0, a_1, a_2, a_3)); heff_drop(v_exports_240); r_; });
  V v_t_2447 = heff_strAppend(heff_intShow(v_t_2446), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11));
  V v_t_2448 = (g_map_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2449 = heff_strAppend(heff_intShow(v_t_2448), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12));
  V v_t_2450 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2451 = heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13));
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14), NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15), v_t_2451), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16), v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17), v_t_2449), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18), v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19), v_t_2447), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), v_t_2441), v_t_2456});
  V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2457));
  V v_t_2459 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2458));
  V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2459));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2460));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_t_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = v_t_247; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eglobalGet(v_ce_242, v_x_2410));
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_249));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  return ({ V a_0 = v_t_2418; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2420 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_p_2420, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2426;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_p_2420, 1);
    heff_take_n(v_p_2420, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2427 = (g_heff_2ecompile_2eemitc_2egetterOf(v_ce_242, v_t_2426));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5), heff_strAppend(v_t_2423, v_t_2428));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_p_2433 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_p_2433)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2433, 1);
    heff_take_n(v_p_2433, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2433);
  }
  return ({ V a_0 = v_t_2436; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2442 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 2ULL, 2);
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  return ({ V a_0 = v_t_2445; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 8, "uint64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 6, "double");

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_b_241), heff_dup(v_k_243))) {
    heff_drop(v_m_240);
    heff_drop(v_b_241);
    heff_drop(v_ps_242);
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_qs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}), heff_dup(v_ps_242)));
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(heff_dup(v_m_240), v_b_241, v_ps_242, heff_intAdd(heff_dup(v_k_243), MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_m_240);
      heff_drop(v_k_243);
      return v_rest_2411;
    }
    case TAG_Cons: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0), heff_intShow(v_k_243));
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_240, v_t_2414), v_qs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemitc_2ekeyHashGo(v_t_248, MK_INT(0LL), MK_INT(7LL)));
  return heff_intEq(heff_intMod(v_t_249, v_b_241), v_k_243);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str0, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str1, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str2, 17, "#define HEFF_PART");
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulesParts_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2emodulesParts(V v_ce_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_defs_245, V v_ems_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str0), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str2), v_t_247})});
  V v_t_249 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 6))));
  V v_t_2410 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 7))));
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emodulePart_clo), 8, (V[]){v_t_248, v_ce_240, heff_dup(v_s_241), v_t_249, v_t_2410, heff_dup(v_strs_242), heff_dup(v_protos_243), heff_dup(v_lams_244)}));
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2emodulesParts_lam0, 1, 4, (V[]){v_s_241, v_strs_242, v_protos_243, v_lams_244})}));
  V v_t_2415 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_245, v_ems_246));
  V v_m_2416 = (g_list_2efoldl_24s96111113x2107485159(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2415));
  V v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2416); r_; });
  V v_t_2418 = (g_list_2econcatMap(v_t_2414, v_t_2417));
  return (g_list_2emap(v_t_2411, v_t_2418));
}
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emodulesParts(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_strs_242 = heff_env(self)[1];
  V v_protos_243 = heff_env(self)[2];
  V v_lams_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2413 = ({ V a_0 = v_s_241; V a_1 = v_strs_242; V a_2 = v_protos_243; V a_3 = v_lams_244; V a_4 = v_p_2412; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_241, 8); heff_drop(v_strs_242); heff_drop(v_protos_243); heff_drop(v_lams_244); heff_drop(v_p_2412); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2413; V r_ = (g_list_2efoldl_24s1894035205x969464323(a_0, a_1, a_2)); heff_drop(v_ls_2413); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 7);
  V v_x2_244 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 7);
  V v_x3_248 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_247; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_248, 0ULL, 1);
    v_t_2410 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 7);
  V v_x2_2412 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2411; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_x2_2415 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 4, 7);
  V v_x3_2420 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2419; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_Nothing: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x3_2420, 0);
    heff_take_n(v_x3_2420, 1ULL, 1);
    v_t_2422 = (g_heff_2ecompile_2erepr_2esigName(v_x_2421));
    break;
  }
  default: heff_nomatch(v_x3_2420);
  }
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2422}), v_rest_242});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2418}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2410}), v_t_2424});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_246}), v_t_2425});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2426});
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epushOwn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str1, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreshEmitted_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efreshEmitted(V v_acc_240, V v_key_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_s1_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_244), heff_take_field(v_acc_240, 0)});
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str0)));
    V v_t_248 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_242), heff_dup(v_e_244), heff_dup(v_s1_245)));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str1), v_t_247), v_t_248, heff_take_field(v_acc_240, 1)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_242, v_e_244, v_s1_245));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_key_241, v_t_2410}), heff_get_n(v_acc_240, 2, 3)});
    return heff_rec_n(3, shape_ems__s__fresh, (V[]){v_t_246, v_t_249, v_t_2411});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efreshEmitted(a[0], a[1], a[2], a[3]);
}