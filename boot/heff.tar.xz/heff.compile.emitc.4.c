// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_MkCArm 24694
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_ctype 296362551
#define LBL_ems 310085
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_workers 1757018875
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2egetterOf(V, V);
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egetterOf_clo;
V g_heff_2ecompile_2eemitc_2eglobalGet(V, V);
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elibmNames_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2erelU(V, V);
V g_heff_2ecompile_2eemitc_2erelU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelU_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etakeLines(V, V);
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeLines_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_list_2eany_24s1177057410x67789151(V, V);
V g_list_2eany_24s1177057410x67789151_entry(V self, V *a);
extern Clo g_list_2eany_24s1177057410x67789151_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24f316845240x1272469554(V, V, V, V);
V g_list_2efoldl_24f316845240x1272469554_entry(V self, V *a);
extern Clo g_list_2efoldl_24f316845240x1272469554_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s96111113x2107485159(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s96111113x2107485159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96111113x2107485159_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1382928954x1260344933(V, V, V);
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s353858844x950951807(V, V, V, V);
V g_list_2emap_24s353858844x950951807_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s588563787x236154271(V, V, V, V);
V g_list_2emap_24s588563787x236154271_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eshowInt_get(void);
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2415));
    V v_x2_2420 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_ls_2417, v_ls2_2422));
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, v_t_2423});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2424 = heff_field(v_x1_240, 0);
    V v_l_2425 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2428 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2424));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_ts_2429 = heff_field(v_x2_2428, 0);
      V v_ls2_2430 = heff_field(v_x2_2428, 1);
      V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_2425, NTAG(TAG_Nil)});
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ls2_2430));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2429, v_t_2432});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  case TAG_ETag: {
    V v_t_2433 = heff_field(v_x1_240, 0);
    V v_as_2434 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2434));
    V v_x2_2438 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2436, v_t_2437));
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_MkPair: {
      V v_ts2_2439 = heff_field(v_x2_2438, 0);
      V v_ls_2440 = heff_field(v_x2_2438, 1);
      V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2441, v_ts2_2439));
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_t_2442, v_ls_2440});
    }
    default: return heff_nomatch(v_x2_2438);
    }
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_x1_240, 0);
    V v_arms_2444 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2445 = (g_list_2emap_24s1009200955x251267316(heff_dup(v_arms_2444)));
    V v_t_2446 = (g_list_2emap_24s60612435x257154841(v_arms_2444));
    V v_es_2447 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2443, v_t_2446});
    V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2447));
    V v_x2_2450 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2448, v_t_2449));
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_MkPair: {
      V v_ts2_2451 = heff_field(v_x2_2450, 0);
      V v_ls_2452 = heff_field(v_x2_2450, 1);
      V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
      V v_t_2453 = (g_prelude_2e_2b_2b(v_ts_2445, v_ts2_2451));
      return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_t_2453, v_ls_2452});
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2457 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2456));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2457, v_t_2458));
  }
  case TAG_ECall: {
    V v_as_2460 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2461 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2460));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2461, v_t_2462));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength(heff_dup(v_text_240)))) {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt(heff_dup(v_text_240), heff_dup(v_i_242))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_244);
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_text_240), heff_dup(v_i_242)), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 5, "((V)&");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str1)));
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), v_t_244);
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_247 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str2), v_t_247));
  V v_t_249 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str6), heff_strAppend(v_t_249, v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str7), heff_strAppend(v_t_248, v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_mac_240, v_t_2413)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_246; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str8), v_t_245), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str0, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str1, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str2, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str3, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str4, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str5, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str6, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str7, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str8, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str9, 3, "log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str10, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str11, 3, "exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str12, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str13, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str14, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str15, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str16, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str17, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str18, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str19, 3, "tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str20, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str21, 3, "cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str22, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str23, 3, "sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str24, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str25, 4, "sqrt");

static V g_heff_2ecompile_2eemitc_2elibmNames_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elibmNames_st;
static V g_heff_2ecompile_2eemitc_2elibmNames_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str0), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str2), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str4), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str6), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str8), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str10), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str12), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str14), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str16), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str18), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str19)}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str20), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str21)}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str22), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str23)}), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str24), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str25)}), v_t_2411});
}
V g_heff_2ecompile_2eemitc_2elibmNames_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elibmNames_st)) return g_heff_2ecompile_2eemitc_2elibmNames_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elibmNames_val, &g_heff_2ecompile_2eemitc_2elibmNames_st, g_heff_2ecompile_2eemitc_2elibmNames_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str65, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str66, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str67, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str68, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str69, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str70, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str71, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str72, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str73, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str74, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str75, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str76, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str77, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str78, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str80, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str81, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str82, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str84, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str85, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str86, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str87, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str88, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str89, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str90, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str91, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str92, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str93, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str94, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str95, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str96, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str97, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str98, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str99, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str100, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str101, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str102, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str103, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str104, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str105, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str106, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str107, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str108, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str109, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str110, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str111, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str112, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str113, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str114, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str115, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str116, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str117, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str118, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str119, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str120, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str121, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str122, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str123, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str124, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str125, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str127, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str128, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str129, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str130, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str131, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str132, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str133, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str134, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str135, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str136, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str137, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str138, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str139, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str140, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str141, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str142, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str143, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str144, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str145, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str146, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str147, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str148, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str149, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str150, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str151, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str152, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str153, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str154, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str155, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str156, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str157, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str158, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str159, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str160, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str161, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str162, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str163, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str164, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str165, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str166, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str167, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str168, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str169, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str170, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str171, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str172, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str173, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str174, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str175, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str176, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str177, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str178, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str179, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str180, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str181, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str182, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str183, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str184, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str185, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str186, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str187, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str188, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str189, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str190, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str191, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str192, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str193, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str194, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str195, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str196, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str197, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str198, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str199, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str200, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str201, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str202, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str203, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str204, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str205, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str206, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str207, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str208, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str209, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str210, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str211, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str212, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str213, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str214, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str215, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str216, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str217, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str218, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str220, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str221, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str222, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str223, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str224, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str225, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str226, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str227, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str228, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str229, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str230, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str231, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str232, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str233, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str234, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str235, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str238, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str239, 6, "c_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str240, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str241, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str242, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str243, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str244, 3, "({ ");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_245));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_246, v_p_244});
  }
  case TAG_CondRelU: {
    V v_p_2416 = heff_field(v_x2_241, 0);
    V v_es_2417 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_2417));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2418, v_p_2416});
  }
  case TAG_CondBool: {
    V v_e_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2425 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2424}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2425});
  }
  case TAG_CondNot: {
    V v_c_2431 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2432 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2431));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2432});
  }
  case TAG_CondIf: {
    V v_a_2437 = heff_field(v_x2_241, 0);
    V v_b_2438 = heff_field(v_x2_241, 1);
    V v_x23_2439 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2439)) {
    case TAG_CondTrue: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_2440 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2440, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_2451 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 4, (V[]){v_m_2451, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_2469 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2469, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_2487 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 4, (V[]){v_m_2487, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24104 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam10, 1, 4, (V[]){v_m_24104, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24121 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam11, 1, 4, (V[]){v_m_24121, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24140 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam12, 1, 4, (V[]){v_m_24140, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24160 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam13, 1, 4, (V[]){v_m_24160, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondFalse: {
      V v_m_24176 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam14, 1, 3, (V[]){v_m_24176, v_k_240, v_b_2438});
    }
    case TAG_CondRel: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24189 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam15, 1, 3, (V[]){v_m_24189, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24200 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam16, 1, 4, (V[]){v_m_24200, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24218 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam17, 1, 4, (V[]){v_m_24218, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24236 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam18, 1, 4, (V[]){v_m_24236, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24253 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam19, 1, 4, (V[]){v_m_24253, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24270 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam20, 1, 4, (V[]){v_m_24270, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24289 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam21, 1, 4, (V[]){v_m_24289, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24309 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam22, 1, 4, (V[]){v_m_24309, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondRelU: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24327 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam23, 1, 3, (V[]){v_m_24327, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24338 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam24, 1, 4, (V[]){v_m_24338, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24356 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam25, 1, 4, (V[]){v_m_24356, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24374 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam26, 1, 4, (V[]){v_m_24374, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24391 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam27, 1, 4, (V[]){v_m_24391, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24408 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam28, 1, 4, (V[]){v_m_24408, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24427 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam29, 1, 4, (V[]){v_m_24427, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24447 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam30, 1, 4, (V[]){v_m_24447, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondBool: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24464 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam31, 1, 3, (V[]){v_m_24464, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24475 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam32, 1, 4, (V[]){v_m_24475, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24493 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam33, 1, 4, (V[]){v_m_24493, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24511 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam34, 1, 4, (V[]){v_m_24511, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24528 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam35, 1, 4, (V[]){v_m_24528, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24545 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam36, 1, 4, (V[]){v_m_24545, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24564 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam37, 1, 4, (V[]){v_m_24564, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24584 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam38, 1, 4, (V[]){v_m_24584, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondNot: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24601 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam39, 1, 3, (V[]){v_m_24601, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24612 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam40, 1, 4, (V[]){v_m_24612, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24630 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam41, 1, 4, (V[]){v_m_24630, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24648 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam42, 1, 4, (V[]){v_m_24648, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24665 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam43, 1, 4, (V[]){v_m_24665, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24682 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam44, 1, 4, (V[]){v_m_24682, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24701 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam45, 1, 4, (V[]){v_m_24701, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24721 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam46, 1, 4, (V[]){v_m_24721, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondIf: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24740 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam47, 1, 3, (V[]){v_m_24740, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24751 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam48, 1, 4, (V[]){v_m_24751, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24769 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam49, 1, 4, (V[]){v_m_24769, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24787 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam50, 1, 4, (V[]){v_m_24787, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24804 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam51, 1, 4, (V[]){v_m_24804, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24821 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam52, 1, 4, (V[]){v_m_24821, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24840 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam53, 1, 4, (V[]){v_m_24840, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_24860 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam54, 1, 4, (V[]){v_m_24860, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    case TAG_CondLet: {
      switch (heff_tag_of(v_b_2438)) {
      case TAG_CondTrue: {
        V v_m_24880 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam55, 1, 3, (V[]){v_m_24880, v_k_240, v_x23_2439});
      }
      case TAG_CondFalse: {
        V v_m_24891 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam56, 1, 4, (V[]){v_m_24891, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRel: {
        V v_m_24909 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam57, 1, 4, (V[]){v_m_24909, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondRelU: {
        V v_m_24927 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam58, 1, 4, (V[]){v_m_24927, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondBool: {
        V v_m_24944 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam59, 1, 4, (V[]){v_m_24944, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondNot: {
        V v_m_24961 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam60, 1, 4, (V[]){v_m_24961, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondIf: {
        V v_m_24980 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam61, 1, 4, (V[]){v_m_24980, v_k_240, v_b_2438, v_x23_2439});
      }
      case TAG_CondLet: {
        V v_m_241000 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2437));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam62, 1, 4, (V[]){v_m_241000, v_k_240, v_b_2438, v_x23_2439});
      }
      default: return heff_nomatch(v_b_2438);
      }
    }
    default: return heff_nomatch(v_x23_2439);
    }
  }
  case TAG_CondLet: {
    V v_x_241016 = heff_field(v_x2_241, 0);
    V v_e_241017 = heff_field(v_x2_241, 1);
    V v_c_241018 = heff_field(v_x2_241, 2);
    V v_drops_241019 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_241020 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_241017}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam63, 1, 5, (V[]){v_m_241020, v_k_240, v_c_241018, v_x_241016, v_drops_241019});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etestC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x_249, 0);
      V v_xs_2412 = heff_field(v_x_249, 1);
      heff_take_n(v_x_249, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2etestC_str5)));
    V v_x_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str6), v_p_244), v_t_2414);
    return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_p_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_s_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_x_2423 = (g_heff_2ecompile_2eemitc_2erelU(v_p_2416, v_x_2421));
    return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_s_2426}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_s_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str7), heff_strAppend(v_x_2428, ((V)&g_heff_2ecompile_2eemitc_2etestC_str8)));
    return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_s_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_s_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str9), v_x_2435), v_s_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_m_2445 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_s_2444}));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_s_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      V v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str10), heff_strAppend(v_x_2447, ((V)&g_heff_2ecompile_2eemitc_2etestC_str11)));
      V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str12), heff_strAppend(v_x_2443, v_t_2449));
      return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){v_t_2450, v_s_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_s_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_s_2455 = heff_field(v_x2_2453, 1);
    V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
    V v_m_2456 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2455}));
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_MkPair: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_s_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      V v_m_2460 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_s_2459}));
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_MkPair: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        V v_s_2463 = heff_field(v_x2_2461, 1);
        heff_take_n(v_x2_2461, 3ULL, 2);
        V v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str13), heff_strAppend(v_x_2462, ((V)&g_heff_2ecompile_2eemitc_2etestC_str14)));
        V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str15), heff_strAppend(v_x_2458, v_t_2464));
        V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str16), heff_strAppend(v_x_2454, v_t_2465));
        return heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_MkPair, 2, (V[]){v_t_2466, v_s_2463});
      }
      default: return heff_nomatch(v_x2_2461);
      }
    }
    default: return heff_nomatch(v_x2_2457);
    }
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_m_2474 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_2475 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2475)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x2_2475, 0);
      V v_s_2477 = heff_field(v_x2_2475, 1);
      heff_take_n(v_x2_2475, 3ULL, 2);
      V v_m_2478 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_s_2477}));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        heff_take_n(v_x2_2479, 3ULL, 2);
        V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str17), heff_strAppend(v_x_2480, ((V)&g_heff_2ecompile_2eemitc_2etestC_str18)));
        V v_t_2483 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str19), heff_strAppend(v_x_2476, v_t_2482));
        V v_t_2484 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str20), heff_strAppend(v_x_2472, v_t_2483));
        return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_t_2484, v_s_2481});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
    default: return heff_nomatch(v_x2_2475);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_m_2492 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_s_2491}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_s_2495 = heff_field(v_x2_2493, 1);
      heff_take_n(v_x2_2493, 3ULL, 2);
      V v_m_2496 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2495}));
      switch (heff_tag_of(v_x2_2497)) {
      case TAG_MkPair: {
        V v_x_2498 = heff_field(v_x2_2497, 0);
        V v_s_2499 = heff_field(v_x2_2497, 1);
        heff_take_n(v_x2_2497, 3ULL, 2);
        V v_t_24100 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str21), heff_strAppend(v_x_2498, ((V)&g_heff_2ecompile_2eemitc_2etestC_str22)));
        V v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str23), heff_strAppend(v_x_2494, v_t_24100));
        V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str24), heff_strAppend(v_x_2490, v_t_24101));
        return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){v_t_24102, v_s_2499});
      }
      default: return heff_nomatch(v_x2_2497);
      }
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    V v_m_24109 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_s_24108}));
    switch (heff_tag_of(v_x2_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x2_24110, 0);
      V v_s_24112 = heff_field(v_x2_24110, 1);
      heff_take_n(v_x2_24110, 3ULL, 2);
      V v_m_24113 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_s_24112}));
      switch (heff_tag_of(v_x2_24114)) {
      case TAG_MkPair: {
        V v_x_24115 = heff_field(v_x2_24114, 0);
        V v_s_24116 = heff_field(v_x2_24114, 1);
        heff_take_n(v_x2_24114, 3ULL, 2);
        V v_t_24117 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str25), heff_strAppend(v_x_24115, ((V)&g_heff_2ecompile_2eemitc_2etestC_str26)));
        V v_t_24118 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str27), heff_strAppend(v_x_24111, v_t_24117));
        V v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str28), heff_strAppend(v_x_24107, v_t_24118));
        return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){v_t_24119, v_s_24116});
      }
      default: return heff_nomatch(v_x2_24114);
      }
    }
    default: return heff_nomatch(v_x2_24110);
    }
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args) {
  V v_s_24122 = args[0];
  V v_m_24121 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24123 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_s_24122}));
  switch (heff_tag_of(v_x2_24123)) {
  case TAG_MkPair: {
    V v_x_24124 = heff_field(v_x2_24123, 0);
    V v_s_24125 = heff_field(v_x2_24123, 1);
    V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
    V v_m_24126 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24127 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24125}));
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_s_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      V v_m_24130 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_s_24129}));
      switch (heff_tag_of(v_x2_24131)) {
      case TAG_MkPair: {
        V v_x_24132 = heff_field(v_x2_24131, 0);
        V v_s_24133 = heff_field(v_x2_24131, 1);
        heff_take_n(v_x2_24131, 3ULL, 2);
        V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str29), heff_strAppend(v_x_24132, ((V)&g_heff_2ecompile_2eemitc_2etestC_str30)));
        V v_t_24135 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str31), heff_strAppend(v_x_24128, v_t_24134));
        V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str32), heff_strAppend(v_x_24124, v_t_24135));
        return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){v_t_24136, v_s_24133});
      }
      default: return heff_nomatch(v_x2_24131);
      }
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_x2_24123);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args) {
  V v_s_24141 = args[0];
  V v_m_24140 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24142 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_s_24141}));
  switch (heff_tag_of(v_x2_24142)) {
  case TAG_MkPair: {
    V v_x_24143 = heff_field(v_x2_24142, 0);
    V v_s_24144 = heff_field(v_x2_24142, 1);
    V v_ru_24x2_24142_24MkPair = heff_take_reuse_n(v_x2_24142, 3ULL, 2);
    V v_m_24145 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24146 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_s_24144}));
    switch (heff_tag_of(v_x2_24146)) {
    case TAG_MkPair: {
      V v_x_24147 = heff_field(v_x2_24146, 0);
      V v_s_24148 = heff_field(v_x2_24146, 1);
      heff_take_n(v_x2_24146, 3ULL, 2);
      V v_m_24149 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24150 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24148}));
      switch (heff_tag_of(v_x2_24150)) {
      case TAG_MkPair: {
        V v_x_24151 = heff_field(v_x2_24150, 0);
        V v_s_24152 = heff_field(v_x2_24150, 1);
        heff_take_n(v_x2_24150, 3ULL, 2);
        V v_t_24153 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str33), heff_strAppend(v_x_24151, ((V)&g_heff_2ecompile_2eemitc_2etestC_str34)));
        V v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str35), heff_strAppend(v_x_24147, v_t_24153));
        V v_t_24155 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str36), heff_strAppend(v_x_24143, v_t_24154));
        return heff_tag_at_n(v_ru_24x2_24142_24MkPair, TAG_MkPair, 2, (V[]){v_t_24155, v_s_24152});
      }
      default: return heff_nomatch(v_x2_24150);
      }
    }
    default: return heff_nomatch(v_x2_24146);
    }
  }
  default: return heff_nomatch(v_x2_24142);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args) {
  V v_s_24161 = args[0];
  V v_m_24160 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24162 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_s_24161}));
  switch (heff_tag_of(v_x2_24162)) {
  case TAG_MkPair: {
    V v_x_24163 = heff_field(v_x2_24162, 0);
    V v_s_24164 = heff_field(v_x2_24162, 1);
    V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
    V v_m_24165 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24166 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24164}));
    switch (heff_tag_of(v_x2_24166)) {
    case TAG_MkPair: {
      V v_x_24167 = heff_field(v_x2_24166, 0);
      V v_s_24168 = heff_field(v_x2_24166, 1);
      heff_take_n(v_x2_24166, 3ULL, 2);
      V v_m_24169 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_s_24168}));
      switch (heff_tag_of(v_x2_24170)) {
      case TAG_MkPair: {
        V v_x_24171 = heff_field(v_x2_24170, 0);
        V v_s_24172 = heff_field(v_x2_24170, 1);
        heff_take_n(v_x2_24170, 3ULL, 2);
        V v_t_24173 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), heff_strAppend(v_x_24171, ((V)&g_heff_2ecompile_2eemitc_2etestC_str38)));
        V v_t_24174 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str39), heff_strAppend(v_x_24167, v_t_24173));
        V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), heff_strAppend(v_x_24163, v_t_24174));
        return heff_tag_at_n(v_ru_24x2_24162_24MkPair, TAG_MkPair, 2, (V[]){v_t_24175, v_s_24172});
      }
      default: return heff_nomatch(v_x2_24170);
      }
    }
    default: return heff_nomatch(v_x2_24166);
    }
  }
  default: return heff_nomatch(v_x2_24162);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args) {
  V v_s_24177 = args[0];
  V v_m_24176 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24178 = heff_tr(heff_call(v_m_24176, 1, (V[]){v_s_24177}));
  switch (heff_tag_of(v_x2_24178)) {
  case TAG_MkPair: {
    V v_x_24179 = heff_field(v_x2_24178, 0);
    V v_s_24180 = heff_field(v_x2_24178, 1);
    V v_ru_24x2_24178_24MkPair = heff_take_reuse_n(v_x2_24178, 3ULL, 2);
    V v_m_24181 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2438));
    V v_x2_24182 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_s_24180}));
    switch (heff_tag_of(v_x2_24182)) {
    case TAG_MkPair: {
      V v_x_24183 = heff_field(v_x2_24182, 0);
      V v_s_24184 = heff_field(v_x2_24182, 1);
      heff_take_n(v_x2_24182, 3ULL, 2);
      V v_t_24185 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str41), heff_strAppend(v_x_24183, ((V)&g_heff_2ecompile_2eemitc_2etestC_str42)));
      V v_t_24186 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str43), heff_strAppend(v_x_24179, v_t_24185));
      return heff_tag_at_n(v_ru_24x2_24178_24MkPair, TAG_MkPair, 2, (V[]){v_t_24186, v_s_24184});
    }
    default: return heff_nomatch(v_x2_24182);
    }
  }
  default: return heff_nomatch(v_x2_24178);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
    V v_m_24194 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24195 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_s_24193}));
    switch (heff_tag_of(v_x2_24195)) {
    case TAG_MkPair: {
      V v_x_24196 = heff_field(v_x2_24195, 0);
      V v_s_24197 = heff_field(v_x2_24195, 1);
      heff_take_n(v_x2_24195, 3ULL, 2);
      V v_t_24198 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str44), heff_strAppend(v_x_24196, ((V)&g_heff_2ecompile_2eemitc_2etestC_str45)));
      V v_t_24199 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str46), heff_strAppend(v_x_24192, v_t_24198));
      return heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_MkPair, 2, (V[]){v_t_24199, v_s_24197});
    }
    default: return heff_nomatch(v_x2_24195);
    }
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args) {
  V v_s_24201 = args[0];
  V v_m_24200 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24202 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_s_24201}));
  switch (heff_tag_of(v_x2_24202)) {
  case TAG_MkPair: {
    V v_x_24203 = heff_field(v_x2_24202, 0);
    V v_s_24204 = heff_field(v_x2_24202, 1);
    V v_ru_24x2_24202_24MkPair = heff_take_reuse_n(v_x2_24202, 3ULL, 2);
    V v_m_24205 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24206 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24204}));
    switch (heff_tag_of(v_x2_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x2_24206, 0);
      V v_s_24208 = heff_field(v_x2_24206, 1);
      heff_take_n(v_x2_24206, 3ULL, 2);
      V v_m_24209 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24210 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_s_24208}));
      switch (heff_tag_of(v_x2_24210)) {
      case TAG_MkPair: {
        V v_x_24211 = heff_field(v_x2_24210, 0);
        V v_s_24212 = heff_field(v_x2_24210, 1);
        heff_take_n(v_x2_24210, 3ULL, 2);
        V v_t_24213 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str47), heff_strAppend(v_x_24211, ((V)&g_heff_2ecompile_2eemitc_2etestC_str48)));
        V v_t_24214 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str49), heff_strAppend(v_x_24207, v_t_24213));
        V v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str50), heff_strAppend(v_x_24203, v_t_24214));
        return heff_tag_at_n(v_ru_24x2_24202_24MkPair, TAG_MkPair, 2, (V[]){v_t_24215, v_s_24212});
      }
      default: return heff_nomatch(v_x2_24210);
      }
    }
    default: return heff_nomatch(v_x2_24206);
    }
  }
  default: return heff_nomatch(v_x2_24202);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args) {
  V v_s_24219 = args[0];
  V v_m_24218 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24220 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_s_24219}));
  switch (heff_tag_of(v_x2_24220)) {
  case TAG_MkPair: {
    V v_x_24221 = heff_field(v_x2_24220, 0);
    V v_s_24222 = heff_field(v_x2_24220, 1);
    V v_ru_24x2_24220_24MkPair = heff_take_reuse_n(v_x2_24220, 3ULL, 2);
    V v_m_24223 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24224 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_s_24222}));
    switch (heff_tag_of(v_x2_24224)) {
    case TAG_MkPair: {
      V v_x_24225 = heff_field(v_x2_24224, 0);
      V v_s_24226 = heff_field(v_x2_24224, 1);
      heff_take_n(v_x2_24224, 3ULL, 2);
      V v_m_24227 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24228 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_s_24226}));
      switch (heff_tag_of(v_x2_24228)) {
      case TAG_MkPair: {
        V v_x_24229 = heff_field(v_x2_24228, 0);
        V v_s_24230 = heff_field(v_x2_24228, 1);
        heff_take_n(v_x2_24228, 3ULL, 2);
        V v_t_24231 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str51), heff_strAppend(v_x_24229, ((V)&g_heff_2ecompile_2eemitc_2etestC_str52)));
        V v_t_24232 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str53), heff_strAppend(v_x_24225, v_t_24231));
        V v_t_24233 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str54), heff_strAppend(v_x_24221, v_t_24232));
        return heff_tag_at_n(v_ru_24x2_24220_24MkPair, TAG_MkPair, 2, (V[]){v_t_24233, v_s_24230});
      }
      default: return heff_nomatch(v_x2_24228);
      }
    }
    default: return heff_nomatch(v_x2_24224);
    }
  }
  default: return heff_nomatch(v_x2_24220);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_m_24241 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24242 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_s_24240}));
    switch (heff_tag_of(v_x2_24242)) {
    case TAG_MkPair: {
      V v_x_24243 = heff_field(v_x2_24242, 0);
      V v_s_24244 = heff_field(v_x2_24242, 1);
      heff_take_n(v_x2_24242, 3ULL, 2);
      V v_m_24245 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24246 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_s_24244}));
      switch (heff_tag_of(v_x2_24246)) {
      case TAG_MkPair: {
        V v_x_24247 = heff_field(v_x2_24246, 0);
        V v_s_24248 = heff_field(v_x2_24246, 1);
        heff_take_n(v_x2_24246, 3ULL, 2);
        V v_t_24249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str55), heff_strAppend(v_x_24247, ((V)&g_heff_2ecompile_2eemitc_2etestC_str56)));
        V v_t_24250 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str57), heff_strAppend(v_x_24243, v_t_24249));
        V v_t_24251 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str58), heff_strAppend(v_x_24239, v_t_24250));
        return heff_tag_at_n(v_ru_24x2_24238_24MkPair, TAG_MkPair, 2, (V[]){v_t_24251, v_s_24248});
      }
      default: return heff_nomatch(v_x2_24246);
      }
    }
    default: return heff_nomatch(v_x2_24242);
    }
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args) {
  V v_s_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_s_24254}));
  switch (heff_tag_of(v_x2_24255)) {
  case TAG_MkPair: {
    V v_x_24256 = heff_field(v_x2_24255, 0);
    V v_s_24257 = heff_field(v_x2_24255, 1);
    V v_ru_24x2_24255_24MkPair = heff_take_reuse_n(v_x2_24255, 3ULL, 2);
    V v_m_24258 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24259 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_s_24257}));
    switch (heff_tag_of(v_x2_24259)) {
    case TAG_MkPair: {
      V v_x_24260 = heff_field(v_x2_24259, 0);
      V v_s_24261 = heff_field(v_x2_24259, 1);
      heff_take_n(v_x2_24259, 3ULL, 2);
      V v_m_24262 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24263 = heff_tr(heff_call(v_m_24262, 1, (V[]){v_s_24261}));
      switch (heff_tag_of(v_x2_24263)) {
      case TAG_MkPair: {
        V v_x_24264 = heff_field(v_x2_24263, 0);
        V v_s_24265 = heff_field(v_x2_24263, 1);
        heff_take_n(v_x2_24263, 3ULL, 2);
        V v_t_24266 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str59), heff_strAppend(v_x_24264, ((V)&g_heff_2ecompile_2eemitc_2etestC_str60)));
        V v_t_24267 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str61), heff_strAppend(v_x_24260, v_t_24266));
        V v_t_24268 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str62), heff_strAppend(v_x_24256, v_t_24267));
        return heff_tag_at_n(v_ru_24x2_24255_24MkPair, TAG_MkPair, 2, (V[]){v_t_24268, v_s_24265});
      }
      default: return heff_nomatch(v_x2_24263);
      }
    }
    default: return heff_nomatch(v_x2_24259);
    }
  }
  default: return heff_nomatch(v_x2_24255);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args) {
  V v_s_24271 = args[0];
  V v_m_24270 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24272 = heff_tr(heff_call(v_m_24270, 1, (V[]){v_s_24271}));
  switch (heff_tag_of(v_x2_24272)) {
  case TAG_MkPair: {
    V v_x_24273 = heff_field(v_x2_24272, 0);
    V v_s_24274 = heff_field(v_x2_24272, 1);
    V v_ru_24x2_24272_24MkPair = heff_take_reuse_n(v_x2_24272, 3ULL, 2);
    V v_m_24275 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24276 = heff_tr(heff_call(v_m_24275, 1, (V[]){v_s_24274}));
    switch (heff_tag_of(v_x2_24276)) {
    case TAG_MkPair: {
      V v_x_24277 = heff_field(v_x2_24276, 0);
      V v_s_24278 = heff_field(v_x2_24276, 1);
      heff_take_n(v_x2_24276, 3ULL, 2);
      V v_m_24279 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24280 = heff_tr(heff_call(v_m_24279, 1, (V[]){v_s_24278}));
      switch (heff_tag_of(v_x2_24280)) {
      case TAG_MkPair: {
        V v_x_24281 = heff_field(v_x2_24280, 0);
        V v_s_24282 = heff_field(v_x2_24280, 1);
        heff_take_n(v_x2_24280, 3ULL, 2);
        V v_t_24283 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str63), heff_strAppend(v_x_24281, ((V)&g_heff_2ecompile_2eemitc_2etestC_str64)));
        V v_t_24284 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str65), heff_strAppend(v_x_24277, v_t_24283));
        V v_t_24285 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str66), heff_strAppend(v_x_24273, v_t_24284));
        return heff_tag_at_n(v_ru_24x2_24272_24MkPair, TAG_MkPair, 2, (V[]){v_t_24285, v_s_24282});
      }
      default: return heff_nomatch(v_x2_24280);
      }
    }
    default: return heff_nomatch(v_x2_24276);
    }
  }
  default: return heff_nomatch(v_x2_24272);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args) {
  V v_s_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24291 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_s_24290}));
  switch (heff_tag_of(v_x2_24291)) {
  case TAG_MkPair: {
    V v_x_24292 = heff_field(v_x2_24291, 0);
    V v_s_24293 = heff_field(v_x2_24291, 1);
    V v_ru_24x2_24291_24MkPair = heff_take_reuse_n(v_x2_24291, 3ULL, 2);
    V v_m_24294 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24295 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_s_24293}));
    switch (heff_tag_of(v_x2_24295)) {
    case TAG_MkPair: {
      V v_x_24296 = heff_field(v_x2_24295, 0);
      V v_s_24297 = heff_field(v_x2_24295, 1);
      heff_take_n(v_x2_24295, 3ULL, 2);
      V v_m_24298 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24299 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_s_24297}));
      switch (heff_tag_of(v_x2_24299)) {
      case TAG_MkPair: {
        V v_x_24300 = heff_field(v_x2_24299, 0);
        V v_s_24301 = heff_field(v_x2_24299, 1);
        heff_take_n(v_x2_24299, 3ULL, 2);
        V v_t_24302 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str67), heff_strAppend(v_x_24300, ((V)&g_heff_2ecompile_2eemitc_2etestC_str68)));
        V v_t_24303 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str69), heff_strAppend(v_x_24296, v_t_24302));
        V v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str70), heff_strAppend(v_x_24292, v_t_24303));
        return heff_tag_at_n(v_ru_24x2_24291_24MkPair, TAG_MkPair, 2, (V[]){v_t_24304, v_s_24301});
      }
      default: return heff_nomatch(v_x2_24299);
      }
    }
    default: return heff_nomatch(v_x2_24295);
    }
  }
  default: return heff_nomatch(v_x2_24291);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args) {
  V v_s_24310 = args[0];
  V v_m_24309 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24311 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_s_24310}));
  switch (heff_tag_of(v_x2_24311)) {
  case TAG_MkPair: {
    V v_x_24312 = heff_field(v_x2_24311, 0);
    V v_s_24313 = heff_field(v_x2_24311, 1);
    V v_ru_24x2_24311_24MkPair = heff_take_reuse_n(v_x2_24311, 3ULL, 2);
    V v_m_24314 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24315 = heff_tr(heff_call(v_m_24314, 1, (V[]){v_s_24313}));
    switch (heff_tag_of(v_x2_24315)) {
    case TAG_MkPair: {
      V v_x_24316 = heff_field(v_x2_24315, 0);
      V v_s_24317 = heff_field(v_x2_24315, 1);
      heff_take_n(v_x2_24315, 3ULL, 2);
      V v_m_24318 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24319 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_s_24317}));
      switch (heff_tag_of(v_x2_24319)) {
      case TAG_MkPair: {
        V v_x_24320 = heff_field(v_x2_24319, 0);
        V v_s_24321 = heff_field(v_x2_24319, 1);
        heff_take_n(v_x2_24319, 3ULL, 2);
        V v_t_24322 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str71), heff_strAppend(v_x_24320, ((V)&g_heff_2ecompile_2eemitc_2etestC_str72)));
        V v_t_24323 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str73), heff_strAppend(v_x_24316, v_t_24322));
        V v_t_24324 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str74), heff_strAppend(v_x_24312, v_t_24323));
        return heff_tag_at_n(v_ru_24x2_24311_24MkPair, TAG_MkPair, 2, (V[]){v_t_24324, v_s_24321});
      }
      default: return heff_nomatch(v_x2_24319);
      }
    }
    default: return heff_nomatch(v_x2_24315);
    }
  }
  default: return heff_nomatch(v_x2_24311);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args) {
  V v_s_24328 = args[0];
  V v_m_24327 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24329 = heff_tr(heff_call(v_m_24327, 1, (V[]){v_s_24328}));
  switch (heff_tag_of(v_x2_24329)) {
  case TAG_MkPair: {
    V v_x_24330 = heff_field(v_x2_24329, 0);
    V v_s_24331 = heff_field(v_x2_24329, 1);
    V v_ru_24x2_24329_24MkPair = heff_take_reuse_n(v_x2_24329, 3ULL, 2);
    V v_m_24332 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24333 = heff_tr(heff_call(v_m_24332, 1, (V[]){v_s_24331}));
    switch (heff_tag_of(v_x2_24333)) {
    case TAG_MkPair: {
      V v_x_24334 = heff_field(v_x2_24333, 0);
      V v_s_24335 = heff_field(v_x2_24333, 1);
      heff_take_n(v_x2_24333, 3ULL, 2);
      V v_t_24336 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str75), heff_strAppend(v_x_24334, ((V)&g_heff_2ecompile_2eemitc_2etestC_str76)));
      V v_t_24337 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str77), heff_strAppend(v_x_24330, v_t_24336));
      return heff_tag_at_n(v_ru_24x2_24329_24MkPair, TAG_MkPair, 2, (V[]){v_t_24337, v_s_24335});
    }
    default: return heff_nomatch(v_x2_24333);
    }
  }
  default: return heff_nomatch(v_x2_24329);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args) {
  V v_s_24339 = args[0];
  V v_m_24338 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24340 = heff_tr(heff_call(v_m_24338, 1, (V[]){v_s_24339}));
  switch (heff_tag_of(v_x2_24340)) {
  case TAG_MkPair: {
    V v_x_24341 = heff_field(v_x2_24340, 0);
    V v_s_24342 = heff_field(v_x2_24340, 1);
    V v_ru_24x2_24340_24MkPair = heff_take_reuse_n(v_x2_24340, 3ULL, 2);
    V v_m_24343 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24344 = heff_tr(heff_call(v_m_24343, 1, (V[]){v_s_24342}));
    switch (heff_tag_of(v_x2_24344)) {
    case TAG_MkPair: {
      V v_x_24345 = heff_field(v_x2_24344, 0);
      V v_s_24346 = heff_field(v_x2_24344, 1);
      heff_take_n(v_x2_24344, 3ULL, 2);
      V v_m_24347 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24348 = heff_tr(heff_call(v_m_24347, 1, (V[]){v_s_24346}));
      switch (heff_tag_of(v_x2_24348)) {
      case TAG_MkPair: {
        V v_x_24349 = heff_field(v_x2_24348, 0);
        V v_s_24350 = heff_field(v_x2_24348, 1);
        heff_take_n(v_x2_24348, 3ULL, 2);
        V v_t_24351 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str78), heff_strAppend(v_x_24349, ((V)&g_heff_2ecompile_2eemitc_2etestC_str79)));
        V v_t_24352 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str80), heff_strAppend(v_x_24345, v_t_24351));
        V v_t_24353 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str81), heff_strAppend(v_x_24341, v_t_24352));
        return heff_tag_at_n(v_ru_24x2_24340_24MkPair, TAG_MkPair, 2, (V[]){v_t_24353, v_s_24350});
      }
      default: return heff_nomatch(v_x2_24348);
      }
    }
    default: return heff_nomatch(v_x2_24344);
    }
  }
  default: return heff_nomatch(v_x2_24340);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args) {
  V v_s_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_s_24357}));
  switch (heff_tag_of(v_x2_24358)) {
  case TAG_MkPair: {
    V v_x_24359 = heff_field(v_x2_24358, 0);
    V v_s_24360 = heff_field(v_x2_24358, 1);
    V v_ru_24x2_24358_24MkPair = heff_take_reuse_n(v_x2_24358, 3ULL, 2);
    V v_m_24361 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24362 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_s_24360}));
    switch (heff_tag_of(v_x2_24362)) {
    case TAG_MkPair: {
      V v_x_24363 = heff_field(v_x2_24362, 0);
      V v_s_24364 = heff_field(v_x2_24362, 1);
      heff_take_n(v_x2_24362, 3ULL, 2);
      V v_m_24365 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24366 = heff_tr(heff_call(v_m_24365, 1, (V[]){v_s_24364}));
      switch (heff_tag_of(v_x2_24366)) {
      case TAG_MkPair: {
        V v_x_24367 = heff_field(v_x2_24366, 0);
        V v_s_24368 = heff_field(v_x2_24366, 1);
        heff_take_n(v_x2_24366, 3ULL, 2);
        V v_t_24369 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str82), heff_strAppend(v_x_24367, ((V)&g_heff_2ecompile_2eemitc_2etestC_str83)));
        V v_t_24370 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str84), heff_strAppend(v_x_24363, v_t_24369));
        V v_t_24371 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str85), heff_strAppend(v_x_24359, v_t_24370));
        return heff_tag_at_n(v_ru_24x2_24358_24MkPair, TAG_MkPair, 2, (V[]){v_t_24371, v_s_24368});
      }
      default: return heff_nomatch(v_x2_24366);
      }
    }
    default: return heff_nomatch(v_x2_24362);
    }
  }
  default: return heff_nomatch(v_x2_24358);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args) {
  V v_s_24375 = args[0];
  V v_m_24374 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24376 = heff_tr(heff_call(v_m_24374, 1, (V[]){v_s_24375}));
  switch (heff_tag_of(v_x2_24376)) {
  case TAG_MkPair: {
    V v_x_24377 = heff_field(v_x2_24376, 0);
    V v_s_24378 = heff_field(v_x2_24376, 1);
    V v_ru_24x2_24376_24MkPair = heff_take_reuse_n(v_x2_24376, 3ULL, 2);
    V v_m_24379 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24380 = heff_tr(heff_call(v_m_24379, 1, (V[]){v_s_24378}));
    switch (heff_tag_of(v_x2_24380)) {
    case TAG_MkPair: {
      V v_x_24381 = heff_field(v_x2_24380, 0);
      V v_s_24382 = heff_field(v_x2_24380, 1);
      heff_take_n(v_x2_24380, 3ULL, 2);
      V v_m_24383 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24384 = heff_tr(heff_call(v_m_24383, 1, (V[]){v_s_24382}));
      switch (heff_tag_of(v_x2_24384)) {
      case TAG_MkPair: {
        V v_x_24385 = heff_field(v_x2_24384, 0);
        V v_s_24386 = heff_field(v_x2_24384, 1);
        heff_take_n(v_x2_24384, 3ULL, 2);
        V v_t_24387 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str86), heff_strAppend(v_x_24385, ((V)&g_heff_2ecompile_2eemitc_2etestC_str87)));
        V v_t_24388 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str88), heff_strAppend(v_x_24381, v_t_24387));
        V v_t_24389 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str89), heff_strAppend(v_x_24377, v_t_24388));
        return heff_tag_at_n(v_ru_24x2_24376_24MkPair, TAG_MkPair, 2, (V[]){v_t_24389, v_s_24386});
      }
      default: return heff_nomatch(v_x2_24384);
      }
    }
    default: return heff_nomatch(v_x2_24380);
    }
  }
  default: return heff_nomatch(v_x2_24376);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args) {
  V v_s_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_s_24392}));
  switch (heff_tag_of(v_x2_24393)) {
  case TAG_MkPair: {
    V v_x_24394 = heff_field(v_x2_24393, 0);
    V v_s_24395 = heff_field(v_x2_24393, 1);
    V v_ru_24x2_24393_24MkPair = heff_take_reuse_n(v_x2_24393, 3ULL, 2);
    V v_m_24396 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24397 = heff_tr(heff_call(v_m_24396, 1, (V[]){v_s_24395}));
    switch (heff_tag_of(v_x2_24397)) {
    case TAG_MkPair: {
      V v_x_24398 = heff_field(v_x2_24397, 0);
      V v_s_24399 = heff_field(v_x2_24397, 1);
      heff_take_n(v_x2_24397, 3ULL, 2);
      V v_m_24400 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24401 = heff_tr(heff_call(v_m_24400, 1, (V[]){v_s_24399}));
      switch (heff_tag_of(v_x2_24401)) {
      case TAG_MkPair: {
        V v_x_24402 = heff_field(v_x2_24401, 0);
        V v_s_24403 = heff_field(v_x2_24401, 1);
        heff_take_n(v_x2_24401, 3ULL, 2);
        V v_t_24404 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str90), heff_strAppend(v_x_24402, ((V)&g_heff_2ecompile_2eemitc_2etestC_str91)));
        V v_t_24405 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str92), heff_strAppend(v_x_24398, v_t_24404));
        V v_t_24406 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str93), heff_strAppend(v_x_24394, v_t_24405));
        return heff_tag_at_n(v_ru_24x2_24393_24MkPair, TAG_MkPair, 2, (V[]){v_t_24406, v_s_24403});
      }
      default: return heff_nomatch(v_x2_24401);
      }
    }
    default: return heff_nomatch(v_x2_24397);
    }
  }
  default: return heff_nomatch(v_x2_24393);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args) {
  V v_s_24409 = args[0];
  V v_m_24408 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24410 = heff_tr(heff_call(v_m_24408, 1, (V[]){v_s_24409}));
  switch (heff_tag_of(v_x2_24410)) {
  case TAG_MkPair: {
    V v_x_24411 = heff_field(v_x2_24410, 0);
    V v_s_24412 = heff_field(v_x2_24410, 1);
    V v_ru_24x2_24410_24MkPair = heff_take_reuse_n(v_x2_24410, 3ULL, 2);
    V v_m_24413 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24414 = heff_tr(heff_call(v_m_24413, 1, (V[]){v_s_24412}));
    switch (heff_tag_of(v_x2_24414)) {
    case TAG_MkPair: {
      V v_x_24415 = heff_field(v_x2_24414, 0);
      V v_s_24416 = heff_field(v_x2_24414, 1);
      heff_take_n(v_x2_24414, 3ULL, 2);
      V v_m_24417 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24418 = heff_tr(heff_call(v_m_24417, 1, (V[]){v_s_24416}));
      switch (heff_tag_of(v_x2_24418)) {
      case TAG_MkPair: {
        V v_x_24419 = heff_field(v_x2_24418, 0);
        V v_s_24420 = heff_field(v_x2_24418, 1);
        heff_take_n(v_x2_24418, 3ULL, 2);
        V v_t_24421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str94), heff_strAppend(v_x_24419, ((V)&g_heff_2ecompile_2eemitc_2etestC_str95)));
        V v_t_24422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str96), heff_strAppend(v_x_24415, v_t_24421));
        V v_t_24423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str97), heff_strAppend(v_x_24411, v_t_24422));
        return heff_tag_at_n(v_ru_24x2_24410_24MkPair, TAG_MkPair, 2, (V[]){v_t_24423, v_s_24420});
      }
      default: return heff_nomatch(v_x2_24418);
      }
    }
    default: return heff_nomatch(v_x2_24414);
    }
  }
  default: return heff_nomatch(v_x2_24410);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args) {
  V v_s_24428 = args[0];
  V v_m_24427 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24429 = heff_tr(heff_call(v_m_24427, 1, (V[]){v_s_24428}));
  switch (heff_tag_of(v_x2_24429)) {
  case TAG_MkPair: {
    V v_x_24430 = heff_field(v_x2_24429, 0);
    V v_s_24431 = heff_field(v_x2_24429, 1);
    V v_ru_24x2_24429_24MkPair = heff_take_reuse_n(v_x2_24429, 3ULL, 2);
    V v_m_24432 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24433 = heff_tr(heff_call(v_m_24432, 1, (V[]){v_s_24431}));
    switch (heff_tag_of(v_x2_24433)) {
    case TAG_MkPair: {
      V v_x_24434 = heff_field(v_x2_24433, 0);
      V v_s_24435 = heff_field(v_x2_24433, 1);
      heff_take_n(v_x2_24433, 3ULL, 2);
      V v_m_24436 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24437 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_s_24435}));
      switch (heff_tag_of(v_x2_24437)) {
      case TAG_MkPair: {
        V v_x_24438 = heff_field(v_x2_24437, 0);
        V v_s_24439 = heff_field(v_x2_24437, 1);
        heff_take_n(v_x2_24437, 3ULL, 2);
        V v_t_24440 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str98), heff_strAppend(v_x_24438, ((V)&g_heff_2ecompile_2eemitc_2etestC_str99)));
        V v_t_24441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str100), heff_strAppend(v_x_24434, v_t_24440));
        V v_t_24442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str101), heff_strAppend(v_x_24430, v_t_24441));
        return heff_tag_at_n(v_ru_24x2_24429_24MkPair, TAG_MkPair, 2, (V[]){v_t_24442, v_s_24439});
      }
      default: return heff_nomatch(v_x2_24437);
      }
    }
    default: return heff_nomatch(v_x2_24433);
    }
  }
  default: return heff_nomatch(v_x2_24429);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args) {
  V v_s_24448 = args[0];
  V v_m_24447 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24449 = heff_tr(heff_call(v_m_24447, 1, (V[]){v_s_24448}));
  switch (heff_tag_of(v_x2_24449)) {
  case TAG_MkPair: {
    V v_x_24450 = heff_field(v_x2_24449, 0);
    V v_s_24451 = heff_field(v_x2_24449, 1);
    V v_ru_24x2_24449_24MkPair = heff_take_reuse_n(v_x2_24449, 3ULL, 2);
    V v_m_24452 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24453 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_s_24451}));
    switch (heff_tag_of(v_x2_24453)) {
    case TAG_MkPair: {
      V v_x_24454 = heff_field(v_x2_24453, 0);
      V v_s_24455 = heff_field(v_x2_24453, 1);
      heff_take_n(v_x2_24453, 3ULL, 2);
      V v_m_24456 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24457 = heff_tr(heff_call(v_m_24456, 1, (V[]){v_s_24455}));
      switch (heff_tag_of(v_x2_24457)) {
      case TAG_MkPair: {
        V v_x_24458 = heff_field(v_x2_24457, 0);
        V v_s_24459 = heff_field(v_x2_24457, 1);
        heff_take_n(v_x2_24457, 3ULL, 2);
        V v_t_24460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str102), heff_strAppend(v_x_24458, ((V)&g_heff_2ecompile_2eemitc_2etestC_str103)));
        V v_t_24461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str104), heff_strAppend(v_x_24454, v_t_24460));
        V v_t_24462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str105), heff_strAppend(v_x_24450, v_t_24461));
        return heff_tag_at_n(v_ru_24x2_24449_24MkPair, TAG_MkPair, 2, (V[]){v_t_24462, v_s_24459});
      }
      default: return heff_nomatch(v_x2_24457);
      }
    }
    default: return heff_nomatch(v_x2_24453);
    }
  }
  default: return heff_nomatch(v_x2_24449);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args) {
  V v_s_24465 = args[0];
  V v_m_24464 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24466 = heff_tr(heff_call(v_m_24464, 1, (V[]){v_s_24465}));
  switch (heff_tag_of(v_x2_24466)) {
  case TAG_MkPair: {
    V v_x_24467 = heff_field(v_x2_24466, 0);
    V v_s_24468 = heff_field(v_x2_24466, 1);
    V v_ru_24x2_24466_24MkPair = heff_take_reuse_n(v_x2_24466, 3ULL, 2);
    V v_m_24469 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24470 = heff_tr(heff_call(v_m_24469, 1, (V[]){v_s_24468}));
    switch (heff_tag_of(v_x2_24470)) {
    case TAG_MkPair: {
      V v_x_24471 = heff_field(v_x2_24470, 0);
      V v_s_24472 = heff_field(v_x2_24470, 1);
      heff_take_n(v_x2_24470, 3ULL, 2);
      V v_t_24473 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str106), heff_strAppend(v_x_24471, ((V)&g_heff_2ecompile_2eemitc_2etestC_str107)));
      V v_t_24474 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str108), heff_strAppend(v_x_24467, v_t_24473));
      return heff_tag_at_n(v_ru_24x2_24466_24MkPair, TAG_MkPair, 2, (V[]){v_t_24474, v_s_24472});
    }
    default: return heff_nomatch(v_x2_24470);
    }
  }
  default: return heff_nomatch(v_x2_24466);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args) {
  V v_s_24476 = args[0];
  V v_m_24475 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24477 = heff_tr(heff_call(v_m_24475, 1, (V[]){v_s_24476}));
  switch (heff_tag_of(v_x2_24477)) {
  case TAG_MkPair: {
    V v_x_24478 = heff_field(v_x2_24477, 0);
    V v_s_24479 = heff_field(v_x2_24477, 1);
    V v_ru_24x2_24477_24MkPair = heff_take_reuse_n(v_x2_24477, 3ULL, 2);
    V v_m_24480 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24481 = heff_tr(heff_call(v_m_24480, 1, (V[]){v_s_24479}));
    switch (heff_tag_of(v_x2_24481)) {
    case TAG_MkPair: {
      V v_x_24482 = heff_field(v_x2_24481, 0);
      V v_s_24483 = heff_field(v_x2_24481, 1);
      heff_take_n(v_x2_24481, 3ULL, 2);
      V v_m_24484 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24485 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_s_24483}));
      switch (heff_tag_of(v_x2_24485)) {
      case TAG_MkPair: {
        V v_x_24486 = heff_field(v_x2_24485, 0);
        V v_s_24487 = heff_field(v_x2_24485, 1);
        heff_take_n(v_x2_24485, 3ULL, 2);
        V v_t_24488 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str109), heff_strAppend(v_x_24486, ((V)&g_heff_2ecompile_2eemitc_2etestC_str110)));
        V v_t_24489 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str111), heff_strAppend(v_x_24482, v_t_24488));
        V v_t_24490 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str112), heff_strAppend(v_x_24478, v_t_24489));
        return heff_tag_at_n(v_ru_24x2_24477_24MkPair, TAG_MkPair, 2, (V[]){v_t_24490, v_s_24487});
      }
      default: return heff_nomatch(v_x2_24485);
      }
    }
    default: return heff_nomatch(v_x2_24481);
    }
  }
  default: return heff_nomatch(v_x2_24477);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args) {
  V v_s_24494 = args[0];
  V v_m_24493 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24495 = heff_tr(heff_call(v_m_24493, 1, (V[]){v_s_24494}));
  switch (heff_tag_of(v_x2_24495)) {
  case TAG_MkPair: {
    V v_x_24496 = heff_field(v_x2_24495, 0);
    V v_s_24497 = heff_field(v_x2_24495, 1);
    V v_ru_24x2_24495_24MkPair = heff_take_reuse_n(v_x2_24495, 3ULL, 2);
    V v_m_24498 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24499 = heff_tr(heff_call(v_m_24498, 1, (V[]){v_s_24497}));
    switch (heff_tag_of(v_x2_24499)) {
    case TAG_MkPair: {
      V v_x_24500 = heff_field(v_x2_24499, 0);
      V v_s_24501 = heff_field(v_x2_24499, 1);
      heff_take_n(v_x2_24499, 3ULL, 2);
      V v_m_24502 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24503 = heff_tr(heff_call(v_m_24502, 1, (V[]){v_s_24501}));
      switch (heff_tag_of(v_x2_24503)) {
      case TAG_MkPair: {
        V v_x_24504 = heff_field(v_x2_24503, 0);
        V v_s_24505 = heff_field(v_x2_24503, 1);
        heff_take_n(v_x2_24503, 3ULL, 2);
        V v_t_24506 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str113), heff_strAppend(v_x_24504, ((V)&g_heff_2ecompile_2eemitc_2etestC_str114)));
        V v_t_24507 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str115), heff_strAppend(v_x_24500, v_t_24506));
        V v_t_24508 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str116), heff_strAppend(v_x_24496, v_t_24507));
        return heff_tag_at_n(v_ru_24x2_24495_24MkPair, TAG_MkPair, 2, (V[]){v_t_24508, v_s_24505});
      }
      default: return heff_nomatch(v_x2_24503);
      }
    }
    default: return heff_nomatch(v_x2_24499);
    }
  }
  default: return heff_nomatch(v_x2_24495);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args) {
  V v_s_24512 = args[0];
  V v_m_24511 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24513 = heff_tr(heff_call(v_m_24511, 1, (V[]){v_s_24512}));
  switch (heff_tag_of(v_x2_24513)) {
  case TAG_MkPair: {
    V v_x_24514 = heff_field(v_x2_24513, 0);
    V v_s_24515 = heff_field(v_x2_24513, 1);
    V v_ru_24x2_24513_24MkPair = heff_take_reuse_n(v_x2_24513, 3ULL, 2);
    V v_m_24516 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24517 = heff_tr(heff_call(v_m_24516, 1, (V[]){v_s_24515}));
    switch (heff_tag_of(v_x2_24517)) {
    case TAG_MkPair: {
      V v_x_24518 = heff_field(v_x2_24517, 0);
      V v_s_24519 = heff_field(v_x2_24517, 1);
      heff_take_n(v_x2_24517, 3ULL, 2);
      V v_m_24520 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24521 = heff_tr(heff_call(v_m_24520, 1, (V[]){v_s_24519}));
      switch (heff_tag_of(v_x2_24521)) {
      case TAG_MkPair: {
        V v_x_24522 = heff_field(v_x2_24521, 0);
        V v_s_24523 = heff_field(v_x2_24521, 1);
        heff_take_n(v_x2_24521, 3ULL, 2);
        V v_t_24524 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str117), heff_strAppend(v_x_24522, ((V)&g_heff_2ecompile_2eemitc_2etestC_str118)));
        V v_t_24525 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str119), heff_strAppend(v_x_24518, v_t_24524));
        V v_t_24526 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str120), heff_strAppend(v_x_24514, v_t_24525));
        return heff_tag_at_n(v_ru_24x2_24513_24MkPair, TAG_MkPair, 2, (V[]){v_t_24526, v_s_24523});
      }
      default: return heff_nomatch(v_x2_24521);
      }
    }
    default: return heff_nomatch(v_x2_24517);
    }
  }
  default: return heff_nomatch(v_x2_24513);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args) {
  V v_s_24529 = args[0];
  V v_m_24528 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24530 = heff_tr(heff_call(v_m_24528, 1, (V[]){v_s_24529}));
  switch (heff_tag_of(v_x2_24530)) {
  case TAG_MkPair: {
    V v_x_24531 = heff_field(v_x2_24530, 0);
    V v_s_24532 = heff_field(v_x2_24530, 1);
    V v_ru_24x2_24530_24MkPair = heff_take_reuse_n(v_x2_24530, 3ULL, 2);
    V v_m_24533 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24534 = heff_tr(heff_call(v_m_24533, 1, (V[]){v_s_24532}));
    switch (heff_tag_of(v_x2_24534)) {
    case TAG_MkPair: {
      V v_x_24535 = heff_field(v_x2_24534, 0);
      V v_s_24536 = heff_field(v_x2_24534, 1);
      heff_take_n(v_x2_24534, 3ULL, 2);
      V v_m_24537 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24538 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_s_24536}));
      switch (heff_tag_of(v_x2_24538)) {
      case TAG_MkPair: {
        V v_x_24539 = heff_field(v_x2_24538, 0);
        V v_s_24540 = heff_field(v_x2_24538, 1);
        heff_take_n(v_x2_24538, 3ULL, 2);
        V v_t_24541 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str121), heff_strAppend(v_x_24539, ((V)&g_heff_2ecompile_2eemitc_2etestC_str122)));
        V v_t_24542 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str123), heff_strAppend(v_x_24535, v_t_24541));
        V v_t_24543 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str124), heff_strAppend(v_x_24531, v_t_24542));
        return heff_tag_at_n(v_ru_24x2_24530_24MkPair, TAG_MkPair, 2, (V[]){v_t_24543, v_s_24540});
      }
      default: return heff_nomatch(v_x2_24538);
      }
    }
    default: return heff_nomatch(v_x2_24534);
    }
  }
  default: return heff_nomatch(v_x2_24530);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args) {
  V v_s_24546 = args[0];
  V v_m_24545 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24547 = heff_tr(heff_call(v_m_24545, 1, (V[]){v_s_24546}));
  switch (heff_tag_of(v_x2_24547)) {
  case TAG_MkPair: {
    V v_x_24548 = heff_field(v_x2_24547, 0);
    V v_s_24549 = heff_field(v_x2_24547, 1);
    V v_ru_24x2_24547_24MkPair = heff_take_reuse_n(v_x2_24547, 3ULL, 2);
    V v_m_24550 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24551 = heff_tr(heff_call(v_m_24550, 1, (V[]){v_s_24549}));
    switch (heff_tag_of(v_x2_24551)) {
    case TAG_MkPair: {
      V v_x_24552 = heff_field(v_x2_24551, 0);
      V v_s_24553 = heff_field(v_x2_24551, 1);
      heff_take_n(v_x2_24551, 3ULL, 2);
      V v_m_24554 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24555 = heff_tr(heff_call(v_m_24554, 1, (V[]){v_s_24553}));
      switch (heff_tag_of(v_x2_24555)) {
      case TAG_MkPair: {
        V v_x_24556 = heff_field(v_x2_24555, 0);
        V v_s_24557 = heff_field(v_x2_24555, 1);
        heff_take_n(v_x2_24555, 3ULL, 2);
        V v_t_24558 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str125), heff_strAppend(v_x_24556, ((V)&g_heff_2ecompile_2eemitc_2etestC_str126)));
        V v_t_24559 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str127), heff_strAppend(v_x_24552, v_t_24558));
        V v_t_24560 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str128), heff_strAppend(v_x_24548, v_t_24559));
        return heff_tag_at_n(v_ru_24x2_24547_24MkPair, TAG_MkPair, 2, (V[]){v_t_24560, v_s_24557});
      }
      default: return heff_nomatch(v_x2_24555);
      }
    }
    default: return heff_nomatch(v_x2_24551);
    }
  }
  default: return heff_nomatch(v_x2_24547);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args) {
  V v_s_24565 = args[0];
  V v_m_24564 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24566 = heff_tr(heff_call(v_m_24564, 1, (V[]){v_s_24565}));
  switch (heff_tag_of(v_x2_24566)) {
  case TAG_MkPair: {
    V v_x_24567 = heff_field(v_x2_24566, 0);
    V v_s_24568 = heff_field(v_x2_24566, 1);
    V v_ru_24x2_24566_24MkPair = heff_take_reuse_n(v_x2_24566, 3ULL, 2);
    V v_m_24569 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24570 = heff_tr(heff_call(v_m_24569, 1, (V[]){v_s_24568}));
    switch (heff_tag_of(v_x2_24570)) {
    case TAG_MkPair: {
      V v_x_24571 = heff_field(v_x2_24570, 0);
      V v_s_24572 = heff_field(v_x2_24570, 1);
      heff_take_n(v_x2_24570, 3ULL, 2);
      V v_m_24573 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24574 = heff_tr(heff_call(v_m_24573, 1, (V[]){v_s_24572}));
      switch (heff_tag_of(v_x2_24574)) {
      case TAG_MkPair: {
        V v_x_24575 = heff_field(v_x2_24574, 0);
        V v_s_24576 = heff_field(v_x2_24574, 1);
        heff_take_n(v_x2_24574, 3ULL, 2);
        V v_t_24577 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str129), heff_strAppend(v_x_24575, ((V)&g_heff_2ecompile_2eemitc_2etestC_str130)));
        V v_t_24578 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str131), heff_strAppend(v_x_24571, v_t_24577));
        V v_t_24579 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str132), heff_strAppend(v_x_24567, v_t_24578));
        return heff_tag_at_n(v_ru_24x2_24566_24MkPair, TAG_MkPair, 2, (V[]){v_t_24579, v_s_24576});
      }
      default: return heff_nomatch(v_x2_24574);
      }
    }
    default: return heff_nomatch(v_x2_24570);
    }
  }
  default: return heff_nomatch(v_x2_24566);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args) {
  V v_s_24585 = args[0];
  V v_m_24584 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24586 = heff_tr(heff_call(v_m_24584, 1, (V[]){v_s_24585}));
  switch (heff_tag_of(v_x2_24586)) {
  case TAG_MkPair: {
    V v_x_24587 = heff_field(v_x2_24586, 0);
    V v_s_24588 = heff_field(v_x2_24586, 1);
    V v_ru_24x2_24586_24MkPair = heff_take_reuse_n(v_x2_24586, 3ULL, 2);
    V v_m_24589 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24590 = heff_tr(heff_call(v_m_24589, 1, (V[]){v_s_24588}));
    switch (heff_tag_of(v_x2_24590)) {
    case TAG_MkPair: {
      V v_x_24591 = heff_field(v_x2_24590, 0);
      V v_s_24592 = heff_field(v_x2_24590, 1);
      heff_take_n(v_x2_24590, 3ULL, 2);
      V v_m_24593 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24594 = heff_tr(heff_call(v_m_24593, 1, (V[]){v_s_24592}));
      switch (heff_tag_of(v_x2_24594)) {
      case TAG_MkPair: {
        V v_x_24595 = heff_field(v_x2_24594, 0);
        V v_s_24596 = heff_field(v_x2_24594, 1);
        heff_take_n(v_x2_24594, 3ULL, 2);
        V v_t_24597 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str133), heff_strAppend(v_x_24595, ((V)&g_heff_2ecompile_2eemitc_2etestC_str134)));
        V v_t_24598 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str135), heff_strAppend(v_x_24591, v_t_24597));
        V v_t_24599 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str136), heff_strAppend(v_x_24587, v_t_24598));
        return heff_tag_at_n(v_ru_24x2_24586_24MkPair, TAG_MkPair, 2, (V[]){v_t_24599, v_s_24596});
      }
      default: return heff_nomatch(v_x2_24594);
      }
    }
    default: return heff_nomatch(v_x2_24590);
    }
  }
  default: return heff_nomatch(v_x2_24586);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args) {
  V v_s_24602 = args[0];
  V v_m_24601 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24603 = heff_tr(heff_call(v_m_24601, 1, (V[]){v_s_24602}));
  switch (heff_tag_of(v_x2_24603)) {
  case TAG_MkPair: {
    V v_x_24604 = heff_field(v_x2_24603, 0);
    V v_s_24605 = heff_field(v_x2_24603, 1);
    V v_ru_24x2_24603_24MkPair = heff_take_reuse_n(v_x2_24603, 3ULL, 2);
    V v_m_24606 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24607 = heff_tr(heff_call(v_m_24606, 1, (V[]){v_s_24605}));
    switch (heff_tag_of(v_x2_24607)) {
    case TAG_MkPair: {
      V v_x_24608 = heff_field(v_x2_24607, 0);
      V v_s_24609 = heff_field(v_x2_24607, 1);
      heff_take_n(v_x2_24607, 3ULL, 2);
      V v_t_24610 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str137), heff_strAppend(v_x_24608, ((V)&g_heff_2ecompile_2eemitc_2etestC_str138)));
      V v_t_24611 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str139), heff_strAppend(v_x_24604, v_t_24610));
      return heff_tag_at_n(v_ru_24x2_24603_24MkPair, TAG_MkPair, 2, (V[]){v_t_24611, v_s_24609});
    }
    default: return heff_nomatch(v_x2_24607);
    }
  }
  default: return heff_nomatch(v_x2_24603);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args) {
  V v_s_24613 = args[0];
  V v_m_24612 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24614 = heff_tr(heff_call(v_m_24612, 1, (V[]){v_s_24613}));
  switch (heff_tag_of(v_x2_24614)) {
  case TAG_MkPair: {
    V v_x_24615 = heff_field(v_x2_24614, 0);
    V v_s_24616 = heff_field(v_x2_24614, 1);
    V v_ru_24x2_24614_24MkPair = heff_take_reuse_n(v_x2_24614, 3ULL, 2);
    V v_m_24617 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24618 = heff_tr(heff_call(v_m_24617, 1, (V[]){v_s_24616}));
    switch (heff_tag_of(v_x2_24618)) {
    case TAG_MkPair: {
      V v_x_24619 = heff_field(v_x2_24618, 0);
      V v_s_24620 = heff_field(v_x2_24618, 1);
      heff_take_n(v_x2_24618, 3ULL, 2);
      V v_m_24621 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24622 = heff_tr(heff_call(v_m_24621, 1, (V[]){v_s_24620}));
      switch (heff_tag_of(v_x2_24622)) {
      case TAG_MkPair: {
        V v_x_24623 = heff_field(v_x2_24622, 0);
        V v_s_24624 = heff_field(v_x2_24622, 1);
        heff_take_n(v_x2_24622, 3ULL, 2);
        V v_t_24625 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str140), heff_strAppend(v_x_24623, ((V)&g_heff_2ecompile_2eemitc_2etestC_str141)));
        V v_t_24626 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str142), heff_strAppend(v_x_24619, v_t_24625));
        V v_t_24627 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str143), heff_strAppend(v_x_24615, v_t_24626));
        return heff_tag_at_n(v_ru_24x2_24614_24MkPair, TAG_MkPair, 2, (V[]){v_t_24627, v_s_24624});
      }
      default: return heff_nomatch(v_x2_24622);
      }
    }
    default: return heff_nomatch(v_x2_24618);
    }
  }
  default: return heff_nomatch(v_x2_24614);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args) {
  V v_s_24631 = args[0];
  V v_m_24630 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24632 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_s_24631}));
  switch (heff_tag_of(v_x2_24632)) {
  case TAG_MkPair: {
    V v_x_24633 = heff_field(v_x2_24632, 0);
    V v_s_24634 = heff_field(v_x2_24632, 1);
    V v_ru_24x2_24632_24MkPair = heff_take_reuse_n(v_x2_24632, 3ULL, 2);
    V v_m_24635 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24636 = heff_tr(heff_call(v_m_24635, 1, (V[]){v_s_24634}));
    switch (heff_tag_of(v_x2_24636)) {
    case TAG_MkPair: {
      V v_x_24637 = heff_field(v_x2_24636, 0);
      V v_s_24638 = heff_field(v_x2_24636, 1);
      heff_take_n(v_x2_24636, 3ULL, 2);
      V v_m_24639 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24640 = heff_tr(heff_call(v_m_24639, 1, (V[]){v_s_24638}));
      switch (heff_tag_of(v_x2_24640)) {
      case TAG_MkPair: {
        V v_x_24641 = heff_field(v_x2_24640, 0);
        V v_s_24642 = heff_field(v_x2_24640, 1);
        heff_take_n(v_x2_24640, 3ULL, 2);
        V v_t_24643 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str144), heff_strAppend(v_x_24641, ((V)&g_heff_2ecompile_2eemitc_2etestC_str145)));
        V v_t_24644 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str146), heff_strAppend(v_x_24637, v_t_24643));
        V v_t_24645 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str147), heff_strAppend(v_x_24633, v_t_24644));
        return heff_tag_at_n(v_ru_24x2_24632_24MkPair, TAG_MkPair, 2, (V[]){v_t_24645, v_s_24642});
      }
      default: return heff_nomatch(v_x2_24640);
      }
    }
    default: return heff_nomatch(v_x2_24636);
    }
  }
  default: return heff_nomatch(v_x2_24632);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args) {
  V v_s_24649 = args[0];
  V v_m_24648 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24650 = heff_tr(heff_call(v_m_24648, 1, (V[]){v_s_24649}));
  switch (heff_tag_of(v_x2_24650)) {
  case TAG_MkPair: {
    V v_x_24651 = heff_field(v_x2_24650, 0);
    V v_s_24652 = heff_field(v_x2_24650, 1);
    V v_ru_24x2_24650_24MkPair = heff_take_reuse_n(v_x2_24650, 3ULL, 2);
    V v_m_24653 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24654 = heff_tr(heff_call(v_m_24653, 1, (V[]){v_s_24652}));
    switch (heff_tag_of(v_x2_24654)) {
    case TAG_MkPair: {
      V v_x_24655 = heff_field(v_x2_24654, 0);
      V v_s_24656 = heff_field(v_x2_24654, 1);
      heff_take_n(v_x2_24654, 3ULL, 2);
      V v_m_24657 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24658 = heff_tr(heff_call(v_m_24657, 1, (V[]){v_s_24656}));
      switch (heff_tag_of(v_x2_24658)) {
      case TAG_MkPair: {
        V v_x_24659 = heff_field(v_x2_24658, 0);
        V v_s_24660 = heff_field(v_x2_24658, 1);
        heff_take_n(v_x2_24658, 3ULL, 2);
        V v_t_24661 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str148), heff_strAppend(v_x_24659, ((V)&g_heff_2ecompile_2eemitc_2etestC_str149)));
        V v_t_24662 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str150), heff_strAppend(v_x_24655, v_t_24661));
        V v_t_24663 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str151), heff_strAppend(v_x_24651, v_t_24662));
        return heff_tag_at_n(v_ru_24x2_24650_24MkPair, TAG_MkPair, 2, (V[]){v_t_24663, v_s_24660});
      }
      default: return heff_nomatch(v_x2_24658);
      }
    }
    default: return heff_nomatch(v_x2_24654);
    }
  }
  default: return heff_nomatch(v_x2_24650);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args) {
  V v_s_24666 = args[0];
  V v_m_24665 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24667 = heff_tr(heff_call(v_m_24665, 1, (V[]){v_s_24666}));
  switch (heff_tag_of(v_x2_24667)) {
  case TAG_MkPair: {
    V v_x_24668 = heff_field(v_x2_24667, 0);
    V v_s_24669 = heff_field(v_x2_24667, 1);
    V v_ru_24x2_24667_24MkPair = heff_take_reuse_n(v_x2_24667, 3ULL, 2);
    V v_m_24670 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24671 = heff_tr(heff_call(v_m_24670, 1, (V[]){v_s_24669}));
    switch (heff_tag_of(v_x2_24671)) {
    case TAG_MkPair: {
      V v_x_24672 = heff_field(v_x2_24671, 0);
      V v_s_24673 = heff_field(v_x2_24671, 1);
      heff_take_n(v_x2_24671, 3ULL, 2);
      V v_m_24674 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24675 = heff_tr(heff_call(v_m_24674, 1, (V[]){v_s_24673}));
      switch (heff_tag_of(v_x2_24675)) {
      case TAG_MkPair: {
        V v_x_24676 = heff_field(v_x2_24675, 0);
        V v_s_24677 = heff_field(v_x2_24675, 1);
        heff_take_n(v_x2_24675, 3ULL, 2);
        V v_t_24678 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str152), heff_strAppend(v_x_24676, ((V)&g_heff_2ecompile_2eemitc_2etestC_str153)));
        V v_t_24679 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str154), heff_strAppend(v_x_24672, v_t_24678));
        V v_t_24680 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str155), heff_strAppend(v_x_24668, v_t_24679));
        return heff_tag_at_n(v_ru_24x2_24667_24MkPair, TAG_MkPair, 2, (V[]){v_t_24680, v_s_24677});
      }
      default: return heff_nomatch(v_x2_24675);
      }
    }
    default: return heff_nomatch(v_x2_24671);
    }
  }
  default: return heff_nomatch(v_x2_24667);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args) {
  V v_s_24683 = args[0];
  V v_m_24682 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24684 = heff_tr(heff_call(v_m_24682, 1, (V[]){v_s_24683}));
  switch (heff_tag_of(v_x2_24684)) {
  case TAG_MkPair: {
    V v_x_24685 = heff_field(v_x2_24684, 0);
    V v_s_24686 = heff_field(v_x2_24684, 1);
    V v_ru_24x2_24684_24MkPair = heff_take_reuse_n(v_x2_24684, 3ULL, 2);
    V v_m_24687 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24688 = heff_tr(heff_call(v_m_24687, 1, (V[]){v_s_24686}));
    switch (heff_tag_of(v_x2_24688)) {
    case TAG_MkPair: {
      V v_x_24689 = heff_field(v_x2_24688, 0);
      V v_s_24690 = heff_field(v_x2_24688, 1);
      heff_take_n(v_x2_24688, 3ULL, 2);
      V v_m_24691 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24692 = heff_tr(heff_call(v_m_24691, 1, (V[]){v_s_24690}));
      switch (heff_tag_of(v_x2_24692)) {
      case TAG_MkPair: {
        V v_x_24693 = heff_field(v_x2_24692, 0);
        V v_s_24694 = heff_field(v_x2_24692, 1);
        heff_take_n(v_x2_24692, 3ULL, 2);
        V v_t_24695 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str156), heff_strAppend(v_x_24693, ((V)&g_heff_2ecompile_2eemitc_2etestC_str157)));
        V v_t_24696 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str158), heff_strAppend(v_x_24689, v_t_24695));
        V v_t_24697 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str159), heff_strAppend(v_x_24685, v_t_24696));
        return heff_tag_at_n(v_ru_24x2_24684_24MkPair, TAG_MkPair, 2, (V[]){v_t_24697, v_s_24694});
      }
      default: return heff_nomatch(v_x2_24692);
      }
    }
    default: return heff_nomatch(v_x2_24688);
    }
  }
  default: return heff_nomatch(v_x2_24684);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args) {
  V v_s_24702 = args[0];
  V v_m_24701 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24703 = heff_tr(heff_call(v_m_24701, 1, (V[]){v_s_24702}));
  switch (heff_tag_of(v_x2_24703)) {
  case TAG_MkPair: {
    V v_x_24704 = heff_field(v_x2_24703, 0);
    V v_s_24705 = heff_field(v_x2_24703, 1);
    V v_ru_24x2_24703_24MkPair = heff_take_reuse_n(v_x2_24703, 3ULL, 2);
    V v_m_24706 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24707 = heff_tr(heff_call(v_m_24706, 1, (V[]){v_s_24705}));
    switch (heff_tag_of(v_x2_24707)) {
    case TAG_MkPair: {
      V v_x_24708 = heff_field(v_x2_24707, 0);
      V v_s_24709 = heff_field(v_x2_24707, 1);
      heff_take_n(v_x2_24707, 3ULL, 2);
      V v_m_24710 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24711 = heff_tr(heff_call(v_m_24710, 1, (V[]){v_s_24709}));
      switch (heff_tag_of(v_x2_24711)) {
      case TAG_MkPair: {
        V v_x_24712 = heff_field(v_x2_24711, 0);
        V v_s_24713 = heff_field(v_x2_24711, 1);
        heff_take_n(v_x2_24711, 3ULL, 2);
        V v_t_24714 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str160), heff_strAppend(v_x_24712, ((V)&g_heff_2ecompile_2eemitc_2etestC_str161)));
        V v_t_24715 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str162), heff_strAppend(v_x_24708, v_t_24714));
        V v_t_24716 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str163), heff_strAppend(v_x_24704, v_t_24715));
        return heff_tag_at_n(v_ru_24x2_24703_24MkPair, TAG_MkPair, 2, (V[]){v_t_24716, v_s_24713});
      }
      default: return heff_nomatch(v_x2_24711);
      }
    }
    default: return heff_nomatch(v_x2_24707);
    }
  }
  default: return heff_nomatch(v_x2_24703);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args) {
  V v_s_24722 = args[0];
  V v_m_24721 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24723 = heff_tr(heff_call(v_m_24721, 1, (V[]){v_s_24722}));
  switch (heff_tag_of(v_x2_24723)) {
  case TAG_MkPair: {
    V v_x_24724 = heff_field(v_x2_24723, 0);
    V v_s_24725 = heff_field(v_x2_24723, 1);
    V v_ru_24x2_24723_24MkPair = heff_take_reuse_n(v_x2_24723, 3ULL, 2);
    V v_m_24726 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24727 = heff_tr(heff_call(v_m_24726, 1, (V[]){v_s_24725}));
    switch (heff_tag_of(v_x2_24727)) {
    case TAG_MkPair: {
      V v_x_24728 = heff_field(v_x2_24727, 0);
      V v_s_24729 = heff_field(v_x2_24727, 1);
      heff_take_n(v_x2_24727, 3ULL, 2);
      V v_m_24730 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24731 = heff_tr(heff_call(v_m_24730, 1, (V[]){v_s_24729}));
      switch (heff_tag_of(v_x2_24731)) {
      case TAG_MkPair: {
        V v_x_24732 = heff_field(v_x2_24731, 0);
        V v_s_24733 = heff_field(v_x2_24731, 1);
        heff_take_n(v_x2_24731, 3ULL, 2);
        V v_t_24734 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str164), heff_strAppend(v_x_24732, ((V)&g_heff_2ecompile_2eemitc_2etestC_str165)));
        V v_t_24735 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str166), heff_strAppend(v_x_24728, v_t_24734));
        V v_t_24736 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str167), heff_strAppend(v_x_24724, v_t_24735));
        return heff_tag_at_n(v_ru_24x2_24723_24MkPair, TAG_MkPair, 2, (V[]){v_t_24736, v_s_24733});
      }
      default: return heff_nomatch(v_x2_24731);
      }
    }
    default: return heff_nomatch(v_x2_24727);
    }
  }
  default: return heff_nomatch(v_x2_24723);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args) {
  V v_s_24741 = args[0];
  V v_m_24740 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24742 = heff_tr(heff_call(v_m_24740, 1, (V[]){v_s_24741}));
  switch (heff_tag_of(v_x2_24742)) {
  case TAG_MkPair: {
    V v_x_24743 = heff_field(v_x2_24742, 0);
    V v_s_24744 = heff_field(v_x2_24742, 1);
    V v_ru_24x2_24742_24MkPair = heff_take_reuse_n(v_x2_24742, 3ULL, 2);
    V v_m_24745 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24746 = heff_tr(heff_call(v_m_24745, 1, (V[]){v_s_24744}));
    switch (heff_tag_of(v_x2_24746)) {
    case TAG_MkPair: {
      V v_x_24747 = heff_field(v_x2_24746, 0);
      V v_s_24748 = heff_field(v_x2_24746, 1);
      heff_take_n(v_x2_24746, 3ULL, 2);
      V v_t_24749 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str168), heff_strAppend(v_x_24747, ((V)&g_heff_2ecompile_2eemitc_2etestC_str169)));
      V v_t_24750 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str170), heff_strAppend(v_x_24743, v_t_24749));
      return heff_tag_at_n(v_ru_24x2_24742_24MkPair, TAG_MkPair, 2, (V[]){v_t_24750, v_s_24748});
    }
    default: return heff_nomatch(v_x2_24746);
    }
  }
  default: return heff_nomatch(v_x2_24742);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args) {
  V v_s_24752 = args[0];
  V v_m_24751 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24753 = heff_tr(heff_call(v_m_24751, 1, (V[]){v_s_24752}));
  switch (heff_tag_of(v_x2_24753)) {
  case TAG_MkPair: {
    V v_x_24754 = heff_field(v_x2_24753, 0);
    V v_s_24755 = heff_field(v_x2_24753, 1);
    V v_ru_24x2_24753_24MkPair = heff_take_reuse_n(v_x2_24753, 3ULL, 2);
    V v_m_24756 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24757 = heff_tr(heff_call(v_m_24756, 1, (V[]){v_s_24755}));
    switch (heff_tag_of(v_x2_24757)) {
    case TAG_MkPair: {
      V v_x_24758 = heff_field(v_x2_24757, 0);
      V v_s_24759 = heff_field(v_x2_24757, 1);
      heff_take_n(v_x2_24757, 3ULL, 2);
      V v_m_24760 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24761 = heff_tr(heff_call(v_m_24760, 1, (V[]){v_s_24759}));
      switch (heff_tag_of(v_x2_24761)) {
      case TAG_MkPair: {
        V v_x_24762 = heff_field(v_x2_24761, 0);
        V v_s_24763 = heff_field(v_x2_24761, 1);
        heff_take_n(v_x2_24761, 3ULL, 2);
        V v_t_24764 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str171), heff_strAppend(v_x_24762, ((V)&g_heff_2ecompile_2eemitc_2etestC_str172)));
        V v_t_24765 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str173), heff_strAppend(v_x_24758, v_t_24764));
        V v_t_24766 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str174), heff_strAppend(v_x_24754, v_t_24765));
        return heff_tag_at_n(v_ru_24x2_24753_24MkPair, TAG_MkPair, 2, (V[]){v_t_24766, v_s_24763});
      }
      default: return heff_nomatch(v_x2_24761);
      }
    }
    default: return heff_nomatch(v_x2_24757);
    }
  }
  default: return heff_nomatch(v_x2_24753);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args) {
  V v_s_24770 = args[0];
  V v_m_24769 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24771 = heff_tr(heff_call(v_m_24769, 1, (V[]){v_s_24770}));
  switch (heff_tag_of(v_x2_24771)) {
  case TAG_MkPair: {
    V v_x_24772 = heff_field(v_x2_24771, 0);
    V v_s_24773 = heff_field(v_x2_24771, 1);
    V v_ru_24x2_24771_24MkPair = heff_take_reuse_n(v_x2_24771, 3ULL, 2);
    V v_m_24774 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24775 = heff_tr(heff_call(v_m_24774, 1, (V[]){v_s_24773}));
    switch (heff_tag_of(v_x2_24775)) {
    case TAG_MkPair: {
      V v_x_24776 = heff_field(v_x2_24775, 0);
      V v_s_24777 = heff_field(v_x2_24775, 1);
      heff_take_n(v_x2_24775, 3ULL, 2);
      V v_m_24778 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24779 = heff_tr(heff_call(v_m_24778, 1, (V[]){v_s_24777}));
      switch (heff_tag_of(v_x2_24779)) {
      case TAG_MkPair: {
        V v_x_24780 = heff_field(v_x2_24779, 0);
        V v_s_24781 = heff_field(v_x2_24779, 1);
        heff_take_n(v_x2_24779, 3ULL, 2);
        V v_t_24782 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str175), heff_strAppend(v_x_24780, ((V)&g_heff_2ecompile_2eemitc_2etestC_str176)));
        V v_t_24783 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str177), heff_strAppend(v_x_24776, v_t_24782));
        V v_t_24784 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str178), heff_strAppend(v_x_24772, v_t_24783));
        return heff_tag_at_n(v_ru_24x2_24771_24MkPair, TAG_MkPair, 2, (V[]){v_t_24784, v_s_24781});
      }
      default: return heff_nomatch(v_x2_24779);
      }
    }
    default: return heff_nomatch(v_x2_24775);
    }
  }
  default: return heff_nomatch(v_x2_24771);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args) {
  V v_s_24788 = args[0];
  V v_m_24787 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24789 = heff_tr(heff_call(v_m_24787, 1, (V[]){v_s_24788}));
  switch (heff_tag_of(v_x2_24789)) {
  case TAG_MkPair: {
    V v_x_24790 = heff_field(v_x2_24789, 0);
    V v_s_24791 = heff_field(v_x2_24789, 1);
    V v_ru_24x2_24789_24MkPair = heff_take_reuse_n(v_x2_24789, 3ULL, 2);
    V v_m_24792 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24793 = heff_tr(heff_call(v_m_24792, 1, (V[]){v_s_24791}));
    switch (heff_tag_of(v_x2_24793)) {
    case TAG_MkPair: {
      V v_x_24794 = heff_field(v_x2_24793, 0);
      V v_s_24795 = heff_field(v_x2_24793, 1);
      heff_take_n(v_x2_24793, 3ULL, 2);
      V v_m_24796 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24797 = heff_tr(heff_call(v_m_24796, 1, (V[]){v_s_24795}));
      switch (heff_tag_of(v_x2_24797)) {
      case TAG_MkPair: {
        V v_x_24798 = heff_field(v_x2_24797, 0);
        V v_s_24799 = heff_field(v_x2_24797, 1);
        heff_take_n(v_x2_24797, 3ULL, 2);
        V v_t_24800 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str179), heff_strAppend(v_x_24798, ((V)&g_heff_2ecompile_2eemitc_2etestC_str180)));
        V v_t_24801 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str181), heff_strAppend(v_x_24794, v_t_24800));
        V v_t_24802 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str182), heff_strAppend(v_x_24790, v_t_24801));
        return heff_tag_at_n(v_ru_24x2_24789_24MkPair, TAG_MkPair, 2, (V[]){v_t_24802, v_s_24799});
      }
      default: return heff_nomatch(v_x2_24797);
      }
    }
    default: return heff_nomatch(v_x2_24793);
    }
  }
  default: return heff_nomatch(v_x2_24789);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args) {
  V v_s_24805 = args[0];
  V v_m_24804 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24806 = heff_tr(heff_call(v_m_24804, 1, (V[]){v_s_24805}));
  switch (heff_tag_of(v_x2_24806)) {
  case TAG_MkPair: {
    V v_x_24807 = heff_field(v_x2_24806, 0);
    V v_s_24808 = heff_field(v_x2_24806, 1);
    V v_ru_24x2_24806_24MkPair = heff_take_reuse_n(v_x2_24806, 3ULL, 2);
    V v_m_24809 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24810 = heff_tr(heff_call(v_m_24809, 1, (V[]){v_s_24808}));
    switch (heff_tag_of(v_x2_24810)) {
    case TAG_MkPair: {
      V v_x_24811 = heff_field(v_x2_24810, 0);
      V v_s_24812 = heff_field(v_x2_24810, 1);
      heff_take_n(v_x2_24810, 3ULL, 2);
      V v_m_24813 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24814 = heff_tr(heff_call(v_m_24813, 1, (V[]){v_s_24812}));
      switch (heff_tag_of(v_x2_24814)) {
      case TAG_MkPair: {
        V v_x_24815 = heff_field(v_x2_24814, 0);
        V v_s_24816 = heff_field(v_x2_24814, 1);
        heff_take_n(v_x2_24814, 3ULL, 2);
        V v_t_24817 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str183), heff_strAppend(v_x_24815, ((V)&g_heff_2ecompile_2eemitc_2etestC_str184)));
        V v_t_24818 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str185), heff_strAppend(v_x_24811, v_t_24817));
        V v_t_24819 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str186), heff_strAppend(v_x_24807, v_t_24818));
        return heff_tag_at_n(v_ru_24x2_24806_24MkPair, TAG_MkPair, 2, (V[]){v_t_24819, v_s_24816});
      }
      default: return heff_nomatch(v_x2_24814);
      }
    }
    default: return heff_nomatch(v_x2_24810);
    }
  }
  default: return heff_nomatch(v_x2_24806);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args) {
  V v_s_24822 = args[0];
  V v_m_24821 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24823 = heff_tr(heff_call(v_m_24821, 1, (V[]){v_s_24822}));
  switch (heff_tag_of(v_x2_24823)) {
  case TAG_MkPair: {
    V v_x_24824 = heff_field(v_x2_24823, 0);
    V v_s_24825 = heff_field(v_x2_24823, 1);
    V v_ru_24x2_24823_24MkPair = heff_take_reuse_n(v_x2_24823, 3ULL, 2);
    V v_m_24826 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24827 = heff_tr(heff_call(v_m_24826, 1, (V[]){v_s_24825}));
    switch (heff_tag_of(v_x2_24827)) {
    case TAG_MkPair: {
      V v_x_24828 = heff_field(v_x2_24827, 0);
      V v_s_24829 = heff_field(v_x2_24827, 1);
      heff_take_n(v_x2_24827, 3ULL, 2);
      V v_m_24830 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24831 = heff_tr(heff_call(v_m_24830, 1, (V[]){v_s_24829}));
      switch (heff_tag_of(v_x2_24831)) {
      case TAG_MkPair: {
        V v_x_24832 = heff_field(v_x2_24831, 0);
        V v_s_24833 = heff_field(v_x2_24831, 1);
        heff_take_n(v_x2_24831, 3ULL, 2);
        V v_t_24834 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str187), heff_strAppend(v_x_24832, ((V)&g_heff_2ecompile_2eemitc_2etestC_str188)));
        V v_t_24835 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str189), heff_strAppend(v_x_24828, v_t_24834));
        V v_t_24836 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str190), heff_strAppend(v_x_24824, v_t_24835));
        return heff_tag_at_n(v_ru_24x2_24823_24MkPair, TAG_MkPair, 2, (V[]){v_t_24836, v_s_24833});
      }
      default: return heff_nomatch(v_x2_24831);
      }
    }
    default: return heff_nomatch(v_x2_24827);
    }
  }
  default: return heff_nomatch(v_x2_24823);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args) {
  V v_s_24841 = args[0];
  V v_m_24840 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24842 = heff_tr(heff_call(v_m_24840, 1, (V[]){v_s_24841}));
  switch (heff_tag_of(v_x2_24842)) {
  case TAG_MkPair: {
    V v_x_24843 = heff_field(v_x2_24842, 0);
    V v_s_24844 = heff_field(v_x2_24842, 1);
    V v_ru_24x2_24842_24MkPair = heff_take_reuse_n(v_x2_24842, 3ULL, 2);
    V v_m_24845 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24846 = heff_tr(heff_call(v_m_24845, 1, (V[]){v_s_24844}));
    switch (heff_tag_of(v_x2_24846)) {
    case TAG_MkPair: {
      V v_x_24847 = heff_field(v_x2_24846, 0);
      V v_s_24848 = heff_field(v_x2_24846, 1);
      heff_take_n(v_x2_24846, 3ULL, 2);
      V v_m_24849 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24850 = heff_tr(heff_call(v_m_24849, 1, (V[]){v_s_24848}));
      switch (heff_tag_of(v_x2_24850)) {
      case TAG_MkPair: {
        V v_x_24851 = heff_field(v_x2_24850, 0);
        V v_s_24852 = heff_field(v_x2_24850, 1);
        heff_take_n(v_x2_24850, 3ULL, 2);
        V v_t_24853 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str191), heff_strAppend(v_x_24851, ((V)&g_heff_2ecompile_2eemitc_2etestC_str192)));
        V v_t_24854 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str193), heff_strAppend(v_x_24847, v_t_24853));
        V v_t_24855 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str194), heff_strAppend(v_x_24843, v_t_24854));
        return heff_tag_at_n(v_ru_24x2_24842_24MkPair, TAG_MkPair, 2, (V[]){v_t_24855, v_s_24852});
      }
      default: return heff_nomatch(v_x2_24850);
      }
    }
    default: return heff_nomatch(v_x2_24846);
    }
  }
  default: return heff_nomatch(v_x2_24842);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args) {
  V v_s_24861 = args[0];
  V v_m_24860 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24862 = heff_tr(heff_call(v_m_24860, 1, (V[]){v_s_24861}));
  switch (heff_tag_of(v_x2_24862)) {
  case TAG_MkPair: {
    V v_x_24863 = heff_field(v_x2_24862, 0);
    V v_s_24864 = heff_field(v_x2_24862, 1);
    V v_ru_24x2_24862_24MkPair = heff_take_reuse_n(v_x2_24862, 3ULL, 2);
    V v_m_24865 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24866 = heff_tr(heff_call(v_m_24865, 1, (V[]){v_s_24864}));
    switch (heff_tag_of(v_x2_24866)) {
    case TAG_MkPair: {
      V v_x_24867 = heff_field(v_x2_24866, 0);
      V v_s_24868 = heff_field(v_x2_24866, 1);
      heff_take_n(v_x2_24866, 3ULL, 2);
      V v_m_24869 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24870 = heff_tr(heff_call(v_m_24869, 1, (V[]){v_s_24868}));
      switch (heff_tag_of(v_x2_24870)) {
      case TAG_MkPair: {
        V v_x_24871 = heff_field(v_x2_24870, 0);
        V v_s_24872 = heff_field(v_x2_24870, 1);
        heff_take_n(v_x2_24870, 3ULL, 2);
        V v_t_24873 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str195), heff_strAppend(v_x_24871, ((V)&g_heff_2ecompile_2eemitc_2etestC_str196)));
        V v_t_24874 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str197), heff_strAppend(v_x_24867, v_t_24873));
        V v_t_24875 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str198), heff_strAppend(v_x_24863, v_t_24874));
        return heff_tag_at_n(v_ru_24x2_24862_24MkPair, TAG_MkPair, 2, (V[]){v_t_24875, v_s_24872});
      }
      default: return heff_nomatch(v_x2_24870);
      }
    }
    default: return heff_nomatch(v_x2_24866);
    }
  }
  default: return heff_nomatch(v_x2_24862);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args) {
  V v_s_24881 = args[0];
  V v_m_24880 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24882 = heff_tr(heff_call(v_m_24880, 1, (V[]){v_s_24881}));
  switch (heff_tag_of(v_x2_24882)) {
  case TAG_MkPair: {
    V v_x_24883 = heff_field(v_x2_24882, 0);
    V v_s_24884 = heff_field(v_x2_24882, 1);
    V v_ru_24x2_24882_24MkPair = heff_take_reuse_n(v_x2_24882, 3ULL, 2);
    V v_m_24885 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
    V v_x2_24886 = heff_tr(heff_call(v_m_24885, 1, (V[]){v_s_24884}));
    switch (heff_tag_of(v_x2_24886)) {
    case TAG_MkPair: {
      V v_x_24887 = heff_field(v_x2_24886, 0);
      V v_s_24888 = heff_field(v_x2_24886, 1);
      heff_take_n(v_x2_24886, 3ULL, 2);
      V v_t_24889 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str199), heff_strAppend(v_x_24887, ((V)&g_heff_2ecompile_2eemitc_2etestC_str200)));
      V v_t_24890 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str201), heff_strAppend(v_x_24883, v_t_24889));
      return heff_tag_at_n(v_ru_24x2_24882_24MkPair, TAG_MkPair, 2, (V[]){v_t_24890, v_s_24888});
    }
    default: return heff_nomatch(v_x2_24886);
    }
  }
  default: return heff_nomatch(v_x2_24882);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args) {
  V v_s_24892 = args[0];
  V v_m_24891 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24893 = heff_tr(heff_call(v_m_24891, 1, (V[]){v_s_24892}));
  switch (heff_tag_of(v_x2_24893)) {
  case TAG_MkPair: {
    V v_x_24894 = heff_field(v_x2_24893, 0);
    V v_s_24895 = heff_field(v_x2_24893, 1);
    V v_ru_24x2_24893_24MkPair = heff_take_reuse_n(v_x2_24893, 3ULL, 2);
    V v_m_24896 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24897 = heff_tr(heff_call(v_m_24896, 1, (V[]){v_s_24895}));
    switch (heff_tag_of(v_x2_24897)) {
    case TAG_MkPair: {
      V v_x_24898 = heff_field(v_x2_24897, 0);
      V v_s_24899 = heff_field(v_x2_24897, 1);
      heff_take_n(v_x2_24897, 3ULL, 2);
      V v_m_24900 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24901 = heff_tr(heff_call(v_m_24900, 1, (V[]){v_s_24899}));
      switch (heff_tag_of(v_x2_24901)) {
      case TAG_MkPair: {
        V v_x_24902 = heff_field(v_x2_24901, 0);
        V v_s_24903 = heff_field(v_x2_24901, 1);
        heff_take_n(v_x2_24901, 3ULL, 2);
        V v_t_24904 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str202), heff_strAppend(v_x_24902, ((V)&g_heff_2ecompile_2eemitc_2etestC_str203)));
        V v_t_24905 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str204), heff_strAppend(v_x_24898, v_t_24904));
        V v_t_24906 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str205), heff_strAppend(v_x_24894, v_t_24905));
        return heff_tag_at_n(v_ru_24x2_24893_24MkPair, TAG_MkPair, 2, (V[]){v_t_24906, v_s_24903});
      }
      default: return heff_nomatch(v_x2_24901);
      }
    }
    default: return heff_nomatch(v_x2_24897);
    }
  }
  default: return heff_nomatch(v_x2_24893);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args) {
  V v_s_24910 = args[0];
  V v_m_24909 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24911 = heff_tr(heff_call(v_m_24909, 1, (V[]){v_s_24910}));
  switch (heff_tag_of(v_x2_24911)) {
  case TAG_MkPair: {
    V v_x_24912 = heff_field(v_x2_24911, 0);
    V v_s_24913 = heff_field(v_x2_24911, 1);
    V v_ru_24x2_24911_24MkPair = heff_take_reuse_n(v_x2_24911, 3ULL, 2);
    V v_m_24914 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24915 = heff_tr(heff_call(v_m_24914, 1, (V[]){v_s_24913}));
    switch (heff_tag_of(v_x2_24915)) {
    case TAG_MkPair: {
      V v_x_24916 = heff_field(v_x2_24915, 0);
      V v_s_24917 = heff_field(v_x2_24915, 1);
      heff_take_n(v_x2_24915, 3ULL, 2);
      V v_m_24918 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24919 = heff_tr(heff_call(v_m_24918, 1, (V[]){v_s_24917}));
      switch (heff_tag_of(v_x2_24919)) {
      case TAG_MkPair: {
        V v_x_24920 = heff_field(v_x2_24919, 0);
        V v_s_24921 = heff_field(v_x2_24919, 1);
        heff_take_n(v_x2_24919, 3ULL, 2);
        V v_t_24922 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str206), heff_strAppend(v_x_24920, ((V)&g_heff_2ecompile_2eemitc_2etestC_str207)));
        V v_t_24923 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str208), heff_strAppend(v_x_24916, v_t_24922));
        V v_t_24924 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str209), heff_strAppend(v_x_24912, v_t_24923));
        return heff_tag_at_n(v_ru_24x2_24911_24MkPair, TAG_MkPair, 2, (V[]){v_t_24924, v_s_24921});
      }
      default: return heff_nomatch(v_x2_24919);
      }
    }
    default: return heff_nomatch(v_x2_24915);
    }
  }
  default: return heff_nomatch(v_x2_24911);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args) {
  V v_s_24928 = args[0];
  V v_m_24927 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24929 = heff_tr(heff_call(v_m_24927, 1, (V[]){v_s_24928}));
  switch (heff_tag_of(v_x2_24929)) {
  case TAG_MkPair: {
    V v_x_24930 = heff_field(v_x2_24929, 0);
    V v_s_24931 = heff_field(v_x2_24929, 1);
    V v_ru_24x2_24929_24MkPair = heff_take_reuse_n(v_x2_24929, 3ULL, 2);
    V v_m_24932 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24933 = heff_tr(heff_call(v_m_24932, 1, (V[]){v_s_24931}));
    switch (heff_tag_of(v_x2_24933)) {
    case TAG_MkPair: {
      V v_x_24934 = heff_field(v_x2_24933, 0);
      V v_s_24935 = heff_field(v_x2_24933, 1);
      heff_take_n(v_x2_24933, 3ULL, 2);
      V v_m_24936 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24937 = heff_tr(heff_call(v_m_24936, 1, (V[]){v_s_24935}));
      switch (heff_tag_of(v_x2_24937)) {
      case TAG_MkPair: {
        V v_x_24938 = heff_field(v_x2_24937, 0);
        V v_s_24939 = heff_field(v_x2_24937, 1);
        heff_take_n(v_x2_24937, 3ULL, 2);
        V v_t_24940 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str210), heff_strAppend(v_x_24938, ((V)&g_heff_2ecompile_2eemitc_2etestC_str211)));
        V v_t_24941 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str212), heff_strAppend(v_x_24934, v_t_24940));
        V v_t_24942 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str213), heff_strAppend(v_x_24930, v_t_24941));
        return heff_tag_at_n(v_ru_24x2_24929_24MkPair, TAG_MkPair, 2, (V[]){v_t_24942, v_s_24939});
      }
      default: return heff_nomatch(v_x2_24937);
      }
    }
    default: return heff_nomatch(v_x2_24933);
    }
  }
  default: return heff_nomatch(v_x2_24929);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args) {
  V v_s_24945 = args[0];
  V v_m_24944 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24946 = heff_tr(heff_call(v_m_24944, 1, (V[]){v_s_24945}));
  switch (heff_tag_of(v_x2_24946)) {
  case TAG_MkPair: {
    V v_x_24947 = heff_field(v_x2_24946, 0);
    V v_s_24948 = heff_field(v_x2_24946, 1);
    V v_ru_24x2_24946_24MkPair = heff_take_reuse_n(v_x2_24946, 3ULL, 2);
    V v_m_24949 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24950 = heff_tr(heff_call(v_m_24949, 1, (V[]){v_s_24948}));
    switch (heff_tag_of(v_x2_24950)) {
    case TAG_MkPair: {
      V v_x_24951 = heff_field(v_x2_24950, 0);
      V v_s_24952 = heff_field(v_x2_24950, 1);
      heff_take_n(v_x2_24950, 3ULL, 2);
      V v_m_24953 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24954 = heff_tr(heff_call(v_m_24953, 1, (V[]){v_s_24952}));
      switch (heff_tag_of(v_x2_24954)) {
      case TAG_MkPair: {
        V v_x_24955 = heff_field(v_x2_24954, 0);
        V v_s_24956 = heff_field(v_x2_24954, 1);
        heff_take_n(v_x2_24954, 3ULL, 2);
        V v_t_24957 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str214), heff_strAppend(v_x_24955, ((V)&g_heff_2ecompile_2eemitc_2etestC_str215)));
        V v_t_24958 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str216), heff_strAppend(v_x_24951, v_t_24957));
        V v_t_24959 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str217), heff_strAppend(v_x_24947, v_t_24958));
        return heff_tag_at_n(v_ru_24x2_24946_24MkPair, TAG_MkPair, 2, (V[]){v_t_24959, v_s_24956});
      }
      default: return heff_nomatch(v_x2_24954);
      }
    }
    default: return heff_nomatch(v_x2_24950);
    }
  }
  default: return heff_nomatch(v_x2_24946);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args) {
  V v_s_24962 = args[0];
  V v_m_24961 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24963 = heff_tr(heff_call(v_m_24961, 1, (V[]){v_s_24962}));
  switch (heff_tag_of(v_x2_24963)) {
  case TAG_MkPair: {
    V v_x_24964 = heff_field(v_x2_24963, 0);
    V v_s_24965 = heff_field(v_x2_24963, 1);
    V v_ru_24x2_24963_24MkPair = heff_take_reuse_n(v_x2_24963, 3ULL, 2);
    V v_m_24966 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24967 = heff_tr(heff_call(v_m_24966, 1, (V[]){v_s_24965}));
    switch (heff_tag_of(v_x2_24967)) {
    case TAG_MkPair: {
      V v_x_24968 = heff_field(v_x2_24967, 0);
      V v_s_24969 = heff_field(v_x2_24967, 1);
      heff_take_n(v_x2_24967, 3ULL, 2);
      V v_m_24970 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24971 = heff_tr(heff_call(v_m_24970, 1, (V[]){v_s_24969}));
      switch (heff_tag_of(v_x2_24971)) {
      case TAG_MkPair: {
        V v_x_24972 = heff_field(v_x2_24971, 0);
        V v_s_24973 = heff_field(v_x2_24971, 1);
        heff_take_n(v_x2_24971, 3ULL, 2);
        V v_t_24974 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str218), heff_strAppend(v_x_24972, ((V)&g_heff_2ecompile_2eemitc_2etestC_str219)));
        V v_t_24975 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str220), heff_strAppend(v_x_24968, v_t_24974));
        V v_t_24976 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str221), heff_strAppend(v_x_24964, v_t_24975));
        return heff_tag_at_n(v_ru_24x2_24963_24MkPair, TAG_MkPair, 2, (V[]){v_t_24976, v_s_24973});
      }
      default: return heff_nomatch(v_x2_24971);
      }
    }
    default: return heff_nomatch(v_x2_24967);
    }
  }
  default: return heff_nomatch(v_x2_24963);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args) {
  V v_s_24981 = args[0];
  V v_m_24980 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24982 = heff_tr(heff_call(v_m_24980, 1, (V[]){v_s_24981}));
  switch (heff_tag_of(v_x2_24982)) {
  case TAG_MkPair: {
    V v_x_24983 = heff_field(v_x2_24982, 0);
    V v_s_24984 = heff_field(v_x2_24982, 1);
    V v_ru_24x2_24982_24MkPair = heff_take_reuse_n(v_x2_24982, 3ULL, 2);
    V v_m_24985 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_24986 = heff_tr(heff_call(v_m_24985, 1, (V[]){v_s_24984}));
    switch (heff_tag_of(v_x2_24986)) {
    case TAG_MkPair: {
      V v_x_24987 = heff_field(v_x2_24986, 0);
      V v_s_24988 = heff_field(v_x2_24986, 1);
      heff_take_n(v_x2_24986, 3ULL, 2);
      V v_m_24989 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_24990 = heff_tr(heff_call(v_m_24989, 1, (V[]){v_s_24988}));
      switch (heff_tag_of(v_x2_24990)) {
      case TAG_MkPair: {
        V v_x_24991 = heff_field(v_x2_24990, 0);
        V v_s_24992 = heff_field(v_x2_24990, 1);
        heff_take_n(v_x2_24990, 3ULL, 2);
        V v_t_24993 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str222), heff_strAppend(v_x_24991, ((V)&g_heff_2ecompile_2eemitc_2etestC_str223)));
        V v_t_24994 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str224), heff_strAppend(v_x_24987, v_t_24993));
        V v_t_24995 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str225), heff_strAppend(v_x_24983, v_t_24994));
        return heff_tag_at_n(v_ru_24x2_24982_24MkPair, TAG_MkPair, 2, (V[]){v_t_24995, v_s_24992});
      }
      default: return heff_nomatch(v_x2_24990);
      }
    }
    default: return heff_nomatch(v_x2_24986);
    }
  }
  default: return heff_nomatch(v_x2_24982);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args) {
  V v_s_241001 = args[0];
  V v_m_241000 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2438 = heff_env(self)[2];
  V v_x23_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_241002 = heff_tr(heff_call(v_m_241000, 1, (V[]){v_s_241001}));
  switch (heff_tag_of(v_x2_241002)) {
  case TAG_MkPair: {
    V v_x_241003 = heff_field(v_x2_241002, 0);
    V v_s_241004 = heff_field(v_x2_241002, 1);
    V v_ru_24x2_241002_24MkPair = heff_take_reuse_n(v_x2_241002, 3ULL, 2);
    V v_m_241005 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2438));
    V v_x2_241006 = heff_tr(heff_call(v_m_241005, 1, (V[]){v_s_241004}));
    switch (heff_tag_of(v_x2_241006)) {
    case TAG_MkPair: {
      V v_x_241007 = heff_field(v_x2_241006, 0);
      V v_s_241008 = heff_field(v_x2_241006, 1);
      heff_take_n(v_x2_241006, 3ULL, 2);
      V v_m_241009 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2439));
      V v_x2_241010 = heff_tr(heff_call(v_m_241009, 1, (V[]){v_s_241008}));
      switch (heff_tag_of(v_x2_241010)) {
      case TAG_MkPair: {
        V v_x_241011 = heff_field(v_x2_241010, 0);
        V v_s_241012 = heff_field(v_x2_241010, 1);
        heff_take_n(v_x2_241010, 3ULL, 2);
        V v_t_241013 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str226), heff_strAppend(v_x_241011, ((V)&g_heff_2ecompile_2eemitc_2etestC_str227)));
        V v_t_241014 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str228), heff_strAppend(v_x_241007, v_t_241013));
        V v_t_241015 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str229), heff_strAppend(v_x_241003, v_t_241014));
        return heff_tag_at_n(v_ru_24x2_241002_24MkPair, TAG_MkPair, 2, (V[]){v_t_241015, v_s_241012});
      }
      default: return heff_nomatch(v_x2_241010);
      }
    }
    default: return heff_nomatch(v_x2_241006);
    }
  }
  default: return heff_nomatch(v_x2_241002);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args) {
  V v_s_241021 = args[0];
  V v_m_241020 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_241018 = heff_env(self)[2];
  V v_x_241016 = heff_env(self)[3];
  V v_drops_241019 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_241022 = heff_tr(heff_call(v_m_241020, 1, (V[]){v_s_241021}));
  switch (heff_tag_of(v_x2_241022)) {
  case TAG_MkPair: {
    V v_x_241023 = heff_field(v_x2_241022, 0);
    V v_s_241024 = heff_field(v_x2_241022, 1);
    V v_ru_24x2_241022_24MkPair = heff_take_reuse_n(v_x2_241022, 3ULL, 2);
    V v_m_241025 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_241018));
    V v_x2_241026 = heff_tr(heff_call(v_m_241025, 1, (V[]){v_s_241024}));
    switch (heff_tag_of(v_x2_241026)) {
    case TAG_MkPair: {
      V v_x_241027 = heff_field(v_x2_241026, 0);
      V v_s_241028 = heff_field(v_x2_241026, 1);
      heff_take_n(v_x2_241026, 3ULL, 2);
      V v_t_241029 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_241016)}));
      V v_t_241030 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241016, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str230)));
      V v_x2_241031 = (g_list_2emap_24s456133444x1904936646(((V)&g_heff_2ecompile_2eemitc_2etestC_str231), ((V)&g_heff_2ecompile_2eemitc_2etestC_str232), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str233), ((V)&g_heff_2ecompile_2eemitc_2etestC_str234), ((V)&g_heff_2ecompile_2eemitc_2etestC_str235), v_drops_241019));
      V v_t_241034;
      switch (heff_tag_of(v_x2_241031)) {
      case TAG_Nil: {
        v_t_241034 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str236);
        break;
      }
      case TAG_Cons: {
        V v_x_241032 = heff_field(v_x2_241031, 0);
        V v_xs_241033 = heff_field(v_x2_241031, 1);
        heff_take_n(v_x2_241031, 3ULL, 2);
        v_t_241034 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str237); V a_1 = v_x_241032; V a_2 = v_xs_241033; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_241033); r_; });
        break;
      }
      default: heff_nomatch(v_x2_241031);
      }
      V v_t_241035 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str238), heff_strAppend(v_t_241034, ((V)&g_heff_2ecompile_2eemitc_2etestC_str239)));
      V v_t_241036 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str240), heff_strAppend(v_x_241027, v_t_241035));
      V v_t_241037 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str241), heff_strAppend(v_x_241023, v_t_241036));
      V v_t_241038 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str242), v_t_241030), v_t_241037);
      V v_t_241039 = heff_strAppend(v_t_241029, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str243), v_t_241038));
      V v_x_241040 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str244), v_t_241039);
      return heff_tag_at_n(v_ru_24x2_241022_24MkPair, TAG_MkPair, 2, (V[]){v_x_241040, v_s_241028});
    }
    default: return heff_nomatch(v_x2_241026);
    }
  }
  default: return heff_nomatch(v_x2_241022);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str1, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str2, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str3, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str4, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str5, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str6, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str12, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2eflatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eflatLine_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eflatLine(V v_k_240, V v_sv_241, V v_sure_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_v_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str0)));
      V v_t_2410 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_i_246), v_sure_242));
      V v_t_2412;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        switch (heff_tag_of(v_r_247)) {
        case TAG_RepV: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str1);
          break;
        }
        case TAG_RepFix: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str2);
          break;
        }
        case TAG_RepF64: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str3);
          break;
        }
        default: heff_nomatch(v_r_247);
        }
      } else {
        heff_drop(v_t_2410);
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str4);
      }
      V v_t_2414;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str5);
        break;
      }
      case TAG_RepFix: {
        V v_w_2413 = heff_field(v_r_247, 0);
        v_t_2414 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_2413));
        break;
      }
      case TAG_RepF64: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str6);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2415 = heff_strAppend(heff_intShow(heff_dup(v_i_246)), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str7));
      V v_t_2416 = heff_strAppend(v_sv_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str8), v_t_2415));
      V v_t_2417 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str9), v_t_2416));
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str10), v_t_249), heff_strAppend(v_t_2412, v_t_2417));
      V v_t_2419 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str11), v_t_2418));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str12), v_t_2419);
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eflatLine(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_sure_246 = heff_field(v_x3_242, 3);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_leaves_2410 = heff_field(v_x3_242, 7);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 10, (V[]){v_m_2411, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_247), heff_dup(v_fields_244), v_k_240, heff_dup(v_sure_246), heff_dup(v_flats_245), heff_dup(v_take_248), heff_dup(v_leaves_2410)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_247 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_sure_246 = heff_env(self)[6];
  V v_flats_245 = heff_env(self)[7];
  V v_take_248 = heff_env(self)[8];
  V v_leaves_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2earmF_str0)));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str1), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2earmF_str2));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2417), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2efieldLine_clo), 2, (V[]){heff_dup(v_sv_241), v_plain_247}));
    V v_t_2420 = (g_list_2emap(v_t_2419, v_fields_244));
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eflatLine_clo), 3, (V[]){v_k_240, heff_dup(v_sv_241), v_sure_246}));
    V v_t_2422 = (g_list_2emap(v_t_2421, v_flats_245));
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
    V v_t_2424 = ({ V a_0 = v_sv_241; V a_1 = v_take_248; V r_ = (g_heff_2ecompile_2eemitc_2etakeLines(a_0, a_1)); heff_drop(v_take_248); r_; });
    V v_t_2425 = (g_list_2emap_24f1217399696x462307458(((V)&g_heff_2ecompile_2eemitc_2earmF_str4), v_t_2424, v_x_2414));
    V v_t_2426;
    if ((heff_dup(v_leaves_2410) == NTAG(TAG_True))) {
      heff_drop(v_leaves_2410);
      v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str5), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_2410);
      v_t_2426 = NTAG(TAG_Nil);
    }
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str6), NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2427));
    V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2428));
    V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2429));
    V v_x_2431 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2430));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2431, v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
  return heff_strAppend(v_t_245, v_t_247);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 10, " return r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 2, "  ");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_bi_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_x2_247 = (g_list_2emap_24f1293205645x619162872(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7), v_t_246), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8), v_t_2412);
  } else {
    heff_drop(v_t_245);
    V v_x2_2413 = (g_list_2emap_24s353858844x950951807(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14)));
    V v_t_2418 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2422 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2418));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_x2_2426 = (g_list_2emap_24s1382928954x1260344933(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), v_bi_241));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26), heff_strAppend(v_t_2425, v_t_2430));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27), v_t_2417), v_t_2431);
    V v_t_2433 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28), v_t_2432));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29), v_t_2433);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = ({ V a_0 = heff_dup(v_i_2419); V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), heff_intShow(v_i_2419));
  } else {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_strAppend(heff_intShow(v_i_2419), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17), v_t_2421);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 22, "static const HeffName ");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s588563787x236154271(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7)));
  V v_t_2411 = heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8), v_t_2410));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9), v_t_2411), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str3, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str4, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str5, 14, "static V gget_");
Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 0, 7);
    V v_x3_245 = ({ V a_0 = heff_dup(v_key_243); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str0)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str1)));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str3));
      V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str4), v_t_249));
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str5), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalGet(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 42, "static const Global heff_globals_arr[] = {");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), heff_rfield(v_ce_242, 0)));
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), heff_rfield(v_ce_242, 1)));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2419));
  V v_t_2432;
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2429);
  }
  V v_x1_2437 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2437, 0ULL, 2);
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9);
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_t_2441 = heff_strAppend(v_t_2432, heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10)));
  V v_t_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f316845240x1272469554(a_0, a_1, a_2, a_3)); heff_drop(v_exports_240); r_; });
  V v_t_2447 = heff_strAppend(heff_intShow(v_t_2446), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11));
  V v_t_2448 = (g_map_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2449 = heff_strAppend(heff_intShow(v_t_2448), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12));
  V v_t_2450 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2451 = heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13));
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14), NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15), v_t_2451), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16), v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17), v_t_2449), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18), v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19), v_t_2447), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), v_t_2441), v_t_2456});
  V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2457));
  V v_t_2459 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2458));
  V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2459));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2460));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_t_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = v_t_247; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eglobalGet(v_ce_242, v_x_2410));
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_249));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  return ({ V a_0 = v_t_2418; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2420 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_p_2420, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2426;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_p_2420, 1);
    heff_take_n(v_p_2420, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2427 = (g_heff_2ecompile_2eemitc_2egetterOf(v_ce_242, v_t_2426));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5), heff_strAppend(v_t_2423, v_t_2428));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_p_2433 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_p_2433)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2433, 1);
    heff_take_n(v_p_2433, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2433);
  }
  return ({ V a_0 = v_t_2436; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2442 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 2ULL, 2);
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  return ({ V a_0 = v_t_2445; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 8, "uint64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 6, "double");

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_b_241), heff_dup(v_k_243))) {
    heff_drop(v_m_240);
    heff_drop(v_b_241);
    heff_drop(v_ps_242);
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_qs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}), heff_dup(v_ps_242)));
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(heff_dup(v_m_240), v_b_241, v_ps_242, heff_intAdd(heff_dup(v_k_243), MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_m_240);
      heff_drop(v_k_243);
      return v_rest_2411;
    }
    case TAG_Cons: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0), heff_intShow(v_k_243));
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_240, v_t_2414), v_qs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemitc_2ekeyHashGo(v_t_248, MK_INT(0LL), MK_INT(7LL)));
  return heff_intEq(heff_intMod(v_t_249, v_b_241), v_k_243);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str0, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str1, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str2, 17, "#define HEFF_PART");
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulesParts_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2emodulesParts(V v_ce_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_defs_245, V v_ems_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str0), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str2), v_t_247})});
  V v_t_249 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 6))));
  V v_t_2410 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 7))));
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emodulePart_clo), 8, (V[]){v_t_248, v_ce_240, heff_dup(v_s_241), v_t_249, v_t_2410, heff_dup(v_strs_242), heff_dup(v_protos_243), heff_dup(v_lams_244)}));
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2emodulesParts_lam0, 1, 4, (V[]){v_s_241, v_strs_242, v_protos_243, v_lams_244})}));
  V v_t_2415 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_245, v_ems_246));
  V v_m_2416 = (g_list_2efoldl_24s96111113x2107485159(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2415));
  V v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2416); r_; });
  V v_t_2418 = (g_list_2econcatMap(v_t_2414, v_t_2417));
  return (g_list_2emap(v_t_2411, v_t_2418));
}
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emodulesParts(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_strs_242 = heff_env(self)[1];
  V v_protos_243 = heff_env(self)[2];
  V v_lams_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2413 = ({ V a_0 = v_s_241; V a_1 = v_strs_242; V a_2 = v_protos_243; V a_3 = v_lams_244; V a_4 = v_p_2412; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_241, 8); heff_drop(v_strs_242); heff_drop(v_protos_243); heff_drop(v_lams_244); heff_drop(v_p_2412); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2413; V r_ = (g_list_2efoldl_24s1894035205x969464323(a_0, a_1, a_2)); heff_drop(v_ls_2413); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 7);
  V v_x2_244 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 7);
  V v_x3_248 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_247; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_248, 0ULL, 1);
    v_t_2410 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 7);
  V v_x2_2412 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2411; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_x2_2415 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 4, 7);
  V v_x3_2420 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2419; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_Nothing: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x3_2420, 0);
    heff_take_n(v_x3_2420, 1ULL, 1);
    v_t_2422 = (g_heff_2ecompile_2erepr_2esigName(v_x_2421));
    break;
  }
  default: heff_nomatch(v_x3_2420);
  }
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2422}), v_rest_242});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2418}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2410}), v_t_2424});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_246}), v_t_2425});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2426});
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epushOwn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str1, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreshEmitted_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efreshEmitted(V v_acc_240, V v_key_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_s1_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_244), heff_take_field(v_acc_240, 0)});
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str0)));
    V v_t_248 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_242), heff_dup(v_e_244), heff_dup(v_s1_245)));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str1), v_t_247), v_t_248, heff_take_field(v_acc_240, 1)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_242, v_e_244, v_s1_245));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_key_241, v_t_2410}), heff_get_n(v_acc_240, 2, 3)});
    return heff_rec_n(3, shape_ems__s__fresh, (V[]){v_t_246, v_t_249, v_t_2411});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efreshEmitted(a[0], a[1], a[2], a[3]);
}