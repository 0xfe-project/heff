// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_ctype 296362551
#define LBL_ems 310085
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_workers 1757018875
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2eflatLine(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eflatLine_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2egetterOf(V, V);
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egetterOf_clo;
V g_heff_2ecompile_2eemitc_2egivesUp(V, V);
V g_heff_2ecompile_2eemitc_2egivesUp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivesUp_clo;
V g_heff_2ecompile_2eemitc_2eglobalGet(V, V);
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elendingPrims_get(void);
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2elibmNames_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2erelU(V, V);
V g_heff_2ecompile_2eemitc_2erelU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelU_clo;
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere(V, V);
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapesOnlyHere_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etakeLines(V, V);
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeLines_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_list_2eall_24s1909236649x7702533(V);
V g_list_2eall_24s1909236649x7702533_entry(V self, V *a);
extern Clo g_list_2eall_24s1909236649x7702533_clo;
V g_list_2eany_24s1177057410x67789151(V, V);
V g_list_2eany_24s1177057410x67789151_entry(V self, V *a);
extern Clo g_list_2eany_24s1177057410x67789151_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s1673346944x1460195389(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1673346944x1460195389_entry(V self, V *a);
extern Clo g_list_2eany_24s1673346944x1460195389_clo;
V g_list_2eany_24s808001422x1111416318(V, V);
V g_list_2eany_24s808001422x1111416318_entry(V self, V *a);
extern Clo g_list_2eany_24s808001422x1111416318_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24f316845240x1272469554(V, V, V, V);
V g_list_2efoldl_24f316845240x1272469554_entry(V self, V *a);
extern Clo g_list_2efoldl_24f316845240x1272469554_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s753153351x493712762(V, V);
V g_list_2efoldl_24s753153351x493712762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753153351x493712762_clo;
V g_list_2efoldl_24s96111113x2107485159(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s96111113x2107485159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96111113x2107485159_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1293205645x619162872(V, V, V, V);
V g_list_2emap_24f1293205645x619162872_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1382928954x1260344933(V, V, V);
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s353858844x950951807(V, V, V, V);
V g_list_2emap_24s353858844x950951807_entry(V self, V *a);
extern Clo g_list_2emap_24s353858844x950951807_clo;
V g_list_2emap_24s456133444x1904936646(V, V, V, V, V, V, V, V);
V g_list_2emap_24s456133444x1904936646_entry(V self, V *a);
extern Clo g_list_2emap_24s456133444x1904936646_clo;
V g_list_2emap_24s588563787x236154271(V, V, V, V);
V g_list_2emap_24s588563787x236154271_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s766426360x2144213627(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s766426360x2144213627_entry(V self, V *a);
extern Clo g_list_2emap_24s766426360x2144213627_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eshowInt_get(void);
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2415));
    V v_x2_2420 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_ls_2417, v_ls2_2422));
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, v_t_2423});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2424 = heff_field(v_x1_240, 0);
    V v_l_2425 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2428 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2424));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_ts_2429 = heff_field(v_x2_2428, 0);
      V v_ls2_2430 = heff_field(v_x2_2428, 1);
      V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_2425, NTAG(TAG_Nil)});
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ls2_2430));
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2429, v_t_2432});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  case TAG_ETag: {
    V v_t_2433 = heff_field(v_x1_240, 0);
    V v_as_2434 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2434));
    V v_x2_2438 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2436, v_t_2437));
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_MkPair: {
      V v_ts2_2439 = heff_field(v_x2_2438, 0);
      V v_ls_2440 = heff_field(v_x2_2438, 1);
      V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2441, v_ts2_2439));
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){v_t_2442, v_ls_2440});
    }
    default: return heff_nomatch(v_x2_2438);
    }
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_x1_240, 0);
    V v_arms_2444 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2445 = (g_list_2emap_24s1009200955x251267316(heff_dup(v_arms_2444)));
    V v_t_2446 = (g_list_2emap_24s60612435x257154841(v_arms_2444));
    V v_es_2447 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2443, v_t_2446});
    V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2447));
    V v_x2_2450 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2448, v_t_2449));
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_MkPair: {
      V v_ts2_2451 = heff_field(v_x2_2450, 0);
      V v_ls_2452 = heff_field(v_x2_2450, 1);
      V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
      V v_t_2453 = (g_prelude_2e_2b_2b(v_ts_2445, v_ts2_2451));
      return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_t_2453, v_ls_2452});
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2457 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2456));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2457, v_t_2458));
  }
  case TAG_ECall: {
    V v_as_2460 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2461 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2460));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2461, v_t_2462));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength_lent(v_text_240, 0))) {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt_lent(v_text_240, v_i_242, 0)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_244);
      if (heff_intEq_c(heff_strByteAt_lent(v_text_240, v_i_242, 0), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 5, "((V)&");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str1)));
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), v_t_244);
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_247 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str2), v_t_247));
  V v_t_249 = heff_intShow(heff_strLength_lent(v_str_241, 0));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str6), heff_strAppend(v_t_249, v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str7), heff_strAppend(v_t_248, v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_mac_240, v_t_2413)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_246; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str8), v_t_245), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str0, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str1, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str2, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str3, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str4, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str5, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str6, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str7, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str8, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str9, 3, "log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str10, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str11, 3, "exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str12, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str13, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str14, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str15, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str16, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str17, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str18, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str19, 3, "tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str20, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str21, 3, "cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str22, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str23, 3, "sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str24, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str25, 4, "sqrt");

static V g_heff_2ecompile_2eemitc_2elibmNames_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elibmNames_st;
static V g_heff_2ecompile_2eemitc_2elibmNames_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str0), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str2), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str4), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str6), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str8), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str10), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str12), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str14), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str16), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str18), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str19)}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str20), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str21)}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str22), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str23)}), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str24), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str25)}), v_t_2411});
}
V g_heff_2ecompile_2eemitc_2elibmNames_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elibmNames_st)) return g_heff_2ecompile_2eemitc_2elibmNames_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elibmNames_val, &g_heff_2ecompile_2eemitc_2elibmNames_st, g_heff_2ecompile_2eemitc_2elibmNames_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str0, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str1, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str2, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str3, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str4, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str5, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str6, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str7, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elendingPrims_str8, 8, "strSlice");

static V g_heff_2ecompile_2eemitc_2elendingPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elendingPrims_st;
static V g_heff_2ecompile_2eemitc_2elendingPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elendingPrims_str8), v_t_243})});
}
V g_heff_2ecompile_2eemitc_2elendingPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elendingPrims_st)) return g_heff_2ecompile_2eemitc_2elendingPrims_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elendingPrims_val, &g_heff_2ecompile_2eemitc_2elendingPrims_st, g_heff_2ecompile_2eemitc_2elendingPrims_init);
}
Clo g_heff_2ecompile_2eemitc_2egivesUp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2egivesUp_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2egivesUp(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_y_242 = heff_field(v_x2_241, 0);
    return heff_strEq_lent(v_x_240, v_y_242, 1);
  }
  case TAG_RDup: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RClo: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2egivesUp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2egivesUp(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 2, "_c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str65, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str66, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str67, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str68, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str69, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str70, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str71, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str72, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str73, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str74, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str75, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str76, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str77, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str78, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str79, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str80, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str81, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str82, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str83, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str84, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str85, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str86, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str87, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str88, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str89, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str90, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str91, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str93, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str94, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str95, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str96, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str97, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str98, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str99, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str100, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str101, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str102, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str103, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str104, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str105, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str106, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str107, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str108, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str109, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str110, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str111, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str112, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str113, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str114, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str115, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str116, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str117, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str118, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str119, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str120, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str121, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str122, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str123, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str124, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str125, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str126, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str127, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str128, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str129, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str130, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str131, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str132, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str133, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str134, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str135, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str136, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str138, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str140, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str141, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str142, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str143, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str144, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str145, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str146, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str147, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str148, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str149, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str150, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str151, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str152, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str153, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str154, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str155, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str156, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str157, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str158, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str159, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str160, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str161, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str162, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str163, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str164, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str165, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str166, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str167, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str168, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str169, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str170, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str171, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str172, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str173, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str174, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str175, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str176, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str177, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str178, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str179, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str180, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str182, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str183, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str184, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str185, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str186, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str187, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str188, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str189, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str190, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str191, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str192, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str193, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str194, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str195, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str196, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str197, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str198, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str199, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str200, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str201, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str202, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str203, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str204, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str205, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str206, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str207, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str208, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str209, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str210, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str211, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str212, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str213, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str214, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str215, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str216, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str217, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str218, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str219, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str220, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str221, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str222, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str223, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str224, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str225, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str226, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str227, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str228, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str229, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str230, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str231, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str232, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str233, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str234, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str235, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str236, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str238, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str239, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str240, 6, "c_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str241, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str242, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str243, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str244, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str245, 3, "({ ");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_p_244); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_248;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eall_24s1909236649x7702533(v_es_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = (g_list_2eany_24s808001422x1111416318(v_es_245, v_es_245));
      } else {
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_246);
      v_t_248 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_244, ((V)&g_heff_2ecompile_2eemitc_2etestC_str2), v_es_245));
    } else {
      heff_drop(v_t_248);
      V v_m_249 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_245));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_249, v_p_244});
    }
  }
  case TAG_CondRelU: {
    V v_p_2419 = heff_field(v_x2_241, 0);
    V v_es_2420 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2421 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_2420));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2421, v_p_2419});
  }
  case TAG_CondBool: {
    V v_e_2427 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2428 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2427}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2428});
  }
  case TAG_CondNot: {
    V v_c_2434 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2435 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2434));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2435});
  }
  case TAG_CondIf: {
    V v_a_2440 = heff_field(v_x2_241, 0);
    V v_b_2441 = heff_field(v_x2_241, 1);
    V v_x23_2442 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2442)) {
    case TAG_CondTrue: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_2443 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2443, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_2454 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 4, (V[]){v_m_2454, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_2472 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2472, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_2490 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 4, (V[]){v_m_2490, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24107 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam10, 1, 4, (V[]){v_m_24107, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24124 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam11, 1, 4, (V[]){v_m_24124, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24143 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam12, 1, 4, (V[]){v_m_24143, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24163 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam13, 1, 4, (V[]){v_m_24163, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondFalse: {
      V v_m_24179 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam14, 1, 3, (V[]){v_m_24179, v_k_240, v_b_2441});
    }
    case TAG_CondRel: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24192 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam15, 1, 3, (V[]){v_m_24192, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24203 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam16, 1, 4, (V[]){v_m_24203, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24221 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam17, 1, 4, (V[]){v_m_24221, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24239 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam18, 1, 4, (V[]){v_m_24239, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24256 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam19, 1, 4, (V[]){v_m_24256, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24273 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam20, 1, 4, (V[]){v_m_24273, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24292 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam21, 1, 4, (V[]){v_m_24292, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24312 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam22, 1, 4, (V[]){v_m_24312, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondRelU: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24330 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam23, 1, 3, (V[]){v_m_24330, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24341 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam24, 1, 4, (V[]){v_m_24341, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24359 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam25, 1, 4, (V[]){v_m_24359, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24377 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam26, 1, 4, (V[]){v_m_24377, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24394 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam27, 1, 4, (V[]){v_m_24394, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24411 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam28, 1, 4, (V[]){v_m_24411, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24430 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam29, 1, 4, (V[]){v_m_24430, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24450 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam30, 1, 4, (V[]){v_m_24450, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondBool: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24467 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam31, 1, 3, (V[]){v_m_24467, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24478 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam32, 1, 4, (V[]){v_m_24478, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24496 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam33, 1, 4, (V[]){v_m_24496, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24514 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam34, 1, 4, (V[]){v_m_24514, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24531 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam35, 1, 4, (V[]){v_m_24531, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24548 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam36, 1, 4, (V[]){v_m_24548, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24567 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam37, 1, 4, (V[]){v_m_24567, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24587 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam38, 1, 4, (V[]){v_m_24587, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondNot: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24604 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam39, 1, 3, (V[]){v_m_24604, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24615 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam40, 1, 4, (V[]){v_m_24615, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24633 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam41, 1, 4, (V[]){v_m_24633, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24651 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam42, 1, 4, (V[]){v_m_24651, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24668 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam43, 1, 4, (V[]){v_m_24668, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24685 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam44, 1, 4, (V[]){v_m_24685, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24704 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam45, 1, 4, (V[]){v_m_24704, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24724 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam46, 1, 4, (V[]){v_m_24724, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondIf: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24743 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam47, 1, 3, (V[]){v_m_24743, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24754 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam48, 1, 4, (V[]){v_m_24754, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24772 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam49, 1, 4, (V[]){v_m_24772, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24790 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam50, 1, 4, (V[]){v_m_24790, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24807 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam51, 1, 4, (V[]){v_m_24807, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24824 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam52, 1, 4, (V[]){v_m_24824, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24843 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam53, 1, 4, (V[]){v_m_24843, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_24863 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam54, 1, 4, (V[]){v_m_24863, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    case TAG_CondLet: {
      switch (heff_tag_of(v_b_2441)) {
      case TAG_CondTrue: {
        V v_m_24883 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam55, 1, 3, (V[]){v_m_24883, v_k_240, v_x23_2442});
      }
      case TAG_CondFalse: {
        V v_m_24894 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam56, 1, 4, (V[]){v_m_24894, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRel: {
        V v_m_24912 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam57, 1, 4, (V[]){v_m_24912, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondRelU: {
        V v_m_24930 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam58, 1, 4, (V[]){v_m_24930, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondBool: {
        V v_m_24947 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam59, 1, 4, (V[]){v_m_24947, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondNot: {
        V v_m_24964 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam60, 1, 4, (V[]){v_m_24964, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondIf: {
        V v_m_24983 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam61, 1, 4, (V[]){v_m_24983, v_k_240, v_b_2441, v_x23_2442});
      }
      case TAG_CondLet: {
        V v_m_241003 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2440));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam62, 1, 4, (V[]){v_m_241003, v_k_240, v_b_2441, v_x23_2442});
      }
      default: return heff_nomatch(v_b_2441);
      }
    }
    default: return heff_nomatch(v_x23_2442);
    }
  }
  case TAG_CondLet: {
    V v_x_241019 = heff_field(v_x2_241, 0);
    V v_e_241020 = heff_field(v_x2_241, 1);
    V v_c_241021 = heff_field(v_x2_241, 2);
    V v_drops_241022 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_241023 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_241020}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam63, 1, 5, (V[]){v_m_241023, v_k_240, v_c_241021, v_x_241019, v_drops_241022});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etestC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x_2412, 0);
      V v_xs_2415 = heff_field(v_x_2412, 1);
      heff_take_n(v_x_2412, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2etestC_str6)));
    V v_x_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str7), v_p_244), v_t_2417);
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_p_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_x_2426 = (g_heff_2ecompile_2eemitc_2erelU(v_p_2419, v_x_2424));
    return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str8), heff_strAppend(v_x_2431, ((V)&g_heff_2ecompile_2eemitc_2etestC_str9)));
    return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){v_t_2433, v_s_2432});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str10), v_x_2438), v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    V v_m_2448 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2447}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str11), heff_strAppend(v_x_2450, ((V)&g_heff_2ecompile_2eemitc_2etestC_str12)));
      V v_t_2453 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str13), heff_strAppend(v_x_2446, v_t_2452));
      return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){v_t_2453, v_s_2451});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_s_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_s_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    V v_m_2459 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_2460 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2458}));
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_MkPair: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_s_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      V v_m_2463 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_2464 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2462}));
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_MkPair: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_s_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str14), heff_strAppend(v_x_2465, ((V)&g_heff_2ecompile_2eemitc_2etestC_str15)));
        V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str16), heff_strAppend(v_x_2461, v_t_2467));
        V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str17), heff_strAppend(v_x_2457, v_t_2468));
        return heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){v_t_2469, v_s_2466});
      }
      default: return heff_nomatch(v_x2_2464);
      }
    }
    default: return heff_nomatch(v_x2_2460);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_m_2477 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_s_2476}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_s_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      V v_m_2481 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2480}));
      switch (heff_tag_of(v_x2_2482)) {
      case TAG_MkPair: {
        V v_x_2483 = heff_field(v_x2_2482, 0);
        V v_s_2484 = heff_field(v_x2_2482, 1);
        heff_take_n(v_x2_2482, 3ULL, 2);
        V v_t_2485 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str18), heff_strAppend(v_x_2483, ((V)&g_heff_2ecompile_2eemitc_2etestC_str19)));
        V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str20), heff_strAppend(v_x_2479, v_t_2485));
        V v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str21), heff_strAppend(v_x_2475, v_t_2486));
        return heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){v_t_2487, v_s_2484});
      }
      default: return heff_nomatch(v_x2_2482);
      }
    }
    default: return heff_nomatch(v_x2_2478);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_s_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_s_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_m_2495 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_2496 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2494}));
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_MkPair: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_s_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      V v_m_2499 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24100 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_s_2498}));
      switch (heff_tag_of(v_x2_24100)) {
      case TAG_MkPair: {
        V v_x_24101 = heff_field(v_x2_24100, 0);
        V v_s_24102 = heff_field(v_x2_24100, 1);
        heff_take_n(v_x2_24100, 3ULL, 2);
        V v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str22), heff_strAppend(v_x_24101, ((V)&g_heff_2ecompile_2eemitc_2etestC_str23)));
        V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str24), heff_strAppend(v_x_2497, v_t_24103));
        V v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str25), heff_strAppend(v_x_2493, v_t_24104));
        return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_t_24105, v_s_24102});
      }
      default: return heff_nomatch(v_x2_24100);
      }
    }
    default: return heff_nomatch(v_x2_2496);
    }
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    V v_m_24112 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24113 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_MkPair: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_s_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      V v_m_24116 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24117 = heff_tr(heff_call(v_m_24116, 1, (V[]){v_s_24115}));
      switch (heff_tag_of(v_x2_24117)) {
      case TAG_MkPair: {
        V v_x_24118 = heff_field(v_x2_24117, 0);
        V v_s_24119 = heff_field(v_x2_24117, 1);
        heff_take_n(v_x2_24117, 3ULL, 2);
        V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str26), heff_strAppend(v_x_24118, ((V)&g_heff_2ecompile_2eemitc_2etestC_str27)));
        V v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str28), heff_strAppend(v_x_24114, v_t_24120));
        V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str29), heff_strAppend(v_x_24110, v_t_24121));
        return heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){v_t_24122, v_s_24119});
      }
      default: return heff_nomatch(v_x2_24117);
      }
    }
    default: return heff_nomatch(v_x2_24113);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args) {
  V v_s_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_s_24125}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_s_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    V v_m_24129 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_s_24128}));
    switch (heff_tag_of(v_x2_24130)) {
    case TAG_MkPair: {
      V v_x_24131 = heff_field(v_x2_24130, 0);
      V v_s_24132 = heff_field(v_x2_24130, 1);
      heff_take_n(v_x2_24130, 3ULL, 2);
      V v_m_24133 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24134 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24132}));
      switch (heff_tag_of(v_x2_24134)) {
      case TAG_MkPair: {
        V v_x_24135 = heff_field(v_x2_24134, 0);
        V v_s_24136 = heff_field(v_x2_24134, 1);
        heff_take_n(v_x2_24134, 3ULL, 2);
        V v_t_24137 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str30), heff_strAppend(v_x_24135, ((V)&g_heff_2ecompile_2eemitc_2etestC_str31)));
        V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str32), heff_strAppend(v_x_24131, v_t_24137));
        V v_t_24139 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str33), heff_strAppend(v_x_24127, v_t_24138));
        return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){v_t_24139, v_s_24136});
      }
      default: return heff_nomatch(v_x2_24134);
      }
    }
    default: return heff_nomatch(v_x2_24130);
    }
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args) {
  V v_s_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24145 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_s_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_s_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    V v_m_24148 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24149 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_s_24147}));
    switch (heff_tag_of(v_x2_24149)) {
    case TAG_MkPair: {
      V v_x_24150 = heff_field(v_x2_24149, 0);
      V v_s_24151 = heff_field(v_x2_24149, 1);
      heff_take_n(v_x2_24149, 3ULL, 2);
      V v_m_24152 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24153 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24151}));
      switch (heff_tag_of(v_x2_24153)) {
      case TAG_MkPair: {
        V v_x_24154 = heff_field(v_x2_24153, 0);
        V v_s_24155 = heff_field(v_x2_24153, 1);
        heff_take_n(v_x2_24153, 3ULL, 2);
        V v_t_24156 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str34), heff_strAppend(v_x_24154, ((V)&g_heff_2ecompile_2eemitc_2etestC_str35)));
        V v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str36), heff_strAppend(v_x_24150, v_t_24156));
        V v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), heff_strAppend(v_x_24146, v_t_24157));
        return heff_tag_at_n(v_ru_24x2_24145_24MkPair, TAG_MkPair, 2, (V[]){v_t_24158, v_s_24155});
      }
      default: return heff_nomatch(v_x2_24153);
      }
    }
    default: return heff_nomatch(v_x2_24149);
    }
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args) {
  V v_s_24164 = args[0];
  V v_m_24163 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24165 = heff_tr(heff_call(v_m_24163, 1, (V[]){v_s_24164}));
  switch (heff_tag_of(v_x2_24165)) {
  case TAG_MkPair: {
    V v_x_24166 = heff_field(v_x2_24165, 0);
    V v_s_24167 = heff_field(v_x2_24165, 1);
    V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
    V v_m_24168 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_s_24167}));
    switch (heff_tag_of(v_x2_24169)) {
    case TAG_MkPair: {
      V v_x_24170 = heff_field(v_x2_24169, 0);
      V v_s_24171 = heff_field(v_x2_24169, 1);
      heff_take_n(v_x2_24169, 3ULL, 2);
      V v_m_24172 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24173 = heff_tr(heff_call(v_m_24172, 1, (V[]){v_s_24171}));
      switch (heff_tag_of(v_x2_24173)) {
      case TAG_MkPair: {
        V v_x_24174 = heff_field(v_x2_24173, 0);
        V v_s_24175 = heff_field(v_x2_24173, 1);
        heff_take_n(v_x2_24173, 3ULL, 2);
        V v_t_24176 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str38), heff_strAppend(v_x_24174, ((V)&g_heff_2ecompile_2eemitc_2etestC_str39)));
        V v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), heff_strAppend(v_x_24170, v_t_24176));
        V v_t_24178 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str41), heff_strAppend(v_x_24166, v_t_24177));
        return heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_MkPair, 2, (V[]){v_t_24178, v_s_24175});
      }
      default: return heff_nomatch(v_x2_24173);
      }
    }
    default: return heff_nomatch(v_x2_24169);
    }
  }
  default: return heff_nomatch(v_x2_24165);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args) {
  V v_s_24180 = args[0];
  V v_m_24179 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24181 = heff_tr(heff_call(v_m_24179, 1, (V[]){v_s_24180}));
  switch (heff_tag_of(v_x2_24181)) {
  case TAG_MkPair: {
    V v_x_24182 = heff_field(v_x2_24181, 0);
    V v_s_24183 = heff_field(v_x2_24181, 1);
    V v_ru_24x2_24181_24MkPair = heff_take_reuse_n(v_x2_24181, 3ULL, 2);
    V v_m_24184 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2441));
    V v_x2_24185 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_s_24183}));
    switch (heff_tag_of(v_x2_24185)) {
    case TAG_MkPair: {
      V v_x_24186 = heff_field(v_x2_24185, 0);
      V v_s_24187 = heff_field(v_x2_24185, 1);
      heff_take_n(v_x2_24185, 3ULL, 2);
      V v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str42), heff_strAppend(v_x_24186, ((V)&g_heff_2ecompile_2eemitc_2etestC_str43)));
      V v_t_24189 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str44), heff_strAppend(v_x_24182, v_t_24188));
      return heff_tag_at_n(v_ru_24x2_24181_24MkPair, TAG_MkPair, 2, (V[]){v_t_24189, v_s_24187});
    }
    default: return heff_nomatch(v_x2_24185);
    }
  }
  default: return heff_nomatch(v_x2_24181);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args) {
  V v_s_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_s_24193}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_MkPair: {
    V v_x_24195 = heff_field(v_x2_24194, 0);
    V v_s_24196 = heff_field(v_x2_24194, 1);
    V v_ru_24x2_24194_24MkPair = heff_take_reuse_n(v_x2_24194, 3ULL, 2);
    V v_m_24197 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24198 = heff_tr(heff_call(v_m_24197, 1, (V[]){v_s_24196}));
    switch (heff_tag_of(v_x2_24198)) {
    case TAG_MkPair: {
      V v_x_24199 = heff_field(v_x2_24198, 0);
      V v_s_24200 = heff_field(v_x2_24198, 1);
      heff_take_n(v_x2_24198, 3ULL, 2);
      V v_t_24201 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str45), heff_strAppend(v_x_24199, ((V)&g_heff_2ecompile_2eemitc_2etestC_str46)));
      V v_t_24202 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str47), heff_strAppend(v_x_24195, v_t_24201));
      return heff_tag_at_n(v_ru_24x2_24194_24MkPair, TAG_MkPair, 2, (V[]){v_t_24202, v_s_24200});
    }
    default: return heff_nomatch(v_x2_24198);
    }
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args) {
  V v_s_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_s_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_s_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    V v_m_24208 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24209 = heff_tr(heff_call(v_m_24208, 1, (V[]){v_s_24207}));
    switch (heff_tag_of(v_x2_24209)) {
    case TAG_MkPair: {
      V v_x_24210 = heff_field(v_x2_24209, 0);
      V v_s_24211 = heff_field(v_x2_24209, 1);
      heff_take_n(v_x2_24209, 3ULL, 2);
      V v_m_24212 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24213 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_s_24211}));
      switch (heff_tag_of(v_x2_24213)) {
      case TAG_MkPair: {
        V v_x_24214 = heff_field(v_x2_24213, 0);
        V v_s_24215 = heff_field(v_x2_24213, 1);
        heff_take_n(v_x2_24213, 3ULL, 2);
        V v_t_24216 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str48), heff_strAppend(v_x_24214, ((V)&g_heff_2ecompile_2eemitc_2etestC_str49)));
        V v_t_24217 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str50), heff_strAppend(v_x_24210, v_t_24216));
        V v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str51), heff_strAppend(v_x_24206, v_t_24217));
        return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){v_t_24218, v_s_24215});
      }
      default: return heff_nomatch(v_x2_24213);
      }
    }
    default: return heff_nomatch(v_x2_24209);
    }
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args) {
  V v_s_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24223 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_s_24222}));
  switch (heff_tag_of(v_x2_24223)) {
  case TAG_MkPair: {
    V v_x_24224 = heff_field(v_x2_24223, 0);
    V v_s_24225 = heff_field(v_x2_24223, 1);
    V v_ru_24x2_24223_24MkPair = heff_take_reuse_n(v_x2_24223, 3ULL, 2);
    V v_m_24226 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24227 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_s_24225}));
    switch (heff_tag_of(v_x2_24227)) {
    case TAG_MkPair: {
      V v_x_24228 = heff_field(v_x2_24227, 0);
      V v_s_24229 = heff_field(v_x2_24227, 1);
      heff_take_n(v_x2_24227, 3ULL, 2);
      V v_m_24230 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24231 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_s_24229}));
      switch (heff_tag_of(v_x2_24231)) {
      case TAG_MkPair: {
        V v_x_24232 = heff_field(v_x2_24231, 0);
        V v_s_24233 = heff_field(v_x2_24231, 1);
        heff_take_n(v_x2_24231, 3ULL, 2);
        V v_t_24234 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str52), heff_strAppend(v_x_24232, ((V)&g_heff_2ecompile_2eemitc_2etestC_str53)));
        V v_t_24235 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str54), heff_strAppend(v_x_24228, v_t_24234));
        V v_t_24236 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str55), heff_strAppend(v_x_24224, v_t_24235));
        return heff_tag_at_n(v_ru_24x2_24223_24MkPair, TAG_MkPair, 2, (V[]){v_t_24236, v_s_24233});
      }
      default: return heff_nomatch(v_x2_24231);
      }
    }
    default: return heff_nomatch(v_x2_24227);
    }
  }
  default: return heff_nomatch(v_x2_24223);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args) {
  V v_s_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_s_24240}));
  switch (heff_tag_of(v_x2_24241)) {
  case TAG_MkPair: {
    V v_x_24242 = heff_field(v_x2_24241, 0);
    V v_s_24243 = heff_field(v_x2_24241, 1);
    V v_ru_24x2_24241_24MkPair = heff_take_reuse_n(v_x2_24241, 3ULL, 2);
    V v_m_24244 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_s_24243}));
    switch (heff_tag_of(v_x2_24245)) {
    case TAG_MkPair: {
      V v_x_24246 = heff_field(v_x2_24245, 0);
      V v_s_24247 = heff_field(v_x2_24245, 1);
      heff_take_n(v_x2_24245, 3ULL, 2);
      V v_m_24248 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24249 = heff_tr(heff_call(v_m_24248, 1, (V[]){v_s_24247}));
      switch (heff_tag_of(v_x2_24249)) {
      case TAG_MkPair: {
        V v_x_24250 = heff_field(v_x2_24249, 0);
        V v_s_24251 = heff_field(v_x2_24249, 1);
        heff_take_n(v_x2_24249, 3ULL, 2);
        V v_t_24252 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str56), heff_strAppend(v_x_24250, ((V)&g_heff_2ecompile_2eemitc_2etestC_str57)));
        V v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str58), heff_strAppend(v_x_24246, v_t_24252));
        V v_t_24254 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str59), heff_strAppend(v_x_24242, v_t_24253));
        return heff_tag_at_n(v_ru_24x2_24241_24MkPair, TAG_MkPair, 2, (V[]){v_t_24254, v_s_24251});
      }
      default: return heff_nomatch(v_x2_24249);
      }
    }
    default: return heff_nomatch(v_x2_24245);
    }
  }
  default: return heff_nomatch(v_x2_24241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args) {
  V v_s_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24258 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_s_24257}));
  switch (heff_tag_of(v_x2_24258)) {
  case TAG_MkPair: {
    V v_x_24259 = heff_field(v_x2_24258, 0);
    V v_s_24260 = heff_field(v_x2_24258, 1);
    V v_ru_24x2_24258_24MkPair = heff_take_reuse_n(v_x2_24258, 3ULL, 2);
    V v_m_24261 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24262 = heff_tr(heff_call(v_m_24261, 1, (V[]){v_s_24260}));
    switch (heff_tag_of(v_x2_24262)) {
    case TAG_MkPair: {
      V v_x_24263 = heff_field(v_x2_24262, 0);
      V v_s_24264 = heff_field(v_x2_24262, 1);
      heff_take_n(v_x2_24262, 3ULL, 2);
      V v_m_24265 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24266 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_s_24264}));
      switch (heff_tag_of(v_x2_24266)) {
      case TAG_MkPair: {
        V v_x_24267 = heff_field(v_x2_24266, 0);
        V v_s_24268 = heff_field(v_x2_24266, 1);
        heff_take_n(v_x2_24266, 3ULL, 2);
        V v_t_24269 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str60), heff_strAppend(v_x_24267, ((V)&g_heff_2ecompile_2eemitc_2etestC_str61)));
        V v_t_24270 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str62), heff_strAppend(v_x_24263, v_t_24269));
        V v_t_24271 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str63), heff_strAppend(v_x_24259, v_t_24270));
        return heff_tag_at_n(v_ru_24x2_24258_24MkPair, TAG_MkPair, 2, (V[]){v_t_24271, v_s_24268});
      }
      default: return heff_nomatch(v_x2_24266);
      }
    }
    default: return heff_nomatch(v_x2_24262);
    }
  }
  default: return heff_nomatch(v_x2_24258);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args) {
  V v_s_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_s_24274}));
  switch (heff_tag_of(v_x2_24275)) {
  case TAG_MkPair: {
    V v_x_24276 = heff_field(v_x2_24275, 0);
    V v_s_24277 = heff_field(v_x2_24275, 1);
    V v_ru_24x2_24275_24MkPair = heff_take_reuse_n(v_x2_24275, 3ULL, 2);
    V v_m_24278 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24279 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_s_24277}));
    switch (heff_tag_of(v_x2_24279)) {
    case TAG_MkPair: {
      V v_x_24280 = heff_field(v_x2_24279, 0);
      V v_s_24281 = heff_field(v_x2_24279, 1);
      heff_take_n(v_x2_24279, 3ULL, 2);
      V v_m_24282 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24283 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_s_24281}));
      switch (heff_tag_of(v_x2_24283)) {
      case TAG_MkPair: {
        V v_x_24284 = heff_field(v_x2_24283, 0);
        V v_s_24285 = heff_field(v_x2_24283, 1);
        heff_take_n(v_x2_24283, 3ULL, 2);
        V v_t_24286 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str64), heff_strAppend(v_x_24284, ((V)&g_heff_2ecompile_2eemitc_2etestC_str65)));
        V v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str66), heff_strAppend(v_x_24280, v_t_24286));
        V v_t_24288 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str67), heff_strAppend(v_x_24276, v_t_24287));
        return heff_tag_at_n(v_ru_24x2_24275_24MkPair, TAG_MkPair, 2, (V[]){v_t_24288, v_s_24285});
      }
      default: return heff_nomatch(v_x2_24283);
      }
    }
    default: return heff_nomatch(v_x2_24279);
    }
  }
  default: return heff_nomatch(v_x2_24275);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args) {
  V v_s_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24294 = heff_tr(heff_call(v_m_24292, 1, (V[]){v_s_24293}));
  switch (heff_tag_of(v_x2_24294)) {
  case TAG_MkPair: {
    V v_x_24295 = heff_field(v_x2_24294, 0);
    V v_s_24296 = heff_field(v_x2_24294, 1);
    V v_ru_24x2_24294_24MkPair = heff_take_reuse_n(v_x2_24294, 3ULL, 2);
    V v_m_24297 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24298 = heff_tr(heff_call(v_m_24297, 1, (V[]){v_s_24296}));
    switch (heff_tag_of(v_x2_24298)) {
    case TAG_MkPair: {
      V v_x_24299 = heff_field(v_x2_24298, 0);
      V v_s_24300 = heff_field(v_x2_24298, 1);
      heff_take_n(v_x2_24298, 3ULL, 2);
      V v_m_24301 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_s_24300}));
      switch (heff_tag_of(v_x2_24302)) {
      case TAG_MkPair: {
        V v_x_24303 = heff_field(v_x2_24302, 0);
        V v_s_24304 = heff_field(v_x2_24302, 1);
        heff_take_n(v_x2_24302, 3ULL, 2);
        V v_t_24305 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str68), heff_strAppend(v_x_24303, ((V)&g_heff_2ecompile_2eemitc_2etestC_str69)));
        V v_t_24306 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str70), heff_strAppend(v_x_24299, v_t_24305));
        V v_t_24307 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str71), heff_strAppend(v_x_24295, v_t_24306));
        return heff_tag_at_n(v_ru_24x2_24294_24MkPair, TAG_MkPair, 2, (V[]){v_t_24307, v_s_24304});
      }
      default: return heff_nomatch(v_x2_24302);
      }
    }
    default: return heff_nomatch(v_x2_24298);
    }
  }
  default: return heff_nomatch(v_x2_24294);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args) {
  V v_s_24313 = args[0];
  V v_m_24312 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24314 = heff_tr(heff_call(v_m_24312, 1, (V[]){v_s_24313}));
  switch (heff_tag_of(v_x2_24314)) {
  case TAG_MkPair: {
    V v_x_24315 = heff_field(v_x2_24314, 0);
    V v_s_24316 = heff_field(v_x2_24314, 1);
    V v_ru_24x2_24314_24MkPair = heff_take_reuse_n(v_x2_24314, 3ULL, 2);
    V v_m_24317 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24318 = heff_tr(heff_call(v_m_24317, 1, (V[]){v_s_24316}));
    switch (heff_tag_of(v_x2_24318)) {
    case TAG_MkPair: {
      V v_x_24319 = heff_field(v_x2_24318, 0);
      V v_s_24320 = heff_field(v_x2_24318, 1);
      heff_take_n(v_x2_24318, 3ULL, 2);
      V v_m_24321 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24322 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_s_24320}));
      switch (heff_tag_of(v_x2_24322)) {
      case TAG_MkPair: {
        V v_x_24323 = heff_field(v_x2_24322, 0);
        V v_s_24324 = heff_field(v_x2_24322, 1);
        heff_take_n(v_x2_24322, 3ULL, 2);
        V v_t_24325 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str72), heff_strAppend(v_x_24323, ((V)&g_heff_2ecompile_2eemitc_2etestC_str73)));
        V v_t_24326 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str74), heff_strAppend(v_x_24319, v_t_24325));
        V v_t_24327 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str75), heff_strAppend(v_x_24315, v_t_24326));
        return heff_tag_at_n(v_ru_24x2_24314_24MkPair, TAG_MkPair, 2, (V[]){v_t_24327, v_s_24324});
      }
      default: return heff_nomatch(v_x2_24322);
      }
    }
    default: return heff_nomatch(v_x2_24318);
    }
  }
  default: return heff_nomatch(v_x2_24314);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args) {
  V v_s_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_s_24331}));
  switch (heff_tag_of(v_x2_24332)) {
  case TAG_MkPair: {
    V v_x_24333 = heff_field(v_x2_24332, 0);
    V v_s_24334 = heff_field(v_x2_24332, 1);
    V v_ru_24x2_24332_24MkPair = heff_take_reuse_n(v_x2_24332, 3ULL, 2);
    V v_m_24335 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24336 = heff_tr(heff_call(v_m_24335, 1, (V[]){v_s_24334}));
    switch (heff_tag_of(v_x2_24336)) {
    case TAG_MkPair: {
      V v_x_24337 = heff_field(v_x2_24336, 0);
      V v_s_24338 = heff_field(v_x2_24336, 1);
      heff_take_n(v_x2_24336, 3ULL, 2);
      V v_t_24339 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str76), heff_strAppend(v_x_24337, ((V)&g_heff_2ecompile_2eemitc_2etestC_str77)));
      V v_t_24340 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str78), heff_strAppend(v_x_24333, v_t_24339));
      return heff_tag_at_n(v_ru_24x2_24332_24MkPair, TAG_MkPair, 2, (V[]){v_t_24340, v_s_24338});
    }
    default: return heff_nomatch(v_x2_24336);
    }
  }
  default: return heff_nomatch(v_x2_24332);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args) {
  V v_s_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_s_24342}));
  switch (heff_tag_of(v_x2_24343)) {
  case TAG_MkPair: {
    V v_x_24344 = heff_field(v_x2_24343, 0);
    V v_s_24345 = heff_field(v_x2_24343, 1);
    V v_ru_24x2_24343_24MkPair = heff_take_reuse_n(v_x2_24343, 3ULL, 2);
    V v_m_24346 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24347 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_s_24345}));
    switch (heff_tag_of(v_x2_24347)) {
    case TAG_MkPair: {
      V v_x_24348 = heff_field(v_x2_24347, 0);
      V v_s_24349 = heff_field(v_x2_24347, 1);
      heff_take_n(v_x2_24347, 3ULL, 2);
      V v_m_24350 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24351 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_s_24349}));
      switch (heff_tag_of(v_x2_24351)) {
      case TAG_MkPair: {
        V v_x_24352 = heff_field(v_x2_24351, 0);
        V v_s_24353 = heff_field(v_x2_24351, 1);
        heff_take_n(v_x2_24351, 3ULL, 2);
        V v_t_24354 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str79), heff_strAppend(v_x_24352, ((V)&g_heff_2ecompile_2eemitc_2etestC_str80)));
        V v_t_24355 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str81), heff_strAppend(v_x_24348, v_t_24354));
        V v_t_24356 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str82), heff_strAppend(v_x_24344, v_t_24355));
        return heff_tag_at_n(v_ru_24x2_24343_24MkPair, TAG_MkPair, 2, (V[]){v_t_24356, v_s_24353});
      }
      default: return heff_nomatch(v_x2_24351);
      }
    }
    default: return heff_nomatch(v_x2_24347);
    }
  }
  default: return heff_nomatch(v_x2_24343);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args) {
  V v_s_24360 = args[0];
  V v_m_24359 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24361 = heff_tr(heff_call(v_m_24359, 1, (V[]){v_s_24360}));
  switch (heff_tag_of(v_x2_24361)) {
  case TAG_MkPair: {
    V v_x_24362 = heff_field(v_x2_24361, 0);
    V v_s_24363 = heff_field(v_x2_24361, 1);
    V v_ru_24x2_24361_24MkPair = heff_take_reuse_n(v_x2_24361, 3ULL, 2);
    V v_m_24364 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24365 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_s_24363}));
    switch (heff_tag_of(v_x2_24365)) {
    case TAG_MkPair: {
      V v_x_24366 = heff_field(v_x2_24365, 0);
      V v_s_24367 = heff_field(v_x2_24365, 1);
      heff_take_n(v_x2_24365, 3ULL, 2);
      V v_m_24368 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24369 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_s_24367}));
      switch (heff_tag_of(v_x2_24369)) {
      case TAG_MkPair: {
        V v_x_24370 = heff_field(v_x2_24369, 0);
        V v_s_24371 = heff_field(v_x2_24369, 1);
        heff_take_n(v_x2_24369, 3ULL, 2);
        V v_t_24372 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str83), heff_strAppend(v_x_24370, ((V)&g_heff_2ecompile_2eemitc_2etestC_str84)));
        V v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str85), heff_strAppend(v_x_24366, v_t_24372));
        V v_t_24374 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str86), heff_strAppend(v_x_24362, v_t_24373));
        return heff_tag_at_n(v_ru_24x2_24361_24MkPair, TAG_MkPair, 2, (V[]){v_t_24374, v_s_24371});
      }
      default: return heff_nomatch(v_x2_24369);
      }
    }
    default: return heff_nomatch(v_x2_24365);
    }
  }
  default: return heff_nomatch(v_x2_24361);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args) {
  V v_s_24378 = args[0];
  V v_m_24377 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24379 = heff_tr(heff_call(v_m_24377, 1, (V[]){v_s_24378}));
  switch (heff_tag_of(v_x2_24379)) {
  case TAG_MkPair: {
    V v_x_24380 = heff_field(v_x2_24379, 0);
    V v_s_24381 = heff_field(v_x2_24379, 1);
    V v_ru_24x2_24379_24MkPair = heff_take_reuse_n(v_x2_24379, 3ULL, 2);
    V v_m_24382 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24383 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_s_24381}));
    switch (heff_tag_of(v_x2_24383)) {
    case TAG_MkPair: {
      V v_x_24384 = heff_field(v_x2_24383, 0);
      V v_s_24385 = heff_field(v_x2_24383, 1);
      heff_take_n(v_x2_24383, 3ULL, 2);
      V v_m_24386 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24387 = heff_tr(heff_call(v_m_24386, 1, (V[]){v_s_24385}));
      switch (heff_tag_of(v_x2_24387)) {
      case TAG_MkPair: {
        V v_x_24388 = heff_field(v_x2_24387, 0);
        V v_s_24389 = heff_field(v_x2_24387, 1);
        heff_take_n(v_x2_24387, 3ULL, 2);
        V v_t_24390 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str87), heff_strAppend(v_x_24388, ((V)&g_heff_2ecompile_2eemitc_2etestC_str88)));
        V v_t_24391 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str89), heff_strAppend(v_x_24384, v_t_24390));
        V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str90), heff_strAppend(v_x_24380, v_t_24391));
        return heff_tag_at_n(v_ru_24x2_24379_24MkPair, TAG_MkPair, 2, (V[]){v_t_24392, v_s_24389});
      }
      default: return heff_nomatch(v_x2_24387);
      }
    }
    default: return heff_nomatch(v_x2_24383);
    }
  }
  default: return heff_nomatch(v_x2_24379);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args) {
  V v_s_24395 = args[0];
  V v_m_24394 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24396 = heff_tr(heff_call(v_m_24394, 1, (V[]){v_s_24395}));
  switch (heff_tag_of(v_x2_24396)) {
  case TAG_MkPair: {
    V v_x_24397 = heff_field(v_x2_24396, 0);
    V v_s_24398 = heff_field(v_x2_24396, 1);
    V v_ru_24x2_24396_24MkPair = heff_take_reuse_n(v_x2_24396, 3ULL, 2);
    V v_m_24399 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24400 = heff_tr(heff_call(v_m_24399, 1, (V[]){v_s_24398}));
    switch (heff_tag_of(v_x2_24400)) {
    case TAG_MkPair: {
      V v_x_24401 = heff_field(v_x2_24400, 0);
      V v_s_24402 = heff_field(v_x2_24400, 1);
      heff_take_n(v_x2_24400, 3ULL, 2);
      V v_m_24403 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24404 = heff_tr(heff_call(v_m_24403, 1, (V[]){v_s_24402}));
      switch (heff_tag_of(v_x2_24404)) {
      case TAG_MkPair: {
        V v_x_24405 = heff_field(v_x2_24404, 0);
        V v_s_24406 = heff_field(v_x2_24404, 1);
        heff_take_n(v_x2_24404, 3ULL, 2);
        V v_t_24407 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str91), heff_strAppend(v_x_24405, ((V)&g_heff_2ecompile_2eemitc_2etestC_str92)));
        V v_t_24408 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str93), heff_strAppend(v_x_24401, v_t_24407));
        V v_t_24409 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str94), heff_strAppend(v_x_24397, v_t_24408));
        return heff_tag_at_n(v_ru_24x2_24396_24MkPair, TAG_MkPair, 2, (V[]){v_t_24409, v_s_24406});
      }
      default: return heff_nomatch(v_x2_24404);
      }
    }
    default: return heff_nomatch(v_x2_24400);
    }
  }
  default: return heff_nomatch(v_x2_24396);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args) {
  V v_s_24412 = args[0];
  V v_m_24411 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24413 = heff_tr(heff_call(v_m_24411, 1, (V[]){v_s_24412}));
  switch (heff_tag_of(v_x2_24413)) {
  case TAG_MkPair: {
    V v_x_24414 = heff_field(v_x2_24413, 0);
    V v_s_24415 = heff_field(v_x2_24413, 1);
    V v_ru_24x2_24413_24MkPair = heff_take_reuse_n(v_x2_24413, 3ULL, 2);
    V v_m_24416 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24417 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_s_24415}));
    switch (heff_tag_of(v_x2_24417)) {
    case TAG_MkPair: {
      V v_x_24418 = heff_field(v_x2_24417, 0);
      V v_s_24419 = heff_field(v_x2_24417, 1);
      heff_take_n(v_x2_24417, 3ULL, 2);
      V v_m_24420 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24421 = heff_tr(heff_call(v_m_24420, 1, (V[]){v_s_24419}));
      switch (heff_tag_of(v_x2_24421)) {
      case TAG_MkPair: {
        V v_x_24422 = heff_field(v_x2_24421, 0);
        V v_s_24423 = heff_field(v_x2_24421, 1);
        heff_take_n(v_x2_24421, 3ULL, 2);
        V v_t_24424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str95), heff_strAppend(v_x_24422, ((V)&g_heff_2ecompile_2eemitc_2etestC_str96)));
        V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str97), heff_strAppend(v_x_24418, v_t_24424));
        V v_t_24426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str98), heff_strAppend(v_x_24414, v_t_24425));
        return heff_tag_at_n(v_ru_24x2_24413_24MkPair, TAG_MkPair, 2, (V[]){v_t_24426, v_s_24423});
      }
      default: return heff_nomatch(v_x2_24421);
      }
    }
    default: return heff_nomatch(v_x2_24417);
    }
  }
  default: return heff_nomatch(v_x2_24413);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args) {
  V v_s_24431 = args[0];
  V v_m_24430 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24432 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_s_24431}));
  switch (heff_tag_of(v_x2_24432)) {
  case TAG_MkPair: {
    V v_x_24433 = heff_field(v_x2_24432, 0);
    V v_s_24434 = heff_field(v_x2_24432, 1);
    V v_ru_24x2_24432_24MkPair = heff_take_reuse_n(v_x2_24432, 3ULL, 2);
    V v_m_24435 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24436 = heff_tr(heff_call(v_m_24435, 1, (V[]){v_s_24434}));
    switch (heff_tag_of(v_x2_24436)) {
    case TAG_MkPair: {
      V v_x_24437 = heff_field(v_x2_24436, 0);
      V v_s_24438 = heff_field(v_x2_24436, 1);
      heff_take_n(v_x2_24436, 3ULL, 2);
      V v_m_24439 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24440 = heff_tr(heff_call(v_m_24439, 1, (V[]){v_s_24438}));
      switch (heff_tag_of(v_x2_24440)) {
      case TAG_MkPair: {
        V v_x_24441 = heff_field(v_x2_24440, 0);
        V v_s_24442 = heff_field(v_x2_24440, 1);
        heff_take_n(v_x2_24440, 3ULL, 2);
        V v_t_24443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str99), heff_strAppend(v_x_24441, ((V)&g_heff_2ecompile_2eemitc_2etestC_str100)));
        V v_t_24444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str101), heff_strAppend(v_x_24437, v_t_24443));
        V v_t_24445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str102), heff_strAppend(v_x_24433, v_t_24444));
        return heff_tag_at_n(v_ru_24x2_24432_24MkPair, TAG_MkPair, 2, (V[]){v_t_24445, v_s_24442});
      }
      default: return heff_nomatch(v_x2_24440);
      }
    }
    default: return heff_nomatch(v_x2_24436);
    }
  }
  default: return heff_nomatch(v_x2_24432);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args) {
  V v_s_24451 = args[0];
  V v_m_24450 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24452 = heff_tr(heff_call(v_m_24450, 1, (V[]){v_s_24451}));
  switch (heff_tag_of(v_x2_24452)) {
  case TAG_MkPair: {
    V v_x_24453 = heff_field(v_x2_24452, 0);
    V v_s_24454 = heff_field(v_x2_24452, 1);
    V v_ru_24x2_24452_24MkPair = heff_take_reuse_n(v_x2_24452, 3ULL, 2);
    V v_m_24455 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24456 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_s_24454}));
    switch (heff_tag_of(v_x2_24456)) {
    case TAG_MkPair: {
      V v_x_24457 = heff_field(v_x2_24456, 0);
      V v_s_24458 = heff_field(v_x2_24456, 1);
      heff_take_n(v_x2_24456, 3ULL, 2);
      V v_m_24459 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24460 = heff_tr(heff_call(v_m_24459, 1, (V[]){v_s_24458}));
      switch (heff_tag_of(v_x2_24460)) {
      case TAG_MkPair: {
        V v_x_24461 = heff_field(v_x2_24460, 0);
        V v_s_24462 = heff_field(v_x2_24460, 1);
        heff_take_n(v_x2_24460, 3ULL, 2);
        V v_t_24463 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str103), heff_strAppend(v_x_24461, ((V)&g_heff_2ecompile_2eemitc_2etestC_str104)));
        V v_t_24464 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str105), heff_strAppend(v_x_24457, v_t_24463));
        V v_t_24465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str106), heff_strAppend(v_x_24453, v_t_24464));
        return heff_tag_at_n(v_ru_24x2_24452_24MkPair, TAG_MkPair, 2, (V[]){v_t_24465, v_s_24462});
      }
      default: return heff_nomatch(v_x2_24460);
      }
    }
    default: return heff_nomatch(v_x2_24456);
    }
  }
  default: return heff_nomatch(v_x2_24452);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args) {
  V v_s_24468 = args[0];
  V v_m_24467 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24469 = heff_tr(heff_call(v_m_24467, 1, (V[]){v_s_24468}));
  switch (heff_tag_of(v_x2_24469)) {
  case TAG_MkPair: {
    V v_x_24470 = heff_field(v_x2_24469, 0);
    V v_s_24471 = heff_field(v_x2_24469, 1);
    V v_ru_24x2_24469_24MkPair = heff_take_reuse_n(v_x2_24469, 3ULL, 2);
    V v_m_24472 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24473 = heff_tr(heff_call(v_m_24472, 1, (V[]){v_s_24471}));
    switch (heff_tag_of(v_x2_24473)) {
    case TAG_MkPair: {
      V v_x_24474 = heff_field(v_x2_24473, 0);
      V v_s_24475 = heff_field(v_x2_24473, 1);
      heff_take_n(v_x2_24473, 3ULL, 2);
      V v_t_24476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str107), heff_strAppend(v_x_24474, ((V)&g_heff_2ecompile_2eemitc_2etestC_str108)));
      V v_t_24477 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str109), heff_strAppend(v_x_24470, v_t_24476));
      return heff_tag_at_n(v_ru_24x2_24469_24MkPair, TAG_MkPair, 2, (V[]){v_t_24477, v_s_24475});
    }
    default: return heff_nomatch(v_x2_24473);
    }
  }
  default: return heff_nomatch(v_x2_24469);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args) {
  V v_s_24479 = args[0];
  V v_m_24478 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24480 = heff_tr(heff_call(v_m_24478, 1, (V[]){v_s_24479}));
  switch (heff_tag_of(v_x2_24480)) {
  case TAG_MkPair: {
    V v_x_24481 = heff_field(v_x2_24480, 0);
    V v_s_24482 = heff_field(v_x2_24480, 1);
    V v_ru_24x2_24480_24MkPair = heff_take_reuse_n(v_x2_24480, 3ULL, 2);
    V v_m_24483 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24484 = heff_tr(heff_call(v_m_24483, 1, (V[]){v_s_24482}));
    switch (heff_tag_of(v_x2_24484)) {
    case TAG_MkPair: {
      V v_x_24485 = heff_field(v_x2_24484, 0);
      V v_s_24486 = heff_field(v_x2_24484, 1);
      heff_take_n(v_x2_24484, 3ULL, 2);
      V v_m_24487 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24488 = heff_tr(heff_call(v_m_24487, 1, (V[]){v_s_24486}));
      switch (heff_tag_of(v_x2_24488)) {
      case TAG_MkPair: {
        V v_x_24489 = heff_field(v_x2_24488, 0);
        V v_s_24490 = heff_field(v_x2_24488, 1);
        heff_take_n(v_x2_24488, 3ULL, 2);
        V v_t_24491 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str110), heff_strAppend(v_x_24489, ((V)&g_heff_2ecompile_2eemitc_2etestC_str111)));
        V v_t_24492 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str112), heff_strAppend(v_x_24485, v_t_24491));
        V v_t_24493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str113), heff_strAppend(v_x_24481, v_t_24492));
        return heff_tag_at_n(v_ru_24x2_24480_24MkPair, TAG_MkPair, 2, (V[]){v_t_24493, v_s_24490});
      }
      default: return heff_nomatch(v_x2_24488);
      }
    }
    default: return heff_nomatch(v_x2_24484);
    }
  }
  default: return heff_nomatch(v_x2_24480);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args) {
  V v_s_24497 = args[0];
  V v_m_24496 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24498 = heff_tr(heff_call(v_m_24496, 1, (V[]){v_s_24497}));
  switch (heff_tag_of(v_x2_24498)) {
  case TAG_MkPair: {
    V v_x_24499 = heff_field(v_x2_24498, 0);
    V v_s_24500 = heff_field(v_x2_24498, 1);
    V v_ru_24x2_24498_24MkPair = heff_take_reuse_n(v_x2_24498, 3ULL, 2);
    V v_m_24501 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24502 = heff_tr(heff_call(v_m_24501, 1, (V[]){v_s_24500}));
    switch (heff_tag_of(v_x2_24502)) {
    case TAG_MkPair: {
      V v_x_24503 = heff_field(v_x2_24502, 0);
      V v_s_24504 = heff_field(v_x2_24502, 1);
      heff_take_n(v_x2_24502, 3ULL, 2);
      V v_m_24505 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24506 = heff_tr(heff_call(v_m_24505, 1, (V[]){v_s_24504}));
      switch (heff_tag_of(v_x2_24506)) {
      case TAG_MkPair: {
        V v_x_24507 = heff_field(v_x2_24506, 0);
        V v_s_24508 = heff_field(v_x2_24506, 1);
        heff_take_n(v_x2_24506, 3ULL, 2);
        V v_t_24509 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str114), heff_strAppend(v_x_24507, ((V)&g_heff_2ecompile_2eemitc_2etestC_str115)));
        V v_t_24510 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str116), heff_strAppend(v_x_24503, v_t_24509));
        V v_t_24511 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str117), heff_strAppend(v_x_24499, v_t_24510));
        return heff_tag_at_n(v_ru_24x2_24498_24MkPair, TAG_MkPair, 2, (V[]){v_t_24511, v_s_24508});
      }
      default: return heff_nomatch(v_x2_24506);
      }
    }
    default: return heff_nomatch(v_x2_24502);
    }
  }
  default: return heff_nomatch(v_x2_24498);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args) {
  V v_s_24515 = args[0];
  V v_m_24514 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24516 = heff_tr(heff_call(v_m_24514, 1, (V[]){v_s_24515}));
  switch (heff_tag_of(v_x2_24516)) {
  case TAG_MkPair: {
    V v_x_24517 = heff_field(v_x2_24516, 0);
    V v_s_24518 = heff_field(v_x2_24516, 1);
    V v_ru_24x2_24516_24MkPair = heff_take_reuse_n(v_x2_24516, 3ULL, 2);
    V v_m_24519 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24520 = heff_tr(heff_call(v_m_24519, 1, (V[]){v_s_24518}));
    switch (heff_tag_of(v_x2_24520)) {
    case TAG_MkPair: {
      V v_x_24521 = heff_field(v_x2_24520, 0);
      V v_s_24522 = heff_field(v_x2_24520, 1);
      heff_take_n(v_x2_24520, 3ULL, 2);
      V v_m_24523 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24524 = heff_tr(heff_call(v_m_24523, 1, (V[]){v_s_24522}));
      switch (heff_tag_of(v_x2_24524)) {
      case TAG_MkPair: {
        V v_x_24525 = heff_field(v_x2_24524, 0);
        V v_s_24526 = heff_field(v_x2_24524, 1);
        heff_take_n(v_x2_24524, 3ULL, 2);
        V v_t_24527 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str118), heff_strAppend(v_x_24525, ((V)&g_heff_2ecompile_2eemitc_2etestC_str119)));
        V v_t_24528 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str120), heff_strAppend(v_x_24521, v_t_24527));
        V v_t_24529 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str121), heff_strAppend(v_x_24517, v_t_24528));
        return heff_tag_at_n(v_ru_24x2_24516_24MkPair, TAG_MkPair, 2, (V[]){v_t_24529, v_s_24526});
      }
      default: return heff_nomatch(v_x2_24524);
      }
    }
    default: return heff_nomatch(v_x2_24520);
    }
  }
  default: return heff_nomatch(v_x2_24516);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args) {
  V v_s_24532 = args[0];
  V v_m_24531 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24533 = heff_tr(heff_call(v_m_24531, 1, (V[]){v_s_24532}));
  switch (heff_tag_of(v_x2_24533)) {
  case TAG_MkPair: {
    V v_x_24534 = heff_field(v_x2_24533, 0);
    V v_s_24535 = heff_field(v_x2_24533, 1);
    V v_ru_24x2_24533_24MkPair = heff_take_reuse_n(v_x2_24533, 3ULL, 2);
    V v_m_24536 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24537 = heff_tr(heff_call(v_m_24536, 1, (V[]){v_s_24535}));
    switch (heff_tag_of(v_x2_24537)) {
    case TAG_MkPair: {
      V v_x_24538 = heff_field(v_x2_24537, 0);
      V v_s_24539 = heff_field(v_x2_24537, 1);
      heff_take_n(v_x2_24537, 3ULL, 2);
      V v_m_24540 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24541 = heff_tr(heff_call(v_m_24540, 1, (V[]){v_s_24539}));
      switch (heff_tag_of(v_x2_24541)) {
      case TAG_MkPair: {
        V v_x_24542 = heff_field(v_x2_24541, 0);
        V v_s_24543 = heff_field(v_x2_24541, 1);
        heff_take_n(v_x2_24541, 3ULL, 2);
        V v_t_24544 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str122), heff_strAppend(v_x_24542, ((V)&g_heff_2ecompile_2eemitc_2etestC_str123)));
        V v_t_24545 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str124), heff_strAppend(v_x_24538, v_t_24544));
        V v_t_24546 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str125), heff_strAppend(v_x_24534, v_t_24545));
        return heff_tag_at_n(v_ru_24x2_24533_24MkPair, TAG_MkPair, 2, (V[]){v_t_24546, v_s_24543});
      }
      default: return heff_nomatch(v_x2_24541);
      }
    }
    default: return heff_nomatch(v_x2_24537);
    }
  }
  default: return heff_nomatch(v_x2_24533);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args) {
  V v_s_24549 = args[0];
  V v_m_24548 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24550 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_s_24549}));
  switch (heff_tag_of(v_x2_24550)) {
  case TAG_MkPair: {
    V v_x_24551 = heff_field(v_x2_24550, 0);
    V v_s_24552 = heff_field(v_x2_24550, 1);
    V v_ru_24x2_24550_24MkPair = heff_take_reuse_n(v_x2_24550, 3ULL, 2);
    V v_m_24553 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24554 = heff_tr(heff_call(v_m_24553, 1, (V[]){v_s_24552}));
    switch (heff_tag_of(v_x2_24554)) {
    case TAG_MkPair: {
      V v_x_24555 = heff_field(v_x2_24554, 0);
      V v_s_24556 = heff_field(v_x2_24554, 1);
      heff_take_n(v_x2_24554, 3ULL, 2);
      V v_m_24557 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24558 = heff_tr(heff_call(v_m_24557, 1, (V[]){v_s_24556}));
      switch (heff_tag_of(v_x2_24558)) {
      case TAG_MkPair: {
        V v_x_24559 = heff_field(v_x2_24558, 0);
        V v_s_24560 = heff_field(v_x2_24558, 1);
        heff_take_n(v_x2_24558, 3ULL, 2);
        V v_t_24561 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str126), heff_strAppend(v_x_24559, ((V)&g_heff_2ecompile_2eemitc_2etestC_str127)));
        V v_t_24562 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str128), heff_strAppend(v_x_24555, v_t_24561));
        V v_t_24563 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str129), heff_strAppend(v_x_24551, v_t_24562));
        return heff_tag_at_n(v_ru_24x2_24550_24MkPair, TAG_MkPair, 2, (V[]){v_t_24563, v_s_24560});
      }
      default: return heff_nomatch(v_x2_24558);
      }
    }
    default: return heff_nomatch(v_x2_24554);
    }
  }
  default: return heff_nomatch(v_x2_24550);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args) {
  V v_s_24568 = args[0];
  V v_m_24567 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24569 = heff_tr(heff_call(v_m_24567, 1, (V[]){v_s_24568}));
  switch (heff_tag_of(v_x2_24569)) {
  case TAG_MkPair: {
    V v_x_24570 = heff_field(v_x2_24569, 0);
    V v_s_24571 = heff_field(v_x2_24569, 1);
    V v_ru_24x2_24569_24MkPair = heff_take_reuse_n(v_x2_24569, 3ULL, 2);
    V v_m_24572 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24573 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_s_24571}));
    switch (heff_tag_of(v_x2_24573)) {
    case TAG_MkPair: {
      V v_x_24574 = heff_field(v_x2_24573, 0);
      V v_s_24575 = heff_field(v_x2_24573, 1);
      heff_take_n(v_x2_24573, 3ULL, 2);
      V v_m_24576 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24577 = heff_tr(heff_call(v_m_24576, 1, (V[]){v_s_24575}));
      switch (heff_tag_of(v_x2_24577)) {
      case TAG_MkPair: {
        V v_x_24578 = heff_field(v_x2_24577, 0);
        V v_s_24579 = heff_field(v_x2_24577, 1);
        heff_take_n(v_x2_24577, 3ULL, 2);
        V v_t_24580 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str130), heff_strAppend(v_x_24578, ((V)&g_heff_2ecompile_2eemitc_2etestC_str131)));
        V v_t_24581 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str132), heff_strAppend(v_x_24574, v_t_24580));
        V v_t_24582 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str133), heff_strAppend(v_x_24570, v_t_24581));
        return heff_tag_at_n(v_ru_24x2_24569_24MkPair, TAG_MkPair, 2, (V[]){v_t_24582, v_s_24579});
      }
      default: return heff_nomatch(v_x2_24577);
      }
    }
    default: return heff_nomatch(v_x2_24573);
    }
  }
  default: return heff_nomatch(v_x2_24569);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args) {
  V v_s_24588 = args[0];
  V v_m_24587 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24589 = heff_tr(heff_call(v_m_24587, 1, (V[]){v_s_24588}));
  switch (heff_tag_of(v_x2_24589)) {
  case TAG_MkPair: {
    V v_x_24590 = heff_field(v_x2_24589, 0);
    V v_s_24591 = heff_field(v_x2_24589, 1);
    V v_ru_24x2_24589_24MkPair = heff_take_reuse_n(v_x2_24589, 3ULL, 2);
    V v_m_24592 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24593 = heff_tr(heff_call(v_m_24592, 1, (V[]){v_s_24591}));
    switch (heff_tag_of(v_x2_24593)) {
    case TAG_MkPair: {
      V v_x_24594 = heff_field(v_x2_24593, 0);
      V v_s_24595 = heff_field(v_x2_24593, 1);
      heff_take_n(v_x2_24593, 3ULL, 2);
      V v_m_24596 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24597 = heff_tr(heff_call(v_m_24596, 1, (V[]){v_s_24595}));
      switch (heff_tag_of(v_x2_24597)) {
      case TAG_MkPair: {
        V v_x_24598 = heff_field(v_x2_24597, 0);
        V v_s_24599 = heff_field(v_x2_24597, 1);
        heff_take_n(v_x2_24597, 3ULL, 2);
        V v_t_24600 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str134), heff_strAppend(v_x_24598, ((V)&g_heff_2ecompile_2eemitc_2etestC_str135)));
        V v_t_24601 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str136), heff_strAppend(v_x_24594, v_t_24600));
        V v_t_24602 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str137), heff_strAppend(v_x_24590, v_t_24601));
        return heff_tag_at_n(v_ru_24x2_24589_24MkPair, TAG_MkPair, 2, (V[]){v_t_24602, v_s_24599});
      }
      default: return heff_nomatch(v_x2_24597);
      }
    }
    default: return heff_nomatch(v_x2_24593);
    }
  }
  default: return heff_nomatch(v_x2_24589);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args) {
  V v_s_24605 = args[0];
  V v_m_24604 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24606 = heff_tr(heff_call(v_m_24604, 1, (V[]){v_s_24605}));
  switch (heff_tag_of(v_x2_24606)) {
  case TAG_MkPair: {
    V v_x_24607 = heff_field(v_x2_24606, 0);
    V v_s_24608 = heff_field(v_x2_24606, 1);
    V v_ru_24x2_24606_24MkPair = heff_take_reuse_n(v_x2_24606, 3ULL, 2);
    V v_m_24609 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24610 = heff_tr(heff_call(v_m_24609, 1, (V[]){v_s_24608}));
    switch (heff_tag_of(v_x2_24610)) {
    case TAG_MkPair: {
      V v_x_24611 = heff_field(v_x2_24610, 0);
      V v_s_24612 = heff_field(v_x2_24610, 1);
      heff_take_n(v_x2_24610, 3ULL, 2);
      V v_t_24613 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str138), heff_strAppend(v_x_24611, ((V)&g_heff_2ecompile_2eemitc_2etestC_str139)));
      V v_t_24614 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str140), heff_strAppend(v_x_24607, v_t_24613));
      return heff_tag_at_n(v_ru_24x2_24606_24MkPair, TAG_MkPair, 2, (V[]){v_t_24614, v_s_24612});
    }
    default: return heff_nomatch(v_x2_24610);
    }
  }
  default: return heff_nomatch(v_x2_24606);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args) {
  V v_s_24616 = args[0];
  V v_m_24615 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24617 = heff_tr(heff_call(v_m_24615, 1, (V[]){v_s_24616}));
  switch (heff_tag_of(v_x2_24617)) {
  case TAG_MkPair: {
    V v_x_24618 = heff_field(v_x2_24617, 0);
    V v_s_24619 = heff_field(v_x2_24617, 1);
    V v_ru_24x2_24617_24MkPair = heff_take_reuse_n(v_x2_24617, 3ULL, 2);
    V v_m_24620 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24621 = heff_tr(heff_call(v_m_24620, 1, (V[]){v_s_24619}));
    switch (heff_tag_of(v_x2_24621)) {
    case TAG_MkPair: {
      V v_x_24622 = heff_field(v_x2_24621, 0);
      V v_s_24623 = heff_field(v_x2_24621, 1);
      heff_take_n(v_x2_24621, 3ULL, 2);
      V v_m_24624 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24625 = heff_tr(heff_call(v_m_24624, 1, (V[]){v_s_24623}));
      switch (heff_tag_of(v_x2_24625)) {
      case TAG_MkPair: {
        V v_x_24626 = heff_field(v_x2_24625, 0);
        V v_s_24627 = heff_field(v_x2_24625, 1);
        heff_take_n(v_x2_24625, 3ULL, 2);
        V v_t_24628 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str141), heff_strAppend(v_x_24626, ((V)&g_heff_2ecompile_2eemitc_2etestC_str142)));
        V v_t_24629 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str143), heff_strAppend(v_x_24622, v_t_24628));
        V v_t_24630 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str144), heff_strAppend(v_x_24618, v_t_24629));
        return heff_tag_at_n(v_ru_24x2_24617_24MkPair, TAG_MkPair, 2, (V[]){v_t_24630, v_s_24627});
      }
      default: return heff_nomatch(v_x2_24625);
      }
    }
    default: return heff_nomatch(v_x2_24621);
    }
  }
  default: return heff_nomatch(v_x2_24617);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args) {
  V v_s_24634 = args[0];
  V v_m_24633 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24635 = heff_tr(heff_call(v_m_24633, 1, (V[]){v_s_24634}));
  switch (heff_tag_of(v_x2_24635)) {
  case TAG_MkPair: {
    V v_x_24636 = heff_field(v_x2_24635, 0);
    V v_s_24637 = heff_field(v_x2_24635, 1);
    V v_ru_24x2_24635_24MkPair = heff_take_reuse_n(v_x2_24635, 3ULL, 2);
    V v_m_24638 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24639 = heff_tr(heff_call(v_m_24638, 1, (V[]){v_s_24637}));
    switch (heff_tag_of(v_x2_24639)) {
    case TAG_MkPair: {
      V v_x_24640 = heff_field(v_x2_24639, 0);
      V v_s_24641 = heff_field(v_x2_24639, 1);
      heff_take_n(v_x2_24639, 3ULL, 2);
      V v_m_24642 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24643 = heff_tr(heff_call(v_m_24642, 1, (V[]){v_s_24641}));
      switch (heff_tag_of(v_x2_24643)) {
      case TAG_MkPair: {
        V v_x_24644 = heff_field(v_x2_24643, 0);
        V v_s_24645 = heff_field(v_x2_24643, 1);
        heff_take_n(v_x2_24643, 3ULL, 2);
        V v_t_24646 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str145), heff_strAppend(v_x_24644, ((V)&g_heff_2ecompile_2eemitc_2etestC_str146)));
        V v_t_24647 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str147), heff_strAppend(v_x_24640, v_t_24646));
        V v_t_24648 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str148), heff_strAppend(v_x_24636, v_t_24647));
        return heff_tag_at_n(v_ru_24x2_24635_24MkPair, TAG_MkPair, 2, (V[]){v_t_24648, v_s_24645});
      }
      default: return heff_nomatch(v_x2_24643);
      }
    }
    default: return heff_nomatch(v_x2_24639);
    }
  }
  default: return heff_nomatch(v_x2_24635);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args) {
  V v_s_24652 = args[0];
  V v_m_24651 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24653 = heff_tr(heff_call(v_m_24651, 1, (V[]){v_s_24652}));
  switch (heff_tag_of(v_x2_24653)) {
  case TAG_MkPair: {
    V v_x_24654 = heff_field(v_x2_24653, 0);
    V v_s_24655 = heff_field(v_x2_24653, 1);
    V v_ru_24x2_24653_24MkPair = heff_take_reuse_n(v_x2_24653, 3ULL, 2);
    V v_m_24656 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24657 = heff_tr(heff_call(v_m_24656, 1, (V[]){v_s_24655}));
    switch (heff_tag_of(v_x2_24657)) {
    case TAG_MkPair: {
      V v_x_24658 = heff_field(v_x2_24657, 0);
      V v_s_24659 = heff_field(v_x2_24657, 1);
      heff_take_n(v_x2_24657, 3ULL, 2);
      V v_m_24660 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24661 = heff_tr(heff_call(v_m_24660, 1, (V[]){v_s_24659}));
      switch (heff_tag_of(v_x2_24661)) {
      case TAG_MkPair: {
        V v_x_24662 = heff_field(v_x2_24661, 0);
        V v_s_24663 = heff_field(v_x2_24661, 1);
        heff_take_n(v_x2_24661, 3ULL, 2);
        V v_t_24664 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str149), heff_strAppend(v_x_24662, ((V)&g_heff_2ecompile_2eemitc_2etestC_str150)));
        V v_t_24665 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str151), heff_strAppend(v_x_24658, v_t_24664));
        V v_t_24666 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str152), heff_strAppend(v_x_24654, v_t_24665));
        return heff_tag_at_n(v_ru_24x2_24653_24MkPair, TAG_MkPair, 2, (V[]){v_t_24666, v_s_24663});
      }
      default: return heff_nomatch(v_x2_24661);
      }
    }
    default: return heff_nomatch(v_x2_24657);
    }
  }
  default: return heff_nomatch(v_x2_24653);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args) {
  V v_s_24669 = args[0];
  V v_m_24668 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24670 = heff_tr(heff_call(v_m_24668, 1, (V[]){v_s_24669}));
  switch (heff_tag_of(v_x2_24670)) {
  case TAG_MkPair: {
    V v_x_24671 = heff_field(v_x2_24670, 0);
    V v_s_24672 = heff_field(v_x2_24670, 1);
    V v_ru_24x2_24670_24MkPair = heff_take_reuse_n(v_x2_24670, 3ULL, 2);
    V v_m_24673 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24674 = heff_tr(heff_call(v_m_24673, 1, (V[]){v_s_24672}));
    switch (heff_tag_of(v_x2_24674)) {
    case TAG_MkPair: {
      V v_x_24675 = heff_field(v_x2_24674, 0);
      V v_s_24676 = heff_field(v_x2_24674, 1);
      heff_take_n(v_x2_24674, 3ULL, 2);
      V v_m_24677 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24678 = heff_tr(heff_call(v_m_24677, 1, (V[]){v_s_24676}));
      switch (heff_tag_of(v_x2_24678)) {
      case TAG_MkPair: {
        V v_x_24679 = heff_field(v_x2_24678, 0);
        V v_s_24680 = heff_field(v_x2_24678, 1);
        heff_take_n(v_x2_24678, 3ULL, 2);
        V v_t_24681 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str153), heff_strAppend(v_x_24679, ((V)&g_heff_2ecompile_2eemitc_2etestC_str154)));
        V v_t_24682 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str155), heff_strAppend(v_x_24675, v_t_24681));
        V v_t_24683 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str156), heff_strAppend(v_x_24671, v_t_24682));
        return heff_tag_at_n(v_ru_24x2_24670_24MkPair, TAG_MkPair, 2, (V[]){v_t_24683, v_s_24680});
      }
      default: return heff_nomatch(v_x2_24678);
      }
    }
    default: return heff_nomatch(v_x2_24674);
    }
  }
  default: return heff_nomatch(v_x2_24670);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args) {
  V v_s_24686 = args[0];
  V v_m_24685 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24687 = heff_tr(heff_call(v_m_24685, 1, (V[]){v_s_24686}));
  switch (heff_tag_of(v_x2_24687)) {
  case TAG_MkPair: {
    V v_x_24688 = heff_field(v_x2_24687, 0);
    V v_s_24689 = heff_field(v_x2_24687, 1);
    V v_ru_24x2_24687_24MkPair = heff_take_reuse_n(v_x2_24687, 3ULL, 2);
    V v_m_24690 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24691 = heff_tr(heff_call(v_m_24690, 1, (V[]){v_s_24689}));
    switch (heff_tag_of(v_x2_24691)) {
    case TAG_MkPair: {
      V v_x_24692 = heff_field(v_x2_24691, 0);
      V v_s_24693 = heff_field(v_x2_24691, 1);
      heff_take_n(v_x2_24691, 3ULL, 2);
      V v_m_24694 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24695 = heff_tr(heff_call(v_m_24694, 1, (V[]){v_s_24693}));
      switch (heff_tag_of(v_x2_24695)) {
      case TAG_MkPair: {
        V v_x_24696 = heff_field(v_x2_24695, 0);
        V v_s_24697 = heff_field(v_x2_24695, 1);
        heff_take_n(v_x2_24695, 3ULL, 2);
        V v_t_24698 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str157), heff_strAppend(v_x_24696, ((V)&g_heff_2ecompile_2eemitc_2etestC_str158)));
        V v_t_24699 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str159), heff_strAppend(v_x_24692, v_t_24698));
        V v_t_24700 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str160), heff_strAppend(v_x_24688, v_t_24699));
        return heff_tag_at_n(v_ru_24x2_24687_24MkPair, TAG_MkPair, 2, (V[]){v_t_24700, v_s_24697});
      }
      default: return heff_nomatch(v_x2_24695);
      }
    }
    default: return heff_nomatch(v_x2_24691);
    }
  }
  default: return heff_nomatch(v_x2_24687);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args) {
  V v_s_24705 = args[0];
  V v_m_24704 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24706 = heff_tr(heff_call(v_m_24704, 1, (V[]){v_s_24705}));
  switch (heff_tag_of(v_x2_24706)) {
  case TAG_MkPair: {
    V v_x_24707 = heff_field(v_x2_24706, 0);
    V v_s_24708 = heff_field(v_x2_24706, 1);
    V v_ru_24x2_24706_24MkPair = heff_take_reuse_n(v_x2_24706, 3ULL, 2);
    V v_m_24709 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24710 = heff_tr(heff_call(v_m_24709, 1, (V[]){v_s_24708}));
    switch (heff_tag_of(v_x2_24710)) {
    case TAG_MkPair: {
      V v_x_24711 = heff_field(v_x2_24710, 0);
      V v_s_24712 = heff_field(v_x2_24710, 1);
      heff_take_n(v_x2_24710, 3ULL, 2);
      V v_m_24713 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24714 = heff_tr(heff_call(v_m_24713, 1, (V[]){v_s_24712}));
      switch (heff_tag_of(v_x2_24714)) {
      case TAG_MkPair: {
        V v_x_24715 = heff_field(v_x2_24714, 0);
        V v_s_24716 = heff_field(v_x2_24714, 1);
        heff_take_n(v_x2_24714, 3ULL, 2);
        V v_t_24717 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str161), heff_strAppend(v_x_24715, ((V)&g_heff_2ecompile_2eemitc_2etestC_str162)));
        V v_t_24718 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str163), heff_strAppend(v_x_24711, v_t_24717));
        V v_t_24719 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str164), heff_strAppend(v_x_24707, v_t_24718));
        return heff_tag_at_n(v_ru_24x2_24706_24MkPair, TAG_MkPair, 2, (V[]){v_t_24719, v_s_24716});
      }
      default: return heff_nomatch(v_x2_24714);
      }
    }
    default: return heff_nomatch(v_x2_24710);
    }
  }
  default: return heff_nomatch(v_x2_24706);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args) {
  V v_s_24725 = args[0];
  V v_m_24724 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24726 = heff_tr(heff_call(v_m_24724, 1, (V[]){v_s_24725}));
  switch (heff_tag_of(v_x2_24726)) {
  case TAG_MkPair: {
    V v_x_24727 = heff_field(v_x2_24726, 0);
    V v_s_24728 = heff_field(v_x2_24726, 1);
    V v_ru_24x2_24726_24MkPair = heff_take_reuse_n(v_x2_24726, 3ULL, 2);
    V v_m_24729 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24730 = heff_tr(heff_call(v_m_24729, 1, (V[]){v_s_24728}));
    switch (heff_tag_of(v_x2_24730)) {
    case TAG_MkPair: {
      V v_x_24731 = heff_field(v_x2_24730, 0);
      V v_s_24732 = heff_field(v_x2_24730, 1);
      heff_take_n(v_x2_24730, 3ULL, 2);
      V v_m_24733 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24734 = heff_tr(heff_call(v_m_24733, 1, (V[]){v_s_24732}));
      switch (heff_tag_of(v_x2_24734)) {
      case TAG_MkPair: {
        V v_x_24735 = heff_field(v_x2_24734, 0);
        V v_s_24736 = heff_field(v_x2_24734, 1);
        heff_take_n(v_x2_24734, 3ULL, 2);
        V v_t_24737 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str165), heff_strAppend(v_x_24735, ((V)&g_heff_2ecompile_2eemitc_2etestC_str166)));
        V v_t_24738 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str167), heff_strAppend(v_x_24731, v_t_24737));
        V v_t_24739 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str168), heff_strAppend(v_x_24727, v_t_24738));
        return heff_tag_at_n(v_ru_24x2_24726_24MkPair, TAG_MkPair, 2, (V[]){v_t_24739, v_s_24736});
      }
      default: return heff_nomatch(v_x2_24734);
      }
    }
    default: return heff_nomatch(v_x2_24730);
    }
  }
  default: return heff_nomatch(v_x2_24726);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args) {
  V v_s_24744 = args[0];
  V v_m_24743 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24745 = heff_tr(heff_call(v_m_24743, 1, (V[]){v_s_24744}));
  switch (heff_tag_of(v_x2_24745)) {
  case TAG_MkPair: {
    V v_x_24746 = heff_field(v_x2_24745, 0);
    V v_s_24747 = heff_field(v_x2_24745, 1);
    V v_ru_24x2_24745_24MkPair = heff_take_reuse_n(v_x2_24745, 3ULL, 2);
    V v_m_24748 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24749 = heff_tr(heff_call(v_m_24748, 1, (V[]){v_s_24747}));
    switch (heff_tag_of(v_x2_24749)) {
    case TAG_MkPair: {
      V v_x_24750 = heff_field(v_x2_24749, 0);
      V v_s_24751 = heff_field(v_x2_24749, 1);
      heff_take_n(v_x2_24749, 3ULL, 2);
      V v_t_24752 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str169), heff_strAppend(v_x_24750, ((V)&g_heff_2ecompile_2eemitc_2etestC_str170)));
      V v_t_24753 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str171), heff_strAppend(v_x_24746, v_t_24752));
      return heff_tag_at_n(v_ru_24x2_24745_24MkPair, TAG_MkPair, 2, (V[]){v_t_24753, v_s_24751});
    }
    default: return heff_nomatch(v_x2_24749);
    }
  }
  default: return heff_nomatch(v_x2_24745);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args) {
  V v_s_24755 = args[0];
  V v_m_24754 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24756 = heff_tr(heff_call(v_m_24754, 1, (V[]){v_s_24755}));
  switch (heff_tag_of(v_x2_24756)) {
  case TAG_MkPair: {
    V v_x_24757 = heff_field(v_x2_24756, 0);
    V v_s_24758 = heff_field(v_x2_24756, 1);
    V v_ru_24x2_24756_24MkPair = heff_take_reuse_n(v_x2_24756, 3ULL, 2);
    V v_m_24759 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24760 = heff_tr(heff_call(v_m_24759, 1, (V[]){v_s_24758}));
    switch (heff_tag_of(v_x2_24760)) {
    case TAG_MkPair: {
      V v_x_24761 = heff_field(v_x2_24760, 0);
      V v_s_24762 = heff_field(v_x2_24760, 1);
      heff_take_n(v_x2_24760, 3ULL, 2);
      V v_m_24763 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24764 = heff_tr(heff_call(v_m_24763, 1, (V[]){v_s_24762}));
      switch (heff_tag_of(v_x2_24764)) {
      case TAG_MkPair: {
        V v_x_24765 = heff_field(v_x2_24764, 0);
        V v_s_24766 = heff_field(v_x2_24764, 1);
        heff_take_n(v_x2_24764, 3ULL, 2);
        V v_t_24767 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str172), heff_strAppend(v_x_24765, ((V)&g_heff_2ecompile_2eemitc_2etestC_str173)));
        V v_t_24768 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str174), heff_strAppend(v_x_24761, v_t_24767));
        V v_t_24769 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str175), heff_strAppend(v_x_24757, v_t_24768));
        return heff_tag_at_n(v_ru_24x2_24756_24MkPair, TAG_MkPair, 2, (V[]){v_t_24769, v_s_24766});
      }
      default: return heff_nomatch(v_x2_24764);
      }
    }
    default: return heff_nomatch(v_x2_24760);
    }
  }
  default: return heff_nomatch(v_x2_24756);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args) {
  V v_s_24773 = args[0];
  V v_m_24772 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24774 = heff_tr(heff_call(v_m_24772, 1, (V[]){v_s_24773}));
  switch (heff_tag_of(v_x2_24774)) {
  case TAG_MkPair: {
    V v_x_24775 = heff_field(v_x2_24774, 0);
    V v_s_24776 = heff_field(v_x2_24774, 1);
    V v_ru_24x2_24774_24MkPair = heff_take_reuse_n(v_x2_24774, 3ULL, 2);
    V v_m_24777 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24778 = heff_tr(heff_call(v_m_24777, 1, (V[]){v_s_24776}));
    switch (heff_tag_of(v_x2_24778)) {
    case TAG_MkPair: {
      V v_x_24779 = heff_field(v_x2_24778, 0);
      V v_s_24780 = heff_field(v_x2_24778, 1);
      heff_take_n(v_x2_24778, 3ULL, 2);
      V v_m_24781 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24782 = heff_tr(heff_call(v_m_24781, 1, (V[]){v_s_24780}));
      switch (heff_tag_of(v_x2_24782)) {
      case TAG_MkPair: {
        V v_x_24783 = heff_field(v_x2_24782, 0);
        V v_s_24784 = heff_field(v_x2_24782, 1);
        heff_take_n(v_x2_24782, 3ULL, 2);
        V v_t_24785 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str176), heff_strAppend(v_x_24783, ((V)&g_heff_2ecompile_2eemitc_2etestC_str177)));
        V v_t_24786 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str178), heff_strAppend(v_x_24779, v_t_24785));
        V v_t_24787 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str179), heff_strAppend(v_x_24775, v_t_24786));
        return heff_tag_at_n(v_ru_24x2_24774_24MkPair, TAG_MkPair, 2, (V[]){v_t_24787, v_s_24784});
      }
      default: return heff_nomatch(v_x2_24782);
      }
    }
    default: return heff_nomatch(v_x2_24778);
    }
  }
  default: return heff_nomatch(v_x2_24774);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args) {
  V v_s_24791 = args[0];
  V v_m_24790 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24792 = heff_tr(heff_call(v_m_24790, 1, (V[]){v_s_24791}));
  switch (heff_tag_of(v_x2_24792)) {
  case TAG_MkPair: {
    V v_x_24793 = heff_field(v_x2_24792, 0);
    V v_s_24794 = heff_field(v_x2_24792, 1);
    V v_ru_24x2_24792_24MkPair = heff_take_reuse_n(v_x2_24792, 3ULL, 2);
    V v_m_24795 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24796 = heff_tr(heff_call(v_m_24795, 1, (V[]){v_s_24794}));
    switch (heff_tag_of(v_x2_24796)) {
    case TAG_MkPair: {
      V v_x_24797 = heff_field(v_x2_24796, 0);
      V v_s_24798 = heff_field(v_x2_24796, 1);
      heff_take_n(v_x2_24796, 3ULL, 2);
      V v_m_24799 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24800 = heff_tr(heff_call(v_m_24799, 1, (V[]){v_s_24798}));
      switch (heff_tag_of(v_x2_24800)) {
      case TAG_MkPair: {
        V v_x_24801 = heff_field(v_x2_24800, 0);
        V v_s_24802 = heff_field(v_x2_24800, 1);
        heff_take_n(v_x2_24800, 3ULL, 2);
        V v_t_24803 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str180), heff_strAppend(v_x_24801, ((V)&g_heff_2ecompile_2eemitc_2etestC_str181)));
        V v_t_24804 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str182), heff_strAppend(v_x_24797, v_t_24803));
        V v_t_24805 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str183), heff_strAppend(v_x_24793, v_t_24804));
        return heff_tag_at_n(v_ru_24x2_24792_24MkPair, TAG_MkPair, 2, (V[]){v_t_24805, v_s_24802});
      }
      default: return heff_nomatch(v_x2_24800);
      }
    }
    default: return heff_nomatch(v_x2_24796);
    }
  }
  default: return heff_nomatch(v_x2_24792);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args) {
  V v_s_24808 = args[0];
  V v_m_24807 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24809 = heff_tr(heff_call(v_m_24807, 1, (V[]){v_s_24808}));
  switch (heff_tag_of(v_x2_24809)) {
  case TAG_MkPair: {
    V v_x_24810 = heff_field(v_x2_24809, 0);
    V v_s_24811 = heff_field(v_x2_24809, 1);
    V v_ru_24x2_24809_24MkPair = heff_take_reuse_n(v_x2_24809, 3ULL, 2);
    V v_m_24812 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24813 = heff_tr(heff_call(v_m_24812, 1, (V[]){v_s_24811}));
    switch (heff_tag_of(v_x2_24813)) {
    case TAG_MkPair: {
      V v_x_24814 = heff_field(v_x2_24813, 0);
      V v_s_24815 = heff_field(v_x2_24813, 1);
      heff_take_n(v_x2_24813, 3ULL, 2);
      V v_m_24816 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24817 = heff_tr(heff_call(v_m_24816, 1, (V[]){v_s_24815}));
      switch (heff_tag_of(v_x2_24817)) {
      case TAG_MkPair: {
        V v_x_24818 = heff_field(v_x2_24817, 0);
        V v_s_24819 = heff_field(v_x2_24817, 1);
        heff_take_n(v_x2_24817, 3ULL, 2);
        V v_t_24820 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str184), heff_strAppend(v_x_24818, ((V)&g_heff_2ecompile_2eemitc_2etestC_str185)));
        V v_t_24821 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str186), heff_strAppend(v_x_24814, v_t_24820));
        V v_t_24822 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str187), heff_strAppend(v_x_24810, v_t_24821));
        return heff_tag_at_n(v_ru_24x2_24809_24MkPair, TAG_MkPair, 2, (V[]){v_t_24822, v_s_24819});
      }
      default: return heff_nomatch(v_x2_24817);
      }
    }
    default: return heff_nomatch(v_x2_24813);
    }
  }
  default: return heff_nomatch(v_x2_24809);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args) {
  V v_s_24825 = args[0];
  V v_m_24824 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24826 = heff_tr(heff_call(v_m_24824, 1, (V[]){v_s_24825}));
  switch (heff_tag_of(v_x2_24826)) {
  case TAG_MkPair: {
    V v_x_24827 = heff_field(v_x2_24826, 0);
    V v_s_24828 = heff_field(v_x2_24826, 1);
    V v_ru_24x2_24826_24MkPair = heff_take_reuse_n(v_x2_24826, 3ULL, 2);
    V v_m_24829 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24830 = heff_tr(heff_call(v_m_24829, 1, (V[]){v_s_24828}));
    switch (heff_tag_of(v_x2_24830)) {
    case TAG_MkPair: {
      V v_x_24831 = heff_field(v_x2_24830, 0);
      V v_s_24832 = heff_field(v_x2_24830, 1);
      heff_take_n(v_x2_24830, 3ULL, 2);
      V v_m_24833 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24834 = heff_tr(heff_call(v_m_24833, 1, (V[]){v_s_24832}));
      switch (heff_tag_of(v_x2_24834)) {
      case TAG_MkPair: {
        V v_x_24835 = heff_field(v_x2_24834, 0);
        V v_s_24836 = heff_field(v_x2_24834, 1);
        heff_take_n(v_x2_24834, 3ULL, 2);
        V v_t_24837 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str188), heff_strAppend(v_x_24835, ((V)&g_heff_2ecompile_2eemitc_2etestC_str189)));
        V v_t_24838 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str190), heff_strAppend(v_x_24831, v_t_24837));
        V v_t_24839 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str191), heff_strAppend(v_x_24827, v_t_24838));
        return heff_tag_at_n(v_ru_24x2_24826_24MkPair, TAG_MkPair, 2, (V[]){v_t_24839, v_s_24836});
      }
      default: return heff_nomatch(v_x2_24834);
      }
    }
    default: return heff_nomatch(v_x2_24830);
    }
  }
  default: return heff_nomatch(v_x2_24826);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args) {
  V v_s_24844 = args[0];
  V v_m_24843 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24845 = heff_tr(heff_call(v_m_24843, 1, (V[]){v_s_24844}));
  switch (heff_tag_of(v_x2_24845)) {
  case TAG_MkPair: {
    V v_x_24846 = heff_field(v_x2_24845, 0);
    V v_s_24847 = heff_field(v_x2_24845, 1);
    V v_ru_24x2_24845_24MkPair = heff_take_reuse_n(v_x2_24845, 3ULL, 2);
    V v_m_24848 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24849 = heff_tr(heff_call(v_m_24848, 1, (V[]){v_s_24847}));
    switch (heff_tag_of(v_x2_24849)) {
    case TAG_MkPair: {
      V v_x_24850 = heff_field(v_x2_24849, 0);
      V v_s_24851 = heff_field(v_x2_24849, 1);
      heff_take_n(v_x2_24849, 3ULL, 2);
      V v_m_24852 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24853 = heff_tr(heff_call(v_m_24852, 1, (V[]){v_s_24851}));
      switch (heff_tag_of(v_x2_24853)) {
      case TAG_MkPair: {
        V v_x_24854 = heff_field(v_x2_24853, 0);
        V v_s_24855 = heff_field(v_x2_24853, 1);
        heff_take_n(v_x2_24853, 3ULL, 2);
        V v_t_24856 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str192), heff_strAppend(v_x_24854, ((V)&g_heff_2ecompile_2eemitc_2etestC_str193)));
        V v_t_24857 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str194), heff_strAppend(v_x_24850, v_t_24856));
        V v_t_24858 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str195), heff_strAppend(v_x_24846, v_t_24857));
        return heff_tag_at_n(v_ru_24x2_24845_24MkPair, TAG_MkPair, 2, (V[]){v_t_24858, v_s_24855});
      }
      default: return heff_nomatch(v_x2_24853);
      }
    }
    default: return heff_nomatch(v_x2_24849);
    }
  }
  default: return heff_nomatch(v_x2_24845);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args) {
  V v_s_24864 = args[0];
  V v_m_24863 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24865 = heff_tr(heff_call(v_m_24863, 1, (V[]){v_s_24864}));
  switch (heff_tag_of(v_x2_24865)) {
  case TAG_MkPair: {
    V v_x_24866 = heff_field(v_x2_24865, 0);
    V v_s_24867 = heff_field(v_x2_24865, 1);
    V v_ru_24x2_24865_24MkPair = heff_take_reuse_n(v_x2_24865, 3ULL, 2);
    V v_m_24868 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24869 = heff_tr(heff_call(v_m_24868, 1, (V[]){v_s_24867}));
    switch (heff_tag_of(v_x2_24869)) {
    case TAG_MkPair: {
      V v_x_24870 = heff_field(v_x2_24869, 0);
      V v_s_24871 = heff_field(v_x2_24869, 1);
      heff_take_n(v_x2_24869, 3ULL, 2);
      V v_m_24872 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24873 = heff_tr(heff_call(v_m_24872, 1, (V[]){v_s_24871}));
      switch (heff_tag_of(v_x2_24873)) {
      case TAG_MkPair: {
        V v_x_24874 = heff_field(v_x2_24873, 0);
        V v_s_24875 = heff_field(v_x2_24873, 1);
        heff_take_n(v_x2_24873, 3ULL, 2);
        V v_t_24876 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str196), heff_strAppend(v_x_24874, ((V)&g_heff_2ecompile_2eemitc_2etestC_str197)));
        V v_t_24877 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str198), heff_strAppend(v_x_24870, v_t_24876));
        V v_t_24878 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str199), heff_strAppend(v_x_24866, v_t_24877));
        return heff_tag_at_n(v_ru_24x2_24865_24MkPair, TAG_MkPair, 2, (V[]){v_t_24878, v_s_24875});
      }
      default: return heff_nomatch(v_x2_24873);
      }
    }
    default: return heff_nomatch(v_x2_24869);
    }
  }
  default: return heff_nomatch(v_x2_24865);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args) {
  V v_s_24884 = args[0];
  V v_m_24883 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24885 = heff_tr(heff_call(v_m_24883, 1, (V[]){v_s_24884}));
  switch (heff_tag_of(v_x2_24885)) {
  case TAG_MkPair: {
    V v_x_24886 = heff_field(v_x2_24885, 0);
    V v_s_24887 = heff_field(v_x2_24885, 1);
    V v_ru_24x2_24885_24MkPair = heff_take_reuse_n(v_x2_24885, 3ULL, 2);
    V v_m_24888 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
    V v_x2_24889 = heff_tr(heff_call(v_m_24888, 1, (V[]){v_s_24887}));
    switch (heff_tag_of(v_x2_24889)) {
    case TAG_MkPair: {
      V v_x_24890 = heff_field(v_x2_24889, 0);
      V v_s_24891 = heff_field(v_x2_24889, 1);
      heff_take_n(v_x2_24889, 3ULL, 2);
      V v_t_24892 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str200), heff_strAppend(v_x_24890, ((V)&g_heff_2ecompile_2eemitc_2etestC_str201)));
      V v_t_24893 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str202), heff_strAppend(v_x_24886, v_t_24892));
      return heff_tag_at_n(v_ru_24x2_24885_24MkPair, TAG_MkPair, 2, (V[]){v_t_24893, v_s_24891});
    }
    default: return heff_nomatch(v_x2_24889);
    }
  }
  default: return heff_nomatch(v_x2_24885);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args) {
  V v_s_24895 = args[0];
  V v_m_24894 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24896 = heff_tr(heff_call(v_m_24894, 1, (V[]){v_s_24895}));
  switch (heff_tag_of(v_x2_24896)) {
  case TAG_MkPair: {
    V v_x_24897 = heff_field(v_x2_24896, 0);
    V v_s_24898 = heff_field(v_x2_24896, 1);
    V v_ru_24x2_24896_24MkPair = heff_take_reuse_n(v_x2_24896, 3ULL, 2);
    V v_m_24899 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24900 = heff_tr(heff_call(v_m_24899, 1, (V[]){v_s_24898}));
    switch (heff_tag_of(v_x2_24900)) {
    case TAG_MkPair: {
      V v_x_24901 = heff_field(v_x2_24900, 0);
      V v_s_24902 = heff_field(v_x2_24900, 1);
      heff_take_n(v_x2_24900, 3ULL, 2);
      V v_m_24903 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24904 = heff_tr(heff_call(v_m_24903, 1, (V[]){v_s_24902}));
      switch (heff_tag_of(v_x2_24904)) {
      case TAG_MkPair: {
        V v_x_24905 = heff_field(v_x2_24904, 0);
        V v_s_24906 = heff_field(v_x2_24904, 1);
        heff_take_n(v_x2_24904, 3ULL, 2);
        V v_t_24907 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str203), heff_strAppend(v_x_24905, ((V)&g_heff_2ecompile_2eemitc_2etestC_str204)));
        V v_t_24908 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str205), heff_strAppend(v_x_24901, v_t_24907));
        V v_t_24909 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str206), heff_strAppend(v_x_24897, v_t_24908));
        return heff_tag_at_n(v_ru_24x2_24896_24MkPair, TAG_MkPair, 2, (V[]){v_t_24909, v_s_24906});
      }
      default: return heff_nomatch(v_x2_24904);
      }
    }
    default: return heff_nomatch(v_x2_24900);
    }
  }
  default: return heff_nomatch(v_x2_24896);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args) {
  V v_s_24913 = args[0];
  V v_m_24912 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24914 = heff_tr(heff_call(v_m_24912, 1, (V[]){v_s_24913}));
  switch (heff_tag_of(v_x2_24914)) {
  case TAG_MkPair: {
    V v_x_24915 = heff_field(v_x2_24914, 0);
    V v_s_24916 = heff_field(v_x2_24914, 1);
    V v_ru_24x2_24914_24MkPair = heff_take_reuse_n(v_x2_24914, 3ULL, 2);
    V v_m_24917 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24918 = heff_tr(heff_call(v_m_24917, 1, (V[]){v_s_24916}));
    switch (heff_tag_of(v_x2_24918)) {
    case TAG_MkPair: {
      V v_x_24919 = heff_field(v_x2_24918, 0);
      V v_s_24920 = heff_field(v_x2_24918, 1);
      heff_take_n(v_x2_24918, 3ULL, 2);
      V v_m_24921 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24922 = heff_tr(heff_call(v_m_24921, 1, (V[]){v_s_24920}));
      switch (heff_tag_of(v_x2_24922)) {
      case TAG_MkPair: {
        V v_x_24923 = heff_field(v_x2_24922, 0);
        V v_s_24924 = heff_field(v_x2_24922, 1);
        heff_take_n(v_x2_24922, 3ULL, 2);
        V v_t_24925 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str207), heff_strAppend(v_x_24923, ((V)&g_heff_2ecompile_2eemitc_2etestC_str208)));
        V v_t_24926 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str209), heff_strAppend(v_x_24919, v_t_24925));
        V v_t_24927 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str210), heff_strAppend(v_x_24915, v_t_24926));
        return heff_tag_at_n(v_ru_24x2_24914_24MkPair, TAG_MkPair, 2, (V[]){v_t_24927, v_s_24924});
      }
      default: return heff_nomatch(v_x2_24922);
      }
    }
    default: return heff_nomatch(v_x2_24918);
    }
  }
  default: return heff_nomatch(v_x2_24914);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args) {
  V v_s_24931 = args[0];
  V v_m_24930 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24932 = heff_tr(heff_call(v_m_24930, 1, (V[]){v_s_24931}));
  switch (heff_tag_of(v_x2_24932)) {
  case TAG_MkPair: {
    V v_x_24933 = heff_field(v_x2_24932, 0);
    V v_s_24934 = heff_field(v_x2_24932, 1);
    V v_ru_24x2_24932_24MkPair = heff_take_reuse_n(v_x2_24932, 3ULL, 2);
    V v_m_24935 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24936 = heff_tr(heff_call(v_m_24935, 1, (V[]){v_s_24934}));
    switch (heff_tag_of(v_x2_24936)) {
    case TAG_MkPair: {
      V v_x_24937 = heff_field(v_x2_24936, 0);
      V v_s_24938 = heff_field(v_x2_24936, 1);
      heff_take_n(v_x2_24936, 3ULL, 2);
      V v_m_24939 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24940 = heff_tr(heff_call(v_m_24939, 1, (V[]){v_s_24938}));
      switch (heff_tag_of(v_x2_24940)) {
      case TAG_MkPair: {
        V v_x_24941 = heff_field(v_x2_24940, 0);
        V v_s_24942 = heff_field(v_x2_24940, 1);
        heff_take_n(v_x2_24940, 3ULL, 2);
        V v_t_24943 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str211), heff_strAppend(v_x_24941, ((V)&g_heff_2ecompile_2eemitc_2etestC_str212)));
        V v_t_24944 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str213), heff_strAppend(v_x_24937, v_t_24943));
        V v_t_24945 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str214), heff_strAppend(v_x_24933, v_t_24944));
        return heff_tag_at_n(v_ru_24x2_24932_24MkPair, TAG_MkPair, 2, (V[]){v_t_24945, v_s_24942});
      }
      default: return heff_nomatch(v_x2_24940);
      }
    }
    default: return heff_nomatch(v_x2_24936);
    }
  }
  default: return heff_nomatch(v_x2_24932);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args) {
  V v_s_24948 = args[0];
  V v_m_24947 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24949 = heff_tr(heff_call(v_m_24947, 1, (V[]){v_s_24948}));
  switch (heff_tag_of(v_x2_24949)) {
  case TAG_MkPair: {
    V v_x_24950 = heff_field(v_x2_24949, 0);
    V v_s_24951 = heff_field(v_x2_24949, 1);
    V v_ru_24x2_24949_24MkPair = heff_take_reuse_n(v_x2_24949, 3ULL, 2);
    V v_m_24952 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24953 = heff_tr(heff_call(v_m_24952, 1, (V[]){v_s_24951}));
    switch (heff_tag_of(v_x2_24953)) {
    case TAG_MkPair: {
      V v_x_24954 = heff_field(v_x2_24953, 0);
      V v_s_24955 = heff_field(v_x2_24953, 1);
      heff_take_n(v_x2_24953, 3ULL, 2);
      V v_m_24956 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24957 = heff_tr(heff_call(v_m_24956, 1, (V[]){v_s_24955}));
      switch (heff_tag_of(v_x2_24957)) {
      case TAG_MkPair: {
        V v_x_24958 = heff_field(v_x2_24957, 0);
        V v_s_24959 = heff_field(v_x2_24957, 1);
        heff_take_n(v_x2_24957, 3ULL, 2);
        V v_t_24960 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str215), heff_strAppend(v_x_24958, ((V)&g_heff_2ecompile_2eemitc_2etestC_str216)));
        V v_t_24961 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str217), heff_strAppend(v_x_24954, v_t_24960));
        V v_t_24962 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str218), heff_strAppend(v_x_24950, v_t_24961));
        return heff_tag_at_n(v_ru_24x2_24949_24MkPair, TAG_MkPair, 2, (V[]){v_t_24962, v_s_24959});
      }
      default: return heff_nomatch(v_x2_24957);
      }
    }
    default: return heff_nomatch(v_x2_24953);
    }
  }
  default: return heff_nomatch(v_x2_24949);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args) {
  V v_s_24965 = args[0];
  V v_m_24964 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24966 = heff_tr(heff_call(v_m_24964, 1, (V[]){v_s_24965}));
  switch (heff_tag_of(v_x2_24966)) {
  case TAG_MkPair: {
    V v_x_24967 = heff_field(v_x2_24966, 0);
    V v_s_24968 = heff_field(v_x2_24966, 1);
    V v_ru_24x2_24966_24MkPair = heff_take_reuse_n(v_x2_24966, 3ULL, 2);
    V v_m_24969 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24970 = heff_tr(heff_call(v_m_24969, 1, (V[]){v_s_24968}));
    switch (heff_tag_of(v_x2_24970)) {
    case TAG_MkPair: {
      V v_x_24971 = heff_field(v_x2_24970, 0);
      V v_s_24972 = heff_field(v_x2_24970, 1);
      heff_take_n(v_x2_24970, 3ULL, 2);
      V v_m_24973 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24974 = heff_tr(heff_call(v_m_24973, 1, (V[]){v_s_24972}));
      switch (heff_tag_of(v_x2_24974)) {
      case TAG_MkPair: {
        V v_x_24975 = heff_field(v_x2_24974, 0);
        V v_s_24976 = heff_field(v_x2_24974, 1);
        heff_take_n(v_x2_24974, 3ULL, 2);
        V v_t_24977 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str219), heff_strAppend(v_x_24975, ((V)&g_heff_2ecompile_2eemitc_2etestC_str220)));
        V v_t_24978 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str221), heff_strAppend(v_x_24971, v_t_24977));
        V v_t_24979 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str222), heff_strAppend(v_x_24967, v_t_24978));
        return heff_tag_at_n(v_ru_24x2_24966_24MkPair, TAG_MkPair, 2, (V[]){v_t_24979, v_s_24976});
      }
      default: return heff_nomatch(v_x2_24974);
      }
    }
    default: return heff_nomatch(v_x2_24970);
    }
  }
  default: return heff_nomatch(v_x2_24966);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args) {
  V v_s_24984 = args[0];
  V v_m_24983 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24985 = heff_tr(heff_call(v_m_24983, 1, (V[]){v_s_24984}));
  switch (heff_tag_of(v_x2_24985)) {
  case TAG_MkPair: {
    V v_x_24986 = heff_field(v_x2_24985, 0);
    V v_s_24987 = heff_field(v_x2_24985, 1);
    V v_ru_24x2_24985_24MkPair = heff_take_reuse_n(v_x2_24985, 3ULL, 2);
    V v_m_24988 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_24989 = heff_tr(heff_call(v_m_24988, 1, (V[]){v_s_24987}));
    switch (heff_tag_of(v_x2_24989)) {
    case TAG_MkPair: {
      V v_x_24990 = heff_field(v_x2_24989, 0);
      V v_s_24991 = heff_field(v_x2_24989, 1);
      heff_take_n(v_x2_24989, 3ULL, 2);
      V v_m_24992 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_24993 = heff_tr(heff_call(v_m_24992, 1, (V[]){v_s_24991}));
      switch (heff_tag_of(v_x2_24993)) {
      case TAG_MkPair: {
        V v_x_24994 = heff_field(v_x2_24993, 0);
        V v_s_24995 = heff_field(v_x2_24993, 1);
        heff_take_n(v_x2_24993, 3ULL, 2);
        V v_t_24996 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str223), heff_strAppend(v_x_24994, ((V)&g_heff_2ecompile_2eemitc_2etestC_str224)));
        V v_t_24997 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str225), heff_strAppend(v_x_24990, v_t_24996));
        V v_t_24998 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str226), heff_strAppend(v_x_24986, v_t_24997));
        return heff_tag_at_n(v_ru_24x2_24985_24MkPair, TAG_MkPair, 2, (V[]){v_t_24998, v_s_24995});
      }
      default: return heff_nomatch(v_x2_24993);
      }
    }
    default: return heff_nomatch(v_x2_24989);
    }
  }
  default: return heff_nomatch(v_x2_24985);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args) {
  V v_s_241004 = args[0];
  V v_m_241003 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2441 = heff_env(self)[2];
  V v_x23_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_241005 = heff_tr(heff_call(v_m_241003, 1, (V[]){v_s_241004}));
  switch (heff_tag_of(v_x2_241005)) {
  case TAG_MkPair: {
    V v_x_241006 = heff_field(v_x2_241005, 0);
    V v_s_241007 = heff_field(v_x2_241005, 1);
    V v_ru_24x2_241005_24MkPair = heff_take_reuse_n(v_x2_241005, 3ULL, 2);
    V v_m_241008 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2441));
    V v_x2_241009 = heff_tr(heff_call(v_m_241008, 1, (V[]){v_s_241007}));
    switch (heff_tag_of(v_x2_241009)) {
    case TAG_MkPair: {
      V v_x_241010 = heff_field(v_x2_241009, 0);
      V v_s_241011 = heff_field(v_x2_241009, 1);
      heff_take_n(v_x2_241009, 3ULL, 2);
      V v_m_241012 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2442));
      V v_x2_241013 = heff_tr(heff_call(v_m_241012, 1, (V[]){v_s_241011}));
      switch (heff_tag_of(v_x2_241013)) {
      case TAG_MkPair: {
        V v_x_241014 = heff_field(v_x2_241013, 0);
        V v_s_241015 = heff_field(v_x2_241013, 1);
        heff_take_n(v_x2_241013, 3ULL, 2);
        V v_t_241016 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str227), heff_strAppend(v_x_241014, ((V)&g_heff_2ecompile_2eemitc_2etestC_str228)));
        V v_t_241017 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str229), heff_strAppend(v_x_241010, v_t_241016));
        V v_t_241018 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str230), heff_strAppend(v_x_241006, v_t_241017));
        return heff_tag_at_n(v_ru_24x2_241005_24MkPair, TAG_MkPair, 2, (V[]){v_t_241018, v_s_241015});
      }
      default: return heff_nomatch(v_x2_241013);
      }
    }
    default: return heff_nomatch(v_x2_241009);
    }
  }
  default: return heff_nomatch(v_x2_241005);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args) {
  V v_s_241024 = args[0];
  V v_m_241023 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_241021 = heff_env(self)[2];
  V v_x_241019 = heff_env(self)[3];
  V v_drops_241022 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_241025 = heff_tr(heff_call(v_m_241023, 1, (V[]){v_s_241024}));
  switch (heff_tag_of(v_x2_241025)) {
  case TAG_MkPair: {
    V v_x_241026 = heff_field(v_x2_241025, 0);
    V v_s_241027 = heff_field(v_x2_241025, 1);
    V v_ru_24x2_241025_24MkPair = heff_take_reuse_n(v_x2_241025, 3ULL, 2);
    V v_m_241028 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_241021));
    V v_x2_241029 = heff_tr(heff_call(v_m_241028, 1, (V[]){v_s_241027}));
    switch (heff_tag_of(v_x2_241029)) {
    case TAG_MkPair: {
      V v_x_241030 = heff_field(v_x2_241029, 0);
      V v_s_241031 = heff_field(v_x2_241029, 1);
      heff_take_n(v_x2_241029, 3ULL, 2);
      V v_t_241032 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_241019)}));
      V v_t_241033 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241019, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str231)));
      V v_x2_241034 = (g_list_2emap_24s456133444x1904936646(((V)&g_heff_2ecompile_2eemitc_2etestC_str232), ((V)&g_heff_2ecompile_2eemitc_2etestC_str233), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str234), ((V)&g_heff_2ecompile_2eemitc_2etestC_str235), ((V)&g_heff_2ecompile_2eemitc_2etestC_str236), v_drops_241022));
      V v_t_241037;
      switch (heff_tag_of(v_x2_241034)) {
      case TAG_Nil: {
        v_t_241037 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str237);
        break;
      }
      case TAG_Cons: {
        V v_x_241035 = heff_field(v_x2_241034, 0);
        V v_xs_241036 = heff_field(v_x2_241034, 1);
        heff_take_n(v_x2_241034, 3ULL, 2);
        v_t_241037 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str238); V a_1 = v_x_241035; V a_2 = v_xs_241036; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_241036); r_; });
        break;
      }
      default: heff_nomatch(v_x2_241034);
      }
      V v_t_241038 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str239), heff_strAppend(v_t_241037, ((V)&g_heff_2ecompile_2eemitc_2etestC_str240)));
      V v_t_241039 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str241), heff_strAppend(v_x_241030, v_t_241038));
      V v_t_241040 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str242), heff_strAppend(v_x_241026, v_t_241039));
      V v_t_241041 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str243), v_t_241033), v_t_241040);
      V v_t_241042 = heff_strAppend(v_t_241032, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str244), v_t_241041));
      V v_x_241043 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str245), v_t_241042);
      return heff_tag_at_n(v_ru_24x2_241025_24MkPair, TAG_MkPair, 2, (V[]){v_x_241043, v_s_241031});
    }
    default: return heff_nomatch(v_x2_241029);
    }
  }
  default: return heff_nomatch(v_x2_241025);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str1, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str2, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str3, 14, " = heff_tflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str4, 13, " = heff_tget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str5, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str6, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eflatLine_str12, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2eflatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eflatLine_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eflatLine(V v_k_240, V v_sv_241, V v_sure_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_v_244), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str0)));
      V v_t_2410 = (g_list_2eany_24s120814613x1439363162(heff_dup(v_i_246), v_sure_242));
      V v_t_2412;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        switch (heff_tag_of(v_r_247)) {
        case TAG_RepV: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str1);
          break;
        }
        case TAG_RepFix: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str2);
          break;
        }
        case TAG_RepF64: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str3);
          break;
        }
        default: heff_nomatch(v_r_247);
        }
      } else {
        heff_drop(v_t_2410);
        v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str4);
      }
      V v_t_2414;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str5);
        break;
      }
      case TAG_RepFix: {
        V v_w_2413 = heff_field(v_r_247, 0);
        v_t_2414 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_2413));
        break;
      }
      case TAG_RepF64: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str6);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2415 = heff_strAppend(heff_intShow(heff_dup(v_i_246)), ((V)&g_heff_2ecompile_2eemitc_2eflatLine_str7));
      V v_t_2416 = heff_strAppend(v_sv_241, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str8), v_t_2415));
      V v_t_2417 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str9), v_t_2416));
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str10), v_t_249), heff_strAppend(v_t_2412, v_t_2417));
      V v_t_2419 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str11), v_t_2418));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eflatLine_str12), v_t_2419);
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2eflatLine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eflatLine(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_sure_246 = heff_field(v_x3_242, 3);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_leaves_2410 = heff_field(v_x3_242, 7);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 10, (V[]){v_m_2411, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_247), heff_dup(v_fields_244), v_k_240, heff_dup(v_sure_246), heff_dup(v_flats_245), heff_dup(v_take_248), heff_dup(v_leaves_2410)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_247 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_sure_246 = heff_env(self)[6];
  V v_flats_245 = heff_env(self)[7];
  V v_take_248 = heff_env(self)[8];
  V v_leaves_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2earmF_str0)));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str1), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2earmF_str2));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2417), NTAG(TAG_Nil)});
    V v_t_2419 = ({ V a_0 = heff_dup(v_sv_241); V a_1 = v_plain_247; V a_2 = v_fields_244; V r_ = (g_list_2emap_24s1518131677x2038133191(a_0, a_1, a_2)); heff_drop(v_plain_247); r_; });
    V v_t_2420 = ({ V a_0 = v_k_240; V a_1 = heff_dup(v_sv_241); V a_2 = v_sure_246; V a_3 = v_flats_245; V r_ = (g_list_2emap_24s1936967306x1304226505(a_0, a_1, a_2, a_3)); heff_drop(v_sure_246); r_; });
    V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2420));
    V v_t_2422 = ({ V a_0 = v_sv_241; V a_1 = v_take_248; V r_ = (g_heff_2ecompile_2eemitc_2etakeLines(a_0, a_1)); heff_drop(v_take_248); r_; });
    V v_t_2423 = (g_list_2emap_24f1217399696x462307458(((V)&g_heff_2ecompile_2eemitc_2earmF_str4), v_t_2422, v_x_2414));
    V v_t_2424;
    if ((heff_dup(v_leaves_2410) == NTAG(TAG_True))) {
      heff_drop(v_leaves_2410);
      v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str5), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_2410);
      v_t_2424 = NTAG(TAG_Nil);
    }
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str6), NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2425));
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2426));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2427));
    V v_x_2429 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2428));
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ecompile_2eemitc_2estmtF(heff_dup(v_lit_240), v_x_243));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam1, 1, 3, (V[]){v_m_245, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(v_lit_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
  return heff_strAppend(v_t_245, v_t_247);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 10, " return r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 2, "  ");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_bi_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_x2_247 = (g_list_2emap_24f1293205645x619162872(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7), v_t_246), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8), v_t_2412);
  } else {
    heff_drop(v_t_245);
    V v_x2_2413 = (g_list_2emap_24s353858844x950951807(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14)));
    V v_t_2418 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2422 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2418));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_x2_2426 = (g_list_2emap_24s1382928954x1260344933(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), v_bi_241));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26), heff_strAppend(v_t_2425, v_t_2430));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27), v_t_2417), v_t_2431);
    V v_t_2433 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28), v_t_2432));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29), v_t_2433);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = ({ V a_0 = heff_dup(v_i_2419); V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), heff_intShow(v_i_2419));
  } else {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_strAppend(heff_intShow(v_i_2419), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17), v_t_2421);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 22, "static const HeffName ");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s588563787x236154271(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7)));
  V v_t_2411 = heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8), v_t_2410));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9), v_t_2411), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str3, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str4, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str5, 14, "static V gget_");
Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 0, 8);
    V v_x3_245 = ({ V a_0 = heff_dup(v_key_243); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str0)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str1)));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str3));
      V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str4), v_t_249));
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str5), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalGet(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 42, "static const Global heff_globals_arr[] = {");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2413 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), heff_rfield(v_ce_242, 0)));
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), heff_rfield(v_ce_242, 1)));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2419));
  V v_t_2432;
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2429);
  }
  V v_x1_2437 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2437, 0ULL, 2);
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9);
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_t_2441 = heff_strAppend(v_t_2432, heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10)));
  V v_t_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f316845240x1272469554(a_0, a_1, a_2, a_3)); heff_drop(v_exports_240); r_; });
  V v_t_2447 = heff_strAppend(heff_intShow(v_t_2446), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11));
  V v_t_2448 = (g_map_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2449 = heff_strAppend(heff_intShow(v_t_2448), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12));
  V v_t_2450 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2451 = heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13));
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14), NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15), v_t_2451), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16), v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17), v_t_2449), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18), v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19), v_t_2447), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), v_t_2441), v_t_2456});
  V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2457));
  V v_t_2459 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2458));
  V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2459));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2460));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_t_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = v_t_247; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eglobalGet(v_ce_242, v_x_2410));
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_249));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  return ({ V a_0 = v_t_2418; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2420 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_dup(heff_field(v_p_2420, 0));
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2426;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_p_2420, 1);
    heff_take_n(v_p_2420, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_t_2427 = (g_heff_2ecompile_2eemitc_2egetterOf(v_ce_242, v_t_2426));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5), heff_strAppend(v_t_2423, v_t_2428));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_p_2433 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_p_2433)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2433, 1);
    heff_take_n(v_p_2433, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2433);
  }
  return ({ V a_0 = v_t_2436; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2442 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 2ULL, 2);
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  return ({ V a_0 = v_t_2445; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1177057410x67789151(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str0, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str3, 1, ",");
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eshapesOnlyHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapesOnlyHere_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eshapesOnlyHere(V v_lbls_240, V v_sure_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_sure_241, NTAG(TAG_Nil)));
  V v_ps_245 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eshapesOnlyHere_lam0, 1, 1, (V[]){heff_dup(v_lbls_240)}), v_t_242));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_245; V r_ = (g_list_2efoldl_24s753153351x493712762(a_0, a_1)); heff_drop(v_ps_245); r_; });
}
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eshapesOnlyHere(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_lbls_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str0); V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str1); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str2); V a_4 = v_p_243; V a_5 = ((V)&g_heff_2ecompile_2eemitc_2eshapesOnlyHere_str3); V a_6 = MK_INT(0LL); V a_7 = v_lbls_240; V r_ = (g_list_2eany_24s1673346944x1460195389(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_p_243); heff_drop(v_lbls_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
  heff_drop(v_x1_244);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 8, "uint64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 6, "double");

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_b_241), heff_dup(v_k_243))) {
    heff_drop(v_m_240);
    heff_drop(v_b_241);
    heff_drop(v_ps_242);
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_qs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}), heff_dup(v_ps_242)));
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(heff_dup(v_m_240), v_b_241, v_ps_242, heff_intAdd(heff_dup(v_k_243), MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_m_240);
      heff_drop(v_k_243);
      return v_rest_2411;
    }
    case TAG_Cons: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0), heff_intShow(v_k_243));
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_240, v_t_2414), v_qs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemitc_2ekeyHashGo(v_t_248, MK_INT(0LL), MK_INT(7LL)));
  return heff_intEq(heff_intMod(v_t_249, v_b_241), v_k_243);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str0, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str1, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str2, 17, "#define HEFF_PART");
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulesParts_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2emodulesParts(V v_ce_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_defs_245, V v_ems_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 6))));
  V v_t_248 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 7))));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str0), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str2), v_t_249})});
  V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2emodulesParts_lam0, 1, 4, (V[]){heff_dup(v_s_241), heff_dup(v_strs_242), heff_dup(v_protos_243), heff_dup(v_lams_244)})}));
  V v_t_2414 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_245, v_ems_246));
  V v_m_2415 = (g_list_2efoldl_24s96111113x2107485159(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2414));
  V v_t_2416 = ({ V a_0 = v_m_2415; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2415); r_; });
  V v_t_2417 = (g_list_2econcatMap(v_t_2413, v_t_2416));
  return ({ V a_0 = v_t_2410; V a_1 = v_ce_240; V a_2 = v_s_241; V a_3 = v_t_247; V a_4 = v_t_248; V a_5 = v_strs_242; V a_6 = v_protos_243; V a_7 = v_lams_244; V a_8 = v_t_2417; V r_ = (g_list_2emap_24s766426360x2144213627(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop_rec(v_s_241, 8); heff_drop(v_t_247); heff_drop(v_t_248); r_; });
}
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2emodulesParts(a[0], a[1], a2, a3, a4, a[5], a[6]); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_strs_242 = heff_env(self)[1];
  V v_protos_243 = heff_env(self)[2];
  V v_lams_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2412 = ({ V a_0 = v_s_241; V a_1 = v_strs_242; V a_2 = v_protos_243; V a_3 = v_lams_244; V a_4 = v_p_2411; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_241, 8); heff_drop(v_strs_242); heff_drop(v_protos_243); heff_drop(v_lams_244); heff_drop(v_p_2411); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2412; V r_ = (g_list_2efoldl_24s1894035205x969464323(a_0, a_1, a_2)); heff_drop(v_ls_2412); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 8);
  V v_x2_244 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 8);
  V v_x3_248 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_247; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_248, 0ULL, 1);
    v_t_2410 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 8);
  V v_x2_2412 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2411; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_x2_2415 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 4, 8);
  V v_x3_2420 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2419; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_Nothing: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x3_2420, 0);
    heff_take_n(v_x3_2420, 1ULL, 1);
    v_t_2422 = (g_heff_2ecompile_2erepr_2esigName(v_x_2421));
    break;
  }
  default: heff_nomatch(v_x3_2420);
  }
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2422}), v_rest_242});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2418}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2410}), v_t_2424});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_246}), v_t_2425});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2426});
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epushOwn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str1, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreshEmitted_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efreshEmitted(V v_acc_240, V v_key_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_s1_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_244), heff_take_field(v_acc_240, 0)});
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str0)));
    V v_t_248 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_242), heff_dup(v_e_244), heff_dup(v_s1_245)));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str1), v_t_247), v_t_248, heff_take_field(v_acc_240, 1)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_242, v_e_244, v_s1_245));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){v_key_241, v_t_2410}), heff_get_n(v_acc_240, 2, 3)});
    return heff_rec_n(3, shape_ems__s__fresh, (V[]){v_t_246, v_t_249, v_t_2411});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efreshEmitted(a[0], a[1], a[2], a[3]);
}