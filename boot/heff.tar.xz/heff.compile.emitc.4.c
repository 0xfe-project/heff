// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_MkCArm 24694
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_ctype 296362551
#define LBL_ems 310085
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_workers 1757018875
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2egetterOf(V, V);
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egetterOf_clo;
V g_heff_2ecompile_2eemitc_2eglobalGet(V, V);
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2einfixC(V, V);
V g_heff_2ecompile_2eemitc_2einfixC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einfixC_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elibmNames_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emodulePart(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2emodulesParts(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2erelSymbol(V, V);
V g_heff_2ecompile_2eemitc_2erelSymbol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erelSymbol_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etakeLines(V, V);
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeLines_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24f1992548173x1980409276(V, V, V, V);
V g_list_2efoldl_24f1992548173x1980409276_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1992548173x1980409276_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1486300758x450371661(V, V, V);
V g_list_2efoldl_24s1486300758x450371661_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1486300758x450371661_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1702849581x277546608(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1702849581x277546608_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1702849581x277546608_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1801471045x554404499(V, V, V, V);
V g_list_2emap_24f1801471045x554404499_entry(V self, V *a);
extern Clo g_list_2emap_24f1801471045x554404499_clo;
V g_list_2emap_24f998257836x1791893456(V, V, V);
V g_list_2emap_24f998257836x1791893456_entry(V self, V *a);
extern Clo g_list_2emap_24f998257836x1791893456_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1437960788x1959942644(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1437960788x1959942644_entry(V self, V *a);
extern Clo g_list_2emap_24s1437960788x1959942644_clo;
V g_list_2emap_24s1785262601x1752264566(V, V, V, V);
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a);
extern Clo g_list_2emap_24s1785262601x1752264566_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eshowInt_get(void);
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, v_t_2413})));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2412, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2417 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2415)));
    V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2415));
    V v_x2_2420 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2418, v_t_2419));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_ts_2421 = heff_field(v_x2_2420, 0);
      V v_ls2_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      V v_t_2423 = (g_prelude_2e_2b_2b(v_ls_2417, v_ls2_2422));
      return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ts_2421, v_t_2423});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  case TAG_EProj: {
    V v_e_2424 = heff_field(v_x1_240, 0);
    V v_l_2425 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2428 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2424));
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_MkPair: {
      V v_ts_2429 = heff_field(v_x2_2428, 0);
      V v_ls2_2430 = heff_field(v_x2_2428, 1);
      V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
      V v_t_2431 = heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_Cons, 2, (V[]){v_l_2425, NTAG(TAG_Nil)});
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ls2_2430));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2429, v_t_2432});
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
  case TAG_ETag: {
    V v_t_2433 = heff_field(v_x1_240, 0);
    V v_as_2434 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2435 = heff_tag_at_n(v_ru_24x1_240_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2434));
    V v_x2_2437 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2435, v_t_2436));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_ts2_2438 = heff_field(v_x2_2437, 0);
      V v_ls_2439 = heff_field(v_x2_2437, 1);
      V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
      V v_t_2440 = heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2440, v_ts2_2438));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_ls_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x1_240, 0);
    V v_arms_2443 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_ts_2444 = (g_list_2emap_24s1009200955x251267316(heff_dup(v_arms_2443)));
    V v_t_2445 = (g_list_2emap_24s60612435x257154841(v_arms_2443));
    V v_es_2446 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2442, v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2446));
    V v_x2_2449 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2447, v_t_2448));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_ts2_2450 = heff_field(v_x2_2449, 0);
      V v_ls_2451 = heff_field(v_x2_2449, 1);
      V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
      V v_t_2452 = (g_prelude_2e_2b_2b(v_ts_2444, v_ts2_2450));
      return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){v_t_2452, v_ls_2451});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_as_2455 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2456 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2455));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2456, v_t_2457));
  }
  case TAG_ECall: {
    V v_as_2459 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2460 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2459));
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2460, v_t_2461));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_242), heff_strLength(heff_dup(v_text_240)))) {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eisAlnum(heff_strByteAt(heff_dup(v_text_240), heff_dup(v_i_242))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_text_240;
      V t_1 = v_start_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_text_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_244);
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_text_240), heff_dup(v_i_242)), MK_INT(95LL))) {
        V t_0 = v_text_240;
        V t_1 = v_start_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_text_240 = t_0;
        v_start_241 = t_1;
        v_i_242 = t_2;
        goto top;
      } else {
        return heff_strSlice(v_text_240, v_start_241, v_i_242);
      }
    }
  } else {
    return heff_strSlice(v_text_240, v_start_241, v_i_242);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eidentAt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 5, "((V)&");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str1)));
  V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), v_t_244);
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_247 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str2), v_t_247));
  V v_t_249 = heff_intShow(heff_strLength(heff_dup(v_str_241)));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3)));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str6), heff_strAppend(v_t_249, v_t_2411));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str7), heff_strAppend(v_t_248, v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_mac_240, v_t_2413)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_246; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str8), v_t_245), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estrLit(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str0, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str1, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str2, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str3, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str4, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str5, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str6, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str7, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str8, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str9, 3, "log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str10, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str11, 3, "exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str12, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str13, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str14, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str15, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str16, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str17, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str18, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str19, 3, "tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str20, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str21, 3, "cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str22, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str23, 3, "sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str24, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elibmNames_str25, 4, "sqrt");

static V g_heff_2ecompile_2eemitc_2elibmNames_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2elibmNames_st;
static V g_heff_2ecompile_2eemitc_2elibmNames_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str0), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str2), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str4), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str6), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str8), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str10), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str11)}), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str12), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str13)}), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str14), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str15)}), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str16), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str17)}), v_t_247});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str18), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str19)}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str20), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str21)}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str22), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str23)}), v_t_2410});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elibmNames_str24), ((V)&g_heff_2ecompile_2eemitc_2elibmNames_str25)}), v_t_2411});
}
V g_heff_2ecompile_2eemitc_2elibmNames_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2elibmNames_st)) return g_heff_2ecompile_2eemitc_2elibmNames_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2elibmNames_val, &g_heff_2ecompile_2eemitc_2elibmNames_st, g_heff_2ecompile_2eemitc_2elibmNames_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str65, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str66, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str67, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str68, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str69, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str70, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str71, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str72, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str73, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str74, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str75, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str76, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str77, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str78, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str80, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str81, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str82, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str84, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str85, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str86, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str87, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str88, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str89, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str90, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str91, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str92, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str93, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str94, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str95, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str96, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str97, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str98, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str99, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str100, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str101, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str102, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str103, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str104, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str105, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str106, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str107, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str108, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str109, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str110, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str111, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str112, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str113, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str114, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str115, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str116, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str117, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str118, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str119, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str120, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str121, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str122, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str123, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str124, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str125, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str127, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str128, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str129, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str130, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str131, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str132, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str133, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str134, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str135, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str136, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str137, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str138, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str139, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str140, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str141, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str142, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str143, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str144, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str145, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str146, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str147, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str148, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str149, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str150, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str151, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str152, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str153, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str154, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str155, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str156, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str157, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str158, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str159, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str160, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str161, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str162, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str163, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str164, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str165, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str166, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str167, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str168, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str169, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str170, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str171, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str172, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str173, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str174, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str175, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str176, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str177, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str178, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str179, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str180, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str181, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str182, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str183, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str184, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str185, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str186, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str187, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str188, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str189, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str190, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str191, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str192, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str193, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str194, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str195, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str196, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str197, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str198, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str199, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str200, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str201, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str202, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str203, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str204, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str205, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str206, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str207, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str208, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str209, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str210, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str211, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str212, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str213, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str214, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str215, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str216, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str217, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str218, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str220, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str221, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str222, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str223, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str224, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str225, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str226, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str227, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str228, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str229, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str230, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str231, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str232, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str233, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str234, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str235, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str238, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str239, 6, "c_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str240, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str241, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str242, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str243, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str244, 3, "({ ");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_245));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_246, v_p_244});
  }
  case TAG_CondRelU: {
    V v_p_2416 = heff_field(v_x2_241, 0);
    V v_es_2417 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_2417));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2418, v_p_2416});
  }
  case TAG_CondBool: {
    V v_e_2426 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2426}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2427});
  }
  case TAG_CondNot: {
    V v_c_2433 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2434 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2433));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2434});
  }
  case TAG_CondIf: {
    V v_a_2439 = heff_field(v_x2_241, 0);
    V v_b_2440 = heff_field(v_x2_241, 1);
    V v_x23_2441 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2441)) {
    case TAG_CondTrue: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_2442 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2442, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_2453 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 4, (V[]){v_m_2453, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_2471 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2471, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_2489 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 4, (V[]){v_m_2489, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24106 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam10, 1, 4, (V[]){v_m_24106, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24123 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam11, 1, 4, (V[]){v_m_24123, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24142 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam12, 1, 4, (V[]){v_m_24142, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24162 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam13, 1, 4, (V[]){v_m_24162, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondFalse: {
      V v_m_24178 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam14, 1, 3, (V[]){v_m_24178, v_k_240, v_b_2440});
    }
    case TAG_CondRel: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24191 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam15, 1, 3, (V[]){v_m_24191, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24202 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam16, 1, 4, (V[]){v_m_24202, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24220 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam17, 1, 4, (V[]){v_m_24220, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24238 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam18, 1, 4, (V[]){v_m_24238, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24255 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam19, 1, 4, (V[]){v_m_24255, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24272 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam20, 1, 4, (V[]){v_m_24272, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24291 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam21, 1, 4, (V[]){v_m_24291, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24311 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam22, 1, 4, (V[]){v_m_24311, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondRelU: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24329 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam23, 1, 3, (V[]){v_m_24329, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24340 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam24, 1, 4, (V[]){v_m_24340, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24358 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam25, 1, 4, (V[]){v_m_24358, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24376 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam26, 1, 4, (V[]){v_m_24376, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24393 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam27, 1, 4, (V[]){v_m_24393, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24410 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam28, 1, 4, (V[]){v_m_24410, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24429 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam29, 1, 4, (V[]){v_m_24429, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24449 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam30, 1, 4, (V[]){v_m_24449, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondBool: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24466 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam31, 1, 3, (V[]){v_m_24466, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24477 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam32, 1, 4, (V[]){v_m_24477, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24495 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam33, 1, 4, (V[]){v_m_24495, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24513 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam34, 1, 4, (V[]){v_m_24513, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24530 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam35, 1, 4, (V[]){v_m_24530, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24547 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam36, 1, 4, (V[]){v_m_24547, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24566 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam37, 1, 4, (V[]){v_m_24566, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24586 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam38, 1, 4, (V[]){v_m_24586, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondNot: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24603 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam39, 1, 3, (V[]){v_m_24603, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24614 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam40, 1, 4, (V[]){v_m_24614, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24632 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam41, 1, 4, (V[]){v_m_24632, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24650 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam42, 1, 4, (V[]){v_m_24650, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24667 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam43, 1, 4, (V[]){v_m_24667, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24684 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam44, 1, 4, (V[]){v_m_24684, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24703 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam45, 1, 4, (V[]){v_m_24703, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24723 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam46, 1, 4, (V[]){v_m_24723, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondIf: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24742 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam47, 1, 3, (V[]){v_m_24742, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24753 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam48, 1, 4, (V[]){v_m_24753, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24771 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam49, 1, 4, (V[]){v_m_24771, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24789 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam50, 1, 4, (V[]){v_m_24789, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24806 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam51, 1, 4, (V[]){v_m_24806, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24823 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam52, 1, 4, (V[]){v_m_24823, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24842 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam53, 1, 4, (V[]){v_m_24842, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_24862 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam54, 1, 4, (V[]){v_m_24862, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    case TAG_CondLet: {
      switch (heff_tag_of(v_b_2440)) {
      case TAG_CondTrue: {
        V v_m_24882 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam55, 1, 3, (V[]){v_m_24882, v_k_240, v_x23_2441});
      }
      case TAG_CondFalse: {
        V v_m_24893 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam56, 1, 4, (V[]){v_m_24893, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRel: {
        V v_m_24911 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam57, 1, 4, (V[]){v_m_24911, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondRelU: {
        V v_m_24929 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam58, 1, 4, (V[]){v_m_24929, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondBool: {
        V v_m_24946 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam59, 1, 4, (V[]){v_m_24946, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondNot: {
        V v_m_24963 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam60, 1, 4, (V[]){v_m_24963, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondIf: {
        V v_m_24982 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam61, 1, 4, (V[]){v_m_24982, v_k_240, v_b_2440, v_x23_2441});
      }
      case TAG_CondLet: {
        V v_m_241002 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_a_2439));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam62, 1, 4, (V[]){v_m_241002, v_k_240, v_b_2440, v_x23_2441});
      }
      default: return heff_nomatch(v_b_2440);
      }
    }
    default: return heff_nomatch(v_x23_2441);
    }
  }
  case TAG_CondLet: {
    V v_x_241018 = heff_field(v_x2_241, 0);
    V v_e_241019 = heff_field(v_x2_241, 1);
    V v_c_241020 = heff_field(v_x2_241, 2);
    V v_drops_241021 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_241022 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_241019}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam63, 1, 5, (V[]){v_m_241022, v_k_240, v_c_241020, v_x_241018, v_drops_241021});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etestC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x_249, 0);
      V v_xs_2412 = heff_field(v_x_249, 1);
      heff_take_n(v_x_249, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2etestC_str5)));
    V v_x_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str6), v_p_244), v_t_2414);
    return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_p_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_s_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_t_2423 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2416)));
    V v_t_2424 = ({ V a_0 = v_p_2416; V a_1 = v_t_2423; V r_ = (g_heff_2ecompile_2eemitc_2erelSymbol(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_x_2425 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2424, v_x_2421));
    return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_x_2425, v_s_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str7), heff_strAppend(v_x_2430, ((V)&g_heff_2ecompile_2eemitc_2etestC_str8)));
    return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_s_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_s_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str9), v_x_2437), v_s_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
    V v_m_2447 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_2448 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2448)) {
    case TAG_MkPair: {
      V v_x_2449 = heff_field(v_x2_2448, 0);
      V v_s_2450 = heff_field(v_x2_2448, 1);
      heff_take_n(v_x2_2448, 3ULL, 2);
      V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str10), heff_strAppend(v_x_2449, ((V)&g_heff_2ecompile_2eemitc_2etestC_str11)));
      V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str12), heff_strAppend(v_x_2445, v_t_2451));
      return heff_tag_at_n(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2452, v_s_2450});
    }
    default: return heff_nomatch(v_x2_2448);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    V v_m_2458 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_2459 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2457}));
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_MkPair: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_s_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      V v_m_2462 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_2461}));
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_MkPair: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        V v_s_2465 = heff_field(v_x2_2463, 1);
        heff_take_n(v_x2_2463, 3ULL, 2);
        V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str13), heff_strAppend(v_x_2464, ((V)&g_heff_2ecompile_2eemitc_2etestC_str14)));
        V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str15), heff_strAppend(v_x_2460, v_t_2466));
        V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str16), heff_strAppend(v_x_2456, v_t_2467));
        return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){v_t_2468, v_s_2465});
      }
      default: return heff_nomatch(v_x2_2463);
      }
    }
    default: return heff_nomatch(v_x2_2459);
    }
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2472 = args[0];
  V v_m_2471 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2473 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_s_2472}));
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_field(v_x2_2473, 0);
    V v_s_2475 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    V v_m_2476 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2475}));
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_MkPair: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_s_2479 = heff_field(v_x2_2477, 1);
      heff_take_n(v_x2_2477, 3ULL, 2);
      V v_m_2480 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_s_2479}));
      switch (heff_tag_of(v_x2_2481)) {
      case TAG_MkPair: {
        V v_x_2482 = heff_field(v_x2_2481, 0);
        V v_s_2483 = heff_field(v_x2_2481, 1);
        heff_take_n(v_x2_2481, 3ULL, 2);
        V v_t_2484 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str17), heff_strAppend(v_x_2482, ((V)&g_heff_2ecompile_2eemitc_2etestC_str18)));
        V v_t_2485 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str19), heff_strAppend(v_x_2478, v_t_2484));
        V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str20), heff_strAppend(v_x_2474, v_t_2485));
        return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){v_t_2486, v_s_2483});
      }
      default: return heff_nomatch(v_x2_2481);
      }
    }
    default: return heff_nomatch(v_x2_2477);
    }
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2490}));
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_MkPair: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    V v_s_2493 = heff_field(v_x2_2491, 1);
    V v_ru_24x2_2491_24MkPair = heff_take_reuse_n(v_x2_2491, 3ULL, 2);
    V v_m_2494 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_s_2493}));
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_s_2497 = heff_field(v_x2_2495, 1);
      heff_take_n(v_x2_2495, 3ULL, 2);
      V v_m_2498 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_2499 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_s_2497}));
      switch (heff_tag_of(v_x2_2499)) {
      case TAG_MkPair: {
        V v_x_24100 = heff_field(v_x2_2499, 0);
        V v_s_24101 = heff_field(v_x2_2499, 1);
        heff_take_n(v_x2_2499, 3ULL, 2);
        V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str21), heff_strAppend(v_x_24100, ((V)&g_heff_2ecompile_2eemitc_2etestC_str22)));
        V v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str23), heff_strAppend(v_x_2496, v_t_24102));
        V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str24), heff_strAppend(v_x_2492, v_t_24103));
        return heff_tag_at_n(v_ru_24x2_2491_24MkPair, TAG_MkPair, 2, (V[]){v_t_24104, v_s_24101});
      }
      default: return heff_nomatch(v_x2_2499);
      }
    }
    default: return heff_nomatch(v_x2_2495);
    }
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam10(V self, V *args) {
  V v_s_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_s_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_s_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    V v_m_24111 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24112 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_s_24110}));
    switch (heff_tag_of(v_x2_24112)) {
    case TAG_MkPair: {
      V v_x_24113 = heff_field(v_x2_24112, 0);
      V v_s_24114 = heff_field(v_x2_24112, 1);
      heff_take_n(v_x2_24112, 3ULL, 2);
      V v_m_24115 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24116 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_s_24114}));
      switch (heff_tag_of(v_x2_24116)) {
      case TAG_MkPair: {
        V v_x_24117 = heff_field(v_x2_24116, 0);
        V v_s_24118 = heff_field(v_x2_24116, 1);
        heff_take_n(v_x2_24116, 3ULL, 2);
        V v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str25), heff_strAppend(v_x_24117, ((V)&g_heff_2ecompile_2eemitc_2etestC_str26)));
        V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str27), heff_strAppend(v_x_24113, v_t_24119));
        V v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str28), heff_strAppend(v_x_24109, v_t_24120));
        return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_t_24121, v_s_24118});
      }
      default: return heff_nomatch(v_x2_24116);
      }
    }
    default: return heff_nomatch(v_x2_24112);
    }
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam11(V self, V *args) {
  V v_s_24124 = args[0];
  V v_m_24123 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24125 = heff_tr(heff_call(v_m_24123, 1, (V[]){v_s_24124}));
  switch (heff_tag_of(v_x2_24125)) {
  case TAG_MkPair: {
    V v_x_24126 = heff_field(v_x2_24125, 0);
    V v_s_24127 = heff_field(v_x2_24125, 1);
    V v_ru_24x2_24125_24MkPair = heff_take_reuse_n(v_x2_24125, 3ULL, 2);
    V v_m_24128 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24129 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_s_24127}));
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_s_24131 = heff_field(v_x2_24129, 1);
      heff_take_n(v_x2_24129, 3ULL, 2);
      V v_m_24132 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24133 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_s_24131}));
      switch (heff_tag_of(v_x2_24133)) {
      case TAG_MkPair: {
        V v_x_24134 = heff_field(v_x2_24133, 0);
        V v_s_24135 = heff_field(v_x2_24133, 1);
        heff_take_n(v_x2_24133, 3ULL, 2);
        V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str29), heff_strAppend(v_x_24134, ((V)&g_heff_2ecompile_2eemitc_2etestC_str30)));
        V v_t_24137 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str31), heff_strAppend(v_x_24130, v_t_24136));
        V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str32), heff_strAppend(v_x_24126, v_t_24137));
        return heff_tag_at_n(v_ru_24x2_24125_24MkPair, TAG_MkPair, 2, (V[]){v_t_24138, v_s_24135});
      }
      default: return heff_nomatch(v_x2_24133);
      }
    }
    default: return heff_nomatch(v_x2_24129);
    }
  }
  default: return heff_nomatch(v_x2_24125);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam12(V self, V *args) {
  V v_s_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24144 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_s_24143}));
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkPair: {
    V v_x_24145 = heff_field(v_x2_24144, 0);
    V v_s_24146 = heff_field(v_x2_24144, 1);
    V v_ru_24x2_24144_24MkPair = heff_take_reuse_n(v_x2_24144, 3ULL, 2);
    V v_m_24147 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24148 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24146}));
    switch (heff_tag_of(v_x2_24148)) {
    case TAG_MkPair: {
      V v_x_24149 = heff_field(v_x2_24148, 0);
      V v_s_24150 = heff_field(v_x2_24148, 1);
      heff_take_n(v_x2_24148, 3ULL, 2);
      V v_m_24151 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24152 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_s_24150}));
      switch (heff_tag_of(v_x2_24152)) {
      case TAG_MkPair: {
        V v_x_24153 = heff_field(v_x2_24152, 0);
        V v_s_24154 = heff_field(v_x2_24152, 1);
        heff_take_n(v_x2_24152, 3ULL, 2);
        V v_t_24155 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str33), heff_strAppend(v_x_24153, ((V)&g_heff_2ecompile_2eemitc_2etestC_str34)));
        V v_t_24156 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str35), heff_strAppend(v_x_24149, v_t_24155));
        V v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str36), heff_strAppend(v_x_24145, v_t_24156));
        return heff_tag_at_n(v_ru_24x2_24144_24MkPair, TAG_MkPair, 2, (V[]){v_t_24157, v_s_24154});
      }
      default: return heff_nomatch(v_x2_24152);
      }
    }
    default: return heff_nomatch(v_x2_24148);
    }
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam13(V self, V *args) {
  V v_s_24163 = args[0];
  V v_m_24162 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24164 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_s_24163}));
  switch (heff_tag_of(v_x2_24164)) {
  case TAG_MkPair: {
    V v_x_24165 = heff_field(v_x2_24164, 0);
    V v_s_24166 = heff_field(v_x2_24164, 1);
    V v_ru_24x2_24164_24MkPair = heff_take_reuse_n(v_x2_24164, 3ULL, 2);
    V v_m_24167 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24168 = heff_tr(heff_call(v_m_24167, 1, (V[]){v_s_24166}));
    switch (heff_tag_of(v_x2_24168)) {
    case TAG_MkPair: {
      V v_x_24169 = heff_field(v_x2_24168, 0);
      V v_s_24170 = heff_field(v_x2_24168, 1);
      heff_take_n(v_x2_24168, 3ULL, 2);
      V v_m_24171 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24172 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_s_24170}));
      switch (heff_tag_of(v_x2_24172)) {
      case TAG_MkPair: {
        V v_x_24173 = heff_field(v_x2_24172, 0);
        V v_s_24174 = heff_field(v_x2_24172, 1);
        heff_take_n(v_x2_24172, 3ULL, 2);
        V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), heff_strAppend(v_x_24173, ((V)&g_heff_2ecompile_2eemitc_2etestC_str38)));
        V v_t_24176 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str39), heff_strAppend(v_x_24169, v_t_24175));
        V v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), heff_strAppend(v_x_24165, v_t_24176));
        return heff_tag_at_n(v_ru_24x2_24164_24MkPair, TAG_MkPair, 2, (V[]){v_t_24177, v_s_24174});
      }
      default: return heff_nomatch(v_x2_24172);
      }
    }
    default: return heff_nomatch(v_x2_24168);
    }
  }
  default: return heff_nomatch(v_x2_24164);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam14(V self, V *args) {
  V v_s_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_s_24179}));
  switch (heff_tag_of(v_x2_24180)) {
  case TAG_MkPair: {
    V v_x_24181 = heff_field(v_x2_24180, 0);
    V v_s_24182 = heff_field(v_x2_24180, 1);
    V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
    V v_m_24183 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2440));
    V v_x2_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_s_24182}));
    switch (heff_tag_of(v_x2_24184)) {
    case TAG_MkPair: {
      V v_x_24185 = heff_field(v_x2_24184, 0);
      V v_s_24186 = heff_field(v_x2_24184, 1);
      heff_take_n(v_x2_24184, 3ULL, 2);
      V v_t_24187 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str41), heff_strAppend(v_x_24185, ((V)&g_heff_2ecompile_2eemitc_2etestC_str42)));
      V v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str43), heff_strAppend(v_x_24181, v_t_24187));
      return heff_tag_at_n(v_ru_24x2_24180_24MkPair, TAG_MkPair, 2, (V[]){v_t_24188, v_s_24186});
    }
    default: return heff_nomatch(v_x2_24184);
    }
  }
  default: return heff_nomatch(v_x2_24180);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam15(V self, V *args) {
  V v_s_24192 = args[0];
  V v_m_24191 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24193 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_s_24192}));
  switch (heff_tag_of(v_x2_24193)) {
  case TAG_MkPair: {
    V v_x_24194 = heff_field(v_x2_24193, 0);
    V v_s_24195 = heff_field(v_x2_24193, 1);
    V v_ru_24x2_24193_24MkPair = heff_take_reuse_n(v_x2_24193, 3ULL, 2);
    V v_m_24196 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24197 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_s_24195}));
    switch (heff_tag_of(v_x2_24197)) {
    case TAG_MkPair: {
      V v_x_24198 = heff_field(v_x2_24197, 0);
      V v_s_24199 = heff_field(v_x2_24197, 1);
      heff_take_n(v_x2_24197, 3ULL, 2);
      V v_t_24200 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str44), heff_strAppend(v_x_24198, ((V)&g_heff_2ecompile_2eemitc_2etestC_str45)));
      V v_t_24201 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str46), heff_strAppend(v_x_24194, v_t_24200));
      return heff_tag_at_n(v_ru_24x2_24193_24MkPair, TAG_MkPair, 2, (V[]){v_t_24201, v_s_24199});
    }
    default: return heff_nomatch(v_x2_24197);
    }
  }
  default: return heff_nomatch(v_x2_24193);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam16(V self, V *args) {
  V v_s_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24204 = heff_tr(heff_call(v_m_24202, 1, (V[]){v_s_24203}));
  switch (heff_tag_of(v_x2_24204)) {
  case TAG_MkPair: {
    V v_x_24205 = heff_field(v_x2_24204, 0);
    V v_s_24206 = heff_field(v_x2_24204, 1);
    V v_ru_24x2_24204_24MkPair = heff_take_reuse_n(v_x2_24204, 3ULL, 2);
    V v_m_24207 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24208 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_s_24206}));
    switch (heff_tag_of(v_x2_24208)) {
    case TAG_MkPair: {
      V v_x_24209 = heff_field(v_x2_24208, 0);
      V v_s_24210 = heff_field(v_x2_24208, 1);
      heff_take_n(v_x2_24208, 3ULL, 2);
      V v_m_24211 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24212 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_s_24210}));
      switch (heff_tag_of(v_x2_24212)) {
      case TAG_MkPair: {
        V v_x_24213 = heff_field(v_x2_24212, 0);
        V v_s_24214 = heff_field(v_x2_24212, 1);
        heff_take_n(v_x2_24212, 3ULL, 2);
        V v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str47), heff_strAppend(v_x_24213, ((V)&g_heff_2ecompile_2eemitc_2etestC_str48)));
        V v_t_24216 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str49), heff_strAppend(v_x_24209, v_t_24215));
        V v_t_24217 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str50), heff_strAppend(v_x_24205, v_t_24216));
        return heff_tag_at_n(v_ru_24x2_24204_24MkPair, TAG_MkPair, 2, (V[]){v_t_24217, v_s_24214});
      }
      default: return heff_nomatch(v_x2_24212);
      }
    }
    default: return heff_nomatch(v_x2_24208);
    }
  }
  default: return heff_nomatch(v_x2_24204);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam17(V self, V *args) {
  V v_s_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_s_24221}));
  switch (heff_tag_of(v_x2_24222)) {
  case TAG_MkPair: {
    V v_x_24223 = heff_field(v_x2_24222, 0);
    V v_s_24224 = heff_field(v_x2_24222, 1);
    V v_ru_24x2_24222_24MkPair = heff_take_reuse_n(v_x2_24222, 3ULL, 2);
    V v_m_24225 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24226 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_s_24224}));
    switch (heff_tag_of(v_x2_24226)) {
    case TAG_MkPair: {
      V v_x_24227 = heff_field(v_x2_24226, 0);
      V v_s_24228 = heff_field(v_x2_24226, 1);
      heff_take_n(v_x2_24226, 3ULL, 2);
      V v_m_24229 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24230 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_s_24228}));
      switch (heff_tag_of(v_x2_24230)) {
      case TAG_MkPair: {
        V v_x_24231 = heff_field(v_x2_24230, 0);
        V v_s_24232 = heff_field(v_x2_24230, 1);
        heff_take_n(v_x2_24230, 3ULL, 2);
        V v_t_24233 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str51), heff_strAppend(v_x_24231, ((V)&g_heff_2ecompile_2eemitc_2etestC_str52)));
        V v_t_24234 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str53), heff_strAppend(v_x_24227, v_t_24233));
        V v_t_24235 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str54), heff_strAppend(v_x_24223, v_t_24234));
        return heff_tag_at_n(v_ru_24x2_24222_24MkPair, TAG_MkPair, 2, (V[]){v_t_24235, v_s_24232});
      }
      default: return heff_nomatch(v_x2_24230);
      }
    }
    default: return heff_nomatch(v_x2_24226);
    }
  }
  default: return heff_nomatch(v_x2_24222);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam18(V self, V *args) {
  V v_s_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_s_24239}));
  switch (heff_tag_of(v_x2_24240)) {
  case TAG_MkPair: {
    V v_x_24241 = heff_field(v_x2_24240, 0);
    V v_s_24242 = heff_field(v_x2_24240, 1);
    V v_ru_24x2_24240_24MkPair = heff_take_reuse_n(v_x2_24240, 3ULL, 2);
    V v_m_24243 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_s_24242}));
    switch (heff_tag_of(v_x2_24244)) {
    case TAG_MkPair: {
      V v_x_24245 = heff_field(v_x2_24244, 0);
      V v_s_24246 = heff_field(v_x2_24244, 1);
      heff_take_n(v_x2_24244, 3ULL, 2);
      V v_m_24247 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24248 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_s_24246}));
      switch (heff_tag_of(v_x2_24248)) {
      case TAG_MkPair: {
        V v_x_24249 = heff_field(v_x2_24248, 0);
        V v_s_24250 = heff_field(v_x2_24248, 1);
        heff_take_n(v_x2_24248, 3ULL, 2);
        V v_t_24251 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str55), heff_strAppend(v_x_24249, ((V)&g_heff_2ecompile_2eemitc_2etestC_str56)));
        V v_t_24252 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str57), heff_strAppend(v_x_24245, v_t_24251));
        V v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str58), heff_strAppend(v_x_24241, v_t_24252));
        return heff_tag_at_n(v_ru_24x2_24240_24MkPair, TAG_MkPair, 2, (V[]){v_t_24253, v_s_24250});
      }
      default: return heff_nomatch(v_x2_24248);
      }
    }
    default: return heff_nomatch(v_x2_24244);
    }
  }
  default: return heff_nomatch(v_x2_24240);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam19(V self, V *args) {
  V v_s_24256 = args[0];
  V v_m_24255 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24257 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_s_24256}));
  switch (heff_tag_of(v_x2_24257)) {
  case TAG_MkPair: {
    V v_x_24258 = heff_field(v_x2_24257, 0);
    V v_s_24259 = heff_field(v_x2_24257, 1);
    V v_ru_24x2_24257_24MkPair = heff_take_reuse_n(v_x2_24257, 3ULL, 2);
    V v_m_24260 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24261 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_s_24259}));
    switch (heff_tag_of(v_x2_24261)) {
    case TAG_MkPair: {
      V v_x_24262 = heff_field(v_x2_24261, 0);
      V v_s_24263 = heff_field(v_x2_24261, 1);
      heff_take_n(v_x2_24261, 3ULL, 2);
      V v_m_24264 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24265 = heff_tr(heff_call(v_m_24264, 1, (V[]){v_s_24263}));
      switch (heff_tag_of(v_x2_24265)) {
      case TAG_MkPair: {
        V v_x_24266 = heff_field(v_x2_24265, 0);
        V v_s_24267 = heff_field(v_x2_24265, 1);
        heff_take_n(v_x2_24265, 3ULL, 2);
        V v_t_24268 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str59), heff_strAppend(v_x_24266, ((V)&g_heff_2ecompile_2eemitc_2etestC_str60)));
        V v_t_24269 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str61), heff_strAppend(v_x_24262, v_t_24268));
        V v_t_24270 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str62), heff_strAppend(v_x_24258, v_t_24269));
        return heff_tag_at_n(v_ru_24x2_24257_24MkPair, TAG_MkPair, 2, (V[]){v_t_24270, v_s_24267});
      }
      default: return heff_nomatch(v_x2_24265);
      }
    }
    default: return heff_nomatch(v_x2_24261);
    }
  }
  default: return heff_nomatch(v_x2_24257);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam20(V self, V *args) {
  V v_s_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_s_24273}));
  switch (heff_tag_of(v_x2_24274)) {
  case TAG_MkPair: {
    V v_x_24275 = heff_field(v_x2_24274, 0);
    V v_s_24276 = heff_field(v_x2_24274, 1);
    V v_ru_24x2_24274_24MkPair = heff_take_reuse_n(v_x2_24274, 3ULL, 2);
    V v_m_24277 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_s_24276}));
    switch (heff_tag_of(v_x2_24278)) {
    case TAG_MkPair: {
      V v_x_24279 = heff_field(v_x2_24278, 0);
      V v_s_24280 = heff_field(v_x2_24278, 1);
      heff_take_n(v_x2_24278, 3ULL, 2);
      V v_m_24281 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24282 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_s_24280}));
      switch (heff_tag_of(v_x2_24282)) {
      case TAG_MkPair: {
        V v_x_24283 = heff_field(v_x2_24282, 0);
        V v_s_24284 = heff_field(v_x2_24282, 1);
        heff_take_n(v_x2_24282, 3ULL, 2);
        V v_t_24285 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str63), heff_strAppend(v_x_24283, ((V)&g_heff_2ecompile_2eemitc_2etestC_str64)));
        V v_t_24286 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str65), heff_strAppend(v_x_24279, v_t_24285));
        V v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str66), heff_strAppend(v_x_24275, v_t_24286));
        return heff_tag_at_n(v_ru_24x2_24274_24MkPair, TAG_MkPair, 2, (V[]){v_t_24287, v_s_24284});
      }
      default: return heff_nomatch(v_x2_24282);
      }
    }
    default: return heff_nomatch(v_x2_24278);
    }
  }
  default: return heff_nomatch(v_x2_24274);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam21(V self, V *args) {
  V v_s_24292 = args[0];
  V v_m_24291 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24293 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_s_24292}));
  switch (heff_tag_of(v_x2_24293)) {
  case TAG_MkPair: {
    V v_x_24294 = heff_field(v_x2_24293, 0);
    V v_s_24295 = heff_field(v_x2_24293, 1);
    V v_ru_24x2_24293_24MkPair = heff_take_reuse_n(v_x2_24293, 3ULL, 2);
    V v_m_24296 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24297 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_s_24295}));
    switch (heff_tag_of(v_x2_24297)) {
    case TAG_MkPair: {
      V v_x_24298 = heff_field(v_x2_24297, 0);
      V v_s_24299 = heff_field(v_x2_24297, 1);
      heff_take_n(v_x2_24297, 3ULL, 2);
      V v_m_24300 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_s_24299}));
      switch (heff_tag_of(v_x2_24301)) {
      case TAG_MkPair: {
        V v_x_24302 = heff_field(v_x2_24301, 0);
        V v_s_24303 = heff_field(v_x2_24301, 1);
        heff_take_n(v_x2_24301, 3ULL, 2);
        V v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str67), heff_strAppend(v_x_24302, ((V)&g_heff_2ecompile_2eemitc_2etestC_str68)));
        V v_t_24305 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str69), heff_strAppend(v_x_24298, v_t_24304));
        V v_t_24306 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str70), heff_strAppend(v_x_24294, v_t_24305));
        return heff_tag_at_n(v_ru_24x2_24293_24MkPair, TAG_MkPair, 2, (V[]){v_t_24306, v_s_24303});
      }
      default: return heff_nomatch(v_x2_24301);
      }
    }
    default: return heff_nomatch(v_x2_24297);
    }
  }
  default: return heff_nomatch(v_x2_24293);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam22(V self, V *args) {
  V v_s_24312 = args[0];
  V v_m_24311 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24313 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_s_24312}));
  switch (heff_tag_of(v_x2_24313)) {
  case TAG_MkPair: {
    V v_x_24314 = heff_field(v_x2_24313, 0);
    V v_s_24315 = heff_field(v_x2_24313, 1);
    V v_ru_24x2_24313_24MkPair = heff_take_reuse_n(v_x2_24313, 3ULL, 2);
    V v_m_24316 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24317 = heff_tr(heff_call(v_m_24316, 1, (V[]){v_s_24315}));
    switch (heff_tag_of(v_x2_24317)) {
    case TAG_MkPair: {
      V v_x_24318 = heff_field(v_x2_24317, 0);
      V v_s_24319 = heff_field(v_x2_24317, 1);
      heff_take_n(v_x2_24317, 3ULL, 2);
      V v_m_24320 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24321 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_s_24319}));
      switch (heff_tag_of(v_x2_24321)) {
      case TAG_MkPair: {
        V v_x_24322 = heff_field(v_x2_24321, 0);
        V v_s_24323 = heff_field(v_x2_24321, 1);
        heff_take_n(v_x2_24321, 3ULL, 2);
        V v_t_24324 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str71), heff_strAppend(v_x_24322, ((V)&g_heff_2ecompile_2eemitc_2etestC_str72)));
        V v_t_24325 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str73), heff_strAppend(v_x_24318, v_t_24324));
        V v_t_24326 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str74), heff_strAppend(v_x_24314, v_t_24325));
        return heff_tag_at_n(v_ru_24x2_24313_24MkPair, TAG_MkPair, 2, (V[]){v_t_24326, v_s_24323});
      }
      default: return heff_nomatch(v_x2_24321);
      }
    }
    default: return heff_nomatch(v_x2_24317);
    }
  }
  default: return heff_nomatch(v_x2_24313);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam23(V self, V *args) {
  V v_s_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_s_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_s_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_m_24334 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24335 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_s_24333}));
    switch (heff_tag_of(v_x2_24335)) {
    case TAG_MkPair: {
      V v_x_24336 = heff_field(v_x2_24335, 0);
      V v_s_24337 = heff_field(v_x2_24335, 1);
      heff_take_n(v_x2_24335, 3ULL, 2);
      V v_t_24338 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str75), heff_strAppend(v_x_24336, ((V)&g_heff_2ecompile_2eemitc_2etestC_str76)));
      V v_t_24339 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str77), heff_strAppend(v_x_24332, v_t_24338));
      return heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_MkPair, 2, (V[]){v_t_24339, v_s_24337});
    }
    default: return heff_nomatch(v_x2_24335);
    }
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam24(V self, V *args) {
  V v_s_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_s_24341}));
  switch (heff_tag_of(v_x2_24342)) {
  case TAG_MkPair: {
    V v_x_24343 = heff_field(v_x2_24342, 0);
    V v_s_24344 = heff_field(v_x2_24342, 1);
    V v_ru_24x2_24342_24MkPair = heff_take_reuse_n(v_x2_24342, 3ULL, 2);
    V v_m_24345 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24346 = heff_tr(heff_call(v_m_24345, 1, (V[]){v_s_24344}));
    switch (heff_tag_of(v_x2_24346)) {
    case TAG_MkPair: {
      V v_x_24347 = heff_field(v_x2_24346, 0);
      V v_s_24348 = heff_field(v_x2_24346, 1);
      heff_take_n(v_x2_24346, 3ULL, 2);
      V v_m_24349 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24350 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_s_24348}));
      switch (heff_tag_of(v_x2_24350)) {
      case TAG_MkPair: {
        V v_x_24351 = heff_field(v_x2_24350, 0);
        V v_s_24352 = heff_field(v_x2_24350, 1);
        heff_take_n(v_x2_24350, 3ULL, 2);
        V v_t_24353 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str78), heff_strAppend(v_x_24351, ((V)&g_heff_2ecompile_2eemitc_2etestC_str79)));
        V v_t_24354 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str80), heff_strAppend(v_x_24347, v_t_24353));
        V v_t_24355 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str81), heff_strAppend(v_x_24343, v_t_24354));
        return heff_tag_at_n(v_ru_24x2_24342_24MkPair, TAG_MkPair, 2, (V[]){v_t_24355, v_s_24352});
      }
      default: return heff_nomatch(v_x2_24350);
      }
    }
    default: return heff_nomatch(v_x2_24346);
    }
  }
  default: return heff_nomatch(v_x2_24342);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam25(V self, V *args) {
  V v_s_24359 = args[0];
  V v_m_24358 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24360 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_s_24359}));
  switch (heff_tag_of(v_x2_24360)) {
  case TAG_MkPair: {
    V v_x_24361 = heff_field(v_x2_24360, 0);
    V v_s_24362 = heff_field(v_x2_24360, 1);
    V v_ru_24x2_24360_24MkPair = heff_take_reuse_n(v_x2_24360, 3ULL, 2);
    V v_m_24363 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24364 = heff_tr(heff_call(v_m_24363, 1, (V[]){v_s_24362}));
    switch (heff_tag_of(v_x2_24364)) {
    case TAG_MkPair: {
      V v_x_24365 = heff_field(v_x2_24364, 0);
      V v_s_24366 = heff_field(v_x2_24364, 1);
      heff_take_n(v_x2_24364, 3ULL, 2);
      V v_m_24367 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24368 = heff_tr(heff_call(v_m_24367, 1, (V[]){v_s_24366}));
      switch (heff_tag_of(v_x2_24368)) {
      case TAG_MkPair: {
        V v_x_24369 = heff_field(v_x2_24368, 0);
        V v_s_24370 = heff_field(v_x2_24368, 1);
        heff_take_n(v_x2_24368, 3ULL, 2);
        V v_t_24371 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str82), heff_strAppend(v_x_24369, ((V)&g_heff_2ecompile_2eemitc_2etestC_str83)));
        V v_t_24372 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str84), heff_strAppend(v_x_24365, v_t_24371));
        V v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str85), heff_strAppend(v_x_24361, v_t_24372));
        return heff_tag_at_n(v_ru_24x2_24360_24MkPair, TAG_MkPair, 2, (V[]){v_t_24373, v_s_24370});
      }
      default: return heff_nomatch(v_x2_24368);
      }
    }
    default: return heff_nomatch(v_x2_24364);
    }
  }
  default: return heff_nomatch(v_x2_24360);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam26(V self, V *args) {
  V v_s_24377 = args[0];
  V v_m_24376 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24378 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_s_24377}));
  switch (heff_tag_of(v_x2_24378)) {
  case TAG_MkPair: {
    V v_x_24379 = heff_field(v_x2_24378, 0);
    V v_s_24380 = heff_field(v_x2_24378, 1);
    V v_ru_24x2_24378_24MkPair = heff_take_reuse_n(v_x2_24378, 3ULL, 2);
    V v_m_24381 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24382 = heff_tr(heff_call(v_m_24381, 1, (V[]){v_s_24380}));
    switch (heff_tag_of(v_x2_24382)) {
    case TAG_MkPair: {
      V v_x_24383 = heff_field(v_x2_24382, 0);
      V v_s_24384 = heff_field(v_x2_24382, 1);
      heff_take_n(v_x2_24382, 3ULL, 2);
      V v_m_24385 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24386 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_s_24384}));
      switch (heff_tag_of(v_x2_24386)) {
      case TAG_MkPair: {
        V v_x_24387 = heff_field(v_x2_24386, 0);
        V v_s_24388 = heff_field(v_x2_24386, 1);
        heff_take_n(v_x2_24386, 3ULL, 2);
        V v_t_24389 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str86), heff_strAppend(v_x_24387, ((V)&g_heff_2ecompile_2eemitc_2etestC_str87)));
        V v_t_24390 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str88), heff_strAppend(v_x_24383, v_t_24389));
        V v_t_24391 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str89), heff_strAppend(v_x_24379, v_t_24390));
        return heff_tag_at_n(v_ru_24x2_24378_24MkPair, TAG_MkPair, 2, (V[]){v_t_24391, v_s_24388});
      }
      default: return heff_nomatch(v_x2_24386);
      }
    }
    default: return heff_nomatch(v_x2_24382);
    }
  }
  default: return heff_nomatch(v_x2_24378);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam27(V self, V *args) {
  V v_s_24394 = args[0];
  V v_m_24393 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24395 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_s_24394}));
  switch (heff_tag_of(v_x2_24395)) {
  case TAG_MkPair: {
    V v_x_24396 = heff_field(v_x2_24395, 0);
    V v_s_24397 = heff_field(v_x2_24395, 1);
    V v_ru_24x2_24395_24MkPair = heff_take_reuse_n(v_x2_24395, 3ULL, 2);
    V v_m_24398 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24399 = heff_tr(heff_call(v_m_24398, 1, (V[]){v_s_24397}));
    switch (heff_tag_of(v_x2_24399)) {
    case TAG_MkPair: {
      V v_x_24400 = heff_field(v_x2_24399, 0);
      V v_s_24401 = heff_field(v_x2_24399, 1);
      heff_take_n(v_x2_24399, 3ULL, 2);
      V v_m_24402 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24403 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_s_24401}));
      switch (heff_tag_of(v_x2_24403)) {
      case TAG_MkPair: {
        V v_x_24404 = heff_field(v_x2_24403, 0);
        V v_s_24405 = heff_field(v_x2_24403, 1);
        heff_take_n(v_x2_24403, 3ULL, 2);
        V v_t_24406 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str90), heff_strAppend(v_x_24404, ((V)&g_heff_2ecompile_2eemitc_2etestC_str91)));
        V v_t_24407 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str92), heff_strAppend(v_x_24400, v_t_24406));
        V v_t_24408 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str93), heff_strAppend(v_x_24396, v_t_24407));
        return heff_tag_at_n(v_ru_24x2_24395_24MkPair, TAG_MkPair, 2, (V[]){v_t_24408, v_s_24405});
      }
      default: return heff_nomatch(v_x2_24403);
      }
    }
    default: return heff_nomatch(v_x2_24399);
    }
  }
  default: return heff_nomatch(v_x2_24395);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam28(V self, V *args) {
  V v_s_24411 = args[0];
  V v_m_24410 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24412 = heff_tr(heff_call(v_m_24410, 1, (V[]){v_s_24411}));
  switch (heff_tag_of(v_x2_24412)) {
  case TAG_MkPair: {
    V v_x_24413 = heff_field(v_x2_24412, 0);
    V v_s_24414 = heff_field(v_x2_24412, 1);
    V v_ru_24x2_24412_24MkPair = heff_take_reuse_n(v_x2_24412, 3ULL, 2);
    V v_m_24415 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24416 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_s_24414}));
    switch (heff_tag_of(v_x2_24416)) {
    case TAG_MkPair: {
      V v_x_24417 = heff_field(v_x2_24416, 0);
      V v_s_24418 = heff_field(v_x2_24416, 1);
      heff_take_n(v_x2_24416, 3ULL, 2);
      V v_m_24419 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24420 = heff_tr(heff_call(v_m_24419, 1, (V[]){v_s_24418}));
      switch (heff_tag_of(v_x2_24420)) {
      case TAG_MkPair: {
        V v_x_24421 = heff_field(v_x2_24420, 0);
        V v_s_24422 = heff_field(v_x2_24420, 1);
        heff_take_n(v_x2_24420, 3ULL, 2);
        V v_t_24423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str94), heff_strAppend(v_x_24421, ((V)&g_heff_2ecompile_2eemitc_2etestC_str95)));
        V v_t_24424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str96), heff_strAppend(v_x_24417, v_t_24423));
        V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str97), heff_strAppend(v_x_24413, v_t_24424));
        return heff_tag_at_n(v_ru_24x2_24412_24MkPair, TAG_MkPair, 2, (V[]){v_t_24425, v_s_24422});
      }
      default: return heff_nomatch(v_x2_24420);
      }
    }
    default: return heff_nomatch(v_x2_24416);
    }
  }
  default: return heff_nomatch(v_x2_24412);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam29(V self, V *args) {
  V v_s_24430 = args[0];
  V v_m_24429 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24431 = heff_tr(heff_call(v_m_24429, 1, (V[]){v_s_24430}));
  switch (heff_tag_of(v_x2_24431)) {
  case TAG_MkPair: {
    V v_x_24432 = heff_field(v_x2_24431, 0);
    V v_s_24433 = heff_field(v_x2_24431, 1);
    V v_ru_24x2_24431_24MkPair = heff_take_reuse_n(v_x2_24431, 3ULL, 2);
    V v_m_24434 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24435 = heff_tr(heff_call(v_m_24434, 1, (V[]){v_s_24433}));
    switch (heff_tag_of(v_x2_24435)) {
    case TAG_MkPair: {
      V v_x_24436 = heff_field(v_x2_24435, 0);
      V v_s_24437 = heff_field(v_x2_24435, 1);
      heff_take_n(v_x2_24435, 3ULL, 2);
      V v_m_24438 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24439 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_s_24437}));
      switch (heff_tag_of(v_x2_24439)) {
      case TAG_MkPair: {
        V v_x_24440 = heff_field(v_x2_24439, 0);
        V v_s_24441 = heff_field(v_x2_24439, 1);
        heff_take_n(v_x2_24439, 3ULL, 2);
        V v_t_24442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str98), heff_strAppend(v_x_24440, ((V)&g_heff_2ecompile_2eemitc_2etestC_str99)));
        V v_t_24443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str100), heff_strAppend(v_x_24436, v_t_24442));
        V v_t_24444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str101), heff_strAppend(v_x_24432, v_t_24443));
        return heff_tag_at_n(v_ru_24x2_24431_24MkPair, TAG_MkPair, 2, (V[]){v_t_24444, v_s_24441});
      }
      default: return heff_nomatch(v_x2_24439);
      }
    }
    default: return heff_nomatch(v_x2_24435);
    }
  }
  default: return heff_nomatch(v_x2_24431);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam30(V self, V *args) {
  V v_s_24450 = args[0];
  V v_m_24449 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24451 = heff_tr(heff_call(v_m_24449, 1, (V[]){v_s_24450}));
  switch (heff_tag_of(v_x2_24451)) {
  case TAG_MkPair: {
    V v_x_24452 = heff_field(v_x2_24451, 0);
    V v_s_24453 = heff_field(v_x2_24451, 1);
    V v_ru_24x2_24451_24MkPair = heff_take_reuse_n(v_x2_24451, 3ULL, 2);
    V v_m_24454 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24455 = heff_tr(heff_call(v_m_24454, 1, (V[]){v_s_24453}));
    switch (heff_tag_of(v_x2_24455)) {
    case TAG_MkPair: {
      V v_x_24456 = heff_field(v_x2_24455, 0);
      V v_s_24457 = heff_field(v_x2_24455, 1);
      heff_take_n(v_x2_24455, 3ULL, 2);
      V v_m_24458 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24459 = heff_tr(heff_call(v_m_24458, 1, (V[]){v_s_24457}));
      switch (heff_tag_of(v_x2_24459)) {
      case TAG_MkPair: {
        V v_x_24460 = heff_field(v_x2_24459, 0);
        V v_s_24461 = heff_field(v_x2_24459, 1);
        heff_take_n(v_x2_24459, 3ULL, 2);
        V v_t_24462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str102), heff_strAppend(v_x_24460, ((V)&g_heff_2ecompile_2eemitc_2etestC_str103)));
        V v_t_24463 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str104), heff_strAppend(v_x_24456, v_t_24462));
        V v_t_24464 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str105), heff_strAppend(v_x_24452, v_t_24463));
        return heff_tag_at_n(v_ru_24x2_24451_24MkPair, TAG_MkPair, 2, (V[]){v_t_24464, v_s_24461});
      }
      default: return heff_nomatch(v_x2_24459);
      }
    }
    default: return heff_nomatch(v_x2_24455);
    }
  }
  default: return heff_nomatch(v_x2_24451);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam31(V self, V *args) {
  V v_s_24467 = args[0];
  V v_m_24466 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24468 = heff_tr(heff_call(v_m_24466, 1, (V[]){v_s_24467}));
  switch (heff_tag_of(v_x2_24468)) {
  case TAG_MkPair: {
    V v_x_24469 = heff_field(v_x2_24468, 0);
    V v_s_24470 = heff_field(v_x2_24468, 1);
    V v_ru_24x2_24468_24MkPair = heff_take_reuse_n(v_x2_24468, 3ULL, 2);
    V v_m_24471 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24472 = heff_tr(heff_call(v_m_24471, 1, (V[]){v_s_24470}));
    switch (heff_tag_of(v_x2_24472)) {
    case TAG_MkPair: {
      V v_x_24473 = heff_field(v_x2_24472, 0);
      V v_s_24474 = heff_field(v_x2_24472, 1);
      heff_take_n(v_x2_24472, 3ULL, 2);
      V v_t_24475 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str106), heff_strAppend(v_x_24473, ((V)&g_heff_2ecompile_2eemitc_2etestC_str107)));
      V v_t_24476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str108), heff_strAppend(v_x_24469, v_t_24475));
      return heff_tag_at_n(v_ru_24x2_24468_24MkPair, TAG_MkPair, 2, (V[]){v_t_24476, v_s_24474});
    }
    default: return heff_nomatch(v_x2_24472);
    }
  }
  default: return heff_nomatch(v_x2_24468);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam32(V self, V *args) {
  V v_s_24478 = args[0];
  V v_m_24477 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24479 = heff_tr(heff_call(v_m_24477, 1, (V[]){v_s_24478}));
  switch (heff_tag_of(v_x2_24479)) {
  case TAG_MkPair: {
    V v_x_24480 = heff_field(v_x2_24479, 0);
    V v_s_24481 = heff_field(v_x2_24479, 1);
    V v_ru_24x2_24479_24MkPair = heff_take_reuse_n(v_x2_24479, 3ULL, 2);
    V v_m_24482 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24483 = heff_tr(heff_call(v_m_24482, 1, (V[]){v_s_24481}));
    switch (heff_tag_of(v_x2_24483)) {
    case TAG_MkPair: {
      V v_x_24484 = heff_field(v_x2_24483, 0);
      V v_s_24485 = heff_field(v_x2_24483, 1);
      heff_take_n(v_x2_24483, 3ULL, 2);
      V v_m_24486 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24487 = heff_tr(heff_call(v_m_24486, 1, (V[]){v_s_24485}));
      switch (heff_tag_of(v_x2_24487)) {
      case TAG_MkPair: {
        V v_x_24488 = heff_field(v_x2_24487, 0);
        V v_s_24489 = heff_field(v_x2_24487, 1);
        heff_take_n(v_x2_24487, 3ULL, 2);
        V v_t_24490 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str109), heff_strAppend(v_x_24488, ((V)&g_heff_2ecompile_2eemitc_2etestC_str110)));
        V v_t_24491 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str111), heff_strAppend(v_x_24484, v_t_24490));
        V v_t_24492 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str112), heff_strAppend(v_x_24480, v_t_24491));
        return heff_tag_at_n(v_ru_24x2_24479_24MkPair, TAG_MkPair, 2, (V[]){v_t_24492, v_s_24489});
      }
      default: return heff_nomatch(v_x2_24487);
      }
    }
    default: return heff_nomatch(v_x2_24483);
    }
  }
  default: return heff_nomatch(v_x2_24479);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam33(V self, V *args) {
  V v_s_24496 = args[0];
  V v_m_24495 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24497 = heff_tr(heff_call(v_m_24495, 1, (V[]){v_s_24496}));
  switch (heff_tag_of(v_x2_24497)) {
  case TAG_MkPair: {
    V v_x_24498 = heff_field(v_x2_24497, 0);
    V v_s_24499 = heff_field(v_x2_24497, 1);
    V v_ru_24x2_24497_24MkPair = heff_take_reuse_n(v_x2_24497, 3ULL, 2);
    V v_m_24500 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24501 = heff_tr(heff_call(v_m_24500, 1, (V[]){v_s_24499}));
    switch (heff_tag_of(v_x2_24501)) {
    case TAG_MkPair: {
      V v_x_24502 = heff_field(v_x2_24501, 0);
      V v_s_24503 = heff_field(v_x2_24501, 1);
      heff_take_n(v_x2_24501, 3ULL, 2);
      V v_m_24504 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24505 = heff_tr(heff_call(v_m_24504, 1, (V[]){v_s_24503}));
      switch (heff_tag_of(v_x2_24505)) {
      case TAG_MkPair: {
        V v_x_24506 = heff_field(v_x2_24505, 0);
        V v_s_24507 = heff_field(v_x2_24505, 1);
        heff_take_n(v_x2_24505, 3ULL, 2);
        V v_t_24508 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str113), heff_strAppend(v_x_24506, ((V)&g_heff_2ecompile_2eemitc_2etestC_str114)));
        V v_t_24509 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str115), heff_strAppend(v_x_24502, v_t_24508));
        V v_t_24510 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str116), heff_strAppend(v_x_24498, v_t_24509));
        return heff_tag_at_n(v_ru_24x2_24497_24MkPair, TAG_MkPair, 2, (V[]){v_t_24510, v_s_24507});
      }
      default: return heff_nomatch(v_x2_24505);
      }
    }
    default: return heff_nomatch(v_x2_24501);
    }
  }
  default: return heff_nomatch(v_x2_24497);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam34(V self, V *args) {
  V v_s_24514 = args[0];
  V v_m_24513 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24515 = heff_tr(heff_call(v_m_24513, 1, (V[]){v_s_24514}));
  switch (heff_tag_of(v_x2_24515)) {
  case TAG_MkPair: {
    V v_x_24516 = heff_field(v_x2_24515, 0);
    V v_s_24517 = heff_field(v_x2_24515, 1);
    V v_ru_24x2_24515_24MkPair = heff_take_reuse_n(v_x2_24515, 3ULL, 2);
    V v_m_24518 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24519 = heff_tr(heff_call(v_m_24518, 1, (V[]){v_s_24517}));
    switch (heff_tag_of(v_x2_24519)) {
    case TAG_MkPair: {
      V v_x_24520 = heff_field(v_x2_24519, 0);
      V v_s_24521 = heff_field(v_x2_24519, 1);
      heff_take_n(v_x2_24519, 3ULL, 2);
      V v_m_24522 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24523 = heff_tr(heff_call(v_m_24522, 1, (V[]){v_s_24521}));
      switch (heff_tag_of(v_x2_24523)) {
      case TAG_MkPair: {
        V v_x_24524 = heff_field(v_x2_24523, 0);
        V v_s_24525 = heff_field(v_x2_24523, 1);
        heff_take_n(v_x2_24523, 3ULL, 2);
        V v_t_24526 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str117), heff_strAppend(v_x_24524, ((V)&g_heff_2ecompile_2eemitc_2etestC_str118)));
        V v_t_24527 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str119), heff_strAppend(v_x_24520, v_t_24526));
        V v_t_24528 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str120), heff_strAppend(v_x_24516, v_t_24527));
        return heff_tag_at_n(v_ru_24x2_24515_24MkPair, TAG_MkPair, 2, (V[]){v_t_24528, v_s_24525});
      }
      default: return heff_nomatch(v_x2_24523);
      }
    }
    default: return heff_nomatch(v_x2_24519);
    }
  }
  default: return heff_nomatch(v_x2_24515);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam35(V self, V *args) {
  V v_s_24531 = args[0];
  V v_m_24530 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24532 = heff_tr(heff_call(v_m_24530, 1, (V[]){v_s_24531}));
  switch (heff_tag_of(v_x2_24532)) {
  case TAG_MkPair: {
    V v_x_24533 = heff_field(v_x2_24532, 0);
    V v_s_24534 = heff_field(v_x2_24532, 1);
    V v_ru_24x2_24532_24MkPair = heff_take_reuse_n(v_x2_24532, 3ULL, 2);
    V v_m_24535 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24536 = heff_tr(heff_call(v_m_24535, 1, (V[]){v_s_24534}));
    switch (heff_tag_of(v_x2_24536)) {
    case TAG_MkPair: {
      V v_x_24537 = heff_field(v_x2_24536, 0);
      V v_s_24538 = heff_field(v_x2_24536, 1);
      heff_take_n(v_x2_24536, 3ULL, 2);
      V v_m_24539 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24540 = heff_tr(heff_call(v_m_24539, 1, (V[]){v_s_24538}));
      switch (heff_tag_of(v_x2_24540)) {
      case TAG_MkPair: {
        V v_x_24541 = heff_field(v_x2_24540, 0);
        V v_s_24542 = heff_field(v_x2_24540, 1);
        heff_take_n(v_x2_24540, 3ULL, 2);
        V v_t_24543 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str121), heff_strAppend(v_x_24541, ((V)&g_heff_2ecompile_2eemitc_2etestC_str122)));
        V v_t_24544 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str123), heff_strAppend(v_x_24537, v_t_24543));
        V v_t_24545 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str124), heff_strAppend(v_x_24533, v_t_24544));
        return heff_tag_at_n(v_ru_24x2_24532_24MkPair, TAG_MkPair, 2, (V[]){v_t_24545, v_s_24542});
      }
      default: return heff_nomatch(v_x2_24540);
      }
    }
    default: return heff_nomatch(v_x2_24536);
    }
  }
  default: return heff_nomatch(v_x2_24532);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam36(V self, V *args) {
  V v_s_24548 = args[0];
  V v_m_24547 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24549 = heff_tr(heff_call(v_m_24547, 1, (V[]){v_s_24548}));
  switch (heff_tag_of(v_x2_24549)) {
  case TAG_MkPair: {
    V v_x_24550 = heff_field(v_x2_24549, 0);
    V v_s_24551 = heff_field(v_x2_24549, 1);
    V v_ru_24x2_24549_24MkPair = heff_take_reuse_n(v_x2_24549, 3ULL, 2);
    V v_m_24552 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24553 = heff_tr(heff_call(v_m_24552, 1, (V[]){v_s_24551}));
    switch (heff_tag_of(v_x2_24553)) {
    case TAG_MkPair: {
      V v_x_24554 = heff_field(v_x2_24553, 0);
      V v_s_24555 = heff_field(v_x2_24553, 1);
      heff_take_n(v_x2_24553, 3ULL, 2);
      V v_m_24556 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24557 = heff_tr(heff_call(v_m_24556, 1, (V[]){v_s_24555}));
      switch (heff_tag_of(v_x2_24557)) {
      case TAG_MkPair: {
        V v_x_24558 = heff_field(v_x2_24557, 0);
        V v_s_24559 = heff_field(v_x2_24557, 1);
        heff_take_n(v_x2_24557, 3ULL, 2);
        V v_t_24560 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str125), heff_strAppend(v_x_24558, ((V)&g_heff_2ecompile_2eemitc_2etestC_str126)));
        V v_t_24561 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str127), heff_strAppend(v_x_24554, v_t_24560));
        V v_t_24562 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str128), heff_strAppend(v_x_24550, v_t_24561));
        return heff_tag_at_n(v_ru_24x2_24549_24MkPair, TAG_MkPair, 2, (V[]){v_t_24562, v_s_24559});
      }
      default: return heff_nomatch(v_x2_24557);
      }
    }
    default: return heff_nomatch(v_x2_24553);
    }
  }
  default: return heff_nomatch(v_x2_24549);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam37(V self, V *args) {
  V v_s_24567 = args[0];
  V v_m_24566 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24568 = heff_tr(heff_call(v_m_24566, 1, (V[]){v_s_24567}));
  switch (heff_tag_of(v_x2_24568)) {
  case TAG_MkPair: {
    V v_x_24569 = heff_field(v_x2_24568, 0);
    V v_s_24570 = heff_field(v_x2_24568, 1);
    V v_ru_24x2_24568_24MkPair = heff_take_reuse_n(v_x2_24568, 3ULL, 2);
    V v_m_24571 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24572 = heff_tr(heff_call(v_m_24571, 1, (V[]){v_s_24570}));
    switch (heff_tag_of(v_x2_24572)) {
    case TAG_MkPair: {
      V v_x_24573 = heff_field(v_x2_24572, 0);
      V v_s_24574 = heff_field(v_x2_24572, 1);
      heff_take_n(v_x2_24572, 3ULL, 2);
      V v_m_24575 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24576 = heff_tr(heff_call(v_m_24575, 1, (V[]){v_s_24574}));
      switch (heff_tag_of(v_x2_24576)) {
      case TAG_MkPair: {
        V v_x_24577 = heff_field(v_x2_24576, 0);
        V v_s_24578 = heff_field(v_x2_24576, 1);
        heff_take_n(v_x2_24576, 3ULL, 2);
        V v_t_24579 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str129), heff_strAppend(v_x_24577, ((V)&g_heff_2ecompile_2eemitc_2etestC_str130)));
        V v_t_24580 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str131), heff_strAppend(v_x_24573, v_t_24579));
        V v_t_24581 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str132), heff_strAppend(v_x_24569, v_t_24580));
        return heff_tag_at_n(v_ru_24x2_24568_24MkPair, TAG_MkPair, 2, (V[]){v_t_24581, v_s_24578});
      }
      default: return heff_nomatch(v_x2_24576);
      }
    }
    default: return heff_nomatch(v_x2_24572);
    }
  }
  default: return heff_nomatch(v_x2_24568);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam38(V self, V *args) {
  V v_s_24587 = args[0];
  V v_m_24586 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24588 = heff_tr(heff_call(v_m_24586, 1, (V[]){v_s_24587}));
  switch (heff_tag_of(v_x2_24588)) {
  case TAG_MkPair: {
    V v_x_24589 = heff_field(v_x2_24588, 0);
    V v_s_24590 = heff_field(v_x2_24588, 1);
    V v_ru_24x2_24588_24MkPair = heff_take_reuse_n(v_x2_24588, 3ULL, 2);
    V v_m_24591 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24592 = heff_tr(heff_call(v_m_24591, 1, (V[]){v_s_24590}));
    switch (heff_tag_of(v_x2_24592)) {
    case TAG_MkPair: {
      V v_x_24593 = heff_field(v_x2_24592, 0);
      V v_s_24594 = heff_field(v_x2_24592, 1);
      heff_take_n(v_x2_24592, 3ULL, 2);
      V v_m_24595 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24596 = heff_tr(heff_call(v_m_24595, 1, (V[]){v_s_24594}));
      switch (heff_tag_of(v_x2_24596)) {
      case TAG_MkPair: {
        V v_x_24597 = heff_field(v_x2_24596, 0);
        V v_s_24598 = heff_field(v_x2_24596, 1);
        heff_take_n(v_x2_24596, 3ULL, 2);
        V v_t_24599 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str133), heff_strAppend(v_x_24597, ((V)&g_heff_2ecompile_2eemitc_2etestC_str134)));
        V v_t_24600 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str135), heff_strAppend(v_x_24593, v_t_24599));
        V v_t_24601 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str136), heff_strAppend(v_x_24589, v_t_24600));
        return heff_tag_at_n(v_ru_24x2_24588_24MkPair, TAG_MkPair, 2, (V[]){v_t_24601, v_s_24598});
      }
      default: return heff_nomatch(v_x2_24596);
      }
    }
    default: return heff_nomatch(v_x2_24592);
    }
  }
  default: return heff_nomatch(v_x2_24588);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam39(V self, V *args) {
  V v_s_24604 = args[0];
  V v_m_24603 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24605 = heff_tr(heff_call(v_m_24603, 1, (V[]){v_s_24604}));
  switch (heff_tag_of(v_x2_24605)) {
  case TAG_MkPair: {
    V v_x_24606 = heff_field(v_x2_24605, 0);
    V v_s_24607 = heff_field(v_x2_24605, 1);
    V v_ru_24x2_24605_24MkPair = heff_take_reuse_n(v_x2_24605, 3ULL, 2);
    V v_m_24608 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24609 = heff_tr(heff_call(v_m_24608, 1, (V[]){v_s_24607}));
    switch (heff_tag_of(v_x2_24609)) {
    case TAG_MkPair: {
      V v_x_24610 = heff_field(v_x2_24609, 0);
      V v_s_24611 = heff_field(v_x2_24609, 1);
      heff_take_n(v_x2_24609, 3ULL, 2);
      V v_t_24612 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str137), heff_strAppend(v_x_24610, ((V)&g_heff_2ecompile_2eemitc_2etestC_str138)));
      V v_t_24613 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str139), heff_strAppend(v_x_24606, v_t_24612));
      return heff_tag_at_n(v_ru_24x2_24605_24MkPair, TAG_MkPair, 2, (V[]){v_t_24613, v_s_24611});
    }
    default: return heff_nomatch(v_x2_24609);
    }
  }
  default: return heff_nomatch(v_x2_24605);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam40(V self, V *args) {
  V v_s_24615 = args[0];
  V v_m_24614 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24616 = heff_tr(heff_call(v_m_24614, 1, (V[]){v_s_24615}));
  switch (heff_tag_of(v_x2_24616)) {
  case TAG_MkPair: {
    V v_x_24617 = heff_field(v_x2_24616, 0);
    V v_s_24618 = heff_field(v_x2_24616, 1);
    V v_ru_24x2_24616_24MkPair = heff_take_reuse_n(v_x2_24616, 3ULL, 2);
    V v_m_24619 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24620 = heff_tr(heff_call(v_m_24619, 1, (V[]){v_s_24618}));
    switch (heff_tag_of(v_x2_24620)) {
    case TAG_MkPair: {
      V v_x_24621 = heff_field(v_x2_24620, 0);
      V v_s_24622 = heff_field(v_x2_24620, 1);
      heff_take_n(v_x2_24620, 3ULL, 2);
      V v_m_24623 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24624 = heff_tr(heff_call(v_m_24623, 1, (V[]){v_s_24622}));
      switch (heff_tag_of(v_x2_24624)) {
      case TAG_MkPair: {
        V v_x_24625 = heff_field(v_x2_24624, 0);
        V v_s_24626 = heff_field(v_x2_24624, 1);
        heff_take_n(v_x2_24624, 3ULL, 2);
        V v_t_24627 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str140), heff_strAppend(v_x_24625, ((V)&g_heff_2ecompile_2eemitc_2etestC_str141)));
        V v_t_24628 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str142), heff_strAppend(v_x_24621, v_t_24627));
        V v_t_24629 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str143), heff_strAppend(v_x_24617, v_t_24628));
        return heff_tag_at_n(v_ru_24x2_24616_24MkPair, TAG_MkPair, 2, (V[]){v_t_24629, v_s_24626});
      }
      default: return heff_nomatch(v_x2_24624);
      }
    }
    default: return heff_nomatch(v_x2_24620);
    }
  }
  default: return heff_nomatch(v_x2_24616);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam41(V self, V *args) {
  V v_s_24633 = args[0];
  V v_m_24632 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24634 = heff_tr(heff_call(v_m_24632, 1, (V[]){v_s_24633}));
  switch (heff_tag_of(v_x2_24634)) {
  case TAG_MkPair: {
    V v_x_24635 = heff_field(v_x2_24634, 0);
    V v_s_24636 = heff_field(v_x2_24634, 1);
    V v_ru_24x2_24634_24MkPair = heff_take_reuse_n(v_x2_24634, 3ULL, 2);
    V v_m_24637 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24638 = heff_tr(heff_call(v_m_24637, 1, (V[]){v_s_24636}));
    switch (heff_tag_of(v_x2_24638)) {
    case TAG_MkPair: {
      V v_x_24639 = heff_field(v_x2_24638, 0);
      V v_s_24640 = heff_field(v_x2_24638, 1);
      heff_take_n(v_x2_24638, 3ULL, 2);
      V v_m_24641 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24642 = heff_tr(heff_call(v_m_24641, 1, (V[]){v_s_24640}));
      switch (heff_tag_of(v_x2_24642)) {
      case TAG_MkPair: {
        V v_x_24643 = heff_field(v_x2_24642, 0);
        V v_s_24644 = heff_field(v_x2_24642, 1);
        heff_take_n(v_x2_24642, 3ULL, 2);
        V v_t_24645 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str144), heff_strAppend(v_x_24643, ((V)&g_heff_2ecompile_2eemitc_2etestC_str145)));
        V v_t_24646 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str146), heff_strAppend(v_x_24639, v_t_24645));
        V v_t_24647 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str147), heff_strAppend(v_x_24635, v_t_24646));
        return heff_tag_at_n(v_ru_24x2_24634_24MkPair, TAG_MkPair, 2, (V[]){v_t_24647, v_s_24644});
      }
      default: return heff_nomatch(v_x2_24642);
      }
    }
    default: return heff_nomatch(v_x2_24638);
    }
  }
  default: return heff_nomatch(v_x2_24634);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam42(V self, V *args) {
  V v_s_24651 = args[0];
  V v_m_24650 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24652 = heff_tr(heff_call(v_m_24650, 1, (V[]){v_s_24651}));
  switch (heff_tag_of(v_x2_24652)) {
  case TAG_MkPair: {
    V v_x_24653 = heff_field(v_x2_24652, 0);
    V v_s_24654 = heff_field(v_x2_24652, 1);
    V v_ru_24x2_24652_24MkPair = heff_take_reuse_n(v_x2_24652, 3ULL, 2);
    V v_m_24655 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24656 = heff_tr(heff_call(v_m_24655, 1, (V[]){v_s_24654}));
    switch (heff_tag_of(v_x2_24656)) {
    case TAG_MkPair: {
      V v_x_24657 = heff_field(v_x2_24656, 0);
      V v_s_24658 = heff_field(v_x2_24656, 1);
      heff_take_n(v_x2_24656, 3ULL, 2);
      V v_m_24659 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24660 = heff_tr(heff_call(v_m_24659, 1, (V[]){v_s_24658}));
      switch (heff_tag_of(v_x2_24660)) {
      case TAG_MkPair: {
        V v_x_24661 = heff_field(v_x2_24660, 0);
        V v_s_24662 = heff_field(v_x2_24660, 1);
        heff_take_n(v_x2_24660, 3ULL, 2);
        V v_t_24663 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str148), heff_strAppend(v_x_24661, ((V)&g_heff_2ecompile_2eemitc_2etestC_str149)));
        V v_t_24664 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str150), heff_strAppend(v_x_24657, v_t_24663));
        V v_t_24665 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str151), heff_strAppend(v_x_24653, v_t_24664));
        return heff_tag_at_n(v_ru_24x2_24652_24MkPair, TAG_MkPair, 2, (V[]){v_t_24665, v_s_24662});
      }
      default: return heff_nomatch(v_x2_24660);
      }
    }
    default: return heff_nomatch(v_x2_24656);
    }
  }
  default: return heff_nomatch(v_x2_24652);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam43(V self, V *args) {
  V v_s_24668 = args[0];
  V v_m_24667 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24669 = heff_tr(heff_call(v_m_24667, 1, (V[]){v_s_24668}));
  switch (heff_tag_of(v_x2_24669)) {
  case TAG_MkPair: {
    V v_x_24670 = heff_field(v_x2_24669, 0);
    V v_s_24671 = heff_field(v_x2_24669, 1);
    V v_ru_24x2_24669_24MkPair = heff_take_reuse_n(v_x2_24669, 3ULL, 2);
    V v_m_24672 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24673 = heff_tr(heff_call(v_m_24672, 1, (V[]){v_s_24671}));
    switch (heff_tag_of(v_x2_24673)) {
    case TAG_MkPair: {
      V v_x_24674 = heff_field(v_x2_24673, 0);
      V v_s_24675 = heff_field(v_x2_24673, 1);
      heff_take_n(v_x2_24673, 3ULL, 2);
      V v_m_24676 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24677 = heff_tr(heff_call(v_m_24676, 1, (V[]){v_s_24675}));
      switch (heff_tag_of(v_x2_24677)) {
      case TAG_MkPair: {
        V v_x_24678 = heff_field(v_x2_24677, 0);
        V v_s_24679 = heff_field(v_x2_24677, 1);
        heff_take_n(v_x2_24677, 3ULL, 2);
        V v_t_24680 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str152), heff_strAppend(v_x_24678, ((V)&g_heff_2ecompile_2eemitc_2etestC_str153)));
        V v_t_24681 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str154), heff_strAppend(v_x_24674, v_t_24680));
        V v_t_24682 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str155), heff_strAppend(v_x_24670, v_t_24681));
        return heff_tag_at_n(v_ru_24x2_24669_24MkPair, TAG_MkPair, 2, (V[]){v_t_24682, v_s_24679});
      }
      default: return heff_nomatch(v_x2_24677);
      }
    }
    default: return heff_nomatch(v_x2_24673);
    }
  }
  default: return heff_nomatch(v_x2_24669);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam44(V self, V *args) {
  V v_s_24685 = args[0];
  V v_m_24684 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24686 = heff_tr(heff_call(v_m_24684, 1, (V[]){v_s_24685}));
  switch (heff_tag_of(v_x2_24686)) {
  case TAG_MkPair: {
    V v_x_24687 = heff_field(v_x2_24686, 0);
    V v_s_24688 = heff_field(v_x2_24686, 1);
    V v_ru_24x2_24686_24MkPair = heff_take_reuse_n(v_x2_24686, 3ULL, 2);
    V v_m_24689 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24690 = heff_tr(heff_call(v_m_24689, 1, (V[]){v_s_24688}));
    switch (heff_tag_of(v_x2_24690)) {
    case TAG_MkPair: {
      V v_x_24691 = heff_field(v_x2_24690, 0);
      V v_s_24692 = heff_field(v_x2_24690, 1);
      heff_take_n(v_x2_24690, 3ULL, 2);
      V v_m_24693 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24694 = heff_tr(heff_call(v_m_24693, 1, (V[]){v_s_24692}));
      switch (heff_tag_of(v_x2_24694)) {
      case TAG_MkPair: {
        V v_x_24695 = heff_field(v_x2_24694, 0);
        V v_s_24696 = heff_field(v_x2_24694, 1);
        heff_take_n(v_x2_24694, 3ULL, 2);
        V v_t_24697 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str156), heff_strAppend(v_x_24695, ((V)&g_heff_2ecompile_2eemitc_2etestC_str157)));
        V v_t_24698 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str158), heff_strAppend(v_x_24691, v_t_24697));
        V v_t_24699 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str159), heff_strAppend(v_x_24687, v_t_24698));
        return heff_tag_at_n(v_ru_24x2_24686_24MkPair, TAG_MkPair, 2, (V[]){v_t_24699, v_s_24696});
      }
      default: return heff_nomatch(v_x2_24694);
      }
    }
    default: return heff_nomatch(v_x2_24690);
    }
  }
  default: return heff_nomatch(v_x2_24686);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam45(V self, V *args) {
  V v_s_24704 = args[0];
  V v_m_24703 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24705 = heff_tr(heff_call(v_m_24703, 1, (V[]){v_s_24704}));
  switch (heff_tag_of(v_x2_24705)) {
  case TAG_MkPair: {
    V v_x_24706 = heff_field(v_x2_24705, 0);
    V v_s_24707 = heff_field(v_x2_24705, 1);
    V v_ru_24x2_24705_24MkPair = heff_take_reuse_n(v_x2_24705, 3ULL, 2);
    V v_m_24708 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24709 = heff_tr(heff_call(v_m_24708, 1, (V[]){v_s_24707}));
    switch (heff_tag_of(v_x2_24709)) {
    case TAG_MkPair: {
      V v_x_24710 = heff_field(v_x2_24709, 0);
      V v_s_24711 = heff_field(v_x2_24709, 1);
      heff_take_n(v_x2_24709, 3ULL, 2);
      V v_m_24712 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24713 = heff_tr(heff_call(v_m_24712, 1, (V[]){v_s_24711}));
      switch (heff_tag_of(v_x2_24713)) {
      case TAG_MkPair: {
        V v_x_24714 = heff_field(v_x2_24713, 0);
        V v_s_24715 = heff_field(v_x2_24713, 1);
        heff_take_n(v_x2_24713, 3ULL, 2);
        V v_t_24716 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str160), heff_strAppend(v_x_24714, ((V)&g_heff_2ecompile_2eemitc_2etestC_str161)));
        V v_t_24717 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str162), heff_strAppend(v_x_24710, v_t_24716));
        V v_t_24718 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str163), heff_strAppend(v_x_24706, v_t_24717));
        return heff_tag_at_n(v_ru_24x2_24705_24MkPair, TAG_MkPair, 2, (V[]){v_t_24718, v_s_24715});
      }
      default: return heff_nomatch(v_x2_24713);
      }
    }
    default: return heff_nomatch(v_x2_24709);
    }
  }
  default: return heff_nomatch(v_x2_24705);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam46(V self, V *args) {
  V v_s_24724 = args[0];
  V v_m_24723 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24725 = heff_tr(heff_call(v_m_24723, 1, (V[]){v_s_24724}));
  switch (heff_tag_of(v_x2_24725)) {
  case TAG_MkPair: {
    V v_x_24726 = heff_field(v_x2_24725, 0);
    V v_s_24727 = heff_field(v_x2_24725, 1);
    V v_ru_24x2_24725_24MkPair = heff_take_reuse_n(v_x2_24725, 3ULL, 2);
    V v_m_24728 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24729 = heff_tr(heff_call(v_m_24728, 1, (V[]){v_s_24727}));
    switch (heff_tag_of(v_x2_24729)) {
    case TAG_MkPair: {
      V v_x_24730 = heff_field(v_x2_24729, 0);
      V v_s_24731 = heff_field(v_x2_24729, 1);
      heff_take_n(v_x2_24729, 3ULL, 2);
      V v_m_24732 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24733 = heff_tr(heff_call(v_m_24732, 1, (V[]){v_s_24731}));
      switch (heff_tag_of(v_x2_24733)) {
      case TAG_MkPair: {
        V v_x_24734 = heff_field(v_x2_24733, 0);
        V v_s_24735 = heff_field(v_x2_24733, 1);
        heff_take_n(v_x2_24733, 3ULL, 2);
        V v_t_24736 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str164), heff_strAppend(v_x_24734, ((V)&g_heff_2ecompile_2eemitc_2etestC_str165)));
        V v_t_24737 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str166), heff_strAppend(v_x_24730, v_t_24736));
        V v_t_24738 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str167), heff_strAppend(v_x_24726, v_t_24737));
        return heff_tag_at_n(v_ru_24x2_24725_24MkPair, TAG_MkPair, 2, (V[]){v_t_24738, v_s_24735});
      }
      default: return heff_nomatch(v_x2_24733);
      }
    }
    default: return heff_nomatch(v_x2_24729);
    }
  }
  default: return heff_nomatch(v_x2_24725);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam47(V self, V *args) {
  V v_s_24743 = args[0];
  V v_m_24742 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24744 = heff_tr(heff_call(v_m_24742, 1, (V[]){v_s_24743}));
  switch (heff_tag_of(v_x2_24744)) {
  case TAG_MkPair: {
    V v_x_24745 = heff_field(v_x2_24744, 0);
    V v_s_24746 = heff_field(v_x2_24744, 1);
    V v_ru_24x2_24744_24MkPair = heff_take_reuse_n(v_x2_24744, 3ULL, 2);
    V v_m_24747 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24748 = heff_tr(heff_call(v_m_24747, 1, (V[]){v_s_24746}));
    switch (heff_tag_of(v_x2_24748)) {
    case TAG_MkPair: {
      V v_x_24749 = heff_field(v_x2_24748, 0);
      V v_s_24750 = heff_field(v_x2_24748, 1);
      heff_take_n(v_x2_24748, 3ULL, 2);
      V v_t_24751 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str168), heff_strAppend(v_x_24749, ((V)&g_heff_2ecompile_2eemitc_2etestC_str169)));
      V v_t_24752 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str170), heff_strAppend(v_x_24745, v_t_24751));
      return heff_tag_at_n(v_ru_24x2_24744_24MkPair, TAG_MkPair, 2, (V[]){v_t_24752, v_s_24750});
    }
    default: return heff_nomatch(v_x2_24748);
    }
  }
  default: return heff_nomatch(v_x2_24744);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam48(V self, V *args) {
  V v_s_24754 = args[0];
  V v_m_24753 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24755 = heff_tr(heff_call(v_m_24753, 1, (V[]){v_s_24754}));
  switch (heff_tag_of(v_x2_24755)) {
  case TAG_MkPair: {
    V v_x_24756 = heff_field(v_x2_24755, 0);
    V v_s_24757 = heff_field(v_x2_24755, 1);
    V v_ru_24x2_24755_24MkPair = heff_take_reuse_n(v_x2_24755, 3ULL, 2);
    V v_m_24758 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24759 = heff_tr(heff_call(v_m_24758, 1, (V[]){v_s_24757}));
    switch (heff_tag_of(v_x2_24759)) {
    case TAG_MkPair: {
      V v_x_24760 = heff_field(v_x2_24759, 0);
      V v_s_24761 = heff_field(v_x2_24759, 1);
      heff_take_n(v_x2_24759, 3ULL, 2);
      V v_m_24762 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24763 = heff_tr(heff_call(v_m_24762, 1, (V[]){v_s_24761}));
      switch (heff_tag_of(v_x2_24763)) {
      case TAG_MkPair: {
        V v_x_24764 = heff_field(v_x2_24763, 0);
        V v_s_24765 = heff_field(v_x2_24763, 1);
        heff_take_n(v_x2_24763, 3ULL, 2);
        V v_t_24766 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str171), heff_strAppend(v_x_24764, ((V)&g_heff_2ecompile_2eemitc_2etestC_str172)));
        V v_t_24767 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str173), heff_strAppend(v_x_24760, v_t_24766));
        V v_t_24768 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str174), heff_strAppend(v_x_24756, v_t_24767));
        return heff_tag_at_n(v_ru_24x2_24755_24MkPair, TAG_MkPair, 2, (V[]){v_t_24768, v_s_24765});
      }
      default: return heff_nomatch(v_x2_24763);
      }
    }
    default: return heff_nomatch(v_x2_24759);
    }
  }
  default: return heff_nomatch(v_x2_24755);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam49(V self, V *args) {
  V v_s_24772 = args[0];
  V v_m_24771 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24773 = heff_tr(heff_call(v_m_24771, 1, (V[]){v_s_24772}));
  switch (heff_tag_of(v_x2_24773)) {
  case TAG_MkPair: {
    V v_x_24774 = heff_field(v_x2_24773, 0);
    V v_s_24775 = heff_field(v_x2_24773, 1);
    V v_ru_24x2_24773_24MkPair = heff_take_reuse_n(v_x2_24773, 3ULL, 2);
    V v_m_24776 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24777 = heff_tr(heff_call(v_m_24776, 1, (V[]){v_s_24775}));
    switch (heff_tag_of(v_x2_24777)) {
    case TAG_MkPair: {
      V v_x_24778 = heff_field(v_x2_24777, 0);
      V v_s_24779 = heff_field(v_x2_24777, 1);
      heff_take_n(v_x2_24777, 3ULL, 2);
      V v_m_24780 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24781 = heff_tr(heff_call(v_m_24780, 1, (V[]){v_s_24779}));
      switch (heff_tag_of(v_x2_24781)) {
      case TAG_MkPair: {
        V v_x_24782 = heff_field(v_x2_24781, 0);
        V v_s_24783 = heff_field(v_x2_24781, 1);
        heff_take_n(v_x2_24781, 3ULL, 2);
        V v_t_24784 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str175), heff_strAppend(v_x_24782, ((V)&g_heff_2ecompile_2eemitc_2etestC_str176)));
        V v_t_24785 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str177), heff_strAppend(v_x_24778, v_t_24784));
        V v_t_24786 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str178), heff_strAppend(v_x_24774, v_t_24785));
        return heff_tag_at_n(v_ru_24x2_24773_24MkPair, TAG_MkPair, 2, (V[]){v_t_24786, v_s_24783});
      }
      default: return heff_nomatch(v_x2_24781);
      }
    }
    default: return heff_nomatch(v_x2_24777);
    }
  }
  default: return heff_nomatch(v_x2_24773);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam50(V self, V *args) {
  V v_s_24790 = args[0];
  V v_m_24789 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24791 = heff_tr(heff_call(v_m_24789, 1, (V[]){v_s_24790}));
  switch (heff_tag_of(v_x2_24791)) {
  case TAG_MkPair: {
    V v_x_24792 = heff_field(v_x2_24791, 0);
    V v_s_24793 = heff_field(v_x2_24791, 1);
    V v_ru_24x2_24791_24MkPair = heff_take_reuse_n(v_x2_24791, 3ULL, 2);
    V v_m_24794 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24795 = heff_tr(heff_call(v_m_24794, 1, (V[]){v_s_24793}));
    switch (heff_tag_of(v_x2_24795)) {
    case TAG_MkPair: {
      V v_x_24796 = heff_field(v_x2_24795, 0);
      V v_s_24797 = heff_field(v_x2_24795, 1);
      heff_take_n(v_x2_24795, 3ULL, 2);
      V v_m_24798 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24799 = heff_tr(heff_call(v_m_24798, 1, (V[]){v_s_24797}));
      switch (heff_tag_of(v_x2_24799)) {
      case TAG_MkPair: {
        V v_x_24800 = heff_field(v_x2_24799, 0);
        V v_s_24801 = heff_field(v_x2_24799, 1);
        heff_take_n(v_x2_24799, 3ULL, 2);
        V v_t_24802 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str179), heff_strAppend(v_x_24800, ((V)&g_heff_2ecompile_2eemitc_2etestC_str180)));
        V v_t_24803 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str181), heff_strAppend(v_x_24796, v_t_24802));
        V v_t_24804 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str182), heff_strAppend(v_x_24792, v_t_24803));
        return heff_tag_at_n(v_ru_24x2_24791_24MkPair, TAG_MkPair, 2, (V[]){v_t_24804, v_s_24801});
      }
      default: return heff_nomatch(v_x2_24799);
      }
    }
    default: return heff_nomatch(v_x2_24795);
    }
  }
  default: return heff_nomatch(v_x2_24791);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam51(V self, V *args) {
  V v_s_24807 = args[0];
  V v_m_24806 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24808 = heff_tr(heff_call(v_m_24806, 1, (V[]){v_s_24807}));
  switch (heff_tag_of(v_x2_24808)) {
  case TAG_MkPair: {
    V v_x_24809 = heff_field(v_x2_24808, 0);
    V v_s_24810 = heff_field(v_x2_24808, 1);
    V v_ru_24x2_24808_24MkPair = heff_take_reuse_n(v_x2_24808, 3ULL, 2);
    V v_m_24811 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24812 = heff_tr(heff_call(v_m_24811, 1, (V[]){v_s_24810}));
    switch (heff_tag_of(v_x2_24812)) {
    case TAG_MkPair: {
      V v_x_24813 = heff_field(v_x2_24812, 0);
      V v_s_24814 = heff_field(v_x2_24812, 1);
      heff_take_n(v_x2_24812, 3ULL, 2);
      V v_m_24815 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24816 = heff_tr(heff_call(v_m_24815, 1, (V[]){v_s_24814}));
      switch (heff_tag_of(v_x2_24816)) {
      case TAG_MkPair: {
        V v_x_24817 = heff_field(v_x2_24816, 0);
        V v_s_24818 = heff_field(v_x2_24816, 1);
        heff_take_n(v_x2_24816, 3ULL, 2);
        V v_t_24819 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str183), heff_strAppend(v_x_24817, ((V)&g_heff_2ecompile_2eemitc_2etestC_str184)));
        V v_t_24820 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str185), heff_strAppend(v_x_24813, v_t_24819));
        V v_t_24821 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str186), heff_strAppend(v_x_24809, v_t_24820));
        return heff_tag_at_n(v_ru_24x2_24808_24MkPair, TAG_MkPair, 2, (V[]){v_t_24821, v_s_24818});
      }
      default: return heff_nomatch(v_x2_24816);
      }
    }
    default: return heff_nomatch(v_x2_24812);
    }
  }
  default: return heff_nomatch(v_x2_24808);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam52(V self, V *args) {
  V v_s_24824 = args[0];
  V v_m_24823 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24825 = heff_tr(heff_call(v_m_24823, 1, (V[]){v_s_24824}));
  switch (heff_tag_of(v_x2_24825)) {
  case TAG_MkPair: {
    V v_x_24826 = heff_field(v_x2_24825, 0);
    V v_s_24827 = heff_field(v_x2_24825, 1);
    V v_ru_24x2_24825_24MkPair = heff_take_reuse_n(v_x2_24825, 3ULL, 2);
    V v_m_24828 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24829 = heff_tr(heff_call(v_m_24828, 1, (V[]){v_s_24827}));
    switch (heff_tag_of(v_x2_24829)) {
    case TAG_MkPair: {
      V v_x_24830 = heff_field(v_x2_24829, 0);
      V v_s_24831 = heff_field(v_x2_24829, 1);
      heff_take_n(v_x2_24829, 3ULL, 2);
      V v_m_24832 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24833 = heff_tr(heff_call(v_m_24832, 1, (V[]){v_s_24831}));
      switch (heff_tag_of(v_x2_24833)) {
      case TAG_MkPair: {
        V v_x_24834 = heff_field(v_x2_24833, 0);
        V v_s_24835 = heff_field(v_x2_24833, 1);
        heff_take_n(v_x2_24833, 3ULL, 2);
        V v_t_24836 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str187), heff_strAppend(v_x_24834, ((V)&g_heff_2ecompile_2eemitc_2etestC_str188)));
        V v_t_24837 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str189), heff_strAppend(v_x_24830, v_t_24836));
        V v_t_24838 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str190), heff_strAppend(v_x_24826, v_t_24837));
        return heff_tag_at_n(v_ru_24x2_24825_24MkPair, TAG_MkPair, 2, (V[]){v_t_24838, v_s_24835});
      }
      default: return heff_nomatch(v_x2_24833);
      }
    }
    default: return heff_nomatch(v_x2_24829);
    }
  }
  default: return heff_nomatch(v_x2_24825);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam53(V self, V *args) {
  V v_s_24843 = args[0];
  V v_m_24842 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24844 = heff_tr(heff_call(v_m_24842, 1, (V[]){v_s_24843}));
  switch (heff_tag_of(v_x2_24844)) {
  case TAG_MkPair: {
    V v_x_24845 = heff_field(v_x2_24844, 0);
    V v_s_24846 = heff_field(v_x2_24844, 1);
    V v_ru_24x2_24844_24MkPair = heff_take_reuse_n(v_x2_24844, 3ULL, 2);
    V v_m_24847 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24848 = heff_tr(heff_call(v_m_24847, 1, (V[]){v_s_24846}));
    switch (heff_tag_of(v_x2_24848)) {
    case TAG_MkPair: {
      V v_x_24849 = heff_field(v_x2_24848, 0);
      V v_s_24850 = heff_field(v_x2_24848, 1);
      heff_take_n(v_x2_24848, 3ULL, 2);
      V v_m_24851 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24852 = heff_tr(heff_call(v_m_24851, 1, (V[]){v_s_24850}));
      switch (heff_tag_of(v_x2_24852)) {
      case TAG_MkPair: {
        V v_x_24853 = heff_field(v_x2_24852, 0);
        V v_s_24854 = heff_field(v_x2_24852, 1);
        heff_take_n(v_x2_24852, 3ULL, 2);
        V v_t_24855 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str191), heff_strAppend(v_x_24853, ((V)&g_heff_2ecompile_2eemitc_2etestC_str192)));
        V v_t_24856 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str193), heff_strAppend(v_x_24849, v_t_24855));
        V v_t_24857 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str194), heff_strAppend(v_x_24845, v_t_24856));
        return heff_tag_at_n(v_ru_24x2_24844_24MkPair, TAG_MkPair, 2, (V[]){v_t_24857, v_s_24854});
      }
      default: return heff_nomatch(v_x2_24852);
      }
    }
    default: return heff_nomatch(v_x2_24848);
    }
  }
  default: return heff_nomatch(v_x2_24844);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam54(V self, V *args) {
  V v_s_24863 = args[0];
  V v_m_24862 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24864 = heff_tr(heff_call(v_m_24862, 1, (V[]){v_s_24863}));
  switch (heff_tag_of(v_x2_24864)) {
  case TAG_MkPair: {
    V v_x_24865 = heff_field(v_x2_24864, 0);
    V v_s_24866 = heff_field(v_x2_24864, 1);
    V v_ru_24x2_24864_24MkPair = heff_take_reuse_n(v_x2_24864, 3ULL, 2);
    V v_m_24867 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24868 = heff_tr(heff_call(v_m_24867, 1, (V[]){v_s_24866}));
    switch (heff_tag_of(v_x2_24868)) {
    case TAG_MkPair: {
      V v_x_24869 = heff_field(v_x2_24868, 0);
      V v_s_24870 = heff_field(v_x2_24868, 1);
      heff_take_n(v_x2_24868, 3ULL, 2);
      V v_m_24871 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24872 = heff_tr(heff_call(v_m_24871, 1, (V[]){v_s_24870}));
      switch (heff_tag_of(v_x2_24872)) {
      case TAG_MkPair: {
        V v_x_24873 = heff_field(v_x2_24872, 0);
        V v_s_24874 = heff_field(v_x2_24872, 1);
        heff_take_n(v_x2_24872, 3ULL, 2);
        V v_t_24875 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str195), heff_strAppend(v_x_24873, ((V)&g_heff_2ecompile_2eemitc_2etestC_str196)));
        V v_t_24876 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str197), heff_strAppend(v_x_24869, v_t_24875));
        V v_t_24877 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str198), heff_strAppend(v_x_24865, v_t_24876));
        return heff_tag_at_n(v_ru_24x2_24864_24MkPair, TAG_MkPair, 2, (V[]){v_t_24877, v_s_24874});
      }
      default: return heff_nomatch(v_x2_24872);
      }
    }
    default: return heff_nomatch(v_x2_24868);
    }
  }
  default: return heff_nomatch(v_x2_24864);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam55(V self, V *args) {
  V v_s_24883 = args[0];
  V v_m_24882 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24884 = heff_tr(heff_call(v_m_24882, 1, (V[]){v_s_24883}));
  switch (heff_tag_of(v_x2_24884)) {
  case TAG_MkPair: {
    V v_x_24885 = heff_field(v_x2_24884, 0);
    V v_s_24886 = heff_field(v_x2_24884, 1);
    V v_ru_24x2_24884_24MkPair = heff_take_reuse_n(v_x2_24884, 3ULL, 2);
    V v_m_24887 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
    V v_x2_24888 = heff_tr(heff_call(v_m_24887, 1, (V[]){v_s_24886}));
    switch (heff_tag_of(v_x2_24888)) {
    case TAG_MkPair: {
      V v_x_24889 = heff_field(v_x2_24888, 0);
      V v_s_24890 = heff_field(v_x2_24888, 1);
      heff_take_n(v_x2_24888, 3ULL, 2);
      V v_t_24891 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str199), heff_strAppend(v_x_24889, ((V)&g_heff_2ecompile_2eemitc_2etestC_str200)));
      V v_t_24892 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str201), heff_strAppend(v_x_24885, v_t_24891));
      return heff_tag_at_n(v_ru_24x2_24884_24MkPair, TAG_MkPair, 2, (V[]){v_t_24892, v_s_24890});
    }
    default: return heff_nomatch(v_x2_24888);
    }
  }
  default: return heff_nomatch(v_x2_24884);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam56(V self, V *args) {
  V v_s_24894 = args[0];
  V v_m_24893 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24895 = heff_tr(heff_call(v_m_24893, 1, (V[]){v_s_24894}));
  switch (heff_tag_of(v_x2_24895)) {
  case TAG_MkPair: {
    V v_x_24896 = heff_field(v_x2_24895, 0);
    V v_s_24897 = heff_field(v_x2_24895, 1);
    V v_ru_24x2_24895_24MkPair = heff_take_reuse_n(v_x2_24895, 3ULL, 2);
    V v_m_24898 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24899 = heff_tr(heff_call(v_m_24898, 1, (V[]){v_s_24897}));
    switch (heff_tag_of(v_x2_24899)) {
    case TAG_MkPair: {
      V v_x_24900 = heff_field(v_x2_24899, 0);
      V v_s_24901 = heff_field(v_x2_24899, 1);
      heff_take_n(v_x2_24899, 3ULL, 2);
      V v_m_24902 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24903 = heff_tr(heff_call(v_m_24902, 1, (V[]){v_s_24901}));
      switch (heff_tag_of(v_x2_24903)) {
      case TAG_MkPair: {
        V v_x_24904 = heff_field(v_x2_24903, 0);
        V v_s_24905 = heff_field(v_x2_24903, 1);
        heff_take_n(v_x2_24903, 3ULL, 2);
        V v_t_24906 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str202), heff_strAppend(v_x_24904, ((V)&g_heff_2ecompile_2eemitc_2etestC_str203)));
        V v_t_24907 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str204), heff_strAppend(v_x_24900, v_t_24906));
        V v_t_24908 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str205), heff_strAppend(v_x_24896, v_t_24907));
        return heff_tag_at_n(v_ru_24x2_24895_24MkPair, TAG_MkPair, 2, (V[]){v_t_24908, v_s_24905});
      }
      default: return heff_nomatch(v_x2_24903);
      }
    }
    default: return heff_nomatch(v_x2_24899);
    }
  }
  default: return heff_nomatch(v_x2_24895);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam57(V self, V *args) {
  V v_s_24912 = args[0];
  V v_m_24911 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24913 = heff_tr(heff_call(v_m_24911, 1, (V[]){v_s_24912}));
  switch (heff_tag_of(v_x2_24913)) {
  case TAG_MkPair: {
    V v_x_24914 = heff_field(v_x2_24913, 0);
    V v_s_24915 = heff_field(v_x2_24913, 1);
    V v_ru_24x2_24913_24MkPair = heff_take_reuse_n(v_x2_24913, 3ULL, 2);
    V v_m_24916 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24917 = heff_tr(heff_call(v_m_24916, 1, (V[]){v_s_24915}));
    switch (heff_tag_of(v_x2_24917)) {
    case TAG_MkPair: {
      V v_x_24918 = heff_field(v_x2_24917, 0);
      V v_s_24919 = heff_field(v_x2_24917, 1);
      heff_take_n(v_x2_24917, 3ULL, 2);
      V v_m_24920 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24921 = heff_tr(heff_call(v_m_24920, 1, (V[]){v_s_24919}));
      switch (heff_tag_of(v_x2_24921)) {
      case TAG_MkPair: {
        V v_x_24922 = heff_field(v_x2_24921, 0);
        V v_s_24923 = heff_field(v_x2_24921, 1);
        heff_take_n(v_x2_24921, 3ULL, 2);
        V v_t_24924 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str206), heff_strAppend(v_x_24922, ((V)&g_heff_2ecompile_2eemitc_2etestC_str207)));
        V v_t_24925 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str208), heff_strAppend(v_x_24918, v_t_24924));
        V v_t_24926 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str209), heff_strAppend(v_x_24914, v_t_24925));
        return heff_tag_at_n(v_ru_24x2_24913_24MkPair, TAG_MkPair, 2, (V[]){v_t_24926, v_s_24923});
      }
      default: return heff_nomatch(v_x2_24921);
      }
    }
    default: return heff_nomatch(v_x2_24917);
    }
  }
  default: return heff_nomatch(v_x2_24913);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam58(V self, V *args) {
  V v_s_24930 = args[0];
  V v_m_24929 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24931 = heff_tr(heff_call(v_m_24929, 1, (V[]){v_s_24930}));
  switch (heff_tag_of(v_x2_24931)) {
  case TAG_MkPair: {
    V v_x_24932 = heff_field(v_x2_24931, 0);
    V v_s_24933 = heff_field(v_x2_24931, 1);
    V v_ru_24x2_24931_24MkPair = heff_take_reuse_n(v_x2_24931, 3ULL, 2);
    V v_m_24934 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24935 = heff_tr(heff_call(v_m_24934, 1, (V[]){v_s_24933}));
    switch (heff_tag_of(v_x2_24935)) {
    case TAG_MkPair: {
      V v_x_24936 = heff_field(v_x2_24935, 0);
      V v_s_24937 = heff_field(v_x2_24935, 1);
      heff_take_n(v_x2_24935, 3ULL, 2);
      V v_m_24938 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24939 = heff_tr(heff_call(v_m_24938, 1, (V[]){v_s_24937}));
      switch (heff_tag_of(v_x2_24939)) {
      case TAG_MkPair: {
        V v_x_24940 = heff_field(v_x2_24939, 0);
        V v_s_24941 = heff_field(v_x2_24939, 1);
        heff_take_n(v_x2_24939, 3ULL, 2);
        V v_t_24942 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str210), heff_strAppend(v_x_24940, ((V)&g_heff_2ecompile_2eemitc_2etestC_str211)));
        V v_t_24943 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str212), heff_strAppend(v_x_24936, v_t_24942));
        V v_t_24944 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str213), heff_strAppend(v_x_24932, v_t_24943));
        return heff_tag_at_n(v_ru_24x2_24931_24MkPair, TAG_MkPair, 2, (V[]){v_t_24944, v_s_24941});
      }
      default: return heff_nomatch(v_x2_24939);
      }
    }
    default: return heff_nomatch(v_x2_24935);
    }
  }
  default: return heff_nomatch(v_x2_24931);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam59(V self, V *args) {
  V v_s_24947 = args[0];
  V v_m_24946 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24948 = heff_tr(heff_call(v_m_24946, 1, (V[]){v_s_24947}));
  switch (heff_tag_of(v_x2_24948)) {
  case TAG_MkPair: {
    V v_x_24949 = heff_field(v_x2_24948, 0);
    V v_s_24950 = heff_field(v_x2_24948, 1);
    V v_ru_24x2_24948_24MkPair = heff_take_reuse_n(v_x2_24948, 3ULL, 2);
    V v_m_24951 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24952 = heff_tr(heff_call(v_m_24951, 1, (V[]){v_s_24950}));
    switch (heff_tag_of(v_x2_24952)) {
    case TAG_MkPair: {
      V v_x_24953 = heff_field(v_x2_24952, 0);
      V v_s_24954 = heff_field(v_x2_24952, 1);
      heff_take_n(v_x2_24952, 3ULL, 2);
      V v_m_24955 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24956 = heff_tr(heff_call(v_m_24955, 1, (V[]){v_s_24954}));
      switch (heff_tag_of(v_x2_24956)) {
      case TAG_MkPair: {
        V v_x_24957 = heff_field(v_x2_24956, 0);
        V v_s_24958 = heff_field(v_x2_24956, 1);
        heff_take_n(v_x2_24956, 3ULL, 2);
        V v_t_24959 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str214), heff_strAppend(v_x_24957, ((V)&g_heff_2ecompile_2eemitc_2etestC_str215)));
        V v_t_24960 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str216), heff_strAppend(v_x_24953, v_t_24959));
        V v_t_24961 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str217), heff_strAppend(v_x_24949, v_t_24960));
        return heff_tag_at_n(v_ru_24x2_24948_24MkPair, TAG_MkPair, 2, (V[]){v_t_24961, v_s_24958});
      }
      default: return heff_nomatch(v_x2_24956);
      }
    }
    default: return heff_nomatch(v_x2_24952);
    }
  }
  default: return heff_nomatch(v_x2_24948);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam60(V self, V *args) {
  V v_s_24964 = args[0];
  V v_m_24963 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24965 = heff_tr(heff_call(v_m_24963, 1, (V[]){v_s_24964}));
  switch (heff_tag_of(v_x2_24965)) {
  case TAG_MkPair: {
    V v_x_24966 = heff_field(v_x2_24965, 0);
    V v_s_24967 = heff_field(v_x2_24965, 1);
    V v_ru_24x2_24965_24MkPair = heff_take_reuse_n(v_x2_24965, 3ULL, 2);
    V v_m_24968 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24969 = heff_tr(heff_call(v_m_24968, 1, (V[]){v_s_24967}));
    switch (heff_tag_of(v_x2_24969)) {
    case TAG_MkPair: {
      V v_x_24970 = heff_field(v_x2_24969, 0);
      V v_s_24971 = heff_field(v_x2_24969, 1);
      heff_take_n(v_x2_24969, 3ULL, 2);
      V v_m_24972 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24973 = heff_tr(heff_call(v_m_24972, 1, (V[]){v_s_24971}));
      switch (heff_tag_of(v_x2_24973)) {
      case TAG_MkPair: {
        V v_x_24974 = heff_field(v_x2_24973, 0);
        V v_s_24975 = heff_field(v_x2_24973, 1);
        heff_take_n(v_x2_24973, 3ULL, 2);
        V v_t_24976 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str218), heff_strAppend(v_x_24974, ((V)&g_heff_2ecompile_2eemitc_2etestC_str219)));
        V v_t_24977 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str220), heff_strAppend(v_x_24970, v_t_24976));
        V v_t_24978 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str221), heff_strAppend(v_x_24966, v_t_24977));
        return heff_tag_at_n(v_ru_24x2_24965_24MkPair, TAG_MkPair, 2, (V[]){v_t_24978, v_s_24975});
      }
      default: return heff_nomatch(v_x2_24973);
      }
    }
    default: return heff_nomatch(v_x2_24969);
    }
  }
  default: return heff_nomatch(v_x2_24965);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam61(V self, V *args) {
  V v_s_24983 = args[0];
  V v_m_24982 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24984 = heff_tr(heff_call(v_m_24982, 1, (V[]){v_s_24983}));
  switch (heff_tag_of(v_x2_24984)) {
  case TAG_MkPair: {
    V v_x_24985 = heff_field(v_x2_24984, 0);
    V v_s_24986 = heff_field(v_x2_24984, 1);
    V v_ru_24x2_24984_24MkPair = heff_take_reuse_n(v_x2_24984, 3ULL, 2);
    V v_m_24987 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_24988 = heff_tr(heff_call(v_m_24987, 1, (V[]){v_s_24986}));
    switch (heff_tag_of(v_x2_24988)) {
    case TAG_MkPair: {
      V v_x_24989 = heff_field(v_x2_24988, 0);
      V v_s_24990 = heff_field(v_x2_24988, 1);
      heff_take_n(v_x2_24988, 3ULL, 2);
      V v_m_24991 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_24992 = heff_tr(heff_call(v_m_24991, 1, (V[]){v_s_24990}));
      switch (heff_tag_of(v_x2_24992)) {
      case TAG_MkPair: {
        V v_x_24993 = heff_field(v_x2_24992, 0);
        V v_s_24994 = heff_field(v_x2_24992, 1);
        heff_take_n(v_x2_24992, 3ULL, 2);
        V v_t_24995 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str222), heff_strAppend(v_x_24993, ((V)&g_heff_2ecompile_2eemitc_2etestC_str223)));
        V v_t_24996 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str224), heff_strAppend(v_x_24989, v_t_24995));
        V v_t_24997 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str225), heff_strAppend(v_x_24985, v_t_24996));
        return heff_tag_at_n(v_ru_24x2_24984_24MkPair, TAG_MkPair, 2, (V[]){v_t_24997, v_s_24994});
      }
      default: return heff_nomatch(v_x2_24992);
      }
    }
    default: return heff_nomatch(v_x2_24988);
    }
  }
  default: return heff_nomatch(v_x2_24984);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam62(V self, V *args) {
  V v_s_241003 = args[0];
  V v_m_241002 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2440 = heff_env(self)[2];
  V v_x23_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_241004 = heff_tr(heff_call(v_m_241002, 1, (V[]){v_s_241003}));
  switch (heff_tag_of(v_x2_241004)) {
  case TAG_MkPair: {
    V v_x_241005 = heff_field(v_x2_241004, 0);
    V v_s_241006 = heff_field(v_x2_241004, 1);
    V v_ru_24x2_241004_24MkPair = heff_take_reuse_n(v_x2_241004, 3ULL, 2);
    V v_m_241007 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_b_2440));
    V v_x2_241008 = heff_tr(heff_call(v_m_241007, 1, (V[]){v_s_241006}));
    switch (heff_tag_of(v_x2_241008)) {
    case TAG_MkPair: {
      V v_x_241009 = heff_field(v_x2_241008, 0);
      V v_s_241010 = heff_field(v_x2_241008, 1);
      heff_take_n(v_x2_241008, 3ULL, 2);
      V v_m_241011 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_x23_2441));
      V v_x2_241012 = heff_tr(heff_call(v_m_241011, 1, (V[]){v_s_241010}));
      switch (heff_tag_of(v_x2_241012)) {
      case TAG_MkPair: {
        V v_x_241013 = heff_field(v_x2_241012, 0);
        V v_s_241014 = heff_field(v_x2_241012, 1);
        heff_take_n(v_x2_241012, 3ULL, 2);
        V v_t_241015 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str226), heff_strAppend(v_x_241013, ((V)&g_heff_2ecompile_2eemitc_2etestC_str227)));
        V v_t_241016 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str228), heff_strAppend(v_x_241009, v_t_241015));
        V v_t_241017 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str229), heff_strAppend(v_x_241005, v_t_241016));
        return heff_tag_at_n(v_ru_24x2_241004_24MkPair, TAG_MkPair, 2, (V[]){v_t_241017, v_s_241014});
      }
      default: return heff_nomatch(v_x2_241012);
      }
    }
    default: return heff_nomatch(v_x2_241008);
    }
  }
  default: return heff_nomatch(v_x2_241004);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam63(V self, V *args) {
  V v_s_241023 = args[0];
  V v_m_241022 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_241020 = heff_env(self)[2];
  V v_x_241018 = heff_env(self)[3];
  V v_drops_241021 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_241024 = heff_tr(heff_call(v_m_241022, 1, (V[]){v_s_241023}));
  switch (heff_tag_of(v_x2_241024)) {
  case TAG_MkPair: {
    V v_x_241025 = heff_field(v_x2_241024, 0);
    V v_s_241026 = heff_field(v_x2_241024, 1);
    V v_ru_24x2_241024_24MkPair = heff_take_reuse_n(v_x2_241024, 3ULL, 2);
    V v_m_241027 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_241020));
    V v_x2_241028 = heff_tr(heff_call(v_m_241027, 1, (V[]){v_s_241026}));
    switch (heff_tag_of(v_x2_241028)) {
    case TAG_MkPair: {
      V v_x_241029 = heff_field(v_x2_241028, 0);
      V v_s_241030 = heff_field(v_x2_241028, 1);
      heff_take_n(v_x2_241028, 3ULL, 2);
      V v_t_241031 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_241018)}));
      V v_t_241032 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241018, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str230)));
      V v_x2_241033 = (g_list_2emap_24s1437960788x1959942644(((V)&g_heff_2ecompile_2eemitc_2etestC_str231), ((V)&g_heff_2ecompile_2eemitc_2etestC_str232), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str233), ((V)&g_heff_2ecompile_2eemitc_2etestC_str234), ((V)&g_heff_2ecompile_2eemitc_2etestC_str235), v_drops_241021));
      V v_t_241036;
      switch (heff_tag_of(v_x2_241033)) {
      case TAG_Nil: {
        v_t_241036 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str236);
        break;
      }
      case TAG_Cons: {
        V v_x_241034 = heff_field(v_x2_241033, 0);
        V v_xs_241035 = heff_field(v_x2_241033, 1);
        heff_take_n(v_x2_241033, 3ULL, 2);
        v_t_241036 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str237); V a_1 = v_x_241034; V a_2 = v_xs_241035; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_241035); r_; });
        break;
      }
      default: heff_nomatch(v_x2_241033);
      }
      V v_t_241037 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str238), heff_strAppend(v_t_241036, ((V)&g_heff_2ecompile_2eemitc_2etestC_str239)));
      V v_t_241038 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str240), heff_strAppend(v_x_241029, v_t_241037));
      V v_t_241039 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str241), heff_strAppend(v_x_241025, v_t_241038));
      V v_t_241040 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str242), v_t_241032), v_t_241039);
      V v_t_241041 = heff_strAppend(v_t_241031, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str243), v_t_241040));
      V v_x_241042 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str244), v_t_241041);
      return heff_tag_at_n(v_ru_24x2_241024_24MkPair, TAG_MkPair, 2, (V[]){v_x_241042, v_s_241030});
    }
    default: return heff_nomatch(v_x2_241028);
    }
  }
  default: return heff_nomatch(v_x2_241024);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_plain_245 = heff_field(v_x3_242, 2);
    V v_take_246 = heff_field(v_x3_242, 3);
    V v_body_247 = heff_field(v_x3_242, 4);
    V v_leaves_248 = heff_field(v_x3_242, 5);
    V v_m_249 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 3), 1, (V[]){heff_dup(v_body_247)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 7, (V[]){v_m_249, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_245), heff_dup(v_fields_244), heff_dup(v_take_246), heff_dup(v_leaves_248)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_245 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_take_246 = heff_env(self)[5];
  V v_leaves_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2earmF_str0)));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str1), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2earmF_str2));
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2415), NTAG(TAG_Nil)});
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2efieldLine_clo), 2, (V[]){heff_dup(v_sv_241), v_plain_245}));
    V v_t_2418 = (g_list_2emap(v_t_2417, v_fields_244));
    V v_t_2419 = (g_heff_2ecompile_2eemitc_2etakeLines(v_sv_241, v_take_246));
    V v_t_2420 = (g_list_2emap_24f998257836x1791893456(((V)&g_heff_2ecompile_2eemitc_2earmF_str4), v_t_2419, v_x_2412));
    V v_t_2421;
    if ((heff_dup(v_leaves_248) == NTAG(TAG_True))) {
      heff_drop(v_leaves_248);
      v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str5), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_248);
      v_t_2421 = NTAG(TAG_Nil);
    }
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str6), NTAG(TAG_Nil)});
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2422));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2424));
    V v_x_2426 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2425));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
  return heff_strAppend(v_t_245, v_t_247);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 10, " return r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 2, "  ");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_bi_241);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_bi_241);
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_x2_247 = (g_list_2emap_24f1801471045x554404499(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7), v_t_246), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8), v_t_2412);
  } else {
    heff_drop(v_t_245);
    V v_x2_2413 = (g_list_2emap_24s1785262601x1752264566(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14)));
    V v_t_2418 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2422 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2418));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_x2_2426 = (g_list_2emap_24s1006477676x1816442814(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), v_bi_241));
    V v_t_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nil: {
      v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_xs_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26), heff_strAppend(v_t_2425, v_t_2430));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27), v_t_2417), v_t_2431);
    V v_t_2433 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28), v_t_2432));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29), v_t_2433);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eentryCall(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2419 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = ({ V a_0 = heff_dup(v_i_2419); V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), heff_intShow(v_i_2419));
  } else {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_strAppend(heff_intShow(v_i_2419), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17), v_t_2421);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 22, "static const HeffName ");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_map_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s1378753456x1787722089(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_map_2esize(v_m_241));
  V v_t_249;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_2410 = heff_strAppend(v_t_246, heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7)));
  V v_t_2411 = heff_strAppend(v_name_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8), v_t_2410));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9), v_t_2411), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str3, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str4, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalGet_str5, 14, "static V gget_");
Clo g_heff_2ecompile_2eemitc_2eglobalGet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalGet_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eglobalGet(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 0, 5);
    V v_x3_245 = ({ V a_0 = heff_dup(v_key_243); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_key_243);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str0)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str1)));
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str2), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str3));
      V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str4), v_t_249));
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglobalGet_str5), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eglobalGet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalGet(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 42, "static const Global heff_globals_arr[] = {");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam8(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0), NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1), heff_rfield(v_ce_242, 0)));
  V v_t_2415 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), heff_rfield(v_ce_242, 1)));
  V v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_x2_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2421));
  V v_t_2434;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    v_t_2434 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2431);
  }
  V v_x1_2440 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam6, 1, 1, (V[]){heff_dup(v_defs_241)}), heff_dup(v_exports_240)));
  V v_t_2443;
  switch (heff_tag_of(v_x1_2440)) {
  case TAG_Nil: {
    v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2440, 0ULL, 2);
    v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9);
    break;
  }
  default: heff_nomatch(v_x1_2440);
  }
  V v_t_2444 = heff_strAppend(v_t_2434, heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10)));
  V v_t_2450 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam8, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f1992548173x1980409276(a_0, a_1, a_2, a_3)); heff_drop(v_exports_240); r_; });
  V v_t_2451 = heff_strAppend(heff_intShow(v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11));
  V v_t_2452 = (g_map_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2453 = heff_strAppend(heff_intShow(v_t_2452), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12));
  V v_t_2454 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_map_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2455 = heff_strAppend(heff_intShow(v_t_2454), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13));
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14), NTAG(TAG_Nil)});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15), v_t_2455), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16), v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17), v_t_2453), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18), v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19), v_t_2451), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), v_t_2444), v_t_2460});
  V v_t_2462 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2461));
  V v_t_2463 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2462));
  V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2463));
  return (g_prelude_2e_2b_2b(v_t_243, v_t_2464));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_d_248 = args[0];
  V v_key_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_248, 0, 3), v_key_247);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_244 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_246 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_key_247 = v_y_246;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 1, 1, (V[]){v_key_247}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2eglobalGet(v_ce_242, v_x_2411));
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_2410));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_d_2420 = args[0];
  V v_key_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2420, 0, 3), v_key_2419);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2416 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2419;
  switch (heff_tag_of(v_p_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_p_2416, 1);
    heff_take_n(v_p_2416, 2ULL, 2);
    v_key_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_p_2416);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){v_key_2419}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2422 = args[0];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425;
  switch (heff_tag_of(v_p_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_dup(heff_field(v_p_2422, 0));
    v_t_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_p_2422);
  }
  V v_t_2428;
  switch (heff_tag_of(v_p_2422)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_p_2422, 1);
    heff_take_n(v_p_2422, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_p_2422);
  }
  V v_t_2429 = (g_heff_2ecompile_2eemitc_2egetterOf(v_ce_242, v_t_2428));
  V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5), heff_strAppend(v_t_2425, v_t_2430));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam7(V self, V *args) {
  V v_d_2439 = args[0];
  V v_key_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2439, 0, 3), v_key_2438);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam6(V self, V *args) {
  V v_p_2435 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2438;
  switch (heff_tag_of(v_p_2435)) {
  case TAG_MkPair: {
    V v_y_2437 = heff_field(v_p_2435, 1);
    heff_take_n(v_p_2435, 2ULL, 2);
    v_key_2438 = v_y_2437;
    break;
  }
  default: heff_nomatch(v_p_2435);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam7, 1, 1, (V[]){v_key_2438}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam9(V self, V *args) {
  V v_d_2449 = args[0];
  V v_key_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_2449, 0, 3), v_key_2448);
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam8(V self, V *args) {
  V v_p_2445 = args[0];
  V v_defs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_key_2448;
  switch (heff_tag_of(v_p_2445)) {
  case TAG_MkPair: {
    V v_y_2447 = heff_field(v_p_2445, 1);
    heff_take_n(v_p_2445, 2ULL, 2);
    v_key_2448 = v_y_2447;
    break;
  }
  default: heff_nomatch(v_p_2445);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam9, 1, 1, (V[]){v_key_2448}); V a_1 = v_defs_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 8, "uint64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 6, "double");

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_b_241), heff_dup(v_k_243))) {
    heff_drop(v_m_240);
    heff_drop(v_b_241);
    heff_drop(v_ps_242);
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_qs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}), heff_dup(v_ps_242)));
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(heff_dup(v_m_240), v_b_241, v_ps_242, heff_intAdd(heff_dup(v_k_243), MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_m_240);
      heff_drop(v_k_243);
      return v_rest_2411;
    }
    case TAG_Cons: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0), heff_intShow(v_k_243));
      V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_240, v_t_2414), v_qs_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsFrom(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_k_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_k_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemitc_2ekeyHashGo(v_k_248, MK_INT(0LL), MK_INT(7LL)));
  return heff_intEq(heff_intMod(v_t_249, v_b_241), v_k_243);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str0, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str1, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulesParts_str2, 17, "#define HEFF_PART");
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulesParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulesParts_entry, 7, 0};

V g_heff_2ecompile_2eemitc_2emodulesParts(V v_ce_240, V v_s_241, V v_strs_242, V v_protos_243, V v_lams_244, V v_defs_245, V v_ems_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str0), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2emodulesParts_str2), v_t_247})});
  V v_t_249 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 6))));
  V v_t_2410 = (g_list_2efoldl_24s132236332x1381264820(heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_s_241, 7))));
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emodulePart_clo), 8, (V[]){v_t_248, v_ce_240, heff_dup(v_s_241), v_t_249, v_t_2410, heff_dup(v_strs_242), heff_dup(v_protos_243), heff_dup(v_lams_244)}));
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2emodulesParts_lam0, 1, 4, (V[]){v_s_241, v_strs_242, v_protos_243, v_lams_244})}));
  V v_t_2415 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_245, v_ems_246));
  V v_m_2416 = (g_list_2efoldl_24s1702849581x277546608(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_map_2eempty_get()), v_t_2415));
  V v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2416); r_; });
  V v_t_2418 = (g_list_2econcatMap(v_t_2414, v_t_2417));
  return (g_list_2emap(v_t_2411, v_t_2418));
}
V g_heff_2ecompile_2eemitc_2emodulesParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emodulesParts(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eemitc_2emodulesParts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_strs_242 = heff_env(self)[1];
  V v_protos_243 = heff_env(self)[2];
  V v_lams_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2413 = ({ V a_0 = v_s_241; V a_1 = v_strs_242; V a_2 = v_protos_243; V a_3 = v_lams_244; V a_4 = v_p_2412; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_241, 8); heff_drop(v_strs_242); heff_drop(v_protos_243); heff_drop(v_lams_244); heff_drop(v_p_2412); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2413; V r_ = (g_list_2efoldl_24s1486300758x450371661(a_0, a_1, a_2)); heff_drop(v_ls_2413); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 5);
  V v_x2_244 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 5);
  V v_x3_248 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_247; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_2410;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    v_t_2410 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_248, 0ULL, 1);
    v_t_2410 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 5);
  V v_x2_2412 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2411; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_x2_2415 = (g_list_2emap(heff_dup(g_prelude_2eshowInt_get()), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 4, 5);
  V v_x3_2420 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2419; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_Nothing: {
    v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x3_2420, 0);
    heff_take_n(v_x3_2420, 1ULL, 1);
    v_t_2422 = (g_heff_2ecompile_2erepr_2esigName(v_x_2421));
    break;
  }
  default: heff_nomatch(v_x3_2420);
  }
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2422}), v_rest_242});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2418}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2410}), v_t_2424});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_246}), v_t_2425});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2426});
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epushOwn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efreshEmitted_str1, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efreshEmitted_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2efreshEmitted(V v_acc_240, V v_key_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_s1_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_e_244), heff_dup(heff_rfield(v_acc_240, 0))});
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_241), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str0)));
    V v_t_248 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_242), heff_dup(v_e_244), heff_dup(v_s1_245)));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efreshEmitted_str1), v_t_247), v_t_248, heff_take_field(v_acc_240, 1)));
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_242, v_e_244, v_s1_245));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_241, v_t_2410}), heff_get_n(v_acc_240, 2, 3)});
    return heff_rec_n(3, shape_ems__s__fresh, (V[]){v_t_246, v_t_249, v_t_2411});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efreshEmitted(a[0], a[1], a[2], a[3]);
}