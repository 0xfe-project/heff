// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2erename_2erenameTermF_lam0(V self, V *args);
V g_heff_2erename_2erenameTermF_lam1(V self, V *args);
V g_heff_2erename_2erenameTermF_lam2(V self, V *args);
Clo g_heff_2erename_2erenameTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2erenameTermF_entry, 3, 0};

V g_heff_2erename_2erenameTermF(V v_k_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_k_240);
    V v_t_245 = heff_tr(heff_apply(v_r_241, 1, (V[]){v_x_244}));
    return heff_tag_at(v_ru_24e_242_24SGlobal, TAG_SGlobal, 1, (V[]){v_t_245});
  }
  case TAG_SCode: {
    V v_t_246 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCode = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_247 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t_246}));
    return heff_tag_at(v_ru_24e_242_24SCode, TAG_SCode, 1, (V[]){v_t_247});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_a_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_f_248}));
    V v_t_2411 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_a_249}));
    return heff_tag_at(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){v_t_2410, v_t_2411});
  }
  case TAG_SLam: {
    V v_d_2412 = heff_field(v_e_242, 0);
    V v_b_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_d_2412}));
    V v_t_2420;
    switch (heff_tag_of(v_b_2413)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2413, 0);
      V v_t_2416 = heff_field(v_b_2413, 1);
      heff_take_n(v_b_2413, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_t_2416}));
      v_t_2420 = heff_tag_at(v_ru_24e_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2418 = heff_field(v_b_2413, 0);
      V v_ru_24b_2413_24AbsConst = heff_take_reuse_n(v_b_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24e_242_24SLam, 2);
      V v_t_2419 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_t_2418}));
      v_t_2420 = heff_tag_at(v_ru_24b_2413_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2413);
    }
    return heff_tag(TAG_SLam, 2, (V[]){v_t_2414, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCons = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_xs_2422 = heff_get(heff_dup(v_d_2421), LBL_values);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo(g_heff_2erename_2erenameTermF_lam0, 1, 2, (V[]){v_xs_2422, v_k_240}));
    V v_t_2426 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_d_2421), LBL_keys), heff_get(v_d_2421, LBL_byName), v_t_2425});
    return heff_tag_at(v_ru_24e_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e2_2427 = heff_field(v_e_242, 0);
    V v_l_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2429 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_e2_2427}));
    return heff_tag_at(v_ru_24e_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_t_2430 = heff_field(v_e_242, 0);
    V v_as_2431 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24STag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2433 = (g_prelude_2emap(heff_clo(g_heff_2erename_2erenameTermF_lam1, 1, 1, (V[]){v_k_240}), heff_arrayToList(v_as_2431)));
    return heff_tag_at(v_ru_24e_242_24STag, TAG_STag, 2, (V[]){v_t_2430, heff_arrayFromList(v_t_2433)});
  }
  case TAG_SMatch: {
    V v_e2_2434 = heff_field(v_e_242, 0);
    V v_cs_2435 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_e2_2434}));
    V v_xs_2437 = heff_get(heff_dup(v_cs_2435), LBL_values);
    V v_t_2443 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2437)), heff_clo(g_heff_2erename_2erenameTermF_lam2, 1, 2, (V[]){v_xs_2437, v_k_240}));
    V v_t_2444 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_cs_2435), LBL_keys), heff_get(v_cs_2435, LBL_byName), v_t_2443});
    return heff_tag_at(v_ru_24e_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2436, v_t_2444});
  }
  case TAG_SSpecialize: {
    V v_e2_2445 = heff_field(v_e_242, 0);
    V v_l_2446 = heff_field(v_e_242, 1);
    V v_v_2447 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SSpecialize = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_el), 1, (V[]){v_e2_2445}));
    V v_t_2449 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_v_2447}));
    return heff_tag_at(v_ru_24e_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2448, v_l_2446, v_t_2449});
  }
  case TAG_SIs: {
    V v_e2_2450 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SIs = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2451 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_e2_2450}));
    return heff_tag_at(v_ru_24e_242_24SIs, TAG_SIs, 1, (V[]){v_t_2451});
  }
  case TAG_SOpaque: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SAbandon: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SRec: {
    V v_e2_2452 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SRec = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2453 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_e2_2452}));
    return heff_tag_at(v_ru_24e_242_24SRec, TAG_SRec, 1, (V[]){v_t_2453});
  }
  case TAG_SFix: {
    V v_d_2454 = heff_field(v_e_242, 0);
    V v_b_2455 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_d_2454}));
    V v_t_2462;
    switch (heff_tag_of(v_b_2455)) {
    case TAG_MkAbs: {
      V v_x_2457 = heff_field(v_b_2455, 0);
      V v_t_2458 = heff_field(v_b_2455, 1);
      heff_take_n(v_b_2455, 3ULL, 2);
      V v_t_2459 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_t_2458}));
      v_t_2462 = heff_tag_at(v_ru_24e_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2457, v_t_2459});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2460 = heff_field(v_b_2455, 0);
      V v_ru_24b_2455_24AbsConst = heff_take_reuse_n(v_b_2455, 1ULL, 1);
      heff_drop_cell(v_ru_24e_242_24SFix, 2);
      V v_t_2461 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_t_2460}));
      v_t_2462 = heff_tag_at(v_ru_24b_2455_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2461});
      break;
    }
    default: heff_nomatch(v_b_2455);
    }
    return heff_tag(TAG_SFix, 2, (V[]){v_t_2456, v_t_2462});
  }
  case TAG_SImplicit: {
    V v_x_2463 = heff_field(v_e_242, 0);
    V v_e2_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SImplicit = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2465 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_e2_2464}));
    return heff_tag_at(v_ru_24e_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2463, v_t_2465});
  }
  case TAG_SPrim: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SMetaApp: {
    V v_m_2467 = heff_field(v_e_242, 0);
    V v_xs_2468 = heff_field(v_e_242, 1);
    V v_t_2469 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SMetaApp = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2470 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t_2469}));
    return heff_tag_at(v_ru_24e_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2467, v_xs_2468, v_t_2470});
  }
  case TAG_SLitInt: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFloat: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitString: {
    heff_drop(v_k_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2erename_2erenameTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2erename_2erenameTermF(a[0], a[1], a[2]);
}
V g_heff_2erename_2erenameTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_e2_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_e2_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erename_2erenameTermF_lam1(V self, V *args) {
  V v_e2_2432 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_e2_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erename_2erenameTermF_lam2(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  switch (heff_tag_of(v_p_2439)) {
  case TAG_MkPair: {
    V v_xs_2440 = heff_field(v_p_2439, 0);
    V v_b_2441 = heff_field(v_p_2439, 1);
    V v_ru_24p_2439_24MkPair = heff_take_reuse_n(v_p_2439, 3ULL, 2);
    V v_t_2442 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_b_2441}));
    return heff_tag_at(v_ru_24p_2439_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2440, v_t_2442});
  }
  default: return heff_nomatch(v_p_2439);
  }
}
V g_heff_2erename_2erenameTypeF_lam0(V self, V *args);
V g_heff_2erename_2erenameTypeF_lam1(V self, V *args);
V g_heff_2erename_2erenameTypeF_lam3(V self, V *args);
V g_heff_2erename_2erenameTypeF_lam2(V self, V *args);
Clo g_heff_2erename_2erenameTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2erenameTypeF_entry, 3, 0};

V g_heff_2erename_2erenameTypeF(V v_k_240, V v_r_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_k_240);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_apply(heff_get(v_k_240, LBL_el), 1, (V[]){v_e_244}));
    return heff_tag_at(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 15ULL, 4);
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_ty), 1, (V[]){v_dom_247}));
    V v_t_2416;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2411 = heff_field(v_cod_248, 0);
      V v_t_2412 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2413 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t_2412}));
      v_t_2416 = heff_tag_at(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2411, v_t_2413});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2414 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t_2414}));
      v_t_2416 = heff_tag_at(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    return heff_tag_at(v_ru_24t_242_24SFunction, TAG_SFunction, 4, (V[]){v_level_246, v_t_2410, v_t_2416, v_implicit_249});
  }
  case TAG_SRecord: {
    V v_level_2417 = heff_field(v_t_242, 0);
    V v_fs_2418 = heff_field(v_t_242, 1);
    V v_ds_2419 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2420 = heff_get(heff_dup(v_fs_2418), LBL_values);
    V v_t_2423 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2420)), heff_clo(g_heff_2erename_2erenameTypeF_lam0, 1, 2, (V[]){v_xs_2420, heff_dup(v_k_240)}));
    V v_t_2424 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fs_2418), LBL_keys), heff_get(v_fs_2418, LBL_byName), v_t_2423});
    V v_xs_2425 = heff_get(heff_dup(v_ds_2419), LBL_values);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo(g_heff_2erename_2erenameTypeF_lam1, 1, 2, (V[]){v_xs_2425, v_k_240}));
    V v_t_2429 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_ds_2419), LBL_keys), heff_get(v_ds_2419, LBL_byName), v_t_2428});
    return heff_tag_at(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2417, v_t_2424, v_t_2429});
  }
  case TAG_SSum: {
    V v_vs_2430 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2431 = heff_get(heff_dup(v_vs_2430), LBL_values);
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2431)), heff_clo(g_heff_2erename_2erenameTypeF_lam2, 1, 2, (V[]){v_xs_2431, v_k_240}));
    V v_t_2437 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_vs_2430), LBL_keys), heff_get(v_vs_2430, LBL_byName), v_t_2436});
    return heff_tag_at(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2437});
  }
  case TAG_SIsTy: {
    V v_t2_2438 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2439 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t2_2438}));
    return heff_tag_at(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2439});
  }
  case TAG_SPrimInt: {
    heff_drop(v_k_240);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_k_240);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop(v_k_240);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    V v_t2_2440 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2441 = heff_tr(heff_apply(heff_get(v_k_240, LBL_ty), 1, (V[]){v_t2_2440}));
    return heff_tag_at(v_ru_24t_242_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2441});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2erename_2erenameTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erename_2erenameTypeF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2erename_2erenameTypeF_lam0(V self, V *args) {
  V v_i_2421 = args[0];
  V v_xs_2420 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t2_2422 = heff_arrayIndex(v_xs_2420, v_i_2421);
  V f_ = heff_get(v_k_240, LBL_ty);
  args[0] = v_t2_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erename_2erenameTypeF_lam1(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_e2_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get(v_k_240, LBL_el);
  args[0] = v_e2_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erename_2erenameTypeF_lam3(V self, V *args) {
  V v_i_2434 = args[0];
  V v_xs_2433 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t2_2435 = heff_arrayIndex(v_xs_2433, v_i_2434);
  V f_ = heff_get(v_k_240, LBL_ty);
  args[0] = v_t2_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2erename_2erenameTypeF_lam2(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2433)), heff_clo(g_heff_2erename_2erenameTypeF_lam3, 1, 2, (V[]){v_xs_2433, v_k_240}));
}
V g_heff_2erename_2erkOf_lam0(V self, V *args);
V g_heff_2erename_2erkOf_lam1(V self, V *args);
Clo g_heff_2erename_2erkOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2erkOf_entry, 1, 0};

V g_heff_2erename_2erkOf(V v_r_240) {
top: ;
  return heff_rec(2, shape_80_351, (V[]){heff_clo(g_heff_2erename_2erkOf_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo(g_heff_2erename_2erkOf_lam1, 1, 1, (V[]){v_r_240})});
}
V g_heff_2erename_2erkOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2erename_2erkOf(a[0]);
}
V g_heff_2erename_2erkOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2erename_2erkOf(heff_dup(v_r_240)));
  return (g_heff_2erename_2erenameTermF(v_t_242, v_r_240, v_e_241));
}
V g_heff_2erename_2erkOf_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2erename_2erkOf(heff_dup(v_r_240)));
  return ({ V a_0 = v_t_244; V a_1 = v_r_240; V a_2 = v_t_243; V r_ = (g_heff_2erename_2erenameTypeF(a_0, a_1, a_2)); heff_drop(v_r_240); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2erename_2edescribeKey_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2erename_2edescribeKey_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {116, 104, 101, 32, 116, 104, 101, 111, 114, 121, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2erename_2edescribeKey_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {35}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2erename_2edescribeKey_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {116, 104, 101, 32, 109, 111, 100, 117, 108, 101, 32}};
Clo g_heff_2erename_2edescribeKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2edescribeKey_entry, 1, 0};

V g_heff_2erename_2edescribeKey(V v_x_240) {
top: ;
  V v_t_241 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(2LL));
  V v_t_242 = heff_strSlice(heff_dup(v_x_240), v_t_241, heff_strLength(heff_dup(v_x_240)));
  V v_t_243 = heff_strEq(v_t_242, ((V)&g_heff_2erename_2edescribeKey_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(2LL));
    return heff_strAppend(((V)&g_heff_2erename_2edescribeKey_str1), heff_strSlice(v_x_240, MK_INT(0LL), v_t_244));
  }
  case TAG_False: {
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(1LL));
    V v_t_246 = heff_strSlice(heff_dup(v_x_240), v_t_245, heff_strLength(heff_dup(v_x_240)));
    V v_t_247 = heff_strEq(v_t_246, ((V)&g_heff_2erename_2edescribeKey_str2));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(1LL));
      return heff_strAppend(((V)&g_heff_2erename_2edescribeKey_str3), heff_strSlice(v_x_240, MK_INT(0LL), v_t_248));
    }
    case TAG_False: {
      return v_x_240;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2erename_2edescribeKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2erename_2edescribeKey(a[0]);
}
V g_heff_2erename_2enubFirst_lam0(V self, V *args);
Clo g_heff_2erename_2enubFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2enubFirst_entry, 1, 0};

V g_heff_2erename_2enubFirst(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2erename_2enubFirst_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2erename_2enubFirst(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erename_2enubFirst_entry(V self, V *a) {
  (void)self;
  return g_heff_2erename_2enubFirst(a[0]);
}
V g_heff_2erename_2enubFirst_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2erename_2eglobalsTypeF_24s190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2eglobalsTypeF_24s190_entry, 1, 0};

V g_heff_2erename_2eglobalsTypeF_24s190(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    return NTAG(TAG_Nil);
  }
  case TAG_SDecode: {
    V v_e_242 = heff_field(v_t_240, 0);
    HEFF_LAST return g_heff_2erename_2eglobalsTermF_24s186(v_e_242);
  }
  case TAG_SFunction: {
    V v_dom_244 = heff_field(v_t_240, 1);
    V v_cod_245 = heff_field(v_t_240, 2);
    V v_t_247 = (g_heff_2erename_2eglobalsTypeF_24s190(v_dom_244));
    V v_t_2411;
    switch (heff_tag_of(v_cod_245)) {
    case TAG_MkAbs: {
      V v_t_249 = heff_field(v_cod_245, 1);
      v_t_2411 = (g_heff_2erename_2eglobalsTypeF_24s190(v_t_249));
      break;
    }
    case TAG_AbsConst: {
      V v_t_2410 = heff_field(v_cod_245, 0);
      v_t_2411 = (g_heff_2erename_2eglobalsTypeF_24s190(v_t_2410));
      break;
    }
    default: heff_nomatch(v_cod_245);
    }
    return (g_prelude_2econcatList(v_t_247, v_t_2411));
  }
  case TAG_SRecord: {
    V v_fs_2413 = heff_field(v_t_240, 1);
    V v_ds_2414 = heff_field(v_t_240, 2);
    V v_t_2415 = heff_arrayToList(heff_get(heff_dup(v_fs_2413), LBL_keys));
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_fs_2413), LBL_values));
    V v_xs_2417 = (g_heff_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2417));
    V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_prelude_2efoldl_24s191(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = heff_arrayToList(heff_get(heff_dup(v_ds_2414), LBL_keys));
    V v_t_2421 = heff_arrayToList(heff_get(heff_dup(v_ds_2414), LBL_values));
    V v_xs_2422 = (g_heff_2edict_2ezipKV(v_t_2420, v_t_2421));
    V v_t_2423 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2422));
    V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_prelude_2efoldl_24s187(a_0, a_1)); heff_drop(v_t_2423); r_; });
    return (g_prelude_2econcatList(v_t_2419, v_t_2424));
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_240, 0);
    V v_t_2426 = heff_arrayToList(heff_get(heff_dup(v_vs_2425), LBL_keys));
    V v_t_2427 = heff_arrayToList(heff_get(heff_dup(v_vs_2425), LBL_values));
    V v_xs_2428 = (g_heff_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2428));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2429; V r_ = (g_prelude_2efoldl_24s193(a_0, a_1)); heff_drop(v_t_2429); r_; });
  }
  case TAG_SIsTy: {
    V v_t2_2430 = heff_field(v_t_240, 0);
    V t_0 = v_t2_2430;
    v_t_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimFloat: {
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimString: {
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimArray: {
    V v_t2_2431 = heff_field(v_t_240, 0);
    V t_0 = v_t2_2431;
    v_t_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2erename_2eglobalsTypeF_24s190_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erename_2eglobalsTypeF_24s190(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2erename_2eglobalsTermF_24s186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2eglobalsTermF_24s186_entry, 1, 0};

V g_heff_2erename_2eglobalsTermF_24s186(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_Nil);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_e_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
  }
  case TAG_SCode: {
    V v_t_243 = heff_field(v_e_240, 0);
    HEFF_LAST return g_heff_2erename_2eglobalsTypeF_24s190(v_t_243);
  }
  case TAG_SApp: {
    V v_f_244 = heff_field(v_e_240, 0);
    V v_a_245 = heff_field(v_e_240, 1);
    V v_t_246 = (g_heff_2erename_2eglobalsTermF_24s186(v_f_244));
    V v_t_247 = (g_heff_2erename_2eglobalsTermF_24s186(v_a_245));
    return (g_prelude_2econcatList(v_t_246, v_t_247));
  }
  case TAG_SLam: {
    V v_d_248 = heff_field(v_e_240, 0);
    V v_b_249 = heff_field(v_e_240, 1);
    V v_t_2410 = (g_heff_2erename_2eglobalsTypeF_24s190(v_d_248));
    V v_t_2414;
    switch (heff_tag_of(v_b_249)) {
    case TAG_MkAbs: {
      V v_t_2412 = heff_field(v_b_249, 1);
      v_t_2414 = (g_heff_2erename_2eglobalsTermF_24s186(v_t_2412));
      break;
    }
    case TAG_AbsConst: {
      V v_t_2413 = heff_field(v_b_249, 0);
      v_t_2414 = (g_heff_2erename_2eglobalsTermF_24s186(v_t_2413));
      break;
    }
    default: heff_nomatch(v_b_249);
    }
    return (g_prelude_2econcatList(v_t_2410, v_t_2414));
  }
  case TAG_SCons: {
    V v_d_2415 = heff_field(v_e_240, 0);
    V v_t_2416 = heff_arrayToList(heff_get(heff_dup(v_d_2415), LBL_keys));
    V v_t_2417 = heff_arrayToList(heff_get(heff_dup(v_d_2415), LBL_values));
    V v_xs_2418 = (g_heff_2edict_2ezipKV(v_t_2416, v_t_2417));
    V v_t_2419 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2418));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_prelude_2efoldl_24s187(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_SProj: {
    V v_e2_2420 = heff_field(v_e_240, 0);
    V t_0 = v_e2_2420;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_STag: {
    V v_as_2423 = heff_field(v_e_240, 1);
    V v_t_2424 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_as_2423))));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_prelude_2efoldl_24s188(a_0, a_1)); heff_drop(v_t_2424); r_; });
  }
  case TAG_SMatch: {
    V v_e2_2425 = heff_field(v_e_240, 0);
    V v_cs_2426 = heff_field(v_e_240, 1);
    V v_t_2427 = (g_heff_2erename_2eglobalsTermF_24s186(v_e2_2425));
    V v_t_2428 = heff_arrayToList(heff_get(heff_dup(v_cs_2426), LBL_keys));
    V v_t_2429 = heff_arrayToList(heff_get(heff_dup(v_cs_2426), LBL_values));
    V v_xs_2430 = (g_heff_2edict_2ezipKV(v_t_2428, v_t_2429));
    V v_t_2431 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2430));
    V v_t_2432 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2431; V r_ = (g_prelude_2efoldl_24s189(a_0, a_1)); heff_drop(v_t_2431); r_; });
    return (g_prelude_2econcatList(v_t_2427, v_t_2432));
  }
  case TAG_SSpecialize: {
    V v_e2_2433 = heff_field(v_e_240, 0);
    V v_v_2435 = heff_field(v_e_240, 2);
    V v_t_2436 = (g_heff_2erename_2eglobalsTermF_24s186(v_e2_2433));
    V v_t_2437 = (g_heff_2erename_2eglobalsTermF_24s186(v_v_2435));
    return (g_prelude_2econcatList(v_t_2436, v_t_2437));
  }
  case TAG_SIs: {
    V v_e2_2438 = heff_field(v_e_240, 0);
    V t_0 = v_e2_2438;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nil);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_SRec: {
    V v_e2_2439 = heff_field(v_e_240, 0);
    V t_0 = v_e2_2439;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SFix: {
    V v_d_2440 = heff_field(v_e_240, 0);
    V v_b_2441 = heff_field(v_e_240, 1);
    V v_t_2442 = (g_heff_2erename_2eglobalsTypeF_24s190(v_d_2440));
    V v_t_2446;
    switch (heff_tag_of(v_b_2441)) {
    case TAG_MkAbs: {
      V v_t_2444 = heff_field(v_b_2441, 1);
      v_t_2446 = (g_heff_2erename_2eglobalsTermF_24s186(v_t_2444));
      break;
    }
    case TAG_AbsConst: {
      V v_t_2445 = heff_field(v_b_2441, 0);
      v_t_2446 = (g_heff_2erename_2eglobalsTermF_24s186(v_t_2445));
      break;
    }
    default: heff_nomatch(v_b_2441);
    }
    return (g_prelude_2econcatList(v_t_2442, v_t_2446));
  }
  case TAG_SImplicit: {
    V v_e2_2448 = heff_field(v_e_240, 1);
    V t_0 = v_e2_2448;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SPrim: {
    return NTAG(TAG_Nil);
  }
  case TAG_SMetaApp: {
    V v_t_2452 = heff_field(v_e_240, 2);
    HEFF_LAST return g_heff_2erename_2eglobalsTypeF_24s190(v_t_2452);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_Nil);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_Nil);
  }
  case TAG_SLitString: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2erename_2eglobalsTermF_24s186_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erename_2eglobalsTermF_24s186(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2erename_2efirstAliasOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2erename_2efirstAliasOf_entry, 2, 0};

V g_heff_2erename_2efirstAliasOf(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_k_245 = heff_field(v_x11_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_245), heff_dup(v_x_241));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_x_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_n_244)});
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2erename_2efirstAliasOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2erename_2efirstAliasOf(a[0], a[1]); heff_drop(a[0]); return r;
}