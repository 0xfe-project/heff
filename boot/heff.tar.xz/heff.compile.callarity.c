// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_ar 9880
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_many 9839398
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_supply 1056026650
#define LBL_tables 1065764240
#define LBL_takes 311482598
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_calls__uses__takes[] = {LBL_calls, LBL_uses, LBL_takes};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__many__ar[] = {LBL_key, LBL_params, LBL_many, LBL_ar};
static uint32_t shape_known__defs__supply[] = {LBL_known, LBL_defs, LBL_supply};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2eafterRound(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo;
V g_heff_2ecompile_2ecallarity_2eappNote(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappNote_clo;
V g_heff_2ecompile_2ecallarity_2eappPush(V, V, V);
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappPush_clo;
V g_heff_2ecompile_2ecallarity_2eargsNote(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2ecallarity_2edefNotes(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo;
V g_heff_2ecompile_2ecallarity_2edropC(V, V);
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edropC_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eisNth(V, V, V);
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eisNth_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enoteUse(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo;
V g_heff_2ecompile_2ecallarity_2enotedThen(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
V g_heff_2ecompile_2ecallarity_2eraiseDef(V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseDef_clo;
V g_heff_2ecompile_2ecallarity_2eraiseOnce(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseOnce_clo;
V g_heff_2ecompile_2ecallarity_2eraiseTo(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseTo_clo;
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2eroundsMost_get(void);
V g_heff_2ecompile_2ecallarity_2esameAll(V, V);
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameAll_clo;
V g_heff_2ecompile_2ecallarity_2esameInts(V, V);
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameInts_clo;
V g_heff_2ecompile_2ecallarity_2esameTables(V, V);
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameTables_clo;
V g_heff_2ecompile_2ecallarity_2etraverseS(V, V);
V g_heff_2ecompile_2ecallarity_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2etraverseS_clo;
V g_heff_2ecompile_2ecallarity_2eunused_get(void);
V g_heff_2ecompile_2ecallarity_2eusesW(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eusesW_clo;
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s847493210x796325999(V, V);
V g_list_2efoldl_24s847493210x796325999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s847493210x796325999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2ecallarity_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2ecallarity_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2etraverseS_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2ecallarity_2etraverseS_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_str0, 1, "z");
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_str1, 1, "$");
Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2efreshMany_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2efreshMany(V v_k_240, V v_p_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  } else {
    V v_m_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_clo), 1, (V[]){heff_intSub(v_k_240, MK_INT(1LL))}));
    V v_x2_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))}));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_n_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_str0), heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_str1), heff_intShow(v_p_241)));
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_x_245}), v_n_246});
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
}
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2efreshMany(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edropC_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edropC(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2enthOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enthOr_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2enthOr(V v_d_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_d_240);
      heff_drop(v_i_241);
      return heff_dup(v_x_243);
    } else {
      V t_0 = v_d_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_d_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2enthOr(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eisNth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eisNth_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eisNth(V v_i_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_strEq(v_x_241, heff_dup(v_y_243));
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_x_241;
      V t_2 = v_ys_244;
      v_i_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eisNth(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ezipTo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2ezipTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_map_2eempty_get());
    }
    case TAG_Cons: {
      V v_z_244 = heff_field(v_x2_241, 0);
      V v_zs_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ecompile_2ecallarity_2ezipTo(v_ys_243, v_zs_245));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_y_242), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_z_244)}), v_t_246));
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ezipTo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2ecallarity_2eunused_val;
static HEFF_ONCE g_heff_2ecompile_2ecallarity_2eunused_st;
static V g_heff_2ecompile_2ecallarity_2eunused_init(void) {
  return MK_INT(1000000LL);
}
V g_heff_2ecompile_2ecallarity_2eunused_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecallarity_2eunused_st)) return g_heff_2ecompile_2ecallarity_2eunused_val;
  return heff_global(&g_heff_2ecompile_2ecallarity_2eunused_val, &g_heff_2ecompile_2ecallarity_2eunused_st, g_heff_2ecompile_2ecallarity_2eunused_init);
}
Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enoteUse_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enoteUse(V v_here_240, V v_g_241, V v_k_242, V v_x4_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_take_field(v_here_240, 2);
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = MK_INT(2LL);
      break;
    }
    case TAG_False: {
      v_t_246 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_x2_247 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_here_240, 3, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_u_2410 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_k_242, v_t_246, v_t_249});
    V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_g_241, v_u_2410, heff_take_field(v_n_244, 1)));
    return ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_n(v_n_244, 5ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_u_2412 = heff_field(v_x4_243, 0);
    V v_t_2415;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_u_2412, 2)))) {
      v_t_2415 = heff_intLe(heff_dup(heff_rfield(v_u_2412, 0)), heff_dup(heff_rfield(v_u_2412, 2)));
    } else {
      if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_u_2412, 1)))) {
        v_t_2415 = NTAG(TAG_True);
      } else {
        v_t_2415 = heff_intEq(heff_dup(heff_rfield(v_u_2412, 0)), MK_INT(0LL));
      }
    }
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop_rec(v_here_240, 4);
      heff_drop(v_g_241);
      heff_drop(v_k_242);
      return v_n_244;
    }
    case TAG_False: {
      V v_t_2417;
      if (heff_intLt_c(heff_dup(v_k_242), heff_dup(heff_rfield(v_u_2412, 0)))) {
        v_t_2417 = v_k_242;
      } else {
        heff_drop(v_k_242);
        v_t_2417 = heff_dup(heff_rfield(v_u_2412, 0));
      }
      V v_t_2418 = heff_get_n(v_here_240, 2, 4);
      V v_t_2419;
      switch (heff_tag_of(v_t_2418)) {
      case TAG_True: {
        v_t_2419 = MK_INT(2LL);
        break;
      }
      case TAG_False: {
        v_t_2419 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      V v_t_2420 = heff_intAdd(heff_dup(heff_rfield(v_u_2412, 1)), v_t_2419);
      V v_u_2421 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_t_2417, v_t_2420, heff_dup(heff_rfield(v_u_2412, 2))});
      V v_t_2422 = (g_map_2einsert_24s1341440536x470972936(v_g_241, v_u_2421, heff_take_field(v_n_244, 1)));
      return ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_n(v_n_244, 5ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2enoteUse(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ehanded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ehanded_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2ehanded(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x_244, V v_n_245) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_dup(v_h_242), heff_dup(heff_rfield(v_here_241, 0)))) {
    v_t_247 = ({ V a_0 = heff_dup(v_j_243); V a_1 = heff_dup(v_x_244); V b_2 = heff_get_n(v_here_241, 1, 4); V r_ = (g_heff_2ecompile_2ecallarity_2eisNth(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    heff_drop_rec(v_here_241, 4);
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    heff_drop(v_x_244);
    return v_n_245;
  }
  case TAG_False: {
    V v_x2_248 = ({ V a_0 = v_h_242; V b_1 = heff_get_n(v_t_240, 0, 1); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_k_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      heff_drop(v_j_243);
      v_k_2410 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_ps_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_k_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_249; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_x3_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_244), heff_rfield(v_n_245, 0)));
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      heff_drop(v_x_244);
      heff_drop(v_k_2410);
      return v_n_245;
    }
    case TAG_Just: {
      V v_k0_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_k_2410), v_k0_2412)) {
        V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_x_244, v_k_2410, heff_take_field(v_n_245, 0)));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_n(v_n_245, 6ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 0) = rv_0; rr_; });
      } else {
        heff_drop(v_x_244);
        heff_drop(v_k_2410);
        return v_n_245;
      }
    }
    default: return heff_nomatch(v_x3_2411);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2ehanded(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eargsNote_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2eargsNote(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x5_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_here_241);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    return v_n_245;
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_as_247 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = (g_heff_2ecompile_2ecallarity_2ehanded(heff_dup(v_t_240), heff_dup(v_here_241), heff_dup(v_h_242), heff_dup(v_j_243), heff_dup(v_x_248), v_n_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_t_249;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELam: {
      V v_ys_2411 = heff_field(v_x51_246, 0);
      V v_x2_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_h_242), heff_rfield(v_t_240, 0)));
      V v_a_2415;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nothing: {
        v_a_2415 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_ps_2414 = heff_field(v_x2_2413, 0);
        heff_take_n(v_x2_2413, 1ULL, 1);
        v_a_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_243); V a_2 = v_ps_2414; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_b_2416 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_2411));
      V v_t_2418;
      if (heff_intLt_c(v_b_2416, v_a_2415)) {
        v_t_2418 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_n(v_n_245, 3ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 2) = rv_2; rr_; });
      } else {
        v_t_2418 = v_n_245;
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_t_2418;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EApp: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ERecord: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EProj: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ETag: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EMatch: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrim: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EPrimCall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ECall: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EInt: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EAbandon: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_EFix: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_as_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x51_246);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2ecallarity_2eargsNote(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappNote_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eappNote(V v_t_240, V v_here_241, V v_f_242, V v_as_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_f_242, 0);
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    V v_k_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_x3_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_245), heff_rfield(v_n_244, 0)));
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      heff_drop(v_k_246);
      return v_n_244;
    }
    case TAG_Just: {
      V v_k0_248 = heff_field(v_x3_247, 0);
      heff_take_n(v_x3_247, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_k_246), v_k0_248)) {
        V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_245), v_k_246, heff_take_field(v_n_244, 0)));
        return ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_n(v_n_244, 6ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 0) = rv_0; rr_; });
      } else {
        heff_drop(v_k_246);
        return v_n_244;
      }
    }
    default: return heff_nomatch(v_x3_247);
    }
  }
  case TAG_EGlobal: {
    V v_g_2411 = heff_field(v_f_242, 0);
    V v_k_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2411), heff_rfield(v_n_244, 1)));
    V v_t_2414 = ({ V a_0 = heff_dup(v_here_241); V a_1 = heff_dup(v_g_2411); V a_2 = v_k_2412; V a_3 = v_t_2413; V a_4 = v_n_244; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
    return (g_heff_2ecompile_2ecallarity_2eargsNote(v_t_240, v_here_241, heff_dup(v_g_2411), MK_INT(0LL), v_as_243, v_t_2414));
  }
  case TAG_ELam: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EApp: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ELet: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ERecord: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EProj: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ETag: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EMatch: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ECall: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    heff_drop(v_here_241);
    return v_n_244;
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eappNote(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_as_243;
      V t_1 = v_rest_241;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_ELam: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EApp: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_ELet: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_ERecord: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EProj: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_ETag: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EMatch: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EPrim: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EPrimCall: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_ECall: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EInt: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EFloat: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EStr: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EFixed: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EFloat32: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EAbandon: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    case TAG_EFix: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_243, v_rest_241))});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eappPush_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappPush_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eappPush(V v_f_240, V v_as_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_EVar: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242));
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_240, 0ULL, 1);
    return (g_heff_2ecompile_2ecallarity_2epushNonVars(v_as_241, v_rest_242));
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, (g_heff_2ecompile_2eir_2eappendI(v_as_241, v_rest_242))});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eappPush_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eappPush(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2ecallarity_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eusesW_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eusesW(V v_t_240, V v_here_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop_rec(v_here_241, 4);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_x3_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_246), heff_rfield(v_n_243, 0)));
      V v_t_2411;
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop(v_x_246);
        v_t_2411 = v_n_243;
        break;
      }
      case TAG_Just: {
        V v_k0_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        if (heff_intLt_c(MK_INT(0LL), v_k0_248)) {
          V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_x_246, MK_INT(0LL), heff_take_field(v_n_243, 0)));
          v_t_2411 = ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_n(v_n_243, 6ULL, 3, shape_vars__globals__dirty); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_x_246);
          v_t_2411 = v_n_243;
        }
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2411;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2412), heff_rfield(v_n_243, 1)));
      V v_t_2414 = ({ V a_0 = heff_dup(v_here_241); V a_1 = v_g_2412; V a_2 = MK_INT(0LL); V a_3 = v_t_2413; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2414;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2416 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      V v_t_2417 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_dup(heff_rfield(v_here_241, 0)), heff_dup(heff_rfield(v_here_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_here_241, 3))});
      V v_t_2418 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2416, NTAG(TAG_Nil)});
      V v_t_2419 = (g_heff_2ecompile_2ecallarity_2eusesW(heff_dup(v_t_240), v_t_2417, v_t_2418, v_n_243));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2419;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2420 = heff_field(v_x31_244, 0);
      V v_as_2421 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2422 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_dup(v_f_2420), heff_dup(v_as_2421), v_rest_245));
      V v_t_2423 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V a_2 = v_f_2420; V a_3 = v_as_2421; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2420); heff_drop(v_as_2421); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2422;
      V t_3 = v_t_2423;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2425 = heff_field(v_x31_244, 1);
      V v_b_2426 = heff_field(v_x31_244, 2);
      heff_take_n(v_x31_244, 6ULL, 3);
      V v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2426, v_rest_245})});
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2427;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2428 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2428, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2429;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2430 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 3);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2430, v_rest_245});
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2434 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_as_2434, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2435;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2436 = heff_field(v_x31_244, 0);
      V v_arms_2437 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_t_2438 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2436, (g_heff_2ecompile_2eir_2epushArms(v_arms_2437, v_rest_245))});
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2438;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2441 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2442 = (g_heff_2ecompile_2eir_2eappendI(v_as_2441, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2442;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2443 = heff_field(v_x31_244, 0);
      V v_as_2444 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2445 = (g_heff_2ecompile_2ecallarity_2eappPush(heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_g_2443)}), heff_dup(v_as_2444), v_rest_245));
      V v_t_2446 = ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_here_241); V b_2 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2443}); V a_3 = v_as_2444; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); heff_drop(v_as_2444); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2445;
      V t_3 = v_t_2446;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x31_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eusesW(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edefNotes_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2edefNotes(V v_t_240, V v_ar_241, V v_gl_242, V v_d_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_d_243, 2));
  V v_t_2435;
  switch (heff_tag_of(v_t_244)) {
  case TAG_EVar: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    v_t_2435 = v_xs_247;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_244, 0ULL, 3);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_244, 0ULL, 3);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_244, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_2435 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2436 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_take_field(v_d_243, 0), v_t_2435, NTAG(TAG_False), v_ar_241});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_243, 2)), NTAG(TAG_Nil)});
  V v_t_2438 = heff_get_n(v_d_243, 2, 3);
  V v_xs_2469;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_EVar: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_2441 = heff_field(v_t_2438, 0);
    heff_take_n(v_t_2438, 1ULL, 2);
    v_xs_2469 = v_xs_2441;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2438, 0ULL, 3);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2438, 0ULL, 3);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2438, 0ULL, 2);
    v_xs_2469 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2470 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2469; V r_ = (g_list_2efoldl_24s847493210x796325999(a_0, a_1)); heff_drop(v_xs_2469); r_; });
  V v_t_2471 = heff_rec_n(3, shape_vars__globals__dirty, (V[]){v_t_2470, v_gl_242, NTAG(TAG_False)});
  HEFF_LAST return g_heff_2ecompile_2ecallarity_2eusesW(v_t_240, v_t_2436, v_t_2437, v_t_2471);
}
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edefNotes(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eknownAdd_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eknownAdd(V v_k_240, V v_d_241, V v_n_242) {
top: ;
  V v_t_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eknownAdd_lam0, 1, 1, (V[]){heff_dup(v_n_242)}), v_xs_246));
    V v_t_2413 = heff_get_n(heff_get_n(v_k_240, 0, 2), 0, 1);
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_2412, v_t_2413));
    return heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){v_t_2414}), heff_get_n(v_n_242, 1, 3)});
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_n(v_k_240, 1ULL, 2, shape_tables__globals); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eknownAdd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_x_248; V b_1 = heff_get_n(v_n_242, 0, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_k_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    if (heff_intLe_c(heff_dup(g_heff_2ecompile_2ecallarity_2eunused_get()), heff_dup(v_k_2410))) {
      heff_drop(v_k_2410);
      return MK_INT(0LL);
    } else {
      return v_k_2410;
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2ecompile_2ecallarity_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_247, v_m_240));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2earityOne(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eextend(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_ELam: {
      V v_ys_246 = heff_field(v_e_241, 0);
      V v_b_247 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_a_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_246));
      V v_b_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_b_249, v_a_248)) {
        V v_t_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2412 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2411, heff_dup(v_ys_246)));
        V v_m_2413 = ({ V a_0 = v_ys_246; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_246); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2414 = (g_map_2esize(v_m_2413));
        V v_t_2416;
        if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
          heff_drop(v_m_2413);
          v_t_2416 = v_b_247;
        } else {
          v_t_2416 = ({ V a_0 = v_m_2413; V a_1 = v_b_247; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2413); r_; });
        }
        return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2412, v_t_2416});
      } else {
        heff_drop_cell(v_ru_24e_241_24ELam, 2);
        V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_246));
        V v_t_2418 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2417, heff_dup(v_zs_240)));
        V v_m_2419 = ({ V a_0 = v_ys_246; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_246); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2420 = (g_map_2esize(v_m_2419));
        V v_t_2422;
        if (heff_intEq_c(v_t_2420, MK_INT(0LL))) {
          heff_drop(v_m_2419);
          v_t_2422 = v_b_247;
        } else {
          v_t_2422 = ({ V a_0 = v_m_2419; V a_1 = v_b_247; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2419); r_; });
        }
        V t_0 = v_t_2418;
        V t_1 = v_t_2422;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2423 = heff_field(v_e_241, 0);
      V v_as_2424 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2425 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_f_2423, (g_prelude_2e_2b_2b(v_as_2424, v_t_2425))});
    }
    case TAG_ELet: {
      V v_x_2426 = heff_field(v_e_241, 0);
      V v_a_2427 = heff_field(v_e_241, 1);
      V v_b_2428 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      return heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2426, v_a_2427, (g_heff_2ecompile_2ecallarity_2eextend(v_zs_240, v_b_2428))});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EMatch: {
      V v_s_2435 = heff_field(v_e_241, 0);
      V v_arms_2436 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_f_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2435, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_lam0, 1, 1, (V[]){v_f_2437}), v_arms_2436))});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return NTAG(TAG_EAbandon);
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, (g_list_2emap_24s1809017761x1063871171(v_zs_240))});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args) {
  V v_x2_2438 = args[0];
  V v_f_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkArm: {
    V v_tg_2439 = heff_field(v_x2_2438, 0);
    V v_vs_2440 = heff_field(v_x2_2438, 1);
    V v_b_2441 = heff_field(v_x2_2438, 2);
    V v_ru_24x2_2438_24MkArm = heff_take_reuse_n(v_x2_2438, 7ULL, 3);
    V v_t_2442 = heff_tr(heff_call(v_f_2437, 1, (V[]){v_b_2441}));
    return heff_tag_at_n(v_ru_24x2_2438_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2439, v_vs_2440, v_t_2442});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
Clo g_heff_2ecompile_2ecallarity_2eraiseTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseTo_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eraiseTo(V v_d_240, V v_xs_241, V v_b_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_z_244});
  }
  case TAG_Just: {
    V v_m_245 = heff_field(v_x4_243, 0);
    V v_b_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    if (heff_intLt_c(v_b_246, heff_dup(v_m_245))) {
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_249 = heff_intSub(heff_dup(v_m_245), v_t_248);
      V v_x2_2410 = (g_heff_2ecompile_2ecallarity_2efreshMany(v_t_249, v_z_244));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_n_2412 = heff_field(v_x2_2410, 1);
        V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
        V v_t_2413 = (g_prelude_2e_2b_2b(v_xs_241, heff_dup(v_x_2411)));
        V v_body_2414 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_ELam, 2, (V[]){v_t_2413, (g_heff_2ecompile_2ecallarity_2eextend(v_x_2411, v_b_242))});
        V v_t_2415 = ({ V rv_2 = v_body_2414; V rr_ = heff_rec_reuse_n(v_d_240, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_n_2412});
      }
      default: return heff_nomatch(v_x2_2410);
      }
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_z_244});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseTo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eraiseTo(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eraiseOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseOnce_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eraiseOnce(V v_d_240, V v_calls_241, V v_uses_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_calls_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
  }
  case TAG_Just: {
    V v_m_244 = heff_field(v_calls_241, 0);
    switch (heff_tag_of(v_uses_242)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
    }
    case TAG_Just: {
      V v_uses1_245 = heff_field(v_uses_242, 0);
      if (heff_intEq_c(heff_dup(v_uses1_245), MK_INT(1LL))) {
        if (heff_intLt_c(MK_INT(0LL), heff_dup(v_m_244))) {
          V v_x2_248 = (g_heff_2ecompile_2ecallarity_2efreshMany(heff_dup(v_m_244), v_p_243));
          switch (heff_tag_of(v_x2_248)) {
          case TAG_MkPair: {
            V v_x_249 = heff_field(v_x2_248, 0);
            V v_n_2410 = heff_field(v_x2_248, 1);
            V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
            V v_body_2411 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_249), (g_heff_2ecompile_2ecallarity_2eextend(v_x_249, heff_dup(heff_rfield(v_d_240, 2))))});
            V v_t_2412 = ({ V rv_2 = v_body_2411; V rr_ = heff_rec_reuse_n(v_d_240, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_n_2410});
          }
          default: return heff_nomatch(v_x2_248);
          }
        } else {
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
        }
      } else {
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
      }
    }
    default: return heff_nomatch(v_uses_242);
    }
  }
  default: return heff_nomatch(v_calls_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseOnce_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eraiseOnce(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eraiseDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseDef_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eraiseDef(V v_gl_240, V v_d_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    V v_ru_24t_243_24EVar = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_247;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EVar, 1);
      v_t_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24t_243_24EVar, TAG_Just, 1, (V[]){heff_get_n(v_u_246, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    V v_x1_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2410;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_249, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_247; V a_2 = v_t_2410; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
  }
  case TAG_EGlobal: {
    V v_ru_24t_243_24EGlobal = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EGlobal, 1);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24t_243_24EGlobal, TAG_Just, 1, (V[]){heff_get_n(v_u_2413, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    V v_x1_2415 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2417;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2416 = heff_field(v_x1_2415, 0);
      V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2416, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); heff_drop(v_t_2417); r_; });
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_t_243, 0);
    V v_b_2419 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_x1_2420 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2422;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Just = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      v_t_2422 = heff_tag_at_n(v_ru_24x1_2420_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2421, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_xs_2418; V a_2 = v_b_2419; V a_3 = v_t_2422; V a_4 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseTo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2422); r_; });
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2425 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_Nothing: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2426 = heff_field(v_x1_2425, 0);
      V v_ru_24x1_2425_24Just = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2426, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_x1_2428 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_Nothing: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2429 = heff_field(v_x1_2428, 0);
      V v_ru_24x1_2428_24Just = heff_take_reuse_n(v_x1_2428, 1ULL, 1);
      v_t_2430 = heff_tag_at_n(v_ru_24x1_2428_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2429, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2428);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2427; V a_2 = v_t_2430; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2427); heff_drop(v_t_2430); r_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_x1_2434 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2436;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nothing: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2435 = heff_field(v_x1_2434, 0);
      V v_ru_24x1_2434_24Just = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
      v_t_2436 = heff_tag_at_n(v_ru_24x1_2434_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2435, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    V v_x1_2437 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2439;
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_Nothing: {
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2438 = heff_field(v_x1_2437, 0);
      V v_ru_24x1_2437_24Just = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
      v_t_2439 = heff_tag_at_n(v_ru_24x1_2437_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2438, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2437);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2436; V a_2 = v_t_2439; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); heff_drop(v_t_2439); r_; });
  }
  case TAG_ERecord: {
    V v_ru_24t_243_24ERecord = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2441 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2443;
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24ERecord, 1);
      v_t_2443 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2442 = heff_field(v_x1_2441, 0);
      heff_take_n(v_x1_2441, 1ULL, 1);
      v_t_2443 = heff_tag_at_n(v_ru_24t_243_24ERecord, TAG_Just, 1, (V[]){heff_get_n(v_u_2442, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2441);
    }
    V v_x1_2444 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2446;
    switch (heff_tag_of(v_x1_2444)) {
    case TAG_Nothing: {
      v_t_2446 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2445 = heff_field(v_x1_2444, 0);
      V v_ru_24x1_2444_24Just = heff_take_reuse_n(v_x1_2444, 1ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24x1_2444_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2445, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2444);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2443; V a_2 = v_t_2446; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); heff_drop(v_t_2446); r_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_x1_2450 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2452;
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_Nothing: {
      v_t_2452 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2451 = heff_field(v_x1_2450, 0);
      V v_ru_24x1_2450_24Just = heff_take_reuse_n(v_x1_2450, 1ULL, 1);
      v_t_2452 = heff_tag_at_n(v_ru_24x1_2450_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2451, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2450);
    }
    V v_x1_2453 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2455;
    switch (heff_tag_of(v_x1_2453)) {
    case TAG_Nothing: {
      v_t_2455 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2454 = heff_field(v_x1_2453, 0);
      V v_ru_24x1_2453_24Just = heff_take_reuse_n(v_x1_2453, 1ULL, 1);
      v_t_2455 = heff_tag_at_n(v_ru_24x1_2453_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2454, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2453);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2452; V a_2 = v_t_2455; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2452); heff_drop(v_t_2455); r_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2458 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2460;
    switch (heff_tag_of(v_x1_2458)) {
    case TAG_Nothing: {
      v_t_2460 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2459 = heff_field(v_x1_2458, 0);
      V v_ru_24x1_2458_24Just = heff_take_reuse_n(v_x1_2458, 1ULL, 1);
      v_t_2460 = heff_tag_at_n(v_ru_24x1_2458_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2459, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2458);
    }
    V v_x1_2461 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2463;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nothing: {
      v_t_2463 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24Just = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      v_t_2463 = heff_tag_at_n(v_ru_24x1_2461_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2462, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2460; V a_2 = v_t_2463; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2460); heff_drop(v_t_2463); r_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2466 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2468;
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nothing: {
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2467 = heff_field(v_x1_2466, 0);
      V v_ru_24x1_2466_24Just = heff_take_reuse_n(v_x1_2466, 1ULL, 1);
      v_t_2468 = heff_tag_at_n(v_ru_24x1_2466_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2467, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2466);
    }
    V v_x1_2469 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2469)) {
    case TAG_Nothing: {
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2470 = heff_field(v_x1_2469, 0);
      V v_ru_24x1_2469_24Just = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
      v_t_2471 = heff_tag_at_n(v_ru_24x1_2469_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2470, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2469);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2468; V a_2 = v_t_2471; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2468); heff_drop(v_t_2471); r_; });
  }
  case TAG_EPrim: {
    V v_ru_24t_243_24EPrim = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2473 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2475;
    switch (heff_tag_of(v_x1_2473)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EPrim, 1);
      v_t_2475 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2474 = heff_field(v_x1_2473, 0);
      heff_take_n(v_x1_2473, 1ULL, 1);
      v_t_2475 = heff_tag_at_n(v_ru_24t_243_24EPrim, TAG_Just, 1, (V[]){heff_get_n(v_u_2474, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2473);
    }
    V v_x1_2476 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2478;
    switch (heff_tag_of(v_x1_2476)) {
    case TAG_Nothing: {
      v_t_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2477 = heff_field(v_x1_2476, 0);
      V v_ru_24x1_2476_24Just = heff_take_reuse_n(v_x1_2476, 1ULL, 1);
      v_t_2478 = heff_tag_at_n(v_ru_24x1_2476_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2477, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2476);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2475; V a_2 = v_t_2478; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2475); heff_drop(v_t_2478); r_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2481 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2483;
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_Nothing: {
      v_t_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2482 = heff_field(v_x1_2481, 0);
      V v_ru_24x1_2481_24Just = heff_take_reuse_n(v_x1_2481, 1ULL, 1);
      v_t_2483 = heff_tag_at_n(v_ru_24x1_2481_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2482, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2481);
    }
    V v_x1_2484 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2486;
    switch (heff_tag_of(v_x1_2484)) {
    case TAG_Nothing: {
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2485 = heff_field(v_x1_2484, 0);
      V v_ru_24x1_2484_24Just = heff_take_reuse_n(v_x1_2484, 1ULL, 1);
      v_t_2486 = heff_tag_at_n(v_ru_24x1_2484_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2485, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2484);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2483; V a_2 = v_t_2486; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2483); heff_drop(v_t_2486); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2489 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2491;
    switch (heff_tag_of(v_x1_2489)) {
    case TAG_Nothing: {
      v_t_2491 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2490 = heff_field(v_x1_2489, 0);
      V v_ru_24x1_2489_24Just = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
      v_t_2491 = heff_tag_at_n(v_ru_24x1_2489_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2490, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2489);
    }
    V v_x1_2492 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2494;
    switch (heff_tag_of(v_x1_2492)) {
    case TAG_Nothing: {
      v_t_2494 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2493 = heff_field(v_x1_2492, 0);
      V v_ru_24x1_2492_24Just = heff_take_reuse_n(v_x1_2492, 1ULL, 1);
      v_t_2494 = heff_tag_at_n(v_ru_24x1_2492_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2493, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2492);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2491; V a_2 = v_t_2494; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2491); heff_drop(v_t_2494); r_; });
  }
  case TAG_EInt: {
    V v_ru_24t_243_24EInt = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2496 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2498;
    switch (heff_tag_of(v_x1_2496)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EInt, 1);
      v_t_2498 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2497 = heff_field(v_x1_2496, 0);
      heff_take_n(v_x1_2496, 1ULL, 1);
      v_t_2498 = heff_tag_at_n(v_ru_24t_243_24EInt, TAG_Just, 1, (V[]){heff_get_n(v_u_2497, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2496);
    }
    V v_x1_2499 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24101;
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_Nothing: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24100 = heff_field(v_x1_2499, 0);
      V v_ru_24x1_2499_24Just = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
      v_t_24101 = heff_tag_at_n(v_ru_24x1_2499_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24100, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2499);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2498; V a_2 = v_t_24101; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2498); heff_drop(v_t_24101); r_; });
  }
  case TAG_EFloat: {
    V v_ru_24t_243_24EFloat = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_24103 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24105;
    switch (heff_tag_of(v_x1_24103)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EFloat, 1);
      v_t_24105 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24104 = heff_field(v_x1_24103, 0);
      heff_take_n(v_x1_24103, 1ULL, 1);
      v_t_24105 = heff_tag_at_n(v_ru_24t_243_24EFloat, TAG_Just, 1, (V[]){heff_get_n(v_u_24104, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24103);
    }
    V v_x1_24106 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24108;
    switch (heff_tag_of(v_x1_24106)) {
    case TAG_Nothing: {
      v_t_24108 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24107 = heff_field(v_x1_24106, 0);
      V v_ru_24x1_24106_24Just = heff_take_reuse_n(v_x1_24106, 1ULL, 1);
      v_t_24108 = heff_tag_at_n(v_ru_24x1_24106_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24107, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24106);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24105; V a_2 = v_t_24108; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24105); heff_drop(v_t_24108); r_; });
  }
  case TAG_EStr: {
    V v_ru_24t_243_24EStr = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_24110 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24112;
    switch (heff_tag_of(v_x1_24110)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EStr, 1);
      v_t_24112 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24111 = heff_field(v_x1_24110, 0);
      heff_take_n(v_x1_24110, 1ULL, 1);
      v_t_24112 = heff_tag_at_n(v_ru_24t_243_24EStr, TAG_Just, 1, (V[]){heff_get_n(v_u_24111, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24110);
    }
    V v_x1_24113 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24115;
    switch (heff_tag_of(v_x1_24113)) {
    case TAG_Nothing: {
      v_t_24115 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24114 = heff_field(v_x1_24113, 0);
      V v_ru_24x1_24113_24Just = heff_take_reuse_n(v_x1_24113, 1ULL, 1);
      v_t_24115 = heff_tag_at_n(v_ru_24x1_24113_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24114, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24113);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24112; V a_2 = v_t_24115; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24112); heff_drop(v_t_24115); r_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_24118 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24120;
    switch (heff_tag_of(v_x1_24118)) {
    case TAG_Nothing: {
      v_t_24120 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24119 = heff_field(v_x1_24118, 0);
      V v_ru_24x1_24118_24Just = heff_take_reuse_n(v_x1_24118, 1ULL, 1);
      v_t_24120 = heff_tag_at_n(v_ru_24x1_24118_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24119, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24118);
    }
    V v_x1_24121 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24123;
    switch (heff_tag_of(v_x1_24121)) {
    case TAG_Nothing: {
      v_t_24123 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24122 = heff_field(v_x1_24121, 0);
      V v_ru_24x1_24121_24Just = heff_take_reuse_n(v_x1_24121, 1ULL, 1);
      v_t_24123 = heff_tag_at_n(v_ru_24x1_24121_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24122, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24121);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24120; V a_2 = v_t_24123; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24120); heff_drop(v_t_24123); r_; });
  }
  case TAG_EFloat32: {
    V v_ru_24t_243_24EFloat32 = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_24125 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24127;
    switch (heff_tag_of(v_x1_24125)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EFloat32, 1);
      v_t_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24126 = heff_field(v_x1_24125, 0);
      heff_take_n(v_x1_24125, 1ULL, 1);
      v_t_24127 = heff_tag_at_n(v_ru_24t_243_24EFloat32, TAG_Just, 1, (V[]){heff_get_n(v_u_24126, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24125);
    }
    V v_x1_24128 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24130;
    switch (heff_tag_of(v_x1_24128)) {
    case TAG_Nothing: {
      v_t_24130 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24129 = heff_field(v_x1_24128, 0);
      V v_ru_24x1_24128_24Just = heff_take_reuse_n(v_x1_24128, 1ULL, 1);
      v_t_24130 = heff_tag_at_n(v_ru_24x1_24128_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24129, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24128);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24127; V a_2 = v_t_24130; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24127); heff_drop(v_t_24130); r_; });
  }
  case TAG_EAbandon: {
    V v_x1_24131 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24133;
    switch (heff_tag_of(v_x1_24131)) {
    case TAG_Nothing: {
      v_t_24133 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24132 = heff_field(v_x1_24131, 0);
      V v_ru_24x1_24131_24Just = heff_take_reuse_n(v_x1_24131, 1ULL, 1);
      v_t_24133 = heff_tag_at_n(v_ru_24x1_24131_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24132, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24131);
    }
    V v_x1_24134 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24136;
    switch (heff_tag_of(v_x1_24134)) {
    case TAG_Nothing: {
      v_t_24136 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24135 = heff_field(v_x1_24134, 0);
      V v_ru_24x1_24134_24Just = heff_take_reuse_n(v_x1_24134, 1ULL, 1);
      v_t_24136 = heff_tag_at_n(v_ru_24x1_24134_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24135, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24134);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24133; V a_2 = v_t_24136; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24133); heff_drop(v_t_24136); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_24139 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24141;
    switch (heff_tag_of(v_x1_24139)) {
    case TAG_Nothing: {
      v_t_24141 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24140 = heff_field(v_x1_24139, 0);
      V v_ru_24x1_24139_24Just = heff_take_reuse_n(v_x1_24139, 1ULL, 1);
      v_t_24141 = heff_tag_at_n(v_ru_24x1_24139_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24140, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24139);
    }
    V v_x1_24142 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24144;
    switch (heff_tag_of(v_x1_24142)) {
    case TAG_Nothing: {
      v_t_24144 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24143 = heff_field(v_x1_24142, 0);
      V v_ru_24x1_24142_24Just = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
      v_t_24144 = heff_tag_at_n(v_ru_24x1_24142_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24143, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24142);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24141; V a_2 = v_t_24144; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24141); heff_drop(v_t_24144); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecallarity_2eraiseDef(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArg_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArg(V v_t_240, V v_h_241, V v_j_242, V v_a_243) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam0, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V v_ys_248 = heff_field(v_a_243, 0);
    V v_b_249 = heff_field(v_a_243, 1);
    heff_take_n(v_a_243, 3ULL, 2);
    V v_x2_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_h_241), heff_rfield(v_t_240, 0)));
    V v_a_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      v_a_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_ps_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      v_a_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_242); V a_2 = v_ps_2411; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_b_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_248));
    if (heff_intLt_c(v_b_2413, v_a_2412)) {
      V v_x2_2415 = ({ V a_0 = v_h_241; V b_1 = heff_get_n(v_t_240, 0, 1); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2417;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nothing: {
        heff_drop(v_j_242);
        v_t_2417 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_ps_2416 = heff_field(v_x2_2415, 0);
        heff_take_n(v_x2_2415, 1ULL, 1);
        v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_242; V a_2 = v_ps_2416; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      V v_t_2418 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_t_2419 = heff_intSub(v_t_2417, v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam2, 1, 3, (V[]){v_t_2419, v_ys_248, v_b_249});
    } else {
      heff_drop_rec(v_t_240, 1);
      heff_drop(v_h_241);
      heff_drop(v_j_242);
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam3, 1, 2, (V[]){v_ys_248, v_b_249});
    }
  }
  case TAG_EApp: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELet: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EProj: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam10, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam11, 1, 1, (V[]){v_a_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam12, 1, 1, (V[]){v_a_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam13, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam14, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam15, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam16, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam17, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam18, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam19, 1, 1, (V[]){v_a_243});
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandArg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_247});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_t_2419 = heff_env(self)[0];
  V v_ys_248 = heff_env(self)[1];
  V v_b_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = (g_heff_2ecompile_2ecallarity_2efreshMany(v_t_2419, v_n_2420));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = (g_prelude_2e_2b_2b(v_ys_248, heff_dup(v_x_2422)));
    V v_x_2425 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_ELam, 2, (V[]){v_t_2424, (g_heff_2ecompile_2ecallarity_2eextend(v_x_2422, v_b_249))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_n_2423});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args) {
  V v_n_2426 = args[0];
  V v_ys_248 = heff_env(self)[0];
  V v_b_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_248, v_b_249}), v_n_2426});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args) {
  V v_n_2429 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2429});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2433});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args) {
  V v_n_2435 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2435});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args) {
  V v_n_2439 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2439});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args) {
  V v_n_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2442});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args) {
  V v_n_2445 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2445});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args) {
  V v_n_2447 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2447});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args) {
  V v_n_2450 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2450});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args) {
  V v_n_2453 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2453});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args) {
  V v_n_2455 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2455});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args) {
  V v_n_2457 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2457});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args) {
  V v_n_2459 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2459});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args) {
  V v_n_2462 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2462});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args) {
  V v_n_2464 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2464});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args) {
  V v_n_2465 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2465});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args) {
  V v_n_2468 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2468});
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArgs(V v_go_240, V v_t_241, V v_h_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_t_241);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    return ((V)&g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_244, 0);
    V v_as_247 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_246}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1, 1, 6, (V[]){v_m_248, v_t_241, v_h_242, v_j_243, v_go_240, v_as_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandArgs(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_go_240 = heff_env(self)[4];
  V v_as_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_m_2413 = (g_heff_2ecompile_2ecallarity_2eexpandArg(heff_dup(v_t_241), heff_dup(v_h_242), heff_dup(v_j_243), v_x_2411));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_m_2417 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_240, v_t_241, v_h_242, heff_intAdd(v_j_243, MK_INT(1LL)), v_as_247));
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_n_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandApp_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandApp(V v_go_240, V v_t_241, V v_f_242, V v_as_243) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    heff_drop(v_t_241);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam0, 1, 3, (V[]){v_m_245, v_go_240, v_as_243});
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_f_242, 0);
    heff_take_n(v_f_242, 1ULL, 1);
    V v_m_2415 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_240, v_t_241, heff_dup(v_g_2414), MK_INT(0LL), v_as_243));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam1, 1, 2, (V[]){v_m_2415, v_g_2414});
  }
  case TAG_ELam: {
    heff_drop(v_t_241);
    V v_m_2423 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam2, 1, 3, (V[]){v_m_2423, v_go_240, v_as_243});
  }
  case TAG_EApp: {
    heff_drop(v_t_241);
    V v_m_2434 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam3, 1, 3, (V[]){v_m_2434, v_go_240, v_as_243});
  }
  case TAG_ELet: {
    heff_drop(v_t_241);
    V v_m_2446 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam4, 1, 3, (V[]){v_m_2446, v_go_240, v_as_243});
  }
  case TAG_ERecord: {
    heff_drop(v_t_241);
    V v_m_2456 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam5, 1, 3, (V[]){v_m_2456, v_go_240, v_as_243});
  }
  case TAG_EProj: {
    heff_drop(v_t_241);
    V v_m_2468 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam6, 1, 3, (V[]){v_m_2468, v_go_240, v_as_243});
  }
  case TAG_ETag: {
    heff_drop(v_t_241);
    V v_m_2479 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam7, 1, 3, (V[]){v_m_2479, v_go_240, v_as_243});
  }
  case TAG_EMatch: {
    heff_drop(v_t_241);
    V v_m_2490 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam8, 1, 3, (V[]){v_m_2490, v_go_240, v_as_243});
  }
  case TAG_EPrim: {
    heff_drop(v_t_241);
    V v_m_24100 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam9, 1, 3, (V[]){v_m_24100, v_go_240, v_as_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_t_241);
    V v_m_24111 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam10, 1, 3, (V[]){v_m_24111, v_go_240, v_as_243});
  }
  case TAG_ECall: {
    heff_drop(v_t_241);
    V v_m_24122 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam11, 1, 3, (V[]){v_m_24122, v_go_240, v_as_243});
  }
  case TAG_EInt: {
    heff_drop(v_t_241);
    V v_m_24132 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam12, 1, 3, (V[]){v_m_24132, v_go_240, v_as_243});
  }
  case TAG_EFloat: {
    heff_drop(v_t_241);
    V v_m_24142 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam13, 1, 3, (V[]){v_m_24142, v_go_240, v_as_243});
  }
  case TAG_EStr: {
    heff_drop(v_t_241);
    V v_m_24152 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam14, 1, 3, (V[]){v_m_24152, v_go_240, v_as_243});
  }
  case TAG_EFixed: {
    heff_drop(v_t_241);
    V v_m_24163 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam15, 1, 3, (V[]){v_m_24163, v_go_240, v_as_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_241);
    V v_m_24173 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam16, 1, 3, (V[]){v_m_24173, v_go_240, v_as_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_241);
    V v_m_24182 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam17, 1, 3, (V[]){v_m_24182, v_go_240, v_as_243});
  }
  case TAG_EFix: {
    heff_drop(v_t_241);
    V v_m_24193 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_f_242}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandApp_lam18, 1, 3, (V[]){v_m_24193, v_go_240, v_as_243});
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandApp(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_x_2418});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    V v_m_2428 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2427}));
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_n_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2426, v_x_2430}), v_n_2431});
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    V v_m_2439 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_n_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2437, v_x_2441}), v_n_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam4(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    V v_m_2451 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_n_2450}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_n_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2449, v_x_2453}), v_n_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam5(V self, V *args) {
  V v_n_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_n_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_n_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2460}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_n_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2459, v_x_2463}), v_n_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam6(V self, V *args) {
  V v_n_2469 = args[0];
  V v_m_2468 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2470 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_n_2469}));
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkPair: {
    V v_x_2471 = heff_field(v_x2_2470, 0);
    V v_n_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    V v_m_2473 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2474 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_n_2472}));
    switch (heff_tag_of(v_x2_2474)) {
    case TAG_MkPair: {
      V v_x_2475 = heff_field(v_x2_2474, 0);
      V v_n_2476 = heff_field(v_x2_2474, 1);
      heff_take_n(v_x2_2474, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2471, v_x_2475}), v_n_2476});
    }
    default: return heff_nomatch(v_x2_2474);
    }
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam7(V self, V *args) {
  V v_n_2480 = args[0];
  V v_m_2479 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2481 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_n_2480}));
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_n_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    V v_m_2484 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_n_2483}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_n_2487 = heff_field(v_x2_2485, 1);
      heff_take_n(v_x2_2485, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2482, v_x_2486}), v_n_2487});
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam8(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_m_2495 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_2496 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_n_2494}));
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_MkPair: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_n_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2493, v_x_2497}), v_n_2498});
    }
    default: return heff_nomatch(v_x2_2496);
    }
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam9(V self, V *args) {
  V v_n_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_n_24101}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_MkPair: {
    V v_x_24103 = heff_field(v_x2_24102, 0);
    V v_n_24104 = heff_field(v_x2_24102, 1);
    V v_ru_24x2_24102_24MkPair = heff_take_reuse_n(v_x2_24102, 3ULL, 2);
    V v_m_24105 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24106 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_n_24104}));
    switch (heff_tag_of(v_x2_24106)) {
    case TAG_MkPair: {
      V v_x_24107 = heff_field(v_x2_24106, 0);
      V v_n_24108 = heff_field(v_x2_24106, 1);
      heff_take_n(v_x2_24106, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24103, v_x_24107}), v_n_24108});
    }
    default: return heff_nomatch(v_x2_24106);
    }
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam10(V self, V *args) {
  V v_n_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_n_24112}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_MkPair: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    V v_n_24115 = heff_field(v_x2_24113, 1);
    V v_ru_24x2_24113_24MkPair = heff_take_reuse_n(v_x2_24113, 3ULL, 2);
    V v_m_24116 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24117 = heff_tr(heff_call(v_m_24116, 1, (V[]){v_n_24115}));
    switch (heff_tag_of(v_x2_24117)) {
    case TAG_MkPair: {
      V v_x_24118 = heff_field(v_x2_24117, 0);
      V v_n_24119 = heff_field(v_x2_24117, 1);
      heff_take_n(v_x2_24117, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24114, v_x_24118}), v_n_24119});
    }
    default: return heff_nomatch(v_x2_24117);
    }
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam11(V self, V *args) {
  V v_n_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_n_24123}));
  switch (heff_tag_of(v_x2_24124)) {
  case TAG_MkPair: {
    V v_x_24125 = heff_field(v_x2_24124, 0);
    V v_n_24126 = heff_field(v_x2_24124, 1);
    V v_ru_24x2_24124_24MkPair = heff_take_reuse_n(v_x2_24124, 3ULL, 2);
    V v_m_24127 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24128 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_n_24126}));
    switch (heff_tag_of(v_x2_24128)) {
    case TAG_MkPair: {
      V v_x_24129 = heff_field(v_x2_24128, 0);
      V v_n_24130 = heff_field(v_x2_24128, 1);
      heff_take_n(v_x2_24128, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24125, v_x_24129}), v_n_24130});
    }
    default: return heff_nomatch(v_x2_24128);
    }
  }
  default: return heff_nomatch(v_x2_24124);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam12(V self, V *args) {
  V v_n_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_n_24133}));
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    V v_n_24136 = heff_field(v_x2_24134, 1);
    V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
    V v_m_24137 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24138 = heff_tr(heff_call(v_m_24137, 1, (V[]){v_n_24136}));
    switch (heff_tag_of(v_x2_24138)) {
    case TAG_MkPair: {
      V v_x_24139 = heff_field(v_x2_24138, 0);
      V v_n_24140 = heff_field(v_x2_24138, 1);
      heff_take_n(v_x2_24138, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24135, v_x_24139}), v_n_24140});
    }
    default: return heff_nomatch(v_x2_24138);
    }
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam13(V self, V *args) {
  V v_n_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24144 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_n_24143}));
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkPair: {
    V v_x_24145 = heff_field(v_x2_24144, 0);
    V v_n_24146 = heff_field(v_x2_24144, 1);
    V v_ru_24x2_24144_24MkPair = heff_take_reuse_n(v_x2_24144, 3ULL, 2);
    V v_m_24147 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24148 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_n_24146}));
    switch (heff_tag_of(v_x2_24148)) {
    case TAG_MkPair: {
      V v_x_24149 = heff_field(v_x2_24148, 0);
      V v_n_24150 = heff_field(v_x2_24148, 1);
      heff_take_n(v_x2_24148, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24145, v_x_24149}), v_n_24150});
    }
    default: return heff_nomatch(v_x2_24148);
    }
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam14(V self, V *args) {
  V v_n_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_n_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_n_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    V v_m_24157 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24158 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_n_24156}));
    switch (heff_tag_of(v_x2_24158)) {
    case TAG_MkPair: {
      V v_x_24159 = heff_field(v_x2_24158, 0);
      V v_n_24160 = heff_field(v_x2_24158, 1);
      heff_take_n(v_x2_24158, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24155, v_x_24159}), v_n_24160});
    }
    default: return heff_nomatch(v_x2_24158);
    }
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam15(V self, V *args) {
  V v_n_24164 = args[0];
  V v_m_24163 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24165 = heff_tr(heff_call(v_m_24163, 1, (V[]){v_n_24164}));
  switch (heff_tag_of(v_x2_24165)) {
  case TAG_MkPair: {
    V v_x_24166 = heff_field(v_x2_24165, 0);
    V v_n_24167 = heff_field(v_x2_24165, 1);
    V v_ru_24x2_24165_24MkPair = heff_take_reuse_n(v_x2_24165, 3ULL, 2);
    V v_m_24168 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_n_24167}));
    switch (heff_tag_of(v_x2_24169)) {
    case TAG_MkPair: {
      V v_x_24170 = heff_field(v_x2_24169, 0);
      V v_n_24171 = heff_field(v_x2_24169, 1);
      heff_take_n(v_x2_24169, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24165_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24166, v_x_24170}), v_n_24171});
    }
    default: return heff_nomatch(v_x2_24169);
    }
  }
  default: return heff_nomatch(v_x2_24165);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam16(V self, V *args) {
  V v_n_24174 = args[0];
  V v_m_24173 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24175 = heff_tr(heff_call(v_m_24173, 1, (V[]){v_n_24174}));
  switch (heff_tag_of(v_x2_24175)) {
  case TAG_MkPair: {
    V v_x_24176 = heff_field(v_x2_24175, 0);
    V v_n_24177 = heff_field(v_x2_24175, 1);
    V v_ru_24x2_24175_24MkPair = heff_take_reuse_n(v_x2_24175, 3ULL, 2);
    V v_m_24178 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24179 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_n_24177}));
    switch (heff_tag_of(v_x2_24179)) {
    case TAG_MkPair: {
      V v_x_24180 = heff_field(v_x2_24179, 0);
      V v_n_24181 = heff_field(v_x2_24179, 1);
      heff_take_n(v_x2_24179, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24175_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24176, v_x_24180}), v_n_24181});
    }
    default: return heff_nomatch(v_x2_24179);
    }
  }
  default: return heff_nomatch(v_x2_24175);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam17(V self, V *args) {
  V v_n_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_n_24183}));
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_x_24185 = heff_field(v_x2_24184, 0);
    V v_n_24186 = heff_field(v_x2_24184, 1);
    V v_ru_24x2_24184_24MkPair = heff_take_reuse_n(v_x2_24184, 3ULL, 2);
    V v_m_24187 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24188 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_n_24186}));
    switch (heff_tag_of(v_x2_24188)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_field(v_x2_24188, 0);
      V v_n_24190 = heff_field(v_x2_24188, 1);
      heff_take_n(v_x2_24188, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24185, v_x_24189}), v_n_24190});
    }
    default: return heff_nomatch(v_x2_24188);
    }
  }
  default: return heff_nomatch(v_x2_24184);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandApp_lam18(V self, V *args) {
  V v_n_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_n_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_n_24197 = heff_field(v_x2_24195, 1);
    V v_ru_24x2_24195_24MkPair = heff_take_reuse_n(v_x2_24195, 3ULL, 2);
    V v_m_24198 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_go_240, v_as_243));
    V v_x2_24199 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_n_24197}));
    switch (heff_tag_of(v_x2_24199)) {
    case TAG_MkPair: {
      V v_x_24200 = heff_field(v_x2_24199, 0);
      V v_n_24201 = heff_field(v_x2_24199, 1);
      heff_take_n(v_x2_24199, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24196, v_x_24200}), v_n_24201});
    }
    default: return heff_nomatch(v_x2_24199);
    }
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eexpandGo(V v_t_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_247));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_241, 0);
    V v_as_2414 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    return (g_heff_2ecompile_2ecallarity_2eexpandApp(v_t_2415, v_t_240, v_f_2413, v_as_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_e_241, 0);
    V v_a_2417 = heff_field(v_e_241, 1);
    V v_b_2418 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2419 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_a_2417));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam3, 1, 4, (V[]){v_m_2419, v_t_240, v_b_2418, v_x_2416});
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_go_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2438 = (g_heff_2ecompile_2ecallarity_2etraverseS(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam4, 1, 1, (V[]){v_go_2429}), v_fs_2428));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam6, 1, 1, (V[]){v_m_2438});
  }
  case TAG_EProj: {
    V v_e1_2443 = heff_field(v_e_241, 0);
    V v_l_2444 = heff_field(v_e_241, 1);
    V v_sh_2445 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2446 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_e1_2443));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam7, 1, 3, (V[]){v_m_2446, v_l_2444, v_sh_2445});
  }
  case TAG_ETag: {
    V v_tg_2451 = heff_field(v_e_241, 0);
    V v_as_2452 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2454 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_t_2453, v_as_2452));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam8, 1, 2, (V[]){v_m_2454, v_tg_2451});
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_e_241, 0);
    V v_arms_2460 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_s_2459));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam9, 1, 3, (V[]){v_m_2461, v_t_240, v_arms_2460});
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam12, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_2482 = heff_field(v_e_241, 0);
    V v_as_2483 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2484 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2485 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_t_2484, v_as_2483));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam13, 1, 2, (V[]){v_m_2485, v_p_2482});
  }
  case TAG_ECall: {
    V v_g_2490 = heff_field(v_e_241, 0);
    V v_as_2491 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2492 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_m_2493 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_t_2492, v_t_240, heff_dup(v_g_2490), MK_INT(0LL), v_as_2491));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam14, 1, 2, (V[]){v_m_2493, v_g_2490});
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam15, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam16, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam17, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam18, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam19, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam20, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam21, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_243});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_b_2418 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_m_2424 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_2418));
    V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2423}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_n_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_x_2422, v_x_2426}), v_n_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args) {
  V v_n_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_l_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_n_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2431, v_x_2436}), v_n_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_go_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_l_2431 = heff_field(v_x2_2430, 0);
    V v_e_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_m_2433 = heff_tr(heff_call(v_go_2429, 1, (V[]){v_e_2432}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam5, 1, 2, (V[]){v_m_2433, v_l_2431});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args) {
  V v_n_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_n_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_x_2441}), v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_l_2444 = heff_env(self)[1];
  V v_sh_2445 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_x_2449, v_l_2444, v_sh_2445}), v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_tg_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_n_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_tg_2451, v_x_2457}), v_n_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args) {
  V v_n_2472 = args[0];
  V v_m_2471 = heff_env(self)[0];
  V v_tg_2468 = heff_env(self)[1];
  V v_vs_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2473 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_n_2472}));
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_field(v_x2_2473, 0);
    V v_n_2475 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tg_2468, v_vs_2469, v_x_2474}), v_n_2475});
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args) {
  V v_x2_2467 = args[0];
  V v_go_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkArm: {
    V v_tg_2468 = heff_field(v_x2_2467, 0);
    V v_vs_2469 = heff_field(v_x2_2467, 1);
    V v_b_2470 = heff_field(v_x2_2467, 2);
    heff_take_n(v_x2_2467, 7ULL, 3);
    V v_m_2471 = heff_tr(heff_call(v_go_2466, 1, (V[]){v_b_2470}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam11, 1, 3, (V[]){v_m_2471, v_tg_2468, v_vs_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_arms_2460 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    V v_go_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2476 = (g_heff_2ecompile_2ecallarity_2etraverseS(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam10, 1, 1, (V[]){v_go_2466}), v_arms_2460));
    V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_n_2465}));
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_MkPair: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_n_2479 = heff_field(v_x2_2477, 1);
      heff_take_n(v_x2_2477, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2464, v_x_2478}), v_n_2479});
    }
    default: return heff_nomatch(v_x2_2477);
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2481});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args) {
  V v_n_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  V v_p_2482 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2487 = heff_tr(heff_call(v_m_2485, 1, (V[]){v_n_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_n_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2482, v_x_2488}), v_n_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args) {
  V v_n_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_g_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_n_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_n_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2490, v_x_2496}), v_n_2497});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args) {
  V v_n_2499 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2499});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args) {
  V v_n_24101 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24101});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args) {
  V v_n_24103 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24103});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args) {
  V v_n_24106 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24106});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args) {
  V v_n_24108 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24108});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args) {
  V v_n_24109 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24109});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args) {
  V v_n_24112 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24112});
}
Clo g_heff_2ecompile_2ecallarity_2enotedThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enotedThen_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enotedThen(V v_ar_240, V v_acc_241, V v_d_242, V v_n_243, V v_notes_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_notes_244, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop_rec(v_notes_244, 3);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 0, 2);
    V v_m_247 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_246, heff_take_field(v_d_242, 2)));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_243}));
    V v_x3_2412;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = ({ V rv_2 = v_x_249; V rr_ = heff_rec_reuse_n(v_d_242, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_x3_2412 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_n_2410});
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    switch (heff_tag_of(v_x3_2412)) {
    case TAG_MkPair: {
      V v_d_2413 = heff_field(v_x3_2412, 0);
      V v_n_2414 = heff_field(v_x3_2412, 1);
      V v_ru_24x3_2412_24MkPair = heff_take_reuse_n(v_x3_2412, 3ULL, 2);
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 0, 2);
      V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_acc_241, 0)), 1, 2);
      V v_t_2417 = (g_heff_2ecompile_2ecallarity_2edefNotes(v_t_2415, v_ar_240, v_t_2416, heff_dup(v_d_2413)));
      V v_k_2418 = (g_heff_2ecompile_2ecallarity_2eknownAdd(heff_take_field(v_acc_241, 0), heff_dup(v_d_2413), v_t_2417));
      V v_t_2419 = heff_tag_at_n(v_ru_24x3_2412_24MkPair, TAG_Cons, 2, (V[]){v_d_2413, heff_get_n(v_acc_241, 1, 3)});
      return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2418, v_t_2419, v_n_2414});
    }
    default: return heff_nomatch(v_x3_2412);
    }
  }
  case TAG_False: {
    heff_drop(v_ar_240);
    V v_k_2420 = (g_heff_2ecompile_2ecallarity_2eknownAdd(heff_take_field(v_acc_241, 0), heff_dup(v_d_242), v_notes_244));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_get_n(v_acc_241, 1, 3)});
    return heff_rec_n(3, shape_known__defs__supply, (V[]){v_k_2420, v_t_2421, v_n_243});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2ecallarity_2enotedThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2enotedThen(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2ecallarity_2esameInts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameInts_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameInts(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_intEq_c(heff_dup(v_x_244), heff_dup(v_y_246))) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameInts(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameAll_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameAll(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2ecallarity_2esameInts(v_x_244, v_y_246));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameAll(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameTables_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameTables_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameTables(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = (g_map_2esize(heff_rfield(v_a_240, 0)));
  V v_t_243 = (g_map_2esize(heff_rfield(v_b_241, 0)));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    V v_t_245 = ({ V b_0 = heff_get_n(v_a_240, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_list_2emap_24s366344330x1145113647(v_t_245));
    V v_t_247 = ({ V b_0 = heff_get_n(v_b_241, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
    return ({ V a_0 = v_t_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2ecallarity_2esameAll(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_t_248); r_; });
  } else {
    heff_drop_rec(v_a_240, 1);
    heff_drop_rec(v_b_241, 1);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2ecallarity_2esameTables_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2esameTables(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eafterRound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eafterRound_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eafterRound(V v_more_240, V v_before_241, V v_n_242, V v_acc_243) {
top: ;
  if (heff_intEq_c(heff_dup(heff_rfield(v_acc_243, 2)), heff_dup(v_n_242))) {
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_acc_243, 0)), 0, 2);
    V v_t_246 = (g_heff_2ecompile_2ecallarity_2esameTables(heff_get_n(v_before_241, 0, 2), v_t_245));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_more_240);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 1, 3)));
      return heff_rec_n(2, shape_defs__supply, (V[]){v_t_247, v_n_242});
    }
    case TAG_False: {
      heff_drop(v_n_242);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
      return heff_tail(v_more_240, 3, (V[]){heff_dup(heff_rfield(v_acc_243, 0)), v_t_248, heff_get_n(v_acc_243, 2, 3)});
    }
    default: return heff_nomatch(v_t_246);
    }
  } else {
    heff_drop_rec(v_before_241, 2);
    heff_drop(v_n_242);
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
    return heff_tail(v_more_240, 3, (V[]){heff_dup(heff_rfield(v_acc_243, 0)), v_t_249, heff_get_n(v_acc_243, 2, 3)});
  }
}
V g_heff_2ecompile_2ecallarity_2eafterRound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eafterRound(a[0], a[1], a[2], a[3]);
}

static V g_heff_2ecompile_2ecallarity_2eroundsMost_val;
static HEFF_ONCE g_heff_2ecompile_2ecallarity_2eroundsMost_st;
static V g_heff_2ecompile_2ecallarity_2eroundsMost_init(void) {
  return MK_INT(3LL);
}
V g_heff_2ecompile_2ecallarity_2eroundsMost_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecallarity_2eroundsMost_st)) return g_heff_2ecompile_2ecallarity_2eroundsMost_val;
  return heff_global(&g_heff_2ecompile_2ecallarity_2eroundsMost_val, &g_heff_2ecompile_2ecallarity_2eroundsMost_st, g_heff_2ecompile_2ecallarity_2eroundsMost_init);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2erounds_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2erounds(V v_left_240, V v_before_241, V v_defs_242, V v_n_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_left_240), MK_INT(0LL))) {
    heff_drop(v_left_240);
    heff_drop_rec(v_before_241, 2);
    return heff_rec_n(2, shape_defs__supply, (V[]){v_defs_242, v_n_243});
  } else {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2erounds_clo), 1, (V[]){heff_intSub(v_left_240, MK_INT(1LL))}));
    V v_ar_246 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_map_2eempty_get()), v_defs_242));
    V v_t_247 = heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){heff_dup(g_map_2eempty_get())}), heff_dup(g_map_2eempty_get())});
    V v_t_248 = heff_rec_n(3, shape_known__defs__supply, (V[]){v_t_247, NTAG(TAG_Nil), heff_dup(v_n_243)});
    V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecallarity_2erounds_lam0, 2, 2, (V[]){heff_dup(v_before_241), v_ar_246}); V a_1 = v_t_248; V a_2 = v_defs_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_242); r_; });
    HEFF_LAST return g_heff_2ecompile_2ecallarity_2eafterRound(v_t_245, v_before_241, v_n_243, v_t_2417);
  }
}
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_d_2410 = args[1];
  V v_before_241 = heff_env(self)[0];
  V v_ar_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2411 = ({ V b_0 = heff_get_n(v_before_241, 1, 2); V a_1 = v_d_2410; V a_2 = heff_dup(heff_rfield(v_acc_249, 2)); V r_ = (g_heff_2ecompile_2ecallarity_2eraiseDef(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_MkPair: {
    V v_d_2412 = heff_field(v_x3_2411, 0);
    V v_n_2413 = heff_field(v_x3_2411, 1);
    heff_take_n(v_x3_2411, 3ULL, 2);
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 0, 2);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 1, 2);
    V v_t_2416 = (g_heff_2ecompile_2ecallarity_2edefNotes(v_t_2414, heff_dup(v_ar_246), v_t_2415, heff_dup(v_d_2412)));
    return (g_heff_2ecompile_2ecallarity_2enotedThen(v_ar_246, v_acc_249, v_d_2412, v_n_2413, v_t_2416));
  }
  default: return heff_nomatch(v_x3_2411);
  }
}